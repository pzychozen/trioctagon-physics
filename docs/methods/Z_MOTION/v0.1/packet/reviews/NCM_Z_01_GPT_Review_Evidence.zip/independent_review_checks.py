"""Independent retained-data/geometry review; no project imports or state updates.
Run: python -I -B independent_review_checks.py --root <review-root>
Only supplied points and supplied counterfactual endpoints are evaluated.
"""
from pathlib import Path
import argparse, json, math
import mpmath as mp
import sympy as sp

ap=argparse.ArgumentParser();ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1]);args=ap.parse_args()
r=args.root/'received';out=args.root/'evidence'
O=json.loads((r/'OBSERVATIONS.json').read_text())
G=json.loads((r/'GAP_COMPARISON.json').read_text())
mp.mp.dps=80
checks=[]
def test(name, ok, detail=None):
    checks.append({'name':name,'passed':bool(ok),'detail':detail})
    if not ok: raise AssertionError(name)
def mvec(v):return mp.matrix([mp.mpf(x) for x in v])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def dist(a,b):return mp.sqrt(dot(a-b,a-b))
rt2=mp.sqrt(2); rt3=mp.sqrt(3)
r0=rt3/6;d=1-rt2/2;a=d/2;h=(rt2-1)/2
rho=mp.sqrt(mp.mpf(13)/12-rt2/2)
# Use exact directional radicals rather than the submitted trigonometric grid.
e=[(0,-1),(rt3/2,-mp.mpf(1)/2),(rt3/2,mp.mpf(1)/2),(0,1),(-rt3/2,mp.mpf(1)/2),(-rt3/2,-mp.mpf(1)/2)]
def arcs(tau,hand):
    xi=tau/r0;sgn=-1 if hand=='MINUS' else 1
    def pt(i,scale,height,bottom=False):
        x,y=e[i%6]
        if bottom:x,y=x+xi*y,y-xi*x
        return mp.matrix([sgn*scale*x,scale*y,height])
    ans={}
    for sign in [1,-1]:
        for k in range(3):
            ans[f"G{'+' if sign==1 else '-'}{k}"]=[pt(2*k,r0,mp.mpf(sign)/2,sign<0),pt(2*k+1,a,sign*h,sign<0),pt(2*(k+1),r0,mp.mpf(sign)/2,sign<0)]
    return ans

def nearest_segment(p,q,t):
    v=t-q;u=dot(p-q,v)/dot(v,v)
    u=max(mp.mpf(0),min(mp.mpf(1),u));c=q+u*v
    return dist(p,c),c,u

def arc_details(p,arc):
    ss=[nearest_segment(p,arc[i],arc[i+1]) for i in range(2)]
    return min(x[0] for x in ss),ss

max_res=mp.mpf(0)
for case in G['references']:
    geom=case['geometry'];aa=arcs(mp.mpf(0) if geom['tau']==0 else h,geom['branch'])
    for row in case['points']:
        p=mvec(row['centered']);dd={k:arc_details(p,arc)[0] for k,arc in aa.items()}
        matches=[]
        for rec in row['arcs']:
            err=abs(dd[rec['label']]-mp.mpf(rec['distance']));max_res=max(max_res,err);matches.append(err<mp.mpf('2e-13'))
        test(case['reference']+' '+row['point']+' six high-precision arc distances',all(matches))
        mn=min(dd.values());winners=[k for k,v in dd.items() if abs(v-mn)<=mp.mpf('1e-12')]
        test(case['reference']+' '+row['point']+' nearest labels',winners==row['nearest_arc_labels'],winners)

# Independently solve the finite-plane intersection and triangle-coordinate tests.
point_hit_count=ray_hit_count=0
max_plane_res=mp.mpf(0)
for pinfo,submitted in zip(O['points'],G['host_patch_comparisons']):
    p=mvec(pinfo['centered']);status=[]
    for rec in submitted['patches']:
        sig=1 if rec['label'][1]=='+' else -1;k=int(rec['label'][2:]);gx,gy=e[2*k+1]
        normal=mp.matrix([gx,gy,sig*rt3/2]);j=mp.matrix([-gy,gx,0]);c=2*r0+rt3*h/2
        def inside(q):
            la=(sig*q[2]-h)/d;ze=dot(j,q);b=[1-la,la/2-ze/d,la/2+ze/d]
            return abs(dot(normal,q)-c)<=mp.mpf('1e-12') and all(-mp.mpf('1e-12')<=x<=1+mp.mpf('1e-12') for x in b)
        ph=inside(p);den=dot(normal,p);rh=den>0 and inside(p*c/den)
        point_hit_count+=ph;ray_hit_count+=rh
        status.append(ph==rec['point_membership']['point_member'] and bool(rh)==rec['outward_ray']['finite_patch_hit'])
        max_plane_res=max(max_plane_res,abs(abs(dot(normal,p)-c)/mp.sqrt(dot(normal,normal))-mp.mpf(rec['point_membership']['plane_distance'])))
    test(pinfo['label']+' independent six finite-patch point/ray classifications',all(status))
    test(pinfo['label']+' inside reference sphere, positive height',dist(p,mp.matrix([0,0,0]))<rho and p[2]>0)

# Written-identity cross-checks. These are not native trajectories.
x=sp.Matrix(sp.symbols('x0:3',real=True));y=sp.Matrix(sp.symbols('y0:3',real=True));c,s=sp.symbols('c s',real=True)
xx=c*x-s*y;yy=s*x+c*y
crossres=xx.cross(yy)-(c*c+s*s)*x.cross(y)
test('common-phase cross product identity',all(sp.expand(v)==0 for v in crossres))
test('common-phase norm identity',sp.expand(xx.dot(xx)+yy.dot(yy)-(c*c+s*s)*(x.dot(x)+y.dot(y)))==0)
A,b,E0,E1=sp.symbols('A b E0 E1',real=True)
res=(A*E0*x+b*y).cross(A*E1*x+b*y)-A*b*(E0-E1)*x.cross(y)
test('envelope cross identity',all(sp.expand(v)==0 for v in res))
px,py,pz,aa,hh=sp.symbols('px py pz a h',real=True)
p=sp.Matrix([px,py,pz]);q0=sp.Matrix([sp.sqrt(3)*aa/2,-aa/2,hh]);q1=sp.Matrix([0,aa,hh])
expr=sp.expand((p-q1).dot(p-q1)-(p-q0).dot(p-q0))
test('equal-elbow squared-distance difference',sp.simplify(expr-aa*(sp.sqrt(3)*px-3*py))==0)

# Clarification using already reported intermediate observation values, no new times.
origin=mvec(O['origin']);ref=arcs(mp.mpf(0),'PLUS');stage_rows=[]
for i,stage in enumerate(O['attribution']['intermediates']):
    p=mvec(stage['point'])-origin;dd={k:arc_details(p,v) for k,v in ref.items()};best=min(dd,key=lambda k:dd[k][0]);
    end0=ref['G+0'][1];end1=ref['G+1'][1]
    elbow0=all(dist(s[1],end0)<mp.mpf('1e-12') for s in dd['G+0'][1])
    elbow1=all(dist(s[1],end1)<mp.mpf('1e-12') for s in dd['G+1'][1])
    stage_rows.append({'stage':i,'native_state_index':stage['state_index'],'theta':stage['theta'],'time':stage['time'],'nearest_arc':best,'distance':float(dd[best][0]),'G+0_distance':float(dd['G+0'][0]),'G+1_distance':float(dd['G+1'][0]),'G+0_and_G+1_nearest_at_elbows':elbow0 and elbow1,'azimuth_degrees':float(mp.atan2(p[1],p[0])*180/mp.pi),'sqrt3_x_minus_3y':float(rt3*p[0]-3*p[1])})
test('retained intermediate nearest labels', [v['nearest_arc'] for v in stage_rows]==['G+0','G+0','G+0','G+1'],stage_rows)
# Both endpoints of the clock comparison need not minimize at both elbows.
# Record this explicitly instead of replacing finite-arc distances with a sector rule.
test('report distinctions retained; no unconditional elbow/azimuth replacement',not all(v['G+0_and_G+1_nearest_at_elbows'] for v in stage_rows[1:]))
test('scheduled nearest winner margin is not a geometry tolerance tie',stage_rows[3]['G+0_distance']-stage_rows[3]['G+1_distance']>1e-6)
summary={'scope':'Independent data/geometry and algebra checks; no native or EMA advancement, new samples, clock sweep, or project execution.', 'passed':all(t['passed'] for t in checks),'test_groups':len(checks),'checks':checks,'arcs_max_residual_width_units':mp.nstr(max_res,30),'host_plane_max_residual_width_units':mp.nstr(max_plane_res,30),'host_point_hits':int(point_hit_count),'host_ray_hits':int(ray_hit_count),'intermediate_ledger':stage_rows,'local_bisector_formula':'Where the closest points on G+0 and G+1 are their ring elbows, d1^2-d0^2 = a*(sqrt(3)*x-3*y). This is not a global sector rule for complete arcs.','numeric_qualification':'80-decimal computations at exact binary64 retained point values with exact geometry radicals; high precision is not interval certification.'}
(out/'independent_review_results.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k!='checks'},indent=2))
