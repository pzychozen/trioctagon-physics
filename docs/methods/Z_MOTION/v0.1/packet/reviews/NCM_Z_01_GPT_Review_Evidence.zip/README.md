# NCM-Z-01 GPT review evidence

Read NCM_Z_01_GPT_REVIEW.md first. This evidence accompanies a review of the supplied archive; it does not replace that archive or any Windows source.

package_audit.json binds the supplied payload and attachments. replay_execution.json records the actual unchanged-script portable invocation. replay_comparison.json lists every differing value (not a byte-identical replay claim). independent_review_checks.py and independent_review_results.json reproduce the additional static-data/geometry and symbolic checks. Original Windows paths were not inspected. No native/EMA update was performed.

The independent review script expects a review root with the original archive extracted to received/ and an evidence/ output folder. It requires already available mpmath and SymPy. It does not import project code or fetch dependencies.

The initial optional diagnostic assumption and helper correction record are retained for transparency; they do not alter any delivered calculation.
