from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,sys,platform
root=Path(__file__).resolve().parent;r=root/'received';out=root/'evidence';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
manifest=load(r/'OUTPUT_HASHES.json');checks=[]
for e in manifest['entries']:
 p=r/e['path'];ok=p.is_file() and p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
 checks.append({'path':e['path'],'passed':ok});assert ok,e['path']
expected={x['path'] for x in manifest['entries']}|{'OUTPUT_HASHES.json'}
actual={p.relative_to(r).as_posix() for p in r.rglob('*') if p.is_file()}
assert expected==actual
attached={'REPORT(20261101-054409).md':'REPORT.md','START_HERE(20261101-054400).md':'START_HERE.md','01_intensity.png':'figures/01_intensity.png','02_transverse.png':'figures/02_transverse.png','03_radial_balance.png':'figures/03_radial_balance.png'}
attachment_checks={a:sha(Path('/mnt/data')/a)==sha(r/b) for a,b in attached.items()}
assert attachment_checks["REPORT(20261101-054409).md"] and attachment_checks["START_HERE(20261101-054400).md"]
# Uploaded image previews may be resampled; reviewed archive originals control.
from PIL import Image
image_dimensions = {a:{"uploaded":list(Image.open(Path("/mnt/data")/a).size),"archive":list(Image.open(r/b).size)} for a,b in attached.items() if a.endswith(".png")}
receipt=load(Path('/mnt/data/REVIEW_RECEIPT(1).json'));archive=Path('/mnt/data/NCM_Z_03_v0.1_REVIEW.zip')
assert sha(archive)==receipt['sha256'] and archive.stat().st_size==receipt['bytes']
assert sha(r/'OUTPUT_HASHES.json')==receipt['manifest_sha256']
prior=r/'packet/NCM_Z_03_Packet_v0.1/evidence/NCM_Z_02_v0.1_REVIEW.zip'
assert sha(prior)==sha(Path('/mnt/data/NCM_Z_02_v0.1_REVIEW.zip'))
inputfile=r/'packet/NCM_Z_03_Packet_v0.1/inputs/SELECTED_HISTORY.json'
with zipfile.ZipFile(prior) as z:
 assert z.read('inputs/SELECTED_HISTORY.json')==inputfile.read_bytes()
freeze=load(r/'PLAN_FREEZE_RECEIPT.json');fchecks={p:sha(r/p)==h for p,h in freeze['sha256'].items()};assert all(fchecks.values())
portable=root/'portable';portable.mkdir(exist_ok=False)
copy_hashes=load(r/'PORTABLE_COPY_HASHES.json')
for name,digest in copy_hashes.items():
 src=inputfile if name=='SELECTED_HISTORY.json' else r/name
 assert sha(src)==digest
 shutil.copy2(src,portable/name)
shutil.copy2(r/'PORTABLE_COPY_HASHES.json',portable/'COPY_HASHES.json')
run=subprocess.run([sys.executable,'-X','utf8','-I','-B',str(portable/'portable_check.py')],cwd=portable,capture_output=True,text=True,timeout=30)
(out/'portable_stdout.txt').write_text(run.stdout,encoding='utf-8');(out/'portable_stderr.txt').write_text(run.stderr,encoding='utf-8')
assert run.returncode==0,run.stderr
pr=load(portable/'PORTABLE_RESULTS.json');assert pr['count']==80 and pr['passed']==80
shutil.copy2(portable/'PORTABLE_RESULTS.json',out/'PORTABLE_RESULTS.json')
original_checks=load(r/'CHECKS.json');assert len(original_checks['checks'])==1851 and all(c['passed'] for c in original_checks['checks'])
counts=load(r/'COUNTS.json');assert counts['primary_pair_budget_evaluations']==8
primary=[json.loads(l) for l in (r/'PRIMARY_EVALUATIONS.jsonl').read_text().splitlines()]
assert len(primary)==8 and {(x['before'],x['after'],x['dps']) for x in primary}=={(n,n+1,p) for n in range(4) for p in [80,120]}
summary={'archive_sha256':sha(archive),'archive_receipt_matches':True,'payload_verified':len(checks),'member_count':len(actual),'payload_checks':checks,'attachments_match':attachment_checks,'image_dimensions':image_dimensions,'prior_archive_matches':True,'selected_input_matches_prior':True,'plan_frozen_hashes_match':fchecks,'submitted_checks_recorded':len(original_checks['checks']),'submitted_checks_all_passed_recorded':True,'submitted_primary_budget_log_consistent':True,'portable_replay':{'checks':pr['count'],'passed':pr['passed'],'returncode':run.returncode},'gpt_primary_stage_or_kick_evaluations':0,'primary_analysis_reexecuted':False,'gpt_environment':{'python':sys.version,'platform':platform.platform()},'qualification':'Package integrity and copy-only replay; not live Windows preservation or independent native evolution certification.'}
(out/'PACKAGE_AND_REPLAY_REVIEW.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['payload_checks','plan_frozen_hashes_match']},indent=2))
for f in ['PRESERVATION_BEFORE.json','PRESERVATION_AFTER.json','SOURCES.json','PORTABLE_VERIFICATION.json']:
 d=load(r/f); print('\n',f, str(d)[:2500])
