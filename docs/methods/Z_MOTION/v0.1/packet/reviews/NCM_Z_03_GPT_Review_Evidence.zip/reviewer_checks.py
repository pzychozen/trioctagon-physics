"""Independent formula/retained-ledger review. No prestage/kick/map evaluations.
No source modules are imported and no candidate/trajectory is generated.
"""
from pathlib import Path
import json, hashlib, zipfile, sys, platform
import mpmath as mp
import sympy as sp
root=Path(__file__).resolve().parent; r=root/'received'; out=root/'evidence'
mp.mp.dps=120
checks=[]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def exact(name, exprs):
 if not isinstance(exprs,(tuple,list,sp.MatrixBase)):exprs=[exprs]
 ok=all(sp.simplify(sp.expand(x))==0 for x in exprs)
 checks.append({'name':name,'kind':'symbolic identity','passed':ok});assert ok,name
def numeric(name, diffs, terms=()):
 if not isinstance(diffs,(tuple,list)):diffs=[diffs]
 err=max([abs(x) for x in diffs]+[mp.mpf(0)])
 scale=max(mp.mpf(1),mp.fsum(abs(x) for x in terms))
 ok=err<=mp.mpf('1e-65')*scale
 checks.append({'name':name,'kind':'retained-ledger calculation','max_abs_residual':mp.nstr(err,120),'scale':mp.nstr(scale,120),'passed':bool(ok)})
 assert ok,name
def pred(name, val, detail=''):
 checks.append({'name':name,'kind':'record/predicate','detail':detail,'passed':bool(val)});assert val,name
def V(v):return [mp.mpf(x) for x in v]
def dot(a,b):return mp.fsum(x*y for x,y in zip(a,b))
# Generic mathematical identities, not numerical states or independent new laws.
a,b,lv=sp.symbols('a b lv',real=True,positive=True)
exact('finite norm gain identity',lv*b/(1+b)-lv*a/(1+a)-lv*(b*b-a*a)/((a+b)*(1+a)*(1+b)))
x=sp.Matrix(sp.symbols('x0:3',real=True)); y=sp.Matrix(sp.symbols('y0:3',real=True));
u=sp.Matrix(sp.symbols('u0:3',real=True)); v=sp.Matrix(sp.symbols('v0:3',real=True))
exact('finite real intensity expansion',(x+u).dot(x+u)+(y+v).dot(y+v)-x.dot(x)-y.dot(y)-2*x.dot(u)-2*y.dot(v)-u.dot(u)-v.dot(v))
exact('increment-square child expansion',(u+v).dot(u+v)-u.dot(u)-2*u.dot(v)-v.dot(v))
M=sp.Matrix(3,3,sp.symbols('m0:9'))
exact('cross-product cofactor identity including singular M',(M*x).cross(M*y)-M.cofactor_matrix()*x.cross(y))
D=sp.diag(*sp.symbols('d0:3'));L=sp.Matrix([[-2,1,1],[1,-2,1],[1,1,-2]]);A=x*y.T-y*x.T;ep,g=sp.symbols('eps g')
B=sp.eye(3)+ep*D+g*L
exact('five finite amplitude-area terms',B*A*B.T-A-ep*(D*A+A*D)-g*(L*A+A*L)-ep**2*D*A*D-ep*g*(D*A*L+L*A*D)-g**2*L*A*L)
ss,aa,th=sp.symbols('ss aa th',real=True)
exact('pair rotation sign',[sp.im((ss+sp.I*aa)*(sp.cos(th)+sp.I*sp.sin(th)))-aa*sp.cos(th)-ss*sp.sin(th),sp.re((ss+sp.I*aa)*(sp.cos(th)+sp.I*sp.sin(th)))-ss*sp.cos(th)+aa*sp.sin(th)])
k,h=sp.symbols('k h',real=True);H=sp.Matrix([h,0,h]);C=x;rv=k*H+C/2
exact('coarse radius decomposition',rv.dot(rv)-k*k*H.dot(H)-C.dot(C)/4-k*H.dot(C))
exact('finite radial dot identity',(x+y).dot(y-x)-(y.dot(y)-x.dot(x)))
Q=sp.eye(3)-sp.Matrix([[1,0,1],[0,0,0],[1,0,1]])/2
exact('transverse cancellation for frozen macro',Q*H)
# Verify the immutable package's bookkeeping against its retained terms, not reexecute stage analysis.
snap=load(r/'STATE_SNAPSHOTS.json')['runs']['120']
ib=load(r/'NATIVE_INTENSITY_BUDGET.json')['runs']['120']; cb=load(r/'NATIVE_CHIRAL_BUDGET.json')['runs']['120']; fb=load(r/'FROZEN_Z_SOURCE_BUDGET.json')['runs']['120']; rb=load(r/'RADIAL_TRANSVERSE_ACCOUNTING.json')['runs']['120']
summary=[]
for i in range(4):
 before,after=snap[i],snap[i+1]
 rad=rb[i]['radial_transverse']; frozen=fb[i]['frozen']; ii=ib[i]['intensity']; chir=cb[i]['chiral']
 p=V(before['centered_r']);qv=V(after['centered_r']);rs=[a+b for a,b in zip(p,qv)]
 gain=mp.mpf(frozen['q_finite_gain']);hh=V(before['H'])
 expected_gain=mp.mpf(.618)/((mp.mpf(before['kappa'])+mp.mpf(after['kappa']))*(1+mp.mpf(before['kappa']))*(1+mp.mpf(after['kappa'])))
 numeric(f'{i}->{i+1} endpoint finite gain',[gain-expected_gain,(mp.mpf(after['K'])-mp.mpf(before['K']))-gain*(mp.mpf(after['I'])-mp.mpf(before['I']))])
 diffs=[]
 for key,value in ii['parent'].items():
  diffs.extend(z-gain*mp.mpf(value)*h0 for z,h0 in zip(V(frozen['intensity_parent_vectors'][key]),hh))
 for key,value in chir['C_terms'].items():
  diffs.extend(z-c/2 for z,c in zip(V(frozen['chiral_vectors'][key]),V(value)))
 numeric(f'{i}->{i+1} source terms carried into observation',diffs)
 contributions={**{'I/'+k:V(v) for k,v in frozen['intensity_parent_vectors'].items()},**{'C/'+k:V(v) for k,v in frozen['chiral_vectors'].items()}}
 numeric(f'{i}->{i+1} each retained radial contribution',[dot(rs,v)-mp.mpf(rad['signed_radius_squared_terms'][key]) for key,v in contributions.items()])
 denominator=mp.mpf(before['radius'])+mp.mpf(after['radius'])
 numeric(f'{i}->{i+1} radius vs squared radius',[mp.mpf(rad['actual_delta_radius_squared'])/denominator-mp.mpf(rad['actual_delta_radius'])])
 numeric(f'{i}->{i+1} transverse x-z and centered y',[(qv[0]-p[0])-(qv[2]-p[2])-(mp.mpf(after['C'][0])-mp.mpf(before['C'][0])-mp.mpf(after['C'][2])+mp.mpf(before['C'][2]))/2,(qv[1]-p[1])-(mp.mpf(after['C'][1])-mp.mpf(before['C'][1]))/2])
 sum_abs=mp.fsum(abs(mp.mpf(v)) for v in rad['signed_radius_squared_terms'].values()); dr2=mp.mpf(rad['actual_delta_radius_squared'])
 numeric(f'{i}->{i+1} source-resolved cancellation ratio',sum_abs/abs(dr2)-mp.mpf(rad['radial_cancellation']['sum_abs_over_abs_net']))
 summary.append({'interval':[i,i+1],'delta_intensity':ii['actual_delta_I'],'delta_radius':rad['actual_delta_radius'],'delta_r_squared':rad['actual_delta_radius_squared'],'macro_displacement':frozen['macro_displacement'],'chiral_displacement':frozen['chiral_displacement'],'coarse_radial':rad['coarse_endpoint_difference'],'fine_radial_cancellation_ratio':rad['radial_cancellation']['sum_abs_over_abs_net']})
pred('2->3 intensity grows while radius shrinks',mp.mpf(ib[2]['intensity']['actual_delta_I'])>0 and mp.mpf(rb[2]['radial_transverse']['actual_delta_radius'])<0)
pred('3->4 outward with falling height',mp.mpf(rb[3]['radial_transverse']['actual_delta_radius'])>0 and mp.mpf(fb[3]['frozen']['actual_displacement'][2])<0)
pred('0->1 dropping finite square gives impossible negative endpoint intensity',mp.mpf(snap[0]['I'])+mp.mpf(ib[0]['intensity']['parent']['onsite'])+mp.mpf(ib[0]['intensity']['parent']['coupling'])<0)
pred('2->3 dropping finite square reverses intensity sign',mp.mpf(ib[2]['intensity']['parent']['onsite'])+mp.mpf(ib[2]['intensity']['parent']['coupling'])<0)
last=rb[3]['radial_transverse'];pred('last symmetric-pair phase opposite signs for y/radial',mp.mpf(last['y_terms']['phase_symmetric_pair'])>0 and mp.mpf(last['signed_radius_squared_terms']['C/phase_symmetric_pair'])<0)
# Preservation records, based only on packaged snapshots/external submitted copies.
baseline=load(r/'PRESERVATION_BEFORE.json');after=load(r/'PRESERVATION_AFTER.json')
lookup={e['path']:e for e in baseline};assert len(lookup)==12
pred('12 original before/after records internally consistent',len(after['entries'])==12 and all(e['path'] in lookup and lookup[e['path']]['sha256']==e['sha256']==e['after_sha256'] and lookup[e['path']]['bytes']==e['bytes']==e['after_bytes'] and e['unchanged'] for e in after['entries']))
sources=load(r/'SOURCES.json')
pred('five delivered source snapshots match declarations',all(sh(r/Path(e['snapshot'].replace('\\','/')))==e['sha256'] for e in sources))
# Compare supplied portable result to this environment's exact run (record last-bit differences honestly).
replay=load(out/'PORTABLE_RESULTS.json');submitted=load(r/'PORTABLE_VERIFICATION.json')
portable_same=replay==submitted
changes=[]
for a,b in zip(replay['checks'],submitted['checks']):
 if a!=b:changes.append({'name':a['name'],'replay':a,'submitted':b})
# Verify reported 1851 result flags and their numerical screens without reexecuting the producer.
logged=load(r/'CHECKS.json')['checks']; bad=[]
for e in logged:
 err=mp.mpf(e['max_abs_residual']);scale=mp.mpf(e['scale']);tol=mp.mpf(e['tolerance'])
 if not (e['passed'] and mp.isfinite(err) and err>=0 and scale>=1 and err<=tol*scale):bad.append(e['name'])
pred('1851 submitted scalar-screen records internally consistent',len(logged)==1851 and not bad)
result={'scope':'Generic symbolic verification and independent transformations of retained terms/endpoints. No prestages, kicks, source budgets, or full native states newly generated. No old suites or scientific producer reexecuted.','checks':checks,'count':len(checks),'passed':sum(e['passed'] for e in checks),'summary':summary,'portable_exact_parsed_json_match':portable_same,'portable_different_check_records':changes,'new_primary_budget_evaluations':0,'new_native_updates':0,'environment':{'python':sys.version,'mpmath':mp.__version__,'sympy':sp.__version__}}
(out/'REVIEWER_IDENTITY_AND_LEDGER_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':result['count'],'passed':result['passed'],'portable_same':portable_same,'portable_record_differences':len(changes),'new_primary_budget_evaluations':0},indent=2))
for s in summary:
 print('SPAN',s['interval'],'cancellation',mp.nstr(mp.mpf(s['fine_radial_cancellation_ratio']),12),'dR',mp.nstr(mp.mpf(s['delta_radius']),12))
