"""NCM-Z-02 detached observation of one frozen retained history.
No native map, producer, old checker, application import or EMA update.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import sys,json,math,hashlib
import mpmath as mp
ROOT=Path(__file__).resolve().parent
PORTABLE="--portable" in sys.argv
GTOL=1e-12; RTOL=2e-13
def sha(b):return hashlib.sha256(b).hexdigest()
def unique(items):
    d={}
    for k,v in items:
        if k in d:raise ValueError("duplicate JSON key")
        d[k]=v
    return d
def parse(b):return json.loads(b,object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def read(p):return parse((ROOT/p).read_bytes())
def write(p,v):(ROOT/p).write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")
TESTS=[]
def check(name,ok,detail=None):
    TESTS.append({"name":name,"passed":bool(ok),"detail":detail})
    if not ok:
        write("checks_results.json",{"passed":False,"tests_run":len(TESTS),"tests":TESTS})
        raise AssertionError(name+": "+str(detail))
def flatten(v):
    return [a for x in v for a in flatten(x)] if isinstance(v,(tuple,list)) else [v]
def maxdiff(a,b):return max((abs(x-y) for x,y in zip(flatten(a),flatten(b))),default=0)
def near(name,a,b):
    err=maxdiff(a,b);bound=RTOL*max(1,*map(abs,flatten(a)),*map(abs,flatten(b)))
    check(name,err<=bound,{"residual":err,"allowance":bound});return err
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def scale(v,s):return tuple(s*x for x in v)
def dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def norm(v):return math.hypot(*v)
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
plan=read("ADMISSION_AND_PLAN.json"); receipt=read("ADMISSION_FREEZE_RECEIPT.json")
check("immutable plan hash",sha((ROOT/"ADMISSION_AND_PLAN.json").read_bytes())==receipt["plan_sha256"])
check("immutable token ledger hash",sha((ROOT/"ORIGINAL_TOKEN_LEDGER.json").read_bytes())==receipt["token_ledger_sha256"])
check("immutable selected native bytes",sha((ROOT/"inputs/SELECTED_HISTORY.json").read_bytes())==receipt["selected_input_sha256"]==plan["selected"]["file_sha256"])
check("immutable candidate inventory",sha((ROOT/"CANDIDATE_INVENTORY.json").read_bytes())==receipt["candidate_inventory_sha256"])
accepted=read("ACCEPTED_SOURCES.json")["files"]
check("accepted source snapshot hashes",all(sha((ROOT/"accepted_sources"/Path(e["snapshot"]).name).read_bytes())==e["sha256"] for e in accepted.values()))
write("ANALYSIS_START.json",{"utc":datetime.now(timezone.utc).isoformat(),"frozen_plan_sha256":receipt["plan_sha256"],"native_evaluations":0,"portable":PORTABLE})
cfg=plan["observer"]; native=read("inputs/SELECTED_HISTORY.json")["observations"]
native=native[:plan["window"]["included_rows"]]
check("frozen actual indices",[x["n"] for x in native]==plan["window"]["included_indices"])
sq3=math.sqrt(3);r=sq3/6;d=1-math.sqrt(2)/2;a=d/2;h=(math.sqrt(2)-1)/2
O=(0,r,0);RHO=math.sqrt(13/12-math.sqrt(2)/2)
def clock(n):
    q=(cfg["q0"]+n*cfg["q_step"])%cfg["N"]
    return {"actual_index_for_angle":n,"actual_index_for_time":n,"q":q,"theta":2.0*math.pi*q/cfg["N"],"t":cfg["time0"]+n*cfg["dt"]}
anchor=clock(native[0]["n"])
def KH(k,cl):
    K=cfg["lambda_vp"]*(k/(1+k));E=math.exp(-cfg["gamma"]*cl["t"])
    f=math.cos(3.0*(cl["theta"]-cfg["lock_angle"]))
    return K,E,(f*math.cos(cl["theta"]),f*math.sin(cl["theta"]),f)
def state(tokens):
    z=[complex(float(x),float(y)) for x,y in tokens]
    return {"omega":z,"kappa":math.hypot(*(v for z0 in z for v in (z0.real,z0.imag))),"C":cross([v.real for v in z],[v.imag for v in z])}
def place(st,cl):
    k,E,H=KH(st["kappa"],cl);M=scale(H,k*E);Z=add(scale(M,cfg["alpha"]),scale(st["C"],cfg["beta"]))
    co,si=math.cos(cfg["psi"]),math.sin(cfg["psi"]);mu=cfg["mu_place"]
    p=(mu*(co*Z[0]-si*Z[1]),mu*(si*Z[0]+co*Z[1]),mu*Z[2])
    X=add(O,p)
    return {"kappa":st["kappa"],"C":st["C"],"K":k,"E":E,"H":H,"macro":M,"alpha_macro":scale(M,cfg["alpha"]),"beta_C":scale(st["C"],cfg["beta"]),"Z":Z,"X":X,"centered":sub(X,O),"clock":cl,"envelope_underflow_to_zero":E==0}
def spatial(p):
    rad=norm(p);hor=math.hypot(*p[:2]);margin=rad-RHO
    return {"radius":rad,"horizontal_radius":hor,"height":p[2],"azimuth_degrees":math.degrees(math.atan2(p[1],p[0])) if hor else None,"elevation_degrees":math.degrees(math.atan2(p[2],hor)) if rad else None,"direction_defined":rad!=0,"azimuth_defined":hor!=0,"direction_numerically_small":rad<=GTOL,"sphere_signed_margin":margin,"sphere_status":"on_tolerance_band" if abs(margin)<=GTOL else ("inside" if margin<0 else "outside")}
def turn(v,w):
    n1,n2=norm(v),norm(w)
    return {"angle_degrees":math.degrees(math.atan2(norm(cross(v,w)),dot(v,w))) if min(n1,n2)>GTOL else None,"first_norm":n1,"second_norm":n2,"undefined_reason":None if min(n1,n2)>GTOL else "zero or numerically unresolved displacement; components are not zeroed"}
directions=[(math.cos(-math.pi/2+i*math.pi/3),math.sin(-math.pi/2+i*math.pi/3)) for i in range(6)]
arcs=[];patches=[];faces=[]
levels={}
for sig in (1,-1):
    ring=[(a*x,a*y,sig*h) for x,y in directions];tips=[(r*directions[2*k][0],r*directions[2*k][1],sig*.5) for k in range(3)]
    levels[sig]=(ring,tips)
    for k in range(3):
        arcs.append({"label":f"G{'+' if sig==1 else '-'}{k}","level":"upper" if sig==1 else "lower","vertices":[tips[k],ring[2*k+1],tips[(k+1)%3]],"azimuth_degrees":-30+120*k if k<2 else -150})
        g=(*directions[2*k+1],0);j=(-g[1],g[0],0)
        verts=[add(add(scale(g,2*r-sq3*d*lam/2),scale(j,zeta)),(0,0,sig*(h+d*lam))) for lam,zeta in ((0,0),(1,-d/2),(1,d/2))]
        patches.append({"label":f"N{'+' if sig==1 else '-'}{k}","sigma":sig,"g":g,"j":j,"normal":add(g,(0,0,sig*sq3/2)),"constant":2*r+sq3*h/2,"vertices":verts})
top,U=levels[1];bot,L=levels[-1]
for i in range(6):faces.extend([(top[i],top[(i+1)%6],bot[(i+2)%6]),(top[i],bot[(i+2)%6],bot[(i+1)%6])])
for ring,tips in (levels[1],levels[-1]):
    for k in range(3):faces.extend([(tips[k],ring[(2*k-1)%6],ring[2*k]),(tips[k],ring[2*k],ring[(2*k+1)%6])])
def segment(p,v,w):
    delta=sub(w,v);den=dot(delta,delta);u0=dot(sub(p,v),delta)/den if den else None
    u=max(0.,min(1.,u0)) if u0 is not None else 0.;q=add(v,scale(delta,u))
    return {"distance":norm(sub(p,q)),"nearest":q,"parameter":u,"raw_parameter":u0,"degenerate":den==0,"feature":"degenerate" if den==0 else ("start" if u==0 else "end" if u==1 else "interior")}
def membership(p,patch):
    lam=(patch["sigma"]*p[2]-h)/d;zeta=dot(p,patch["j"])
    bary=[1-lam,lam/2-zeta/d,lam/2+zeta/d];plane=dot(p,patch["normal"])-patch["constant"]
    return {"plane_residual":plane,"plane_distance":abs(plane)/norm(patch["normal"]),"lambda":lam,"zeta":zeta,"barycentric":bary,"on_plane":abs(plane)<=GTOL,"in_finite_domain":all(-GTOL<=v<=1+GTOL for v in bary),"point_member":abs(plane)<=GTOL and all(-GTOL<=v<=1+GTOL for v in bary)}
def ray(p,patch):
    if norm(p)==0:return {"defined":False,"hit":False,"reason":"zero centered vector"}
    den=dot(p,patch["normal"])
    if abs(den)<=GTOL:return {"defined":True,"hit":False,"reason":"parallel or numerically unresolved carrier incidence"}
    t=patch["constant"]/den
    if t<0:return {"defined":True,"parameter":t,"hit":False,"reason":"carrier intersection behind origin"}
    q=scale(p,t);m=membership(q,patch)
    return {"defined":True,"parameter":t,"point":q,"membership":m,"hit":m["point_member"],"reason":"finite triangle hit" if m["point_member"] else "carrier hit outside finite triangle"}
def gap(p):
    rows=[]
    for arc in arcs:
        v=arc["vertices"];seg=[segment(p,v[i],v[i+1]) for i in (0,1)]
        ds=min(x["distance"] for x in seg);tie=[i for i,x in enumerate(seg) if x["distance"]-ds<=GTOL]
        spatial_points=[]
        for i in tie:
            if not any(norm(sub(seg[i]["nearest"],q))<=GTOL for q in spatial_points):spatial_points.append(seg[i]["nearest"])
        rows.append({"label":arc["label"],"level":arc["level"],"distance":ds,"segments":seg,"segment_ties":tie,"distinct_nearest_points":len(spatial_points),"on_boundary_within_tolerance":ds<=GTOL})
    ordered=sorted(rows,key=lambda x:x["distance"]);best=ordered[0]["distance"]
    winners=[x["label"] for x in rows if x["distance"]-best<=GTOL];margin=ordered[1]["distance"]-best
    return {"arcs":rows,"winner_set":winners,"unique_winner":winners[0] if len(winners)==1 else None,"best_distance":best,"second_best_distance":ordered[1]["distance"],"runner_up_labels":[x["label"] for x in rows if abs(x["distance"]-ordered[1]["distance"])<=GTOL and x["label"]!=ordered[0]["label"]],"margin":margin,"borderline":abs(margin-GTOL)<=10*GTOL or any(abs(x["distance"]-GTOL)<=10*GTOL for x in rows),"host_notches":[{"label":pa["label"],"point":membership(p,pa),"ray":ray(p,pa)} for pa in patches]}

# Independently written 80-decimal point and finite-segment geometry formulas.
# Retained strings are read directly; native state is never regenerated.
mp.mp.dps=80
def hp(tokens,cl):
    x=[mp.mpf(v[0]) for v in tokens];y=[mp.mpf(v[1]) for v in tokens]
    kap=mp.sqrt(sum(xi**2+yi**2 for xi,yi in zip(x,y)))
    C=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
    constants={k:mp.mpf(v) for k,v in cfg.items()}
    angle=2*mp.pi*cl["q"]/cfg["N"];time=constants["time0"]+cl["actual_index_for_time"]*constants["dt"]
    env=mp.exp(-constants["gamma"]*time)
    scalar=constants["lambda_vp"]*kap/(1+kap)*env*mp.cos(3*(angle-constants["lock_angle"]))
    M=[scalar*mp.cos(angle),scalar*mp.sin(angle),scalar]
    Z=[constants["alpha"]*M[i]+constants["beta"]*C[i] for i in range(3)]
    co,si=mp.cos(constants["psi"]),mp.sin(constants["psi"]);mu=constants["mu_place"]
    p=[mu*(co*Z[0]-si*Z[1]),mu*(si*Z[0]+co*Z[1]),mu*Z[2]]
    rr=mp.sqrt(3)/6;dd=1-mp.sqrt(2)/2;aa=dd/2;hh=(mp.sqrt(2)-1)/2
    ds=[];details=[];patchtests=[]
    for sign in (1,-1):
        for k in range(3):
            va=-mp.pi/2+2*k*mp.pi/3; vb=va+mp.pi/3;vc=va+2*mp.pi/3
            vertices=[[rr*mp.cos(va),rr*mp.sin(va),mp.mpf(sign)/2],[aa*mp.cos(vb),aa*mp.sin(vb),sign*hh],[rr*mp.cos(vc),rr*mp.sin(vc),mp.mpf(sign)/2]]
            segs=[]
            for u,v in zip(vertices,vertices[1:]):
                vmu=[vi-ui for ui,vi in zip(u,v)];pmu=[pi-ui for pi,ui in zip(p,u)]
                par=sum(xi*yi for xi,yi in zip(pmu,vmu))/sum(vi*vi for vi in vmu)
                par=max(mp.mpf(0),min(mp.mpf(1),par))
                nearest=[ui+par*vi for ui,vi in zip(u,vmu)]
                dist=mp.sqrt(sum((pi-qi)**2 for pi,qi in zip(p,nearest)))
                segs.append({"distance":dist,"parameter":par,"nearest":nearest})
            ds.append(min(s["distance"] for s in segs));details.append(segs)
            gv=[mp.cos(vb),mp.sin(vb)];jv=[-gv[1],gv[0]];const=2*rr+mp.sqrt(3)*hh/2
            def mem(q):
                lam=(sign*q[2]-hh)/dd;zet=q[0]*jv[0]+q[1]*jv[1]
                plane=q[0]*gv[0]+q[1]*gv[1]+sign*mp.sqrt(3)*q[2]/2-const
                bary=[1-lam,lam/2-zet/dd,lam/2+zet/dd]
                return abs(plane)<=mp.mpf(str(GTOL)) and all(-mp.mpf(str(GTOL))<=b<=1+mp.mpf(str(GTOL)) for b in bary)
            denom=p[0]*gv[0]+p[1]*gv[1]+sign*mp.sqrt(3)*p[2]/2
            hit=False
            if abs(denom)>mp.mpf(str(GTOL)):
                tt=const/denom
                if tt>=0:hit=mem([tt*v for v in p])
            patchtests.append({"point_member":mem(p),"ray_hit":hit})
    mind=min(ds);winner=[arcs[i]["label"] for i,v in enumerate(ds) if v-mind<=mp.mpf(str(GTOL))]
    def strings(v):
        if isinstance(v,dict):return {k:strings(x) for k,x in v.items()}
        if isinstance(v,list):return [strings(x) for x in v]
        return mp.nstr(v,80)
    return {"kappa":kap,"C":C,"macro":M,"Z":Z,"centered":p,"E":env,"distances":ds,"segment_details":details,"winner_set":winner,"margin":sorted(ds)[1]-sorted(ds)[0],"patch_flags":patchtests,"decimal":{"kappa":strings(kap),"C":strings(C),"macro":strings(M),"Z":strings(Z),"centered":strings(p),"envelope":strings(env),"all_six_distances":strings(ds),"segment_details":strings(details),"margin":strings(sorted(ds)[1]-sorted(ds)[0])}}

# One old fixture regression, excluded from history counts and figures.
fixture=read("packet/inputs/NCM_Z_01_RETAINED.motion.json")
canon=lambda v:json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
for tag,v in (("outer",fixture),("observation",fixture["observation"]),("probe",fixture["phase_probe"])):
    check("regression "+tag+" seal",sha(canon({k:x for k,x in v.items() if k!="content_sha256"}))==v["content_sha256"])
reg=[]
for sample in fixture["observation"]["samples"]:
    st=state(sample["omega"]);entry={"native_index":sample["update_index"]}
    entry["kappa"]=near("regression norm",st["kappa"],sample["kappa"]);entry["C"]=near("regression chirality",st["C"],sample["C"])
    for mode,cl in (("scheduled",clock(sample["update_index"])),("frozen",clock(0))):
        p=place(st,cl)
        entry[mode]={k:near("regression "+mode+" "+k,p[k],sample[mode][{"X":"point","macro":"macro","Z":"Z"}[k]]) for k in ("macro","Z","X")}
    reg.append(entry)
near("same accepted central mesh",[[add(O,p) for p in tri] for tri in faces],fixture["observation"]["geometry"]["central_triangles"])

states=[state(v["omega"]) for v in native];evaluations={};HP=[]
def evaluate(key,ordinal,cl,kind):
    p=place(states[ordinal],cl);gg=gap(p["centered"]);hhp=hp(native[ordinal]["omega"],cl)
    errors={k:near(key+" hp "+k,p[k],[float(v) for v in hhp[k]] if isinstance(hhp[k],list) else float(hhp[k])) for k in ("kappa","C","macro","Z","centered")}
    errors["arc_distances"]=near(key+" hp distances",[v["distance"] for v in gg["arcs"]],[float(v) for v in hhp["distances"]])
    agrees=gg["winner_set"]==hhp["winner_set"]
    flags=[{"point_member":n["point"]["point_member"],"ray_hit":n["ray"]["hit"]} for n in gg["host_notches"]]
    check(key+" patch classification precision agreement",flags==hhp["patch_flags"])
    gg["precision_classification_agrees"]=agrees
    gg["resolved_unique"]=bool(gg["unique_winner"] and agrees)
    gg["decision_status"]="resolved_unique" if gg["resolved_unique"] else ("tie_set" if agrees else "unresolved_precision_disagreement")
    evaluations[key]={"id":key,"kind":kind,"sample_ordinal":ordinal,"native_update_index":native[ordinal]["n"],"readout":p,"spatial":spatial(p["centered"]),"gap":gg}
    HP.append({"id":key,"native_update_index":native[ordinal]["n"],"input":"original retained decimal strings; no state update","precision_dps":80,"results":hhp["decimal"],"winner_set":hhp["winner_set"],"agrees_with_binary64_winner_set":agrees,"patch_flags":hhp["patch_flags"],"binary64_abs_residuals":errors})
    return evaluations[key]
for i,v in enumerate(native):
    evaluate("S"+str(v["n"]),i,clock(v["n"]),"scheduled")
    evaluate("F"+str(v["n"]),i,anchor,"frozen")
near("initial scheduled/frozen coincidence",evaluations["S"+str(native[0]["n"])]["readout"]["X"],evaluations["F"+str(native[0]["n"])]["readout"]["X"])
historical=[]
for i,v in enumerate(native):
    p=evaluations["S"+str(v["n"])]["readout"]
    historical.append({"native_index":v["n"],"numeric_semantics":"historical exact-decimal ideal readout versus binary64-coefficient overlay; rounding differences expected","kappa_residual":near("retained historical norm",p["kappa"],float(v["norm"])),"C_residual":near("retained historical C",p["C"],[float(x) for x in v["chiral"]]),"Z_residual":near("retained historical Z",p["Z"],[float(x) for x in v["Z"]])})
attributes=[]
for i in range(len(native)-1):
    n0,n1=native[i]["n"],native[i+1]["n"];old=states[i];new=states[i+1];c0=clock(n0);c1=clock(n1)
    k0,e0,H0=KH(old["kappa"],c0);k1,e1,H1=KH(new["kappa"],c1)
    # mu=1, psi=0 is frozen in this plan.
    check("fixed identity placement",cfg["mu_place"]==1 and cfg["psi"]==0)
    normterm=scale(H0,cfg["alpha"]*e0*(k1-k0));chirterm=scale(sub(new["C"],old["C"]),cfg["beta"])
    nat=add(normterm,chirterm);env=scale(H0,cfg["alpha"]*k1*(e1-e0));clk=scale(sub(H1,H0),cfg["alpha"]*k1*e1)
    I1=evaluate(f"I{n0}_{n1}_native",i+1,c0,"native replacement")
    middle={**c0,"actual_index_for_time":n1,"t":c1["t"]}
    I2=evaluate(f"I{n0}_{n1}_envelope",i+1,middle,"envelope replacement")
    keys=[f"S{n0}",I1["id"],I2["id"],f"S{n1}"]
    total=sub(evaluations[keys[-1]]["readout"]["X"],evaluations[keys[0]]["readout"]["X"])
    residual=sub(total,add(nat,add(env,clk)))
    near("telescope "+str(n0)+" residual",residual,(0,0,0))
    for j,term in enumerate((nat,env,clk)):near("telescope intermediate "+str(n0)+":"+str(j),sub(evaluations[keys[j+1]]["readout"]["X"],evaluations[keys[j]]["readout"]["X"]),term)
    global_delta=sub(evaluations[f"F{n1}"]["readout"]["X"],evaluations[f"F{n0}"]["readout"]["X"])
    attributes.append({"from_index":n0,"to_index":n1,"update_span":n1-n0,"order":["native","envelope","clock"],"native":nat,"native_subterms":{"norm_macro":normterm,"chiral":chirterm},"envelope":env,"clock":clk,"total":total,"residual":residual,"global_frozen_delta":global_delta,"local_native_minus_global_frozen":sub(nat,global_delta),"intermediate_evaluation_ids":keys,"component_norms_not_additive":{k:norm(v) for k,v in (("native",nat),("envelope",env),("clock",clk),("total",total))}})
def label(e):return e["gap"]["unique_winner"] if e["gap"]["resolved_unique"] else None
def transition(a,b):
    A,B=label(a),label(b);status="unresolved_or_tied" if A is None or B is None else ("switch" if A!=B else "same")
    ds0={x["label"]:x["distance"] for x in a["gap"]["arcs"]};ds1={x["label"]:x["distance"] for x in b["gap"]["arcs"]}
    winners=set(a["gap"]["winner_set"]+b["gap"]["winner_set"])
    return {"from_labels":a["gap"]["winner_set"],"to_labels":b["gap"]["winner_set"],"status":status,"from_decision":a["gap"]["decision_status"],"to_decision":b["gap"]["decision_status"],"center_radius_change":b["spatial"]["radius"]-a["spatial"]["radius"],"nearest_boundary_distance_change":b["gap"]["best_distance"]-a["gap"]["best_distance"],"old_and_new_winning_boundary_distances":[{"label":x,"before":ds0[x],"after":ds1[x],"change":ds1[x]-ds0[x]} for x in sorted(winners)],"segment_ties_before":{x["label"]:x["segment_ties"] for x in a["gap"]["arcs"] if len(x["segment_ties"])>1},"segment_ties_after":{x["label"]:x["segment_ties"] for x in b["gap"]["arcs"] if len(x["segment_ties"])>1}}
transitions=[];deltas={"S":[],"F":[]}
for i in range(len(native)-1):
    n0,n1=native[i]["n"],native[i+1]["n"]
    ss=transition(evaluations[f"S{n0}"],evaluations[f"S{n1}"]);ff=transition(evaluations[f"F{n0}"],evaluations[f"F{n1}"])
    sws,swf=ss["status"]=="switch",ff["status"]=="switch"
    cat="unresolved/tied" if "unresolved_or_tied" in (ss["status"],ff["status"]) else ("both_same_ordered_labels" if sws and swf and (ss["from_labels"],ss["to_labels"])==(ff["from_labels"],ff["to_labels"]) else "both_different_ordered_labels" if sws and swf else "scheduled_only" if sws else "frozen_only" if swf else "neither")
    entry={"from_index":n0,"to_index":n1,"update_span":n1-n0,"category":cat,"scheduled":ss,"frozen":ff,"displacements":{},"turn_at_middle_stored_index":{}}
    for mode in ("S","F"):
        delta=sub(evaluations[f"{mode}{n1}"]["readout"]["X"],evaluations[f"{mode}{n0}"]["readout"]["X"])
        entry["displacements"][mode]={"vector":delta,"norm":norm(delta),"direction_defined_exact":norm(delta)!=0,"direction_numerically_resolved":norm(delta)>GTOL}
        if deltas[mode]:
            entry["turn_at_middle_stored_index"][mode]={"middle_index":n0,"incoming_span":native[i]["n"]-native[i-1]["n"],"outgoing_span":n1-n0,**turn(deltas[mode][-1],delta)}
        else:entry["turn_at_middle_stored_index"][mode]=None
        deltas[mode].append(delta)
    transitions.append(entry)
    ids=attributes[i]["intermediate_evaluation_ids"]
    attributes[i]["label_replacements"]=[{"stage":stage,**transition(evaluations[ids[j]],evaluations[ids[j+1]])} for j,stage in enumerate(("native","envelope","clock"))]
sameindex=[];robustness=[]
for v in native:
    n=v["n"];S,F=evaluations[f"S{n}"],evaluations[f"F{n}"];sl,fl=label(S),label(F)
    sameindex.append({"index":n,"scheduled_labels":S["gap"]["winner_set"],"frozen_labels":F["gap"]["winner_set"],"resolved_disagreement":sl is not None and fl is not None and sl!=fl,"unresolved_or_tied":sl is None or fl is None})
    b=norm(sub(S["readout"]["X"],F["readout"]["X"]));margin=F["gap"]["margin"];slack=margin-2*b
    sufficient=F["gap"]["resolved_unique"] and slack-4*GTOL>0
    robustness.append({"index":n,"frozen_labels":F["gap"]["winner_set"],"scheduled_labels":S["gap"]["winner_set"],"margin":margin,"b":b,"raw_slack":slack,"heuristic_allowance":4*GTOL,"allowance_adjusted_slack":slack-4*GTOL,"numerically_sufficient":sufficient,"actual_same_unique_winner":sl is not None and sl==fl,"status":"numerical sufficient-margin diagnostic, not interval certificate" if sufficient else "inconclusive; no prediction"})
    check("robustness sufficient diagnostic agrees with labels "+str(n),not sufficient or sl==fl)

# Small source/readout/geometry tests, none counted as retained history.
check("six distinct arcs and finite notches",len(arcs)==6 and len(patches)==6 and len({x["label"] for x in arcs})==6)
for bad in ('{"x":1,"x":2}','{"x":NaN}'):
    try:parse(bad);fail=False
    except ValueError:fail=True
    check("strict JSON "+bad,fail)
check("sparse indices schedule",clock(5)["q"]==5 and clock(17)["q"]==5 and clock(17)["t"]==1.7000000000000002)
near("first interval local/global native freeze",attributes[0]["native"],attributes[0]["global_frozen_delta"])
check("later local/global freeze not conflated",any(norm(v["local_native_minus_global_frozen"])>GTOL for v in attributes[1:]))
late=place(states[0],clock(5));late_again=place(states[0],clock(5))
near("late first stored index anchors without rebase",late["X"],late_again["X"])
check("late anchor differs from zero anchor",norm(sub(late["X"],place(states[0],clock(0))["X"]))>GTOL)
for i,st in enumerate(states):
    factor=complex(math.cos(.731),math.sin(.731));zz=[z*factor for z in st["omega"]]
    transformed=state([(z.real,z.imag) for z in zz])
    near("common-phase frozen invariance "+str(i),place(transformed,anchor)["X"],place(st,anchor)["X"])
for arc in arcs:
    vv=arc["vertices"];q=vv[1]
    near("shared elbow "+arc["label"],[segment(q,vv[0],vv[1])["distance"],segment(q,vv[1],vv[2])["distance"]],[0,0])
    # Common orthogonal camera transform, all coordinates transformed together.
    J=lambda v:(-v[0],v[2],-v[1]);p=evaluations["S0"]["readout"]["centered"]
    near("opposite-camera metric "+arc["label"],[segment(J(p),J(vv[j]),J(vv[j+1]))["distance"] for j in (0,1)],[segment(p,vv[j],vv[j+1])["distance"] for j in (0,1)])
check("finite segment endpoint clamp",segment((2,0,0),(0,0,0),(1,0,0))["parameter"]==1)
check("degenerate segment",segment((1,0,0),(0,0,0),(0,0,0))["degenerate"])
check("gap tie kept as set",len(gap((0,0,0))["winner_set"])==6)
check("zero position directions undefined",spatial((0,0,0))["azimuth_degrees"] is None and spatial((0,0,0))["elevation_degrees"] is None)
check("axis azimuth undefined",spatial((0,0,1))["azimuth_degrees"] is None and spatial((0,0,1))["elevation_degrees"]==90)
check("zero displacement turn undefined",turn((0,0,0),(1,0,0))["angle_degrees"] is None)
check("small nonzero displacement unresolved not zeroed",turn((1e-14,0,0),(1,0,0))["angle_degrees"] is None and turn((1e-14,0,0),(1,0,0))["first_norm"]>0)
check("right angle displacement",turn((1,0,0),(0,1,0))["angle_degrees"]==90)
for patch in patches:
    center=scale(tuple(sum(v[j] for v in patch["vertices"]) for j in range(3)),1/3)
    check("positive finite patch ray "+patch["label"],ray(center,patch)["hit"])
    q=add(patch["vertices"][0],scale(patch["j"],2))
    check("plane outside finite triangle "+patch["label"],membership(q,patch)["on_plane"] and not membership(q,patch)["point_member"])
check("zero ray undefined",not ray((0,0,0),patches[0])["defined"])
# Nonempty singleton sets give transparent positive/negative/inconclusive examples.
def bound_example(x,y):
    dist=lambda p:[norm(sub(p,z)) for z in ((0,0,0),(10,0,0))]
    dx,dy=dist(x),dist(y);a0=min(range(2),key=dx.__getitem__)
    m=abs(dx[1]-dx[0]);b=norm(sub(x,y))
    return m>2*b,min(range(2),key=dy.__getitem__)==a0
check("positive margin bound example",bound_example((1,0,0),(1.1,0,0))==(True,True))
check("failed bound may switch",bound_example((1,0,0),(9,0,0))==(False,False))
check("failed bound may retain winner",bound_example((1,0,0),(-9,0,0))==(False,True))
check("all required high precision points",len(HP)==2*len(native)+2*(len(native)-1))
check("no unplanned samples or settings",len(evaluations)==plan["evaluation_limits"]["primary_points"]+plan["evaluation_limits"]["telescope_intermediate_points"])
check("all numbers finite",all(math.isfinite(v) for e in evaluations.values() for v in flatten(e["readout"]["X"])))
summary={"states":len(native),"indices":[v["n"] for v in native],"spans":len(transitions),"total_native_index_span":native[-1]["n"]-native[0]["n"],"frozen_switches":sum(v["frozen"]["status"]=="switch" for v in transitions),"scheduled_switches":sum(v["scheduled"]["status"]=="switch" for v in transitions),"transition_categories":dict(Counter(v["category"] for v in transitions)),"same_index_disagreements":[v["index"] for v in sameindex if v["resolved_disagreement"]],"primary_tie_or_unresolved_evaluations":[k for k,v in evaluations.items() if v["kind"] in ("scheduled","frozen") and not v["gap"]["resolved_unique"]],"high_precision_evaluations":len(HP),"high_precision_classification_disagreements":sum(not x["agrees_with_binary64_winner_set"] for x in HP),"numerically_sufficient_margin_indices":[x["index"] for x in robustness if x["numerically_sufficient"]],"native_evaluations":0,"ema_advances":0}
write("OBSERVATIONS.json",{"scope":plan["selected"],"anchor":anchor,"config":cfg,"token_ledger":"ORIGINAL_TOKEN_LEDGER.json","samples":[{"ordinal":i,"index":v["n"],"scheduled":{k:x for k,x in evaluations[f"S{v['n']}"].items() if k!="gap"},"frozen":{k:x for k,x in evaluations[f"F{v['n']}"].items() if k!="gap"}} for i,v in enumerate(native)],"historical_readout_comparison":historical,"prior_two_state_regression":reg,"summary":summary})
write("GAP_COMPARISON.json",{"fixed_geometry":{"origin":O,"sphere_radius":RHO,"arcs":arcs,"finite_notch_patches":patches,"central_faces":faces},"evaluations":evaluations,"robustness":robustness,"ties_use_absolute_width_tolerance":GTOL,"empty_aperture_interior_definition":True})
write("TRANSITIONS.json",{"summary":summary,"intervals":transitions,"same_index_comparisons":sameindex,"meaning":"Stored endpoints only. No inferred event times, paths or flux."})
write("ATTRIBUTION.json",{"intervals":attributes,"meaning":"Ordered native -> envelope -> clock. Local native term uses previous scheduled settings; global frozen differences use first-sample anchor. Component norms are not additive."})
write("HIGH_PRECISION.json",{"dps":80,"state_input":"Original retained decimal strings","coefficients":"Exact binary64 preset coefficients lifted to mp; exact pi and radical geometry","interval_certificate":False,"evaluations":HP})
protected=read("PROTECTED.before.json");pres=[]
for e in protected:
    p=ROOT/e["copy"] if PORTABLE else Path(e["path"])
    got=sha(p.read_bytes());pres.append({**e,"checked_path":str(p),"after_sha256":got,"unchanged":got==e["sha256"]})
check("packaged evidence identities" if PORTABLE else "bounded original preservation",all(e["unchanged"] for e in pres))
write("PORTABLE_PRESERVATION.json" if PORTABLE else "PRESERVATION.json",{"portable":PORTABLE,"scope":"Packaged copies only" if PORTABLE else "Only listed read sources/inputs; not whole checkout","files":pres})
write("checks_results.json",{"passed":True,"tests_run":len(TESTS),"tests":TESTS,"portable":PORTABLE,"native_evaluations":0,"ema_advances":0,"environment":{"python":sys.version,"executable":sys.executable,"mpmath":mp.__version__}})
print(json.dumps({"summary":summary,"tests_passed":len(TESTS),"point_overview":[{"id":k,"centered":v["readout"]["centered"],"radius":v["spatial"]["radius"],"labels":v["gap"]["winner_set"],"margin":v["gap"]["margin"],"nearest_distance":v["gap"]["best_distance"]} for k,v in evaluations.items()],"robustness":robustness},indent=2))
