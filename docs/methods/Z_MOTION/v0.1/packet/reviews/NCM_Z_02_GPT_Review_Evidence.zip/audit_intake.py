from pathlib import Path
import json,hashlib,zipfile,shutil,sys
ROOT=Path(__file__).resolve().parent
R=ROOT/'received'; E=ROOT/'evidence';E.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'OUTPUT_HASHES.json').read_text()); entries=m['entries']
checks=[{'path':e['path'],'bytes_match':(R/e['path']).stat().st_size==e['bytes'],'sha256_match':h(R/e['path'])==e['sha256']} for e in entries]
assert all(x['bytes_match'] and x['sha256_match'] for x in checks)
allfiles={str(p.relative_to(R)).replace('\\','/') for p in R.rglob('*') if p.is_file()}
print('Manifest',len(entries),'/',len(allfiles),'unlisted',sorted(allfiles-{e['path'] for e in entries}))
comparisons=[]
for a,b in [('REPORT.md','REPORT(20261101-025034).md'),('START_HERE.md','START_HERE(20261101-025025).md'),('packet/inputs/NCM_Z_01_RETAINED.motion.json','interactive.motion.json'),('inputs/NCM_Z_02_Codex_Packet_v0.1.zip','NCM_Z_02_Codex_Packet_v0.1.zip'),('packet/evidence/NCM_Z_01_v0.1_REVIEW.zip','NCM_Z_01_v0.1_REVIEW.zip'),('figures/01_top.png','01_top(1).png'),('figures/02_opposite_sides.png','02_opposite_sides.png'),('figures/03_index_diagnostics.png','03_index_diagnostics.png')]:
 p=Path('/mnt/data')/b
 comparisons.append({'received':a,'attachment':b,'byte_equal':(R/a).read_bytes()==p.read_bytes(),'received_sha256':h(R/a),'attachment_sha256':h(p)})
print('Attachments',[(x['attachment'],x['byte_equal']) for x in comparisons])
rc=json.loads(Path('/mnt/data/REVIEW_RECEIPT.json').read_text())
assert rc['sha256']==h(Path('/mnt/data/NCM_Z_02_v0.1_REVIEW.zip'))
plan=json.loads((R/'ADMISSION_AND_PLAN.json').read_text());fr=json.loads((R/'ADMISSION_FREEZE_RECEIPT.json').read_text())
assert h(R/'ADMISSION_AND_PLAN.json')==fr['plan_sha256']==rc['plan_hash_unchanged']
print('Plan window',plan['window'],'selected',plan['selected'])
print('Freeze',fr)
print('Analysis start', (R/'ANALYSIS_START.json').read_text())
# Check archival nominal input directly against its retained archive, without running producers.
z=zipfile.ZipFile(R/'sources/005_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1_REVIEW_BUNDLE.zip')
for name in z.namelist():
 if name.endswith('NOMINAL_CROSSCHECK.json'):
  assert z.read(name)==(R/'inputs/SELECTED_HISTORY.json').read_bytes()
  print('Selected bytes identical in historical archive',name)
preserve=json.loads((R/'PROTECTED.before.json').read_text())
assert len(preserve)==10
assert all(h(R/e['copy'])==e['sha256'] for e in preserve)
print('All 10 packaged protected snapshots match baseline')
result={'archive_sha256':rc['sha256'],'manifest_entries':len(entries),'archive_entries':99,'payload_checks':checks,'attachments':comparisons,'plan_hash':fr['plan_sha256'],'historical_nominal_input_identical':True,'ten_packaged_protected_snapshots_match':True,'live_windows_sources_checked':False,'python':sys.version}
(E/'intake.json').write_text(json.dumps(result,indent=2)+'\n')
if not (ROOT/'replay').exists():shutil.copytree(R,ROOT/'replay')
