"""Independent detached review. Reads stored states; never evaluates a native map."""
from pathlib import Path
import json, math, hashlib
import numpy as np
import mpmath as mp
import sympy as sy
ROOT=Path(__file__).resolve().parent; R=ROOT/'received'; E=ROOT/'evidence'
mp.mp.dps=80
j=lambda p:json.loads((R/p).read_text())
plan=j('ADMISSION_AND_PLAN.json'); cfg=plan['observer']; hist=j('inputs/SELECTED_HISTORY.json')['observations']
evals=j('GAP_COMPARISON.json')['evaluations']; originals=j('GAP_COMPARISON.json')['fixed_geometry']
rows={v['n']:v for v in hist}; tol=1e-12; checks=[]
def check(name,ok):
 checks.append({'name':name,'passed':bool(ok)})
 if not ok:raise AssertionError(name)
# Independent scalar high-precision formula evaluated on the original saved tokens.
def rp(n,q,nt):
 z=[mp.mpc(*v) for v in rows[n]['omega']]
 k=mp.sqrt(sum(abs(x)**2 for x in z))
 C=[mp.im(mp.conj(z[1])*z[2]),mp.im(mp.conj(z[2])*z[0]),mp.im(mp.conj(z[0])*z[1])]
 th=2*mp.pi*q/cfg['N']; t=mp.mpf(cfg['time0'])+nt*mp.mpf(cfg['dt'])
 gain=mp.mpf(cfg['lambda_vp'])*k/(1+k)*mp.exp(-mp.mpf(cfg['gamma'])*t)*mp.cos(3*(th-mp.mpf(cfg['lock_angle'])))
 p=[gain*mp.cos(th)+mp.mpf(cfg['beta'])*C[0],gain*mp.sin(th)+mp.mpf(cfg['beta'])*C[1],gain+mp.mpf(cfg['beta'])*C[2]]
 return np.array([float(x) for x in p]),C
# Geometry reconstructed independently in canonical centered coordinates.
sq2=math.sqrt(2);r=math.sqrt(3)/6;d=1-sq2/2;a=d/2;h=(sq2-1)/2
unit=lambda theta:np.array([math.cos(theta),math.sin(theta)])
arcs={};patches={}
for sig in (1,-1):
 for k in range(3):
  t0=-math.pi/2+2*k*math.pi/3
  verts=[np.r_[r*unit(t0),sig*.5],np.r_[a*unit(t0+math.pi/3),sig*h],np.r_[r*unit(t0+2*math.pi/3),sig*.5]]
  arcs[f"G{'+' if sig>0 else '-'}{k}"]=verts
  g=unit(t0+math.pi/3);tangent=np.array([-g[1],g[0]])
  vertsN=[np.r_[2*r*g,sig*h]]+[np.r_[(2*r-math.sqrt(3)*d/2)*g+sgn*d/2*tangent,sig*(h+d)] for sgn in (-1,1)]
  patches[f"N{'+' if sig>0 else '-'}{k}"]=vertsN
# Compare endpoint and interior critical point, no copied segment-clamping implementation.
def segdist(p,u,v):
 w=v-u; den=float(w@w); candidates=[np.linalg.norm(p-u),np.linalg.norm(p-v)]
 if den:
  t=float((p-u)@w/den)
  if 0<t<1:candidates.append(np.linalg.norm(p-u-t*w))
 return min(candidates)
def arcdist(p,vs):return min(segdist(p,vs[0],vs[1]),segdist(p,vs[1],vs[2]))
def patch(p,vs):
 u,v,w=vs;basis=np.column_stack((v-u,w-u));normal=np.cross(v-u,w-u)
 signed=float(normal@(p-u));bc=np.linalg.lstsq(basis,p-u,rcond=None)[0];bary=np.r_[1-sum(bc),bc]
 member=abs(signed)/np.linalg.norm(normal)<=tol and min(bary)>=-tol and max(bary)<=1+tol
 denom=float(normal@p)
 if abs(denom)<1e-14:return bool(member),False,None
 t=float(normal@u/denom)
 if t<0:return bool(member),False,t
 pt=t*p;bc2=np.linalg.lstsq(basis,pt-u,rcond=None)[0];bary2=np.r_[1-sum(bc2),bc2]
 hit=min(bary2)>=-tol and max(bary2)<=1+tol
 return bool(member),bool(hit),t
errs=[];allclasses=[];mirror=[];frozen=[];sched=[]
for name,v in evals.items():
 cl=v['readout']['clock'];p,C=rp(v['native_update_index'],cl['q'],cl['actual_index_for_time'])
 p0=np.array(v['readout']['centered']);ds={lab:arcdist(p,vs) for lab,vs in arcs.items()}
 stored={u['label']:u['distance'] for u in v['gap']['arcs']}
 best=min(ds.values());winners=[lab for lab,x in ds.items() if x-best<=tol]
 flags={lab:patch(p,vs)[:2] for lab,vs in patches.items()}
 stflags={u['label']:(u['point']['point_member'],u['ray']['hit']) for u in v['gap']['host_notches']}
 er={'id':name,'coordinate_error':float(max(abs(p-p0))),'arc_distance_error':max(abs(ds[k]-stored[k]) for k in ds),'labels_agree':winners==v['gap']['winner_set'],'patch_flags_agree':flags==stflags}
 errs.append(er);allclasses.append(er['labels_agree'] and er['patch_flags_agree'])
 for k in range(3):
  if p[2]>=0:slack=ds[f'G-{k}']**2-ds[f'G+{k}']**2-4*h*p[2]
  else:slack=ds[f'G+{k}']**2-ds[f'G-{k}']**2-4*h*(-p[2])
  mirror.append({'id':name,'k':k,'slack':slack})
 if name[0] in ('F','S'):
  data={'index':v['native_update_index'],'height':float(p[2]),'nearest':winners,'macro_vertical':v['readout']['macro'][2],'chiral_vertical':v['readout']['beta_C'][2], 'H_vertical':v['readout']['H'][2]}
  (frozen if name[0]=='F' else sched).append(data)
check('all 18 retained/intermediate readouts checked',len(errs)==18)
check('independent positions agree',max(e['coordinate_error'] for e in errs)<1e-14)
check('independent finite-arc distances agree',max(e['arc_distance_error'] for e in errs)<1e-14)
check('independent nearest sets and finite-patch flags agree',all(allclasses))
# Exact mirror identity: no sampling is used for the proof.
x,y,z,u,v,t=sy.symbols('x y z u v t', real=True)
Dminus=(x-u)**2+(y-v)**2+(z+t)**2
Dplus=(x-u)**2+(y-v)**2+(z-t)**2
check('exact reflected-point squared-distance difference',sy.expand(Dminus-Dplus-4*z*t)==0)
check('paired-arc inequality on all 54 retained comparisons',min(q['slack'] for q in mirror)>-1e-14)
check('global winner hemisphere follows height for all 18 evaluations',all(all(lab[1]==('+' if q['readout']['centered'][2]>0 else '-') for lab in q['gap']['winner_set']) for q in evals.values()))
# Exact scheduled harmonic sequence (the positive envelope does not change its sign).
L=sy.symbols('ell',real=True)
factors=[sy.expand_trig(sy.cos(n*sy.pi/2-3*L)) for n in range(5)]
expected=[sy.cos(3*L),sy.sin(3*L),-sy.cos(3*L),-sy.sin(3*L),sy.cos(3*L)]
check('exact five-index harmonic factors',all(sy.simplify(s-t)==0 for s,t in zip(factors,expected)))
check('recorded harmonic signs',[(q['H_vertical']>0) for q in sched]==[True,True,False,False,True])
check('negative macro outweighs chiral vertical at indices 2 and 3',all(sched[n]['macro_vertical']<0 and 0<sched[n]['chiral_vertical']<-sched[n]['macro_vertical'] for n in (2,3)))
# Frozen observer: only the chiral change contributes transverse to the fixed macro ray.
dK,c=sy.symbols('dK c',real=True);c1,c2,c3=sy.symbols('dc1 dc2 dc3',real=True)
unitv=sy.Matrix([1,0,1])/sy.sqrt(2);P=sy.eye(3)-unitv*unitv.T
D=sy.Matrix([dK*c+c1/2,c2/2,dK*c+c3/2])
check('exact transverse frozen increment identity',sy.simplify(P*D-P*sy.Matrix([c1,c2,c3])/2)==sy.zeros(3,1))
check('exact frozen y-coordinate relation',sy.simplify(D[1]-c2/2)==0)
obs=j('OBSERVATIONS.json')['samples'];max_transverse=0.;deltas=[]
Pr=np.eye(3)-np.outer(np.array([1,0,1])/math.sqrt(2),np.array([1,0,1])/math.sqrt(2))
for i in range(4):
 f0=obs[i]['frozen']['readout'];f1=obs[i+1]['frozen']['readout']
 dz=np.array(f1['centered'])-np.array(f0['centered']);dc=np.array(f1['C'])-np.array(f0['C'])
 err=float(max(abs(Pr@dz-.5*Pr@dc)));max_transverse=max(max_transverse,err)
 deltas.append({'from':i,'to':i+1,'transverse_increment':(Pr@dz).tolist(),'transverse_from_chiral':(.5*Pr@dc).tolist(),'residual':err})
check('retained transverse decomposition',max_transverse<1e-14)
# Same-state scheduled-minus-frozen difference cancels the entire chiral term.
sep=[]
for s in obs:
 f=s['frozen']['readout'];a0=s['scheduled']['readout']
 sep.append(float(max(abs((np.array(a0['centered'])-np.array(f['centered']))-(np.array(a0['macro'])-np.array(f['macro']))))))
check('same-state observer separation cancels chirality',max(sep)<1e-14)
# Exact elementary squared-distance part of nearest-set margin proof reviewed in text.
review={
 'scope':'Detached calculations on already-retained 18 readouts and original five states. No native update or EMA update; no additional observer settings.',
 'native_evaluations':0,'ema_advances':0,'checks_passed':len(checks),'checks':checks,'independent_readout_and_geometry':errs,
 'max_position_error':max(e['coordinate_error'] for e in errs),'max_arc_error':max(e['arc_distance_error'] for e in errs),
 'frozen_height_and_label':frozen,'scheduled_height_and_label':sched,'paired_arc_inequality':mirror,
 'minimum_pair_inequality_slack':min(q['slack'] for q in mirror),'harmonic_identity':[str(v) for v in expected],
 'transverse_frozen_increments':deltas,'max_transverse_residual':max_transverse,
 'frozen_y_change_0_to_4':obs[4]['frozen']['readout']['centered'][1]-obs[0]['frozen']['readout']['centered'][1],
 'same_state_chiral_cancellation_max_residual':max(sep),
 'qualification':'Checks are bounded verification, not formal interval certification. New simple algebraic consequences require their stated fixed-geometry/preset assumptions.'}
(E/'independent_review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({k:review[k] for k in ('checks_passed','max_position_error','max_arc_error','minimum_pair_inequality_slack','max_transverse_residual','frozen_y_change_0_to_4','same_state_chiral_cancellation_max_residual')},indent=2))
print('PASS')
