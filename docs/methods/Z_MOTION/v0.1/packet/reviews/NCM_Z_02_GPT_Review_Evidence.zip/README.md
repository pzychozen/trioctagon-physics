# NCM-Z-02 GPT review evidence

Project-internal review of the delivered retained-history package. The note explains the scope and differences between the submitted Windows result and this portable Linux replay. No native trajectory or EMA state was advanced.

Scripts refer to a sibling received/ directory containing the original review ZIP extraction. This evidence archive deliberately does not duplicate all source/history files. The supplied_analyze_unchanged.py file is included for identity/reference, not as a standalone runnable distribution. Original scripts and frozen outputs remain unchanged in the uploaded package.

The reviewer mathematical identities are deductions from the existing readout and tau=0 geometry, not added model laws.
