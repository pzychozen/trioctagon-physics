"""Independent copy-only endpoint and ledger checker: zero stage/kick evaluations."""
from pathlib import Path
import json,hashlib
import mpmath as m
R=Path(__file__).resolve().parent;m.mp.dps=120
def load(f):return json.loads((R/f).read_text(encoding='utf-8'))
def v(x):return [m.mpf(a) for a in x]
def dot(a,b):return m.fsum(x*y for x,y in zip(a,b))
checks=[]
def ck(name,a,b,terms=()):
    scale=max(m.mpf(1),abs(a),abs(b),m.fsum(abs(x) for x in terms));err=abs(a-b)
    ok=err<=m.mpf('1e-65')*scale
    checks.append({'name':name,'residual':m.nstr(err,120),'scale':m.nstr(scale,120),'passed':bool(ok)})
    assert ok,name
manifest=load('COPY_HASHES.json')
for f,h in manifest.items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==h,f
data=load('SELECTED_HISTORY.json')['observations'];snap=load('STATE_SNAPSHOTS.json')['runs']['120']
lv=m.mpf(.618);lock=m.mpf(.244);hh=m.cos(3*lock)
for row,s in zip(data,snap):
    z=[m.mpc(m.mpf(a),m.mpf(b)) for a,b in row['omega']]
    ii=m.fsum(abs(a)**2 for a in z);cc=[m.im(m.conj(z[j])*z[k]) for j,k in [(1,2),(2,0),(0,1)]]
    kk=lv*m.sqrt(ii)/(1+m.sqrt(ii));rr=[kk*hh+cc[0]/2,cc[1]/2,kk*hh+cc[2]/2]
    ck(f'n{row["n"]} I',ii,m.mpf(s['I']))
    for j in range(3):
        ck(f'n{row["n"]} C{j}',cc[j],m.mpf(s['C'][j]));ck(f'n{row["n"]} r{j}',rr[j],m.mpf(s['centered_r'][j]))
    ck(f'n{row["n"]} radius squared',dot(rr,rr),m.mpf(s['radius_squared']))
ib=load('NATIVE_INTENSITY_BUDGET.json')['runs']['120'];cb=load('NATIVE_CHIRAL_BUDGET.json')['runs']['120'];fb=load('FROZEN_Z_SOURCE_BUDGET.json')['runs']['120'];rb=load('RADIAL_TRANSVERSE_ACCOUNTING.json')['runs']['120']
for i in range(4):
    b=ib[i]['intensity'];c=cb[i]['chiral'];f=fb[i]['frozen'];r=rb[i]['radial_transverse'];a0=v(snap[i]['centered_r']);a1=v(snap[i+1]['centered_r'])
    ck(f'{i} intensity sum',m.fsum(v(list(b['parent'].values())))+m.mpf(b['saved_after_residual_RI']),m.mpf(snap[i+1]['I'])-m.mpf(snap[i]['I']))
    for j in range(3):
        cterms=[m.mpf(t[j]) for t in c['C_terms'].values()]
        ck(f'{i} chirality sum {j}',m.fsum(cterms)+m.mpf(c['saved_after_residual_RC'][j]),m.mpf(snap[i+1]['C'][j])-m.mpf(snap[i]['C'][j]),cterms)
        allv=[m.mpf(t[j]) for t in list(f['intensity_parent_vectors'].values())+list(f['chiral_vectors'].values())]
        ck(f'{i} displacement sum {j}',m.fsum(allv)+m.mpf(f['model_to_data_residual_vector'][j])+m.mpf(f['readout_roundoff_residual'][j]),a1[j]-a0[j],allv)
    sr=m.fsum(v(list(r['signed_radius_squared_terms'].values())))+m.mpf(r['model_to_data_residual_contribution'])+m.mpf(r['readout_roundoff_contribution'])+m.mpf(r['radial_closure_residual'])
    ck(f'{i} radial sum',sr,dot(a1,a1)-dot(a0,a0),v(list(r['signed_radius_squared_terms'].values())))
    ck(f'{i} coarse radial',m.fsum(v(list(r['coarse_endpoint_difference'].values())))+m.mpf(r['coarse_residual']),dot(a1,a1)-dot(a0,a0))
    ck(f'{i} transverse y',m.fsum(v(list(r['y_terms'].values())))+m.mpf(r['y_model_to_data_residual']),a1[1]-a0[1])
out={'scope':'copies only; independent endpoint pair products and additive ledger closure; no prestage/kick/budget reconstruction or previous-suite execution','input_hashes_verified':len(manifest),'checks':checks,'count':len(checks),'passed':sum(c['passed'] for c in checks),'primary_pair_budget_evaluations':0}
(R/'PORTABLE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({'checks':len(checks),'passed':out['passed'],'primary_pair_budget_evaluations':0}))
