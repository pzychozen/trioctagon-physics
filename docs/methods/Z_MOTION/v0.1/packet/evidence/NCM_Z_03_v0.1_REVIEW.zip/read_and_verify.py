from pathlib import Path
import json,zipfile,hashlib
R=Path(__file__).resolve().parent;P=R/'packet/NCM_Z_03_Packet_v0.1';OLD=R.parent/'NATURAL_CORE_MOTION_Z_RETAINED_HISTORY_01'
def sha(b):return hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(P/'evidence/NCM_Z_02_v0.1_REVIEW.zip') as z:
 m=json.loads(z.read('OUTPUT_HASHES.json'))['entries']
 assert set(z.namelist())=={e['path'] for e in m}|{'OUTPUT_HASHES.json'}
 for e in m:
  b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
 assert z.read('inputs/SELECTED_HISTORY.json')==(P/'inputs/SELECTED_HISTORY.json').read_bytes()==(OLD/'inputs/SELECTED_HISTORY.json').read_bytes()
 assert z.read('OBSERVATIONS.json')==(P/'context/NCM_Z_02_OBSERVATIONS.json').read_bytes()==(OLD/'OBSERVATIONS.json').read_bytes()
 assert (P/'source_text/dynamics.py.txt').read_bytes()==(R/'sources/kernel_physics/dynamics.py').read_bytes()
 assert (P/'source_text/readouts.py.txt').read_bytes()==(R/'sources/kernel_physics/readouts.py').read_bytes()
 verification={'prior_payload_verified':len(m),'prior_members':len(z.namelist()),'selected_input_sha256':sha(z.read('inputs/SELECTED_HISTORY.json')),'selected_original_and_packet_and_archive_identical':True,'prior_observations_original_and_packet_and_archive_identical':True,'local_dynamics_readouts_match':True,'source_blob_ids_match_packet':True}
 assert json.loads((R/'SOURCES.json').read_text())[1]['git_blob_sha1_calculated_without_git']=='c3fef4d1c6b4c2e60c9d6668d3f6cd0a367e1d04'
 assert json.loads((R/'SOURCES.json').read_text())[2]['git_blob_sha1_calculated_without_git']=='d6de26ddb54e73063aca2fdbde3dc35b93797284'
(R/'INPUT_VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
for f,lo,hi in [('sources/papers/PAPER_G/v0.1.1/source/paper_g.tex',60,165),('packet/NCM_Z_03_Packet_v0.1/source_text/historical_nominal_producer.py.txt',120,175),('sources/kernel_physics/readouts.py',1,100)]:
 print('\nSOURCE',f)
 for i,line in enumerate((R/f).read_text(encoding='utf-8').splitlines(),1):
  if lo<=i<=hi: print(f'{i}: {line}')
obs=json.loads((P/'context/NCM_Z_02_OBSERVATIONS.json').read_text());print('OBS_SCHEMA',str(obs)[:4300])
for f in ['source_text/motion_observer.py.txt']:
 lines=(P/f).read_text(encoding='utf-8').splitlines();print('OBSERVER LOCATORS')
 for i,l in enumerate(lines,1):
  if any(t in l for t in ['def ', 'lambda_vp', 'Z_macro', 'placement', 'theta', 'lock']):print(i,l)
