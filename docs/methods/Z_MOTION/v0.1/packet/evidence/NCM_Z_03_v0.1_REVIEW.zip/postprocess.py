from pathlib import Path
import json,hashlib,shutil,os,subprocess,sys
R=Path(__file__).resolve().parent
def load(n):return json.loads((R/n).read_text(encoding='utf-8'))
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
files=['STATE_SNAPSHOTS.json','NATIVE_INTENSITY_BUDGET.json','NATIVE_CHIRAL_BUDGET.json','FROZEN_Z_SOURCE_BUDGET.json','RADIAL_TRANSVERSE_ACCOUNTING.json','NUMERIC_POLICY.json','portable_check.py']
scratch=R/'scratch/portable_01';scratch.mkdir(parents=True,exist_ok=False)
for f in files:shutil.copyfile(R/f,scratch/f)
shutil.copyfile(R/'packet/NCM_Z_03_Packet_v0.1/inputs/SELECTED_HISTORY.json',scratch/'SELECTED_HISTORY.json')
mapping={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in scratch.iterdir() if p.is_file()}
(scratch/'COPY_HASHES.json').write_text(json.dumps(mapping,indent=2)+'\n',encoding='utf-8')
done=subprocess.run([sys.executable,'-X','utf8','-I','-B',str(scratch/'portable_check.py')],cwd=scratch,capture_output=True,text=True)
(R/'logs/portable_check.txt').write_text(done.stdout+done.stderr,encoding='utf-8');print(done.stdout+done.stderr);assert done.returncode==0
shutil.copyfile(scratch/'PORTABLE_RESULTS.json',R/'PORTABLE_VERIFICATION.json')
assert all(hashlib.sha256((scratch/f).read_bytes()).hexdigest()==h for f,h in mapping.items())
dump('PORTABLE_COPY_HASHES.json',mapping)
snap=load('STATE_SNAPSHOTS.json')['runs']['120'];ib=load('NATIVE_INTENSITY_BUDGET.json')['runs']['120'];cb=load('NATIVE_CHIRAL_BUDGET.json')['runs']['120'];fb=load('FROZEN_Z_SOURCE_BUDGET.json')['runs']['120'];rb=load('RADIAL_TRANSVERSE_ACCOUNTING.json')['runs']['120']
for i in range(4):
 print('INTERVAL',i,i+1)
 print('I actual',ib[i]['intensity']['actual_delta_I'],'EXPANDED',ib[i]['intensity']['expanded_alternative'])
 print('radii',float(snap[i]['radius']),float(snap[i+1]['radius']),'delta',float(rb[i]['radial_transverse']['actual_delta_radius']),'r2',float(rb[i]['radial_transverse']['actual_delta_radius_squared']))
 print('displacement',list(map(float,fb[i]['frozen']['actual_displacement'])),'norm',float(fb[i]['frozen']['net_displacement_norm']))
 print('macro',list(map(float,fb[i]['frozen']['macro_displacement'])),'chiral',list(map(float,fb[i]['frozen']['chiral_displacement'])))
 print('RC',cb[i]['chiral']['saved_after_residual_RC'])
 print('cancellation radial,y',rb[i]['radial_transverse']['radial_cancellation']['sum_abs_over_abs_net'],rb[i]['radial_transverse']['y_cancellation']['sum_abs_over_abs_net'])
checks=load('CHECKS.json')['checks']
summary={}
for dps in [80,120]:
 c=[x for x in checks if x['dps']==dps and 'saved-after' in x['name']]
 summary[str(dps)]={'model_to_data_max_absolute_residual':max(float(x['max_abs_residual']) for x in c),'model_to_data_max_scaled_residual':max(float(x['max_abs_residual'])/float(x['scale']) for x in c)}
summary['precision_comparison_max_absolute']=max(float(x['max_abs_residual']) for x in checks if x['name'].startswith('80/120'))
dump('RESIDUAL_SUMMARY.json',summary);print('RESIDUALS',summary)

# Plot only already-delivered ledger values, not stage arithmetic.
os.environ['MPLCONFIGDIR']=str(R/'cache/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12})
figdir=R/'figures';figdir.mkdir(exist_ok=True)
def bars(ax,labels,values):
 colors=['#267a91' if v>=0 else '#bd6940' for v in values]
 rect=ax.bar(range(len(values)),values,color=colors,width=.62)
 ax.axhline(0,color='#333333',lw=.8);ax.set_xticks(range(len(labels)),labels)
 ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
 ax.margins(y=.24)
 for r,v in zip(rect,values):ax.annotate(f'{v:+.5g}',(r.get_x()+r.get_width()/2,v),xytext=(0,4 if v>=0 else -4),textcoords='offset points',ha='center',va='bottom' if v>=0 else 'top',fontsize=9)
fig,axs=plt.subplots(4,2,figsize=(13,12),layout='constrained')
for i in range(4):
 b=ib[i]['intensity'];p=b['parent'];e=b['expanded_alternative']
 bars(axs[i,0],['Onsite','Graph','Increment square'],[float(v) for v in p.values()]);axs[i,0].set_title(f'{i} → {i+1}: ΔI = {float(b["actual_delta_I"]):+.7g}')
 bars(axs[i,1],['Onsite²','Mixed','Graph²'],[float(e[k]) for k in ['onsite_square','mixed_onsite_coupling','coupling_square']]);axs[i,1].set_title('Increment-square detail — alternative expansion')
 for ax in axs[i]:ax.set_ylabel('Signed state-intensity contribution')
fig.suptitle('Native intensity budgets • saved update spans 0–4\nLeft: three-term sum. Right: children of the square, not extra terms.',fontsize=15)
fig.supxlabel('Uncalibrated native-update spans; independent vertical scale per panel',fontsize=10)
fig.savefig(figdir/'01_intensity.png',dpi=160);plt.close(fig)
short=['Onsite\nfirst','Graph\nfirst','Onsite²','Mixed','Graph²','Existing\narea phase','Symmetric\npair phase']
fig,axs=plt.subplots(2,2,figsize=(14,9),layout='constrained')
for i,ax in enumerate(axs.flat):
 r=rb[i]['radial_transverse'];bars(ax,short,[float(v) for v in r['y_terms'].values()]);ax.tick_params(axis='x',labelsize=9)
 ax.set_title(f'{i} → {i+1}: Δ centered y = {float(r["delta_centered_y"]):+.7g}');ax.set_ylabel('Signed contribution to β ΔCᵧ (placed units)')
fig.suptitle('Frozen transverse displacement • seven chiral terms\nThe norm-dependent macro term has exactly zero y component.',fontsize=15)
fig.supxlabel('Uncalibrated native-update spans; independent vertical scale per panel',fontsize=10)
fig.savefig(figdir/'02_transverse.png',dpi=160);plt.close(fig)
fig,axs=plt.subplots(2,2,figsize=(12,8),layout='constrained')
for i,ax in enumerate(axs.flat):
 r=rb[i]['radial_transverse'];bars(ax,['Macro magnitude','Chiral magnitude','Cross alignment'],[float(v) for v in r['coarse_endpoint_difference'].values()]);ax.tick_params(axis='x',labelsize=9)
 net=float(r['actual_delta_radius_squared']);ax.axhline(net,color='#795599',ls='--',lw=1,label=f'Net {net:+.7g}');ax.legend(fontsize=9)
 ax.set_title(f'{i} → {i+1}: '+('outward' if net>0 else 'inward'));ax.set_ylabel('Change in placed squared radius (width²)')
fig.suptitle('Frozen radial balance • endpoint differences\nMacro size, chiral size and their signed cross term',fontsize=15)
fig.supxlabel('Uncalibrated native-update spans; independent vertical scale per panel',fontsize=10)
fig.savefig(figdir/'03_radial_balance.png',dpi=160);plt.close(fig)
dump('FIGURE_RECORD.json',{'source':'120-digit delivered ledgers, converted to float for plotting only','figure_count':3,'no_intermediate_states':True,'files':[str(p.relative_to(R)) for p in sorted(figdir.glob('*.png'))],'independent_panel_scales':True,'visual_QA':'pending'})
