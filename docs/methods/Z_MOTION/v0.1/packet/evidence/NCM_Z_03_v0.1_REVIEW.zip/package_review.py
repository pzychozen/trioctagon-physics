from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,datetime
R=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((R/n).read_text(encoding='utf-8'))
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
before=load('PRESERVATION_BEFORE.json');after=[]
for e in before:
 p=Path(e['path']);b=p.read_bytes();after.append({**e,'after_bytes':len(b),'after_sha256':sha(b),'unchanged':len(b)==e['bytes'] and sha(b)==e['sha256']})
assert all(e['unchanged'] for e in after)
dump('PRESERVATION_AFTER.json',{'utc':now(),'scope':'only the explicitly listed 12 live Windows originals; not a whole-checkout audit','checked':len(after),'unchanged':sum(e['unchanged'] for e in after),'entries':after})
for name,h in load('PLAN_FREEZE_RECEIPT.json')['sha256'].items():assert sha((R/name).read_bytes())==h,name
evaluations=[json.loads(x) for x in (R/'PRIMARY_EVALUATIONS.jsonl').read_text().splitlines()]
assert len(evaluations)==8 and {(e['before'],e['after'],e['dps']) for e in evaluations}=={(i,i+1,p) for i in range(4) for p in [80,120]}
checks=load('CHECKS.json');portable=load('PORTABLE_VERIFICATION.json')
assert checks['count']==checks['passed']==1851 and portable['count']==portable['passed']==80
assert all(c['passed'] for c in checks['checks']) and all(c['passed'] for c in portable['checks'])
assert load('COUNTS.json')['primary_pair_budget_evaluations']==8
for filename in ['NATIVE_INTENSITY_BUDGET.json','NATIVE_CHIRAL_BUDGET.json','FROZEN_Z_SOURCE_BUDGET.json','RADIAL_TRANSVERSE_ACCOUNTING.json']:
 for p,rows in load(filename)['runs'].items():
  assert [(r['before'],r['after']) for r in rows]==[(i,i+1) for i in range(4)]
  assert all(r['status']=='SOURCE_CONSISTENT_NUMERICAL_ACCOUNTING' for r in rows)
assert len(list((R/'figures').glob('*.png')))==3
dump('QA_RECORD.json',{'utc':now(),'primary_script_and_plan_still_match_frozen_hashes':True,'four_intervals_source_consistent_at_both_precisions':True,'source_crosswalk_checked_against_actual_line_numbers':True,'numerical_artifacts_immutable_after_analysis':True,'figures':'three original PNGs inspected; no clipping; signed values visible; separate intensity/radius units and independent scales labeled','primary_budget_evaluations':8,'copy_only_portable_checks':80,'main_logged_checks':1851,'live_originals_preserved':len(after),'no_publication_or_successor':True})
(R/'CLOSEOUT.txt').write_text('NCM-Z-03 v0.1 complete. Four retained transitions accounted at 80 and 120 decimal digits. Eight primary passive prestage/kick/budget evaluations; zero trajectory advances or new admitted native states. 1851 main checks and 80 copy-only portable checks passed. 12 live original files unchanged. No Git, old producer/suite rerun, application/model change, publication or successor task.\n',encoding='utf-8')
name='NCM_Z_03_v0.1_REVIEW.zip';archive=R/name
assert not archive.exists(),'Do not overwrite a prior review archive'
exclude={'OUTPUT_HASHES.json','REVIEW_RECEIPT.json',name}
payload=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if rel.parts[0] in {'scratch','cache'} or p.name in exclude:continue
 assert not p.is_symlink()
 b=p.read_bytes();payload.append({'path':rel.as_posix(),'bytes':len(b),'sha256':sha(b)})
dump('OUTPUT_HASHES.json',{'algorithm':'SHA-256','scope':'all ZIP payload files; manifest excludes itself; receipt is external','entries':payload})
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for e in payload:z.write(R/e['path'],e['path'])
 z.write(R/'OUTPUT_HASHES.json','OUTPUT_HASHES.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))==len(payload)+1
 assert set(names)=={e['path'] for e in payload}|{'OUTPUT_HASHES.json'}
 for n in names:
  q=PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts and '\\' not in n and ':' not in n
 for e in payload:
  b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'] and b==(R/e['path']).read_bytes()
 assert z.read('OUTPUT_HASHES.json')==(R/'OUTPUT_HASHES.json').read_bytes()
 assert sha(z.read('packet/NCM_Z_03_Packet_v0.1/inputs/SELECTED_HISTORY.json'))=='a294a4b0bf181adaa2054aa52379c1832a7833e3faa7614d0785aecd709ea09c'
for e in before:assert sha(Path(e['path']).read_bytes())==e['sha256']
receipt={'task':'NCM-Z-03 v0.1','completed_utc':now(),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payload_files_verified':len(payload),'total_members_verified':len(payload)+1,'manifest_sha256':sha((R/'OUTPUT_HASHES.json').read_bytes()),'crc_safe_paths_unique_members_exact_set_and_local_bytes_verified':True,'selected_input_unmodified':True,'live_original_files_unchanged_after_packaging':len(before),'primary_pair_budget_evaluations':8,'main_checks_passed':1851,'portable_checks_passed':80,'no_trajectory_advancement_or_publication':True}
dump('REVIEW_RECEIPT.json',receipt);print(json.dumps(receipt,indent=2))
