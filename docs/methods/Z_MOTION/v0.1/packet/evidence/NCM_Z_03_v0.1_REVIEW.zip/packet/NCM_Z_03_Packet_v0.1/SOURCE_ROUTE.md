# Source route and authority — read-only

## Included and already byte-verified

`evidence/NCM_Z_02_v0.1_REVIEW.zip` is the original unchanged 99-member submission. Its manifest validates 98 payload files, excluding itself. `INPUT_COPY_PROVENANCE.json` identifies each unmodified convenience copy taken from it. Its existing source/accounting records, rather than an assumed present HEAD, establish the retained history's lineage.

Selected history and all four transitions are fixed in the new order. No database/library/filename search for another history is needed. The original producer text is included ONLY for parameter and serialization meaning; do not execute it.

Relevant definitions included as non-executable text copies:

* `source_text/dynamics.py.txt`: native update and Arg0; SHA matches the Z-02 accepted snapshot.
* `source_text/readouts.py.txt`: raw C orientation and cyclic extraction.
* `source_text/motion_observer.py.txt`: frozen point, preset and placement arithmetic.
* `source_text/PAPER_E_v0.1.1.md`: source manuscript, including inherited norm/potential accounting.
* `source_text/observables_closure.tex.txt`: state/geometry typing and domain caveats.
* `source_text/historical_nominal_producer.py.txt`: historical exact-decimal coefficient choices and rounded saved-string format; text only.

## Three additional named source reads on the existing Windows checkout

Root: `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`.

1. `kernel_physics/z_diagnostics.py`: `intensity_budget`, `IntensityBudget`, `_state_parameters`, and `readout_accounting` as needed. The former does not execute a phase step and computes its own prestage `observed_delta`, so an independent saved-after comparison must be added externally.
2. `kernel_physics/axial_observables.py`: `_sa`, `_area`, `axial_source_budget` and relevant records. Source names of five amplitude terms and two phase terms control terminology.
3. `papers/PAPER_G/v0.1.1/source/paper_g.tex`: §2 area conventions; §3 “Exact finite-step source and entrance conversion.” In the reading baseline, the main budget passage occurs around lines 120–156; use section/equation labels if line endings change.

The preparation read these through the available GitHub connector at:

    7cc1fa03af589818bcdcfaaac51838cc36c84253

Verified connector-reported Git blob identities:

    kernel_physics/axial_observables.py
      c3fef4d1c6b4c2e60c9d6668d3f6cd0a367e1d04
    papers/PAPER_G/v0.1.1/source/paper_g.tex
      d6de26ddb54e73063aca2fdbde3dc35b93797284

A Git blob ID is SHA-1 of the Git blob header plus bytes, not a SHA-256 file checksum. No Git command is needed to compare either type. The diagnostics connector response was read, but a blob identity was not retained in this packet; hash its actual local bytes instead of fabricating one.

Those three full byte streams are not included here. A direct sandbox download was unavailable; no reconstructed full source copy is represented as an authoritative byte snapshot. Codex should read the already-present local files, snapshot them in the new research directory, and record their actual identities and consulted ranges. Any formula difference from the provided brief must be reported and resolved from the controlling source, not silently patched. No network acquisition, source reset or repository modification is required by this order.

## Source boundaries

The historical native parameters .1/.2/.17/(2,3,4) are the ones to use. Paper G's M3 coefficients and the recent coherence-paper coefficients are NOT substituted. Observer lambda_vp=.618 and native lambda_phase=.17 are different quantities. The literal observer constants have binary64 semantics as declared in Z-02; no exact golden ratio is substituted.

The primary data are a constructed historical nominal example. Source hashes and passed retained checks do not authenticate a producer or establish an exact ideal trajectory. Report the new model-to-saved-endpoint residuals rather than assuming equality from filenames.

All formulas and proposed decompositions in `MATHEMATICAL_BRIEF.md` are subject to independent verification. Existing identities should be credited as existing; the frozen-readout composition and signed radial split are elementary accounting tools, not new forces or motion variables.
