# Mathematical brief — NCM-Z-03

**Status:** GPT lead analysis for independent Codex verification. Established budget identities are cited below; composing them with the frozen readout gives the proposed accounting. This brief is not a completed experiment or a claim of new fundamental mathematics. No retained native stages were evaluated while preparing it.

## 1. Fixed definitions and notation

Let z=x+i y be a SAVED triad, s_i=|z_i|², D=diag(k−s), and

    L = [[−2,1,1],[1,−2,1],[1,1,−2]].
    u = epsilon D z                 (onsite increment)
    v = g L z                       (graph increment)
    b = u+v
    z_tilde = z+b = M z,   M=Id+epsilon D+gL.

Use epsilon=1/10, g=1/5, lambda=17/100, k=(2,3,4), inherited from the selected nominal producer. All quantities here use the same before-state; do not sequentially apply the onsite and graph corrections as if they were different native updates.

Native phase kicks are delta_i=lambda sum_(j!=i) sin(3(phi_j−phi_i)), all computed from phi_i=Arg0(z_tilde_i). For nonzero pairs this equals lambda sum Im[((conj(z_tilde_i) z_tilde_j)/(|z_tilde_i||z_tilde_j|))^3]. At zeros use the source convention, not the normalized expression. Lambda=0 bypasses synchronization in the code. No phase ramp or clock belongs to these kicks.

Define

    S = x x^T + y y^T,
    A = x y^T − y x^T,
    C = (A_23,A_31,A_12) = x cross y  (one-based indices),
    I = ||z||²,   kappa=sqrt(I).

The coherence zz† equals S−iA in this convention. The conjugate-pair matrix with entries conj(z_i)z_j is S+iA. Preserve that distinction.

## 2. Inherited exact intensity accounting

The ideal phase step preserves each |z_tilde_i|, so

    Delta I_model = ||z_tilde||² − ||z||²
      = 2 Re(z†u) + 2 Re(z†v) + ||u+v||²
      = 2 epsilon sum_i (k_i s_i−s_i²)
        − 2g sum_(i<j)|z_i−z_j|² + ||u+v||².

The edges are counted once. The first three displayed terms correspond to `intensity_budget`'s onsite, coupling and remainder. The further expansion

    ||u+v||² = ||u||² + 2 Re(u†v) + ||v||²

exposes a signed interaction term. Either display the three-term parent budget or its five-term expansion; never add both the parent remainder and its three children.

For saved endpoints i,j=i+1 retain

    R_I = (I_j−I_i) − sum_l B_l.

R_I includes finite arithmetic and the fact that the saved decimal states are rounded. Do not hide it or assert exact native consistency from its small numerical size. The ideal identity is exact; evaluation on retained nominal strings is numerical evidence.

Source: `kernel_physics/z_diagnostics.py::intensity_budget`; Paper E's native potential/intensity accounting. No full-map energy conservation/descent is asserted. I is a native state norm squared, not gravitational energy or spatial radius squared.

## 3. Inherited exact chirality accounting

Before synchronization,

    S_tilde=M S M^T,  A_tilde=M A M^T,
    C_tilde=cof(M) C.

The cofactor identity is polynomial and needs no inverse. With D and L symmetric,

    A_tilde−A = epsilon(DA+AD)                  onsite_first
                + g(LA+AL)                    coupling_first
                + epsilon² DAD                onsite_squared
                + epsilon g(DAL+LAD)          mixed
                + g² LAL.                     coupling_squared

After the simultaneous phase kicks, set d_ij=delta_j−delta_i. Then

    Aplus_ij=Atilde_ij cos(d_ij)+Stilde_ij sin(d_ij).

Consequently the two phase-increment terms are

    Atilde_ij[cos(d_ij)−1]          phase_existing_area
    Stilde_ij sin(d_ij)             phase_symmetric_pair.

Trig multiplication here is ENTRYWISE. Extract each term's C triple using the same cyclic convention. Let these seven triples be c_t. Then

    R_C = (C_j−C_i) − sum_t c_t.

This is the existing finite-step source budget, not a new force decomposition. A_tilde, S_tilde and delta are reconstructed diagnostic intermediates, not observations saved by the old producer. Keep the established phase terms dependent on the actual mixed prestage; do not relabel them as independent external causes.

Source: Paper G §3 equations `eq:cof`, `eq:budget`, `eq:rotateA`, `eq:rotateS`; `kernel_physics/axial_observables.py::axial_source_budget`.

## 4. Exact finite gain from intensity to frozen macro displacement

The staged gain is K(kappa)=lambda_vp*kappa/(1+kappa). For two saved endpoint norms a=kappa_i and b=kappa_j,

    K(b)−K(a) = lambda_vp (b−a)/[(1+a)(1+b)]
              = q_ij (I_j−I_i),
    q_ij = lambda_vp / [(a+b)(1+a)(1+b)]       if a+b>0.

This is an EXACT finite divided difference, not a derivative or infinitesimal approximation. Both endpoint norms are used. If a=b>0 it remains valid and Delta I=0; if a=b=0, Delta K=0 and the divided-difference coefficient is left undefined. Do not create an axis or divide by zero.

The frozen centered placement is

    r_n = X_n*−O = L_p [alpha E_* K_n H_* + beta C_n],
    L_p=mu_place R_psi,
    H_*=cos(3(theta_*−lock)) (cos theta_*, sin theta_*,1).

All settings are inherited and frozen; for this task mu_place=1, psi=0, theta_*=0, t_*=0 and E_*=1. Do not confuse L_p with the native graph L.

Assign each intensity term B_l a vector

    d_l^I = L_p [alpha E_* H_* q_ij B_l],

and each area term a vector

    d_t^C = L_p [beta c_t].

Then the actual saved-state frozen displacement obeys

    Delta r = sum_l d_l^I + sum_t d_t^C + d_res,
    d_res = L_p [alpha E_* H_* q_ij R_I + beta R_C],

up to the separately retained rounding residual in the readout reconstruction. Nothing is discarded to force closure. The intensity and C pathways are two ways the SAME update changes the SAME readout; their names are not separate physical forces. A different algebraic grouping can change numerical 'shares'.

## 5. Transverse displacement with no norm-macro component

For a fixed nonzero H_*, set h_hat=H_*/||H_*|| and Q=Id−h_hat h_hat^T in readout coordinates. Then

    Q L_p^(-1) Delta r = beta Q (C_j−C_i).

Here L_p is invertible because the fixed scale is positive. At the actual identity placement, Q projects perpendicular to (1,0,1); cos(3 lock) changes its sign or magnitude, not the projector. In particular,

    (r_n)_y=beta C_y(n),
    Delta r_y = beta sum_t (c_t)_y + beta (R_C)_y.

An alternative independent transverse scalar is r_x−r_z=beta(C_x−C_z). Check both identities without claiming they recover the full native state. Macro/chiral cancellations along (1,0,1) can coexist with transverse movement.

## 6. Additive, signed radial accounting

For each saved pair use

    Delta ||r||² = (r_j+r_i) dot (r_j−r_i).

If Delta r=sum d_a+d_res, define the signed endpoint contribution

    B_a^rad=(r_j+r_i) dot d_a.

Summing B_a^rad and the residual contribution gives exactly Delta||r||² in real arithmetic. These are signed bookkeeping quantities, not energies, work by forces or probabilities. Negative entries are meaningful. They may cancel; percentages can be unstable or exceed 100%. Avoid percentages when the net change is small.

Where ||r_j||+||r_i||>0, dividing these contributions by that common positive denominator gives an additive identity for Delta||r|| if useful. If both vanish, leave that ratio undefined and use the squared-radius identity.

Independently calculate the coarser three-term endpoint identity

    ||r_n||² = mu_place² [ alpha² E_*² K_n² ||H_*||²
                    + beta² ||C_n||²
                    + 2 alpha beta E_* K_n (H_* dot C_n) ].

Take endpoint differences of each bracketed term. This provides the macro-size, chiral-size and cross-alignment view. Do not equate the cross term with physical interference energy or use only the separate magnitudes to predict inward/outward behavior. A larger native norm and a smaller chiral contribution can still yield a net direction or radius change determined by their signed geometry.

## 7. Questions the four-interval explanation must answer

1. Which signed intensity terms explain the sharp initial norm change? Is the finite-step square or its mixed part material to the balance?
2. How do the five prestage terms and two phase terms share or oppose each component of Delta C, especially Delta C_y?
3. Do the smaller middle displacements reflect smaller sources, cancellation, or both?
4. Which contributions give a positive radial balance at 3→4? Does that differ from the mechanism of the first inward span?
5. What is purely inherited algebra, what is newly applied to this history, and what remains an interpretation not supplied by the equations?

Do not predict the answers from the final displacement. Compute every term and every residual. No new history, phase sweep, observer schedule, gap geometry, physical coupling or favored number is needed.
