# NCM-Z-03 v0.1 — Native-source accounting of frozen Z displacement

**Author:** Hilmir Frímann Halldórsson / pzychozen  
**Scientific lead:** GPT; independent derivation, implementation and verification: Codex  
**Prepared:** 1 November 2026  
**Disposition:** Author-requested bounded research work order. Not implementation, publication, or authority to alter a model.

## 1. The question and why this is the next step

For the SAME five retained native states used in NCM-Z-02, **which terms of the existing native update account for the changes of norm and chirality that survive in frozen staged Z?** Explain the strong first inward displacement, the smaller intermediate displacements, and the final outward endpoint change. Determine what is reinforced and what cancels, without presupposing that any one term dominates.

This is a source-to-observation accounting investigation, not another nearest-gap search. Z-02 already found no frozen nearest-opening switches and three scheduled switches in this window, all at clock replacement in its stated ordered decomposition. Frozen positions nevertheless change and their final radial increment is positive. We now follow those surviving changes back to the already-defined native intensity and area budgets.

The model must be allowed to contradict a simple narrative. Small total motion need not mean every contribution is small. Increasing state norm need not mean increasing placed radius. A large term norm does not make that term a physical force or an independent cause.

## 2. Authority, environment and preservation

Use Windows **Command Prompt**, the existing `torment` environment, and its existing Python/math libraries. Do not substitute PowerShell, install dependencies, modify environment configuration, elevate privileges or acquire new runtimes.

Read-only checkout:

    C:\TORMENT\TRIOCTAGON_new\trioctagon-physics

Existing Z-02 research (read only):

    C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_RETAINED_HISTORY_01

Create a fresh external output directory, initially:

    C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01

If it exists, leave it untouched and reserve the next unused suffix. All calculations, caches, plans, source copies and outputs belong there. Record exact commands, interpreter and working directories. Put caches outside the checkout. Use `python -X utf8 -I -B` where appropriate after `call conda activate torment`; resolve scripts using their actual extracted paths, not an assumed repository-root location.

No Git commands or Git-invoking helpers. Do not edit native kernels, the UI, accepted papers, earlier research, locks, TORMENT, Brainvision, or unrelated working files. This order neither checks nor changes the separately authorized coherence-paper publication. No new paper, branch, commit, push, release or successor task follows automatically.

Hash a bounded list of the actual input/source files before and after. A preserved packaged snapshot is not a preservation check of a live Windows original. Do not conduct another whole-repository audit.

## 3. Required inputs: no record search

The packet contains the unchanged Z-02 review archive, its ledgers and selected state file, and GPT's separate review. Verify the packet manifest and the selected input identity before calculating contributions. Verify the prior archive manifest as data; do not execute its analysis or producer scripts.

| Input | Required identity |
|---|---|
| Z-02 review archive | 3,759,247 bytes; SHA-256 `a0e26a24ce7511498d207bfac4a78da7ed4fa02605f92eed7b4a1a999a218518` |
| `inputs/SELECTED_HISTORY.json` | 8,871 bytes; SHA-256 `a294a4b0bf181adaa2054aa52379c1832a7833e3faa7614d0785aecd709ea09c` |
| Stored states | Actual indices 0,1,2,3,4; every row, no exclusions |
| Primary transitions | Exactly 0→1, 1→2, 2→3, 3→4 |
| Historical native parameters | epsilon=1/10, g=1/5, lambda_phase=17/100, k=(2,3,4) |

This is the admitted historical nominal example, not the earlier two-state run and not the coherence-paper coefficient set. The five states are saved rounded high-precision values, originally produced with 120-decimal working arithmetic and retained as up to 100-significant-digit strings. Their evidence class remains `NUMERICAL_CORROBORATION_ONLY`. Do not regenerate the exact radical entrance, infer missing digits, turn enclosure flags into a new certificate, or normalize/rephase any row.

Use packet copies as the portable fallback when an original path is unavailable, recording that fact. If source/input identity cannot be resolved, return the supported partial result and the exact blocker; do not ask the author to reconstruct archives already supplied or silently replace the history.

## 4. Recover the already-established budgets first

Read `SOURCE_ROUTE.md` and the source definitions, not just the proposed mathematical brief. The established authority is:

* `kernel_physics/dynamics.py`: simultaneous polynomial prestage and harmonic-three synchronization; retain Arg0 and the lambda=0 bypass.
* `kernel_physics/z_diagnostics.py`, `intensity_budget`: canonical onsite, graph and finite-increment-square intensity accounting. Its `observed_delta` is a reconstructed prestage difference, NOT a comparison with the saved next state.
* `kernel_physics/axial_observables.py`, `axial_source_budget`: five amplitude/congruence terms and two phase-area terms. Its reconstructed prestage is not a saved intermediate.
* `papers/PAPER_G/v0.1.1/source/paper_g.tex`, “Exact finite-step source and entrance conversion”: congruence, cofactor and phase-pair identities. Use the source definitions, not Paper G's different M3 parameters.
* Z-02's copied staged-observer and placement definitions, fixed anchor and ledgers.

GPT inspected the three budget sources through the GitHub connector at the stated reading baseline. They are named local reads in this order; complete byte copies of those three files are NOT included in this packet. Their locators and available Git blob identities are in `SOURCE_ROUTE.md`. Other relevant exact snapshots ARE included. A known reading baseline is not the checkout HEAD and is not a reset instruction. If local bytes differ, compare the relevant definitions and provenance; do not merge formulas silently or initiate a source archaeology project.

Read source modules as text and make standalone algebraic transcriptions. Do not import project packages, passive APIs with transitive project imports, old producers, archived checkers, or app workers. No `step3`, `step_ring`, `_advance`, `run`, `resume`, full complex next-state evaluator or trajectory loop is authorized. Reuse their definitions, not their execution entry points.

## 5. Explicit computational scope — passive stage reconstruction is allowed

The previous studies prohibited reconstructing dynamics. This NEW order specifically permits **isolated passive budget reconstructions on the four saved adjacent pairs**. For each saved before-state at n=0,1,2,3, you may calculate:

1. onsite and graph increments, their sum, and the reconstructed prestage;
2. prestage phases and simultaneous native kicks under the retained convention;
3. predicted intensity and area/chiral quantities via the established identities;
4. residuals against the independently supplied next-state quantities.

No reconstructed prestage or predicted quantity becomes a new history sample. No output is fed into another update. Every budget starts afresh from the original saved before-state. Do not calculate an index-4 successor, reconstruct intermediate time states, or form/export an evolved post-sync complex state. The saved after-state is always authoritative data, not replaced by a prediction.

These reconstructions do evaluate algebra from the native stages. Report them honestly as **prestage/kick/budget evaluations**, not as “no dynamics arithmetic” merely because `step3` was not called. Distinguish them from zero trajectory advances and zero newly admitted native states.

Primary limit: four pair budgets at 80 decimals plus the same four at 120 decimals; at most four optional binary64 shadow budgets. Maximum **12 primary pair-budget evaluations**. Cache reusable terms. Up to 16 predeclared synthetic identity/edge-case fixtures may each be evaluated at at most two precisions; these are algebra checks, not new trajectories, physical examples or parameter research. Symbolic proofs are permitted. No data-dependent new states, parameter sweep, phase scan, new frozen anchor, optimizer, fit, stochastic seed or intervention setting a model term to zero for a new trajectory.

## 6. Freeze a compact analysis plan before new contribution results

Record the four intervals, sources, parameter semantics, frozen observer, numeric policies, chosen term names/groupings, test fixtures and computation ceilings in `PLAN.json`. Hash it and the new scripts before primary budget output. Source reading and inspecting existing ledgers to prepare the plan are allowed. Repair genuine code/definition mistakes with an explicit correction log; do not alter the science window, grouping or thresholds to favor an outcome.

Native reference arithmetic: parse saved strings directly with mpmath; use exact rational native coefficients (1/10,1/5,17/100;2,3,4), as in the historical nominal producer. Do not quietly substitute binary64 values for these native coefficients.

Observer reference arithmetic: preserve Z-02's application-style constants by lifting the exact binary64 values into high precision, including lambda_vp=0.618, gamma=0.577 and lock=0.244. Alpha=1, beta=0.5, placement scale=1, placement rotation=0, frozen angle=0 and time=0. Use high-precision pi/radicals and trig on these declared inputs. The old ideal-decimal saved Z is a separate historical comparison, not a required byte match to these application-style readouts.

Use scaled numerical checks: high-precision agreement and budget/end-state residual target 1e-65 times max(1, magnitudes and sum of absolute contributing terms). This is a reproducibility screen, NOT a proved error bound for the rounded historical trajectory. Optional binary64 comparisons use 5e-12 times the same explicit scale, reported separately. No retrospective tolerance relaxation. Report small sign/dominance decisions as unresolved when arithmetic disagreement or severe cancellation makes them unreliable. Retain raw residuals. If a historical transition fails reconstruction, preserve it and stop attributing that transition to the assumed update pending reconciliation; do not repair its next state.

## 7. Required calculations

### A. Five endpoint snapshots and four model-to-data checks

For all five states retain I=||Omega||², kappa=sqrt(I), S, A, C, and the frozen placed point X*. Use `F` for the native map only when clearly typeset; avoid confusing it with the previous “F” frozen-point marker.

For each before-state reconstruct onsite/coupling/prestage/kicks from the source, with simultaneous kicks. Compare the predicted intensity and each predicted C component to the saved after-state. Verify congruence and phase-pair accounting independently. Residuals are informative, not another authentication or full native replay certificate.

### B. Native norm/intensity budget

Recover the established three-term identity: onsite intensity contribution, graph contribution, and ||onsite increment + graph increment||². Keep the finite-step square; it need not be negligible at these coefficients or at the large initial norm.

Also expand that square into onsite², mixed onsite–graph, and graph² subterms to expose cancellation without counting them twice. Report both views with their hierarchy. Synchronization preserves component magnitudes exactly in the ideal formula: it has ZERO intensity increment, even if it substantially changes chirality.

### C. Native area/chirality budget

Keep the five existing amplitude terms separately: `onsite_first`, `coupling_first`, `onsite_squared`, `mixed`, `coupling_squared`. Keep the two actual phase terms: `phase_existing_area`, `phase_symmetric_pair`. Preserve their signed components; do not drop finite-step terms, replace them with an infinitesimal law, or compute sine/cosine as matrix functions.

Use A_ij = x_i y_j − y_i x_j, d_ij=delta_j−delta_i and C=(A_23,A_31,A_12) in 1-based notation. Independently check the orientation/sign conventions against `readouts.py` and the source. The cube in normalized-pair phase evaluation is INSIDE the imaginary-part operation. At exact zero retain Arg0=0; do not divide by a zero modulus or repair a denominator.

S and A are both needed by the phase step. Do not call C, W or Gamma a closed dynamical state. W may be used to check the established linear attachment, but it must not replace raw C in the historical Z formula.

### D. Carry these budgets into the frozen displacement

For each saved pair calculate the exact finite-difference norm gain, not a first-order derivative approximation. Use the identity in the mathematical brief to assign each intensity term its contribution to the norm-dependent macro displacement. Pass the seven C contributions through the unchanged beta weighting and placement.

Keep model-to-data residual contributions explicitly, so the term vectors reconstruct the actual saved-state frozen displacement. Report vector sums, signed components and cancellation. Contribution norms are NOT additive percentages and must not be used as shares of a physical cause.

Separate the global first-sample freeze used here from the interval-native attribution at the previous scheduled setting in Z-02. Those are different after the first interval. The primary target is X*_(n+1)−X*_n at the SAME theta*=time*=0 for all intervals. No new schedule is needed.

### E. Explain the transverse movement and radial reversal

Independently check the projection perpendicular to the fixed macro direction. At the actual identity placement and theta*=0, the frozen y coordinate is beta*C_y; the norm gain has no y component. Trace that change through the seven area-budget terms, including cancellations.

For inward/outward accounting, use the exact signed squared-radius identity in the brief and keep its residual. In addition give a coarse three-part radius-square ledger: macro magnitude, chiral magnitude, and their cross term. This reveals whether the final outward step is explained by increased macro magnitude, a chiral change, changed alignment/cancellation, or a mixture. Do not assume a winner beforehand.

Give equal coverage to all four intervals, including the small middle changes. Explain which mathematical contributions support the large first shift and the last outward step. A small net displacement can reflect cancellation rather than inactivity. Do not infer acceleration, force, attraction, energy transfer, or an asymptotic equilibrium from these four spans. No new nearest-opening classifications or geometric reconstruction campaign is required.

## 8. Verification and return package

Require independent checks, not only the same implementation rearranged. Verify the intensity sum against the directly computed prestage intensity; the five-term A sum against direct prestage cross products/congruence; and the phase A prediction against an independent pair-product calculation or equivalent real 2D rotation algebra without constructing a new full complex output. Check the cofactor identity polynomially, without inverse-M assumptions at singularity.

Check the finite gain identity, the transverse projection, same-norm/changing-C and cancellation cases, norm preservation in the phase stage, the signed squared-radius sum, and zero/missing-direction handling. Clearly separate all synthetic fixtures from the five retained rows. A second precision/formula agreement is not an interval certificate. No minimum theatrical test count is required; name what each check establishes.

Return:

* `START_HERE.md`: at most one page; the actual explanation, important numbers, surprises, limits and whether any genuinely new issue remains.
* `REPORT.md`: concise source-grounded derivations and four-interval explanation; put bulk numbers in ledgers. State what is inherited and what is an elementary derived bookkeeping identity. No novelty, physical-field or energy-emission claim.
* `STATE_SNAPSHOTS.json`, `NATIVE_INTENSITY_BUDGET.json`, `NATIVE_CHIRAL_BUDGET.json`, `FROZEN_Z_SOURCE_BUDGET.json`, `RADIAL_TRANSVERSE_ACCOUNTING.json`: machine-readable signed terms, exact parameter tokens, working precision, scale/tolerance policies, actual indices and residuals. Combining closely related ledgers is acceptable with a schema index.
* Standalone source/checker, frozen plan, commands, tests, source/line crosswalk, before/after manifest, accounting of reconstruction counts and limitations.
* At most three simple, coordinate/data-derived figures. Prefer signed intensity terms, chiral transverse contributions, and radial balance. No generated illustration, new motion animation, fabricated intermediate state or energy beam. Axis labels must distinguish state intensity, placed squared radius and uncalibrated update index. Verify visibility and readable labels before packaging.
* A complete review ZIP and external receipt with actual SHA-256, bytes and verified member count; internally verify every payload member, avoid manifest self-reference, and include the exact unmodified selected input. Do not bundle environments, fonts, caches or unrelated files.

A portable check must operate on copies, never overwrite delivered immutable inputs or the original research. No rerun of Z-01/Z-02's full suites, producer audits, old interval certificates or the prior return search. Recompute only the reference endpoint quantities needed for the new budgets; compare them to the retained Z-02 ledgers.

## 9. Stop and review boundary

Finish when all four frozen transitions have a reproducible, source-consistent accounting, or when a clearly identified source/data problem prevents one. Return both agreement and failures without hiding either. If the answer is “several large terms cancel and no single source dominates,” report that; do not force a tidy mechanism.

This task does not claim physical core movement, transport through openings, gravity, magnetic fields, a cone/support law, a preferred number or a new paper. The fixed-support and two-arrangement ideas remain available for later comparison, neither confirmed nor rejected here. The golden-ratio wording was illustrative; literal observer constants retain their own definitions.

GPT reviews the mathematics and explains the finding before any further work order. The author has supplied enough geometric context for this task; no new axis, gap, pose or spin-speed decision is needed.
