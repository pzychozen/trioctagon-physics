# Start here — NCM-Z-03 v0.1

**Question:** Which already-defined native norm and chirality source terms explain the frozen Z displacements in the five saved states from NCM-Z-02?

Read `CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md`, then `SOURCE_ROUTE.md` and `MATHEMATICAL_BRIEF.md`. The explicit limits are also in `PREDECLARED_LIMITS.json`.

The SAME five states and four transitions are supplied. No further history search, trajectory, angle sweep or geometry interpretation is needed. The only additional source intake is reading the named existing local budget functions and Paper G definitions as text. Complete byte copies of those three sources are not included; their source route is explicit.

Unlike Z-02, this task authorizes isolated passive prestage, kick and source-budget reconstructions from each saved before-state. No reconstruction is chained, promoted to a saved sample, or used to replace the supplied after-state. Counts must distinguish this dynamics arithmetic from actual new-trajectory generation, which remains prohibited.

Use Command Prompt and `call conda activate torment`. Write in a fresh external `NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01` directory or next free suffix. Do not run Git, import project modules, edit the model, run earlier analyses, install packages, or publish.

## Packet contents

* Work order, mathematical brief and machine-readable limits.
* Unmodified original Z-02 review ZIP and its complete provenance/evidence.
* Unchanged selected history and essential reference ledgers, source text and admission records.
* GPT's separate Z-02 review and review evidence, explicitly secondary to the original report/source definitions.
* Input-copy provenance, preparation receipt and a SHA-256 payload manifest.

During preparation the archive/input hashes and member identities were verified. No native stage, source budget, new observer value, old checker, or new scientific trajectory was evaluated. The mathematical brief is proposed analysis for independent verification; the packet does not prejudge which term explains the observed displacement.

Return a one-page discovery summary, reproducible ledgers and tests, a concise mathematical report and up to three explanatory figures. Preserve cancellations, residuals and inconclusive results. No paper or further task is automatically authorized.

## Message to send with this packet

> Execute NCM-Z-03 v0.1 — Native-source accounting of frozen Z displacement. Use the same five retained states and recover the existing intensity/chirality budgets. Carry their signed contributions into the frozen readout and explain the four displacements, including the final outward step. Perform only the explicitly allowed passive stage/budget reconstructions; do not generate or extend a native trajectory. Use Command Prompt and the existing torment environment. No Git, model/application changes, old-study reruns or publication. Return the complete bounded review package.
