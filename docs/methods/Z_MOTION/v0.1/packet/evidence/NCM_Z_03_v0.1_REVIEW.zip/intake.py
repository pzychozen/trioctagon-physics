from pathlib import Path
import hashlib, json, zipfile, sys, platform, datetime
ROOT=Path(__file__).resolve().parent
DOWNLOAD=Path('C:/Users/Notandi/Downloads')
PACKET=DOWNLOAD/'NCM_Z_03_Codex_Packet_v0.1.zip'
ORDER=DOWNLOAD/'CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md'
def digest(b): return hashlib.sha256(b).hexdigest()
def write(name,x): (ROOT/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with zipfile.ZipFile(PACKET) as z:
    assert z.testzip() is None
    for i in z.infolist():
        p=ROOT/'packet'/i.filename
        assert p.resolve().is_relative_to((ROOT/'packet').resolve())
        if not i.is_dir():
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(i))
    print('\n'.join(z.namelist()))
write('INTAKE.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packet':{'path':str(PACKET),'bytes':PACKET.stat().st_size,'sha256':digest(PACKET.read_bytes())},'order':{'path':str(ORDER),'sha256':digest(ORDER.read_bytes())},'python':sys.executable,'version':sys.version,'platform':platform.platform()})
