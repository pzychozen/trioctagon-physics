"""NCM-Z-03 standalone passive accounting. No project imports or post-sync states.

Each pair starts from original saved strings. Reconstructed prestages and pair
products are diagnostics only. Never feed predictions to another calculation.
"""
from pathlib import Path
import json, hashlib, datetime, sys
import mpmath as mp

R=Path(__file__).resolve().parent
P=R/'packet/NCM_Z_03_Packet_v0.1'
CHECKS=[]
AMP=['onsite_first','coupling_first','onsite_squared','mixed','coupling_squared']
PHASE=['phase_existing_area','phase_symmetric_pair']
INT=['onsite','coupling','onsite_square','mixed_onsite_coupling','coupling_square']

def flat(x):
    if isinstance(x,mp.matrix):return list(x)
    if isinstance(x,(list,tuple)):return [a for v in x for a in flat(v)]
    return [x]
def check(name,residual,terms=(),tol='1e-65'):
    raw=max([abs(v) for v in flat(residual)]+[mp.mpf(0)])
    scale=max(mp.mpf(1),mp.fsum(abs(v) for v in flat(terms)))
    passed=mp.isfinite(raw) and raw<=mp.mpf(tol)*scale
    CHECKS.append({'name':name,'dps':mp.mp.dps,'max_abs_residual':mp.nstr(raw,mp.mp.dps),'scale':mp.nstr(scale,mp.mp.dps),'tolerance':tol,'passed':bool(passed)})
    return bool(passed)
def need(name,residual,terms=(),tol='1e-65'):
    assert check(name,residual,terms,tol),name
def dump(path,obj):
    (R/path).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def serial(x):
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,mp.matrix):return [[serial(x[i,j]) for j in range(x.cols)] for i in range(x.rows)] if x.cols!=1 else [serial(v) for v in x]
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    if isinstance(x,(str,int,bool)) or x is None:return x
    if isinstance(x,mp.mpc):return [mp.nstr(x.real,mp.mp.dps),mp.nstr(x.imag,mp.mp.dps)]
    return mp.nstr(x,mp.mp.dps)
def vec(x):return mp.matrix(x)
def mat3(fn):return mp.matrix([[fn(i,j) for j in range(3)] for i in range(3)])
def dot(a,b):return mp.fsum(x*y for x,y in zip(a,b))
def norm(a):return mp.sqrt(dot(a,a))
def cross(a,b):return vec([a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]])
def sa(z):
    x=vec([v.real for v in z]);y=vec([v.imag for v in z])
    return x*x.T+y*y.T,x*y.T-y*x.T,cross(x,y)
def cyc(A):return vec([A[1,2],A[2,0],A[0,1]])
def cofactor(M):
    def entry(i,j):
        rows=[k for k in range(3) if k!=i];cols=[k for k in range(3) if k!=j]
        return (-1)**(i+j)*(M[rows[0],cols[0]]*M[rows[1],cols[1]]-M[rows[0],cols[1]]*M[rows[1],cols[0]])
    return mat3(entry)
def exact_float(x):
    a,b=x.as_integer_ratio();return mp.mpf(a)/b
def settings():
    lv=exact_float(.618);lock=exact_float(.244);gamma=exact_float(.577)
    H=vec([mp.cos(3*lock),0,mp.cos(3*lock)])
    return lv,gamma,lock,H
def snapshot(row):
    z=[mp.mpc(mp.mpf(a),mp.mpf(b)) for a,b in row['omega']]
    S,A,C=sa(z);I=mp.fsum(v.real*v.real+v.imag*v.imag for v in z);kap=mp.sqrt(I)
    lv,gamma,lock,H=settings();K=lv*kap/(1+kap);macro=K*H;r=macro+C/2
    O=vec([0,mp.sqrt(3)/6,0]);X=O+r
    need(f'n{row["n"]} C orientation',C-cyc(A),C)
    return {'n':row['n'],'I':I,'kappa':kap,'S':S,'A':A,'C':C,'K':K,'H':H,'macro':macro,'centered_r':r,'placed_X':X,'radius':norm(r),'radius_squared':dot(r,r),'coarse':{'macro_magnitude':dot(macro,macro),'chiral_magnitude':dot(C,C)/4,'cross_alignment':dot(macro,C)}}

def kicks(w,strength):
    # Preserve source lambda=0 bypass, and Arg0 for exact complex zeros.
    if strength==0:return None,vec([0,0,0]),None
    phases=[mp.arg(v) if v!=0 else mp.mpf(0) for v in w]
    delta=vec([strength*mp.fsum(mp.sin(3*(phases[j]-phases[i])) for j in range(3) if j!=i) for i in range(3)])
    alternative=[]
    for i in range(3):
        terms=[]
        for j in range(3):
            if j==i:continue
            if w[i]==0 or w[j]==0:
                terms.append(mp.sin(3*(phases[j]-phases[i])))
            else:
                pair=mp.conj(w[i])*w[j]/(abs(w[i])*abs(w[j]))
                terms.append(mp.im(pair**3))
        alternative.append(strength*mp.fsum(terms))
    need('Arg0 kicks versus normalized pair cube (zero fallback)',delta-vec(alternative),[delta,alternative])
    return phases,delta,vec(alternative)

def budget(z,eps,g,strength,k,label):
    S,A,C=sa(z);s=vec([abs(v)**2 for v in z]);D=mp.diag([k[i]-s[i] for i in range(3)])
    L=mp.matrix([[-2,1,1],[1,-2,1],[1,1,-2]]);M=mp.eye(3)+eps*D+g*L
    u=eps*D*vec(z);v=g*L*vec(z);b=u+v;w=vec(z)+b
    St,At,Ct=sa(w)
    pair_sum=mp.fsum(abs(z[i]-z[j])**2 for i,j in [(0,1),(0,2),(1,2)])
    parent={'onsite':2*eps*mp.fsum(k[i]*s[i]-s[i]**2 for i in range(3)),'coupling':-2*g*pair_sum,'finite_increment_square':mp.fsum(abs(a)**2 for a in b)}
    expanded={'onsite':parent['onsite'],'coupling':parent['coupling'],'onsite_square':mp.fsum(abs(a)**2 for a in u),'mixed_onsite_coupling':2*mp.re(mp.fsum(mp.conj(a)*c for a,c in zip(u,v))),'coupling_square':mp.fsum(abs(a)**2 for a in v)}
    model_I=mp.fsum(parent.values());pre_I=mp.fsum(abs(a)**2 for a in w);before_I=mp.fsum(s)
    need(label+' intensity direct prestage',pre_I-before_I-model_I,list(parent.values()))
    need(label+' square hierarchy',parent['finite_increment_square']-mp.fsum(list(expanded.values())[2:]),list(expanded.values()))
    need(label+' onsite direct inner product',parent['onsite']-2*mp.re(mp.fsum(mp.conj(a)*c for a,c in zip(z,u))),parent['onsite'])
    need(label+' graph direct inner product',parent['coupling']-2*mp.re(mp.fsum(mp.conj(a)*c for a,c in zip(z,v))),parent['coupling'])
    terms={'onsite_first':eps*(D*A+A*D),'coupling_first':g*(L*A+A*L),'onsite_squared':eps**2*D*A*D,'mixed':eps*g*(D*A*L+L*A*D),'coupling_squared':g*g*L*A*L}
    amplitude_sum=sum(terms.values(),mp.zeros(3,3))
    need(label+' five terms versus direct cross products',A+amplitude_sum-At,list(terms.values()))
    need(label+' A congruence',M*A*M.T-At,[A,At])
    need(label+' S congruence',M*S*M.T-St,[S,St])
    need(label+' polynomial cofactor',cofactor(M)*C-Ct,[C,Ct])
    phases,delta,alternative=kicks(w,strength)
    d=mat3(lambda i,j:delta[j]-delta[i])
    terms['phase_existing_area']=mat3(lambda i,j:At[i,j]*(mp.cos(d[i,j])-1))
    terms['phase_symmetric_pair']=mat3(lambda i,j:St[i,j]*mp.sin(d[i,j]))
    predicted_A=A+sum(terms.values(),mp.zeros(3,3))
    # Only conjugate pair products are rotated; no evolved complex component is formed.
    pair_A=mat3(lambda i,j:mp.im(mp.conj(w[i])*w[j]*mp.mpc(mp.cos(d[i,j]),mp.sin(d[i,j]))))
    need(label+' phase prediction versus independently rotated pairs',predicted_A-pair_A,[At,St])
    phase_S=mat3(lambda i,j:St[i,j]*mp.cos(d[i,j])-At[i,j]*mp.sin(d[i,j]))
    need(label+' component magnitudes invariant in phase',[phase_S[i,i]-abs(w[i])**2 for i in range(3)],s)
    need(label+' pair norm invariant',[(St[i,j]*mp.cos(d[i,j])-At[i,j]*mp.sin(d[i,j]))**2+pair_A[i,j]**2-St[i,j]**2-At[i,j]**2 for i in range(3) for j in range(3)],[St,At])
    ct={name:cyc(t) for name,t in terms.items()}
    return {'prestage':{'onsite_increment':u,'graph_increment':v,'total_increment':b,'omega_tilde':w,'M':M,'S_tilde':St,'A_tilde':At,'phases_Arg0':phases,'delta_simultaneous':delta,'delta_pair_cube':alternative,'d_ij':d,'qualification':'reconstructed diagnostic, never a saved intermediate'},'intensity':{'parent':parent,'expanded_alternative':expanded,'prestage_I':pre_I,'model_delta_I':model_I,'phase_delta_I_exact':0,'direct_prestage_residual':pre_I-before_I-model_I},'chiral':{'A_terms':terms,'C_terms':ct,'predicted_C':cyc(predicted_A),'predicted_A':predicted_A,'direct_pair_A':pair_A,'congruence_residual':M*A*M.T-At,'pair_residual':predicted_A-pair_A}}

def gain(a,b,lv):return None if a+b==0 else lv/((a+b)*(1+a)*(1+b))
def project(v,H):return None if dot(H,H)==0 else v-H*(dot(H,v)/dot(H,H))
def cancellation(terms,total):
    amount=mp.fsum(abs(v) for v in terms)
    return {'sum_abs':amount,'net':total,'sum_abs_over_abs_net':None if total==0 else amount/abs(total),'sign_screen_resolved':bool(abs(total)>mp.mpf('1e-65')*max(1,amount))}

def account(a,b,raw,label):
    H=a['H'];lv,_,_,_=settings();q=gain(a['kappa'],b['kappa'],lv)
    assert q is not None
    di=b['I']-a['I'];dc=b['C']-a['C'];dr=b['centered_r']-a['centered_r'];rs=a['centered_r']+b['centered_r']
    ib=raw['intensity'];cb=raw['chiral']
    ri=di-ib['model_delta_I'];rc=dc-sum(cb['C_terms'].values(),mp.zeros(3,1))
    okI=check(label+' saved-after intensity',ri,[a['I'],b['I'],*ib['parent'].values()])
    okC=check(label+' saved-after chirality',rc,[a['C'],b['C'],*cb['C_terms'].values()])
    ib.update({'actual_delta_I':di,'saved_after_I':b['I'],'saved_after_residual_RI':ri,'model_to_data_passed':okI})
    cb.update({'actual_delta_C':dc,'saved_after_C':b['C'],'saved_after_residual_RC':rc,'model_to_data_passed':okC})
    if not(okI and okC):return {'status':'FAILED_TRANSITION_DO_NOT_ATTRIBUTE','intensity':ib,'chiral':cb}
    iv={name:H*(q*x) for name,x in ib['parent'].items()}
    expanded={name:H*(q*x) for name,x in ib['expanded_alternative'].items()}
    cv={name:x/2 for name,x in cb['C_terms'].items()}
    rv=H*(q*ri)+rc/2
    terms={**{'I/'+k:v for k,v in iv.items()},**{'C/'+k:v for k,v in cv.items()}}
    closure=dr-sum(terms.values(),mp.zeros(3,1))-rv
    need(label+' finite norm gain',(b['K']-a['K'])-q*di,[a['K'],b['K'],q*di])
    need(label+' frozen displacement closure',closure,[dr,*terms.values(),rv])
    need(label+' full transverse projection',project(dr,H)-project(dc,H)/2,[dr,dc])
    need(label+' centered y',dr[1]-dc[1]/2,[dr[1],dc[1]])
    need(label+' x-minus-z transverse',dr[0]-dr[2]-(dc[0]-dc[2])/2,[dr,dc])
    rad={k:dot(rs,v) for k,v in terms.items()};rad_res=dot(rs,rv);round_rad=dot(rs,closure)
    actual_rad=b['radius_squared']-a['radius_squared'];rad_closure=actual_rad-mp.fsum(rad.values())-rad_res-round_rad
    coarse={k:b['coarse'][k]-a['coarse'][k] for k in a['coarse']}
    need(label+' signed squared radius',rad_closure,[actual_rad,*rad.values(),rad_res,round_rad])
    need(label+' coarse squared radius',actual_rad-mp.fsum(coarse.values()),[actual_rad,*coarse.values()])
    denom=a['radius']+b['radius']
    need(label+' ordinary radius gain',b['radius']-a['radius']-actual_rad/denom,[a['radius'],b['radius']])
    return {'status':'SOURCE_CONSISTENT_NUMERICAL_ACCOUNTING','intensity':ib,'chiral':cb,'frozen':{'q_finite_gain':q,'actual_displacement':dr,'macro_displacement':H*(b['K']-a['K']),'chiral_displacement':dc/2,'intensity_parent_vectors':iv,'intensity_expansion_alternative_vectors':expanded,'chiral_vectors':cv,'model_to_data_residual_vector':rv,'readout_roundoff_residual':closure,'component_cancellation':[cancellation([v[j] for v in terms.values()],dr[j]) for j in range(3)],'sum_term_norms':mp.fsum(norm(v) for v in terms.values()),'net_displacement_norm':norm(dr)},'radial_transverse':{'actual_delta_radius_squared':actual_rad,'actual_delta_radius':b['radius']-a['radius'],'signed_radius_squared_terms':rad,'model_to_data_residual_contribution':rad_res,'readout_roundoff_contribution':round_rad,'radial_closure_residual':rad_closure,'coarse_endpoint_difference':coarse,'coarse_residual':actual_rad-mp.fsum(coarse.values()),'radial_cancellation':cancellation(list(rad.values()),actual_rad),'ordinary_radius_denominator':denom,'signed_radius_terms':{k:v/denom for k,v in rad.items()},'transverse_projection':project(dr,H),'chiral_transverse_projection':project(dc,H)/2,'delta_centered_y':dr[1],'y_terms':{k:v[1] for k,v in cv.items()},'y_model_to_data_residual':rc[1]/2,'y_cancellation':cancellation([v[1] for v in cv.values()],dr[1]),'delta_x_minus_z':dr[0]-dr[2]}}

def synthetic():
    import sympy as sp
    # Generic symbolic polynomial identity, including singular matrices.
    entries=sp.symbols('m0:9');M=sp.Matrix(3,3,entries);x=sp.Matrix(sp.symbols('x0:3'));y=sp.Matrix(sp.symbols('y0:3'))
    assert all(sp.expand(v)==0 for v in ((M*x).cross(M*y)-M.cofactor_matrix()*x.cross(y)))
    result={'symbolic_cofactor_polynomial':'three component polynomials identically zero; no inverse used','fixtures':[]}
    for dps in [80,120]:
        mp.mp.dps=dps
        z=[mp.mpc(1,2),mp.mpc(-2,1),mp.mpc(3,-1)]
        budget(z,mp.mpf(1)/10,mp.mpf(1)/5,mp.mpf(17)/100,[2,3,4],'synthetic generic')
        budget([mp.mpc(0)]*3,mp.mpf(1)/10,mp.mpf(1)/5,mp.mpf(17)/100,[2,3,4],'synthetic zero')
        phases,d,_=kicks([mp.mpc(0),mp.mpc(1),mp.j],mp.mpf(17)/100);assert phases[0]==0
        ph,d,alt=kicks([mp.mpc(0),mp.mpc(1,2),mp.mpc(-2,1)],mp.mpf(0));assert ph is None and alt is None and list(d)==[0,0,0]
        kicks([mp.mpc(1),mp.mpc(1,1),mp.mpc(2,-1)],mp.mpf(17)/100)
        Q=mp.diag([1,0,1]);xx=vec([1,2,3]);yy=vec([2,-1,1]);need('synthetic singular cofactor',cross(Q*xx,Q*yy)-cofactor(Q)*cross(xx,yy))
        lv,_,_,H=settings();assert gain(mp.mpf(0),mp.mpf(0),lv) is None
        a=mp.mpf(2);need('synthetic equal-norm finite gain',gain(a,a,lv)*0)
        a=mp.mpf(0);b=mp.mpf(3);need('synthetic zero/nonzero finite gain',lv*b/(1+b)-gain(a,b,lv)*(b*b-a*a))
        z1=[mp.mpc(1),mp.j,mp.mpc(0)];z2=[mp.mpc(1),-mp.j,mp.mpc(0)];C1=sa(z1)[2];C2=sa(z2)[2]
        need('synthetic same norm',mp.fsum(abs(v)**2 for v in z1)-mp.fsum(abs(v)**2 for v in z2));assert norm(C2-C1)>0
        K=mp.mpf(1)/3;C=-2*K*H;r=K*H+C/2;need('synthetic exact cancellation vector',r);assert norm(r)==0
        r1=vec([1,0,0]);r2=vec([0,1,0]);need('synthetic zero signed radial balance',dot(r2+r1,r2-r1));assert norm(r2-r1)>0
        assert project(vec([1,2,3]),vec([0,0,0])) is None
        result['fixtures'].append({'dps':dps,'fixture_count':13,'full_pair_budgets':2,'passed':True})
    return result

def compare_numeric(a,b,path=''):
    if isinstance(a,dict):
        for k in a:
            if k in b:compare_numeric(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        assert len(a)==len(b)
        for i,(x,y) in enumerate(zip(a,b)):compare_numeric(x,y,path+'/'+str(i))
    elif isinstance(a,str):
        try:x=mp.mpf(a);y=mp.mpf(b)
        except (ValueError,TypeError):assert a==b;return
        need('80/120 '+path,x-y,[x,y])
    else:assert a==b,(path,a,b)

def main():
    freeze=json.loads((R/'PLAN_FREEZE_RECEIPT.json').read_text())
    for name,digest in freeze['sha256'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
    assert not (R/'PRIMARY_EVALUATIONS.jsonl').exists(),'Refusing uncounted repeated primary evaluations'
    data=json.loads((P/'inputs/SELECTED_HISTORY.json').read_text());rows=data['observations'];assert [r['n'] for r in rows]==list(range(5))
    old=json.loads((P/'context/NCM_Z_02_OBSERVATIONS.json').read_text())
    fixtures=synthetic();dump('SYNTHETIC_CHECKS.json',fixtures)
    allruns={};started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    for dps in [80,120]:
        mp.mp.dps=dps;snap=[snapshot(row) for row in rows];pairs=[]
        for i in range(4):
            with (R/'PRIMARY_EVALUATIONS.jsonl').open('a',encoding='utf-8') as log:log.write(json.dumps({'before':i,'after':i+1,'dps':dps,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'prestage/kick/budget evaluation; independent saved before-state'})+'\n')
            z=[mp.mpc(mp.mpf(a),mp.mpf(b)) for a,b in rows[i]['omega']]
            raw=budget(z,mp.mpf(1)/10,mp.mpf(1)/5,mp.mpf(17)/100,[2,3,4],f'{i}->{i+1}')
            result=account(snap[i],snap[i+1],raw,f'{i}->{i+1}')
            pairs.append({'before':i,'after':i+1,'prestage':raw['prestage'],**result})
        for s,o in zip(snap,old['samples']):
            ref=o['frozen']['readout']
            for name,oldname in [('kappa','kappa'),('C','C'),('centered_r','centered'),('placed_X','X')]:
                actual=flat(s[name]);saved=flat(ref[oldname]);need(f'Z02 binary64 endpoint {s["n"]} {name}',[a-mp.mpf(b) for a,b in zip(actual,saved)],actual,'5e-12')
        allruns[str(dps)]=serial({'snapshots':snap,'pairs':pairs})
    mp.mp.dps=120;compare_numeric(allruns['80'],allruns['120'])
    policy={'task':'NCM-Z-03 v0.1','input_sha256':hashlib.sha256((P/'inputs/SELECTED_HISTORY.json').read_bytes()).hexdigest(),'actual_indices':[0,1,2,3,4],'native_exact':{'epsilon':'1/10','g':'1/5','lambda_phase':'17/100','k':['2','3','4']},'observer_binary64_literals':{str(x):{'hex':x.hex(),'ratio':list(x.as_integer_ratio())} for x in [.618,.577,.244]},'anchor':{'theta':'0','time':'0','alpha':'1','beta':'1/2','placement_scale':'1','placement_rotation':'0'},'precisions':[80,120],'screen':'abs residual <= 1e-65 * max(1,sum absolute compared terms); actual per-check scales retained','comparison_to_Z02_binary64':'5e-12 scaled; no primary binary64 budget evaluations','evidence_class':'NUMERICAL_CORROBORATION_ONLY','not_interval_certificate':True,'notation':'r=X-O; centered y=beta*C_y; absolute X_y=O_y+beta*C_y'}
    dump('NUMERIC_POLICY.json',policy)
    dump('STATE_SNAPSHOTS.json',{'policy':'NUMERIC_POLICY.json','runs':{p:run['snapshots'] for p,run in allruns.items()}})
    for filename,key in [('NATIVE_INTENSITY_BUDGET.json','intensity'),('NATIVE_CHIRAL_BUDGET.json','chiral'),('FROZEN_Z_SOURCE_BUDGET.json','frozen'),('RADIAL_TRANSVERSE_ACCOUNTING.json','radial_transverse')]:
        dump(filename,{'policy':'NUMERIC_POLICY.json','runs':{p:[{'before':q['before'],'after':q['after'],'status':q['status'],key:q.get(key)} for q in run['pairs']] for p,run in allruns.items()}})
    dump('PASSIVE_PRESTAGES.json',{'qualification':'Diagnostics only; no post-sync complex output constructed; no intermediate appended to history','runs':{p:[{'before':q['before'],'after':q['after'],'prestage':q['prestage']} for q in run['pairs']] for p,run in allruns.items()}})
    dump('CHECKS.json',{'count':len(CHECKS),'passed':sum(c['passed'] for c in CHECKS),'checks':CHECKS})
    dump('COUNTS.json',{'started_utc':started,'primary_pair_budget_evaluations':8,'primary_precisions':[80,120],'optional_binary64_pair_budgets':0,'synthetic_named_fixtures':13,'synthetic_evaluations_each':2,'synthetic_full_pair_budgets':4,'trajectory_advances':0,'new_admitted_states':0,'full_complex_postsync_outputs':0,'index_4_successor':0,'project_imports':0,'old_suite_or_producer_runs':0,'EMA_advances':0,'new_observer_schedules':0,'geometry_scans':0,'Git_commands':0})
    print(json.dumps({'checks':len(CHECKS),'passed':sum(c['passed'] for c in CHECKS),'primary_pair_budget_evaluations':8}))
    for p in allruns['120']['pairs']:
        print('INTERVAL',p['before'],p['after'],'STATUS',p['status'])
        if p['status'].startswith('SOURCE'):
            print('I', {k:float(v) for k,v in p['intensity']['parent'].items()},'RI',p['intensity']['saved_after_residual_RI'])
            print('R2 coarse', {k:float(v) for k,v in p['radial_transverse']['coarse_endpoint_difference'].items()})
            print('Y terms', {k:float(v) for k,v in p['radial_transverse']['y_terms'].items()})
            print('SIGNED R2',{k:float(v) for k,v in p['radial_transverse']['signed_radius_squared_terms'].items()})

if __name__=='__main__':main()
