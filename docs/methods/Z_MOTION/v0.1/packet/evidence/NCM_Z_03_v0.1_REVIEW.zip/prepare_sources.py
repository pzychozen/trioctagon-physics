from pathlib import Path
import json,hashlib,zipfile,datetime
R=Path(__file__).resolve().parent; P=R/'packet/NCM_Z_03_Packet_v0.1'; REPO=Path('C:/TORMENT/TRIOCTAGON_new/trioctagon-physics'); OLD=R.parent/'NATURAL_CORE_MOTION_Z_RETAINED_HISTORY_01'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def meta(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
entries=json.loads((P/'PACKET_MANIFEST.json').read_text())['entries']
for e in entries:
 b=(P/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
assert (P/'CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md').read_bytes()==Path('C:/Users/Notandi/Downloads/CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md').read_bytes()
with zipfile.ZipFile(P/'evidence/NCM_Z_02_v0.1_REVIEW.zip') as z:
 assert z.testzip() is None and len(z.namelist())==99 and len(set(z.namelist()))==99
 manifest=json.loads(z.read('OUTPUT_HASHES.json'));print('OLD MANIFEST SCHEMA',str(manifest)[:1100])
 dump('PRIOR_MANIFEST_READ.json',manifest)
 for name in ['accepted_sources/z.py','ENVIRONMENT.json','ADMISSION_AND_PLAN.json']:
  if name in z.namelist():
   p=R/'prior_reference'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 print('OLD NAMES', '\n'.join(z.namelist()))
sources=[];live=[Path('C:/Users/Notandi/Downloads/NCM_Z_03_Codex_Packet_v0.1.zip'),Path('C:/Users/Notandi/Downloads/CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md')]
for rel in ['kernel_physics/z_diagnostics.py','kernel_physics/axial_observables.py','papers/PAPER_G/v0.1.1/source/paper_g.tex','kernel_physics/dynamics.py','kernel_physics/readouts.py']:
 p=REPO/rel; b=p.read_bytes();dest=R/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);live.append(p)
 sources.append({**meta(p),'snapshot':str(dest.relative_to(R)),'git_blob_sha1_calculated_without_git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
for rel in ['inputs/SELECTED_HISTORY.json','OBSERVATIONS.json','ADMISSION_AND_PLAN.json','analyze.py','NCM_Z_02_v0.1_REVIEW.zip']:
 p=OLD/rel
 if p.exists(): live.append(p)
dump('SOURCES.json',sources);dump('PRESERVATION_BEFORE.json',[meta(p) for p in live])
dump('PACKET_VERIFICATION.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload_entries_verified':len(entries),'standalone_order_identical':True})
print('SOURCE IDENTITIES',json.dumps(sources,indent=2))
