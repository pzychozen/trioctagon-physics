from pathlib import Path
import json,hashlib,datetime,re
R=Path(__file__).resolve().parent
def load(n):return json.loads((R/n).read_text(encoding='utf-8'))
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def write(n,s):(R/n).write_text(s.strip()+'\n',encoding='utf-8')
def f(x):return f'{float(x):+.10g}'
def vv(x):return '('+', '.join(f(v) for v in x)+')'
def table(head,rows):return '| '+' | '.join(head)+' |\n| '+' | '.join(['---']*len(head))+' |\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)+'\n'
snap=load('STATE_SNAPSHOTS.json')['runs']['120'];ib=load('NATIVE_INTENSITY_BUDGET.json')['runs']['120'];cb=load('NATIVE_CHIRAL_BUDGET.json')['runs']['120'];fb=load('FROZEN_Z_SOURCE_BUDGET.json')['runs']['120'];rb=load('RADIAL_TRANSVERSE_ACCOUNTING.json')['runs']['120']
rootlink=R.as_posix()
def link(n,label=None):return f'[{label or n}]({rootlink}/{n})'
crosswalk=[
 ('Native prestage, Arg0 and lambda-zero bypass','sources/kernel_physics/dynamics.py',56,99),
 ('Intensity and finite square; observed_delta is prestage-only','sources/kernel_physics/z_diagnostics.py',219,287),
 ('S/A and cyclic extraction','sources/kernel_physics/axial_observables.py',158,178),
 ('Seven native area terms and reconstructed quantities','sources/kernel_physics/axial_observables.py',220,269),
 ('Independent canonical C orientation','sources/kernel_physics/readouts.py',7,17),
 ('Area sign and fixed W attachment','sources/papers/PAPER_G/v0.1.1/source/paper_g.tex',66,103),
 ('Congruence/cofactor and phase-pair budget','sources/papers/PAPER_G/v0.1.1/source/paper_g.tex',123,145),
 ('Frozen placement and inherited constants','packet/NCM_Z_03_Packet_v0.1/source_text/motion_observer.py.txt',20,36),
 ('Preset','packet/NCM_Z_03_Packet_v0.1/source_text/motion_observer.py.txt',84,101),
 ('Placement, envelope, H, K and Z','packet/NCM_Z_03_Packet_v0.1/source_text/motion_observer.py.txt',177,204),
 ('Historical exact-decimal coefficients and rounded serialization; read only','packet/NCM_Z_03_Packet_v0.1/source_text/historical_nominal_producer.py.txt',120,171),
]
# Retain the exact consulted source excerpts with stable line labels.
excerpts=[]
for subject,name,a,b in crosswalk:
 lines=(R/name).read_text(encoding='utf-8').splitlines()
 excerpts.append(subject+'\n'+name+'\n'+'\n'.join(f'{i}: {lines[i-1]}' for i in range(a,min(b,len(lines))+1)))
write('SOURCE_EXCERPTS.txt','\n\n'.join(excerpts))
write('SOURCE_CROSSWALK.md',table(['Definition','Snapshot','Lines'],[(s,link(p),f'{a}–{b}') for s,p,a,b in crosswalk])+'''\nAll copied project/producer source was read as text. None was imported or executed. The native and axial identities are inherited definitions; the finite-gain and radial composition below are elementary bookkeeping identities. No Paper G example coefficients were substituted. Local axial and Paper G blob digests agree with SOURCE_ROUTE; diagnostics had no recorded baseline digest, so only its actual local SHA-256 and matching definitions are claimed.\n''')

start='''# NCM-Z-03 v0.1 — What explains the frozen movement?

All four saved transitions agree numerically with the existing native intensity and chirality budgets. The same five states, indices 0–4, were used unchanged. Nothing was advanced or extended.

The frozen readout combines a norm-dependent vector along (1,0,1) with half the raw chirality vector. Their changes can reinforce in one coordinate and cancel in another.

* **0→1: strong inward shift.** Native intensity falls by 8.704703. Onsite and graph terms contribute −5.203523 and −10.257851; the finite increment square returns +6.756671. It cannot be ignored. The placed radius falls by 0.104109. Macro and chiral magnitudes both shrink, while their cross term offsets much of that decrease.
* **1→2: smaller inward shift.** Intensity falls by 0.0674034 and radius by 0.0172925. The x changes nearly cancel: macro −0.0133118 plus chiral +0.0141878 leaves +0.000876039. Movement is not uniformly small in every coordinate.
* **2→3: nearly balanced, still inward.** Intensity increases by 0.00754918, but radius decreases by 0.000590475. The positive macro-size contribution to squared radius is outweighed by chiral-size and cross-term decreases. Substantial native terms still oppose one another.
* **3→4: outward reversal.** Radius increases by 0.00780087. Its squared-radius balance is **+0.00977297 macro −0.00104437 chiral −0.00509118 cross = +0.00363742**. Macro growth wins this balance; the other two contributions oppose it. Height nevertheless decreases slightly, so “outward” does not mean “upward.”

The final transverse y shift is +0.0211527, entirely chiral at this freeze. The phase symmetric-pair term supplies +0.0144813 of that signed y sum while contributing negatively to the radial sum. A term has no single direction-independent role.

Eight passive pair-budget evaluations were made: four at 80 and four at 120 decimal digits. All 1,851 logged checks passed (many are scalar precision comparisons), plus 80 copy-only portable checks. Thirteen declared synthetic fixtures were checked at both precisions. The largest 120-digit saved-endpoint residual is 1.27×10⁻¹⁰⁰. These are numerical screens on rounded historical states, not interval certificates.

No source/data blocker remains within this window. Physical interpretation and behavior beyond these four spans remain unresolved. No force, energy transfer, equilibrium or motion law follows. No Git, producer, old-study suite, application/model change or publication occurred. The bounded work ends here for GPT/author review.
'''
write('START_HERE.md',start)
report='''# NCM-Z-03 v0.1 — Native-source accounting of frozen Z displacement

Author: Hilmir Frímann Halldórsson / pzychozen. GPT supplied the work order and proposed mathematical brief; Codex independently checked definitions, identities and numerical accounting. This is a bounded research review package, not a manuscript or publication action.

## Finding

Every admitted adjacent pair is source-consistent under the stipulated numerical screen. All four frozen displacements close with the established intensity and area contributions, explicit model-to-data residuals, and a separate readout-roundoff residual. Small middle displacement reflects both smaller absolute terms than the first span and substantial cancellation. Native intensity growth does not imply outward placed movement: 2→3 is an explicit counterexample in this window. The 3→4 outward change has a positive macro-size balance exceeding two negative chiral/cross contributions.

## Identity, source authority and arithmetic

The exact unmodified input is `packet/NCM_Z_03_Packet_v0.1/inputs/SELECTED_HISTORY.json`: 8,871 bytes, SHA-256 `a294a4b0bf181adaa2054aa52379c1832a7833e3faa7614d0785aecd709ea09c`. Actual indices are 0,1,2,3,4, without exclusions or an index-4 successor. The selected file matches the original Windows Z-02 file and its unchanged 3,759,247-byte archive (SHA-256 `a0e26a24ce7511498d207bfac4a78da7ed4fa02605f92eed7b4a1a999a218518`). All 25 new packet payload hashes and all 98 prior archive payload hashes were checked; the prior archive has 99 members including its manifest. No old script was run.

Local dynamics/readouts match the supplied accepted snapshots. Local axial_observables.py and Paper G match the packet's two retained Git blob identities, calculated as header-plus-byte SHA-1 without any Git command. z_diagnostics.py has no baseline blob identity in the packet; its actual local SHA-256 is bound and its relevant definitions agree with the proposed formulas. Source authority is the read definitions, not an assumed checkout HEAD. All required originals were available; no fallback or new history search was needed. See SOURCE_CROSSWALK.md, SOURCE_EXCERPTS.txt, SOURCES.json and INPUT_VERIFICATION.json.

Native coefficients are exact rationals ε=1/10, g=1/5, λ_phase=17/100, k=(2,3,4). This is the constructed historical nominal example, distinct from the earlier two-state history and coherence-paper parameters. The historical producer used 120 working decimal digits and saved up to 100 significant digits. Its original radical entrance was not regenerated; enclosure flags were neither used as new certificates nor re-proved. Source identity does not authenticate the old producer.

Observer constants 0.618, 0.577 and 0.244 are exact lifts of the application binary64 values; hexadecimal encodings and integer ratios are retained. No golden-ratio substitution is made. α=1, β=1/2, μ=1, ψ=0, θ*=t*=0; E*=1. Pi/radicals/trigonometry use high precision. This is the first-sample freeze for every interval. It differs from Z-02's interval-native term at the previous scheduled setting after 0→1. No schedule is reconstructed here.

PLAN.json and the computation/checker source hashes were frozen at 2026-11-01T05:31:00.475390+00:00, before primary contributions. No post-freeze science/code correction or threshold change was needed. Primary arithmetic was 80 and 120 decimal digits; there were no binary64 shadow budgets. The residual screen is 10⁻⁶⁵ times max(1, sum of absolute contributing/compared scalar terms); each check stores its actual scale and raw residual. Existing Z-02 binary64 endpoint comparisons use the separately declared 5×10⁻¹² screen. Results remain NUMERICAL_CORROBORATION_ONLY.

## Inherited native identities

Write Ω=x+iy, s_i=|Ω_i|², D=diag(k−s), and L with diagonal −2 and off-diagonal 1. The simultaneous prestage uses u=εDΩ, v=gLΩ, Ω̃=Ω+u+v=MΩ, M=Id+εD+gL. These diagnostic intermediates are reconstructed, not stored observations. No sequential onsite/graph evolution is implied.

Expanding ||Ω+u+v||² proves the exact intensity identity

    ΔI_model = 2ε Σ(k_i s_i − s_i²) − 2g Σ_(i<j)|Ω_i−Ω_j|² + ||u+v||².
    ||u+v||² = ||u||² + 2 Re(u†v) + ||v||².

The three terms are onsite, coupling and finite_increment_square (the source API calls the last remainder). The five-term expansion is an alternative hierarchy, not five additional terms. Phase synchronization preserves each prestage modulus exactly, so its ideal intensity increment is zero. The source API's observed_delta compares its reconstructed prestage to its before-state; this study separately compares the saved after-state through R_I=ΔI_saved−ΔI_model.

For S=xxᵀ+yyᵀ and A=xyᵀ−yxᵀ, C=(A₂₃,A₃₁,A₁₂)=x×y. Thus ΩΩ†=S−iA, whereas the conjugate-pair matrix is S+iA. Direct expansion gives S̃=MSMᵀ, Ã=MAMᵀ, C̃=cof(M)C, and

    ΔA_amplitude = ε(DA+AD) + g(LA+AL) + ε²DAD
                   + εg(DAL+LAD) + g²LAL.

These are onsite_first, coupling_first, onsite_squared, mixed, coupling_squared. The cofactor statement follows from the bilinear cross-product/minor expansion, a polynomial identity valid at singular M. A generic symbolic three-component expansion was identically zero without using an inverse.

The simultaneous kicks are δ_i=λ_phase Σ_(j≠i)sin(3(Arg0 Ω̃_j−Arg0 Ω̃_i)); Arg0(0)=0, and λ_phase=0 bypasses phase extraction. For nonzero pairs, Im[((conj(Ω̃_i)Ω̃_j)/(|Ω̃_i||Ω̃_j|))³] agrees with the harmonic sine. The cube is inside Im. Zero-component tests use the source Arg0 convention, not division by zero.

With d_ij=δ_j−δ_i, conjugate-pair rotation gives A⁺_ij=Ã_ij cos d_ij+S̃_ij sin d_ij. The two increments are phase_existing_area=Ã_ij(cos d_ij−1) and phase_symmetric_pair=S̃_ij sin d_ij, entrywise. The seven C triples use the same cyclic extraction. R_C=ΔC_saved−Σc_t is retained componentwise. Each phase term depends on the actual mixed prestage, so these are algebraic source terms, not independent causal interventions. Both S and A are required; C, W and Γ are not claimed to be closed dynamical states. Raw C remains in Z; W is not substituted.

## Derived finite readout and radial bookkeeping

Let K(a)=λ_vp a/(1+a), H=cos(3 lock)(1,0,1), and r=X*−O=KH+C/2 with O=(0,√3/6,0). Subtracting two rational gains and using b²−a²=(b−a)(b+a) proves

    K(b)−K(a)=q ΔI,   q=λ_vp/[(a+b)(1+a)(1+b)],   a+b>0.

This is a finite divided difference, not a derivative. If a=b>0, the identity still holds; if both are zero, ΔK=0 and q is left undefined. For each parent intensity term B_l use d_l=HqB_l; each area triple contributes d_t=c_t/2. Add d_res=HqR_I+R_C/2 and the recorded arithmetic closure residual to reconstruct the actual saved displacement. The ledgers also retain the alternative intensity-child vectors without double counting them.

For nonzero H, Q=Id−HHᵀ/||H||² annihilates the macro direction, so QΔr=QΔC/2. In particular Δr_y=ΔC_y/2 and Δ(r_x−r_z)=Δ(C_x−C_z)/2. The work-order phrase about the frozen y coordinate means **centered** r_y; the absolute coordinate is X_y=√3/6+C_y/2. This notation clarification was frozen in the plan. At zero H the projector is undefined, not an invented axis.

The signed radial contribution of a displacement term is (r_j+r_i)·d_a, because ||r_j||²−||r_i||²=(r_j+r_i)·(r_j−r_i). The sum includes model-to-data and arithmetic residual contributions. Division by ||r_j||+||r_i|| gives an additive ordinary-radius ledger when the denominator is nonzero. Independently,

    ||r||² = K²||H||² + ||C||²/4 + K H·C.

Endpoint differences yield macro_magnitude, chiral_magnitude and cross_alignment. The last is a cross term involving both magnitude and alignment; it is not a pure angle measurement. These finite-gain, projection and radial compositions are elementary consequences of established definitions, not claims of new fundamental identities, forces or physical energies. Norms of contribution vectors are not additive percentages.

## Endpoints and all four displacement balances

The following tables round only for readability; JSON retains both precisions and residuals. Radius and displacement use placed width units, not native intensity units or a calibrated physical time.

'''
report+=table(['n','I','κ','C','Frozen radius'],[(s['n'],f(s['I']),f(s['kappa']),vv(s['C']),f(s['radius'])) for s in snap])+'\n'
report+=table(['Span','Δr=(Δx,Δy,Δz)','||Δr||','Δradius'],[(f'{i}→{i+1}',vv(fb[i]['frozen']['actual_displacement']),f(fb[i]['frozen']['net_displacement_norm']),f(rb[i]['radial_transverse']['actual_delta_radius'])) for i in range(4)])+'\n'
report+=table(['Span','Onsite ΔI','Graph ΔI','Increment square','Actual ΔI'],[(f'{i}→{i+1}',*[f(v) for v in ib[i]['intensity']['parent'].values()],f(ib[i]['intensity']['actual_delta_I'])) for i in range(4)])+'\n'
report+=table(['Span','Macro-size Δr²','Chiral-size Δr²','Cross-term Δr²','Total Δr²'],[(f'{i}→{i+1}',*[f(v) for v in rb[i]['radial_transverse']['coarse_endpoint_difference'].values()],f(rb[i]['radial_transverse']['actual_delta_radius_squared'])) for i in range(4)])+'\n'
report+='''### 0→1: large intensity decrease, partial spatial cancellation

The graph contribution −10.2578509 and onsite contribution −5.2035230 reinforce the native intensity decrease. The positive square +6.7566707 is material: its children are +0.9967298 onsite², +2.6825856 mixed and +3.0773553 graph². Dropping it would predict a negative final intensity from I₀≈9. The actual final intensity is about 0.2952968.

The macro displacement is (−0.1829186,0,−0.1829186); the chiral displacement is (+0.2893798,+0.1244792,+0.0703416). They oppose in x and z: the net x is positive, z negative. The y increase is wholly chiral. In its seven-term y ledger, coupling_first +0.2040638 and mixed +0.0495824 oppose onsite_first −0.0645448 and coupling_squared −0.0614369; the remaining three terms make smaller signed adjustments. The two phase terms together slightly reduce the y increase.

For squared radius, falling macro and chiral magnitudes give −0.1853406 and −0.1187050, but the cross term rises +0.2417510. Much of the decrease is canceled. In the source-resolved radial ledger the three intensity pathways sum to about −0.1258317; the seven chiral pathways sum to about +0.0635372. This alternate split has a different meaning from the three coarse endpoint terms and must not be mixed with them.

### 1→2: smaller sources, important coordinate cancellation

Onsite +0.1691187 and the square +0.0364389 oppose graph −0.2729609, leaving ΔI=−0.0674034. Inside the square, +0.0263927 onsite² and +0.0818883 graph² are opposed by mixed −0.0718421. The finite square remains relevant.

Macro x and z each decrease 0.0133118. Chiral x increases 0.0141878, almost canceling the macro x change; chiral z decreases 0.0068096, reinforcing the downward displacement. Chiral y increases 0.0159642: coupling_first +0.0325362 and mixed +0.0102830 oppose onsite_first −0.0260113 and two negative squared terms; the two phase terms add approximately +0.00579605. The raw signed components are retained rather than ranked by vector norm.

Macro-size squared radius falls 0.00826369. Chiral-size decrease −0.00171820 and cross increase +0.00173409 almost cancel each other. The net Δradius is −0.0172925. Sources are smaller than in 0→1, but small net x especially is a cancellation result.

### 2→3: increasing native norm, decreasing placed radius

Onsite +0.1468163 and graph −0.1646281 nearly balance. The +0.0253610 square makes ΔI positive, +0.00754918; ignoring this finite term would reverse the predicted intensity sign. Its children are +0.0248938, −0.0489212 and +0.0493884.

Macro x and z each rise 0.00164299. Chiral x falls 0.000161463 and chiral z falls 0.00322774. Thus x rises while z falls, despite a larger native norm. Chiral y rises only 0.00316930 after coupling_first +0.0182892, onsite_first −0.0169507, mixed +0.00577696, two negative square terms and phase terms +0.000858491 and −0.00206638 are combined. This is not inactivity.

Macro-size squared radius rises +0.000981589, but chiral-size −0.000315415 and cross −0.000937245 outweigh it. Δr²=−0.000271072 and Δradius=−0.000590475. The source-resolved radial sum has sum of absolute terms about 223.9 times its net magnitude: a strong cancellation measure, not percentages or an error bound. The sign is stable at both precisions and far above the declared screen.

### 3→4: outward radius, slightly decreasing height

Onsite +0.1589076 exceeds graph −0.1007577; the square adds +0.0237968, giving ΔI=+0.0819467. Its +0.0276978 onsite² and +0.0302273 graph² oppose mixed −0.0341282. The norm-dependent macro x/z rise +0.0154716 each.

The chiral displacement is (−0.000670044,+0.0211527,−0.0166755), so the net is (+0.0148016,+0.0211527,−0.00120391). The radius grows although height falls. In the y budget, coupling_first +0.0164316 and phase_symmetric_pair +0.0144813 are substantial positive terms; onsite_first −0.0151054 opposes them. The other four terms complete the +0.0211527 total. Both amplitude and phase contributions matter; phase still changes intensity by exactly zero in the ideal formula.

The coarse squared-radius balance is +0.00977297−0.00104437−0.00509118=+0.00363742. Macro growth exceeds the chiral-size and cross-term decreases. In the alternative source-resolved radial ledger, intensity pathways total about +0.0101601 and chiral pathways about −0.00652271. In particular phase_symmetric_pair gives +0.0144813 in y but −0.00478717 in radial balance. A contribution cannot be called simply “outward” from one positive coordinate. This explains the final reversal without an added force or clock.

## Verification, uncertainty and stopping boundary

Intensity sums were checked against directly computed prestage norms and independently evaluated inner products. Five-term area sums were checked against direct real cross products, matrix congruence and minor/cofactor evaluation. Phase predictions were checked using rotated conjugate pair products, without constructing a full post-sync complex vector. Pair magnitudes and phase diagonal intensities were checked independently. Arg0 sine kicks agreed with normalized-pair cubes where defined. The finite norm gain, full transverse projector, y and x−z identities, fine radial sum and coarse radial sum were checked for every pair.

There were exactly eight primary prestage/kick/budget evaluations: four at 80 digits and the same four at 120 digits. These are native-stage algebra evaluations and are reported as such. Each began afresh from an original saved row. Zero trajectory advances, full complex post-sync outputs, index-4 successors or new admitted states occurred. No project modules, old suites, producers, app workers or EMA were executed. Thirteen predeclared synthetic fixtures were evaluated at both precisions, with two full synthetic budgets per precision (four total, separate from the primary count). The other fixtures test zero/undefined cases, singularity, nontrivial phase cubing, cancellation and equal-norm/changing-C or equal-radius/nonzero-displacement cases. A generic cofactor polynomial proof was also checked symbolically.

All 1,851 logged assertions passed; many are individual scalar 80/120 comparisons, not independent experiments. Maximum absolute saved-after residual is 1.05422×10⁻⁸¹ at 80 digits and 1.27026×10⁻¹⁰⁰ at 120 digits. The 80-digit evaluation cannot resolve residuals at the finer stored-rounding scale. Maximum raw discrepancy across all compared 80/120 numerical fields is 2.65813×10⁻⁷⁷ (including cancellation ratios); all pass their explicit scaled screen. No historical transition failed, so none was excluded from attribution. Residual signs near rounding scale have no scientific interpretation. Material signs and comparisons discussed above are resolved; exact structural zero y macro and phase intensity increments follow algebraically, not from rounded zeros.

An independent portable checker used copies only, recomputed endpoint observables through conjugate pairs and verified ledger closure. All 80 checks passed. It did not rerun stage/kick budgets, so the primary count remains eight. This checks portability of the delivered data/accounting with the existing interpreter, not cross-platform byte reproducibility or an independently authenticated producer. The exact commands and environment are included.

The three figures use only existing ledger coordinates and signed terms. All four intervals are visible, with independent panel scales explicitly labeled. Intensity, placed squared radius and uncalibrated update spans are distinguished. All three original PNGs were visually inspected for clipping, signs and labels. No geometry scan, new opening classification, animation, invented intermediate state or generated illustration was used.

These are numerical corroborations on rounded nominal states, not interval enclosures, an exact trajectory proof or independent physical causes. The history is deliberately constructed and only four spans long. It supports no inference of acceleration, attraction, energy transfer, asymptotic equilibrium or general behavior beyond this window. Physical core motion, transport through openings, fields and fixed-support/two-arrangement interpretations remain unestablished. No new issue blocks this bounded source accounting; interpretation is left for GPT and the author before any further work order. No publication or successor investigation is started.

## Package index and preservation

STATE_SNAPSHOTS.json contains I, κ, S, A, C, K, centered/absolute frozen placement and radius at all five endpoints. NATIVE_INTENSITY_BUDGET.json contains parent/child terms and saved-after residuals. NATIVE_CHIRAL_BUDGET.json retains each signed A matrix and C vector, pair/congruence checks and saved-after residuals. FROZEN_Z_SOURCE_BUDGET.json carries all terms and residuals into the actual displacement. RADIAL_TRANSVERSE_ACCOUNTING.json contains fine radial contributions, the independent three-part coarse split and transverse accounting. PASSIVE_PRESTAGES.json is explicitly diagnostic, not a history extension. All use NUMERIC_POLICY.json and run keys 80/120.

The archive includes the exact input, packet context/evidence, actual source snapshots, standalone analysis and copy-only checker, frozen plan, commands, environment, checks, three figures and before/after hashes. Scratch copies and matplotlib caches are excluded. Preservation is a bounded audit of the 12 actual original input/source files listed in PRESERVATION_BEFORE.json, with results in PRESERVATION_AFTER.json; it is not a whole-checkout assertion. The external REVIEW_RECEIPT.json records the final ZIP bytes, SHA-256 and member verification. Every payload member is hashed; the internal manifest excludes itself.
'''
write('REPORT.md',report)
fig=load('FIGURE_RECORD.json');fig['visual_QA']='All three PNGs inspected via image viewer; visible labels and signed bars, no clipped content; no numerical or layout repair required.';dump('FIGURE_RECORD.json',fig)
write('COMMANDS.txt',r'''
NCM-Z-03 command record. All shell execution used cmd.exe, login=false.
Interpreter activation for each Python invocation:
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
Interpreter reported C:\Users\Notandi\miniconda3\envs\torment\python.exe, Python 3.11.15.
Initial cwd: C:\TORMENT\TRIOCTAGON_new
Output cwd for all new Python calculations and subsequent relative commands:
C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01

Initial read command, failed before reading (CMD wrapper quote syntax):
type "C:\Users\Notandi\Downloads\CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md"
Retry succeeded:
type C:\Users\Notandi\Downloads\CODEX_NCM_Z_03_NATIVE_SOURCE_ACCOUNTING_WORK_ORDER_v0.1.md
where conda
rg --files -g AGENTS.md -g "!node_modules" -g "!env" -g "!venv" .
dir /b C:\TORMENT\TRIOCTAGON_new
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment && python -V
if exist C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01 (echo EXISTS) else (mkdir C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01 && echo CREATED)
for %p in (C:\AGENTS.md C:\TORMENT\AGENTS.md C:\TORMENT\TRIOCTAGON_new\AGENTS.md C:\TORMENT\TRIOCTAGON_new\research\AGENTS.md) do @if exist %p type %p

Every new Python invocation below used this exact prefix:
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment && python -X utf8 -I -B

C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01\intake.py
prepare_sources.py
read_and_verify.py
freeze_plan.py
mkdir logs
analyze.py > logs\analysis.txt 2>&1
type logs\analysis.txt
postprocess.py > logs\postprocess.txt 2>&1
type logs\postprocess.txt
build_report.py
package_review.py

The report builder was run twice: the second pass narrowed source crosswalk ranges
to complete definitions. No numerical script, budget, fixture or figure was rerun.
Additional read-only review commands:
rg -n "def.|ORIGIN|SQRT3" sources\kernel_physics\axial_observables.py sources\kernel_physics\z_diagnostics.py packet\NCM_Z_03_Packet_v0.1\source_text\motion_observer.py.txt
type ENVIRONMENT.json
rg -n def sources\kernel_physics\axial_observables.py sources\kernel_physics\z_diagnostics.py
type SOURCE_EXCERPTS.txt

postprocess.py launched the copy-only checker with subprocess, using the same activated sys.executable:
python -X utf8 -I -B C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_SOURCE_ACCOUNTING_01\scratch\portable_01\portable_check.py
cwd: the scratch\portable_01 directory. No shell/producer or previous suite invoked.

Read-only type calls also displayed these exact new-root files:
packet\NCM_Z_03_Packet_v0.1\SOURCE_ROUTE.md
packet\NCM_Z_03_Packet_v0.1\MATHEMATICAL_BRIEF.md
packet\NCM_Z_03_Packet_v0.1\PREDECLARED_LIMITS.json
packet\NCM_Z_03_Packet_v0.1\PACKET_MANIFEST.json
sources\kernel_physics\axial_observables.py
sources\kernel_physics\z_diagnostics.py
sources\kernel_physics\dynamics.py
packet\NCM_Z_03_Packet_v0.1\inputs\SELECTED_HISTORY.json
packet\NCM_Z_03_Packet_v0.1\context\NCM_Z_02_GPT_REVIEW.md
Read-only search:
rg -n -A 32 -B 2 "def._linear_place|def._placed|def.reference_geometry" packet\NCM_Z_03_Packet_v0.1\source_text\motion_observer.py.txt

New text/scripts were written with apply_patch into the new output directory.
The image viewer inspected figures\01_intensity.png, 02_transverse.png, 03_radial_balance.png.
No PowerShell execution, Git, dependency installation, runtime acquisition, environment configuration change, old-study suite or producer execution occurred.
''')
write('REPLAY_NOTES.md','''# Safe bounded verification of this delivery

Use an extracted **copy** and the existing torment interpreter. To repeat only the portable verification, copy portable_check.py, the five numerical ledgers, NUMERIC_POLICY.json, and the original SELECTED_HISTORY.json into a fresh directory; copy PORTABLE_COPY_HASHES.json there as COPY_HASHES.json. Execute `python -X utf8 -I -B portable_check.py` from that directory after CMD conda activation. It writes only PORTABLE_RESULTS.json there and evaluates no native stages. The supplied copy hashes bind the exact files.

analyze.py is the inspectable source for the already-completed eight primary budget evaluations. It refuses to run where PRIMARY_EVALUATIONS.jsonl already exists. This task did not run it again in a portable copy, because that would spend additional primary budget evaluations. Do not remove the guard or rerun budget calculations automatically. No prior archive script is an execution dependency. No environments, fonts or caches are required from the archive.
''')
print(json.dumps({'start_here_words':len(start.split()),'report_words':len(report.split()),'figures_visually_verified':3,'postfreeze_corrections':0}))
