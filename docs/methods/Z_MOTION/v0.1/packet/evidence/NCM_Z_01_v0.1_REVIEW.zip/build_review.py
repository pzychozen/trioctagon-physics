"""Format the completed finite-data calculations; no new scientific execution."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
def read(p): return json.loads((ROOT/p).read_text(encoding="utf-8"))
def write(p,text): (ROOT/p).write_text(text,encoding="utf-8")
def f(v): return f"{v:.9f}"
def vec(v): return "("+", ".join(f(x) for x in v)+")"
def table(headers,rows):
    return "\n".join(["| "+" | ".join(headers)+" |","| "+" | ".join("---" for _ in headers)+" |"]+["| "+" | ".join(map(str,row))+" |" for row in rows])+"\n"
o=read("OBSERVATIONS.json"); g=read("GAP_COMPARISON.json"); tests=read("checks_results.json")
source=read("SOURCE_MANIFEST.before.json")
roles={
    "observer":"75–84 seals; 137–204 arithmetic, clock and placement; 207–238 geometry; 241–276 snapshots/telescope; 305–373 selected-record observation; 380–419 display phase; 426–446 export",
    "appguide":"Natural Core Motion scope and retained app-observation provenance; no scientific replay",
    "motion":"328–386 local phase/ambient Gram obstruction; 442–483 ordered telescope; correspondence definitions",
    "central":"181–224 constants, complete PLUS/MINUS mesh; 331–373 arcs and finite notches; 438–501 native/staged/placement separation",
    "host":"235–242 octagon vertices; 283–285 three folded panel maps; original host radius derived from these vertices",
    "z":"staged observation definitions; 226–265 cubic innovation/current-memory EMA (no execution)",
    "readouts":"raw chiral cross product, read as text",
    "dynamics":"native accepted update signatures/definition, read as text only; never evaluated",
    "paperE":"staged versus EMA provenance and named literal coefficients",
    "attachment":"1–72 spatial observable nonuniqueness; 78–104 adopted fixed-face decoder; no geometry feedback",
    "records":"142–149 current inert canonical JSON and deterministic digest rules; whole-file bytes differ from historical producer, explicitly not authenticated"
}
snap=ROOT/"source_snapshots"; snap.mkdir(exist_ok=True)
for key,item in source.items():
    raw=Path(item["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==item["sha256"]
    name=key+Path(item["path"]).suffix
    (snap/name).write_bytes(raw)
    item["snapshot"]="source_snapshots/"+name
    item["consulted_passages_and_role"]=roles[key]
(ROOT/"SOURCE_MANIFEST.json").write_text(json.dumps({"scope":"Eleven actual consulted source files; byte snapshots retained. Historical revision is not assumed to be current HEAD.","files":source,"inputs":read("INPUT_MANIFEST.before.json"),"preservation":"PRESERVATION.json","line_numbered_read_copies":"source_reads/","passage_read_trace":"SOURCE_READS.jsonl"},indent=2),encoding="utf-8")

lead="""# NCM-Z-01 v0.1 — discovery and review

The existing Z observation changes between the two saved states even with its observer frozen. In this example it moves closer to the fixed center. The scheduled observer also changes the point's apparent direction: its nearest upper opening changes from G+0 to G+1, while the frozen observer remains nearest G+0. That distinction comes from the existing formulas, without animating the shell.

All scheduled and frozen points remain inside the original close sphere and above the center. None is on any of the six central opening boundaries or finite host notch triangles. None of the outward rays through these points hits a finite notch triangle. These are position/direction comparisons, not evidence of passage or energy leaving an opening.

The useful surprise is that a change in the observer can change which opening appears closest. Also, the saved common-phase display probe rotates each face arrow in its own fixed tangent plane while leaving frozen staged Z unchanged, to rounding scale. Z alone cannot recover all the motion visible in those arrows.

Only updates 0 and 1 were retained: one displacement, no continuous path, turn between displacements, speed, period or flow. This is a useful reconciliation of existing definitions, with two elementary exact corollaries; no new physical mechanism or novelty claim.

- [Full report and six-opening tables](REPORT.md)
- [Top view](figures/01_top.png) and [opposite side views](figures/02_side.png)
- [Observed-state ledger](OBSERVATIONS.json), [all finite geometry comparisons](GAP_COMPARISON.json)
- [Standalone calculations](checks.py), [test results](checks_results.json), [actual calculation log](logs/checks.txt)
- [Source identities](SOURCE_MANIFEST.json), [integrity](INTEGRITY.json), [bounded preservation](PRESERVATION.json)

"""
lead+=f"Validation: {tests['tests_run']} assertions passed; all 17 listed source/input files unchanged. Command Prompt and the existing torment environment were used offline. No Git, native/EMA updates, application/kernel changes or publication.\n\n"
lead+="One possible successor question for review only: in an independently admitted record containing at least three saved states, does a change of nearest-opening identity persist when the observer is frozen? No such record was sought or analyzed here.\n"
write("START_HERE.md",lead)

report=r"""# NCM-Z-01 v0.1 — existing Z against fixed geometry

## Finding and scope

For the two retained native states, the existing placed Z point changes under a frozen observer. Its distance from the center decreases. Scheduled changes of the observer angle and envelope additionally change the point, including its nearest-opening label. This supports a finite, conditional observation statement, not a stronger material-core motion or transport interpretation.

The fixed-support conception is preserved: the shell, six opening arcs and close original sphere are reference geometry. No support, cone axis, rigid body or gap has been mechanically moved. The old moving-cone choreography and average-arrow gap scan are not used. The exported literal 0.618 is retained as a coefficient, not replaced with an exact golden-ratio constant or a controller.

## Input admission and source route

Primary data came from the named Windows export; the packet convenience copy is byte-identical. The outer export, nested observation and nested display probe content seals pass. The parent file named by the Windows closeout was found at C:\TORMENT\trioctagon_motion_validation_20261029_01\test-suite\fixtures\axial_old_run.json. Its bytes and canonical JSON hash both equal the recorded parent identity; its deterministic digest, actual indices and hexadecimal native values match. This is the parent of the same two samples, not a second experiment. No additional records were nominated.

Recorded content identities:

"""
report+=table(["Object","SHA-256"],[
    ["Supplied packet ZIP","ae0473e599397e284a448511f30b1156676c8687c603406f6ae3ef901f6d4784"],
    ["Retained export (27,068 bytes)","071f6f7dc74128d638b0e96e33897b1366b2f8bcb98ca741c11fe0af5ed0e1e7"],
    ["Outer content seal",read("inputs/retained.motion.json")["content_sha256"]],
    ["Observation content seal",read("inputs/retained.motion.json")["observation"]["content_sha256"]],
    ["Probe content seal",read("inputs/retained.motion.json")["phase_probe"]["content_sha256"]],
    ["Parent canonical/file hash",o["source"]["canonical_json_sha256"]],
    ["Parent deterministic digest",o["source"]["deterministic_sha256"]]])
report+="""
Integrity is not producer authentication or scientific replay certification. The earlier Windows validation reports Core loading; this investigation executes neither Core validation nor a producer. The observation source hash matches the current motion_observer.py, and the consulted native dynamics, readouts and z_manifold bytes match the parent module claims.

The current _records.py has hash 31ddf7ee819d2f58a6399c1405b2a236a371b3f2daa561b9aed8162ecebb702b, different from the historical parent's aa82d39cfc92a9d8f58ffd87342186ddf67134c4590f41e475327f0396bb5785. The initial gate incorrectly demanded whole-file equality for that additional current serialization helper. It stopped before movement calculations; the check was corrected to distinguish the historical producer from the current checkout, as the order requires. Both digests independently reproduce under the read canonicalization rule. No actual data seal, state, observer formula or parent-reference mismatch was waived. The failed overconstraint and correction are retained in logs/initial_gate_overconstraint.json and INTEGRITY.json.

The ZIP manifest and standalone/packaged order equality pass. Both named Windows/fixed-gap background files match their packet copies. GPT's review is retained as background, not mathematical authority. Exact input bytes, snapshots, hashes and source roles are in SOURCE_MANIFEST.json and INPUT_VERIFICATION.json.

## Typed map, prepared before analysis

"""
report+=(ROOT/"TYPED_CORRESPONDENCE.md").read_text(encoding="utf-8").split("\n",1)[1]
report+=r"""
## Reproduction and numeric meaning

Write Omega=x+i y, kappa=norm(Omega), C=x cross y. For each actual saved index n:

\[
q_n=(q_0+n q_{\rm step})\bmod N,\quad
\theta_n=2\pi q_n/N,\quad t_n=t_0+n\,dt.
\]

\[
K=\lambda_{\rm vp}\frac{\kappa}{1+\kappa},\quad E=e^{-\gamma t},\quad
H_\theta=\cos[3(\theta-\ell)](\cos\theta,\sin\theta,1),\quad
M=KEH_\theta,\quad Z=\alpha M+\beta C,\quad X=O+\mu R_\psi Z.
\]

The exported settings are N=12, q0=0, q_step=1, dt=0.1, time0=0, lambda_vp=0.618, gamma=0.577, lock_angle=0.244 radians, alpha=1, beta=0.5, mu=1, psi=0. The frozen observer has theta=time=0. The face-arrow display scale 0.5335783750799324 does not scale X.

The standalone script reads states as data and reproduces the application order: math.hypot for kappa, explicit cross products, K=lambda*(kappa/(1+kappa)), E and H followed by M=(K*E)H, then alpha M + beta C and placement. Binary64 values and hexadecimal identities are retained. Separate 80-decimal arithmetic checks evaluate the real formulas at those exact binary64 input values, not imagined exact decimal initial values. The kernel's checked arithmetic can associate products differently; its retained staged results are compared, not recalculated by executing it.

Test tolerance is 2e-13 times max(1,magnitudes). Geometry comparisons and ties use 1e-12 width units. These are numerical tolerances, not statistical error bars or formal interval certification. Coordinates and values printed below are rounded; JSON retains binary64 precision. Recomputed application values match the exported fields exactly for the fields tested. Real-formula and parent comparisons differ only at rounding scale.

"""
numeric=[t["detail"]["max_abs_residual"] for t in tests["tests"] if isinstance(t.get("detail"),dict) and "max_abs_residual" in t["detail"]]
report+=f"Largest absolute residual among all scalar/vector reproduction and identity comparisons: {max(numeric):.17g}. The ordered telescope residual is {vec(o['attribution']['residual'])} at displayed precision; its maximum absolute component is {max(map(abs,o['attribution']['residual'])):.17g}.\n\n"
report+=table(["Actual n","Omega (Re, Im), three channels","kappa","C"],[[s["native_update_index"],"; ".join(vec(v) for v in s["derived"]["omega"]),f(s["derived"]["kappa"]),vec(s["derived"]["C"])] for s in o["samples"]])
report+="\nScheduled and frozen readouts are separate evaluations:\n\n"
report+=table(["Point","q / angle / time","M","beta C","Z = X−O (real formula)"],[
    [p["label"],(str(o["samples"][p["native_update_index"]]["derived"]["clock"]["sector"])+" / "+("0°" if p["native_update_index"]==0 else "30°")+" / "+str(o["samples"][p["native_update_index"]]["derived"]["clock"]["time"])) if p["mode"]=="scheduled" else "0 / 0° / 0",
     vec(o["samples"][p["native_update_index"]]["derived"][p["mode"]]["macro"]),
     vec(o["samples"][p["native_update_index"]]["derived"][p["mode"]]["beta_C"]),
     vec(o["samples"][p["native_update_index"]]["derived"][p["mode"]]["Z"])] for p in o["points"]])
report+="\nWorld coordinates add O=(0,0.28867513459481287,0). Subtracting this binary64 center from a stored world point may introduce a final rounding unit relative to Z. The reported spatial ledger uses that explicit X−O calculation.\n\n"
report+=table(["Point","World X","radius","horizontal radius","height","azimuth","elevation"],[
    [p["label"],vec(p["world"]),f(p["measurements"]["radius"]),f(p["measurements"]["horizontal_radius"]),f(p["measurements"]["centered_height"]),f(p["measurements"]["azimuth_degrees"])+"°",f(p["measurements"]["elevation_degrees"])+"°"] for p in o["points"]])
report+=r"""
All directions in these retained point evaluations are defined. Zero-vector and axial-azimuth cases are tested separately, with null values rather than arbitrary directions. The exact original enclosing radius is sqrt(13/12−sqrt(2)/2), approximately 0.6133730937584284; the direct binary64 expression gives 0.6133730937584283. The difference is one rounding unit. The smallest inside margin here is 0.294585266109, far above any tolerance. This is the sphere enclosing the original folded host, not an extended-line sphere or physical wall. It follows independently from the published folded vertices: corner-tip radius squared is 1/3+h²=13/12−sqrt(2)/2 and the remaining vertex radii are no greater. Convex panel faces therefore lie within the same sphere. No classification of a material “core interior” is inferred.

## The ordered native → envelope → clock telescope

Let subscripts 0 and 1 indicate the two retained endpoint states/settings. With L=mu R_psi, the exact real identity is

\[
\Delta X = D_{\rm native}+D_{\rm envelope}+D_{\rm clock},
\]
\[
D_{\rm native}=L[\alpha E_0(K_1-K_0)H_0+\beta(C_1-C_0)],
\quad D_{\rm envelope}=L[\alpha K_1(E_1-E_0)H_0],
\quad D_{\rm clock}=L[\alpha K_1E_1(H_1-H_0)].
\]

Insert X(Omega1,theta0,t0), then X(Omega1,theta0,t1) between the endpoints. Cancellation proves the identity. This is the implemented evaluation order; a different ordering reallocates mixed changes. Its labels are not physical forces or an order-independent causal partition. The retained states are indexed as a native update pair; this study does not independently certify Omega1=F(Omega0) by replay.

"""
report+=table(["Stage","native state index","observer angle (radians)","envelope time","world point"],[[i,v["state_index"],f(v["theta"]),f(v["time"]),vec(v["point"])] for i,v in enumerate(o["attribution"]["intermediates"])])
report+="\n"
report+=table(["Contribution","vector displacement","norm (not additive)"],[[key,vec(o["attribution"][key]),f(o["attribution"]["component_norms"][key])] for key in ("native","envelope","clock","total")])
report+="""
The implementation forms residual = total − [native + (envelope + clock)]. Maximum residual is 1.0408340855860843e-17. Separately subtracting the rounded intermediate points reproduces the same components within rounding. Component norms are not percentages and do not sum to the total norm.

## Controlled comparisons with retained values

"""
report+=table(["Comparison","What changes","radius change","angle between centered position vectors"],[[c["name"],c["meaning"],f(c["radius_change"]),f(c["centered_direction_difference_degrees"])+"°"] for c in o["controls"]])
report+="""
These angles compare position vectors from O. They are not a turn between two successive displacement vectors. At fixed state/angle/envelope the observation is identical. The changed native state moves frozen Z. Envelope change alone changes both radius and direction because beta C remains present. Clock change alone changes both as well. No term was disabled and no coefficient was varied.

The saved 0.731-radian common-phase probe is reproduced as a display-copy operation only. Kappa and C remain invariant in exact real arithmetic; the observed maximum C discrepancy is 6.94e-18. Frozen and scheduled placed points reproduce unchanged at binary64 precision in this example. Face vectors change, with maximum pairwise ambient Gram changes 0.14809856321107384 and 0.03982136766457467 for the two states. That change rules out a single common rigid ambient rotation relating these particular decoded triples.

EMA is separate. Its source uses J=Im(Omega1 conjugate(Omega2) Omega3), normalized innovation J/(1+abs(J)), and m_new=(1−0.01)m+0.01*innovation; literal 0.01 is used. Under a common phase, the complex cubic product gets a factor exp(i chi), so J can change even when C and kappa do not. This is a formula observation only; no EMA state or trace was advanced or merged into the staged ledger.

## Six finite central opening boundaries

All coordinates here are centered at O and have host width one. Let s=sqrt(2)−1, d=1−sqrt(2)/2, r=sqrt(3)/6, a=d/2, h=s/2, H0=1/2; e_i=(cos alpha_i,sin alpha_i) with alpha_i=−pi/2+i*pi/3. Put J(x,y)=(-y,x), A_tau=I−(tau/r)J,
T_i=(a e_i,h), B_i=(a A_tau e_i,−h), U_k=(r e_(2k),H0), L_k=(r A_tau e_(2k),−H0).

The upper G+k is U_k—T_(2k+1)—U_(k+1); lower G−k is L_k—B_(2k+1)—L_(k+1). Each comprises two finite segments. Their union has no supplied filled aperture, centroid or aperture normal. MINUS is reflection of the entire PLUS geometry and face list by diag(−1,1,1), with the fixed host retained. It is not just a change of sign of tau.

For segment [A,B], u=clamp(((p−A)·(B−A))/norm(B−A)²,0,1), nearest=A+u(B−A). Compare both segments and keep all ties within 1e-12. Degenerate segments are explicitly handled by the script; none occurs in these references. Segment 0 goes from tip k to the middle ring point; segment 1 goes from the middle point to tip k+1. A two-segment tie at the shared endpoint is one nearest spatial point, not two.

Primary PLUS tau=0: all six distances, in width units. S0 and F0 coincide in 3D.

"""
primary=g["references"][0]
report+=table(["Arc","Level / bisector azimuth","S0=F0 distance","S1 distance","F1 distance"],[
    [arc["label"],arc["level"]+" / "+f(arc["bisector_azimuth_degrees"])+"°",f(primary["points"][0]["arcs"][i]["distance"]),f(primary["points"][2]["arcs"][i]["distance"]),f(primary["points"][3]["arcs"][i]["distance"])]
    for i,arc in enumerate(primary["geometry"]["arcs"])])
report+="\nFull nearest segment/point, all segment parameters, ties and projected distances are retained in GAP_COMPARISON.json. The nearest results are:\n\n"
nearrows=[]
for point in primary["points"]:
    near=[v for v in point["arcs"] if v["label"] in point["nearest_arc_labels"]][0]
    ss=near["segments"][near["nearest_segments_zero_based"][0]]
    nearrows.append([point["point"],", ".join(point["nearest_arc_labels"]),",".join(map(str,near["nearest_segments_zero_based"])),vec(ss["nearest_point"]),f(near["distance"]),f(near["projected_top_distance"])])
report+=table(["Point","Nearest arc","Segment(s)","Nearest 3D point","3D distance","top projected distance"],nearrows)
report+="""
Every 3D distance is positive. Thus none of these points lies on a central boundary arc. No statement of aperture passage follows: the aperture interior is not supplied. At fixed native state 1, the clock/envelope setting distinguishes F1 nearest G+0 from S1 nearest G+1. Even a nearest-label change is just an endpoint classification, not a traced crossing.

## Finite host notch patches, treated separately

For g_k=e_(2k+1), j_k=Jg_k and sigma=±1, the accepted measurement triangle is

N_(k,sigma)(lambda,zeta)=(2r−sqrt(3)d lambda/2)g_k + zeta j_k + sigma(h+d lambda)e_z,

with 0≤lambda≤1 and abs(zeta)≤d lambda/2. Its plane is g_k·(x,y)+sigma sqrt(3)w/2 = c0=2r+sqrt(3)h/2. Plane membership alone is insufficient. The script tests the plane and barycentric coordinates (1−lambda,lambda/2−zeta/d,lambda/2+zeta/d).

For the outward ray t p, t≥0, a nonparallel carrier hit occurs at t=c0/(n·p); only positive t with finite-domain membership is a notch hit. A zero p has no direction; a parallel ray from O has no hit because O is off the plane. Neither ray incidence nor point membership is a trajectory statement.

"""
report+=table(["Patch","S0=F0 plane distance","S1 plane distance","F1 plane distance","Point membership / outward-ray finite hit"],[
    [patch["label"],f(g["host_patch_comparisons"][0]["patches"][i]["point_membership"]["plane_distance"]),f(g["host_patch_comparisons"][2]["patches"][i]["point_membership"]["plane_distance"]),f(g["host_patch_comparisons"][3]["patches"][i]["point_membership"]["plane_distance"]),"none / none for all four labels"]
    for i,patch in enumerate(g["host_patches"])])
report+="\nRay diagnostics (a positive carrier-plane intersection can still miss the triangle):\n\n"
rays=[]
for case in g["host_patch_comparisons"]:
    if case["point"]=="F0": continue
    for p in case["patches"]:
        ray=p["outward_ray"]; m=ray.get("membership")
        rays.append([case["point"],p["label"],f(ray["parameter"]) if "parameter" in ray else "undefined",f(m["lambda"]) if m else "—",f(m["zeta"]) if m else "—",ray["reason"]])
report+=table(["Point","Patch","ray parameter t","lambda","zeta","Result"],rays)
report+="""
All 24 point/patch combinations reject point membership; all 24 ray/patch combinations reject a finite hit. Synthetic tests verify positive finite hits at each patch center and rejection of plane points outside each finite triangle. They are geometry tests, not additional native observations.

## Static shape controls and view parity

Exactly three geometries were compared, using the same four labeled points: PLUS tau=0, PLUS tau=h and MINUS tau=h. Tau is a static shape parameter. No connections between cases are drawn as motion. PLUS upper arcs are unchanged by tau, while lower arcs change; MINUS reflects the full mesh. The host patches and placement remain fixed.

"""
report+=table(["Reference","Point","nearest arc","distance"],[
    [ref["reference"],p["point"],", ".join(p["nearest_arc_labels"]),f(p["nearest_arc_distance"])] for ref in g["references"] for p in ref["points"] if p["point"]!="F0"])
report+="""
The nearest points remain on upper arcs in every case. MINUS swaps geometric upper label G+0 with G+2 under reflection; this is a label correspondence, not measured movement. Every lower comparison remains in the JSON even though no lower arc wins the minimum.

![Top projection](figures/01_top.png)

Top projections of corresponding upper/lower arcs coincide at tau=0 despite their different 3D heights. Source azimuths are −30°, 90°, −150°. The projected marker may look close to an arc while its 3D separation is appreciable. The top view never tests 3D passage.

![Opposite side projections](figures/02_side.png)

Opposite cameras retain all upper/lower, near/far geometry; the camera changes no 3D distance or incidence. The colored broken boundaries are distinct from pale filled finite measurement triangles. Gray host edges and the dotted original sphere are passive references. There are no sample connectors or invented energy beams. PNGs were visually inspected as files, not through the Windows candidate application.

## Two exact corollaries, without a novelty claim

**1. Static point measurements cannot identify common phase.** Fix observer settings, placement and any of these static references. Write c=cos chi, s=sin chi. Common phase sends x to cx−sy and y to sx+cy, so

(cx−sy) cross (sx+cy) = (c²+s²) x cross y = C,

and norm(exp(i chi)Omega)=kappa. Hence M, Z and X are identical. Every deterministic measurement of that same X against the fixed geometry—including sphere distance, six arc distances, patch membership and directed-ray incidence—is consequently identical. Nevertheless D_i(exp(i chi)Omega_i)=cos chi D_i(Omega_i)+sin chi n_i cross D_i(Omega_i), so nonzero face vectors rotate in their own fixed planes. Therefore those point/geometry measurements cannot recover common phase or all changes of the decoded arrows. This extends the already established invariance to these measurements; it asserts no native temporal evolution or global phase quotient of F.

**2. Envelope-only change can alter the full Z direction.** Fix Omega and theta; put A=alpha K and b=beta. Then Z(E)=A E H+b C. Direct expansion gives

Z(E1) cross Z(E2) = A b (E1−E2) (H cross C).

If A b (E1−E2)≠0 and H cross C≠0, the two full vectors are nonparallel and nonzero, hence their centered placed directions differ for the fixed nonzero isotropic scale/rotation. The retained state-1 comparison satisfies this: direction changes by about 0.222623° even though only the envelope changes. This would disappear from a macro-only calculation; no chiral term was removed here. Parallel/zero degeneracies are not covered by the nondegenerate conclusion.

These are elementary consequences of accepted definitions, useful for interpretation. No new foundational theorem, motion law or independently validated physical mechanism is claimed.

## Limits, verdict and stop

There is one retained displacement. A second displacement and a turn between displacements require at least a third admitted stored state. A continuous path would additionally require a specified interpolation or continuous dynamics; even three points do not supply it. Physical velocity requires a time calibration and positional interpretation. Flux additionally requires a relevant transported quantity and a defined surface/transport law. None is supplied or added here.

The existing Z supports a stronger accounting of what the display means, but no stronger claim of material core motion, emitted energy, an orbit or circulating substance. Both stored observations are above the center in this particular fixture; this is not evidence of a persistent upper-side preference. The frozen displacement confirms a native-state contribution to the readout, while the schedule changes geometric appearance. No further investigation is run.

One narrowly justified successor question for author/GPT review only: in an independently admitted record with at least three saved states, does a nearest-opening change persist under the frozen observer? No new record search, simulation or permission for that successor is implied.

## Verification and reproducibility

"""
report+=f"{tests['tests_run']} assertions passed across the ten predeclared check categories. They are tests, not {tests['tests_run']} theorems. All 17 bounded source/input hashes are unchanged. A separate external portable copy passed the same {tests['tests_run']} assertions and reproduced OBSERVATIONS.json and GAP_COMPARISON.json byte-for-byte; this is a reproducibility check of this new script, not another experiment. No whole-checkout audit or Windows application graphical validation is claimed. No Git commands, native/EMA execution, previous checker reruns, installation, external downloads, model/app/kernel edits or publication occurred.\n\n"
report+=r"""Run from Command Prompt in the existing environment:

~~~bat
call conda activate torment
cd /d C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_FIXED_REFERENCE_01
python -X utf8 -I -B checks.py
~~~

On a separate review machine with the same already-available libraries, extract the ZIP and use checks.py --portable. This checks packaged source/input snapshots instead of asserting preservation of the original Windows paths. Running the script regenerates derived files and can change platform-dependent figure bytes; use the delivered hashes to inspect the original package before rerunning. No package installation is part of this work.

Source passage crosswalk (exact bytes and absolute original paths are in SOURCE_MANIFEST.json):

"""
report+=table(["Source copy","Consulted role/passages"],[[f"[{key}]({item['snapshot']})",roles[key]] for key,item in source.items()])
write("REPORT.md",report)
print("Formatted START_HERE.md, REPORT.md and SOURCE_MANIFEST.json from completed calculations.")
print("Report bytes:",len(report.encode("utf-8")))
