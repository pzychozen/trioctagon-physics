"""Package the completed review with per-member hashes; no scientific rerun."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8"))
def write(name,value): (ROOT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
tests=read("checks_results.json"); portable=read("PORTABILITY_VERIFICATION.json")
assert tests["all_passed"] and portable["all_passed"] and all(portable["derived_json_byte_identity"].values())
pres=read("PRESERVATION.json")
for item in pres["files"]:
    assert sha(Path(item["path"]).read_bytes())==item["sha256"],item["path"]
write("FINAL_PRESERVATION.json",{"utc":datetime.now(timezone.utc).isoformat(),"files_checked":len(pres["files"]),"all_unchanged":True,"scope":"The same 17 listed sources/inputs, checked again at packaging; not a whole-checkout audit","reference":"PRESERVATION.json"})
closeout=f"""NCM-Z-01 v0.1 — CLOSED, BOUNDED DESCRIPTIVE RESULT

The accepted observation was studied at actual saved native indices 0 and 1.
Native-state change moves frozen staged Z. Scheduled observer changes also affect
direction and which upper arc is nearest. All four labeled placements are above
the center and inside the original close sphere. None belongs to a central
opening boundary or finite host notch triangle, and no outward ray hits a finite
notch triangle. Distances do not establish passage, emission or energy flow.

Two useful elementary exact corollaries were recorded: static Z measurements
cannot identify common phase; envelope-only change can alter full Z direction.
These reconcile existing definitions. No meaningful new foundational theorem or
physical motion mechanism is claimed. This was not a search or paper-writing task.
The fixed-support and stationary-reference interpretation was preserved.

Validation:
{tests['tests_run']} assertions in the final standalone calculation passed.
{portable['tests_run']} assertions in the separate portable-copy check passed.
Both derived numerical JSON files matched byte-for-byte across the copies.
Outer/nested observation seals, parent byte/canonical identity, deterministic
digest, source-observer identity and native state/index linkage passed.
Integrity is not producer authentication or scientific replay certification.
Initial current/historical _records.py overconstraint and its correction are
explicitly retained in INTEGRITY.json and logs; no data mismatch was waived.

The 17 consulted source/input files were hashed before/after and again at
packaging, unchanged. This is a bounded list, not a whole-checkout audit.
Both PNG figures were visually inspected as files; no Windows application GUI
review was performed. All six arcs, both levels and opposite side views remain.

Execution: Command Prompt, existing torment Python {tests['python'].split()[0]},
offline. Native updates 0; EMA updates 0; Git commands 0.
No native producer or prior checker executed. No environment installation,
download, kernel/application/model edits, fitted constants, new law or publication.
All task writes stayed inside this fresh external research root.

Portable review:
NCM_Z_01_v0.1_REVIEW.zip
OUTPUT_HASHES.json lists every payload member except itself; the ZIP also
contains that manifest. REVIEW_RECEIPT.json is external to the ZIP and records
the final ZIP hash, manifest hash, member count and verification results.
Scratch portable copy and process-local matplotlib font cache are excluded.
No further investigation was started. See START_HERE.md and REPORT.md.
"""
(ROOT/"CLOSEOUT.txt").write_text(closeout,encoding="utf-8")
zip_path=ROOT/"NCM_Z_01_v0.1_REVIEW.zip"
receipt_path=ROOT/"REVIEW_RECEIPT.json"
assert not zip_path.exists() and not receipt_path.exists(),"Refuse to replace an existing review archive"
excluded={"OUTPUT_HASHES.json",zip_path.name,receipt_path.name}
files=sorted(p for p in ROOT.rglob("*") if p.is_file() and p.relative_to(ROOT).parts[0] not in ("scratch","mplconfig") and p.relative_to(ROOT).as_posix() not in excluded and p.name!="package_run.txt")
entries=[{"path":p.relative_to(ROOT).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in files]
write("OUTPUT_HASHES.json",{"algorithm":"SHA-256","entries":entries,"excluded_from_own_hash_list":["OUTPUT_HASHES.json","NCM_Z_01_v0.1_REVIEW.zip","REVIEW_RECEIPT.json","scratch/","mplconfig/","logs/package_run.txt"],"scope":"All delivered payload files, including frozen inputs and consulted source snapshots; no self-hash."})
files.append(ROOT/"OUTPUT_HASHES.json")
with zipfile.ZipFile(zip_path,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files: z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(names))==len(files)
    assert all(not n.startswith(("/","\\")) and ".." not in Path(n).parts for n in names)
    assert set(names)=={e["path"] for e in entries}|{"OUTPUT_HASHES.json"}
    for e in entries:
        raw=z.read(e["path"])
        assert len(raw)==e["bytes"] and sha(raw)==e["sha256"],e["path"]
        assert raw==(ROOT/e["path"]).read_bytes(),e["path"]
    manifest_bytes=z.read("OUTPUT_HASHES.json")
    assert manifest_bytes==(ROOT/"OUTPUT_HASHES.json").read_bytes()
receipt={"study":"NCM-Z-01 v0.1","utc":datetime.now(timezone.utc).isoformat(),"archive":str(zip_path),"archive_bytes":zip_path.stat().st_size,"archive_sha256":sha(zip_path.read_bytes()),"archive_members":len(files),"payload_members_individually_sha256_verified":len(entries),"manifest_member_verified":True,"manifest_sha256":sha(manifest_bytes),"crc_all_passed":True,"unique_safe_member_paths":True,"all_members_match_delivered_files":True,"final_calculation_assertions_passed":tests["tests_run"],"portable_calculation_assertions_passed":portable["tests_run"],"portable_numerical_json_byte_matches":2,"protected_original_files_unchanged":len(pres["files"]),"native_steps":0,"ema_updates":0,"git_commands":0,"publication":False}
write("REVIEW_RECEIPT.json",receipt)
print(json.dumps(receipt,indent=2))
