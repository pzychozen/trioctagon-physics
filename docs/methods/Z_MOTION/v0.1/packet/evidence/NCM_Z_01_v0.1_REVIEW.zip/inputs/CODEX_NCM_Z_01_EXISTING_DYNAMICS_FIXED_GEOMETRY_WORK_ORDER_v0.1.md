# CODEX WORK ORDER — NCM-Z-01 v0.1
## Existing Z dynamics against the stationary Tri-Octagon central geometry

**31 October 2026 · Author-approved next investigation · Mathematical evidence only**

### 0. Scientific purpose and controlling correction

The research team (author, GPT, Codex) has approved a **bounded, source-grounded examination of the Z observations and actual native updates that already exist**. We are **not** authorizing a new motion model. The question is:

> **For existing retained native samples, where does the already-defined placed Z point lie relative to the accepted stationary center, close original enclosing sphere, and three upper/three lower central opening boundaries; how does it change between real stored update indices; and which part of each displacement is attributable to native-state change rather than observer scheduling or envelope change?**

This order is the next step after NCM-FIXED-GAP-01. Its geometric report establishes that a centered common rotation can carry openings together under compatible support constraints; that upper/lower relative offset is preserved by a whole-body rigid turn; and that apparent near-180° top projections can differ sharply from three-dimensional edge angles. These are **static geometric results**, not a motion engine.

**Author intent to preserve:** The two-arrangement / fixed-180°-support / close-sphere geometric picture is a scientific lead. The cones were explanatory proxies; their previously prescribed moving-axis choreography was **not** a faithful reconstruction of the author's fixed-support conception. The ratio/“golden controller” language in that sketch was illustrative, **not** a requirement for a controller in this study. The tight central toroid is parked. The surrounding octagon geometry serves as a reference rather than something we must mechanically animate. No author response is required before commencing this bounded task.

**Separation of objects is mandatory**:

1. Native state \(\Omega\in\mathbb C^3\) at actual saved update index: evolves under the accepted nonlinear recurrence \(F\).
2. Face-local decoded vectors \(D_i(\Omega_i)\): a faithful representation on **fixed** face tangent planes, not particle positions.
3. Chiral/readout values \(C=\Re\Omega\times\Im\Omega\), staged macro \(M\), and \(Z=\alpha M+\beta C\): derived observations, not a force, flux, or independent dynamical variable.
4. Declared spatial placement \(X=O+\mu_{\rm place}R_\psi Z\): an observation point at specified observer settings; it is **not** a material core trajectory.
5. Fixed original folded shell and separately declared refined central surface with **six broken opening boundary arcs**; also distinct **finite host notch measurement patches**.
6. Original close-fitting **enclosing sphere** of the original folded shell, not the larger extended-line sphere or a physical confining wall.

**Prohibited shortcuts:** Do not substitute the previous average-arrow \(P\) or its gap-phase scan for the Z observation. Do not turn the observer's 12 sectors / 30° step into native spatial rotations. Do not silently treat a displayed line connecting two sampled points as a continuous path, emission, passage, energy flow, magnetic/gravitational field, physical speed, or new orbit. Do not assume a gap has a filled aperture interior, normal, centroid, valve, or hinge unless an accepted source explicitly defines it.

### 1. Authority, environment, input paths, and source route

**Operator platform:** Windows 11, Command Prompt; existing `torment` Conda environment (Python 3.11.15). Use `call conda activate torment` and `python -X utf8 -I -B` for permitted standalone scripts. Do not install, upgrade, download, elevate privileges or change environment settings. Offline work only.

**Authoritative checkout (READ ONLY for this task):**

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`

**Existing retained observation (first source candidate):**

`C:\TORMENT\trioctagon_motion_validation_20261029_01\exports\interactive.motion.json`

A byte-identical **convenience copy** is included in this task packet as `INPUTS/interactive.motion.json` (27,068 bytes; SHA-256 `071f6f7dc74128d638b0e96e33897b1366b2f8bcb98ca741c11fe0af5ed0e1e7`). The same-data `natural-motion.motion.json` is **not** a second independent experiment. The detached observation has stored parent identity, readout definitions, two native sample states and update indices **0 and 1**, a saved phase probe at 0.731 radians, and its own content seals. **Export integrity and ordinary Core structural validation are not producer authentication or scientific replay certification.** Check seals/lineage before calculations; fail closed on mismatches. Use the included exact copy only with explicit provenance if the Windows primary path is absent.

Existing Windows validation (background, DO NOT reexecute):

`C:\TORMENT\trioctagon_motion_validation_20261029_01\WINDOWS_CLOSEOUT.txt` — packet copy `REFERENCES/WINDOWS_CLOSEOUT.txt`.

Latest stationary-geometry source review (background, not an authority to alter mathematical definitions):

`C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_FIXED_SUPPORT_GAP_01\REPORT.md` — packet copy `REFERENCES/NCM_FIXED_GAP_01_REPORT.md`.

**Read only the necessary source passages and their actual bytes** (do not assume a historical commit is the local current HEAD):

- `apps/scientific_ui/src/trioctagon_ui/motion_observer.py` — actual implemented stage/frozen observation, geometry snapshot, native/envelope/clock attribution, numerical semantics and export definitions.
- `apps/scientific_ui/NATURAL_CORE_MOTION_v0.1.md` — scope and UI provenance; existing app-only observation is not a native replay.
- `papers/NATURAL_CORE_MOTION_CORRESPONDENCE/v0.1/main.tex` — derived correspondence/phase invariance and telescoping attribution; currently a separate research draft and not an authorization to edit it.
- `papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/manuscript.tex` — accepted placement, PLUS/MINUS family, fixed contacts, source geometry, central fan-opening arcs, host notch patches and native vs clock.
- `papers/PAPER_C/publication/v1.0.1/` — accepted folded host, if the radius/center needs source confirmation.
- `kernel_physics/z_manifold.py`, `kernel_physics/readouts.py`, `kernel_physics/dynamics.py` — only relevant definitions, read as text; no kernel execution or package rebuild.
- `papers/PAPER_E/v0.1.1/PAPER_E_Z_MANIFOLD_v0.1.1.md` — staged vs EMA definitions when needed; never merge the variants.
- `papers/NATIVE_RESPONSE_GEOMETRY/manuscript/observables_closure.tex` — distinguish actual fixed-face decoding and spatial-observable nonuniqueness.

Avoid wholesale source archaeology, reopening completed gravity/turning/SRG certificates, or checking everything in the repository. Record a bounded source/hash crosswalk for files actually consulted.

**Output root:** Create a new, external directory, such as

`C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_FIXED_REFERENCE_01`

If already present, create a fresh suffixed root and do not overwrite. Copy the work order, retained observation and named background reports there; verify hashes. Leave the authoritative checkout and all prior evidence **unchanged**. This task uses **no Git commands and no Git-invoking helpers**; it is separate from the already-authorized NCM-PUBLISH-01 paper publication task. Do not modify the publication worktree, kernels, locks, application, papers or production TORMENT.

### 2. First deliverable: a small typed correspondence and observed-state ledger

**Before analyzing movement, build a 1-page map** specifying: each input; output coordinates; which geometry is fixed; whether change is from native state, independent observer angle, observer time/envelope or optional EMA memory; and whether the output feeds back into F (it does not in these accepted definitions).

For every stored actual sample, produce a machine-readable ledger including:

- Stored sample ordinal and **actual native update index** (not an assumed unit time or a fabricated intermediate index).
- Original \(\Omega\) values, norm \(\kappa\), raw chiral \(C\), macro \(M\), full staged \(Z\), and conditional spatial point \(X\), using the **actual exported configuration** and declared center/rotation/scale.
- The independently recomputed staged clock \((q,\theta,t_c)\); separately record the actual/frozen placements, not a single merged path.
- Residuals between source-observation values and independently derived calculations; classify rounding-scale residuals honestly.
- Explicit defined/undefined flags for directions and angular differences at zero vectors or degenerate projected directions. No arbitrary fallback direction.

Inspect and verify the included outer and nested content seals. Do **not** advance the native recurrence. All output from those two states remains an observation of two retained samples, not a fresh simulation, time calibration, or multi-update trajectory certificate.

### 3. Motion decomposition — what is really changing?

Independently verify the implemented **ordered telescoping decomposition** of each scheduled placed-point displacement into **native / envelope / clock** contributions at its actual endpoints. Preserve the implementation's exact evaluation order and freeze conventions; do not silently change it to a different “physical contribution” definition. Give the defining intermediate evaluations, identity and residuals in ordinary mathematics.

Also provide a **controlled readout comparison** using the retained observations only:

- Fixed native \(\Omega\), fixed clock and envelope: what is constant?
- Changed native \(\Omega\) at the same fixed clock/envelope: what can change?
- Changed staged time/envelope at fixed state and angle: what can change?
- Changed clock angle at fixed state and envelope: what can change?
- Common phase applied **only to a display copy** at frozen observer settings: what changes (face arrows), and what remains invariant (\(C\), \(\kappa\), staged \(Z\), placed point)? Distinguish this kinematic comparison from actual native evolution.

Do not “turn off” the chiral term in the accepted Z formula to invent a new observation law. If useful, **algebraically report** its evaluated contribution \(\beta C\) separately from \(\alpha M\), and distinguish that spatial decomposition from the time-step attribution. Staged and EMA are different observers; EMA memory is not advanced here. If discussing phase-sensitive EMA innovation, derive or cite its rule **without executing an EMA trace**.

**Data limitation:** The retained example has only **two samples**, so one displacement is defined but a turn between successive displacements is not. No velocity, acceleration, sustained circulation, genuine three-sample turning, frequency, or orbital period may be inferred. If an additional independently admitted stored RunRecord is readily identified by the scoped source references, Codex may nominate **at most two** for a separate read-only comparison with hash and provenance; it must not search broadly, execute them, generate new runs, or treat a report's constructed mathematical witness as newly measured data. The original two-sample analysis must stand on its own if no such records qualify.

### 4. Spatial question — where do the placed Z observations lie?

Using the published fixed coordinates and **one stated reference configuration at a time**, compute for the actual sample points:

- \(X-O\), Euclidean radius \(\|X-O\|\), horizontal radius, centered height, and azimuth/elevation **only when defined**.
- Relation to original close sphere of the folded shell, radius \(\rho/w=\sqrt{13/12-\sqrt2/2}\approx0.6133730937584284\) at width one. Point is inside/on/outside by the stated norm comparison; **sphere is a reference, not a field/transport boundary**.
- Relation to each of the **three upper and three lower** actual central **broken boundary arcs** (a pair of finite 3D segments per opening). When useful compute nearest segment-point distance and 3D separation, retaining gap label, level and segment and noting tie/degeneracy. If there is no defined filled aperture, **do not** declare “inside,” “crossed,” or “passed through” it.
- Separately, relation to six **finite host notch measurement patches**: source-plane/finite-domain membership or ray incidence, clearly distinguished from proximity to central opening arcs. If checking outward directed ray from O through X, distinguish direction/patch hit from the point's own membership or a real trajectory.
- Upper/lower and opposite-view parity: retain all six labels and both near/far sides in calculations. Do not interpret an apparent coincidence in top projection as a 3D intersection.

Use the **fixed PLUS \(\tau=0\)** surface, the same reference as the existing NCM display, for the primary ledger. You may add **separate static geometry controls** for PLUS \(\tau=h\) and MINUS \(\tau=h\), keeping the same observed Z coordinates and same placement settings **only as sensitivity comparisons**. \(\tau\) is a **shape parameter, not elapsed time**; do not draw connections between these static cases and call them a motion. Every claim about a finite face/patch must use its real 3D geometry, not the infinite carrier plane or an invented filled central aperture.

Important: A placed Z value can lie outside the finite shell, within the sphere, or at a position without a meaningful ray angle; do not automatically locate it “inside the core.” No physical field or energy-flux assignment is supported by such distances alone.

### 5. Smallest new mathematical finding — not another prescribed choreography

After the above calculations, formulate **one (at most two)** exact implications, counterexamples, or obstructions grounded in the source-defined maps. Preferred candidates, only if actually useful:

- Which native-state transformations can move face-local directions without moving frozen staged Z, and why?
- Under what nondegenerate conditions does a centered placed point change direction while its Euclidean radius does not (or vice versa)? Distinguish source-invariant formulas from specific finite examples.
- Which geometrical measurements of a Z point can be derived independently of camera orientation, and which are projection artefacts?
- What data would be mathematically necessary to promote two sampled observation points to a continuous path or flux law, without adding such a law?

Do not turn “we could define such a map” into an established physical mechanism. An exact negative or non-identifiability result may be the most valuable discovery. If the only new result is a faithful finite-sample accounting, state that rather than fabricate novelty.

### 6. Validation, figures, and stop conditions

**Permitted:** One modest standalone offline research script (with tests) using existing Python math libraries, reading the retained JSON as data and the existing formulas from text. Exact/symbolic checks for small identities are welcome. Include a declared, small test list: input integrity; independent reproduction of two observed samples; decomposition identity; clock/state counterfactuals; six labeled opening-arc distances; host-patch versus arc distinction; both near/far views; zeros/undefined angles; \(\tau\)-static sensitivity; source preservation. Preserve binary64-versus-exact distinctions.

**Not permitted:** Native `step/run/resume` or producer calls, old scientific-checker reruns, coefficient sweeps, orbit/period search, new observation export treated as evidence, modifications to the application, graphics that invent energy beams or circulating material, external downloads, model/API changes, paper drafts or publication. No continuous trajectory interpolation except clearly labeled **straight sample connector for visualization only**, and preferably just plot markers with no connector.

**Figures (code-drawn from exact source coordinates):**

1. **Top view**: original folded reference/sphere silhouette, fixed center, all six upper/lower opening arcs distinguishably drawn, and actual placed Z markers (scheduled and frozen distinguished), with source-based angular labels and an honest projection disclaimer.
2. **Side or oblique view**: same center, near/far, upper/lower edges, close sphere, labeled placed points, and finite notch patches separately from central broken arcs.
3. **Optional small diagnostic plot**: actual two-sample native/envelope/clock vector displacement components or norm decomposition. Do not portray each component norm as additive; the **vectors** add.

No generative image tool or unverified 3D material animation is needed. Source-defined coordinates and actual observed points are sufficient. If a plot makes an interpretation visually ambiguous, prefer a table plus a side-view rather than making up missing geometry.

**Delivery into the fresh external root:**

- `START_HERE.md` — 1-page plain-language discovery summary, biggest surprise (if any), and honest scientific status.
- `REPORT.md` — definition map; equations; reproducible computation; per-sample and six-opening tables; limits; one or two exact mathematical statements if supported; explicit verdict whether existing Z supports any **stronger** core-motion interpretation.
- `OBSERVATIONS.json` (or CSV) — two-sample measured/derived ledger with source lineage, exact sample indices, residuals and uncertainty flags.
- `GAP_COMPARISON.json` — six-labeled finite 3D geometry comparisons, including both PLUS and sensitivity references where used.
- `checks.py`, `checks_results.json` and actual output log/command trace.
- `figures/01_top.png` and `figures/02_side.png` (plus optional diagnostic figure).
- `SOURCE_MANIFEST.json`, `CLOSEOUT.txt`, `OUTPUT_HASHES.json` and a verified portable review ZIP plus external ZIP receipt.

Report the actual number of tests run (not as a count of theorems). Verify packet input identities; hash a bounded list of read-only source/input files before and after. **No Git**. Do not claim a whole-checkout preservation audit if only a bounded set was checked. Do not claim Windows graphical inspection if only files and scripts ran. The closeout must say clearly whether a meaningful new theorem emerged or just a useful reconciliation of existing definitions.

**STOP HERE** if the retained two samples and prior evidence do not support more than a bounded descriptive answer. No extra search, no new native run, no published paper, and no invented motion law to resolve an inconclusive result. Return the evidence and propose at most **one** narrowly justified successor question for author/GPT review—not an automatically authorized new investigation.

### 7. Suggested operator message to Codex

> Execute **NCM-Z-01 v0.1 — Existing Z dynamics against the stationary Tri-Octagon geometry** from the attached packet. Use the accepted native, Z-placement and central-opening definitions. Study the existing retained observations, not the earlier average-arrow gap sweep; separate native state changes, observer clock and envelope, and distinguish central opening arcs from finite host notch patches. Keep the close original sphere as a passive geometric reference. Produce a faithful top view and side view, numerical/analytical accounting with actual sample indices, and a verifiable report. Preserve our fixed-support interpretation; no new motion laws or assumptions of flow. Use Windows Command Prompt with the existing `torment` environment; write only to a fresh external research directory. **No Git, code/kernel/app edits, native runs, search sweeps or publication.** Return the review ZIP and one-paragraph discovery verdict.
