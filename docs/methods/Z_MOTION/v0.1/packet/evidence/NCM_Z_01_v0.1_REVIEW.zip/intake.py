"""Offline packet inspection only; never execute archived code."""
from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,stat,sys,datetime
ROOT=Path(__file__).resolve().parent
for d in ['inputs','logs','source_reads','figures','scratch','mplconfig']:(ROOT/d).mkdir(exist_ok=True)
def fp(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
zip_path=Path(r'C:\Users\Notandi\Downloads\NCM_Z_01_Codex_Packet_v0.1.zip')
order=Path(r'C:\Users\Notandi\Downloads\CODEX_NCM_Z_01_EXISTING_DYNAMICS_FIXED_GEOMETRY_WORK_ORDER_v0.1.md')
assert not (ROOT/'inputs'/zip_path.name).exists()
for p in [zip_path,order]:(ROOT/'inputs'/p.name).write_bytes(p.read_bytes())
with zipfile.ZipFile(zip_path) as z:
    info=z.infolist();names=[i.filename for i in info if not i.is_dir()]
    assert len(names)==len(set(names))==len({x.casefold() for x in names})
    for i in info:
        p=PurePosixPath(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and ':' not in i.filename
        assert not stat.S_ISLNK(i.external_attr>>16)
        assert not (i.create_system==0 and i.external_attr&0x400)
    assert z.testzip() is None
    print('ZIP',json.dumps(fp(zip_path.read_bytes())))
    print('MEMBERS',json.dumps(names,indent=2))
    for name in names:
        if any(key in name.upper() for key in ['MANIFEST','IDENTIT','READ_FIRST','START_HERE']):
            if name.endswith(('.json','.md','.txt')):
                print('DOCUMENT',name);print(z.read(name).decode('utf8'))
    inventory={name:fp(z.read(name)) for name in names}
(ROOT/'PACKET_INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
(ROOT/'ENVIRONMENT.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'python':sys.executable,'version':sys.version,'input_zip':fp(zip_path.read_bytes()),'standalone_order':fp(order.read_bytes()),
 'offline':True,'native_executions':0,'git_commands':0},indent=2)+'\n')
