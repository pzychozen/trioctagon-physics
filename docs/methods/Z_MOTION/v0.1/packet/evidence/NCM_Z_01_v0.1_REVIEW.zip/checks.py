"""NCM-Z-01: finite retained-data analysis. No kernel imports, native steps or EMA updates.

Run from any directory with: python -X utf8 -I -B <absolute path to checks.py>
Writes derived research artifacts only beside this script.
"""
from pathlib import Path
import copy, hashlib, json, math, os, sys
import mpmath as mp

ROOT=Path(__file__).resolve().parent
PORTABLE="--portable" in sys.argv[1:]
TOL=2e-13
GTOL=1e-12
SQ3=math.sqrt(3.0)
r=SQ3/6; d=1-math.sqrt(2)/2; a=d/2; h=(math.sqrt(2)-1)/2
O=(0.0,r,0.0)
rho=math.sqrt(13/12-math.sqrt(2)/2)
T=((-0.5,-SQ3/2,0.0),(1.0,0.0,0.0),(-0.5,SQ3/2,0.0))
N=((-SQ3/2,0.5,0.0),(0.0,-1.0,0.0),(SQ3/2,0.5,0.0))
TESTS=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
def unique(items):
    out={}
    for k,v in items:
        if k in out: raise ValueError("duplicate key: "+k)
        out[k]=v
    return out
def parse(b): return json.loads(b,object_pairs_hook=unique,parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
def read(p): return parse((ROOT/p).read_bytes())
def write(p,v): (ROOT/p).write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")
def check(name,ok,detail=None):
    TESTS.append({"name":name,"passed":bool(ok),"detail":detail})
    if not ok:
        write("checks_results.json",{"all_passed":False,"tests_run":len(TESTS),"tests":TESTS})
        raise AssertionError(name+": "+str(detail))
def flat(v):
    if isinstance(v,(tuple,list)): return [z for x in v for z in flat(x)]
    return [v]
def residual(x,y):
    xx,yy=flat(x),flat(y)
    if len(xx)!=len(yy): return float("inf")
    return max((abs(u-v) for u,v in zip(xx,yy)),default=0.0)
def close(name,x,y,tol=TOL):
    res=residual(x,y); scale=max(1.0,*map(abs,flat(x)),*map(abs,flat(y)))
    check(name,res<=tol*scale,{"max_abs_residual":res,"allowed":tol*scale})
    return res
def add(x,y): return tuple(a+b for a,b in zip(x,y))
def sub(x,y): return tuple(a-b for a,b in zip(x,y))
def mul(v,k): return tuple(x*k for x in v)
def dot(x,y): return math.fsum(a*b for a,b in zip(x,y))
def norm(x): return math.hypot(*x)
def cross(x,y): return (x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0])
def angles(p):
    R=norm(p); hr=math.hypot(*p[:2])
    return {"radius":R,"horizontal_radius":hr,"centered_height":p[2],
            "direction_defined":R!=0,"azimuth_defined":hr!=0,
            "azimuth_degrees":math.degrees(math.atan2(p[1],p[0])) if hr else None,
            "elevation_degrees":math.degrees(math.atan2(p[2],hr)) if R else None,
            "unit_direction":mul(p,1/R) if R else None}
def angle(x,y):
    if norm(x)==0 or norm(y)==0: return None
    return math.degrees(math.atan2(norm(cross(x,y)),dot(x,y)))
def seal(v): return sha(canonical({k:x for k,x in v.items() if k!="content_sha256"}))==v["content_sha256"]

# Admission is repeated before any scientific calculation; all reads are inert JSON/text.
outer=read("inputs/retained.motion.json"); obs=outer["observation"]; probe=outer["phase_probe"]
parent=read("inputs/parent_run_record.json"); cfg=obs["config"]; frozen=obs["frozen_clock"]
check("prescribed retained-file hash",sha((ROOT/"inputs/retained.motion.json").read_bytes())=="071f6f7dc74128d638b0e96e33897b1366b2f8bcb98ca741c11fe0af5ed0e1e7")
for name,v in (("outer",outer),("observation",obs),("phase probe",probe)): check(name+" content seal",seal(v))
check("admission gate",read("INTEGRITY.json")["all_passed"])
check("parent canonical identity",sha(canonical(parent))==obs["parent"]["canonical_json_sha256"])
check("parent deterministic identity",sha(canonical({k:v for k,v in parent.items() if k not in ("execution_metadata","deterministic_sha256")}))==parent["deterministic_sha256"]==obs["parent"]["deterministic_sha256"])
check("probe lineage",probe["parent"]==obs["parent"] and probe["observation_sha256"]==obs["content_sha256"])
check("probe configuration",all(probe[k]==obs[k] for k in ("config","geometry","frozen_clock","display_scale")))
check("source identity",read("SOURCE_MANIFEST.before.json")["observer"]["sha256"]==obs["component_source_sha256"])
source_files=read("SOURCE_MANIFEST.before.json")
source_paths={key:ROOT/"source_snapshots"/(key+Path(v["path"]).suffix) if PORTABLE else Path(v["path"]) for key,v in source_files.items()}
check("consulted source bytes before calculation",all(sha(source_paths[k].read_bytes())==v["sha256"] for k,v in source_files.items()))
check("map and initial ledger precede analysis",(ROOT/"TYPED_CORRESPONDENCE.md").is_file() and (ROOT/"INITIAL_STATE_LEDGER.json").is_file())
for text in ('{"a":1,"a":2}','{"a":NaN}','{"a":Infinity}'):
    try: parse(text); rejected=False
    except ValueError: rejected=True
    check("strict JSON rejection: "+text,rejected)
tamper=copy.deepcopy(outer); tamper["observation"]["samples"][0]["kappa"]+=1
check("changed observation invalidates both seals",not seal(tamper) and not seal(tamper["observation"]))

def clock(index):
    q=(cfg["q0"]+index*cfg["q_step"])%cfg["N"]
    return {"sector":q,"theta":2.0*math.pi*q/cfg["N"],"time":cfg["time0"]+index*cfg["dt"]}
def envelope(cl):
    th=cl["theta"]; f=math.cos(3.0*(th-cfg["lock_angle"]))
    return math.exp(-cfg["gamma"]*cl["time"]),(f*math.cos(th),f*math.sin(th),f)
def K(k): return cfg["lambda_vp"]*(k/(1.0+k))
def linear(v):
    c,s=math.cos(cfg["psi"]),math.sin(cfg["psi"]); mu=cfg["mu_place"]
    return (mu*(c*v[0]-s*v[1]),mu*(s*v[0]+c*v[1]),mu*v[2])
def placed(k,C,cl):
    E,H=envelope(cl); M=mul(H,K(k)*E); Z=add(mul(M,cfg["alpha"]),mul(C,cfg["beta"]))
    return {"macro":M,"Z":Z,"point":add(O,linear(Z)),"alpha_macro":mul(M,cfg["alpha"]),"beta_C":mul(C,cfg["beta"]),"K":K(k),"E":E,"H":H}
def snapshot(omega,idx):
    C=cross([z.real for z in omega],[z.imag for z in omega])
    k=math.hypot(*(p for z in omega for p in (z.real,z.imag)))
    W=tuple(math.fsum(T[i][j]*C[i] for i in range(3)) for j in range(3))
    faces=[(z.real*T[i][0],z.real*T[i][1],z.imag) for i,z in enumerate(omega)]
    return {"omega":[(z.real,z.imag) for z in omega],"omega_binary64_hex":[(z.real.hex(),z.imag.hex()) for z in omega],
            "kappa":k,"C":C,"W":W,"Gamma":math.fsum(C),"face_vectors":faces,"clock":clock(idx),
            "scheduled":placed(k,C,clock(idx)),"frozen":placed(k,C,frozen)}
def high_precision(omega,cl):
    # Real-formula comparison at exact binary64 inputs, 80 decimal digits.
    mp.mp.dps=80
    x=[mp.mpf(z.real) for z in omega]; y=[mp.mpf(z.imag) for z in omega]
    k=mp.sqrt(sum(t*t for t in x+y)); C=cross(x,y)
    th=mp.mpf(cl["theta"]); E=mp.exp(-mp.mpf(cfg["gamma"])*mp.mpf(cl["time"]))
    f=mp.cos(3*(th-mp.mpf(cfg["lock_angle"])))
    amp=mp.mpf(cfg["lambda_vp"])*k/(1+k)*E*f
    M=[amp*mp.cos(th),amp*mp.sin(th),amp]
    return {"kappa":float(k),"C":list(map(float,C)),"macro":list(map(float,M)),
            "Z":[float(mp.mpf(cfg["alpha"])*v+mp.mpf(cfg["beta"])*c) for v,c in zip(M,C)]}

rows=[]; points=[]
for stored,pr in zip(obs["samples"],parent["samples"]):
    idx=stored["update_index"]; omega=[complex(*p) for p in stored["omega"]]
    check(f"n={idx} parent native index",idx==int(pr["update_index"]))
    check(f"n={idx} exact native state and hex",all(z.real.hex()==q["re"]["f64"] and z.imag.hex()==q["im"]["f64"] for z,q in zip(omega,pr["omega"])) and [[z.real.hex(),z.imag.hex()] for z in omega]==stored["omega_binary64_hex"])
    calc=snapshot(omega,idx)
    res={key:close(f"n={idx} reproduced {key}",calc[key],stored[key]) for key in ("omega","kappa","C","W","Gamma","face_vectors")}
    check(f"n={idx} scheduled clock",calc["clock"]==stored["clock"])
    for mode in ("scheduled","frozen"):
        res[mode]={key:close(f"n={idx} {mode} {key}",calc[mode][key],stored[mode][key]) for key in ("macro","Z","point")}
        hp=high_precision(omega,calc["clock"] if mode=="scheduled" else frozen)
        res[mode]["80_digit_real_formula"]={key:close(f"n={idx} {mode} 80-digit {key}",hp[key],calc[key] if key in ("kappa","C") else calc[mode][key]) for key in ("kappa","C","macro","Z")}
        p=sub(calc[mode]["point"],O); measurements=angles(p)
        measurements["sphere_radius"]=rho; measurements["sphere_signed_margin"]=norm(p)-rho
        measurements["sphere_relation"]="on_tolerance_band" if abs(norm(p)-rho)<=GTOL else ("inside" if norm(p)<rho else "outside")
        label=("S" if mode=="scheduled" else "F")+str(idx)
        points.append({"label":label,"sample_ordinal":stored["sample_ordinal"],"native_update_index":idx,"mode":mode,"world":calc[mode]["point"],"centered":p,"measurements":measurements})
        calc[mode]["spatial"]=measurements
    pres={}
    for key,rkey in (("macro","Z_macro"),("Z","Z_total")):
        ref=[float.fromhex(v["f64"]) for v in pr["observer_results"]["paper_e_staged_v1"][rkey]]
        pres[key]=close(f"n={idx} parent staged {key}",calc["scheduled"][key],ref)
    rows.append({"sample_ordinal":stored["sample_ordinal"],"native_update_index":idx,"derived":calc,"residuals":res,"parent_staged_residuals":pres,"zero_flags":{"C_direction_defined":norm(calc["C"])!=0,"face_direction_defined":[norm(v)!=0 for v in calc["face_vectors"]],"W_direction_defined":norm(calc["W"])!=0}})
check("only two distinct native indices",[z["native_update_index"] for z in rows]==[0,1])
old,new=[z["derived"] for z in rows]; Eo,Ho=envelope(old["clock"]); En,Hn=envelope(new["clock"])
Ko,Kn=K(old["kappa"]),K(new["kappa"])
native=linear(add(mul(Ho,cfg["alpha"]*Eo*(Kn-Ko)),mul(sub(new["C"],old["C"]),cfg["beta"])))
env=linear(mul(Ho,cfg["alpha"]*Kn*(En-Eo)))
clk=linear(mul(sub(Hn,Ho),cfg["alpha"]*Kn*En))
total=sub(new["scheduled"]["point"],old["scheduled"]["point"])
telres=sub(total,add(native,add(env,clk)))
attr={"from_native_index":0,"to_native_index":1,"update_span":1,"order":["native","envelope","clock"],"native":native,"envelope":env,"clock":clk,"total":total,"residual":telres,"norms_are_not_additive":True,"component_norms":{k:norm(v) for k,v in (("native",native),("envelope",env),("clock",clk),("total",total))},"turn_between_displacements_degrees":None,"turn_undefined_reason":"Only one displacement; a second displacement would require a third retained sample."}
for key in ("native","envelope","clock","total","residual"):
    close("retained attribution "+key,attr[key],obs["samples"][1]["attribution"][key])
close("ordered telescope residual",telres,(0,0,0))
midclock={"sector":old["clock"]["sector"],"theta":old["clock"]["theta"],"time":new["clock"]["time"]}
mid1=placed(new["kappa"],new["C"],old["clock"])
mid2=placed(new["kappa"],new["C"],midclock)
stages=[old["scheduled"],mid1,mid2,new["scheduled"]]
attr["intermediates"]=[{"state_index":n,"theta":cl["theta"],"time":cl["time"],"point":p["point"]} for n,cl,p in ((0,old["clock"],stages[0]),(1,old["clock"],stages[1]),(1,midclock,stages[2]),(1,new["clock"],stages[3]))]
for i,key in enumerate(("native","envelope","clock")): close("successive intermediate "+key,sub(stages[i+1]["point"],stages[i]["point"]),attr[key])
controls=[]
for name,before,after,meaning in (
    ("all_fixed",old["frozen"],placed(old["kappa"],old["C"],frozen),"same retained state and same observer"),
    ("native_only",old["frozen"],new["frozen"],"two retained native states; frozen theta and envelope"),
    ("envelope_only",mid1,mid2,"retained state 1, theta0; only retained time settings 0 and 0.1"),
    ("clock_only",mid2,new["scheduled"],"retained state 1, time0.1; only retained theta settings 0 and pi/6")):
    pb,pa=linear(before["Z"]),linear(after["Z"])
    controls.append({"name":name,"meaning":meaning,"before":before,"after":after,"displacement":sub(after["point"],before["point"]),"radius_change":norm(pa)-norm(pb),"centered_direction_difference_degrees":angle(pb,pa)})
check("all-fixed observation identical",controls[0]["displacement"]==(0.0,0.0,0.0))
check("native-only retained displacement nonzero",norm(controls[1]["displacement"])>GTOL)
check("envelope-only can change direction",controls[2]["centered_direction_difference_degrees"]>GTOL)
check("clock-only can change point",norm(controls[3]["displacement"])>GTOL)
# Exact real identity: Z(E1) cross Z(E2)=alpha*K*beta*(E1-E2)*(H cross C).
close("envelope direction identity",cross(mid1["Z"],mid2["Z"]),mul(cross(Ho,new["C"]),cfg["alpha"]*Kn*cfg["beta"]*(Eo-En)))
phase=[]
for row,stored,pr in zip(rows,obs["samples"],probe["samples"]):
    omega=[complex(*p) for p in stored["omega"]]; chi=probe["probe_angle"]
    transformed=[z*complex(math.cos(chi),math.sin(chi)) for z in omega]
    q=snapshot(transformed,row["native_update_index"]); base=row["derived"]
    rr={}
    for key in ("omega","kappa","C","W","Gamma","face_vectors"): rr[key]=close(f"phase n={row['native_update_index']} reproduction {key}",q[key],pr[key])
    for mode in ("frozen","scheduled"): rr[mode]=close(f"phase n={row['native_update_index']} reproduced {mode}",q[mode]["point"],pr[mode]["point"])
    inv={}
    for key in ("kappa","C","W","Gamma"): inv[key]=close(f"phase n={row['native_update_index']} invariant {key}",q[key],base[key])
    for mode in ("frozen","scheduled"): inv[mode+"_point"]=close(f"phase n={row['native_update_index']} invariant {mode}",q[mode]["point"],base[mode]["point"])
    gram=max(abs(dot(q["face_vectors"][i],q["face_vectors"][j])-dot(base["face_vectors"][i],base["face_vectors"][j])) for i in range(3) for j in range(i+1,3))
    close("saved phase Gram change",gram,pr["ambient_gram_change"])
    local=[add(mul(v,math.cos(chi)),mul(cross(N[i],v),math.sin(chi))) for i,v in enumerate(base["face_vectors"])]
    close("phase rotation in each fixed tangent plane",q["face_vectors"],local)
    phase.append({"native_update_index":row["native_update_index"],"angle":chi,"display_only":True,"derived":q,"invariance_residuals":inv,"saved_reproduction_residuals":rr,"ambient_gram_change":gram})

def geometry(tau,hand):
    e=[(math.cos(-math.pi/2+i*math.pi/3),math.sin(-math.pi/2+i*math.pi/3)) for i in range(6)]
    def point(v,scale,z,shear=False):
        x,y=v
        if shear: x,y=x+(tau/r)*y,y-(tau/r)*x
        return ((-1 if hand=="MINUS" else 1)*scale*x,scale*y,z)
    top=[point(v,a,h) for v in e]; bot=[point(v,a,-h,True) for v in e]
    U=[point(e[2*k],r,.5) for k in range(3)]; L=[point(e[2*k],r,-.5,True) for k in range(3)]
    faces=[]
    for i in range(6): faces.extend(((top[i],top[(i+1)%6],bot[(i+2)%6]),(top[i],bot[(i+2)%6],bot[(i+1)%6])))
    arcs=[]
    for sign,tips,ring in (("+",U,top),("-",L,bot)):
        for k in range(3):
            faces.extend(((tips[k],ring[(2*k-1)%6],ring[2*k]),(tips[k],ring[2*k],ring[(2*k+1)%6])))
            vertices=(tips[k],ring[2*k+1],tips[(k+1)%3])
            arcs.append({"label":f"G{sign}{k}","level":"upper" if sign=="+" else "lower","vertices":vertices,"bisector_azimuth_degrees":math.degrees(math.atan2(vertices[1][1],vertices[1][0]))})
    return {"branch":hand,"tau":tau,"tau_is_time":False,"vertices":top+bot+U+L,"faces":faces,"arcs":arcs}
def host():
    local=[(-.5,-h),(-h,-.5),(h,-.5),(.5,-h),(.5,h),(h,.5),(-h,.5),(-.5,h)]
    panels=[[( -.25-u/2, SQ3/4-SQ3*u/2-r,z) for u,z in local],[(u,-r,z) for u,z in local],[(.25-u/2,SQ3/4+SQ3*u/2-r,z) for u,z in local]]
    unique_edges={}
    for panel in panels:
        for j in range(8):
            pair=(panel[j],panel[(j+1)%8]); key=tuple(sorted(tuple(round(v,13) for v in p) for p in pair))
            unique_edges[key]=pair
    return list(unique_edges.values())
def segment(p,a,b):
    v=sub(b,a); den=dot(v,v); raw=dot(sub(p,a),v)/den if den else None
    u=max(0.0,min(1.0,raw)) if raw is not None else 0.0
    nearest=add(a,mul(v,u))
    return {"parameter_unclamped":raw,"parameter":u,"nearest_point":nearest,"distance":norm(sub(p,nearest)),"degenerate_segment":den==0,"location":"degenerate" if den==0 else ("start" if u==0 else ("end" if u==1 else "interior"))}
def patches():
    out=[]
    for sig in (1,-1):
        for k in range(3):
            th=-math.pi/2+(2*k+1)*math.pi/3; g=(math.cos(th),math.sin(th),0); j=(-g[1],g[0],0)
            verts=[add(add(mul(g,2*r-SQ3*d*lam/2),mul(j,zeta)),(0,0,sig*(h+d*lam))) for lam,zeta in ((0,0),(1,-d/2),(1,d/2))]
            out.append({"label":f"N{'+' if sig==1 else '-'}{k}","sigma":sig,"g":g,"j":j,"normal_unnormalized":add(g,(0,0,sig*SQ3/2)),"plane_constant":2*r+SQ3*h/2,"vertices":verts})
    return out
def patch_member(p,patch):
    lam=(patch["sigma"]*p[2]-h)/d; zet=dot(p,patch["j"])
    res=dot(p,patch["normal_unnormalized"])-patch["plane_constant"]
    bary=[1-lam,lam/2-zet/d,lam/2+zet/d]
    plane=abs(res)<=GTOL; finite=all(-GTOL<=v<=1+GTOL for v in bary)
    return {"plane_residual":res,"plane_distance":abs(res)/norm(patch["normal_unnormalized"]),"lambda":lam,"zeta":zet,"barycentric":bary,"on_plane":plane,"finite_domain":finite,"point_member":plane and finite}
def ray(p,patch):
    if norm(p)==0: return {"defined":False,"reason":"zero centered point","finite_patch_hit":False}
    den=dot(p,patch["normal_unnormalized"])
    if abs(den)<=GTOL: return {"defined":True,"reason":"parallel within tolerance; origin off plane","finite_patch_hit":False}
    t=patch["plane_constant"]/den
    if t<0: return {"defined":True,"parameter":t,"reason":"carrier intersection behind origin","finite_patch_hit":False}
    q=mul(p,t); membership=patch_member(q,patch)
    return {"defined":True,"parameter":t,"point":q,"membership":membership,"finite_patch_hit":membership["point_member"],"reason":"finite hit" if membership["point_member"] else "forward carrier-plane hit outside finite triangle"}

refs=[geometry(0,"PLUS"),geometry(h,"PLUS"),geometry(h,"MINUS")]
edges=host(); pp=patches()
close("source center",O,obs["geometry"]["origin"])
close("source fixed tangents",T,obs["geometry"]["tangents"])
close("reconstructed 24 central triangles",[[add(O,p) for p in f] for f in refs[0]["faces"]],obs["geometry"]["central_triangles"])
check("21 distinct host edges",len(edges)==21)
def edge_match(x,y): return min(residual(x,y),residual(x,tuple(reversed(y))))
hostres=max(min(edge_match(tuple(add(O,p) for p in e),z) for z in obs["geometry"]["host_edges"]) for e in edges)
close("folded host matches retained geometry",hostres,0)
close("original host enclosing radius from vertices",max(norm(p) for e in edges for p in e),rho)
gapcases=[]
for geom in refs:
    label=f"{geom['branch']}_tau_{'0' if geom['tau']==0 else 'h'}"
    cases=[]
    for point in points:
        comparisons=[]
        for arc in geom["arcs"]:
            vv=arc["vertices"]; ss=[segment(point["centered"],vv[i],vv[i+1]) for i in range(2)]
            near=min(s["distance"] for s in ss); tied=[i for i,s in enumerate(ss) if abs(s["distance"]-near)<=GTOL]
            unique_points=[]
            for i in tied:
                if not any(norm(sub(ss[i]["nearest_point"],q))<=GTOL for q in unique_points): unique_points.append(ss[i]["nearest_point"])
            proj=[segment(point["centered"][:2],vv[i][:2],vv[i+1][:2])["distance"] for i in range(2)]
            comparisons.append({"label":arc["label"],"level":arc["level"],"segments":ss,"distance":near,"nearest_segments_zero_based":tied,"nearest_point_count_with_tolerance":len(unique_points),"segment_tie":len(tied)>1,"projected_top_distance":min(proj),"projection_test_is_3d_intersection_test":False})
        check(label+" "+point["label"]+" six distinct finite-arc comparisons",len(comparisons)==6 and len({x["label"] for x in comparisons})==6 and all(all(0<=s["parameter"]<=1 and not s["degenerate_segment"] for s in x["segments"]) for x in comparisons))
        check(label+" "+point["label"]+" projection bound",all(x["projected_top_distance"]<=x["distance"]+GTOL for x in comparisons))
        nearest=min(x["distance"] for x in comparisons)
        cases.append({"point":point["label"],"centered":point["centered"],"arcs":comparisons,"nearest_arc_labels":[x["label"] for x in comparisons if abs(x["distance"]-nearest)<=GTOL],"nearest_arc_distance":nearest})
    gapcases.append({"reference":label,"geometry":geom,"points":cases})
patchcases=[]
for p in points:
    entries=[{"label":patch["label"],"point_membership":patch_member(p["centered"],patch),"outward_ray":ray(p["centered"],patch)} for patch in pp]
    check(p["label"]+" six finite patch comparisons",len(entries)==6)
    patchcases.append({"point":p["label"],"patches":entries})
for patch in pp:
    check(patch["label"]+" exact-domain vertex checks",all(patch_member(p,patch)["point_member"] for p in patch["vertices"]))
    center=mul(tuple(math.fsum(v[j] for v in patch["vertices"]) for j in range(3)),1/3)
    check(patch["label"]+" synthetic positive ray test",ray(center,patch)["finite_patch_hit"])
    outside=add(patch["vertices"][0],mul(patch["j"],2))
    m=patch_member(outside,patch)
    check(patch["label"]+" plane is not finite triangle",m["on_plane"] and not m["point_member"])
    check(patch["label"]+" arc/patch distinction",all(not patch_member(v,patch)["point_member"] for arc in refs[0]["arcs"] for v in arc["vertices"]))
check("segment interior test",segment((.5,1,0),(0,0,0),(1,0,0))["parameter"]==.5)
check("segment endpoint clamp",segment((2,0,0),(0,0,0),(1,0,0))["parameter"]==1)
check("segment degenerate flag",segment((1,0,0),(0,0,0),(0,0,0))["degenerate_segment"])
check("shared opening middle point segment tie",all(abs(segment(arc["vertices"][1],arc["vertices"][0],arc["vertices"][1])["distance"])<=GTOL and abs(segment(arc["vertices"][1],arc["vertices"][1],arc["vertices"][2])["distance"])<=GTOL for arc in refs[0]["arcs"]))
check("zero direction undefined",angles((0,0,0))["unit_direction"] is None and angles((0,0,0))["elevation_degrees"] is None and angle((0,0,0),(1,0,0)) is None)
check("vertical azimuth undefined",angles((0,0,1))["azimuth_degrees"] is None and angles((0,0,1))["elevation_degrees"]==90)
check("zero ray undefined",not ray((0,0,0),pp[0])["defined"])
close("MINUS is reflected complete PLUS mesh",refs[2]["faces"],[[(-p[0],p[1],p[2]) for p in f] for f in refs[1]["faces"]])
check("static sensitivity never changes observation points",all(case["centered"]==p["centered"] for ref in gapcases for case,p in zip(ref["points"],points)))
close("upper arcs unchanged under PLUS tau sensitivity",[q["vertices"] for q in refs[0]["arcs"][:3]],[q["vertices"] for q in refs[1]["arcs"][:3]])
check("lower arcs change under PLUS tau sensitivity",residual([q["vertices"] for q in refs[0]["arcs"][3:]],[q["vertices"] for q in refs[1]["arcs"][3:]])>GTOL)
opposite=lambda p:(-p[0],p[2],-p[1])
close("opposite orthographic coordinates preserve 3D distances",[norm(sub(opposite(p["centered"]),opposite(v))) for p in points for arc in refs[0]["arcs"] for v in arc["vertices"]],[norm(sub(p["centered"],v)) for p in points for arc in refs[0]["arcs"] for v in arc["vertices"]])
check("all six labels retained in both side views",len(refs[0]["arcs"])==6 and {x["level"] for x in refs[0]["arcs"]}=={"upper","lower"})

observations={"study":"NCM-Z-01 v0.1","evidence":"Derived observations of two saved states; no native replay or new experiment","source":obs["parent"],"integrity":read("INTEGRITY.json"),"config":cfg,"frozen_clock":frozen,"origin":O,"face_arrow_display_scale_not_placement":obs["display_scale"],"numeric_semantics":{"evaluation":"binary64 application operation order; real formula checked at 80 decimals using exact binary64 inputs","numeric_tolerance":TOL,"geometry_tolerance_width_units":GTOL,"angles":"degrees from centered vectors; atan2; zero directions null"},"samples":rows,"points":points,"attribution":attr,"controls":controls,"common_phase_display_probe":phase,"limitations":["two samples; one displacement","no physical time calibration, velocity, acceleration, turn between displacements or period","no native or EMA state advancement","integrity is not producer authentication or scientific replay certification"]}
gaps={"study":"NCM-Z-01 v0.1","coordinates":"centered width-one; world=O+centered","origin":O,"sphere_radius":rho,"geometry_tolerance":GTOL,"segment_index_convention":"0: tip k to middle ring point; 1: middle ring point to tip k+1","arcs_are_unfilled_boundaries":True,"finite_host_patches_are_separate_measurement_triangles":True,"references":gapcases,"host_edges":edges,"host_patches":pp,"host_patch_comparisons":patchcases}
write("OBSERVATIONS.json",observations); write("GAP_COMPARISON.json",gaps)

# Plot only reconstructed static coordinates and retained markers. No sample connectors.
os.environ["MPLCONFIGDIR"]=str(ROOT/"mplconfig")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon
from matplotlib.lines import Line2D
plt.rcParams.update({"font.size":10,"axes.titlesize":12,"font.family":"DejaVu Sans"})
COLORS=["#007a73","#9d5b00","#6e4fa5"]
def marker(ax,p,coords,offset):
    v=p["centered"]; x,y=coords(v)
    ax.scatter([x],[y],s=85 if p["mode"]=="scheduled" else 145,marker="o" if p["mode"]=="scheduled" else "s",facecolor="#cf2454" if p["mode"]=="scheduled" else "none",edgecolor="#cf2454" if p["mode"]=="scheduled" else "#164f9a",linewidth=1.8,zorder=8)
    ax.annotate(p["label"],(x,y),xytext=offset,textcoords="offset points",fontsize=10,color="#9d173d" if p["mode"]=="scheduled" else "#164f9a",weight="bold",zorder=9)
def style(ax,xlabel,ylabel):
    ax.set_aspect("equal"); ax.set_xlim(-.72,.72); ax.set_ylim(-.72,.72)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.grid(alpha=.12)
    ax.scatter([0],[0],marker="+",s=65,color="black",zorder=9); ax.annotate("O",(0,0),xytext=(-13,-15),textcoords="offset points")
    ax.add_patch(Circle((0,0),rho,fill=False,color="#8492a0",lw=1.3,ls=":"))
fig,ax=plt.subplots(figsize=(9,9))
for e in edges: ax.plot([v[0] for v in e],[v[1] for v in e],color="#c4cbd0",lw=1)
for i,arc in enumerate(refs[0]["arcs"]):
    vv=arc["vertices"]; upper=i<3
    ax.plot([v[0] for v in vv],[v[1] for v in vv],color=COLORS[i%3] if upper else "#151515",lw=3.2 if upper else 1.3,ls="-" if upper else (0,(3,3)),zorder=3 if upper else 4)
for k,arc in enumerate(refs[0]["arcs"][:3]):
    th=math.radians(arc["bisector_azimuth_degrees"])
    q=(.43*math.cos(th),.43*math.sin(th))
    ax.text(*q,f"G+{k} / G-{k}\n{arc['bisector_azimuth_degrees']:.0f}°",ha="center",va="center",color=COLORS[k],weight="bold")
for p,off in zip(points,[(7,12),(7,-20),(9,8),(-27,-20)]): marker(ax,p,lambda v:v[:2],off)
style(ax,"centered x / width","centered y / width")
ax.set_title("Fixed PLUS τ = 0 · top projection\nAll three upper arcs coincide in projection with their lower partners",pad=14)
ax.legend(handles=[Line2D([0],[0],color="#007a73",lw=3,label="Upper G+ (solid; k colors)"),Line2D([0],[0],color="black",ls="--",label="Lower G− (dashed overlay)"),Line2D([0],[0],color="#c4cbd0",label="Original folded host"),Line2D([0],[0],color="#8492a0",ls=":",label="Original enclosing sphere")],loc="lower right",fontsize=8)
fig.text(.5,.035,"S: scheduled   F: frozen observer   S0 = F0 in 3D\nMarker positions only. Projection overlap is not a 3D intersection or passage.",ha="center",fontsize=10)
fig.subplots_adjust(bottom=.13,top=.88)
fig.savefig(ROOT/"figures/01_top.png",dpi=190); plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(14,8))
for ax,view in zip(axes,(1,-1)):
    coords=lambda v,view=view:(view*v[0],v[2])
    # Opposite cameras along y; all edges remain visible, near/far only alter weight.
    for patch in pp: ax.add_patch(Polygon([coords(p) for p in patch["vertices"]],closed=True,facecolor="#bcc4ca",edgecolor="#8d969e",alpha=.22,lw=.9))
    for e in edges: ax.plot(*zip(*(coords(v) for v in e)),color="#c4cbd0",lw=.8,zorder=1)
    for i,arc in enumerate(refs[0]["arcs"]):
        near=math.fsum(p[1] for p in arc["vertices"])*view<0
        ax.plot(*zip(*(coords(v) for v in arc["vertices"])),color=COLORS[i%3],lw=2.6 if near else 1.5,alpha=1 if near else .65,ls="-" if i<3 else "--",zorder=4)
        mid=arc["vertices"][1]; xx,yy=coords(mid)
        dx=42 if xx>1e-10 else (-63 if xx<-1e-10 else -12); dy=28 if i<3 else -16
        ax.annotate(arc["label"],(xx,yy),xytext=(dx,dy),textcoords="offset points",color=COLORS[i%3],fontsize=9,weight="bold")
    for p,off in zip(points,[(8,8),(8,-18),(-35,0),(8,-15)]): marker(ax,p,coords,off)
    style(ax,"centered "+("x" if view==1 else "−x")+" / width","centered height / width")
    ax.set_title("View from "+("−y toward +y" if view==1 else "+y toward −y")+"\nAll near and far geometry retained")
fig.suptitle("Same fixed PLUS τ = 0 reference · opposite side projections",fontsize=16,y=.97)
fig.text(.5,.09,"Colored solid: upper arcs   Colored dashed: lower arcs   Pale triangles: finite host notch patches\nGray outline: original folded host   Dotted circle: close enclosing sphere   Thick arcs are nearer the camera",ha="center",fontsize=10)
fig.text(.5,.035,"S0/F0 and S1/F1 are retained-observation markers; no continuous path is drawn. Patches are measurement regions, not material.",ha="center",fontsize=10)
fig.subplots_adjust(bottom=.17,top=.85,wspace=.22)
fig.savefig(ROOT/"figures/02_side.png",dpi=180); plt.close(fig)
check("two required PNGs produced",all((ROOT/"figures"/p).stat().st_size>1000 for p in ("01_top.png","02_side.png")))
protected=list(read("SOURCE_MANIFEST.before.json").values())+read("INPUT_MANIFEST.before.json")
preservation=[]
if PORTABLE:
    for key,item in source_files.items():
        p=source_paths[key]; after=sha(p.read_bytes())
        preservation.append({**item,"checked_packaged_path":str(p),"after_sha256":after,"unchanged":after==item["sha256"]})
else:
    for item in protected:
        p=Path(item["path"]); after=sha(p.read_bytes())
        preservation.append({**item,"after_sha256":after,"unchanged":after==item["sha256"]})
check("packaged source snapshots" if PORTABLE else "bounded source/input preservation",all(v["unchanged"] for v in preservation),{"files":len(preservation)})
write("PORTABLE_SOURCE_CHECK.json" if PORTABLE else "PRESERVATION.json",{"scope":"Packaged snapshots only; original Windows paths were not inspected" if PORTABLE else "Only the listed consulted files; not a whole-checkout audit","files":preservation,"all_unchanged":all(v["unchanged"] for v in preservation)})
result={"all_passed":all(t["passed"] for t in TESTS),"tests_run":len(TESTS),"tests":TESTS,"python":sys.version,"python_executable":sys.executable,"mpmath":mp.__version__,"matplotlib":matplotlib.__version__,"portable":PORTABLE,"native_steps":0,"ema_updates":0,"note":"Tests are implementation checks, not theorems or a scientific replay."}
write("checks_results.json",result)
print(json.dumps({"tests_run":len(TESTS),"all_passed":result["all_passed"],"points":[{"label":p["label"],**p["measurements"]} for p in points],"attribution":attr,"controls":[{k:v for k,v in c.items() if k not in ("before","after")} for c in controls],"nearest_arcs":[{"reference":q["reference"],"points":[{k:v for k,v in p.items() if k not in ("arcs","centered")} for p in q["points"]]} for q in gapcases],"patch_hits":[{"point":q["point"],"point_members":[p["label"] for p in q["patches"] if p["point_membership"]["point_member"]],"outward_ray_hits":[p["label"] for p in q["patches"] if p["outward_ray"]["finite_patch_hit"]]} for q in patchcases]},indent=2))
