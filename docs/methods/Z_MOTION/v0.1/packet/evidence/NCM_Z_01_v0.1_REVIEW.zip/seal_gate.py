"""Read-only input admission; no repository imports or recurrence."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\TORMENT\TRIOCTAGON_new\trioctagon-physics")
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode("utf-8")
def pairs(items):
    result={}
    for k,v in items:
        if k in result: raise ValueError("duplicate JSON key")
        result[k]=v
    return result
def parse(b):
    return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
def seal(v):
    return sha(canonical({k:x for k,x in v.items() if k!="content_sha256"}))==v["content_sha256"]

paths = [
    Path(r"C:\Users\Notandi\Downloads\NCM_Z_01_Codex_Packet_v0.1.zip"),
    Path(r"C:\Users\Notandi\Downloads\CODEX_NCM_Z_01_EXISTING_DYNAMICS_FIXED_GEOMETRY_WORK_ORDER_v0.1.md"),
    Path(r"C:\TORMENT\trioctagon_motion_validation_20261029_01\exports\interactive.motion.json"),
    Path(r"C:\TORMENT\trioctagon_motion_validation_20261029_01\WINDOWS_CLOSEOUT.txt"),
    Path(r"C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_FIXED_SUPPORT_GAP_01\REPORT.md"),
    Path(r"C:\TORMENT\trioctagon_motion_validation_20261029_01\test-suite\fixtures\axial_old_run.json"),
]
source = parse((ROOT/"SOURCE_MANIFEST.before.json").read_bytes())
rp=REPO/"kernel_physics/_records.py"
rb=rp.read_bytes()
source["records"]={"path":str(rp),"bytes":len(rb),"sha256":sha(rb)}
(ROOT/"SOURCE_MANIFEST.before.json").write_bytes(json.dumps(source,indent=2).encode())
(ROOT/"source_reads/records.txt").write_text("\n".join(f"{i:04d}: {s}" for i,s in enumerate(rb.decode().splitlines(),1)),encoding="utf-8")
before=[{"path":str(p),"bytes":len(p.read_bytes()),"sha256":sha(p.read_bytes())} for p in paths]
(ROOT/"INPUT_MANIFEST.before.json").write_text(json.dumps(before,indent=2),encoding="utf-8")
raw=(ROOT/"inputs/retained.motion.json").read_bytes()
outer=parse(raw); obs=outer["observation"]; probe=outer["phase_probe"]
parentraw=paths[-1].read_bytes(); parent=parse(parentraw)
(ROOT/"inputs/parent_run_record.json").write_bytes(parentraw)
checks={}
checks["prescribed_file_identity"]=len(raw)==27068 and sha(raw)=="071f6f7dc74128d638b0e96e33897b1366b2f8bcb98ca741c11fe0af5ed0e1e7"
for name,v in [("outer",outer),("observation",obs),("probe",probe)]:
    checks[name+"_content_seal"]=seal(v)
checks["observer_source_identity"]=obs["component_source_sha256"]==source["observer"]["sha256"]
checks["parent_canonical_identity"]=sha(canonical(parent))==obs["parent"]["canonical_json_sha256"]
checks["parent_deterministic_seal"]=sha(canonical({k:v for k,v in parent.items() if k not in ("deterministic_sha256","execution_metadata")}))==parent["deterministic_sha256"]==obs["parent"]["deterministic_sha256"]
checks["parent_implementation_reference"]=parent["implementation"]==obs["parent"]["implementation"]
checks["probe_parent_reference"]=probe["parent"]==obs["parent"] and probe["observation_sha256"]==obs["content_sha256"]
checks["probe_settings_geometry"]=all(probe[k]==obs[k] for k in ("config","geometry","frozen_clock","display_scale"))
checks["native_indices"]= [int(x["update_index"]) for x in parent["samples"]]==[x["update_index"] for x in obs["samples"]]==[0,1]
def omega(s): return [[float.fromhex(c["re"]["f64"]),float.fromhex(c["im"]["f64"])] for c in s["omega"]]
print("Observation sample keys:",list(obs["samples"][0]))
checks["retained_states_match_parent"]=all(omega(p)==s["omega"] for p,s in zip(parent["samples"],obs["samples"]))
module={x["path"]:x["sha256"] for x in parent["implementation"]["modules"]}
checks["consulted_native_formula_identities"]=all(source[k]["sha256"]==module["kernel_physics/"+f] for k,f in [("dynamics","dynamics.py"),("z","z_manifold.py"),("readouts","readouts.py")])
historical_records={"parent_claim":module["kernel_physics/_records.py"],"current_file":source["records"]["sha256"],"same_bytes":source["records"]["sha256"]==module["kernel_physics/_records.py"],"meaning":"The parent names a historical producer revision, not this checkout. The current serialization helper was read only for its canonicalization/digest definition; its whole-file hash is not asserted to identify the historical producer. No validator or producer was executed."}
previous=ROOT/"INTEGRITY.json"
if previous.exists() and not (ROOT/"logs/initial_gate_overconstraint.json").exists():
    (ROOT/"logs/initial_gate_overconstraint.json").write_bytes(previous.read_bytes())
result={"checks":checks,"all_passed":all(checks.values()),"historical_serialization_source":historical_records,"initial_gate_correction":"Initial gate overconstrained the current _records.py to equal the historical producer. The packet explicitly distinguishes historical revision from current checkout. Actual required seals, parent bytes, native states, observer source and consulted native formulas all match. No scientific mismatch waived.","parent_file_sha256":sha(parentraw),"parent_canonical_sha256":sha(canonical(parent)),"scope":"Content integrity and explicit retained-state/source linkage only; no producer authentication, Core validator execution or native scientific replay."}
(ROOT/"INTEGRITY.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result,indent=2))
if not result["all_passed"]: raise SystemExit("STOP: input admission mismatch")
(ROOT/"INITIAL_STATE_LEDGER.json").write_text(json.dumps({"status":"Admitted copied values before movement calculations","parent":obs["parent"],"config":obs["config"],"frozen_clock":obs["frozen_clock"],"samples":obs["samples"]},indent=2),encoding="utf-8")
print("Parent serialization definition:")
for i,line in enumerate(rb.decode().splitlines(),1):
    if 142<=i<=150: print(f"{i}: {line}")
