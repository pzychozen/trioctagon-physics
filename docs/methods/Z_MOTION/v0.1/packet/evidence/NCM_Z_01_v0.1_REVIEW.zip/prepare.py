from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,sys
ROOT=Path(__file__).resolve().parent;REPO=Path(r'C:\TORMENT\TRIOCTAGON_new\trioctagon-physics')
def fp(p):
    b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,x):(ROOT/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
zpath=ROOT/'inputs/NCM_Z_01_Codex_Packet_v0.1.zip'
assert fp(zpath)==json.loads((ROOT/'ENVIRONMENT.json').read_text())['input_zip']
with zipfile.ZipFile(zpath) as z:
    manifest=json.loads(z.read('PACKET_MANIFEST.json'))
    inv=json.loads((ROOT/'PACKET_INVENTORY.json').read_text())
    assert set(inv)=={r['path'] for r in manifest['packet_entries']}|{'PACKET_MANIFEST.json'}
    for row in manifest['packet_entries']:
        assert inv[row['path']]=={k:row[k] for k in ['bytes','sha256']}
    target=ROOT/'packet';target.mkdir(exist_ok=False)
    for name in inv:
        p=target.joinpath(*PurePosixPath(name).parts)
        assert p.resolve().is_relative_to(target.resolve())
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
standalone=ROOT/'inputs/CODEX_NCM_Z_01_EXISTING_DYNAMICS_FIXED_GEOMETRY_WORK_ORDER_v0.1.md'
assert standalone.read_bytes()==(target/standalone.name).read_bytes(),'Standalone/packet order mismatch'
primary=Path(r'C:\TORMENT\trioctagon_motion_validation_20261029_01\exports\interactive.motion.json')
copy=target/'INPUTS/interactive.motion.json'
want={'bytes':27068,'sha256':'071f6f7dc74128d638b0e96e33897b1366b2f8bcb98ca741c11fe0af5ed0e1e7'}
assert fp(copy)==want
chosen=primary if primary.exists() else copy
assert fp(chosen)==want
(ROOT/'inputs/retained.motion.json').write_bytes(chosen.read_bytes())
backgrounds=[
 (Path(r'C:\TORMENT\trioctagon_motion_validation_20261029_01\WINDOWS_CLOSEOUT.txt'),'REFERENCES/WINDOWS_CLOSEOUT.txt'),
 (ROOT.parent/'NATURAL_CORE_FIXED_SUPPORT_GAP_01/REPORT.md','REFERENCES/NCM_FIXED_GAP_01_REPORT.md')]
bg=[]
for p,rel in backgrounds:
    bg.append({'path':str(p),'present':p.exists(),'packet':rel,
               'identical':p.exists() and p.read_bytes()==(target/rel).read_bytes()})
    if p.exists():assert p.read_bytes()==(target/rel).read_bytes(),'Background copy mismatch'
files={
 'observer':'apps/scientific_ui/src/trioctagon_ui/motion_observer.py',
 'appguide':'apps/scientific_ui/NATURAL_CORE_MOTION_v0.1.md',
 'motion':'papers/NATURAL_CORE_MOTION_CORRESPONDENCE/v0.1/main.tex',
 'central':'papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/manuscript.tex',
 'host':'papers/PAPER_C/publication/v1.0.1/paper_C_final.tex',
 'z':'kernel_physics/z_manifold.py',
 'readouts':'kernel_physics/readouts.py',
 'dynamics':'kernel_physics/dynamics.py',
 'paperE':'papers/PAPER_E/v0.1.1/PAPER_E_Z_MANIFOLD_v0.1.1.md',
 'attachment':'papers/NATIVE_RESPONSE_GEOMETRY/manuscript/observables_closure.tex'}
records={}
for key,rel in files.items():
    p=REPO/rel;assert p.exists(),rel
    records[key]={'path':str(p),**fp(p)}
    lines=p.read_text(encoding='utf8').splitlines()
    (ROOT/'source_reads'/f'{key}.txt').write_text('\n'.join(f'{i+1:04d}: {x}' for i,x in enumerate(lines))+'\n',encoding='utf8')
save('SOURCE_MANIFEST.before.json',records)
save('INPUT_VERIFICATION.json',{'zip':fp(zpath),'manifest_entries_verified':len(manifest['packet_entries']),
 'standalone_matches_packet':True,'retained_primary':str(primary),'primary_present':primary.exists(),
 'selected_observation':str(chosen),'observation':want,'background':bg,'seals':'Pending source-led verification; byte identities alone do not establish scientific replay.'})
data=json.loads(copy.read_text())
print('INPUTS PASS; source files',len(records))
print('OBSERVATION TOP KEYS:',list(data))
print(json.dumps(data,indent=2)[:38000])
