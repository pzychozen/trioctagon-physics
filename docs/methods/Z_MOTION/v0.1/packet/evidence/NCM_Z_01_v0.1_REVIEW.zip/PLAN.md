# Predeclared bounded checks

Only the two retained states at actual indices 0 and 1, plus the saved 0.731-radian display-copy probe, are examined. The parent record is the source of those same states, not a second experiment. No additional retained records will be nominated.

1. Verify input identities, outer/observation/probe seals, parent digest, linkage, stored hexadecimal states and corresponding source identities; reject duplicate JSON keys and nonfinite constants.
2. Reproduce each state's norm, raw chirality, macro, staged readout, scheduled/frozen placements and decoded face vectors from data and source formulas. Compare parent staged readouts separately; allow only recorded rounding-scale differences.
3. Check the native → envelope → clock telescope, intermediate observations and retained attribution, with exact implementation association.
4. Compare fixed-all, changed-state, envelope-only, clock-only and saved common-phase display-copy controls. Do not advance native or EMA state.
5. Reconstruct fixed geometry and six finite broken arcs. Check all six distances, segment endpoint/interior rules, ties and degenerate-segment handling.
6. Distinguish all six finite host notch patches from arcs; check plane/domain membership and directed-ray incidence, including finite-domain rejection.
7. Retain both upper/lower and opposite-view information; verify orthographic projection distances never exceed 3D distances. Use markers only.
8. Test zero-radius, axial azimuth and zero-displacement direction flags; no fallback directions.
9. Use exactly three separate static references: PLUS tau=0, PLUS tau=h, MINUS tau=h. Keep all observed coordinates and placement fixed.
10. Verify bounded source/input preservation and portable archive hashes.

Numerics: independent binary64 formulas with explicit math.fsum/math.hypot and observer evaluation order; optional 80-decimal arithmetic check of real formulas at the exact retained binary64 inputs. Comparison tolerance 2e-13 times max(1,magnitudes); geometry classification/ties use 1e-12 width units. Exact identities are proved algebraically, not inferred from floating-point test counts.
