from pathlib import Path
import sys,re,json
ROOT=Path(__file__).resolve().parent
key=sys.argv[1]
lines=(ROOT/'source_reads'/f'{key}.txt').read_text(encoding='utf8').splitlines()
if len(sys.argv)==2:
    for line in lines:
        if re.search(r'\bdef |^....: (from |import |[A-Z_]{3,}|class )|\\section|\\subsection|seal|sha256|parent|frozen|telescop',line):print(line)
else:
    first,last=int(sys.argv[2]),int(sys.argv[3]);print('\n'.join(lines[first-1:last]))
    with (ROOT/'SOURCE_READS.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps({'key':key,'start':first,'end':last})+'\n')
