"""Check the standalone observer/geometry calculation in an isolated external copy."""
from pathlib import Path
import json,shutil,subprocess,sys,hashlib
ROOT=Path(__file__).resolve().parent
dest=ROOT/"scratch/portable_check_01"
dest.mkdir(parents=True,exist_ok=False)
for folder in ("inputs","figures","mplconfig","source_snapshots"):
    (dest/folder).mkdir()
for name in ("checks.py","INTEGRITY.json","SOURCE_MANIFEST.before.json","INPUT_MANIFEST.before.json","TYPED_CORRESPONDENCE.md","INITIAL_STATE_LEDGER.json"):
    shutil.copyfile(ROOT/name,dest/name)
for name in ("retained.motion.json","parent_run_record.json"):
    shutil.copyfile(ROOT/"inputs"/name,dest/"inputs"/name)
for p in (ROOT/"source_snapshots").iterdir(): shutil.copyfile(p,dest/"source_snapshots"/p.name)
cmd=[sys.executable,"-X","utf8","-I","-B",str(dest/"checks.py"),"--portable"]
with (ROOT/"logs/portable_checks.txt").open("w",encoding="utf-8") as log:
    run=subprocess.run(cmd,cwd=dest,stdout=log,stderr=subprocess.STDOUT,check=False)
assert run.returncode==0,run.returncode
results=json.loads((dest/"checks_results.json").read_text(encoding="utf-8"))
matches={}
for name in ("OBSERVATIONS.json","GAP_COMPARISON.json"):
    matches[name]=(ROOT/name).read_bytes()==(dest/name).read_bytes()
assert all(matches.values()),matches
receipt={"command":cmd,"returncode":run.returncode,"tests_run":results["tests_run"],"all_passed":results["all_passed"],"portable_flag":results["portable"],"derived_json_byte_identity":matches,"meaning":"Independent external copy of this investigation script; no repository modules or native recurrence. Packaged source snapshots checked; not an independent scientific experiment or historical checker replay."}
(ROOT/"PORTABILITY_VERIFICATION.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
(ROOT/"logs/portable_checks_results.json").write_bytes((dest/"checks_results.json").read_bytes())
print(json.dumps(receipt,indent=2))
