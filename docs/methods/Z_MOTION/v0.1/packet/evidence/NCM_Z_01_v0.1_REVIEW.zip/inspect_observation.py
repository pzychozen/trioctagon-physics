from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
d=json.loads((ROOT/'inputs/retained.motion.json').read_text())
out={k:({kk:vv for kk,vv in v.items() if kk not in {'geometry'}} if isinstance(v,dict) else v) for k,v in d.items()}
print(json.dumps(out,indent=2))
