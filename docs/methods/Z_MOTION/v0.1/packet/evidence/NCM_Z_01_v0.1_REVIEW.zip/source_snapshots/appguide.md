# Natural Core Motion - application guide v0.1

**Status: source candidate, 29 October 2026. Windows installation and release
certification are pending.** This guide describes the new source component; it
does not claim that the author's installed application has been replaced.

Entry point: **B - Observers & Diagnostics -> Natural Core Motion**.

The component makes the accepted geometry-to-state correspondence visible in
the existing scientific application. It displays decoded face vectors, their
matched collective mean, conditional Z placement, and the separate contributions
of native state, observer envelope and observer clock. The folded host and the
declared refined PLUS surface at tau=0 remain fixed reference geometry.

The accompanying [research manuscript source](../../papers/NATURAL_CORE_MOTION_CORRESPONDENCE/v0.1/main.tex)
states the mathematical identities and their interpretation. Its research status
is separate from software testing and from any later publication approval.

## Start with an existing native history

1. Create a triad run through the existing Dynamics workflow, or load a Core
   RunRecord through the existing validated loader.
2. Explicitly select that **Core RunRecord** in Records. A historical artifact,
   geometry record or ring run is not an eligible motion source.
3. Open **B - Observers & Diagnostics -> Natural Core Motion**.
4. Keep the default placement scale 1 and axial rotation 0 radians, or enter the
   placement you want to inspect. The scale must be positive and finite; the
   angle must be finite.
5. Press **Analyze selected triad record**.

Analysis uses the stored states. It does not take another native step, resume a
run, change the dynamics draft, or replay an earlier scientific certificate.
Opening the application or the tab does not analyze a record automatically.

This version accepts a source of at most 32,000,000 UTF-8 bytes and 1-4096 stored
samples. It requires three complex channels and strictly increasing actual
update indices. An unsupported record is refused; no samples are silently
dropped. These are application observation limits, not limits on the kernel.

## Read the three views

### Face motion

The left plot places the individual decoded vectors at the accepted face centers:

\[
v_i=D_i(\Omega_i)=\Re\Omega_i\,t_i+\Im\Omega_i\,e_z.
\]

The dashed vectors show the collective complex mean decoded into each face:

\[
m=\frac13\sum_i\Omega_i,\qquad
D_i(m)=\frac13\sum_jT_{ij}D_j(\Omega_j).
\]

The right plot shows the same collective history in its complex-state plane.
The current stored sample is highlighted. Lines join stored samples visually;
they do not supply an interpolating native or material trajectory.

Vector arrows use one display scale selected from the entire analyzed history:
`0.22 / max(abs(Omega_i))`, with 0.22 used for an all-zero history. That scale is
shown on the plot and retained in provenance. It stays fixed while scrubbing or
applying a common-phase probe. The Values tab retains the unscaled decoded
vectors. This display scale is distinct from the conditional Z placement scale.

The fixed host wire has 21 edges from the existing hash-checked inert shell
reference. The central triangles numerically evaluate the declared refined
PLUS tau=0 construction. Neither object is a new fit to the state history.

### Placed Z

The placement is

\[
X=O+\mu_{\mathrm{place}}R_\psi Z,
\qquad O=(0,\sqrt3/6,0).
\]

Both traces use the same stored native states and one fixed placement:

| Trace | Meaning |
| --- | --- |
| Staged display clock | The stated observer angle and decay time advance according to each actual stored update index. |
| Observer frozen at first stored sample | The angle and decay time stay at the first stored sample's scheduled values; changes arise from the native state supplied to the observer. |

The central surface and host do not move with either trace. A point approaching
the center, lying on a surface or appearing near an opening is a statement about
this conditional placement. The view does not infer a material core path,
collision, contact, opening passage or transport law.

The entire history determines fixed equal-axis plotting bounds. Scrubbing does
not renormalize the trace. Camera orientation is preserved during sample changes
and phase-probe application.

### Change accounting

For a selected sample after the first, the bars show the endpoint displacement
split in this order:

1. Change the native state at the preceding observer settings.
2. Change the staged decay envelope at the new state.
3. Change the observer angle at the new state and envelope.

The total, component vectors and reconstruction residual are in the Values tab.
This is an exact algebraic telescoping convention evaluated numerically. It is
not a force decomposition. Its attribution order is part of the definition.

The second plot shows the signed collective increment area

\[
K=\Im\!\left(\overline{\Delta m_{\mathrm{previous}}}\,\Delta m_{\mathrm{current}}\right).
\]

Three stored samples are required. K includes the two increment lengths as well
as their oriented angle; it is not itself an angle. The separate `turn_angle`
value is absent when either increment is zero. Actual update spans are retained,
so an endpoint difference over skipped indices is not labelled a one-step
increment.

## Browse completed observations

Use **Previous**, **Next**, or **Cached sample** in the panel. These controls
stay synchronized with the existing Dynamics sample scrubber. Browsing reads
the completed observation cache; it does not calculate a new observation or
invoke the scientific worker. There is no new animation timer.

**Values** supplies the selected sample's complete numerical quantities, with
round-trip display values and binary64 hexadecimal spellings. It includes the
decoded state, collective state, C, W, Gamma, placement outputs, increments,
attribution and any active probe comparison. W has no direction when it is zero;
the corresponding direction value is absent rather than normalized artificially.

**Definition / provenance** identifies the parent record, its canonical-byte
hash, source commit, observation component, resolved configuration, fixed
geometry, conventions and display scale. These are detached application
observations. They are not new Core records or interval-certified results.

## Use the common-phase probe

Enter an angle in radians and press **Apply phase probe**. The component forms a
display copy of each state by multiplying all three channels by the same
complex phase. It does not run a new native trajectory or alter the parent
record, stored clock, parameter draft or original observation.

The orange overlay makes the distinction visible: decoded face vectors rotate
within their respective planes, while C, W, Gamma and fixed-observer Z remain
invariant in exact arithmetic. The Values tab includes the numerical comparison
residuals. The copy is not assumed to be a native solution, and this operation
does not assert global common-phase equivariance of the recurrence at its zero
stratum.

Editing the phase field removes the previous active probe. Typing an angle alone
does not apply it. **Reset probe** removes the transformed copy and retains the
original completed observation.

## The display observer is separate from recorded observers

This version recomputes a specifically declared staged observer:

| Setting | Value |
| --- | --- |
| alpha, beta | 1, 0.5 |
| lambda_vp, gamma | 0.618, 0.577 |
| lock angle | 0.244 radians |
| Sector count N | 12 |
| q0, q_step | 0, 1 |
| time0, dt | 0, 0.1 |
| Placement defaults | mu_place=1, psi=0 radians |

At actual update index n, the observer uses the sector determined by q0+n*q_step
and time time0+n*dt. The frozen trace uses the schedule at the first stored
sample, even when that sample starts at a nonzero update index.

The first stored sample is recomputed under this display definition. It is not
silently replaced by a historical constructor-zero observer value. Recorded
staged and EMA observers remain available in the existing application workflow;
their values and memory are unchanged. This panel does not combine the staged
and EMA laws. Observer time is not a dynamics timestep or a physical clock.

Only placement scale and rotation are editable in this panel version. The
remaining displayed constants are explicit component defaults, not inferred
native coefficients or a newly selected physical calibration.

## Source, edit and export guards

- Changing placement inputs marks the retained view as requiring analysis and
  disables phase application and export until successful analysis.
- Selecting another record, geometry or artifact preserves the completed cache
  with a visible source qualification. It does not rebind that cache to the new
  selection. Explicit Core selection is required before another analysis.
- A failed request preserves the previous completed observation and reports the
  failure. Nonfinite values and unrepresentable arithmetic results are refused.
- Opening another plot or browsing a cached sample does not change its source,
  placement or observer configuration.

**Export observation JSON** writes the completed observation and, when active,
its matching phase probe. The export contains the source identity, exact
configuration, cached values, formula/source conventions, component-source hash
and content digest. It uses the existing no-overwrite Windows publication route;
an occupied destination is refused. It does not save a Core RunRecord or import
the observation into the native continuation history.

Cancelling the file dialog writes nothing. A change in source, settings,
observation or phase probe while the dialog is open cancels publication. Export
failure leaves the completed cache available for inspection.

## Implementation and verification scope

`motion_observer.py` computes the bounded passive correspondence using the Python
standard library. `motion_panel.py` manages explicit selection, completed caches
and export. `motion_view.py` renders cached quantities. The existing `app.py`
adds the tab and guarded sample/context hooks. The kernel, worker protocol,
installed artifact locks and native recurrence are unchanged.

This is a separately identified application-level observation, following the
existing static shell observer's separation from Core state. It is not a new
public kernel capability and does not inherit the previous release's scientific
or installation certification.

The current source-candidate checks are:

| Check | Recorded scope |
| --- | --- |
| Component and mathematical checks | 23 passing tests of correspondence, numerical admission, invariance, attribution and isolation. |
| Native Qt panel checks | 13 passing tests, including explicit-only calculation, cached browsing, guards, exports, accessibility, camera preservation and synchronous rendering of all three plots with and without a probe. |
| Main-window smoke | Real MainWindow and an existing Core fixture; a test-only installed-kernel-lock stub was used. The dynamics draft stayed unchanged and no job started. This was not installed-lock certification. |
| Runtime | Linux, Python 3.12.14, PySide6 6.11.2, Matplotlib 3.10.8. |
| Pending | Windows CPython 3.11 validation of the actual locked application/kernel pair and real Windows export publication. |

These counts are software checks, not theorem counts. The research draft supplies
the written mathematical arguments. This component introduces no material pose
law, geometry-to-native feedback, force calibration or new gravity/magnetism
identification. Source integration, Windows acceptance, and any publication or
package release remain separate dispositions.
