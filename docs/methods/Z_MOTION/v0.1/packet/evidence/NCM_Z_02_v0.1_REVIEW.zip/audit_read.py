"""Inert scoped text/index reader. Candidate state data uses a separate bounded reader."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
mode=sys.argv[1]
manifest=ROOT/"PROTECTED.before.json"
items=json.loads(manifest.read_text(encoding="utf-8"))
def track(p):
    b=p.read_bytes(); digest=hashlib.sha256(b).hexdigest()
    if p.resolve().is_relative_to(ROOT): return b
    old=next((x for x in items if x["path"]==str(p)),None)
    if old: assert old["sha256"]==digest
    else:
        name=f"sources/{len(items):03d}_{p.name}"
        (ROOT/name).write_bytes(b)
        items.append({"path":str(p),"bytes":len(b),"sha256":digest,"copy":name,"role":"metadata/source text read only"})
        manifest.write_text(json.dumps(items,indent=2)+"\n",encoding="utf-8")
    return b
if mode=="inventory":
    base=Path(sys.argv[2])
    excluded={"runtime","build-env","cache","build-source","recovery","mplconfig","tmp","publication_work","__pycache__"}
    result=[{"path":str(p),"bytes":p.stat().st_size} for p in base.rglob("*") if p.is_file() and not excluded.intersection(p.relative_to(base).parts) and p.suffix.lower() in (".json",".csv",".npz",".zip",".md",".txt",".py")]
    target=ROOT/"logs"/("inventory_"+base.name+".json")
    target.write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
elif mode=="archive":
    p=Path(sys.argv[2]); b=track(p)
    with zipfile.ZipFile(p) as z:
        print(json.dumps([{"path":i.filename,"bytes":i.file_size} for i in z.infolist()],indent=2))
else:
    p=Path(sys.argv[2]); b=track(p)
    text=b.decode("utf-8-sig"); lines=text.splitlines()
    if mode=="read":
        lo=int(sys.argv[3]) if len(sys.argv)>3 else 1;hi=int(sys.argv[4]) if len(sys.argv)>4 else min(len(lines),180)
        chosen=range(lo-1,min(hi,len(lines)))
    elif mode=="find":
        terms=[s.lower() for s in sys.argv[3:]]
        chosen=sorted({j for i,line in enumerate(lines) if any(t in line.lower() for t in terms) for j in range(max(0,i-1),min(len(lines),i+2))})
    else: raise ValueError(mode)
    with (ROOT/"logs/SOURCE_READS.jsonl").open("a",encoding="utf-8") as f: f.write(json.dumps({"utc":datetime.now(timezone.utc).isoformat(),"path":str(p),"mode":mode,"arguments":sys.argv[3:]})+"\n")
    print("SOURCE",p)
    for i in chosen: print(f"{i+1:04d}: {lines[i]}")
