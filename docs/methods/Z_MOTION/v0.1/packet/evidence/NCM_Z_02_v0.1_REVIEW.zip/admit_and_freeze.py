"""Admit stored values and freeze an outcome-independent plan. No observer calls."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal
import hashlib,json,math,zipfile
ROOT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads((ROOT/p).read_text(encoding="utf-8"))
def write(p,v): (ROOT/p).write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")
assert not (ROOT/"ADMISSION_AND_PLAN.json").exists(),"Plan is immutable; refuse replacement"
inv=load("CANDIDATE_INVENTORY.json")
old=load(inv["artifacts"][0]["copy"])
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
assert sha(canonical({k:v for k,v in old.items() if k not in ("deterministic_sha256","execution_metadata")}))==old["deterministic_sha256"]
assert [int(v["update_index"]) for v in old["samples"]]==[0,1]
assert sha((ROOT/"packet/inputs/NCM_Z_01_PARENT_RUN_RECORD.json").read_bytes())==inv["artifacts"][0]["sha256"]
chosen=inv["artifacts"][2]; raw=(ROOT/chosen["copy"]).read_bytes()
assert sha(raw)==chosen["sha256"]
record=json.loads(raw); rows=record["observations"]
indices=[v["n"] for v in rows]
assert len(rows)>=3 and all(type(n) is int and n>=0 for n in indices)
assert all(x<y for x,y in zip(indices,indices[1:]))
for v in rows:
    assert len(v["omega"])==3
    for pair in v["omega"]:
        assert len(pair)==2 and all(isinstance(t,str) and Decimal(t).is_finite() for t in pair)
        assert all(math.isfinite(float(t)) for t in pair)
assert record["backend"]=="mpmath" and record["decimal_precision"]==120 and indices==[0,1,2,3,4]
# Verify available outer artifact hashes, never re-run the archived producer.
manifest=load("sources/arch_OUTPUT_HASH_MANIFEST.json")
entries=manifest.get("files",manifest.get("entries"))
assert isinstance(entries,list),manifest.keys()
byname={v["path"]:v for v in entries}
assert byname["NOMINAL_CROSSCHECK.json"]["sha256"]==sha(raw)
checked=[]
for name in ("verification.py","audit.py","supplement.py","ENVIRONMENT_AND_REPLAY.md","logs/audit-console.txt","INDEPENDENT_NUMERICAL_AUDIT_REPORT.md"):
    archived=ROOT/"sources"/("arch_"+name.replace("/","_"))
    if archived.exists():
        b=archived.read_bytes()
    else:
        zip_path=chosen["locators"][0].split("!")[0]
        with zipfile.ZipFile(zip_path) as z:b=z.read(name)
        archived.write_bytes(b)
    assert len(b)==byname[name]["bytes"] and sha(b)==byname[name]["sha256"]
    checked.append({"member":name,"sha256":sha(b),"copy":str(archived.relative_to(ROOT))})
inv["artifacts"][0].update(status="EXCLUDED_TOO_SHORT",reason="Two states at indices 0 and 1; no continuation in the inspected Windows record/fixture inventory",integrity="canonical/file identity and deterministic digest verified",rank_if_longer=1)
inv["artifacts"][1].update(status="EXCLUDED_NOT_HISTORY",reason="55-byte overwrite-protection sentinel, not JSON or scientific samples")
chosen.update(status="ADMITTED_SELECTED",reason="Five stored native triad states from the documented prior 120-digit nominal producer, at fixed parameters, with manifest-bound source and execution account",selection_rank=3,source_route_position=1,internal_content_seal="none; file member size/SHA-256 verified against historical OUTPUT_HASH_MANIFEST")
inv["metadata_exclusions"]=[
    {"locator":"Windows exports/interactive.motion.json and natural-motion.motion.json","reason":"Known identical two-state detached observations; no additional independent history. Packet original copy already verified."},
    {"locator":"central manuscript and R6 rational comparison-center tables","reason":"Explicitly enclosure comparison centers, not stored native history. Rejected by source description; not decoded as candidate state data."},
    {"locator":"central audit AUDIT_RESULTS.json and tmp/direct_enclosures.json","reason":"Interval proof/enclosure artifacts, not selected as point history; not read as candidate state data."}
]
inv["selection_stop"]="First eligible history in ordered A1 route after no longer old-run continuation/old initialization match in the Windows fixture route. No candidate selected on opening results; later lower-priority route directories were filename-listed only, no state data inspected. No search after freeze."
write("CANDIDATE_INVENTORY.json",inv)
(ROOT/"inputs/SELECTED_HISTORY.json").write_bytes(raw)
ledger={"representation":"100-significant-digit decimal output strings (mp.nstr(...,100)) from a documented 120-decimal-digit mpmath producer. Tokens retained unchanged; they are rounded numerical values, not exact native solutions or interval enclosures.","initialization_source":"sources/arch_verification.py lines 124–134; explicit original radical/basis construction, not manuscript comparison centers","native_parameter_tokens":{"epsilon":".1","g":".2","lambda_phase":".17","k":["2","3","4"]},"indices":indices,"rows":[{"ordinal":i,"native_update_index":v["n"],"omega_original_decimal_tokens":v["omega"],"binary64_overlay_inputs":[[float(t) for t in pair] for pair in v["omega"]],"binary64_hex":[[float(t).hex() for t in pair] for pair in v["omega"]]} for i,v in enumerate(rows)]}
write("ORIGINAL_TOKEN_LEDGER.json",ledger)
plan={"task":"NCM-Z-02 v0.1","frozen_utc":datetime.now(timezone.utc).isoformat(),"status":"ADMITTED; definitions and window frozen before opening calculations","candidate_inventory":inv,"selected":{"source_locator":chosen["locators"][0],"file_sha256":sha(raw),"bytes":len(raw),"packaged_copy":"inputs/SELECTED_HISTORY.json","record_description":"NOMINAL_CROSSCHECK mpmath native-triad nominal sequence; not a modern Core record","source_lineage":{"historical_source_revision_locator":"3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34","data_producer":"verification.py:nominal_crosscheck, lines 120–171; called and serialized by audit.py lines 551–552","original_precision_dps":120,"output_precision_significant_digits":100,"fixed_coefficients":ledger["native_parameter_tokens"],"prior_execution_account":"INDEPENDENT_NUMERICAL_AUDIT_REPORT.md line 99; ENVIRONMENT_AND_REPLAY.md lines 38–45; logs/audit-console.txt line 7","source_members_verified":checked},"comparison_to_Z01":"Different initialization and native coefficients: epsilon .1 instead of .05, phase .17 instead of .001, k=(2,3,4) instead of (1,1,1); g=.2 shared. Not an extension or same-parameter replication.","evidence_limits":"Retained nominal numerical producer values with file integrity and source account; not producer authentication, a new native replay certificate, exact ideal-map solutions or propagated certified intervals."},"window":{"all_original_indices":indices,"included_indices":indices[:4096],"original_rows":len(rows),"included_rows":min(4096,len(rows)),"excluded_suffix_rows":max(0,len(rows)-4096),"rule":"all rows if <=4096; otherwise earliest 4096 stored rows; no reindexing"},"observer":{"N":12,"q0":0,"q_step":1,"time0":0.0,"dt":0.1,"lambda_vp":0.618,"gamma":0.577,"lock_angle":0.244,"alpha":1.0,"beta":0.5,"mu_place":1.0,"psi":0.0},"freeze_anchor":{"actual_native_index":indices[0],"rule":"scheduled angle/time of first included sample; here theta=time=0"},"geometry":{"branch":"PLUS","tau":0,"width":1,"origin":"(0,sqrt(3)/6,0)","sphere":"sqrt(13/12-sqrt(2)/2)","six_arc_labels":["G+0","G+1","G+2","G-0","G-1","G-2"],"finite_notches":"Separate N+0..N+2,N-0..N-2"},"numeric":{"primary":"binary64 detached overlay from explicitly converted retained tokens; source observer operation order; exact original tokens retained","independent":"80-decimal formulas from original decimal state tokens, exact binary64 coefficient constants lifted to high precision, exact pi/radical geometry","geometry_tie_tolerance":1e-12,"reproduction_tolerance":"2e-13*max(1,magnitudes)","unique_winner":"lead over second-best >1e-12; preserve tied sets and compare independent high-precision decision","direction":"exact zero undefined; displacement norm <=1e-12 classified numerically unresolved for chord-angle diagnostics without setting its actual value to zero","borderline":"within 10*1e-12 of a geometry/tie/zero threshold; high precision comparison, no interval claim","robustness":"unique frozen winner and numerical slack m-2*b-4e-12>0; allowance is heuristic, not rigorous error enclosure"},"evaluation_limits":{"native_map_calls":0,"ema_advances":0,"histories":1,"primary_points":2*len(rows),"telescope_intermediate_points":2*(len(rows)-1),"high_precision":"All 18 primary/intermediate evaluations, covering every mandatory switch/disagreement/borderline and first/middle/last case; no extra settings","geometry_sensitivity_cases":0,"regression_fixture":"Old two-state input once per script run, separate from primary result counts","figures_max":4},"tests":["packet/source input integrity","prior two-state regression","global vs local freeze","sparse actual indices","ordered telescope","six labels and opposite cameras","common-phase frozen invariance","segment endpoints/ties","zero/axis and zero displacement","positive/negative and inconclusive robustness margins","independent 80-decimal point/distances/classifications","original source/input preservation"],"no_outcome_calculation_before_this_receipt":True}
write("ADMISSION_AND_PLAN.json",plan)
write("ADMISSION_FREEZE_RECEIPT.json",{"frozen_utc":plan["frozen_utc"],"plan_sha256":sha((ROOT/"ADMISSION_AND_PLAN.json").read_bytes()),"selected_input_sha256":sha(raw),"token_ledger_sha256":sha((ROOT/"ORIGINAL_TOKEN_LEDGER.json").read_bytes()),"candidate_inventory_sha256":sha((ROOT/"CANDIDATE_INVENTORY.json").read_bytes()),"movement_calculations_started":False})
print(json.dumps({"selected":chosen,"indices":indices,"native_parameters":ledger["native_parameter_tokens"],"freeze":load("ADMISSION_FREEZE_RECEIPT.json")},indent=2))
