"""Bounded inert candidate reader; never computes an observer or opening outcome."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import sys,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
store=ROOT/"CANDIDATE_INVENTORY.json"
inv=json.loads(store.read_text()) if store.exists() else {"limit_distinct":12,"limit_each_bytes":33554432,"limit_total_bytes":134217728,"artifacts":[]}
p=Path(sys.argv[1]);member=sys.argv[2] if len(sys.argv)>2 else None
if member:
    with zipfile.ZipFile(p) as z:
        info=z.getinfo(member);pp=PurePosixPath(member)
        assert not pp.is_absolute() and ".." not in pp.parts and "\\" not in member
        assert info.file_size<=inv["limit_each_bytes"]
        raw=z.read(member)
else:
    assert p.stat().st_size<=inv["limit_each_bytes"]
    raw=p.read_bytes()
digest=hashlib.sha256(raw).hexdigest()
old=next((v for v in inv["artifacts"] if v["sha256"]==digest),None)
locator=str(p)+("!"+member if member else "")
if old:
    if locator not in old["locators"]: old["locators"].append(locator)
    entry=old
else:
    assert len(inv["artifacts"])<inv["limit_distinct"]
    assert sum(v["bytes"] for v in inv["artifacts"])+len(raw)<=inv["limit_total_bytes"]
    name=f"inputs/candidate_{len(inv['artifacts'])+1:02d}_{Path(member or p.name).name}"
    (ROOT/name).write_bytes(raw)
    entry={"candidate_id":len(inv["artifacts"])+1,"locators":[locator],"bytes":len(raw),"sha256":digest,"copy":name,"read_utc":datetime.now(timezone.utc).isoformat(),"status":"pending independent admission; no Z/opening calculations"}
    inv["artifacts"].append(entry)
inv["distinct_artifacts_read"]=len(inv["artifacts"]);inv["total_candidate_bytes"]=sum(v["bytes"] for v in inv["artifacts"])
store.write_text(json.dumps(inv,indent=2)+"\n",encoding="utf-8")
prot=ROOT/"PROTECTED.before.json"; entries=json.loads(prot.read_text())
if not member and not any(x["path"]==str(p) for x in entries):
    entries.append({"path":str(p),"bytes":len(raw),"sha256":digest,"copy":entry["copy"],"role":"candidate native data"})
    prot.write_text(json.dumps(entries,indent=2)+"\n",encoding="utf-8")
def shape(v,depth=0):
    if isinstance(v,dict): return {k:shape(x,depth+1) for k,x in v.items()} if depth<3 else {"keys":list(v)}
    if isinstance(v,list):return {"list_length":len(v),"first_item_structure":shape(v[0],depth+1) if v else None}
    if isinstance(v,str): return v if len(v)<150 else v[:90]+"..."
    return v
print(json.dumps(entry,indent=2))
try:
    data=json.loads(raw); print(json.dumps(shape(data),indent=2))
except (ValueError,UnicodeDecodeError):print("Not JSON; raw preview:",repr(raw[:200]))
