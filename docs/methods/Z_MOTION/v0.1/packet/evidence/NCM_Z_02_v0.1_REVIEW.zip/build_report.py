"""Format already-calculated ledgers into the bounded review report."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads((ROOT/p).read_text(encoding="utf-8"))
def save(p,v):(ROOT/p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
def text(p,s):(ROOT/p).write_text(s,encoding="utf-8")
def f(x):return "undefined" if x is None else f"{x:.9f}"
def vec(x):return "("+", ".join(f(v) for v in x)+")"
def table(h,rows):return "\n".join(["| "+" | ".join(h)+" |","| "+" | ".join("---" for _ in h)+" |"]+["| "+" | ".join(map(str,row))+" |" for row in rows])+"\n"
obs=read("OBSERVATIONS.json");g=read("GAP_COMPARISON.json");tr=read("TRANSITIONS.json");at=read("ATTRIBUTION.json");hp=read("HIGH_PRECISION.json")
plan=read("ADMISSION_AND_PLAN.json");rec=read("ADMISSION_FREEZE_RECEIPT.json");checks=read("checks_results.json");ev=g["evaluations"];indices=obs["summary"]["indices"]
primary=[ev[f"{mode}{n}"] for n in indices for mode in ("F","S")]
on_arcs=[(v["id"],a["label"]) for v in primary for a in v["gap"]["arcs"] if a["on_boundary_within_tolerance"]]
on_patches=[(v["id"],p["label"]) for v in primary for p in v["gap"]["host_notches"] if p["point"]["point_member"]]
rayhits=[(v["id"],p["label"]) for v in primary for p in v["gap"]["host_notches"] if p["ray"]["hit"]]
maxhp=max(x for v in hp["evaluations"] for x in v["binary64_abs_residuals"].values())
maxres=max(abs(x) for v in at["intervals"] for x in v["residual"])
source={"authority":"Accepted NCM-Z-01 byte-bound snapshots; no current HEAD assertion or historical-data repair","sources":read("ACCEPTED_SOURCES.json")["files"],"selected_lineage":plan["selected"],"bounded_original_reads":read("PROTECTED.before.json"),"source_read_trace":"logs/SOURCE_READS.jsonl","archive_member_read_trace":"logs/ARCHIVE_SOURCE_READS.jsonl"}
save("SOURCE_MANIFEST.json",source)
qa={"utc":datetime.now(timezone.utc).isoformat(),"numerical":{"tests_passed":checks["tests_run"],"retained_native_rows":len(indices),"primary_evaluations":10,"telescope_intermediates":8,"hp_evaluations":18,"hp_label_disagreements":obs["summary"]["high_precision_classification_disagreements"],"max_hp_binary64_abs_discrepancy":maxhp,"max_telescope_abs_residual":maxres,"primary_on_arc_tolerance_flags":on_arcs,"primary_finite_notch_memberships":on_patches,"primary_outward_ray_notch_hits":rayhits},"visual":{"file_view_inspection":True,"application_gui_review":False,"sheets":3,"all_points_included":True,"marker_only_spatial_plots":True,"shared_limits":True,"both_camera_sides":True,"all_six_boundaries":True,"finite_patches_separate":True,"correction":"Darkened numeric labels for legibility, separated close labels in side view and shortened an index-panel title. No numerical definitions, data, window or outcomes changed.","limitation":"Several frozen markers overlap because their projected positions are close. All are retained; exact coordinates and distances remain in the ledgers."}}
save("QA_RECORD.json",qa)
summary="""# NCM-Z-02 v0.1 — retained-history answer

**No nearest-opening switch survives freezing in the selected five-state window.** Frozen Z stays nearest G+0 at indices 0, 1, 2, 3 and 4. Scheduled Z has three resolved endpoint switches: G+0 → G−2 at 1→2, G−2 → G−0 at 2→3, and G−0 → G+1 at 3→4. In the specified native → envelope → clock accounting, each switch occurs at the clock replacement.

The admitted input is the already-saved NOMINAL_CROSSCHECK.json from the central-geometry numerical audit: five full triad states and four consecutive spans. It was computed previously at 120-decimal precision and saved as up to 100-significant-digit strings. Its file and source-member hashes match the historical manifest. This is a different initialization and fixed native parameter tuple from NCM-Z-01, not a continuation of that two-state fixture.

The entire 0–4 window, preset, geometry and tolerances were frozen in ADMISSION_AND_PLAN.json before opening calculations. Three distinct candidate artifacts totaling 19,361 bytes were read. No native states were generated or reconstructed.

The frozen points still change position and chord direction. Their radius decreases through index 3, then increases at index 4. From 1→2 the frozen point moves closer to the center while becoming farther from its nearest boundary. An unchanged nearest label is a coarse result, not stationary native behavior.

All ten primary F/S placements lie inside the original enclosing sphere. None lies on a central boundary or finite notch patch. The outward ray through F1 hits N+0; this is a direction test, not a point contact or passage. There are no unresolved nearest-arc ties or high-precision classification disagreements. This short, deliberately constructed historical nominal example does not establish behavior for other states, parameters or longer windows.

"""
summary+=f"Validation: **{checks['tests_run']} assertions passed**, all 18 primary/intermediate readouts checked with independent 80-decimal formulas, and five numerical ledgers reproduced byte-for-byte in a separate packaged-input run. Ten monitored original files remain unchanged. The margin condition m>2||S−F|| supplies a numerical stability diagnostic at indices 0 and 1; failure at the later indices is inconclusive by itself.\n\n"
summary+="""- [Full report](REPORT.md), [frozen admission plan](ADMISSION_AND_PLAN.json), [identity/time receipt](ADMISSION_FREEZE_RECEIPT.json)
- [Top view](figures/01_top.png), [opposite side views](figures/02_opposite_sides.png), [complete index diagnostics](figures/03_index_diagnostics.png)
- [Observation ledger](OBSERVATIONS.json), [all six boundaries and notches](GAP_COMPARISON.json), [every transition](TRANSITIONS.json), [ordered attribution](ATTRIBUTION.json)
- [Standalone calculation](analyze.py), [tests](checks_results.json), [80-decimal comparisons](HIGH_PRECISION.json), [portable verification](PORTABLE_VERIFICATION.json)

Command Prompt and the existing torment environment were used offline. Native evaluations: zero. EMA updates: zero. No Git, model/application/kernel edits, new motion law or publication. The investigation stops here.
"""
text("START_HERE.md",summary)
report=r"""# NCM-Z-02 v0.1 — frozen versus scheduled retained-history Z

## Answer

The admitted window contains five retained native-triad states at actual indices 0–4, giving four consecutive spans. Frozen staged Z stays nearest **G+0 at all five endpoints**. Scheduled staged Z has **three resolved endpoint-label switches**. All three occur at the clock replacement in the required native → envelope → clock telescope. There are no primary nearest-label ties or precision disagreements. These are endpoint facts about a declared spatial readout, not continuous crossings or a material motion law.

## Admission before outcomes

The work order was read separately and checked against the ZIP copy. All 14 manifest-listed packet entries passed. The supplied NCM-Z-01 review archive has the prescribed SHA-256 and its 73 payload entries were checked without running its helpers. Its byte-bound definitions supplied the observation and geometry; the prior full study was not executed.

The read-only route began in the named Windows validation directory. Its fixture/export inventory and closeout identify only the old two-state record; the other export is an overwrite-protection sentinel. The first next evidence route, the central-geometry v0.3 source index, explicitly identifies its saved numerical audit archive. Its report describes a separate 120-decimal nominal calculation of the exact nominal starting state and four native images. NOMINAL_CROSSCHECK.json retains all six real state components at each of those indices.

The central manuscript/R6 rational comparison centers were rejected as substitutes. The selected data instead come from the independently retained nominal producer output. The archived verification.py, read as text, constructs the starting state from its radical/basis definition, fixes epsilon=.1, g=.2, lambda_phase=.17 and k=(2,3,4), iterates four times, and writes the five full states. Audit.py calls that function and serializes its returned object. The retained console log and report account for that earlier execution. No part of that producer was run or transcribed as an executable native evaluator in this task.

Source locators: [source/evidence index](sources/003_SOURCE_ACCESS.md), [prior audit report](sources/006_INDEPENDENT_NUMERICAL_AUDIT_REPORT.md), [producer text, lines 120–171](sources/arch_verification.py), [caller text, lines 551–552](sources/arch_audit.py), [prior execution account](sources/arch_ENVIRONMENT_AND_REPLAY.md), [prior console log](sources/arch_logs_audit-console.txt).

"""
report+=table(["Candidate","Bytes","Decision"],[[v["candidate_id"],v["bytes"],v["status"]+": "+v["reason"]] for v in plan["candidate_inventory"]["artifacts"]])
report+="""
Three distinct candidate artifacts totaling 19,361 bytes were inspected, below the 12-artifact, 32 MiB each, 128 MiB total limits. Known byte-identical old exports are one two-state observation, not independent histories. Interval result boxes were not converted to midpoints. The manifest route first yields this eligible nominal history; it was selected at rank 3 after the old-run continuation/initialization route did not supply a qualifying longer record. No equally ranked eligible competing history was admitted, so the tie-breakers did not select by outcomes. Later named route directories were filename-listed initially, but their state data were not read; the search stopped at admission. This is a bounded route result, not an assertion that no other history exists anywhere.

The historical nominal initial state was constructed for the earlier geometry investigation. It is not a random or representative draw. That inherited construction is disclosed; selection here used provenance and source-route order, not its new nearest-opening outcomes.

"""
report+=table(["Frozen item","Value"],[
["Selected member","NOMINAL_CROSSCHECK.json"],
["Selected member size / SHA-256",str(plan["selected"]["bytes"])+" / "+plan["selected"]["file_sha256"]],
["Source archive SHA-256","959aff5caf6b617565e1b059035f5254046a39bdd93c875706008978a869e90b"],
["Plan frozen UTC",plan["frozen_utc"]],
["ADMISSION_AND_PLAN.json SHA-256",rec["plan_sha256"]],
["Included actual indices","0, 1, 2, 3, 4; entire history; excluded suffix 0"],
["Native coefficient tokens","epsilon=.1; g=.2; lambda_phase=.17; k=(2,3,4)"],
["Native-map calls / EMA updates","0 / 0"]])
report+="""
NCM-Z-01 instead used epsilon=.05, g=.2, phase_strength=.001, k=(1,1,1), and a different starting state. Consequently this is a new retained example, not a same-lineage extension or same-configuration replication.

Original values are in [the immutable selected copy](inputs/SELECTED_HISTORY.json) and [the original-token ledger](ORIGINAL_TOKEN_LEDGER.json). The record has no internal Core content seal; its member size and SHA-256, plus the selected producer/caller/report/log members, match the historical OUTPUT_HASH_MANIFEST.json. The old regression parent also matches its prescribed bytes and inert deterministic digest. Integrity and a source account do not authenticate a producer or newly certify ideal native evolution. The nominal record explicitly labels itself NUMERICAL_CORROBORATION_ONLY. Its enclosure-agreement flags are inherited, not freshly proved here.

## Definitions, fixed geometry and numerical meaning

Native Omega is the saved complex triad. It is not altered, rephased, normalized, interpolated or stepped. The state-to-observation chain uses

"""
report+=r"""
\[
\kappa=\|\Omega\|,\quad C=\Re\Omega\times\Im\Omega,\quad
K=\lambda_{\rm vp}\frac{\kappa}{1+\kappa},\quad
E(t)=e^{-\gamma t},\quad
H_\theta=\cos(3(\theta-\ell))(\cos\theta,\sin\theta,1),
\]
\[
M=KEH_\theta,\quad Z=\alpha M+\beta C,\quad
X=O+\mu R_\psi Z.
\]

The unchanged observer preset is N=12, q0=0, q_step=1, time0=0, dt=0.1, lambda_vp=0.618, gamma=0.577, lock_angle=0.244 radians, alpha=1, beta=0.5, mu=1, psi=0. These observer coefficients differ in role from the native tuple. The literal 0.618 retains binary64 source semantics; no exact inverse golden ratio or controller was substituted.

For actual saved index n, q=(q0+n*q_step) mod N, theta=2*pi*q/N and t=time0+n*dt. Frozen F_n uses the first included index n*=0, hence theta*=t*=0. Scheduled S_n uses each actual n. Integer q is computed before angle evaluation. No sample ordinal substitutes for n; late and sparse schedules are tested separately. F_n and S_n are simultaneous readout alternatives of the same state, not successive native positions. The native recurrence has no feedback from these observations.

Geometry is fixed PLUS tau=0, width one, centered at O=(0,sqrt(3)/6,0). With r=sqrt(3)/6, d=1−sqrt(2)/2, a=d/2, h=(sqrt(2)−1)/2 and e_i=(cos(−pi/2+i*pi/3),sin(−pi/2+i*pi/3)), the upper broken arc is
G+k = U_k—T_(2k+1)—U_(k+1), where U_k=(r e_(2k),1/2), T_i=(a e_i,h). Lower arcs replace positive heights with their negatives at tau=0. All six compete. No filled aperture interior, aperture normal or flux is invented. No tau/branch/pose sensitivity scan was performed.

The separate finite host notch is
N_(k,sigma)(lambda,zeta)=(2r−sqrt(3)d*lambda/2)g_k+zeta*Jg_k+sigma(h+d*lambda)e_z,
0≤lambda≤1, abs(zeta)≤d*lambda/2, g_k=e_(2k+1). Its carrier plane alone is insufficient: both plane and finite barycentric domain are tested. The passive original enclosing sphere has radius sqrt(13/12−sqrt(2)/2)≈0.6133730937584284.

Definitions are from [observer.py](accepted_sources/observer.py), lines 184–204, 262–276 and 305–369; [central.tex](accepted_sources/central.tex), lines 181–224 and 331–373; [host.tex](accepted_sources/host.tex), lines 235–242 and 283–285. Complete source identities are in SOURCE_MANIFEST.json. Accepted snapshots are used, not an assumed current Git HEAD. No current-source repair or source substitution was made.

Primary computation explicitly converts the retained decimal strings to binary64 for the detached application-style overlay, retaining the original strings and conversion hex tokens. The historical producer used 120 decimal working digits but stored up to 100 significant digits; “120 digits” is not a claim of 120 retained digits. Independent 80-decimal calculations parse the original strings directly, lift the binary64 observer coefficient constants exactly, and use high-precision pi/radicals and independently written segment/patch formulas. These checks assess readout/classification stability without reconstructing any native state.

The historical record's saved Z used its own ideal-decimal formula. Its values are compared separately within 2e-13*max(1,magnitudes), not relabeled as bit-identical application readouts. High-precision state/output values are not certified state intervals. Geometry/tie tolerance is 1e-12 width units. All 18 primary/intermediate evaluations received high-precision comparison, covering the required switch endpoints, S/F disagreements, borderline tests and first/middle/last samples. No scheduled envelope underflow or nonfinite output occurred.

"""
report+=f"Largest binary64-versus-80-decimal discrepancy across computed state/readout coordinates and arc distances: **{maxhp:.17g}**. Largest telescope residual component: **{maxres:.17g}**. No precision comparison changed a nearest-label decision. The 4e-12 robustness allowance is heuristic screening, not a proven error enclosure.\n\n"
report+="## Complete endpoint results\n\nAll measurements below use host width units and centered coordinates; world X adds O. All ten primary points are inside the original sphere. “Inside the sphere” does not assert membership in a material core.\n\n"
report+=table(["Point","X−O","radius","height","azimuth °","elevation °","nearest arc","distance","runner-up margin"],[
[v["id"],vec(v["readout"]["centered"]),f(v["spatial"]["radius"]),f(v["spatial"]["height"]),f(v["spatial"]["azimuth_degrees"]),f(v["spatial"]["elevation_degrees"]),", ".join(v["gap"]["winner_set"]),f(v["gap"]["best_distance"]),f(v["gap"]["margin"])] for v in primary])
report+="\nAll six finite-arc distances, not azimuth sectors:\n\n"
report+=table(["Point"]+[a["label"] for a in g["fixed_geometry"]["arcs"]],[[v["id"]]+[f(a["distance"]) for a in v["gap"]["arcs"]] for v in primary])
report+="""
A unique numerical winner requires its lead over the second-best arc to exceed 1e-12, with agreement of the independent high-precision winner set. Otherwise the result is a set/unresolved decision, never a label-order tie break. No primary tie occurred. Segment ties at a shared elbow are retained separately and do not create two different nearest arcs.

"""
report+=table(["Point","nearest segment(s), zero-based","distinct nearest spatial points","nearest point(s)"],[
[v["id"],",".join(map(str,next(a for a in v["gap"]["arcs"] if a["label"]==v["gap"]["unique_winner"])["segment_ties"])),next(a for a in v["gap"]["arcs"] if a["label"]==v["gap"]["unique_winner"])["distinct_nearest_points"],"; ".join(vec(next(a for a in v["gap"]["arcs"] if a["label"]==v["gap"]["unique_winner"])["segments"][j]["nearest"]) for j in next(a for a in v["gap"]["arcs"] if a["label"]==v["gap"]["unique_winner"])["segment_ties"])] for v in primary])
report+=f"\nPrimary point-on-central-boundary flags: {on_arcs or 'none'}. Primary finite-notch point memberships: {on_patches or 'none'}. Primary outward-ray finite-notch hits: {rayhits or 'none'}. Full plane residuals, finite-domain coordinates, carrier-ray parameters, hit reasons and every one of the 60 primary point/patch comparisons are retained in GAP_COMPARISON.json. A ray is a geometric direction test, not an observed path.\n\n"
report+=table(["Point / patch","ray parameter t","centered ray-hit point","finite lambda","finite zeta","point itself a patch member"],[[v["id"]+" / "+p["label"],f(p["ray"]["parameter"]),vec(p["ray"]["point"]),f(p["ray"]["membership"]["lambda"]),f(p["ray"]["membership"]["zeta"]),p["point"]["point_member"]] for v in primary for p in v["gap"]["host_notches"] if p["ray"]["hit"]])
report+="\nThis single forward-ray hit does not establish emission. The finite notch triangle is a separate measurement region, not a filled central opening or material cap. A ray hit and a closest-central-boundary label answer different geometric questions.\n\n"
report+="## Every stored interval and same-index comparison\n\n"
report+=table(["Actual interval","span","Frozen labels","Scheduled labels","category"],[[str(x["from_index"])+"→"+str(x["to_index"]),x["update_span"]," → ".join(",".join(x["frozen"][k]) for k in ("from_labels","to_labels"))," → ".join(",".join(x["scheduled"][k]) for k in ("from_labels","to_labels")),x["category"]] for x in tr["intervals"]])
report+="\nTotals: frozen-only 0; scheduled-only 3; both same ordered labels 0; both different labels 0; neither 1; unresolved/tied 0. Same-index S/F disagreements occur at 2, 3 and 4. No unresolved transition was silently counted as “neither.” The complete ledger also records changes in per-arc segment ties.\n\n"
report+=table(["Interval","Convention","center-radius change","nearest-boundary distance change"],[[f"{x['from_index']}→{x['to_index']}",mode,f(x[mode]["center_radius_change"]),f(x[mode]["nearest_boundary_distance_change"])] for x in tr["intervals"] for mode in ("frozen","scheduled")])
report+="\nDistances to both the old and new winners for every scheduled switch:\n\n"
report+=table(["Interval","Boundary","distance before","distance after","change"],[[f"{x['from_index']}→{x['to_index']}",d["label"],f(d["before"]),f(d["after"]),f(d["change"])] for x in tr["intervals"] if x["scheduled"]["status"]=="switch" for d in x["scheduled"]["old_and_new_winning_boundary_distances"]])
report+="""
For example, F1→F2 moves inward (radius 0.247125→0.229832) while moving farther from G+0 (distance 0.036974→0.060604). The scheduled S2→S3 switch is separated by only 0.001265553 width units at S3, still far above the tie tolerance. Neither a switch nor a small gap lead means attraction, activation, aperture crossing or energy flow.

## Displacements and chord turns

Delta F and Delta S connect adjacent stored indices algebraically; no continuous path is supplied. For successive non-negligible displacement vectors u,v, the unsigned chord angle is atan2(norm(u cross v),u·v). A zero or norm≤1e-12 displacement has an undefined angle; actual nonzero components are retained, not zeroed. Spans remain visible. These are not calibrated speeds, accelerations or continuous curvature.

"""
report+=table(["Interval","Delta F","norm","Delta S","norm"],[[f"{x['from_index']}→{x['to_index']}",vec(x["displacements"]["F"]["vector"]),f(x["displacements"]["F"]["norm"]),vec(x["displacements"]["S"]["vector"]),f(x["displacements"]["S"]["norm"])] for x in tr["intervals"]])
report+="\n"
report+=table(["Middle actual index","incoming/outgoing spans","Frozen chord angle °","Scheduled chord angle °"],[[x["from_index"],str(x["turn_at_middle_stored_index"]["F"]["incoming_span"])+"/"+str(x["turn_at_middle_stored_index"]["F"]["outgoing_span"]),f(x["turn_at_middle_stored_index"]["F"]["angle_degrees"]),f(x["turn_at_middle_stored_index"]["S"]["angle_degrees"])] for x in tr["intervals"][1:]])
report+=r"""

## Ordered attribution and the two freezes

For adjacent saved endpoints i,j, set K_i=K(kappa_i), E_i=E(t_i), H_i=H(theta_i). Here placement is the identity scale/rotation:

\[
D_{\rm nat}=\alpha E_i(K_j-K_i)H_i+\beta(C_j-C_i),\quad
D_{\rm env}=\alpha K_j(E_j-E_i)H_i,\quad
D_{\rm clock}=\alpha K_j E_j(H_j-H_i).
\]

Insert X(Omega_j,theta_i,t_i), then X(Omega_j,theta_i,t_j). Subtracting these four evaluations telescopes exactly to S_j−S_i over the reals. The implementation computes total−[native+(envelope+clock)] and retains its finite-arithmetic residual. The norm/chiral split is inside the native term; chirality is not a separate fourth contribution.

The interval-native term uses the **previous scheduled setting**, while Delta F uses the **global first-sample setting**:

\[
\Delta F=\alpha E_\star(K_j-K_i)H_\star+\beta(C_j-C_i).
\]

They coincide in the first interval here; generally they differ afterward. Neither is an order-independent physical force. Norms are not additive contribution percentages.

"""
report+=table(["Interval","Native","Envelope","Clock","local native − Delta F"],[[f"{x['from_index']}→{x['to_index']}",vec(x["native"]),vec(x["envelope"]),vec(x["clock"]),vec(x["local_native_minus_global_frozen"])] for x in at["intervals"]])
report+="\nThe full four-point sequence for every interval, including actual settings and world coordinates, is stored through ATTRIBUTION.json evaluation IDs into GAP_COMPARISON.json. Its nearest labels are:\n\n"
report+=table(["Interval","initial scheduled","native replacement","envelope replacement","final scheduled"],[[f"{x['from_index']}→{x['to_index']}"]+[", ".join(ev[key]["gap"]["winner_set"]) for key in x["intermediate_evaluation_ids"]] for x in at["intervals"]])
report+="""
Thus the three scheduled switches arise at the clock replacement in this declared order. The envelope alone does not change a nearest label in any of these intervals, although it changes the observation. These replacements are counterfactual evaluations of stored states, not extra native stages, event times or traced paths.

## Independently verified margin bound

Let G_a be any nonempty fixed boundary set and d_a(x)=inf_{p in G_a} norm(x−p). The triangle inequality gives d_a(y)≤d_a(x)+norm(y−x): take the infimum over p. Interchanging x,y yields abs(d_a(y)−d_a(x))≤norm(y−x). The finite segment unions here are nonempty compact sets, so their minima also exist.

If a is uniquely nearest at x and m=min_{b≠a}(d_b(x)−d_a(x)), then for every b≠a:

d_b(y)−d_a(y) ≥ d_b(x)−norm(y−x)−[d_a(x)+norm(y−x)] ≥ m−2 norm(y−x).

Consequently m>2 norm(y−x) implies a remains uniquely nearest. Applying x=F_n,y=S_n establishes the brief's exact sufficient condition. The failure of that condition proves nothing about label change. As a check, singleton sets at 0 and 10 on one axis give: x=1,y=1.1 satisfies the bound and retains the winner; x=1,y=9 fails and switches; x=1,y=−9 fails but retains the winner.

With rigorously proven distance error e_d and displacement-norm error e_b, m_hat−2e_d−2(b_hat+e_b)>0 would certify the same conclusion. Here 1e-12 tolerances are not proven enclosures. The frozen plan's screening condition is m_hat−2b_hat−4e-12>0, with independent high-precision checks; it is reported only as a numerical sufficient-margin diagnostic.

"""
report+=table(["Index","frozen lead m","observer separation b","m−2b","adjusted slack","numerical diagnostic","actual labels agree"],[[x["index"],f(x["margin"]),f(x["b"]),f(x["raw_slack"]),f(x["allowance_adjusted_slack"]),"sufficient" if x["numerically_sufficient"] else "inconclusive",x["actual_same_unique_winner"]] for x in g["robustness"]])
report+="""
The bound succeeds at indices 0 and 1. It fails at 2–4, where direct distance comparisons happen to show disagreements. That coincidence does not turn failure of the bound into a predictor. This elementary distance-to-set argument is an interpretation aid, not a new observation or motion law.

## Figures and QA

![Top comparison](figures/01_top.png)

![Opposite side comparisons](figures/02_opposite_sides.png)

![All-six distances and radius/height](figures/03_index_diagnostics.png)

There are three sheets, all with original width-one geometry and the close sphere. Both conventions use the same spatial limits; all five markers are plotted without connectors or thinning. Both camera directions and all upper/lower near/far arcs are retained. Some frozen markers overlap in projection; this is real proximity, not omitted data. The full numerical ledger disambiguates them. Index-chart lines only guide the eye between stored rows. PNGs were inspected as files, not through the Windows application. A visual-only label/title adjustment changed no calculations.

"""
report+=f"The standalone script passed **{checks['tests_run']} assertions**. All 18 evaluations were checked at 80 decimals, including every switch endpoint, same-index disagreement and the first/middle/last states. The regression fixture, synthetic geometric cases and common-phase display-copy tests are excluded from primary history counts. A separate portable copy passed the same {checks['tests_run']} checks and reproduced all five numerical JSON ledgers byte-for-byte on this host. Cross-platform last-place differences are possible; changed classifications must be reviewed, not waived. Ten monitored original sources/inputs remained unchanged; this is a bounded preservation check, not a whole-checkout audit.\n\n"
report+=r"""
## Reproduce the detached analysis

From Command Prompt, using the existing environment, after extracting the review package:

~~~bat
call conda activate torment
python -X utf8 -I -B C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_RETAINED_HISTORY_01\analyze.py --portable
python -X utf8 -I -B C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_RETAINED_HISTORY_01\make_figures.py
~~~

Substitute the extraction path if moved. Portable mode checks packaged source/input bytes; it does not assert preservation of inaccessible original Windows paths. It regenerates derived files, so verify the delivered manifest before rerunning. Existing Python/math libraries are required; this task performs no installation. Never run the archived producer scripts as part of this detached review.

## Limits and closeout

The result is “no frozen nearest-label switch in this five-state window, three scheduled switches.” It is not a proof of absent native motion, global nonexistence of frozen switches, long-time behavior, a period or upper-side preference. The selected input has its own constructed nominal initialization and different native coefficients from NCM-Z-01. Its saved numerical producer lineage is admitted at the stated evidence level, not upgraded to authentication or replay certification.

No missing-data result was necessary because a qualifying pre-existing history was found. No longer record, second history, alternative window, phase sweep, extra anchor, geometry scan, fitted rotation, native evaluator, EMA trace, application/kernel edit, Git operation or publication followed. No material core trajectory, aperture passage, emitted energy or new mechanism is established. The work stops with this review package.
"""
text("REPORT.md",report)
print(json.dumps({"summary":obs["summary"],"primary_on_arc":on_arcs,"primary_notch_membership":on_patches,"primary_ray_hits":rayhits,"max_hp_error":maxhp,"max_telescope_residual":maxres,"chord_turns":[x["turn_at_middle_stored_index"] for x in tr["intervals"][1:]],"report_bytes":len(report.encode())},indent=2))
