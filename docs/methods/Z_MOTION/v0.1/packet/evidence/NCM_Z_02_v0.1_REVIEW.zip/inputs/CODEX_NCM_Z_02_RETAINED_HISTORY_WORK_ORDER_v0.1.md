# CODEX WORK ORDER — NCM-Z-02 v0.1
## Retained-history Z motion: frozen observer versus scheduled observer

**1 November 2026 · Author-authorized bounded investigation · Existing data and equations only**

## 1. Question and success condition

> **In one independently admitted existing native-triad history containing at least three stored states, do changes of nearest central-opening boundary survive when the staged observer's angle and envelope time are frozen? How do native-state changes and the scheduled observer differ over that same saved history?**

The author has approved this successor. Proceed without another routine approval request. GPT leads mathematical interpretation; Codex independently checks sources, performs the bounded observation analysis, and challenges misleading interpretations. The author need not supply another geometric explanation.

NCM-Z-01 already established, for its two retained states, that frozen staged Z changes inward, while the scheduled observer changes the nearest-opening label. GPT's review located that label change at the clock replacement in the specified ordered decomposition. Those were endpoint observations, not flow or continuous trajectories. This task extends the question to an adequate **pre-existing history**, not to more observer phases of the same two states.

A useful outcome is any of the following: a native-state-dependent nearest-label change under the fixed readout; only scheduled-label changes in the selected window; no resolved changes; or an explicit data-admission limitation. No desired behavior, inward tendency, twelve-count, side preference or paper is a success requirement. Here “survives freezing” means the endpoint effect remains in the controlled readout; it does not mean long-time persistence.

## 2. Scope, environment and output location

Use **Windows Command Prompt**, `call conda activate torment`, and existing Python 3.11 tooling. For new standalone scripts use `python -X utf8 -I -B`. Verify the active interpreter/version; do not substitute another environment. Use existing local libraries only. No installation, downloads, network acquisition, privilege changes or browser/server work.

Read-only checkout:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`

Previous Z investigation:

`C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_FIXED_REFERENCE_01`

Previous Windows observation/parent:

`C:\TORMENT\trioctagon_motion_validation_20261029_01\exports\interactive.motion.json`

`C:\TORMENT\trioctagon_motion_validation_20261029_01\test-suite\fixtures\axial_old_run.json`

Create a fresh external output root, proposed:

`C:\TORMENT\TRIOCTAGON_new\research\NATURAL_CORE_MOTION_Z_RETAINED_HISTORY_01`

Use the next unused suffix if necessary. Never overwrite a prior investigation. Keep all new scripts, copied inputs, figures, caches, logs and results there. The existing NCM-PUBLISH-01 publication is a separate task: do not inspect/change its Git state, staging or publication payload.

**Native F calls: ZERO.** No step/run/resume, source or transcribed native-map evaluation, root solve, parameter search, trajectory regeneration, producer execution, old certificate replay, EMA advancement, or animation of geometry. No application/kernel/lock/paper edits, Git commands or Git-invoking helper, commit, push, release, or publication. Reading source text and inert saved data is allowed. Re-evaluating the existing staged observation and static geometry on already stored states is the work being authorized.

## 3. Packet and inherited sources

Use `PACKET_MANIFEST.json` to check this packet's actual bytes. The packet includes the unchanged full NCM-Z-01 review archive, its report/source manifest, the GPT review/evidence, the fixed-gap report, and byte-identical copies of the old two-state parent/export. These are reference material and a regression fixture, **not the longer history**. The supplied parent has only indices 0 and 1. The two identical exports are not independent experiments.

NCM-Z-01 archive SHA-256:

`92f9b1ab59d60333470956d49681849939e6def28d8bc84d976261f045f28a2e`

Old export: 27,068 bytes, SHA-256

`071f6f7dc74128d638b0e96e33897b1366b2f8bcb98ca741c11fe0af5ed0e1e7`

Old parent: 10,435 bytes, SHA-256

`d0f963cc4160f2aa565e90e5d1d0c9af530aa8f6c5d0a20e033be1b02fb8f764`

Read the necessary source passages, not the whole research history. NCM-Z-01's archive already contains byte-bound snapshots of:

- `motion_observer.py`, `z_manifold.py`, `readouts.py`: staged readout, placement, actual-index clock and first-stored-sample freeze convention.
- `central.tex`, `host.tex`: fixed PLUS zero surface, six broken arcs, separate finite notch triangles and original sphere.
- `records.py`: inert canonicalization/digest rules; its whole-file version differs from the old producer, a disclosed fact rather than failed data integrity.
- `dynamics.py`, attachment and motion manuscripts: definitions only, never execution.

Use those accepted snapshot definitions for the analysis unless the selected history requires an explicitly identified historical source definition. The new analysis is an overlay using the NCM-Z-01 staged formula; it need not pretend to reproduce every observer already saved in the chosen record. Current-source differences must be reported by mathematical role, not “repaired” by changing historical data. Historical commit strings are locators, not current HEAD assertions. Do not query Git.

## 4. Stage A — locate and admit a longer history, before plotting outcomes

### A1. Bounded read-only source route

Look first for a retained continuation of the old run or another retained native-triad history in the named Windows validation directory and its explicitly referenced record/fixture locations. Then consult these established source directories and their evidence indexes/manifests:

1. `papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/`
2. `papers/COLLECTIVE_TURNING_AND_COHERENT_RELAXATION/v0.1/`
3. `papers/PAPER_G/v0.1.1/`
4. If needed, record/fixture locations explicitly indexed by the scientific UI or native run-record documentation under the same checkout.

A source index may identify a particular external retained research directory; follow that explicit path as data. Do not scan all of C:, the entire user profile or unrelated TORMENT/Brainvision folders. Do not reopen SRG reconstruction or prior publication audits. No web acquisition is required.

Read at most **12 distinct candidate history artifacts**, at most **32 MiB each** and **128 MiB of candidate data in total**. Inspect metadata/index files first. Byte-identical copies count as one history. ZIP members can be read as data with safe path/size checks. Do not execute an archive's helpers, unpickle objects, or load object arrays. Log candidates and reasons as they are examined; a search budget ending without admissible data is a valid closeout.

### A2. Admission requirements

An eligible primary history must provide:

- At least three stored native states of three complex components, one identifiable run/branch, strictly increasing actual nonnegative integer update indices, finite values and a stated fixed native coefficient tuple.
- Reproducible source lineage: original bytes, record/schema description, source/model version as available, and a source account connecting those rows to one already performed native evolution. An admitted copy may be a documented fixture of a real run, not arbitrary synthetic samples.
- A clearly stated numerical meaning: binary64 tokens, retained higher-precision producer values, or another documented representation. Preserve original tokens and precision. Do not silently replace exact data with plotted/rounded coordinates.
- All available stored digests/seals checked using the appropriate version's inert rule. Record the limits: integrity and provenance are not authentication of the producer, replay certification or a new theorem that the states solve the ideal recurrence.

Retained full native states are necessary for this primary observation analysis. Z-only plots/values, a GIF, limiting cycle endpoints without an actual ordered run, solver iterates, comparison-phase sweeps, normalized-only records, and the previously prescribed cone poses are not substitutes. **In particular, the central-geometry four-update manuscript labels its rational comparison vectors as comparison centers, not actual replacement trajectory states. Do not turn those centers or interval-box midpoints into a purported native history.** A separately retained producer trajectory associated with that study may qualify if its actual lineage is established without rerunning the producer.

A legacy non-Core JSON/CSV/NPZ history may qualify if the mapping of its native states, indices, parameters and provenance is explicit; do not impose a modern schema retroactively. Do not silently splice separate runs, renumber sparse samples, interpolate, infer missing states from the recurrence, normalize state magnitude, rephase each row or change coefficients. A current serialization helper need not have the historical producer's whole-file hash. Conversely, an actual state/digest/source mismatch must not be waived.

### A3. Selection rule — independent of opening results

Select **one primary history**, using only admission, provenance and comparability, before calculating Z/gap outcomes:

1. Prefer an independently retained longer continuation containing the exact old indices 0 and 1 and the same run identity, initial state, coefficient tokens and source lineage. A match of only a few values is not proof of common lineage.
2. Otherwise, prefer an admitted history at the same old native coefficients and initialization, with any differences in run/source identified.
3. Otherwise, use the first eligible history in the ordered source route A1. This is a new retained example at its own fixed parameters, not an extension of the old run and not evidence that all parameter sets behave alike.

Within an equal rank, prefer stronger recorded lineage, then consecutive saved indices, then the larger stored sample count up to the cap, then case-insensitive full-path order. Never rank by apparent curvature, label switches, inward motion, desired numbers, proximity to gaps or visual attractiveness. A short three-state history is eligible but must not be promoted to long-time evidence. Retain duplicates and excluded candidate reasons in the inventory.

Analyze all states if there are at most **4096**; for a larger admitted history, predeclare the **earliest 4096 stored rows** as a bounded prefix and state the excluded suffix/count. Preserve the original full input identity. No alternate windows, event-based cropping or hidden decimation. Gapped indices stay gapped; report each update span. If the chosen history produces no interesting changes, that is the result; do not switch to another history afterward.

### A4. Freeze the plan and handle absence honestly

Before movement calculations, write and hash `ADMISSION_AND_PLAN.json`: candidate inventory/rank; selected path/hash; evidence status; exact native parameters; original indices and selected prefix; numerical representation; fixed geometry/observer configuration; tolerances; output/evaluation limits. A small intake script may decode states and check finiteness, shape and provenance, but must not inspect opening-label outcomes before selection.

If no admissible history exists within the bounded source route, return `START_HERE.md`, the candidate inventory and a precise missing-data statement. Do not create a new native run, present the two-state regression as an extension, ask the author to redescribe geometry, or declare the scientific question answered. Requesting a future bounded run, if eventually necessary, is a separate decision after this closeout.

## 5. Stage B — same states, two observation conventions

Use the existing staged observation, not EMA and not the average arrow P. The native coefficient tuple comes from the admitted history and is not changed. The observer configuration is the unchanged NCM-Z-01 comparison preset below, applied as a declared detached observation of that history:

```
N=12; q0=0; q_step=1; time0=0; dt=0.1
lambda_vp=0.618; gamma=0.577; lock_angle=0.244 radians
alpha=1; beta=0.5; mu_place=1; psi=0
geometry: PLUS, tau=0; host width=1; O=(0,sqrt(3)/6,0)
```

The decimal literals retain their source numeric semantics. Do not substitute exact inverse golden ratio for 0.618. None is a controller of a moving cone.

For each **actual** index n, the scheduled settings are q_n=(q0+n q_step) mod N, theta_n=2*pi*q_n/N, t_n=time0+n*dt. This is a readout schedule, not an extra native time step. Use integer sector arithmetic; do not silently rebase to the sample ordinal.

Freeze the second observer at the scheduled angle/time of the **first included stored sample n_star**, as in the existing application:

`theta_star=theta(n_star); t_star=t(n_star)`.

For histories beginning at n=0, this is exactly the theta=time=0 comparison from NCM-Z-01. If the history starts later, state the new freeze anchor prominently; do not silently reset the envelope or add an outcome-selected second anchor.

Write `S_n=X(Omega_n,theta_n,t_n)` and `F_n=X(Omega_n,theta_star,t_star)`. S_n and F_n are two evaluations of the **same native state**, not two consecutive native positions. The initial evaluations coincide by construction.

Recompute kappa, C, macro, Z and X using the source definitions. Document stored-observer reproduction separately if the selected record already contains matching readouts. Different historical observers do not invalidate an otherwise admitted native history, and their values must not be silently relabeled as this preset.

No guarantee keeps a general Z point inside the reference sphere. Report actual inside/on-tolerance/outside status; do not clip points or rescale the construction. If finite arithmetic underflows an envelope to zero, distinguish that numerical outcome from exact extinction; use the separately stated high-precision diagnostic where needed, without renormalizing the native data or changing the schedule. Report nonfinite or unresolved outputs honestly.

## 6. Stage C — primary measurement and displacement accounting

### C1. Six-opening comparisons at every stored state

Reconstruct the SAME six finite two-segment central boundary arcs G+0..G+2, G-0..G-2 at PLUS tau=0. All six compete in the nearest-boundary test; do not assume an upper winner or ignore the far side. Host notch triangles N+/-k are separate finite measurement regions, not aperture interiors or material caps.

For each S_n and F_n, retain:

- World and centered point; center distance; horizontal radius; signed height; azimuth/elevation only when defined; sphere margin.
- All six exact-formula/numerically evaluated finite-arc distances, nearest points/segment parameters, best and second-best margins, all ties and unresolved decisions.
- Point-on-boundary-within-tolerance flags; finite notch point-membership and centered-ray incidence as separately named endpoint diagnostics. Neither a hit nor a miss is a transport claim.

A nearest identity changing between saved indices does not mean the point approached that boundary, crossed an aperture or carried energy through it. Report both distance-to-center change and distance-to-boundary change, including distances to the old and new winning arcs. Do not use azimuth sectors instead of finite-segment distances.

### C2. What counts as a switch

A **resolved endpoint-label switch** requires unique, numerically separated winners at both endpoint samples and different labels. Keep ties and near-ties as sets; do not silently resolve them by label order. Report transitions into/out of ties separately, including multi-segment ties at the same physical arc elbow.

Across each adjacent pair of stored indices, compare the frozen and scheduled outcomes: frozen switch only, scheduled switch only, both (same ordered labels or different), neither, or unresolved/tied. Also list same-index S/F disagreements. This is endpoint classification, not a continuous crossing event. Do not invent an event time between stored indices.

Return the complete transition ledger and totals, not selected good examples. “No frozen switch in this window” is not proof of globally stationary native motion; nearest identity is only one coarse readout.

### C3. Displacements and discrete turns

Compute Delta F and Delta S only between adjacent stored rows, retaining actual start/end indices and Delta n. With at least three rows, an unsigned turn between consecutive displacement vectors may be computed, preferably as atan2(norm(cross),dot). Zero or numerically unresolved displacements give an undefined angle, not 0 degrees or an arbitrary axis. Unequal update spans are visible; these are chord-angle diagnostics, not calibrated velocity, acceleration, or continuous curvature.

For each scheduled interval, use the existing ordered telescope **native state -> envelope -> clock**. Retain its four evaluation settings/points and vector residual. Split the native contribution into its norm-dependent macro and chiral subterms if useful, but do not count chirality twice as an independent fourth stage. Component norms are not additive percentages.

Important: the interval's native term freezes settings at its **previous scheduled endpoint**. It generally differs from Delta F, whose settings stay at the **global first-sample anchor**. Do not conflate them after the first interval. Compute nearest-arc labels for the two intermediate readouts to identify where a label changes within this declared algebraic replacement order; this is not an order-independent causal force attribution.

### C4. One small robustness result

Independently verify the distance-to-set bound in `MATHEMATICAL_BRIEF.md`. For a unique nearest boundary a at F_n, let m_n be its lead over the runner-up and b_n=norm(S_n-F_n). The exact sufficient condition

`m_n > 2 b_n`

guarantees that a remains the unique nearest boundary at S_n. Failure of this condition predicts nothing by itself. Report the margin/slack and actual labels. Apply the bound only as a mathematical theorem at exact points, or as a numerical sufficient-margin diagnostic with an explicit uncertainty allowance. Ordinary floating-point inequalities are not an interval certificate.

This is a bounded interpretive check, not a new observation law and not a reason for another phase sweep. No extra frozen anchors, geometry scans, fitted rotations or supplemental histories are authorized.

## 7. Numerical and implementation review

Use a fresh standalone observation/geometry script; reuse prior formulas without executing the old full study or importing application/kernel packages. Preserve old sources and evidence unchanged. Data readers must be inert. The earlier two-state input may be used once as a small regression fixture, explicitly excluded from the new history/transition counts.

Primary geometry/tie tolerance: **1e-12 of host width**. Source-reproduction tolerance: **2e-13 times max(1,magnitudes)**, as in NCM-Z-01. Record actual discrepancies. Tolerances are not rigorous enclosures. Keep original exact/hex tokens alongside derived numeric values. Do not threshold a small nonzero native state into an exact zero, or silently suppress apparent fast turns near cancellation.

Re-evaluate, using independently written 80-decimal formulas, the endpoints of every provisional resolved label switch, every S/F label disagreement, every tolerance-borderline decision, plus the first/middle/last samples. These are already selected states and observer settings, not fresh native evaluations. The bound is the selected 4096-row history and its two telescope intermediates per interval. If the comparison remains ambiguous, report unresolved; do not claim an exact equality or physical event from numerical agreement. Propagating full certified state boxes is out of scope here.

New tests should cover source reproduction; global versus local freeze; sparse actual indices; telescope identity; all six geometry labels; opposite-camera parity; common-phase invariance of frozen staged Z; segment endpoints and ties; zero/axis direction; zero displacement; and positive/negative robustness-margin examples. Synthetic cases exercise the readout/geometry only and must never enter the retained-history result counts. No target check count is prescribed; report genuine passes/failures and corrections.

Freeze the analysis definitions before outcomes. If a coding defect is found, preserve the failure and correction log, fix the implementation, and rerun only this new bounded observation analysis. No undisclosed change of record, window, preset, geometry or scientific question is permitted.

## 8. Visualizations and explanation

Return a short discovery summary first. It should directly answer: what was admitted; how many states/spans; whether any frozen-label switch occurred; which differences arise in the scheduled comparison; what remains unresolved.

Produce coordinate-based, readable figures with unchanged width-one geometry and the original close sphere:

1. A top view and both opposite side views with S/F points clearly distinguished, actual index labels or a declared index-color scale, all six upper/lower boundaries, and the stationary center.
2. An index-based comparison of all six boundary distances or their winning margins for frozen and scheduled readouts, plus an explicit record of ties. A small center-radius/height panel is useful; at most four figure sheets in total.

Use marker-only spatial plots by default. Any connectors must be labeled as guides between stored endpoints, never a continuous trajectory. Plot thinning, if needed for labels, must be deterministic and disclosed; the numerical ledgers and counts use every included sample. Match spatial limits/cameras/scales across the comparisons; do not clip external points to make them fit the sphere. Show both near/far and upper/lower geometry. No image-generation artwork, flow arrows, emission glow, activation heatmap, prescribed cone movement or interactive application change.

## 9. Required return package and stop

Return an external `NCM_Z_02_v0.1_REVIEW.zip` containing:

- `START_HERE.md`: approximately one-page answer/discovery summary, including negative or insufficient-data outcomes.
- `REPORT.md`: source-linked methods, selected-history scope, full primary findings, a few interpretable examples and limits. This is a research report, not a commissioned manuscript.
- `ADMISSION_AND_PLAN.json`: candidate inventory, eligibility decisions, deterministic selection and window, provenance limits, observer settings, selected indices, and pre-analysis hash/time receipt.
- Immutable selected input copy (or exact source/archive member with a lossless extraction) and original numeric-token/index ledger; the prior two-state fixture is separately labeled.
- `OBSERVATIONS.json`, `GAP_COMPARISON.json`, `TRANSITIONS.json`, `ATTRIBUTION.json` (names may be combined sensibly if all required fields remain clear).
- Standalone script/tests, test results, high-precision comparisons, exact mathematical argument for the margin bound, source locators/hashes, actual commands/environment, and before/after hashes of the bounded files read.
- The calculated PNG/SVG figures, a numerical/visual QA record, and `CLOSEOUT.txt` with actual counts, limitations, zero native/EMA evaluation counts, and preservation status.
- An output manifest of sizes/SHA-256 (excluding itself) and a ZIP receipt outside the archive that verifies all included entries. No self-referential hash claim.

Do not include unrelated installed environments, full repository copies, private directories or font files. Copy only inspected scientific inputs and source material needed to interpret/reproduce this observation study. A portable rerun must explicitly use packaged source/input copies rather than pretending to verify inaccessible original Windows paths. Cross-platform last-place differences may be disclosed; do not demand impossible byte-identical floating outputs or silently waive changed classifications.

Stop after the review package. No new native simulation follows automatically if the history is too short, too sparse, or shows no frozen switches. No second record, larger search, EMA extension, state-to-pose law, paper, publication or successor task is authorized. Return the actual result for GPT/author discussion.
