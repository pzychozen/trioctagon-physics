"""Draw only packaged fixed coordinates and already-calculated observation points."""
from pathlib import Path
import os,json,math
ROOT=Path(__file__).resolve().parent
os.environ["MPLCONFIGDIR"]=str(ROOT/"mplconfig")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Polygon
from matplotlib.lines import Line2D
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
data=json.loads((ROOT/"GAP_COMPARISON.json").read_text());obs=json.loads((ROOT/"OBSERVATIONS.json").read_text())
geom=data["fixed_geometry"];ev=data["evaluations"];arcs=geom["arcs"];patches=geom["finite_notch_patches"];rho=geom["sphere_radius"]
indices=obs["summary"]["indices"];cm=plt.get_cmap("viridis");norm=Normalize(min(indices),max(indices))
plt.rcParams.update({"font.size":10,"axes.titlesize":12,"font.family":"DejaVu Sans"})
r=math.sqrt(3)/6;h=(math.sqrt(2)-1)/2
uv=[(-.5,-h),(-h,-.5),(h,-.5),(.5,-h),(.5,h),(h,.5),(-h,.5),(-.5,h)]
panels=[[(u,-r,z) for u,z in uv],[(-.25-u/2,math.sqrt(3)/4-math.sqrt(3)*u/2-r,z) for u,z in uv],[(.25-u/2,math.sqrt(3)/4+math.sqrt(3)*u/2-r,z) for u,z in uv]]
radius=max(rho,max(math.hypot(*ev[f"{mode}{n}"]["readout"]["centered"]) for mode in ("F","S") for n in indices))
lim=1.18*max(radius,.6)
colors=["#087e76","#a06800","#7952a6"]
def background(ax,project,side=False,view=1):
    for panel in panels:
        pts=panel+[panel[0]];ax.plot(*zip(*(project(p) for p in pts)),color="#c8ced3",lw=.9,zorder=1)
    if side:
        for patch in patches:ax.add_patch(Polygon([project(p) for p in patch["vertices"]],closed=True,facecolor="#aeb8c3",edgecolor="#9ba4ae",alpha=.22,zorder=1))
    for i,arc in enumerate(arcs):
        near=sum(p[1] for p in arc["vertices"])*view<0
        ax.plot(*zip(*(project(p) for p in arc["vertices"])),color=colors[i%3] if side or i<3 else "#222222",lw=(2.0 if near else 1.2) if side else (2.7 if i<3 else 1.2),ls="-" if i<3 else "--",alpha=1 if not side or near else .65,zorder=3+i/10)
    if side:
        for i,arc in enumerate(arcs):
            x,y=project(arc["vertices"][1]);dx=25 if x>1e-10 else -48 if x<-1e-10 else -13
            ax.annotate(arc["label"],(x,y),xytext=(dx,33 if i<3 else -15),textcoords="offset points",color=colors[i%3],fontsize=9,weight="bold")
    else:
        for k,arc in enumerate(arcs[:3]):
            th=math.radians(arc["azimuth_degrees"])
            ax.text(.43*math.cos(th),.43*math.sin(th),f"G+{k} / G−{k}\n{arc['azimuth_degrees']}°",ha="center",va="center",color=colors[k],fontsize=10,weight="bold")
    ax.add_patch(Circle((0,0),rho,fill=False,color="#8292a3",linestyle=":",lw=1.2,zorder=0))
    ax.scatter([0],[0],color="#222222",marker="+",s=50,zorder=5);ax.annotate("O",(0,0),xytext=(-12,-14),textcoords="offset points")
    ax.set_aspect("equal");ax.set_xlim(-lim,lim);ax.set_ylim(-lim,lim);ax.grid(alpha=.12)
def markers(ax,mode,project,side=False):
    # Five of five markers; no thinning or spatial connectors.
    offsets=([(12,-16),(24,5),(-28,0),(-28,-18),(24,-20)] if mode=="F" and side else [(8,10),(12,8),(-24,1),(-24,-15),(10,10)] if mode=="F" else [(8,-16),(8,8),(-22,-14),(8,-16),(8,8)])
    for n,offset in zip(indices,offsets):
        xy=project(ev[f"{mode}{n}"]["readout"]["centered"])
        ax.scatter(*xy,s=65,marker="s" if mode=="F" else "o",c=[cm(norm(n))],edgecolors="#1b2730",linewidths=.6,zorder=7)
        ax.annotate(str(n),xy,xytext=offset,textcoords="offset points",fontsize=10,weight="bold",color="#182330",bbox={"facecolor":"white","edgecolor":"none","pad":.2,"alpha":.7},zorder=8)
fig,axes=plt.subplots(1,2,figsize=(13,7.8))
for ax,mode in zip(axes,("F","S")):
    background(ax,lambda p:p[:2]);markers(ax,mode,lambda p:p[:2])
    ax.set_title("Frozen F · θ*=0, t*=0" if mode=="F" else "Scheduled S · actual native indices")
    ax.set_xlabel("centered x / width");ax.set_ylabel("centered y / width")
fig.suptitle("One retained history, indices 0–4 · fixed PLUS τ=0 · top projection",fontsize=15,y=.98)
fig.colorbar(ScalarMappable(norm=norm,cmap=cm),ax=axes,location="bottom",fraction=.045,pad=.12,ticks=indices,label="Actual saved native update index (all five points shown)")
fig.text(.5,.025,"Solid colored arcs: upper   Dashed overlay: lower   Gray: original folded host   Dotted circle: original close sphere\nUpper/lower projections overlap; they are different 3D boundaries. Markers only, no continuous path.",ha="center",fontsize=10)
fig.subplots_adjust(top=.87,bottom=.24,wspace=.19)
fig.savefig(ROOT/"figures/01_top.png",dpi=180);plt.close(fig)

fig,axes=plt.subplots(2,2,figsize=(12.5,13))
for row,mode in enumerate(("F","S")):
    for col,view in enumerate((1,-1)):
        ax=axes[row,col];project=lambda p,view=view:(view*p[0],p[2])
        background(ax,project,True,view);markers(ax,mode,project,True)
        ax.set_title(("Frozen F" if mode=="F" else "Scheduled S")+" · view from "+("−y" if view==1 else "+y"))
        ax.set_xlabel("centered "+("x" if view==1 else "−x")+" / width");ax.set_ylabel("centered height / width")
fig.suptitle("Opposite side projections · same center, scale and retained samples",fontsize=15,y=.98)
fig.text(.5,.055,"Upper arcs solid; lower arcs dashed. Thick arcs are nearer the camera; all far arcs remain visible.\nPale finite triangles are host notch measurement patches, separate from the colored broken boundaries.",ha="center",fontsize=10)
fig.text(.5,.02,"Square markers: frozen   Round markers: scheduled   Numbers/colors: actual saved indices 0–4\nNo native interpolation, material motion or opening passage is depicted.",ha="center",fontsize=10)
fig.subplots_adjust(top=.93,bottom=.13,wspace=.18,hspace=.16)
fig.savefig(ROOT/"figures/02_opposite_sides.png",dpi=170);plt.close(fig)

fig,axes=plt.subplots(2,2,figsize=(13,9))
all_d=[arc["distance"] for mode in ("F","S") for n in indices for arc in ev[f"{mode}{n}"]["gap"]["arcs"]]
for ax,mode in zip(axes[0],("F","S")):
    for k,arc in enumerate(arcs):
        vals=[ev[f"{mode}{n}"]["gap"]["arcs"][k]["distance"] for n in indices]
        ax.plot(indices,vals,marker="o",ms=4,lw=1.3,linestyle="-" if k<3 else "--",color=colors[k%3],label=arc["label"])
    ax.set_ylim(0,max(all_d)*1.07);ax.set_title(("Frozen F" if mode=="F" else "Scheduled S")+" · all six boundary distances")
    ax.set_ylabel("finite 3D distance / width");ax.set_xticks(indices);ax.grid(alpha=.18)
    ax.legend(ncol=3,fontsize=8,loc="upper right")
for mode,color,marker in (("F","#145da0","s"),("S","#b52559","o")):
    axes[1,0].plot(indices,[ev[f"{mode}{n}"]["spatial"]["radius"] for n in indices],marker=marker,color=color,label=mode+" center radius")
    axes[1,1].plot(indices,[ev[f"{mode}{n}"]["spatial"]["height"] for n in indices],marker=marker,color=color,label=mode+" centered height")
axes[1,0].axhline(rho,color="#8193a4",ls=":",label="original sphere radius")
axes[1,1].axhline(0,color="#8193a4",lw=.8)
for ax in axes[1]:
    ax.set_xticks(indices);ax.set_xlabel("actual saved native update index");ax.set_ylabel("width units");ax.grid(alpha=.18);ax.legend(fontsize=9)
axes[1,0].set_title("Center radius · original sphere unchanged")
axes[1,1].set_title("Height changes under the scheduled observer")
fig.suptitle("Five stored samples · complete distance comparison",fontsize=16,y=.98)
fig.text(.5,.035,"Nearest-arc ties / unresolved primary decisions: none at tolerance 10⁻¹² width; all 18 evaluations checked at 80 decimals.\nLines in these index charts guide the eye between stored rows; they do not supply intermediate native states or a spatial path.",ha="center",fontsize=10)
fig.subplots_adjust(top=.91,bottom=.14,hspace=.32,wspace=.2)
fig.savefig(ROOT/"figures/03_index_diagnostics.png",dpi=180);plt.close(fig)
record={"figures":["figures/01_top.png","figures/02_opposite_sides.png","figures/03_index_diagnostics.png"],"figure_sheets":3,"spatial_markers_per_mode":len(indices),"omitted_points":0,"thinning":"none","spatial_connectors":False,"index_chart_connectors":"guides only; no new native samples","common_spatial_half_range":lim,"all_six_arcs_both_levels_retained":True,"finite_host_notch_patches_separate":True,"viewing":"image files only; no application UI"}
(ROOT/"FIGURE_RECORD.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
print(json.dumps(record,indent=2))
