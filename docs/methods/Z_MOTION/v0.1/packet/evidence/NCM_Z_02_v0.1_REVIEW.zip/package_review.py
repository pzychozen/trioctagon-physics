"""Verify bounded preservation and package this completed detached study."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((ROOT/n).read_text(encoding="utf-8"))
def write(n,v):(ROOT/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
checks=read("checks_results.json");obs=read("OBSERVATIONS.json");portable=read("PORTABLE_VERIFICATION.json");freeze=read("ADMISSION_FREEZE_RECEIPT.json")
assert checks["passed"] and portable["returncode"]==0 and all(x["byte_identical"] for x in portable["data_output_matches"].values())
assert sha((ROOT/"ADMISSION_AND_PLAN.json").read_bytes())==freeze["plan_sha256"]
protected=read("PROTECTED.before.json")
pres=[]
for e in protected:
    got=sha(Path(e["path"]).read_bytes());assert got==e["sha256"],e["path"]
    assert sha((ROOT/e["copy"]).read_bytes())==e["sha256"]
    pres.append({"path":e["path"],"before_sha256":e["sha256"],"after_sha256":got,"unchanged":True})
write("FINAL_PRESERVATION.json",{"utc":datetime.now(timezone.utc).isoformat(),"files":pres,"count":len(pres),"all_unchanged":True,"scope":"Only named source/input originals; not a whole-checkout or whole-machine audit"})
close=f"""NCM-Z-02 v0.1 — COMPLETE

Admitted existing input:
Central Geometry v0.3 numerical audit, NOMINAL_CROSSCHECK.json
8,871 bytes; SHA-256 a294a4b0bf181adaa2054aa52379c1832a7833e3faa7614d0785aecd709ea09c
Five saved full native-triad states, actual indices 0..4; four consecutive spans.
Prior producer: mpmath 120 decimal working precision, saved at up to 100 significant digits.
Fixed native parameters epsilon=.1, g=.2, phase=.17, k=(2,3,4).
This is a different initialization/parameter example from the old two-state record.
It is not a continuation of that run or a statistically representative history.

Admission:
Three distinct candidate artifacts, 19,361 bytes. No cap exceeded.
Selected first eligible history in the ordered source route.
Plan hash {freeze['plan_sha256']}
Freeze UTC {freeze['frozen_utc']}
All five rows selected before opening calculations; no alternative window or record.
Legacy source account and manifest hashes verified; no modern Core schema imposed.
Integrity/provenance do not authenticate a producer or certify native ideal evolution.

Results:
Frozen nearest-opening switches: 0 (G+0 throughout).
Scheduled nearest-opening switches: 3.
1->2 G+0 to G-2; 2->3 G-2 to G-0; 3->4 G-0 to G+1.
All three occur at the clock replacement in the specified ordered telescope.
Same-index F/S disagreements: 2, 3, 4.
No nearest-label ties/unresolved primary decisions or high-precision label disagreements.
Frozen points still change position and chord direction.
All 10 primary points inside the original close sphere; none on a central arc
or finite notch patch. The outward ray through F1 hits N+0; this is a direction
test only, not point membership, aperture passage, emission or transport.
Margin-bound numerical sufficient diagnostic succeeds at indices 0 and 1 only.
Failure elsewhere is inconclusive by itself.

Verification:
{checks['tests_run']} assertions passed in the fresh standalone observation analysis.
18 primary/intermediate evaluations independently checked at 80 decimals.
{portable['assertions_passed']} assertions passed in a packaged-input portable copy.
All five numerical ledgers byte-identical on this host; cross-platform last-place
differences are possible, but classification changes require explicit review.
Three PNG sheets inspected as files; all five points shown, no spatial connectors,
no thinning, all upper/lower and opposite camera sides retained.
No Windows application GUI verification claimed.
{len(pres)} bounded original files unchanged at final packaging; not a whole-checkout audit.

Interpretation:
The exact distance-to-set margin argument is independently verified.
This result is bounded endpoint readout accounting, not a new motion law,
physical mechanism, general no-switch theorem or long-time result.
No missing-data result needed: an eligible pre-existing history was found.
No further history, simulation or successor investigation was started.

Constraints:
Command Prompt and existing torment, offline.
Native evaluations ZERO; producer calls ZERO; EMA advances ZERO; Git commands ZERO.
No model, application, kernel, lock or paper edits, downloads, installations,
browser/server work, commit/push or publication.
All task writes in this fresh external output root.

Delivery:
NCM_Z_02_v0.1_REVIEW.zip; OUTPUT_HASHES.json lists payload hashes excluding itself.
REVIEW_RECEIPT.json is outside the ZIP and records archive/manifest hash, entry
counts and byte/CRC verification. Scratch and font cache are excluded.
"""
(ROOT/"CLOSEOUT.txt").write_text(close,encoding="utf-8")
archive=ROOT/"NCM_Z_02_v0.1_REVIEW.zip"
assert not archive.exists() and not (ROOT/"REVIEW_RECEIPT.json").exists(),"Do not overwrite a delivered archive"
excluded={"OUTPUT_HASHES.json","NCM_Z_02_v0.1_REVIEW.zip","REVIEW_RECEIPT.json","logs/packaging.txt"}
paths=sorted(p for p in ROOT.rglob("*") if p.is_file() and p.relative_to(ROOT).parts[0] not in ("scratch","mplconfig") and p.relative_to(ROOT).as_posix() not in excluded)
entries=[{"path":p.relative_to(ROOT).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in paths]
write("OUTPUT_HASHES.json",{"algorithm":"SHA-256","entries":entries,"exclusions":["itself","review ZIP","external REVIEW_RECEIPT.json","logs/packaging.txt","scratch/","mplconfig/"],"no_self_referential_hash":True})
paths.append(ROOT/"OUTPUT_HASHES.json")
with zipfile.ZipFile(archive,"x",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in paths:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(n.casefold() for n in names))==len(paths)
    assert set(names)=={e["path"] for e in entries}|{"OUTPUT_HASHES.json"}
    assert all(not PurePosixPath(n).is_absolute() and ".." not in PurePosixPath(n).parts and "\\" not in n and ":" not in n for n in names)
    for e in entries:
        b=z.read(e["path"])
        assert len(b)==e["bytes"] and sha(b)==e["sha256"] and b==(ROOT/e["path"]).read_bytes(),e["path"]
    mb=z.read("OUTPUT_HASHES.json");assert mb==(ROOT/"OUTPUT_HASHES.json").read_bytes()
receipt={"task":"NCM-Z-02 v0.1","utc":datetime.now(timezone.utc).isoformat(),"archive":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"members_verified":len(paths),"payload_member_sha256_checks":len(entries),"manifest_member_checked":True,"manifest_sha256":sha(mb),"safe_unique_member_names":True,"all_crc_passed":True,"all_members_match_delivered_files":True,"plan_hash_unchanged":freeze["plan_sha256"],"primary_states":5,"spans":4,"frozen_switches":0,"scheduled_switches":3,"tests_passed":checks["tests_run"],"portable_tests_passed":portable["assertions_passed"],"portable_numerical_ledgers_matched":len(portable["data_output_matches"]),"original_files_unchanged":len(pres),"native_evaluations":0,"ema_advances":0,"git_commands":0,"publication":False}
write("REVIEW_RECEIPT.json",receipt);print(json.dumps(receipt,indent=2))
