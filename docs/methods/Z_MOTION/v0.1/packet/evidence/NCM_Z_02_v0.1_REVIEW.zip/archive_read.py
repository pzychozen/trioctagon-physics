"""Read selected metadata/source members as inert text, never import or execute."""
from pathlib import Path,PurePosixPath
import sys,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
archive=Path(sys.argv[1]); name=sys.argv[2]
pp=PurePosixPath(name); assert not pp.is_absolute() and ".." not in pp.parts and "\\" not in name
with zipfile.ZipFile(archive) as z:
    info=z.getinfo(name);assert info.file_size<=1024*1024
    raw=z.read(name)
out=ROOT/"sources"/("arch_"+name.replace("/","_"))
out.write_bytes(raw)
record={"archive":str(archive),"member":name,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"copy":str(out.relative_to(ROOT))}
with (ROOT/"logs/ARCHIVE_SOURCE_READS.jsonl").open("a",encoding="utf-8") as f:f.write(json.dumps(record)+"\n")
print(json.dumps(record))
lines=raw.decode("utf-8-sig").splitlines()
terms=sys.argv[3:]
if terms:
    indices=sorted({j for i,line in enumerate(lines) if any(t.lower() in line.lower() for t in terms) for j in range(max(0,i-3),min(len(lines),i+5))})
else: indices=range(min(len(lines),120))
for i in indices: print(f"{i+1:04d}: {lines[i]}")
