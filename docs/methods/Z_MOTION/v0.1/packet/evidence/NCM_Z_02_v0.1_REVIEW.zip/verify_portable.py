"""Re-run only this new detached observation script from packaged data copies."""
from pathlib import Path
import shutil,json,sys,subprocess,hashlib
ROOT=Path(__file__).resolve().parent
dest=ROOT/"scratch/portable_01";dest.mkdir(parents=True,exist_ok=False)
required=["analyze.py","ADMISSION_AND_PLAN.json","ADMISSION_FREEZE_RECEIPT.json","ORIGINAL_TOKEN_LEDGER.json","CANDIDATE_INVENTORY.json","ACCEPTED_SOURCES.json","PROTECTED.before.json","inputs/SELECTED_HISTORY.json","packet/inputs/NCM_Z_01_RETAINED.motion.json"]
protected=json.loads((ROOT/"PROTECTED.before.json").read_text())
required += [e["copy"] for e in protected]
required += [str(p.relative_to(ROOT)) for p in (ROOT/"accepted_sources").iterdir()]
for name in sorted(set(required)):
    p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,p)
cmd=[sys.executable,"-X","utf8","-I","-B",str(dest/"analyze.py"),"--portable"]
with (ROOT/"logs/portable_analysis.txt").open("w",encoding="utf-8") as log:
    run=subprocess.run(cmd,cwd=dest,stdout=log,stderr=subprocess.STDOUT,check=False)
assert run.returncode==0
result=json.loads((dest/"checks_results.json").read_text())
files=["OBSERVATIONS.json","GAP_COMPARISON.json","TRANSITIONS.json","ATTRIBUTION.json","HIGH_PRECISION.json"]
identities={}
for name in files:
    identities[name]={"byte_identical":(ROOT/name).read_bytes()==(dest/name).read_bytes(),"delivered_sha256":hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),"portable_sha256":hashlib.sha256((dest/name).read_bytes()).hexdigest()}
assert all(v["byte_identical"] for v in identities.values())
receipt={"command":cmd,"returncode":run.returncode,"assertions_passed":result["tests_run"],"portable_mode":True,"data_output_matches":identities,"meaning":"Same-host packaged-input reproduction; no original-path preservation assertion by portable mode; no new native experiment. Cross-platform last-place differences may occur, but changed classifications require review."}
(ROOT/"PORTABLE_VERIFICATION.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
(ROOT/"logs/portable_checks_results.json").write_bytes((dest/"checks_results.json").read_bytes())
print(json.dumps(receipt,indent=2))
