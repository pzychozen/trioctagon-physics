# NCM-Z-02 — mathematical brief

**Lead analysis for independent verification; no new native evolution performed.**

## Starting evidence

NCM-Z-01's primary data have only native indices 0 and 1. Its report distinguishes a frozen inward endpoint change from a scheduled change of nearest opening. Its four telescope evaluation points show the nearest label changing at the clock replacement, in that declared order. This does not establish a later trajectory. The new question needs another already-retained history with at least three actual states.

The earlier application freezes the observer at the angle/time of its first stored sample, while the schedule is indexed from native index zero. The two coincide with theta=time=0 for the prior fixture because it starts at n=0. The same convention is retained in NCM-Z-02; sparse/late histories must not be reindexed.

## 1. Two readouts of the same history

Let i number stored samples, and n_i be their actual update indices. Define

\[
\kappa_i=\|\Omega_i\|,\quad C_i=\Re\Omega_i\times\Im\Omega_i,
\quad K_i=\lambda_{\rm vp}\frac{\kappa_i}{1+\kappa_i},
\]
\[
E_i=e^{-\gamma t_i},\quad
H_i=\cos[3(\theta_i-\ell)](\cos\theta_i,\sin\theta_i,1).
\]

Here H_i is a macro direction/harmonic vector, not the coherence matrix used in the return papers. Write L=mu_place R_psi, with L fixed.

\[
S_i=O+L(\alpha K_iE_iH_i+\beta C_i),\qquad
F_i=O+L(\alpha K_iE_\star H_\star+\beta C_i).
\]

The star uses the first included sample's observer settings. These comparisons keep the same \(\Omega_i\) and geometry. They do not alter F (the native recurrence); to avoid notational confusion, the work order's F_i means a frozen point, not a map evaluation.

A frozen nearest-label change is state-dependent **under this declared readout and placement**. It is not an intrinsic, observer-free force or unique spatial interpretation of the native state.

## 2. Ordered endpoint identity and the two kinds of “native-only”

For adjacent saved samples i and j=i+1, at possibly nonconsecutive native indices:

\[
D_{\rm native}=L[\alpha E_i(K_j-K_i)H_i+\beta(C_j-C_i)],
\]
\[
D_{\rm envelope}=L[\alpha K_j(E_j-E_i)H_i],\qquad
D_{\rm clock}=L[\alpha K_jE_j(H_j-H_i)].
\]

Then \(S_j-S_i=D_{\rm native}+D_{\rm envelope}+D_{\rm clock}\) by inserting two intermediate endpoint evaluations. Those intermediates use (Omega_j,theta_i,t_i) and (Omega_j,theta_i,t_j).

By contrast,

\[
F_j-F_i=L[\alpha E_\star(K_j-K_i)H_\star+\beta(C_j-C_i)].
\]

These are generally different after the first interval. One uses the previous scheduled setting; the other the fixed global anchor. Component vector sums are exact algebraic accounting. Component norms/angles are not additive causal percentages, and intermediate replacements are not extra native observations or physical path stages.

## 3. Nearest-boundary stability under observer changes

For a nonempty closed opening boundary set G_a, let

\[
d_a(x)=\inf_{p\in G_a}\|x-p\|.
\]

For any x,y, the triangle inequality gives d_a(y)<=d_a(x)+||y-x||; interchanging x,y yields

\[
|d_a(y)-d_a(x)|\le\|y-x\|.
\]

Suppose a is uniquely nearest at x and

\[
m(x)=\min_{b\ne a}\{d_b(x)-d_a(x)\}>0.
\]

For every other b,

\[
d_b(y)-d_a(y)\ge m(x)-2\|y-x\|.
\]

Therefore **m(x)>2||y-x|| is a sufficient condition for the same unique nearest label at y.** Apply x=F_i,y=S_i. Failure of the condition is inconclusive: the label may or may not change. Ties do not have a unique winner. This is an elementary geometric fact, not a new model assumption.

When distances and displacement norms are numerical, the theorem is not an automatic rigorous certificate. If each distance has a proven absolute error e_d and the displacement norm a proven error e_b, a conservative sufficient lower bound is

`m_hat - 2*e_d - 2*(b_hat + e_b) > 0`.

The inherited tolerances are heuristic numerical screening, not proven e_d/e_b. Record a numerical margin test as such, and use the independent high-precision comparison without claiming interval certification.

## 4. A useful distinction about approach and labels

For an adjacent frozen pair whose labels are a then b, calculate all four endpoint quantities d_a(F_i), d_a(F_j), d_b(F_i), d_b(F_j), not just the names of the winners. A switch can occur while both boundaries become more distant. A shrinking center radius does not entail approaching an opening. The same reasoning applies to scheduled samples.

## 5. Existing data is not every printed state table

The inherited central manuscript (archived as `source_snapshots/central.tex` in NCM-Z-01), lines approximately 1344–1418, explicitly identifies its four-update decimal vectors as **rational comparison centers** used in an enclosure proof. Their presence is not evidence of a concrete saved producer trajectory through those centers. Follow the underlying evidence indexes for an actual retained trajectory, or report that only comparison data are available. Never call native F to fill the missing history.

Likewise, observation integrity does not establish original producer execution. The source-bound retained history is analyzed at the evidence level it actually has; this task adds readout/geometry accounting, not a retrospective native replay certificate.
