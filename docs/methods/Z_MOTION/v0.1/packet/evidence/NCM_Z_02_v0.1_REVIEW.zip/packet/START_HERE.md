# NCM-Z-02 v0.1 — start here

## Give Codex this instruction

Execute **NCM-Z-02 v0.1 — Retained-history Z motion: frozen observer versus scheduled observer** under the included work order. First admit one existing longer native-triad history using the outcome-independent selection rules. Freeze its identity and window before calculating opening-proximity results. Then compare the same stored states with the staged observer frozen and scheduled against the unchanged PLUS zero geometry. No native evaluations, fabricated intermediate states, EMA updates, Git, model/application changes or publication. Return the complete bounded review package, including a clear no-data result if no admissible longer history is available.

## Read in this order

1. `CODEX_NCM_Z_02_RETAINED_HISTORY_WORK_ORDER_v0.1.md` — task authority, selection rules, calculations, outputs and stop.
2. `MATHEMATICAL_BRIEF.md` and `PREDECLARED_LIMITS.json` — the exact comparisons and bounded predeclared plan.
3. `references/NCM_Z_01_START_HERE.md`, `references/NCM_Z_01_REPORT.md`, and `references/NCM_Z_01_GPT_REVIEW.md` — existing results and limitations.
4. `evidence/NCM_Z_01_v0.1_REVIEW.zip` — immutable original evidence, source snapshots and formulas as needed. Do not execute its old helpers or overwrite this archive.

## What this packet does not contain

It does **not** contain a newly selected longer trajectory. Locating and admitting one from the named Windows source route is the first part of Codex's task. The included parent/export contain the same old two native states at updates 0 and 1 and may be used only as reference/regression data. No history was searched, generated or analyzed in preparing this packet.

No need for the author to install anything, rerun `apply_candidate.py`, or describe more geometry. Use Command Prompt and the existing `torment` environment. All authored work stays in a new external directory.

## Integrity

`PACKET_MANIFEST.json` lists sizes and SHA-256 hashes for every packet file except itself. `REFERENCE_INTAKE_VERIFICATION.json` records the bounded prior-archive verification during preparation. A ZIP receipt is supplied outside this packet to avoid self-reference. These checks concern packaging, not new scientific results.
