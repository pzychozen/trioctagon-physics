from pathlib import Path,PurePosixPath
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(n,v): (ROOT/n).write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8")
out=ROOT/"packet";out.mkdir(exist_ok=False)
with zipfile.ZipFile(ROOT/"inputs/NCM_Z_02_Codex_Packet_v0.1.zip") as z:
    m=json.loads(z.read("PACKET_MANIFEST.json"))
    assert set(z.namelist())=={e["path"] for e in m["entries"]}|{"PACKET_MANIFEST.json"}
    for e in m["entries"]:
        b=z.read(e["path"]);assert len(b)==e["bytes"] and sha(b)==e["sha256"]
    assert z.read("CODEX_NCM_Z_02_RETAINED_HISTORY_WORK_ORDER_v0.1.md")== (ROOT/"inputs/CODEX_NCM_Z_02_RETAINED_HISTORY_WORK_ORDER_v0.1.md").read_bytes()
    for i in z.infolist():
        p=PurePosixPath(i.filename); assert not p.is_absolute() and ".." not in p.parts and "\\" not in i.filename
        dest=out/i.filename;dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(z.read(i))
old=out/"evidence/NCM_Z_01_v0.1_REVIEW.zip"
assert sha(old.read_bytes())=="92f9b1ab59d60333470956d49681849939e6def28d8bc84d976261f045f28a2e"
with zipfile.ZipFile(old) as z:
    assert z.testzip() is None
    m=json.loads(z.read("OUTPUT_HASHES.json"))
    for e in m["entries"]:
        assert sha(z.read(e["path"]))==e["sha256"]
    selected=[x for x in z.namelist() if x.startswith("source_snapshots/")]
    dest=ROOT/"accepted_sources";dest.mkdir(exist_ok=False)
    source=json.loads(z.read("SOURCE_MANIFEST.json"))
    for path in selected: (dest/Path(path).name).write_bytes(z.read(path))
    dump("ACCEPTED_SOURCES.json",source)
dump("PACKET_VERIFICATION.json",{"packet_entries_verified":len(json.loads((out/"PACKET_MANIFEST.json").read_text())["entries"]),"standalone_workorder_identical":True,"prior_review_archive_sha256":sha(old.read_bytes()),"prior_payload_members_verified":len(m["entries"]),"copied_source_snapshots":selected,"helpers_executed":False})
print((out/"MATHEMATICAL_BRIEF.md").read_text(encoding="utf-8"))
print((out/"PREDECLARED_LIMITS.json").read_text(encoding="utf-8"))
