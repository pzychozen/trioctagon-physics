from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import sys,os,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def js(p,v): p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
for name in ("inputs","logs","sources","figures","scratch","mplconfig"): (ROOT/name).mkdir(exist_ok=True)
assert Path(sys.executable).parent.name.lower()=="torment"
assert sys.version_info[:2]==(3,11)
js(ROOT/"ENVIRONMENT.json",{"utc":datetime.now(timezone.utc).isoformat(),"executable":sys.executable,"version":sys.version,"shell":"Command Prompt","native_evaluations":0,"ema_updates":0,"offline":True})
paths=[Path(r"C:\Users\Notandi\Downloads\NCM_Z_02_Codex_Packet_v0.1.zip"),Path(r"C:\Users\Notandi\Downloads\CODEX_NCM_Z_02_RETAINED_HISTORY_WORK_ORDER_v0.1.md")]
entries=[]
for p in paths:
    b=p.read_bytes(); (ROOT/"inputs"/p.name).write_bytes(b)
    entries.append({"path":str(p),"bytes":len(b),"sha256":sha(b),"copy":"inputs/"+p.name})
js(ROOT/"PROTECTED.before.json",entries)
with zipfile.ZipFile(ROOT/"inputs"/paths[0].name) as z:
    infos=z.infolist()
    assert len({i.filename.casefold() for i in infos})==len(infos)
    for i in infos:
        p=PurePosixPath(i.filename)
        assert not p.is_absolute() and ".." not in p.parts and "\\" not in i.filename and ":" not in i.filename
        assert (i.external_attr>>16)&0o170000 != 0o120000
        assert i.file_size<=40*1024**2
    assert sum(i.file_size for i in infos)<=128*1024**2
    assert z.testzip() is None
    inventory=[{"path":i.filename,"bytes":i.file_size,"sha256":sha(z.read(i))} for i in infos if not i.is_dir()]
    js(ROOT/"PACKET_INVENTORY.json",inventory)
    manifests=[i for i in infos if i.filename.endswith("PACKET_MANIFEST.json")]
    assert len(manifests)==1
    manifest=json.loads(z.read(manifests[0]))
    print(json.dumps({"packet":entries[0],"files":inventory,"manifest":manifest},indent=2))
