"""Independent document-only review. No historical script/module execution.
Allowed work: file hashes, JSON-pointer lookup, literal/Decimal transcription,
PDF text/layout inspection. This script performs no scientific evaluations.
"""
from pathlib import Path, PurePosixPath
from decimal import Decimal, localcontext
from zipfile import ZipFile
from collections import OrderedDict
import json, hashlib, re, unicodedata, ast, platform
import fitz

ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'received'
checks=[]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads((R/p).read_text(encoding='utf-8'),parse_float=Decimal)
def text(p): return (R/p).read_text(encoding='utf-8')
def require(name, cond, details):
    checks.append({'name':name,'passed':bool(cond),'details':details})
    if not cond: raise AssertionError(name)
def point(file, ptr):
    x=load(file)
    for k in ptr.strip('/').split('/'):
        if not ptr: break
        k=k.replace('~1','/').replace('~0','~')
        x=x[int(k)] if isinstance(x,list) else x[k]
    return x

def norm(s):
    return re.sub(r'\s+','',unicodedata.normalize('NFKC',s).replace('−','-'))

zip_path=Path('/mnt/data/NCM_Z_DOC_01_v0.1_REVIEW.zip')
expected='65665ee66784dd12af536a77a647f5cc8969cb4b3f8c51eff4fd94fde98145a5'
require('archive identity matches supplied receipt', sha(zip_path)==expected and zip_path.stat().st_size==12152471,{'sha256':sha(zip_path),'bytes':zip_path.stat().st_size})
with ZipFile(zip_path) as z:
    names=z.namelist()
    safe=len(names)==len(set(names))==len({n.casefold() for n in names})
    for i in z.infolist():
        p=PurePosixPath(i.filename)
        safe &= not p.is_absolute() and '..' not in p.parts and ':' not in i.filename and '\\' not in i.filename and ((i.external_attr>>16)&0o170000)!=0o120000
    require('outer archive safe unique members CRC and extraction',safe and z.testzip() is None and all(z.read(n)==(R/n).read_bytes() for n in names),len(names))
manifest=load('OUTPUT_HASHES.json')['entries']
require('manifest exact set and all payload hashes',set(e['path'] for e in manifest)==set(names)-{'OUTPUT_HASHES.json'} and all(sha(R/e['path'])==e['sha256'] and (R/e['path']).stat().st_size==e['bytes'] for e in manifest),{'payloads':len(manifest),'members':len(names)})
sm=load('SOURCE_MANIFEST.json')
require('copied inputs and original records', all(sha(R/e['path'])==e['sha256'] and (R/e['path']).stat().st_size==e['bytes'] for e in sm['copied_inputs']) and all(e['before']==e['after'] and e['unchanged'] for e in sm['original_consulted_files']),{'copies':len(sm['copied_inputs']),'Windows_preservation_records':len(sm['original_consulted_files']),'live_Windows_files_inspected':False})
old=[]
for p in sorted((R/'packet').rglob('*.zip')):
    original=Path('/mnt/data')/p.name
    with ZipFile(p) as z:
        ns=z.namelist()
        assert z.testzip() is None and len(ns)==len(set(ns))
    eq=original.exists() and p.read_bytes()==original.read_bytes()
    old.append({'path':str(p.relative_to(R)),'sha256':sha(p),'matches_prior_upload':eq,'members':len(ns)})
require('retained archives match prior uploads', all(x['matches_prior_upload'] for x in old),old)
originals=[]
for e in sm['original_consulted_files']:
    p=Path('/mnt/data')/e['path'].split('\\')[-1]
    originals.append({'name':p.name,'available':p.exists(),'matches_intake':p.exists() and sha(p)==e['before']['sha256']})
require('uploaded original packet and work order agree with intake',all(x['matches_intake'] for x in originals), originals)
ext=load('EXTRACTION_MANIFEST.json')
for e in ext:
    with ZipFile(R/e['archive']) as z: assert z.read(e['member'])==(R/e['extracted_path']).read_bytes()
require('extracted members exact bytes',True,len(ext))
fig=load('FIGURE_PROVENANCE.json')
require('all copied figures unchanged',all((R/e['source_extracted_file']).read_bytes()==(R/e['manuscript_file']).read_bytes() and sha(R/e['manuscript_file'])==e['sha256'] for e in fig),len(fig))

# No scientific derivation: compare stored tokens and decimal rounding only.
cells=load('manuscript/tables/TABLE_PROVENANCE.json')['cells'];tables=OrderedDict()
for c in cells:
    x=point(c['source_file'],c['json_pointer'])
    assert (x if isinstance(x,list) else str(x))==c['original_token']
    if c['rule'].startswith('Decimal'):
        nd=int(re.search(r'(\d+) places',c['rule']).group(1))
        with localcontext() as ctx:
            ctx.prec=160;shown=format(Decimal(str(x)),('+' if 'explicit sign' in c['rule'] else '')+f'.{nd}f')
    else:shown=', '.join(map(str,x)) if isinstance(x,list) else str(x)
    assert shown==c['display']
    tables.setdefault(c['table'],OrderedDict()).setdefault(str(c['row']),[]).append(shown)
for table, rows in tables.items():
    mdrows=[[v.strip() for v in line.strip('|').split('|')] for line in text(f'manuscript/tables/{table}.md').splitlines()[2:]]
    assert len(mdrows)==len(rows)
    for row,vals in zip(mdrows,rows.values()):assert row[1:]==vals
require('table token pointers rounding and ordered cell placement',True,{'tables':len(tables),'cells':len(cells)})
manual=load('manuscript/tables/MANUAL_TABLE_PROVENANCE.json')
for c in manual:
    if 'json_pointer' in c:assert point(c['source_file'],c['json_pointer'])==c['original_token']
    if 'line' in c:assert c['original_token'] in text(c['source_file']).splitlines()[c['line']-1]
require('manual table provenance',True,len(manual))
prose=load('PROSE_NUMERIC_PROVENANCE.json')
for e in prose:
    x=point(e['source_file'],e['json_pointer']);assert str(x)==e['original_token']
    d=Decimal(str(x));s=Decimal(e['display'])
    if 'magnitude' in e['rule']:d=abs(d)
    with localcontext() as ctx:
        ctx.prec=160;assert d.quantize(Decimal(1).scaleb(s.as_tuple().exponent))==s
require('additional prose numeric transcription',True,len(prose))

claims=load('CLAIM_SOURCE_MAP.json');note=text('manuscript/NOTE.md');ids={c['id'] for c in claims}
assert ids==set(re.findall(r'\[(C\d\d)\]',note))=={f'C{i:02d}' for i in range(1,52)}
count_ptrs=0;count_def=0
for c in claims:
    e=c['report'];assert text(e['file']).splitlines()[e['line']-1]==e['heading']
    for e in c['ledger_references']:point(e['file'],e['pointer']);count_ptrs+=1
    for e in c['definitions']:assert (R/e['file']).is_file();count_def+=1
    if 'review' in c:assert (R/c['review']['file']).is_file()
require('all claim IDs report locators and ledger pointers resolve',True,{'claims':len(claims),'ledger_pointers':count_ptrs,'definition_locators':count_def})
equations=[' '.join(s.strip() for s in b.splitlines()) for b in re.findall(r'\$\$\s*\n(.*?)\n\$\$',note,re.S)]
eq_records=load('manuscript/EQUATION_TRANSCRIPTION.json')
require('display equation expressions match editable source',equations==[e['latex'] for e in eq_records],len(equations))
links=[]
for p in list((R/'manuscript').rglob('*.md'))+[R/n for n in ['START_HERE.md','PLAIN_LANGUAGE_GUIDE.md','CLAIM_SOURCE_MAP.md','EVIDENCE_INDEX.md','PLACEMENT_AND_CONTRIBUTION.md','CORRECTIONS_AND_DISPOSITION.md']]:
    s=re.sub(r'\$\$.*?\$\$','',p.read_text(encoding='utf-8'),flags=re.S)
    for match in re.finditer(r'!?\[[^\]]*\]\(([^)]+)\)',s):
        target=match.group(1);assert not re.match(r'\w+://',target)
        dest=(p.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R) and dest.is_file()
        links.append({'source':str(p.relative_to(R)),'target':target})
require('all authored Markdown links resolve in package',True,len(links))

pdf_records=[]
full_text=''
page_for_table={'z01_points':5,'z02_points':5,'chords':5,'intensity':10,'radial':13,'displacements_early':14,'displacements_late':15}
for b in load('BUILD_RECORD.json')['outputs']:
    p=R/b['pdf'];d=fitz.open(p)
    assert sha(p)==b['sha256'] and len(d)==b['pages']
    pt=[page.get_text(sort=True) for page in d];full_text+='\n'.join(pt)
    if len(d)==18:
        for c in cells:
            assert norm(c['display']) in norm(pt[page_for_table[c['table']]-1]),c
        assert set(re.findall(r'\[(C\d\d)\]','\n'.join(pt)))==ids
        pages=note.split('<!-- page -->')
        assert len(pages)==18
        # All prose and table source numerals are inspected in addition to the exact table token test.
    out_of_bounds=[];bad_glyph=[]
    for no,page in enumerate(d,1):
        if '\ufffd' in page.get_text():bad_glyph.append(no)
        for word in page.get_text('words'):
            x0,y0,x1,y1,*_=word
            if x0 < -0.5 or y0 < -0.5 or x1>page.rect.width+0.5 or y1>page.rect.height+0.5:out_of_bounds.append([no,*word])
    assert not out_of_bounds and not bad_glyph
    pdf_records.append({'path':b['pdf'],'sha256':sha(p),'pages':len(d),'extractable_chars':sum(map(len,pt)),'links':sum(len(page.get_links()) for page in d),'figures':sum(len(page.get_images()) for page in d),'text_outside_page':out_of_bounds,'replacement_char_pages':bad_glyph})
require('actual PDFs identities page counts and text bounds',True,pdf_records)
require('all 83 table values and 51 claim tags present in actual methods PDF',True,{'table_values':len(cells),'claim_tags':len(ids),'test':'Unicode-normalized PDF extracted text; visual review separately required'})
require('no incomplete placeholders in narrative',not any(x in note+text('PLAIN_LANGUAGE_GUIDE.md') for x in ['TODO','TBD','INSERT HERE','turn0search']),True)

# Review helper files as text only; do not run publisher QA or old checks.
helper_imports={}
for name in ['document_qa.py','extract_document_data.py','make_review_documents.py','manuscript/build_document.py','package_review.py','verify_extract.py']:
    nodes=ast.parse(text(name));names=[]
    for n in ast.walk(nodes):
        if isinstance(n,ast.Import):names.extend(a.name for a in n.names)
        elif isinstance(n,ast.ImportFrom):names.append(n.module)
    assert not any(x and (x.startswith('kernel_physics') or x.startswith('evidence.') or x.startswith('packet.')) for x in names)
    helper_imports[name]=names
require('document helper imports checked without executing',True,helper_imports)

summary={'task':'NCM-Z-DOC-01 independent documentation review','platform':platform.platform(),'python':platform.python_version(),'status':'PASS','groups_passed':len(checks),'checks':checks,'scientific_evaluations':0,'old_producer_or_checker_runs':0,'new_document_builds':0,'render_only':True,'no_original_files_modified':True,'limits':['No live Windows original verification.','No native calculations, prestage reconstruction, source-budget/observer/EMA evaluation or scientific certification.','Structural claim-map validity is not a substitute for manual content review.','PDF citations are printed tags; relative navigable references are in package Markdown.']}
(ROOT/'checks/INDEPENDENT_DOCUMENT_QA.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=str)+'\n')
print(json.dumps({'status':'PASS','groups':len(checks),'payloads':len(manifest),'table_cells':len(cells),'claims':len(claims),'ledger_pointers':count_ptrs,'equations':len(equations),'links':len(links),'pages':sum(p['pages'] for p in pdf_records),'prose_checks':len(prose)},indent=2))
