# Certified Capture of the Collective-Turning Trajectory in the Native Triad

Author: **Hilmir Frímann Halldórsson (pzychozen)**. Research manuscript v0.1, 11 November 2026, Atlantic/Reykjavik.

**Accepted underlying mathematics; manuscript and author review pending.** This seven-page companion note supplies the accepted finite connection between the original collective-turning entrance and its inherited coherent-relaxation domain. Strict inclusion is certified at update 50, which is a sufficient index rather than a certified earliest entry. The neighborhood corollary is qualitative and keeps the coefficients fixed.

Open [the manuscript](NATIVE_TURNING_CAPTURE_COMPANION_v0.1.pdf). Its editable source is [main.tex](main.tex), with [references.tex](references.tex) and the [generated terminal-bound table](tables/terminal_bounds.tex). The table is the sole visual; no new trajectory or optional figure was generated.

The note is self-contained for its principal certificate and neighborhood arguments. The full accepted investigation and internal acceptance are directly accessible under [evidence/accepted_capture](evidence/accepted_capture/README.md), with their original bytes unchanged. The untouched acceptance archive is under `archives/`. There is one manuscript-level extracted acceptance tree; the archives and nested records already present in the supplied evidence remain preserved as provenance.

The [claim crosswalk](MANUSCRIPT_CLAIM_LEDGER.json) maps all 16 original ledger IDs to final manuscript section/equation/table labels, page numbers and source lines. Those IDs are not the investigation's work-package numbering and do not count 16 new theorems. [SOURCE_INVENTORY.json](SOURCE_INVENTORY.json) records the reading edition and precise input identities. [CURRENT_STATUS.md](CURRENT_STATUS.md) explains the later manuscript commission without editing the historical acceptance wording.

See [BUILD.md](BUILD.md) for the cached, untrusted TeX build. This was document preparation only: no trajectory search, certificate generation, scientific checker, damaged-input controls or historical suite was rerun. The original Windows scientific execution and GPT's later Linux replay are described separately in the manuscript and retained evidence.

Document checks are in `verification/`: the final build receipt and messages, TeX log, resolved reference map, font embedding checks, table transcription, PDF metadata/text, rendered pages and [final page inspection](verification/FINAL_PAGE_INSPECTION.json). All seven final pages were visually inspected. The final build has no compiler warnings, unresolved references/citations or unembedded fonts. Intermediate layout fixes and document-helper discovery issues are recorded honestly in the execution history; there are no outstanding mathematical discrepancies.

The final review manifest excludes only itself. The included delivery audit records an actual preseal member audit; the external final-delivery audit verifies every member of the completed ZIP, including that audit and the manifest. The external `.zip.sha256` binds the final archive. No fonts, caches or temporary TeX outputs are distributed separately. The earlier published edition remains unchanged, and no publication or Git operation occurred.
