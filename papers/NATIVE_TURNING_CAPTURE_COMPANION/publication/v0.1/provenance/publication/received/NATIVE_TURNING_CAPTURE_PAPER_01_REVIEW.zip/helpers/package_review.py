"""Package the completed document and preserved evidence; verify every member."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, hashlib, json, os, shutil, sys, zipfile
E=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--delivery-dir',required=True);p.add_argument('--pdf-output-dir',required=True);a=p.parse_args()
D=Path(a.delivery_dir).resolve();O=Path(a.pdf_output_dir).resolve()
assert os.environ.get('CONDA_DEFAULT_ENV')=='torment' and sys.flags.optimize==0
assert not D.exists() and not D.is_relative_to(E) and not O.is_relative_to(E)
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def members():
    result=[]
    for f in sorted(E.rglob('*')):
        if not f.is_file():continue
        assert not f.is_symlink() and f.resolve().is_relative_to(E)
        rel=f.relative_to(E).as_posix()
        assert f.suffix.lower() not in ['.ttf','.otf','.woff','.woff2','.pyc','.aux','.toc','.xdv','.log']
        assert not any(part in ['__pycache__','fontcache','tmp'] for part in f.parts)
        b=f.read_bytes();result.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
    return result
def archive(target,items,mode):
    with zipfile.ZipFile(target,mode,compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for row in items:
            b=(E/row['path']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
            info=zipfile.ZipInfo(row['path'],date_time=(2026,11,11,0,0,0));info.create_system=3;info.external_attr=0o100644<<16
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
def audit(target,items):
    expected={x['path']:x for x in items};checked=[]
    with zipfile.ZipFile(target) as z:
        names=z.namelist();assert len(names)==len(set(names))==len({n.casefold() for n in names})
        assert set(names)==set(expected)
        for name in names:
            path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
            b=z.read(name);row=expected[name]
            assert b==(E/name).read_bytes() and sha(b)==row['sha256'] and len(b)==row['bytes']
            checked.append({**row,'reopened_crc_bytes_sha256':'PASS'})
    return checked
start=now();pdfname='NATIVE_TURNING_CAPTURE_COMPANION_v0.1.pdf';pdf=E/pdfname
inspection=json.loads((E/'verification/FINAL_PAGE_INSPECTION.json').read_text())
assert inspection['status']=='PASS' and inspection['pdf_sha256']==sha(pdf.read_bytes()) and inspection['page_count']==7
assert inspection['all_final_pages_inspected_after_final_rebuild']
for item in json.loads((E/'PRESERVED_INPUTS.json').read_text())['files']:
    b=(E/item['path']).read_bytes();assert sha(b)==item['sha256'] and len(b)==item['bytes']
status=json.loads((E/'CURRENT_STATUS.json').read_text());assert not status['published'] and not status['manuscript_accepted']
assert not (E/'REVIEW_MANIFEST.json').exists() and not (E/'DELIVERY_AUDIT.json').exists()
D.mkdir(parents=True);target=D/'NATIVE_TURNING_CAPTURE_PAPER_01_REVIEW.zip'
payload=members();archive(target,payload,'x');preseal=audit(target,payload)
write(E/'DELIVERY_AUDIT.json',{'status':'PASS','checked_utc':now(),'kind':'Actual preseal archive reopening; final all-member audit is external to avoid self-reference','member_count':len(preseal),'members':preseal,'not_present_in_this_pass':['DELIVERY_AUDIT.json','REVIEW_MANIFEST.json'],'final_audit_filename':'NATIVE_TURNING_CAPTURE_PAPER_01_FINAL_DELIVERY_AUDIT.json','scientific_runs':0})
manifest=members();write(E/'REVIEW_MANIFEST.json',{'task':'NATIVE_TURNING_CAPTURE_PAPER_01','self_excluded':'REVIEW_MANIFEST.json','files':manifest})
final=members();archive(target,final,'w');checked=audit(target,final)
with zipfile.ZipFile(target) as z:
    embedded=json.loads(z.read('REVIEW_MANIFEST.json'))
    assert {row['path'] for row in embedded['files']}|{'REVIEW_MANIFEST.json'}==set(z.namelist())
    for row in embedded['files']:
        b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
archivehash=sha(target.read_bytes());sidecar=D/(target.name+'.sha256');sidecar.write_text(archivehash+'  '+target.name+'\n',encoding='ascii')
O.mkdir(parents=True,exist_ok=True);standalone=O/pdfname;assert not standalone.exists();shutil.copyfile(pdf,standalone)
assert sha(standalone.read_bytes())==inspection['pdf_sha256']
write(D/'NATIVE_TURNING_CAPTURE_PAPER_01_FINAL_DELIVERY_AUDIT.json',{'status':'PASS','started_utc':start,'finished_utc':now(),'python':sys.executable,'argv':sys.argv,'conda_environment':'torment','archive':str(target),'archive_bytes':target.stat().st_size,'archive_sha256':archivehash,'sidecar_matches':sidecar.read_text().split()[0]==archivehash,'all_final_members_reopened':True,'member_count':len(checked),'members':checked,'self_excluding_manifest_verified':True,'relative_archive_names_safe_unique':True,'standalone_pdf':str(standalone),'standalone_pdf_sha256':sha(standalone.read_bytes()),'standalone_matches_archived_and_inspected_pdf':True,'final_pages':7,'new_scientific_executions':0,'publication':False})
summary={'status':'PASS','archive':str(target),'archive_sha256':archivehash,'archive_bytes':target.stat().st_size,'verified_members':len(checked),'manifest_entries':len(manifest),'standalone_pdf':str(standalone),'pdf_sha256':sha(standalone.read_bytes()),'page_count':7}
out=json.dumps(summary,indent=2)+'\n';(D/'PACKAGING_OUTPUT.txt').write_text(out,encoding='utf-8');print(out,end='')
