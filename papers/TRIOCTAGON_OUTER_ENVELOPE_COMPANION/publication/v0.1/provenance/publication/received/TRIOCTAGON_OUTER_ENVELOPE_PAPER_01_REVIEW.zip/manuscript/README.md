# Outer-envelope companion manuscript, v0.1

**Noncollision Facet Transition and Exact Outer-Envelope Classification in the Folded Tri-Octagon**

Accepted mathematical investigation; manuscript and author review pending. Project-internal research manuscript, not externally peer reviewed. Prepared 14 November 2026. This is a manuscript return, not a publication package.

Read the [12-page manuscript](TRIOCTAGON_OUTER_ENVELOPE_COMPANION_v0.1.pdf). Editable sources are [main.tex](main.tex), [references.tex](references.tex), [tables](tables/) and [figure assets](figures/). The paper contains the concrete noncollision event, full closed A-B classification, ridge-closure completeness proof, endpoint attachment and all 26 exact orbit representatives.

The [claim ledger](MANUSCRIPT_CLAIM_LEDGER.json) maps O01-O04 to actual final labels, pages and raw evidence identities. The [access guide](ACCESS_AND_EVIDENCE_MAP.md) links the preserved sources and evidence. [BUILD.md](BUILD.md) describes document-only reproduction in Windows Command Prompt using `conda activate torment`.

The [current status](CURRENT_STATUS.json) and [handoff](HANDOFF.md) distinguish accepted mathematics from the pending review of this actual manuscript. The original investigation, acceptance extraction, archive and commissioning records are retained unchanged, with the complete 187-file incoming mapping in [PRESERVED_INPUTS.json](PRESERVED_INPUTS.json).

The [document checks](verification/DOCUMENT_CHECK.json), [transcription checks](verification/TRANSCRIPTION_CHECK.json), [font checks](verification/FONT_CHECK.json), [reference checks](verification/REFERENCE_CHECK.json), [build receipt](verification/final_build/BUILD_RECEIPT.json) and [all-page visual inspection](verification/VISUAL_INSPECTION.json) bind to the delivered PDF. Every final page render is under [verification/pages](verification/pages/).

PDF SHA-256: `1b046265672f449808050b2ca542415ca4c0d29f02528d051109eec14d55302b`.

No scientific checker, geometry generator, root search, proof replay or historical suite ran during this commission. No repository write, commit, push or publication occurred. Prior papers remain untouched. Historical reproduction commands are evidence, not authoring instructions.

The payload manifest covers every other file in this delivery by raw bytes. The ZIP checksum and archive audit are external to the ZIP. Keep the whole package when forwarding for GPT and author review.
