# Tri-Octagon Physics

**v0.1.0 research/developer preview candidate**, by Hilmir Frímann Halldórsson.
A mathematical-physics toy model with exact folded Tri-Octagon geometry,
nonlinear complex triad/cycle dynamics, graph coverings and invariant sectors,
chirality/orientation geometry, an exact reference scaffold, passive
observer/readout constructions, and local transverse-chirality analysis.
An executable Python kernel, reproducible scientific records and a companion
scientific UI connect the mathematics to explicit numerical experiments.
This is **not the TORMENT production memory system**.

- **[SCIENTIFIC DOMAINS](scientific_domains/README.md)** - current core, historical TORMENT and experimental Research Lab ownership and authority.
- **[READ THE RESEARCH](#papers-a-g)** — seven repository publication editions below.
- **[MATHEMATICAL ATLAS](research/mathematical_atlas/README.md)** — first-principles derivations, exact checks, counterexamples, scope boundaries and open interfaces for the current kernel mathematics.
- **[USE THE PYTHON KERNEL](#use-the-python-kernel)** — build, install and save a small explicit experiment.
- **[RUN THE SCIENTIFIC UI](apps/scientific_ui/README.md#public-installation)** — install the separately certified, locked kernel/UI pair.

**Scientific boundary:** this preview is not an experimentally validated physical
theory. It establishes no physical field attached to the shell, gravity theory,
electromagnetic/magnetism theory, teleportation mechanism, dark-matter explanation,
physical energy law, geometry↔dynamics physical coupling, Z↔six-opening spatial
registration, or host/gap causal dynamics. Mathematical identities, numerical
evidence and open physical interfaces remain distinct.

<a id="papers-a-f"></a>

## Papers A-G

These are the authoritative repository publication editions. Earlier
editions remain available as historical/superseded research; mathematical source
versions and publication editions need not have the same number.

| Paper | Current publication PDF | Source / recorded status |
|---|---|---|
| A — v1.0 | [Cycle-Covering Dynamics of a Three-State Nonlinear Kernel](papers/PAPER_A/publication/PAPER_A_CYCLE_COVERING_DYNAMICS_v1.0.pdf) | [Publication source](papers/PAPER_A/publication/paper_A_publication.md); scientific source v0.5.1. |
| B — v0.1.2 | [Triadic Chirality and Orientation Geometry](papers/PAPER_B/publication/v0.1.2/PAPER_B_TRIADIC_CHIRALITY_AND_ORIENTATION_GEOMETRY_PUBLICATION_v0.1.2.pdf) | [Edition and evidence](papers/PAPER_B/publication/v0.1.2/README.md); scope/citation revision. |
| C — v1.0.1 | [Exact Geometry of the Folded Tri-Octagon Module](papers/PAPER_C/publication/v1.0.1/PAPER_C_EXACT_TRIOCTAGON_GEOMETRY_v1.0.1.pdf) | [Edition and evidence](papers/PAPER_C/publication/v1.0.1/README.md); scientific source v0.3.1. |
| D — v0.1.1 | [Tri-Octagon Reference-Scaffold Geometry](papers/PAPER_D/v0.1.1/publication/PAPER_D_REFERENCE_SCAFFOLD_v0.1.1.pdf) | [Edition and scoped acceptance](papers/PAPER_D/v0.1.1/README.md). |
| E — v0.1.1 | [The Tri-Octagon Z Manifold](papers/PAPER_E/v0.1.1/publication/PAPER_E_Z_MANIFOLD_v0.1.1.pdf) | [Recorded review/revision status](papers/PAPER_E/v0.1.1/README.md); owner-authorized for this preview at that status. |
| F — v0.2 | [Transverse Chirality, Dihedral Harmonic Selection, and Local Linearization](papers/PAPER_F/PAPER_F_PUBLICATION_v0.2.pdf) | [Accepted scientific source and publication-build status](papers/PAPER_F/README.md); owner-authorized for this preview at that status. |
| G — v0.1.1 | [Geometry-Attached Axial Observables, Period-Doubling, and Certified Entrance Capture in the Tri-Octagon Map](papers/PAPER_G/v0.1.1/publication/PAPER_G_v0.1.1_LOCAL_REVIEW.pdf) | [Edition, source and publication disposition](papers/PAPER_G/README.md); author-authorized repository publication of the approved review artifact, unchanged. |

- [Kernel history and comparison — v0.1](papers/KERNEL_HISTORY_AND_COMPARISON/README.md)

The [owner publication disposition](PUBLIC_RELEASE_CONTENT_DISPOSITION_v0.1.md)
authorizes E/F public visibility/publication at their currently recorded
scientific/review status. It supersedes earlier owner-authorization-pending
notices without inventing another review round. No external peer review is claimed.

Paper G has a separate [author publication disposition](papers/PAPER_G/repository_publication/v0.1.1/PUBLICATION_DISPOSITION.md).
Its approved v0.1.1 PDF/source retain their review labels and exact bytes;
that later disposition authorizes repository publication without changing the science.

## Certified alternating-branch connection

[Certified Connection from Local Period-Doubling to the Captured Alternating Cycle in the Native Triad](papers/NATIVE_ALTERNATING_BRANCH_CONNECTION_COMPANION/README.md), by **Hilmir Frímann Halldórsson**, research edition v0.1. Companion to Paper G, with completed project-internal manuscript review and author-authorized repository publication.

Certified M2-to-M3 alternating-branch connection throughout `0 < mu <= 1/200`, with a separate explicit local-attraction result only on `0.004999 <= mu <= 0.005`. Full-range attraction remains unresolved. No kernel changes; Paper G and all earlier editions remain unchanged.

[Final PDF](papers/NATIVE_ALTERNATING_BRANCH_CONNECTION_COMPANION/publication/v0.1/NATIVE_ALTERNATING_BRANCH_CONNECTION_COMPANION_v0.1.pdf) | [Editable source and evidence](papers/NATIVE_ALTERNATING_BRANCH_CONNECTION_COMPANION/publication/v0.1/README.md).

## Strength-to-pattern identifiability

[Strength-to-Pattern Conversion and Readout Identifiability in the Tri-Octagon Native Kernel](papers/STRENGTH_PATTERN_IDENTIFIABILITY/README.md) by **Hilmir Frímann Halldórsson**.
v0.1 is an author-authorized repository research publication with project-internal review, not external peer review.
[Final PDF](papers/STRENGTH_PATTERN_IDENTIFIABILITY/v0.1/publication/SPR01_STRENGTH_PATTERN_IDENTIFIABILITY_v0.1.pdf) | [Publication disposition](papers/STRENGTH_PATTERN_IDENTIFIABILITY/v0.1/PUBLICATION_DISPOSITION.md). No runtime changes.

## Geometry-attached observation retention

[Information Retention Across Geometry-Attached Observations in the Tri-Octagon Kernel](papers/GEOMETRY_ATTACHED_OBSERVATION_RETENTION/README.md) by **Hilmir Frímann Halldórsson**.
v0.1 is an author-authorized repository research publication with project-internal review, not external peer review.
[Final PDF](papers/GEOMETRY_ATTACHED_OBSERVATION_RETENTION/v0.1/publication/SGO01_GEOMETRY_ATTACHED_OBSERVATION_RETENTION_v0.1.pdf) | [Publication disposition](papers/GEOMETRY_ATTACHED_OBSERVATION_RETENTION/v0.1/PUBLICATION_DISPOSITION.md). No runtime change.

## SU(3), CP and chirality reassessment

[SU(3), CP, and Chirality in Tri-Octagon Models: A Mathematical Reassessment](papers/SU3_CP_CHIRALITY_REASSESSMENT/README.md) by **Hilmir Frímann Halldórsson**.
v0.1 is an author-authorized repository research publication with project-internal review, not external peer review.
[Final PDF](papers/SU3_CP_CHIRALITY_REASSESSMENT/v0.1/publication/SCC01_SU3_CP_CHIRALITY_REASSESSMENT_v0.1.pdf) | [Publication disposition](papers/SU3_CP_CHIRALITY_REASSESSMENT/v0.1/PUBLICATION_DISPOSITION.md). No runtime change.

## Lens and toroidal geometry

- [Equal-Circle Lens Geometry - v0.1.1](papers/EQUAL_CIRCLE_LENS_GEOMETRY/README.md): accepted manuscript bytes retained, with the later acceptance receipt.
- [Homothetic Toroidal Models - v0.1.1](papers/HOMOTHETIC_TOROIDAL_MODELS/README.md): bounded minor revision and corrected reviewer attribution.

These mathematical repository-research candidates have project-internal review;
the edition notes state their exact status. Final toroidal revision verification
and owner confirmation of this public payload remain pending. No external peer
review, physical field validation or runtime change is claimed.

## Standalone Three-Way research

**NOT IMPLEMENTED RESEARCH — standalone mathematical research; no `kernel_physics`
authority or runtime dependency.** Three-Way is not implemented in the physics kernel.

- [Paper I — reconstruction v0.1](papers/three_way_reconstruction/README.md): [PDF](papers/three_way_reconstruction/output/pdf/three_way_reconstruction_v0.1.pdf), sources, provenance and retained validation.
- [Paper II — reciprocal hierarchy v0.1](papers/three_way_reciprocal_hierarchy/README.md): [PDF](papers/three_way_reciprocal_hierarchy/output/pdf/three_way_reciprocal_hierarchy_v0.1.pdf), sources, provenance and retained validation. **FINITE `S_3` BRIDGE ONLY.**

The two research lanes remain separate. **`THREE_WAY_RESEARCH = PARKED`**
(6 October 2026 repository checkpoint).

## Standalone SRG research

[Symbolic Resonance Geometry](SRG_REDISCOVERY/README.md) has a dedicated standalone research area. [SRG-I v0.1.1](SRG_REDISCOVERY/PAPERS/SRG_I_FOUNDATIONAL_RECONSTRUCTION/publication/v0.1.1/README.md) is accepted within internal manuscript scope; this curated publication candidate awaits owner approval of the exact payload. The accepted manuscript bytes and its historical/model boundaries are retained.

This research area adds no kernel authority or runtime dependency. The existing fixed November SRG initialization helper has a separate documented scope; it does not implement the complete historical programme reconstructed in SRG-I. The edition's source index and draft publication disposition describe access, attribution and reuse boundaries.

## Licensing and reuse

**Apache-2.0 applies to the approved software scope** described by the root
[LICENSE_SCOPE.md](LICENSE_SCOPE.md) and separate
[UI LICENSE_SCOPE.md](apps/scientific_ui/LICENSE_SCOPE.md).
Papers, research, figures, datasets, historical scientific material and other
excluded scientific content are **not automatically Apache-2.0 licensed**.
Public repository visibility does not broaden those rights.

Read the [software LICENSE](LICENSE), [UI LICENSE](apps/scientific_ui/LICENSE),
and [third-party notices](apps/scientific_ui/THIRD_PARTY_NOTICES.md).
Dependencies retain their own licenses; the original application wheel does not
bundle the kernel, Qt or other dependency binaries. Software is supplied without
warranty under its applicable license.

## Supported platform and runtime

The certified lane is **Windows x86-64, CPython >=3.11,<3.12**.
Other operating systems and Python versions may work but are **NOT CERTIFIED BY
v0.1.0**. No GPU, LLM or embedding model is required. Normal installed runtime is
offline; acquiring source and dependencies initially requires network access or
an existing verified cache. Git is needed for source builds, not installed runtime.

Only the declared [public API](kernel_physics/api.py) and documented workflows are
supported. Internal modules and historical research are not a promise of a stable
API. The UI uses its own exact kernel selection; **do not install the root kernel
from this quickstart into the UI environment**. See the
[release identity and draft notes](RELEASE_v0.1.0.md) for that intentional pairing.

## Use the Python kernel

The distribution is **trioctagon-physics**; imports use **kernel_physics**.
No PyPI publication is required or assumed. Install Git and a clean Windows
CPython 3.11 x64 interpreter with the `py` launcher. In PowerShell, from a directory
where you want the checkout, run:

```powershell
git clone https://github.com/pzychozen/trioctagon-physics
Set-Location trioctagon-physics
$source = (Get-Location).Path
$work = Join-Path $env:TEMP ('tri-kernel-' + [guid]::NewGuid().ToString('N').Substring(0,8))
py -3.11 -m venv $work
$kernelPython = Join-Path $work 'Scripts/python.exe'
& $kernelPython -I -B -m pip --isolated install setuptools==81.0.0 wheel==0.47.0 -r "$source/kernel_physics/requirements.txt"
& $kernelPython -I -B -m pip --isolated wheel --no-index --no-deps --no-build-isolation --wheel-dir "$work/dist" $source
& $kernelPython -I -B -m pip --isolated install --no-index --no-deps "$work/dist/trioctagon_physics-0.1.0-py3-none-any.whl"
& $kernelPython -I -B -m pip check
Set-Location $work
```

Use a clean complete checkout and keep build outputs outside it. The exact origin
URL spelling above (without `.git`) matches the canonical CI/reconstruction origin;
origin spelling is part of strict distribution provenance. Changing it can change
the manifest identity even when source bytes match. After a release tag exists,
check out the approved tag before building for that release. Until then, the
candidate commit is identified by the [release document](RELEASE_v0.1.0.md).

Save and inspect a small explicit triad experiment in the same PowerShell session:

```powershell
@'
from pathlib import Path
from kernel_physics.api import Parameters, State, Provenance, run, RunRecord

parameters = Parameters(eps=0.05, g=0.2, phase_strength=0.001, k=(1, 1, 1))
state = State(omega=(0.2+0.3j, -0.4+0.1j, 0.1-0.2j), update_index=0)
source = Provenance(kind="user_supplied", source_id="readme-example",
    source_revision=None, locator="README.md explicit triad example",
    literal_values={"eps": "0.05", "g": "0.2", "phase_strength": "0.001",
        "k": "(1,1,1)", "omega": "(0.2+0.3j,-0.4+0.1j,0.1-0.2j)"},
    notes="Illustrative user choices, not model defaults.")
record = run(state, parameters, topology="triad", updates=3,
    parameter_provenance=source, initialization_provenance=source,
    observers=(), readouts=(), diagnostics=())
path = Path("example.run.json")
path.write_text(record.to_json(), encoding="utf-8")
loaded = RunRecord.from_json(path.read_text(encoding="utf-8"))
assert loaded.to_json() == record.to_json()
print("Source commit:", loaded.data["implementation"]["commit"])
print("Saved:", path.resolve())
'@ | & $kernelPython -I -B -
```

The record stores the parameters, state, samples and implementation identity.
Loading does not run equations. [API/provenance details](kernel_physics/README.md)
and the [distribution verifier](tools/verify_distribution.py) describe strict
record/resume and artifact checks. Historical machine paths in that engineering
reference are provenance, not public setup requirements.

GitHub's **Download ZIP is for reading source/papers**, not a replacement for the
Git checkout or a provenance-bearing kernel sdist. The generated source ZIP lacks
the Git evidence/generated manifest needed for supported builds and record
production. A certified sdist or wheel preserves its own immutable provenance.
Editable installation is outside this preview's contract.

## Run the scientific UI

Follow the [complete UI installation and first-run guide](apps/scientific_ui/README.md#public-installation).
It installs the exact dependency closure and the certified kernel from source
`7b3a0fcec2c9bde6c9e1ea482fe1f1ea6b16793e`, separately from the repository/UI
candidate commit. Missing GitHub CLI/authentication or an unavailable Actions
artifact can fall through to strict source reconstruction. A downloaded artifact
that fails verification remains fatal. While this repository is private, fetching
its source still needs authorized access; anonymous public-endpoint verification
is deferred until visibility changes.

**Known issue:** numeric sliders may react to mouse-wheel events and replace a
precisely typed parameter value with a slider tick value. Before Run, verify the
visible/resolved request values. Completed records remain immutable and retain
the values actually used. This input-integrity issue is accepted for the preview
with disclosure; it is not harmless.

## Certification, attribution and historical navigation

The [P1–P12 parity closeout](kernel_physics/K2_PARITY_FINAL_CLOSEOUT.md) records
bounded mathematical/software parity; it does not establish physical laws.
[Kernel distribution CI](https://github.com/pzychozen/trioctagon-physics/actions/workflows/kernel-distribution.yml)
and [scientific UI CI](https://github.com/pzychozen/trioctagon-physics/actions/workflows/scientific-ui.yml)
must be read against their exact source commit. The release document identifies
the candidate and separately locked kernel. AI assistance/review attribution in
the papers is retained; it is not a claim of external peer review.

For attribution, identify Hilmir Frímann Halldórsson, the software release and
exact commit; cite each paper using its own title and edition above. No DOI or
public registry release is implied.

[CURRENT_STATE.md](CURRENT_STATE.md), [SOURCE_MANIFEST.md](SOURCE_MANIFEST.md),
and the [23 September publication checkpoint](papers/publication_updates/20260923_BC_scope/README.md)
preserve dated handoffs and previous scope. Research directories contain
historical/experimental and sometimes superseded work; their presence does not
promote it into the supported API or establish a physical interpretation.
`tools/verify_archive.py` validates a historical frozen archive baseline and is
**not the current release validation command**; its old checksums can disagree
with later files. Those receipts have not been rewritten to make that command pass.

---

## Historical landing page — 21–23 September 2026

The material below is preserved historical context. Its old environment paths,
test counts, publication status and archive-verification command do not override
the current quickstarts, paper index or owner disposition above.

# Publication checkpoint - 23 September 2026

Latest local publication editions: [Paper B v0.1.2](papers/PAPER_B/publication/v0.1.2/README.md), [Paper C v1.0.1](papers/PAPER_C/publication/v1.0.1/README.md), and [accepted Paper D v0.1.1](papers/PAPER_D/v0.1.1/README.md). [Paper A](papers/PAPER_A/publication/PAPER_A_CYCLE_COVERING_DYNAMICS_v1.0.pdf) is unchanged.

GPT accepted D's stated scientific scope and approved exactly five B/C scope/citation additions. B/C's preexisting mathematical content, coordinates, proofs, equations and figures are retained. C's publication label v1.0.1 is distinct from its preserved scientific manuscript v0.3.1. [Exact changes, checks, preservation and the combined proposed publication allowlist](papers/publication_updates/20260923_BC_scope/README.md) identify this local checkpoint. D's approved PDF was not rebuilt. No staging, commit, push, release, tag or DOI was performed.

Predecessors remain reachable: [B v0.1.1](papers/PAPER_B/publication/v0.1.1/PAPER_B_TRIADIC_CHIRALITY_AND_ORIENTATION_GEOMETRY_PUBLICATION_v0.1.1.pdf), [C v1.0](papers/PAPER_C/publication/PAPER_C_EXACT_TRIOCTAGON_GEOMETRY_v1.0.pdf), [D v0.1](papers/PAPER_D/README.md). The original archive manifests are frozen baseline receipts, not manifests of these later publication additions; use the combined checkpoint manifest for the proposed changes.

The publication clarification does not implement a reference-scaffold placement, restore historical Z/torus behavior or define a physical gap response. The current boundary/SRG preparation and face-state option remain as recorded in their existing implementation records. The older snapshot below retains its dated scope and is not a current claim that subsequent implementation/publication work never occurred.

---

## Earlier repository snapshot (preserved)

# Tri-Octagon physics

Mathematical-physics reconstruction of the Tri-Octagon, by Hilmir Frímann Halldórsson.

The aim is a rigorous mathematical toy model with explicit proofs, connections
to established mathematics/physics, an executable physics kernel, and eventually
an interactive visual physics laboratory. This is not the production TORMENT
memory system.

Start with **[CURRENT_STATE.md](CURRENT_STATE.md)**, the primary human/machine handoff.

The three authoritative layers are:

1. [Paper C](papers/PAPER_C/PAPER_C_EXACT_TRIOCTAGON_GEOMETRY_DRAFT_v0.3.1.md): exact folded geometry ([publication PDF](papers/PAPER_C/publication/PAPER_C_EXACT_TRIOCTAGON_GEOMETRY_v1.0.pdf)).
2. [Paper A](papers/PAPER_A/PAPER_A_CYCLE_COVERING_DYNAMICS_DRAFT_v0.5.1.md): three-state nonlinear dynamics ([publication PDF](papers/PAPER_A/publication/PAPER_A_CYCLE_COVERING_DYNAMICS_v1.0.pdf)).
3. [kernel_physics](kernel_physics/README.md): the clean executable mathematical implementation, with its recorded 41-test baseline.

The current frontier is the **geometry-to-dynamical-state interface**.
The [completed first-bridge study](research/top_to_recursive_bridge/TOP_TO_RECURSIVE_BRIDGE_DERIVATION.md)
establishes exact structural results and a conditional kinematic complex-space
construction. Three complex dynamical amplitudes have not yet been derived.
No physical coupling between geometry and dynamics is claimed yet.

This repository is a byte-preserved archive/transfer of the current state.
See [SOURCE_MANIFEST.md](SOURCE_MANIFEST.md) for origins and hashes, and
[supporting_research/INDEX.md](supporting_research/INDEX.md) for historical sources
kept outside the frozen baseline. Large historical archives are not included.

Verify package bytes without executing research:

```sh
python -B tools/verify_archive.py
```

For kernel tests, follow its README and pinned requirements. Historical test
results are archived as recorded; packaging did not rerun them. The original
bridge script and scientific documents retain their original absolute paths;
see CURRENT_STATE.md before attempting research-script execution on another host.


### Spherical edge extensions

[Detailed synthesis paper](papers/SPHERICAL_EDGE_EXTENSIONS/README.md) and
[accepted evidence, observation prototype and deferred questions](research/spherical_edge_extensions/README.md).


## Native Spherical Edge Observer source

The accepted P1R1 Spherical Edge Observer and its required export repair are available in the scientific application's C — Geometry workspace. See the [source publication record](apps/scientific_ui/publication/shell_observer/v0.1/README.md) and [application guide](apps/scientific_ui/README.md). This is source publication; no package release or installation replacement is included.


## Geometric origins and constant interpretations

[Tri-Octagon: Geometric Origins, Normalization, and Constant Interpretations](papers/GEOMETRIC_ORIGINS_AND_NORMALIZATION/publication/v0.2/README.md) — the expanded twelve-page historical companion, preserving the original mathematics and distinguishing the author's recollections from physical claims; [v0.1 historical edition](papers/GEOMETRIC_ORIGINS_AND_NORMALIZATION/publication/v0.1/README.md) remains unchanged.


## Paired-gap geometry and toroidal observations — Paper I

[Paired-Gap Geometry and Toroidal Observation Maps for the Folded Tri-Octagon](SRG_REDISCOVERY/PAPERS/PAIRED_GAP_GEOMETRY_OBSERVATION/publication/v0.1.1/README.md) — author-authorized v0.1.1 repository edition of the accepted 25-page manuscript. Includes editable source, computed figures and manuscript-reproduction inputs; conditional geometry/observation research, with no kernel or application changes.


## Paired driving and exterior identifiability — Paper II

[Paired Driving and Exterior Identifiability on a Conditional Periodic Carrier](SRG_REDISCOVERY/PAPERS/PAIRED_DRIVING_EXTERIOR_IDENTIFIABILITY/publication/v0.1/README.md) — author-authorized v0.1 repository edition of the accepted 33-page manuscript. Includes editable source, computed figures and manuscript-reproduction data; conditional shared-carrier, reception and timing analysis, with no kernel or application changes.

## Central geometry, Z readouts, and chiral response

[Central Geometry, Z Readouts, and Chiral Response in the Tri-Octagon Model](papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/README.md), by **Hilmir Frímann Halldórsson**.
Author-authorized repository research edition **v0.3**; the reviewed manuscript is preserved unchanged, with project-internal review and a completed scoped numerical audit and replay. No external peer review is claimed.
[PDF](papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.pdf) · [Edition and supporting evidence](papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/README.md) · [Publication disposition](papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/PUBLICATION_DISPOSITION.md).
No runtime or kernel changes.


## Collective turning and coherent relaxation

[Transient Collective Turning and Coherent Relaxation in the Native Triad — v0.1](papers/COLLECTIVE_TURNING_AND_COHERENT_RELAXATION/v0.1/README.md), by **Hilmir Frímann Halldórsson**. Author-authorized repository research edition with completed GPT project-internal scientific review and author review; no external peer review is claimed. [Published PDF](papers/COLLECTIVE_TURNING_AND_COHERENT_RELAXATION/v0.1/REVIEW.pdf). Turning, delayed graph response, and a separate finite-domain convergence theorem; no kernel changes.


[Certified Capture of the Collective-Turning Trajectory in the Native Triad - v0.1](papers/NATIVE_TURNING_CAPTURE_COMPANION/README.md), by **Hilmir Frímann Halldórsson (pzychozen)**. Author-authorized companion note: certified strict inclusion of the original turning trajectory in the inherited coherent domain at update 50, followed by the existing convergence theorem, with a qualitative same-coefficient neighborhood. The index is sufficient, not earliest. [PDF](papers/NATIVE_TURNING_CAPTURE_COMPANION/publication/v0.1/NATIVE_TURNING_CAPTURE_COMPANION_v0.1.pdf).

## Coherence returns and phase-remainder bounds

[Coherence Returns and Phase-Remainder Bounds in the Native Tri-Octagon Map — v0.1](papers/COHERENCE_RETURNS_AND_PHASE_REMAINDER_BOUNDS/publication/v0.1/README.md), by **Hilmir Frímann Halldórsson**. Author-authorized repository research edition with project-internal review; [canonical 19-page PDF](papers/COHERENCE_RETURNS_AND_PHASE_REMAINDER_BOUNDS/publication/v0.1/manuscript/REVIEW.pdf) preserved unchanged. Regular coherence returns and fixed-parameter amplitude, 60-degree phase-sector and phase-remainder bounds, with the complete retained finite-search account; no external peer review, physical motion law or runtime change is claimed.


## Native potential descent and closed coherence coordinates

[Native Potential Descent and Closed Coherence Coordinates in the Tri-Octagon Map — v0.1](papers/NATIVE_POTENTIAL_AND_CLOSED_COHERENCE/README.md), by **Hilmir Frímann Halldórsson**. Author-authorized repository research edition with completed project-internal scientific review; no external peer review is claimed. [Final PDF](papers/NATIVE_POTENTIAL_AND_CLOSED_COHERENCE/publication/v0.1/NATIVE_POTENTIAL_AND_COHERENCE_v0.1.pdf). Local native-potential descent, an explicit coherent-domain decrease bound, and autonomous coherence coordinates with attained minimum counts in the stated pair-entry dictionaries. No runtime changes.


## Phase reconstruction and stationary support axes

[Phase Reconstruction and Stationary Support Axes in the Tri-Octagon Map — v0.1](papers/PHASE_RECONSTRUCTION_AND_STATIONARY_SUPPORT_AXES/README.md), by **Hilmir Frímann Halldórsson**. Author-authorized repository research edition with completed project-internal scientific and manuscript review. [Final PDF](papers/PHASE_RECONSTRUCTION_AND_STATIONARY_SUPPORT_AXES/publication/v0.1/NATIVE_PHASE_SPATIAL_v0.1.pdf). Exact common-phase reconstruction, corrected overlap accumulation, stationary support-axis correspondence, and the fixed-label, state-independent proper-rotation theorem on the admitted domain. No external peer review is claimed.


## Native intensity and conditional carrier crossings

[Native Intensity Accounting and Conditional Carrier Crossings in the Tri-Octagon Model — v0.1](papers/NATIVE_INTENSITY_AND_CONDITIONAL_CARRIER_CROSSINGS/README.md), by **Hilmir Frímann Halldórsson**. [Final PDF](papers/NATIVE_INTENSITY_AND_CONDITIONAL_CARRIER_CROSSINGS/publication/v0.1/NATIVE_INTENSITY_CARRIER_CROSSINGS_v0.1.pdf). Exact native intensity accounting and conditional signed host-notch cut powers; reciprocal native debit and six-central-opening emission remain unestablished. Author-approved repository research edition; internally accepted mathematics, manuscript checks by Codex, no external peer review.

### Understanding Z motion — methods guide

[Understanding Z Motion in the Tri-Octagon Model](docs/methods/Z_MOTION/README.md) explains native changes, observer effects and source accounting against fixed geometry. Start with the [two-page reading companion](docs/methods/Z_MOTION/v0.1/PLAIN_LANGUAGE_GUIDE_v0.1.pdf), then the [18-page methods note](docs/methods/Z_MOTION/v0.1/manuscript/NCM_Z_DOCUMENTATION_v0.1.pdf). Author-authorized project documentation with retained evidence and internal review; no new runtime feature or physical-motion claim.

## Conditional recirculation and diversion accounting

[Recirculation and Diversion Accounting on a Conditional Tri-Octagon Carrier](papers/RECIRCULATION_AND_DIVERSION_ACCOUNTING/README.md) by **Hilmir Frímann Halldórsson**.
Author-authorized research edition v0.1: exact conditional source-off recurrence and cut-throughput accounting; energetic return to the native center and a diversion share remain unassigned. No physical emission or numerical diversion fraction is claimed.
[PDF](papers/RECIRCULATION_AND_DIVERSION_ACCOUNTING/publication/v0.1/RECIRCULATION_AND_DIVERSION_ACCOUNTING_v0.1.pdf) | [Edition and evidence](papers/RECIRCULATION_AND_DIVERSION_ACCOUNTING/publication/v0.1/README.md).

## Reciprocal chiral exchange candidate

[A Reciprocal Chiral Exchange Extension of the Tri-Octagon Model](papers/RECIPROCAL_CHIRAL_EXCHANGE/README.md) by **Hilmir Frímann Halldórsson**.
Author-authorized research edition v0.1: a conditional candidate extension with well-posed reciprocal exchange, matched trial storage, and restrictive extraction/domain limits. Same-trajectory delayed return and physical toroidal registration remain open; zero coupling recovers the original native map.
[PDF](papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1/RECIPROCAL_CHIRAL_EXCHANGE_v0.1.pdf) | [Edition and evidence](papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1/README.md).


## Same-trajectory native credit

[Same-Trajectory Native Credit in the Reciprocal Chiral Exchange Candidate](papers/SAME_TRAJECTORY_NATIVE_CREDIT/README.md) by **Hilmir Frímann Halldórsson**.
Author-authorized research edition v0.1, with completed internal manuscript and final artifact review: an explicit sufficient finite-coupling regime for initial supply and later total native credit on the same empty-launch solution. Recovery does not establish a substantial returned fraction, the exact receiver-power sign at the witness or the intended spatial toroidal route.
[PDF](papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1/SAME_TRAJECTORY_NATIVE_CREDIT_v0.1.pdf) | [Edition and evidence](papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1/README.md).


## Recoverable transfer and projection capacity

[Recoverable Transfer and Projection Capacity in the Reciprocal Chiral Exchange Candidate](papers/RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY/README.md) by **Hilmir Frímann Halldórsson**. Author-authorized research edition v0.1, 15 pages: a general projection-capacity ceiling and a separate finite-coupling recovery theorem for the specified empty coherent family. [PDF](papers/RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY/publication/v0.1/RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY_v0.1.pdf) | [Edition and evidence](papers/RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY/publication/v0.1/README.md). GPT accepted the submitted manuscript; Codex checked the author-approved polished release.


## Finite-time access to native projection capacity

[Finite-Time Access to Native Projection Capacity in the Reciprocal Chiral Exchange Candidate](papers/NATIVE_FINITE_CAPACITY_ACCESS/README.md) by **Hilmir Frímann Halldórsson**. Author-authorized repository research edition v0.1, 11 pages: an explicit sufficient finite positive regime gives combined carrier-plus-receiver stock greater than 1053/4096 of joint capacity at time 1/nu for the specified coherent empty-launch family. [PDF](papers/NATIVE_FINITE_CAPACITY_ACCESS/publication/v0.1/NATIVE_FINITE_CAPACITY_ACCESS_v0.1.pdf) | [Edition and evidence](papers/NATIVE_FINITE_CAPACITY_ACCESS/publication/v0.1/README.md). GPT accepted the exact manuscript and PDF; the author authorized the metadata-only XW-01 correction and publication. Receiving and recovering this amount on the same fixed coefficients remain subsequent questions. No external peer review or physical calibration is claimed.

- [Capacity-Sized Receiving and Native Recovery in the Reciprocal Chiral Exchange Candidate](papers/NATIVE_CAPACITY_RECEIVING_RECOVERY/README.md), v0.1 — a same-trajectory finite-parameter certificate joining joint-capacity access to receiving and net native recovery.

- [Native Stepping and Exchange Cadence in the Reciprocal Chiral Exchange Candidate](papers/NATIVE_F_STEPPING_EXCHANGE_CADENCE/README.md), v0.1 — finite native-step accounting, pointwise post-F initial receiving, local capacity and qualified cadence limits. Later hybrid receiving/recovery and physical cadence remain open.

- [Central-Route Accounting and Six-Opening Geometry in the Reciprocal Chiral Exchange Candidate](papers/CENTRAL_ROUTE_SIX_OPENING_CORRESPONDENCE/README.md), v0.1 — exact regional accounts show receiving can precede selected carrier travel events; uniform six-opening separation prevents relabeling host contacts as central-opening crossings. [PDF](papers/CENTRAL_ROUTE_SIX_OPENING_CORRESPONDENCE/publication/v0.1/CENTRAL_ROUTE_SIX_OPENING_CORRESPONDENCE_v0.1.pdf) | [Edition and evidence](papers/CENTRAL_ROUTE_SIX_OPENING_CORRESPONDENCE/publication/v0.1/README.md).

- [Spatial Observation and Causal Transport with Storage in the Reciprocal Chiral Exchange Candidate](papers/SPATIAL_WORK_CAUSAL_TRANSPORT/README.md), v0.1 — bounded causal history observation, its qualified temporal adjoint, and a declared transport/storage connection with matched work, forward mild evolution and a carrier-preload activity witness. Physical route and material correspondence remain open. [PDF](papers/SPATIAL_WORK_CAUSAL_TRANSPORT/publication/v0.1/SPATIAL_WORK_CAUSAL_TRANSPORT_v0.1.pdf) | [Edition and evidence](papers/SPATIAL_WORK_CAUSAL_TRANSPORT/publication/v0.1/README.md).
