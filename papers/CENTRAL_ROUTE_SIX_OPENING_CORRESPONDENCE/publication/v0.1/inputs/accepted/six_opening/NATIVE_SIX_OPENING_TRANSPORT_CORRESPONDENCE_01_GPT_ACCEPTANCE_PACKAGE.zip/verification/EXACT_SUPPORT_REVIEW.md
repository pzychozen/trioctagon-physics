# Six-opening exact-support audit and unchanged-checker replay

**Disposition: no required correction to E01–E06 or the recorded exact-arithmetic results.**
The six support groups agree with the written proof at their stated scope.
The byte-unchanged checker replay passed in a separate directory and reproduced every stable result field exactly.

## 1. Inspection and provenance

Inspected before execution:
- submitted/verification/independent_exact_checks.py
- submitted/verification/INDEPENDENT_EXACT_RESULTS.json
- submitted/verification/INDEPENDENT_EXACT_LOG.txt
- submitted/NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01_PROOF_REVIEW.md
- the corrections/limits and run_checks.cmd

The script uses only the standard library. It imports no source module or prior checker.
It reads its own bytes for a hash and writes its result to ROOT/verification, where ROOT is derived
from its own path. Accordingly, an exact byte copy was placed at:

research/six_opening_review/agents/algebra/replay/verification/independent_exact_checks.py

Only that copy was executed, with python -I -B. Its output remained inside the replay tree.
The script is 7,135 bytes, SHA-256:

66a45e9dd710f925b5258dd2161c101557132c37574892a659857ee8217fb3db

That identity matches the submitted original, replay copy, recorded Windows result and replay result.
The submitted Windows result and submitted execution log parse to identical JSON.
The four inspected submitted arithmetic/proof artifacts retain their before-execution sizes and hashes.

## 2. Mathematical encoding audit

| Group | Finding | Scope retained |
|---|---|---|
| E01 | Q(sqrt3) arithmetic, exact 120-degree rotation, g/tip identity, reflection maps and opposite face-center ray dictionary are correct. The resulting (j,k,i) table is (0,1,2), (1,2,3), (2,0,1), matching V2–V7 and the source frame. | This is a direction/index dictionary, not a new physical attachment or native reflection law. |
| E02 | Every coarse radical enclosure has positive rational endpoints and strict integer/rational-square residuals. No floating arithmetic decides a sign. | Certifies the particular bounds used by E03–E04. |
| E03 | Positive upper radial bounds and the lower height bound are substituted with the right directions. The exact strict margins are 79601/20000000 and 277849/60000000, matching V11. | The hull/halfspace convexity and all-parameter argument are proved in writing, not replaced by vertex tests alone. |
| E04 | The upper bound Rc=sqrt7 Kc/(2+sqrt3), separator margin and Lipschitz conversion constants are valid. The last margin is 3/2500000>0, giving the strict 297/5000 target. | The separator gap becomes a Euclidean bound only through the written V16 Lipschitz proof. It is not an optimized minimum distance. |
| E05 | Fine rational root bounds and monotone quotient arithmetic rigorously enclose Delta_*/L_*; positivity and interval order hold. Exact records reproduce unchanged. | Decimal strings are displays, not outward-rounded certified endpoints. The rational fractions are the enclosure. The manuscript uses the decimal approximately, so no correction is needed. |
| E06 | The normalized Q01 witness has epsilon/eta=1/4, A/eta=1/2, and cut distance/eta=1/4. It is in the stated inner gap. | Arithmetic corroboration of an accepted witness only, not a replay or new proof of the central-route propagation theorem. |

### Q(sqrt3) implementation

The representation (a,b) means a+b sqrt3 with rational coefficients. Addition and negation operate
componentwise. Multiplication implements

(a+b sqrt3)(c+d sqrt3)=(ac+3bd)+(ad+bc)sqrt3,

exactly as required. No division in this quadratic field is needed in E01. Every vector used by the
zip-based addition has the same two components; there is no truncation in the actual calls.

The direction data are the source triples:
g0=(sqrt3/2,-1/2), g1=(0,1), g2=(-sqrt3/2,-1/2),
and the even-index tips are (0,-1), (sqrt3/2,1/2), (-sqrt3/2,1/2).
The exact rotation with cosine -1/2 and sine sqrt3/2 generates u_j, rather than sampling floating
angles. The negative sqrt3/6 scaling of g_k correctly reproduces c_(k+1)-O.
Thus the source's line equality and opposite-ray distinction are both preserved.

### E05 interval rigor

For each n in {3,6,7,34}, isqrt(n*10^48) constructs floor(10^24 sqrt(n)).
The saved positive fractions j/10^24 and (j+1)/10^24 are verified by strict squaring.
The derived intervals obey

kl <= Kc <= kh,
rl <= Rc <= rh,
ll <= L_* <= lh,

with all endpoint quantities positive. Correlated use of sqrt3 in Kc and the Rc denominator
does not invalidate these conservative bounds: positive numerator/denominator monotonicity still
gives rl and rh as enclosing endpoints.

Consequently

dl=kl-lh*rh-3/50 <= Delta_* <= kh-ll*rl-3/50=dh.

The saved lower endpoint dl/lh is positive. Dividing these positive bounds by the positive L_*
interval gives the valid enclosure

dl/lh <= Delta_*/L_* <= dh/ll.

The actual saved endpoints are ordered, lie between 60971/10^6 and 60973/10^6, and differ by
less than 10^-21. All those comparisons are exact Fraction operations.
The 50-digit Decimal conversions are performed only after the exact assertions, with fields
explicitly named decimal_display. They do not drive the rigorous bound.

## 3. Replay and comparison

The source execution remains the recorded Windows torment run:
Python 3.11.15 at C:\Users\Notandi\miniconda3\envs\torment\python.exe.
The separate reviewer replay used Linux Python 3.12.14 from the primary runtime, with no package
installation and no third-party dependency.

Comparison excluded only these environment/time metadata keys:
utc, python, executable, conda_default_env.

Every remaining field matched exactly, including task, dependencies, script hash, overall status,
group count, all six IDs/scopes, every rational value, both E05 decimal display strings and final scope.
The deterministic normalized-content SHA-256 is:

c21d80ee8b031a5955d13ec09f4c6bded58986b68590bb14dac8c10340c56e12

The source and replay result JSON files are not claimed byte-identical: environment/time data and
platform serialization differ. REPLAY_COMPARISON.json records both identities and the exact
normalization used.

## 4. Evidential limits

This replay corroborates the submitted checker. It is not a newly independent derivation, six new
proofs, or another trajectory experiment. The separate mathematical review above checks that the
encoded operations support the advertised subclaims and agree with V2–V18 and V21.
The geometry/convexity, global Lipschitz argument, source subset consequences and transport
interpretation remain the written analytical proof. That distinction is correctly preserved by the
submitted script, results and proof.

No optional broad tests were run. No submitted artifact was modified.

## Files

- EXACT_SUPPORT_REVIEW.md — this audit.
- REPLAY_COMPARISON.json — complete identities, metadata separation and value comparison.
- SUBMITTED_BEFORE.json — four inspected submitted artifact identities before replay.
- replay/verification/independent_exact_checks.py — byte-unchanged executed copy.
- replay/verification/INDEPENDENT_EXACT_RESULTS.json — actual Linux replay output.

