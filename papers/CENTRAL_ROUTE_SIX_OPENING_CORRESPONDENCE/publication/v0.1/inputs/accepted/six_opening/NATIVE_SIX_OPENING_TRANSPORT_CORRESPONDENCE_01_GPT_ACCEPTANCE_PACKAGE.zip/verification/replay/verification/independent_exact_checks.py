"""Independent exact support for S01-S03 and the retained Q01 qualification.

Uses only the Python standard library. No input helper is read or imported.
The geometry, convexity and Lipschitz proofs are in the standalone review.
"""
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
groups = []


def record(name, scope, values):
    groups.append({'id': name, 'status': 'PASS', 'scope': scope, 'values': values})


# Exact arithmetic in Q(sqrt(3)), represented by (rational, sqrt3 coefficient).
def q3(a=0, b=0):
    return (F(a), F(b))


def plus(x, y):
    return (x[0]+y[0], x[1]+y[1])


def neg(x):
    return (-x[0], -x[1])


def times(x, y):
    return (x[0]*y[0]+3*x[1]*y[1], x[0]*y[1]+x[1]*y[0])


def scale(q, v):
    return tuple(times(q, x) for x in v)


def vadd(v, w):
    return tuple(plus(x, y) for x, y in zip(v, w))


# E01: compute u_j by the exact 120-degree rotation, not a float angle sample.
g = [(q3(0, F(1, 2)), q3(F(-1, 2))), (q3(), q3(1)),
     (q3(0, F(-1, 2)), q3(F(-1, 2)))]
tip = [(q3(), q3(-1)), (q3(0, F(1, 2)), q3(F(1, 2))),
       (q3(0, F(-1, 2)), q3(F(1, 2)))]
u = [(q3(), q3(1))]
co, si = q3(F(-1, 2)), q3(0, F(1, 2))
for _ in range(2):
    x, y = u[-1]
    u.append((plus(times(co, x), neg(times(si, y))), plus(times(si, x), times(co, y))))
center_offsets = [(q3(F(-1, 4)), q3(0, F(1, 12))),
                  (q3(), q3(0, F(-1, 6))),
                  (q3(F(1, 4)), q3(0, F(1, 12)))]
dictionary = []
for k in range(3):
    assert vadd(tip[k], tip[(k+1) % 3]) == g[k]
    reflected = (neg(g[k][0]), g[k][1])
    assert reflected == g[(-k-1) % 3]
    assert center_offsets[k] == scale(q3(0, F(-1, 6)), g[k])
for j in range(3):
    k = (j+1) % 3
    assert u[j] == g[k]
    assert (neg(u[j][0]), u[j][1]) == u[(-j) % 3]
    dictionary.append({'carrier_j': j, 'N_and_upper_G_bisector_k': k, 'native_channel': k+1})
record('E01', 'Exact direction, reflection and opposite face-center ray dictionary.', dictionary)

# E02: certify all radical bounds by integer/rational squares.
bounds = {2: (F(14142, 10000), F(14143, 10000)),
          3: (F(17320, 10000), F(17321, 10000)),
          6: (F(24494, 10000), F(24495, 10000)),
          7: (F(26457, 10000), F(26458, 10000))}
square_residuals = {}
for n, (lo, hi) in bounds.items():
    assert lo > 0 and lo*lo < n < hi*hi
    square_residuals[str(n)] = {'lo': str(lo), 'hi': str(hi),
                                'n_minus_lo_squared': str(n-lo*lo),
                                'hi_squared_minus_n': str(hi*hi-n)}
record('E02', 'Positive rational radical enclosures, certified by exact squaring.', square_residuals)

# E03: envelope checks use upper radius and lower height bounds separately.
s2lo, s2hi = bounds[2]
s3lo, s3hi = bounds[3]
s6lo, s6hi = bounds[6]
s7lo, s7hi = bounds[7]
Dhi = F(1231, 1000)
assert Dhi**2 > 10-6*s2lo
ahi = (1-s2lo/2)/2
hlo = (s2lo-1)/2
rhi = s3hi/6
ring_margin = F(3, 50)-(Dhi*ahi-F(3, 5)*hlo)
tip_margin = F(3, 50)-(Dhi*rhi-F(3, 10))
assert ring_margin == F(79601, 20000000) > 0
assert tip_margin == F(277849, 60000000) > 0
record('E03', 'Strict two-vertex envelope bounds; convex interpolation is proved in writing.',
       {'D_upper': str(Dhi), 'D_square_slack': str(Dhi**2-(10-6*s2lo)),
        'ring_margin': str(ring_margin), 'tip_margin': str(tip_margin)})

# E04: derive the conservative carrier constants from the radical intervals.
Klo, Khi = s3lo/12+s6lo/4, s3hi/12+s6hi/4
# R_c = sqrt(7) K_c / (2+sqrt(3)). Denominator positive.
Rlo, Rhi = s7lo*Klo/(2+s3hi), s7hi*Khi/(2+s3lo)
assert Klo > F(756, 1000)
assert Rhi < F(537, 1000)
assert Klo > Rhi
Lhi = F(1167, 1000)
assert Lhi**2 > F(34, 25)
delta_lower = F(756, 1000)-Lhi*F(537, 1000)-F(3, 50)
assert delta_lower == F(69321, 1000000) > 0
target = F(297, 5000)
last_margin = delta_lower-target*Lhi
assert last_margin == F(3, 2500000) > 0
record('E04', 'Strict separator and Euclidean target arithmetic after the written Lipschitz conversion.',
       {'K_lower_from_radicals': str(Klo), 'K_upper_from_radicals': str(Khi),
        'R_lower_from_radicals': str(Rlo), 'R_upper_from_radicals': str(Rhi),
        'K_margin_above_756_1000': str(Klo-F(756, 1000)),
        'R_margin_below_537_1000': str(F(537, 1000)-Rhi),
        'L_square_slack': str(Lhi**2-F(34, 25)),
        'separator_lower': str(delta_lower), 'target': str(target),
        'last_strict_margin': str(last_margin),
        'rational_distance_lower': str(delta_lower/Lhi)})


def tight_sqrt(n):
    scale = 10**24
    j = isqrt(n*scale*scale)
    lo, hi = F(j, scale), F(j+1, scale)
    assert lo*lo < n < hi*hi
    return lo, hi


# E05: separately generated fine rational bounds corroborate the exact lower
# bound Delta/L. This does not calculate the minimum set-to-set distance.
fine = {n: tight_sqrt(n) for n in (3, 6, 7, 34)}
kl, kh = fine[3][0]/12+fine[6][0]/4, fine[3][1]/12+fine[6][1]/4
rl, rh = fine[7][0]*kl/(2+fine[3][1]), fine[7][1]*kh/(2+fine[3][0])
ll, lh = fine[34][0]/5, fine[34][1]/5
dl, dh = kl-lh*rh-F(3, 50), kh-ll*rl-F(3, 50)
lower, upper = dl/lh, dh/ll
assert lower > F(60971, 1000000) and upper < F(60973, 1000000)
assert upper-lower < F(1, 10**21)
with localcontext() as ctx:
    ctx.prec = 50
    dc = lambda x: Decimal(x.numerator)/Decimal(x.denominator)
    lower_text, upper_text = str(dc(lower)), str(dc(upper))
record('E05', 'Fine certified rational enclosure of the conservative exact Delta/L bound, not optimized clearance.',
       {'root_bounds': {str(n): [str(a), str(b)] for n, (a, b) in fine.items()},
        'lower_exact': str(lower), 'upper_exact': str(upper),
        'lower_decimal_display': lower_text, 'upper_decimal_display': upper_text})

# E06: carry the accepted Q01 witness as an arithmetic qualification only.
# All lengths here are normalized by eta_g; no physical parameters selected.
eps_ratio, A_ratio = F(1, 4), F(1, 2)
inner_gap = 1-eps_ratio-A_ratio
assert 0 < A_ratio < 1-eps_ratio and inner_gap == F(1, 4)
record('E06', 'Accepted Q01 inner-gap witness arithmetic; no central-route theorem replay.',
       {'epsilon_over_eta': str(eps_ratio), 'A_over_eta': str(A_ratio),
        'cut_distance_over_eta': str(inner_gap)})

record_out = {
    'task': 'NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01',
    'utc': datetime.now(timezone.utc).isoformat(),
    'python': sys.version, 'executable': sys.executable,
    'conda_default_env': os.environ.get('CONDA_DEFAULT_ENV'),
    'dependencies': 'Python standard library only; no supporting third-party package',
    'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
    'status': 'PASS', 'group_count': len(groups), 'groups': groups,
    'scope': 'Exact corroboration, not formal proof of convexity, Lipschitz bounds or transport interpretation; no samples or trajectory execution.'
}
(ROOT/'verification/INDEPENDENT_EXACT_RESULTS.json').write_text(json.dumps(record_out, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record_out, indent=2))
