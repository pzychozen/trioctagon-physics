# Independent GPT scrutiny of the external six-opening review

## Disposition

**Clean scoped acceptance of S01-S05 is recommended.** No required mathematical or interpretive correction was found in external equations V1-V21, the written proofs, or `CORRECTIONS_AND_LIMITS.md`. The external review establishes the submitted analytical start's claims rather than silently changing the spatial model.

This recommendation concerns the bounded source comparison, individual-hull separation theorem, and stated transport limitations. It does not establish physical six-opening transport or authorize publication. The accepted material is sufficient for the proposed combined manuscript after the parent GPT acceptance decision.

## What was read and compared

- External `NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01_PROOF_REVIEW.md`, including V1-V21 and the concluding manuscript recommendation.
- External `CORRECTIONS_AND_LIMITS.md`.
- The actual GPT analytical start previously reviewed in the delivered packet, compared claim by claim with the external S01-S05 dispositions.
- Targeted preserved CG/PG/CC source definitions and the accepted central-route GPT review, especially its Q01 and reconstruction qualifications.

Submitted source/evidence files were not modified. No carrier or native trajectory was run. The submitted checker was not replayed. A small independent standard-library Fraction calculation recomputed the printed rational constants; decimal arithmetic was used only to confirm the illustrative display.

## S01 / V2-V7: common frame and dictionary

The G vertices are centered at the same O used by the carrier embedding. Cylindrical radius is correctly distinguished from full distance to O. V3 and V4 recover the actual source-defined upper/lower segment unions, including the endpoint indices and prescribed whole-complex reflection.

The direction table u_0=g_1, u_1=g_2, u_2=g_0 is correct. The upper bisector identity e_(2k)+e_(2k+2)=g_k is exact, while the lower bisector inherits the full similarity A_tau. The stationary support lines agree as unoriented positioned lines; the face-center vectors have the opposite ray sign. The reflection identities Sg_k=g_((-k-1) mod 3), Su_j=u_((-j) mod 3), and pointwise invariance of Gamma_0 are correct and are not promoted into a symmetry of the native dynamics. Raw source V7 has the correct fixed-yaw matrix entries and does not impose a one-channel/one-opening power allocation.

## S02 / V8-V12: individual hulls and uniform enclosure

Each broken arc's convex hull is exactly the triangle of its three endpoints. Its use is expressly mathematical, with no adopted aperture or added physical chord. Every such hull remains entirely in its corresponding positive or negative height slab. On that slab Phi=rho-(3/5)|zeta| is a convex norm minus a linear function, so the vertex enclosure extends to every hull point.

A_tau^T A_tau=(1+(tau/r_g)^2)I and D_*=sqrt(10-6sqrt(2)) correctly bound the full closed parameter range, including both endpoints and both hands. The rational bounds in V10-V11 preserve inequality direction. The review also supplies a valid counterexample to applying this convexity argument to a hull mixing upper and lower sets, so no hidden global-convexity assumption remains.

## S03 / V13-V18 and V1: strict distance, infima, and scale

K_c>R_c makes the cylindrical radius K_c+R_c cos(theta), without an absolute-value branch. Cauchy-Schwarz gives the exact uniform lower bound K_c-L_*R_c for Phi on every candidate circle. The hull bound supplies the fixed positive gap Delta_*.

The global L_*-Lipschitz estimate for Phi is valid even across opposite height signs and at the radial axis; differentiability is not required. Taking an infimum therefore preserves the non-strict exact bound dist>=Delta_*/L_*. Only after retaining that fixed exact quantity does the proof use the strict rational lower bound >297/5000. There is no strict-infimum error.

The proof correctly calls Delta_*/L_* a conservative lower bound, not the true minimum separation. Inclusion G subset H gives the same result for actual rims. Finite B/B* support images stay on the selected circle, so their separation follows by subset inclusion; arclength width is not tube radius.

Common positive scaling multiplies all distances, the envelope intercept, and the separator gap by w while preserving the dimensionless Lipschitz factor and normalized parameter range. The review explicitly scales tau and r_g together and excludes independent re-registration of one compared object. V1 is therefore a valid uniform width-scaled statement.

### Independently recomputed rational values

All of these exactly match the external review:

| Quantity | Exact value |
| --- | --- |
| D upper-square margin | 561/1000000 |
| Elbow vertex margin | 79601/20000000 |
| Fan-tip vertex margin | 277849/60000000 |
| K_c lower bound | 45401/60000 |
| K_c upper bound | 45403/60000 |
| R_c upper bound | 600636287/1119600000 |
| 537/1000 minus that R_c bound | 588913/1119600000 |
| L_* upper-square margin | 1889/1000000 |
| Coarse separator margin | 69321/1000000 |
| Final strict comparison margin | 3/2500000 |
| Coarse clearance ratio | 23107/389000 |

Independent 65-digit Decimal evaluation gives the illustrative value

    Delta_*/L_* = 0.060971801656535550652939525470133865631155312765848429209817382999...

This agrees with the review's rounded display. The proof of positivity and the 297/5000 conclusion rely on exact rational inequalities, not that display.

## S04 / V19-V20: dynamics and C6

V19 preserves the reciprocal candidate's signs, one-half native-feedback normalization, profiles, and matched work. The stated hybrid endpoint convention matches accepted CR. Point-cut powers retain the H1 trace hypothesis.

The empty preimages are correctly used to rule out literal unchanged-C1 intersections and label substitution. They are not treated as a physical flux calculation through undefined apertures. The review explicitly avoids a false two-input/six-output dimension impossibility argument.

In V20, Gamma_0 is angle-parametrized, so Gamma_0(s/R_c) is the correct arclength embedding in d_X(s); the integration measure remains ds. The tangent encoding, retardation, and scalar/vector components agree with the retained C6 definition. The positive separation establishes its off-carrier geometric condition at fixed G/hull points, but the review retains supplied history, regularity, fixed observation points, and independent observer parameters. It does not convert a static geometry parameter into a moving observation trajectory or identify C6 with a receiving load, ambient current, or energy flux.

## S05 / V21: accepted qualifications and manuscript scope

V21 correctly carries the accepted Q01 formula for the inherited nonwrapping support geometry. For an inner cut A<eta_g-epsilon_c, the adjacent inner support endpoint is closest. For an outer cut A>eta_g+epsilon_c, the alternative seam path exceeds the direct distance by L_c-2A>0. The middle range lies in a source support. Thus max(|A-eta_g|-epsilon_c,0) is the correct shortest-circle distance for either symmetric cut.

The review correctly distinguishes a zero geometric gap from inevitable immediate nonzero field/flux. It preserves the pointwise launch and preload limits, conditional common-phase outlet obstruction, singular-prestage caveat, and restriction on autonomous-F reconstruction during coupled evolution.

Historical missing-feedback and same-trajectory-return passages are correctly subordinated to the later accepted results. Local reversible exchange and later elsewhere transfer are expressly compatible; no false mandatory binary choice is reintroduced.

## Final recommendation

Accept S01-S05 at their stated hypotheses and move to the combined manuscript. Its substantive boundary is supported: existing embedding and exact accounting, accepted receiving-before-selected-activity, uniform G/individual-hull separation, and the missing spatial/transport registration. No new physical receiver, aperture closure, tube thickness, clock, coefficient fit, or author geometry choice is required to document these results.
