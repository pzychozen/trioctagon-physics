"""Portable exact-arithmetic corroboration of Codex G04 and G08.

Reads the unchanged submitted archive. This is not a full SymPy replay or a
new set of independent research proof groups. No trajectory is evolved.
"""
from pathlib import Path
from zipfile import ZipFile
from fractions import Fraction as F
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "submitted/NATIVE_CENTRAL_ROUTE_CORRESPONDENCE_01_REVIEW.zip"
ARCHIVE_SHA = "eb3b2e850b1db2f3eb360d8d36dca18ee4dafa0ae9e984d85b07633facd1952f"
before = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
assert before == ARCHIVE_SHA
with ZipFile(ARCHIVE) as z:
    result_bytes = z.read("verification/INDEPENDENT_ALGEBRA_RESULTS.json")
    script_bytes = z.read("verification/independent_algebra.py")
record = json.loads(result_bytes)
assert hashlib.sha256(script_bytes).hexdigest() == record["script_sha256"]
groups = {row["id"]: row for row in record["groups"]}
g04 = groups["G04"]

bounds = {}
for n, entry in g04["square_root_bounds"].items():
    n = int(n)
    lo, hi = F(entry["lower_exact"]), F(entry["upper_exact"])
    assert 0 < lo < hi and lo * lo < n < hi * hi
    bounds[n] = lo, hi
s2l, s2u = bounds[2]
s3l, s3u = bounds[3]
s6l, s6u = bounds[6]
s7l, s7u = bounds[7]

# Independent monotone endpoint transcription of the geometric constants.
kl, ku = s3l / 12 + s6l / 4, s3u / 12 + s6u / 4
al, au = kl / (1 + s3u / 2), ku / (1 + s3l / 2)
rl, ru = s7l * al / 2, s7u * au / 2
r0l, r0u = F(13, 12) - s2u / 2, F(13, 12) - s2l / 2
hl, hu = (s2l - 1) / 2, (s2u - 1) / 2
dl, du = 1 / s3u - ku, 1 / s3l - kl
assert dl < du < 0
computed = {
    "Kc_minus_Rc_positive": (kl - ru, ku - rl),
    "contact_above_host_tip": (al - hu, au - hl),
    "contact_below_host_base": (F(1, 2) - au, F(1, 2) - al),
    "R0sq_minus_contact_radius_sq": (r0l - 2 * au**2, r0u - 2 * al**2),
    "radius_at_2eta_sq_minus_R0sq": (
        kl**2 + rl**2 + 2 * kl * rl / 7 - r0u,
        ku**2 + ru**2 + 2 * ku * ru / 7 - r0l),
    "filled_panel_seam_clearance_above_quarter": (
        rl**2 - dl**2 - F(1, 4), ru**2 - du**2 - F(1, 4)),
}
checks = {}
for key, (lo, hi) in computed.items():
    target = g04["inequalities"][key]
    assert lo > 0 and hi >= lo
    assert lo == F(target["lower_exact"])
    assert hi == F(target["upper_exact"])
    checks[key] = {"exact_endpoints_match": True, "strict_positive_lower": True}
assert computed["R0sq_minus_contact_radius_sq"][0] > F(4, 100)
assert computed["radius_at_2eta_sq_minus_R0sq"][0] > F(59, 100)
coefficient = F(6, 7) * F(97, 100)**2 * F(284971, 300000)**2
assert coefficient == F(groups["G08"]["post_F_coefficient"])

# Q01: normalized exact witness for an inner-gap diagnostic cut.
epsilon_over_eta, A_over_eta = F(1, 4), F(1, 2)
distance_over_eta = 1 - epsilon_over_eta - A_over_eta
assert 0 < A_over_eta < 1 - epsilon_over_eta
assert distance_over_eta == F(1, 4)
assert not A_over_eta >= 1 + epsilon_over_eta
assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() == before

result = {
    "status": "PASS",
    "utc": datetime.now(timezone.utc).isoformat(),
    "execution": "GPT exact-arithmetic corroboration, separate from the recorded Windows torment execution.",
    "python": sys.version, "executable": sys.executable,
    "scope": "G04 saved exact endpoints/signs, G08 coefficient and Q01 rational witness. No full SymPy replay or trajectory test.",
    "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "submitted_archive_sha256": before,
    "g04_sqrt_enclosures_verified_by_squaring": True,
    "g04_exact_interval_records": checks,
    "g04_stated_weaker_rational_margins": True,
    "g08_post_F_coefficient": str(coefficient),
    "q01_inner_gap_witness": {
        "epsilon_over_eta": str(epsilon_over_eta), "A_over_eta": str(A_over_eta),
        "distance_over_eta": str(distance_over_eta), "enclosing_containment": False},
    "submitted_archive_unchanged": True,
    "submitted_script_sha256_matches_record": True,
}
(ROOT / "verification/G04_CORROBORATION.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": result["status"], "g04_exact_endpoint_pairs": len(checks),
                  "g08_coefficient_matches": True, "q01_witness_matches": True,
                  "scope": result["scope"]}, indent=2))
