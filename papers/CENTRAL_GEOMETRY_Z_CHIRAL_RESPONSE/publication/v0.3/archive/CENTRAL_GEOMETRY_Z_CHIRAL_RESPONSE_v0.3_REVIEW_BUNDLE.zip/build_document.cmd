@echo off
setlocal
cd /d "%~dp0"
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
if errorlevel 1 exit /b 1
set "TEMP=%CD%\build\tmp"
set "TMP=%CD%\build\tmp"
set "TECTONIC_CACHE_DIR=%CD%\build\tectonic-cache"
set "FONTCONFIG_FILE=%CD%\build\fontconfig.xml"
"C:\TORMENT\TRIOCTAGON_new\reconstruction\publication\paper_C\build\tools\tectonic\tectonic.exe" --only-cached --untrusted --keep-logs --keep-intermediates --outdir build manuscript.tex > build\compile-console.txt 2>&1
set "BUILD_EXIT=%ERRORLEVEL%"
type build\compile-console.txt
if not "%BUILD_EXIT%"=="0" exit /b %BUILD_EXIT%
copy /Y build\manuscript.pdf CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.pdf > nul
"C:\Users\Notandi\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdfinfo.exe" CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.pdf > build\review\pdfinfo.txt
if errorlevel 1 exit /b 1
python -B build\pdf_extract.py
if errorlevel 1 exit /b 1
"C:\Users\Notandi\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe" -r 120 -png CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.pdf build\review\page
exit /b %ERRORLEVEL%
