# CODEX WORK ORDER
## Central Geometry / Z / Chiral Response — Post-Audit Manuscript Finalization v0.1

**Issued:** 20 October 2026  
**Target:** a separate manuscript **v0.3 local final-review draft**, based on accepted v0.2  
**Mode:** document-only consolidation of completed verification evidence  
**Authority:** Hilmir has authorized this work order; GPT coordinates and reviews the returned artifacts.

## 1. Objective and stopping boundary

Prepare a separately versioned review copy of **Central Geometry, Z Readouts, and Chiral Response in the Tri-Octagon Model** that accurately records the completed numerical audit and GPT replay.

The mathematical content is already fixed. Review items **E01–E06 are closed**, and the separately scoped numerical-verification obligations are now closed. This task updates the manuscript's verification status and supporting documentation. It does not reopen the mathematics, rerun the audit, or initiate publication.

Preserve manuscript v0.1, accepted v0.2, reports R0–R9, the delivered audit, the GPT replay evidence, and all repository/publication material. Do not replace earlier files or revise their historical descriptions of what was checked at the time.

**Stop after delivering v0.3 and its review bundle. Author-wording approval and publication clearance remain separate.**

## 2. Workspaces and controlling inputs

### Read-only baseline

```text
C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_MANUSCRIPT_v0.2
```

Use that folder's accepted `manuscript.tex`, PDF, `CLAIM_SOURCE_MAP.csv`, `SOURCE_MANIFEST.json`, `PROOF_REVIEW_AND_EDITORIAL_NOTES.md`, `README_REVIEW.md`, `REVISION_DISPOSITION.md`, and retained figure. In particular, do not accidentally use the older loose v0.1 proof-review notes.

### Completed audit

```text
C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1
```

Read `INDEPENDENT_NUMERICAL_AUDIT_REPORT.md`, `CLAIM_AUDIT_COVERAGE.csv`, the relevant `AUDIT_RESULTS.json` status/metadata, and the input/output manifests. Read `ENVIRONMENT_AND_REPLAY.md` for the provenance of the completed execution, **not as an instruction to execute it again**.

### GPT receipts supplied with this order

- `GPT_REVISION_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md` — E01–E06 closure and the preserved baseline identities.
- `GPT_NUMERICAL_AUDIT_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md` — controlling disposition accepting the scoped audit, its replay, and the exact evidence comparison.
- `GPT_CENTRAL_Z_NUMERICAL_AUDIT_REPLAY_EVIDENCE_v0.1.zip` — companion evidence for that completed replay.

Use the supplied attachments or their actual downloaded copies. Record their resolved locations; do not invent a local location or reconstruct a missing receipt from conversational recollection. If a controlling input is absent or has a conflicting hash, report that specific block rather than silently substitute another edition.

### New output workspace

```text
C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_MANUSCRIPT_v0.3
```

Create it separately. Do not overwrite an existing unrelated v0.3 directory. Keep all build products, caches, temporary files and new evidence copies inside the new workspace. The authoritative checkout below is not a write destination:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

Retain the manuscript's source snapshot `3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34`; do not refresh the science from a newer checkout or upstream revision.

### Input identities

Check these identities before editing. Hashing and archive inspection are document/provenance operations, not a new scientific run.

| Input | Bytes | SHA-256 |
|---|---:|---|
| Accepted v0.2 review ZIP | 595068 | `37674d5df58596749855fc8d4c33c77e262e7b926ce2e7528c4dcec1b3b2a38c` |
| Accepted v0.2 `manuscript.tex` | 86681 | `02610193c2aebdf8b97b424f1837696dff79feb1f3079e038a0385dc4863640b` |
| Accepted v0.2 PDF | 364084 | `f0b323bae4f552ee385e6a32f812c1842d88dc26423d129bcff2e74b7b332288` |
| Accepted v0.2 disposition | 4940 | `ea7b5297d0fbf52a842d55ca1155776f083dc129a24273222e3742fb07931a9d` |
| Delivered numerical-audit review ZIP | 419520 | `959aff5caf6b617565e1b059035f5254046a39bdd93c875706008978a869e90b` |
| Delivered audit report | 26922 | `877b97fcb51a1b3abf9dc4d6cdb8168ef7a6c153eecba10d5b240aa676765d60` |
| GPT numerical-audit closure receipt | 10646 | `8b736d1ea2c63fcc7183c1c219a57dba6b28d7569085915c23e374ec0a0ef3e8` |
| GPT replay-evidence ZIP | 160645 | `8b4eccc36121ffdb49a943759b4fa23ce582025b86b47c40b65781c2c2fe75d0` |

## 3. What the completed evidence actually establishes

Use the audit report and GPT numerical-audit closure receipt as evidence of the completed checks. Preserve their scope and distinctions:

- A separately written standalone evaluator checks the stated ideal real/complex formulas, including the entire original twelve-coordinate radius-`10^-8` box through four updates, each input's fixed configuration, and the full closed phase/amplitude products.
- All **six numerical proof blocks** passed. There are **768 scalar bound records**, **58 arithmetic self-checks**, and **eight exact supporting-identity checks**. These are different counts, not 834 independent theorems.
- GPT inspected the delivered checker and proof structure and replayed the **same unchanged checker** in an isolated environment. All 768 records matched exactly, including endpoints, margins and statuses. That replay is not a third independently written evaluator or independent human peer review.
- The 37 claim-map rows have different coverage: **14 quantitative rows checked within scope; six rows checked only as supporting definitions/identities; 17 rows outside the numerical audit.** The coverage CSV controls the status of each row. Do not sum overlapping per-claim record counts or imply that all 37 full assertions were newly proved by execution.
- Outward interval evidence supports whole-domain claims; the high-precision nominal cross-check is corroboration only. Successful point calculations are not the proof of the entire neighbourhood.
- The ideal-formula certificate remains conditional on the inspectable interval implementation, integer/Fraction operations, source transcription and stated analytic remainder bounds. It is not proof-assistant verification, production binary64 certification, experimental validation or a new physical model.

The audit supplies no new scientific correction. Keep all accepted manuscript inequalities and intervals unchanged; do not replace them with the tighter audit intervals or derive extra conclusions from those tighter bounds.

The earlier unresolved projection/direction comparisons remain unresolved in the manuscript. The audit does not authorize a fifth update, wider parameter domains, new trajectories, invariant-region or long-time claims, physical flow, crystal movement, or geometry-to-dynamics feedback.

## 4. Authorized edits

### F01 — Update verification status without rewriting history

Replace current-tense statements that the specified numerical audit is still pending with a concise, cited account of its completion. Inspect the entire current draft and supporting records, particularly:

- Abstract and front-matter evidence boundary.
- Proposition 9.1 / `prop:four`, its proof-status paragraph, and the observation-table context.
- Phase-domain proof discussion and the separate actual-image inclusion section.
- Conclusion and Appendices A–F, especially `app:certificate`, `app:mechanism`, `app:inclusion` and `app:crosswalk`.
- README, proof-review notes and claim/source map.

**Do not globally delete the word “inherited.”** The bounds still originate in R3–R8; they have subsequently been independently checked within the accepted numerical scope. Keep the source attribution and explain the later validation. Historical statements about the original reports' written-algebra-only work remain true.

A suitable factual model for the new status notice is:

> The numerical bounds originate in reports R3–R8. A subsequent standalone audit independently checked the required residual, propagation, finite-region, mechanism and phase-domain inequalities using outward interval arithmetic and exact supporting identities. A separate replay of the unchanged checker reproduced the saved scalar certificates. The scoped numerical review is closed; its implementation assumptions and the manuscript's scientific limits remain explicit.

Adapt this wording only for accurate terminology and readability. Do not imply that this document-only pass performed the calculations, that every claim was computationally re-proved, or that a new proof replaces the existing derivations.

Keep the readable paper concise: one clear verification account with local citations is preferable to repeated operational disclaimers or a new audit-report-length appendix.

### F02 — Cite the audit and distinguish the replay

Add proper bibliographic/source entries for the delivered numerical audit and the GPT closure/replay record, using their actual titles, versions, dates and recorded authorship/preparation roles. Do not invent a human coauthor, affiliation, journal, DOI, licence or public URL.

Identify them as local, unpublished supporting review materials. The audit evidence establishes the numerical check; the GPT receipt documents review, replay and closure. Neither becomes a new physical premise.

Retain existing theorem labels, equations, references, figures and logical structure wherever possible. Update version labels, PDF metadata, headers and review status to **v0.3 — local final-review draft**. Do not call it published, final-approved or publication-cleared.

### F03 — Integrate statement-level coverage and provenance

Retain all 37 existing claim IDs and scientific statements in `CLAIM_SOURCE_MAP.csv`. Add separate audit-coverage/status/evidence columns, or an equivalently clear cross-reference, rather than erasing the original written-review/source provenance.

Use `CLAIM_AUDIT_COVERAGE.csv` and the GPT receipt to distinguish the 14 quantitative rows, six supporting-only rows and 17 outside-scope rows. `OUTSIDE_NUMERICAL_SCOPE` is not a numerical failure and not permission to expand this task.

Preserve the 37 baseline scientific source identities in the new source manifest and append separately identified audit/replay/review inputs. Do not confuse the number of source records with the number of claim rows. Preserve the original source dates and hashes; record v0.3 as a new document with its own output identities.

Retain E01–E06 closure, the known conservative R6 arithmetic clarification, the R9 omitted-plus provenance correction and its source hashes. Do not reopen them or edit the originals.

### F04 — Preserve the author-review boundary

Keep the existing Section 1 author-attributed paragraph unchanged in this pass and reproduce it verbatim in the new disposition under **“Hilmir's wording review — pending.”** Do not infer approval of that exact wording from authorization to conduct the audit or finalize its status.

Do not rewrite Hilmir's motivations, quote new chat material, or add statements about his beliefs, health or cognitive process. Proposed alternative author wording is not part of this order.

Do not import the separate SRG Origins, G-derivative, `1/12`, mirror/toroidal interpretation revision. The three-paper SRG programme, historical companion and TORMENT remain outside this lane.

### F05 — Preserve mathematical content and show the complete diff

Make only verification-status, citation/provenance, version and necessary layout edits. Preserve the exact state and basis, configuration, box, four-update horizon, observer schedule, geometry/hand/placement, theorem assumptions, margins and conclusions.

Keep the retained figure byte-identical. No new figures, displays or animations are needed. Do not alter equations or numerical tables to make the paper look more fully verified.

Provide a unified TeX diff from accepted v0.2 and a brief disposition of every change. Document comparison code may extract and compare formula/table blocks, labels and references; it must not evaluate scientific formulas. The title or explanatory prose of a certificate may change to record its completed audit, but its mathematical assertion must not.

If a newly noticed issue would require a mathematical change, preserve it as an unresolved finding for GPT review; do not silently fix it, retune the inputs or launch more research. The accepted audit does not require such a change.

### F06 — Build and inspect the new review copy

Use the existing local document toolchain and cached assets. Compilation, PDF extraction/rendering, page inspection, reference checks, hashing and packaging are authorized. Use Windows CMD for command records; no environment changes or software installation.

Confine caches and build outputs to v0.3. Do not run an old project build script that could execute science. Do not run `audit.py`, `replay.cmd`, project modules, tests or a new numerical helper. The earlier audit authorization does not make another run necessary in this document-only pass.

Render the final PDF and inspect every page for equations, signs, tables, retained figure, captions, contents, bibliography, glyphs, clipping and pagination. Check unresolved references, duplicate labels and missing citation keys. Record the actual page count; retain the existing 28-page layout where practical, but do not shrink readable text or remove necessary material merely to keep that number.

## 5. Deliverables

Place the following in the new v0.3 workspace:

1. `manuscript.tex` and `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.pdf`, with the unchanged retained figure.
2. Updated `README_REVIEW.md`, `PROOF_REVIEW_AND_EDITORIAL_NOTES.md`, `CLAIM_SOURCE_MAP.csv` and `SOURCE_MANIFEST.json`.
3. A new `REVISION_DISPOSITION.md` covering F01–F06, linking the completed audit, identifying what was and was not done in this pass, and reproducing the pending author passage. Include a compact status table: E01–E06 closed; scoped numerical audit closed; v0.3 document review pending; author wording pending; publication not authorized.
4. `DIFF_FROM_v0.2.patch`, final build/reference/page-inspection records, and a compact artifact/preservation manifest with sizes and SHA-256 hashes. Hash before/after the preserved inputs actually used; do not claim a whole-machine or live-repository audit.
5. `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3_REVIEW_BUNDLE.zip` containing the revised manuscript, figure, review records and exact supporting audit/closure evidence.

For portable review, an `evidence/` subfolder may hold byte-identical copies of the delivered audit ZIP, GPT replay-evidence ZIP and the two GPT closure receipts. Identify these as preserved supporting inputs, not new v0.3 executions. Use archive/file reads only. Avoid redundant unpacked copies of all checker outputs. Do not package font files, caches or unnecessary page renders.

Keep absolute local paths in the private review records, not the readable manuscript. Report the bundle's own hash outside its member-hash manifest to avoid a self-referential checksum requirement.

## 6. Completion criteria

Return the PDF, editable source, review ZIP and disposition paths with a short summary confirming:

- Verification-status language now reflects the accepted audit and exact replay, with claim-level coverage preserved.
- Mathematical definitions, statements, bounds, figures and all original artifacts are unchanged.
- The final PDF was compiled and every page inspected, with actual page count and remaining warnings reported.
- No scientific evaluator, recurrence, test, simulation, project application or audit replay was run during this pass.
- Hilmir's wording review and publication decision remain open; no repository, release, DOI or upload operation occurred.

Do not commit, push, tag, publish, modify TORMENT or any kernel, reopen SRG work, or issue an automatic next investigation. Stop with the v0.3 package for GPT and Hilmir's review.

## Source basis for this order

This order is an editorial specification, not new scientific evidence. Its completed-verification statements derive from:

- `INDEPENDENT_NUMERICAL_AUDIT_REPORT.md`, §§1–2 and 7–8: baseline identities, rigorous versus nominal evidence, coverage and limits.
- `GPT_NUMERICAL_AUDIT_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md`, verdict and §§3–6: replay, exact certificate match, accepted scope and recommended document-only step.
- `GPT_REVISION_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md`: E01–E06 closure and preservation requirements.
- Accepted v0.2 `manuscript.tex`, `README_REVIEW.md`, `PROOF_REVIEW_AND_EDITORIAL_NOTES.md`, `CLAIM_SOURCE_MAP.csv`, `SOURCE_MANIFEST.json` and `REVISION_DISPOSITION.md`: current text, provenance and pending author wording.
