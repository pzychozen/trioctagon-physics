# Central Geometry, Z Readouts, and Chiral Response — v0.3 review copy

20 October 2026 · Local final-review draft · Prepared by Codex for GPT and Hilmir's review

This separate v0.3 incorporates the accepted standalone numerical audit and GPT's exact replay into the verification-status language of accepted v0.2. E01–E06 and the scoped numerical audit are closed. Review of this document, Hilmir's author wording, and publication authorization remain separate.

The PDF has **29 A4 pages**, all rendered at 120 dpi and individually inspected. Three underfull paragraph warnings remain; none causes clipping, collision, missing content or an unreadable equation. There are no reported overfull boxes, unresolved references, missing citation keys, duplicate labels or missing glyphs. The additional bibliography material occupies page 29; the font size and mathematical content were retained.

## Review files

- `manuscript.tex` — editable source, with embedded bibliography.
- `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.pdf` — compiled review copy.
- `DIFF_FROM_v0.2.patch` — complete unified TeX diff.
- `REVISION_DISPOSITION.md` — F01–F06 disposition, closure status and unchanged author passage.
- `PROOF_REVIEW_AND_EDITORIAL_NOTES.md` — original written-review provenance and later numerical-check status.
- `CLAIM_SOURCE_MAP.csv` — all 37 baseline claim rows and original columns preserved, with separate current audit columns.
- `SOURCE_MANIFEST.json` — all 37 baseline scientific source records preserved, plus separately identified supporting audit/review inputs.
- `ARTIFACT_HASH_MANIFEST.json` — sizes and SHA-256 hashes of the packaged payload.
- `PRESERVATION_MANIFEST.json` — before/after identities of the preserved inputs actually used.
- `BUNDLE_RECEIPT.json` — ZIP identity and archive verification, outside the ZIP's member manifest.
- `build/review/` — document comparison, input identity, PDF extraction and page-inspection records.

The old `review_status` column in the claim map records the v0.2 written-review history. Its historical statements about outstanding numerical review have not been erased. The added `audit_scope`, `audit_status`, `audit_proof_blocks`, `audit_limits`, `audit_evidence` and `gpt_replay_disposition` columns give the subsequent accepted numerical disposition.

## What the completed audit supports

All six numerical proof blocks passed. The saved evidence comprises **768 scalar bound records**, **58 arithmetic self-checks**, and **eight exact supporting-identity checks**; these are separate counts. The claim-level coverage is **14 quantitative rows**, **six supporting-definitions/identities-only rows**, and **17 rows outside numerical scope**. Outside scope does not mean failure. Overlapping per-claim record counts are not summed.

The standalone evaluator checked the ideal real/complex formulas on the entire unchanged twelve-coordinate radius-`10^-8` box through four updates, with each input's configuration fixed, and on the full closed phase/amplitude products. Outward interval evidence supports these whole-domain claims. The high-precision nominal calculation is corroboration only.

GPT inspected and replayed the **same unchanged checker** in an isolated environment. All 768 scalar records matched exactly, including endpoints, margins, statuses and associated evidence fields. This is not a third independently written evaluator or independent human peer review. The original run used Windows/Python 3.11.15; GPT's completed replay used Linux/Python 3.13.5. GPT verified copied input identities, not unavailable original Windows paths.

The certificate remains conditional on the inspectable interval implementation, integer/Fraction operations, source transcription and stated analytic remainder bounds. It is not proof-assistant verification, production binary64 certification, experimental evidence or a physical flow model. Unresolved direction/projection comparisons remain unresolved. No tighter audit bounds have replaced the accepted manuscript bounds.

## Preserved evidence

`evidence/` contains byte-identical copies of:

1. `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1_REVIEW_BUNDLE.zip`.
2. `GPT_CENTRAL_Z_NUMERICAL_AUDIT_REPLAY_EVIDENCE_v0.1.zip`.
3. `GPT_REVISION_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md`.
4. `GPT_NUMERICAL_AUDIT_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md`.
5. `CODEX_WORK_ORDER_CENTRAL_Z_POST_AUDIT_FINALIZATION_v0.1.md`.

These are evidence of earlier completed work, not new executions. The audit ZIP contains the report, checker, coverage CSV, saved results and manifests; redundant unpacked checker outputs are not included. All eight work-order input identities matched before editing, and both evidence ZIPs passed member-hash and CRC inspection. The supplied replay ZIP is 160645 bytes with SHA-256 `8b4eccc36121ffdb49a943759b4fa23ce582025b86b47c40b65781c2c2fe75d0`.

The baseline is `C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_MANUSCRIPT_v0.2`. The source snapshot remains `3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34`. Its 37 scientific records are preserved historical identities, not a new read or audit of the live repository. Before/after hashing is limited to the actual preserved inputs used by this pass, including the copied baseline TeX cache and existing compiler.

## Document production

The existing Tectonic 0.17.0 executable was called directly with `--only-cached --untrusted --keep-logs --keep-intermediates`. A copy of v0.2's cache, the new fontconfig cache and temporary outputs are confined to this v0.3 workspace. The retained TeX Gyre Pagella fonts and figure were used. No software was installed and no project build script was run. The retained image requires a multi-file document build, and the app's standalone LaTeX tool does not export a PDF or support additional project files.

Windows CMD command record, from this directory:

```bat
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
python -B build\document_check.py > build\document-check-console.txt
call build_document.cmd
```

`build_document.cmd` activates `torment`, invokes the existing compiler, copies the resulting PDF, records Poppler `pdfinfo`, extracts text/metadata with `build/pdf_extract.py`, and renders pages with Poppler `pdftoppm -r 120 -png`. Document scripts ran with `C:\Users\Notandi\miniconda3\envs\torment\python.exe` (3.11.15). PDF extraction used bundled pure-Python pypdf 6.10.0 by an explicit module path; no package was installed or environment changed. `pdftotext` was unavailable, so it was not used for final extraction.

The compiler's final log reports three distinct underfull paragraphs at source lines 1596–1602, 1654–1658 and 1867–1871. Their pages (24, 25 and 28) were inspected. The compiler reran TeX internally for the contents file; the rendered contents and section/part page numbers were checked, including Part III on page 15. See `build/review/PAGE_INSPECTION.md`.

Lexical document checks compare 731 inline-math spans, 53 displayed bracket-math blocks, 39 equation environments, nine tabular environments, one longtable, six theorem bodies, three proposition bodies, the figure environment and author paragraph. All are unchanged after newline normalization; only the certificate's optional status title changed. All 79 labels remain, and both new bibliography keys resolve. These checks inspect text, not scientific formulas.

The compact ZIP omits font files, caches and the 29 page renders. The local workspace retains those renders for review. Compiler/cache paths in the scripts are local-toolchain records, not a promise of a portable compiler installation.

## Stop boundary

No scientific evaluator, native recurrence, simulation, test, project application or audit replay was run in this pass. No equation, numerical table, mathematical assertion, geometry, state, configuration, box, observer, schedule or four-update limit changed. Original manuscripts, reports, evidence and repository/publication files were not edited. No commit, push, tag, release, DOI, upload or publication operation occurred. Hilmir's wording review remains pending and publication is not authorized.
