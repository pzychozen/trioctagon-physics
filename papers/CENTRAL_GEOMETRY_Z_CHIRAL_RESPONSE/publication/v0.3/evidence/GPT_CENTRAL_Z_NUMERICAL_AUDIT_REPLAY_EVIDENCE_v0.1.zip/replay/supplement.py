"""Additional inherited proof estimates, using the independent interval backend."""
from rigorous import *
from fractions import Fraction


def run(a,data,ob):
    check=a.check
    nominal,boxes,nompres,pres,g=data
    obs,read=ob
    kw=dict(source="R3",locator="7 nominal enclosures",domain="exact nominal four-update composition")
    constants=[
        ("sqrt2",I(2).sqrt(),"1.4142135","1.4142136"),
        ("sqrt3",I(3).sqrt(),"1.7320508","1.7320509"),
        ("cos",g["c"],".7438391",".7438393"),
        ("sin",sin(I(".732")),".6683",".6684"),
        ("envelope",exp(I("-.0577")),".9439",".9440"),
        ("a",g["a"],".1464",".1465"),("h",g["h"],".2071",".2072"),
        ("r",g["r"],".2886",".2887"),("b",g["b"],".69344",".69345"),
        ("X",g["X"],"2.99090","2.99092"),("X_over_b",g["X"]/g["b"],"4.313131","4.313139")]
    for name,value,lo,hi in constants: check("A.supp.constant."+name,value,lo,hi,**kw)
    for j,(lo,hi) in enumerate([("-.6049883","-.6049877"),("-.3388968","-.3388966"),("-.0800636","-.0800629")]):
        check(f"A.supp.star{j}",g["star"][j],lo,hi,**kw)
    v1bounds=[(".33497",".33523",".03005",".03008",".3363",".3366"),
              ("-.27953","-.27916",".03882",".03885",".2818",".2823"),
              ("-.22958","-.22950",".22330",".22334",".3202",".3204")]
    for j,row in enumerate(v1bounds):
        for k,val in enumerate([nompres[1][j][0],nompres[1][j][1],cabs(nompres[1][j])]):
            check(f"A.supp.V1.{j}.{k}",val,*row[2*k:2*k+2],**kw)
    for j,bounds in enumerate([(".1131079034",".1132839593"),(".079437298",".0796463434"),(".10253314",".102587732")]):
        check(f"A.supp.V1.intensity{j}",abs2(nompres[1][j]),*bounds,**kw)
    # R4 whole-box finite difference proof: every coefficient and enlargement
    # is substituted exactly. These are inequalities on the entire stated
    # containing balls, not centre derivatives.
    kw4=dict(source="R4",locator="3-4 (10)-(26)",domain="entire original box and the stated radius-four / nonzero containing domains",
             method="integer rational arithmetic")
    d=I(a.DELTA);e=2*d;D=78*d;G=58*D+2*d;Q=21*D+d
    for name,value,upper in [
        ("cubic_Lipschitz",3*I(4).square(),"48"),
        ("H_Lipschitz",5+3*I(4).square(),"53"),
        ("H_centre",3*(4+I(3).square()),"39"),
        ("state_coefficient",1+I(".2")*53+I(".3")*4,"12.8"),
        ("parameter_coefficient",I(".2")*3+39+12,"51.6"),
        ("pre_error",I("12.8")*e+I("51.6")*d,".00000078"),
        ("normalized_coefficient",I(2)/I(".25"),"8"),
        ("T_difference_coefficient",9*16,"144"),
        ("phase_coefficient",I(".2")*2*144,"58"),
        ("phase_error",G,".00004526"),
        ("post_error",D+I(".34")*G,".00001639"),
        ("post_enlargement",Q,".00001639"),
        ("initial_observation",9*d,".00000009"),
        ("updated_observation",I("1.236")*D+I(".34")*Q,".00000653668")]:
        check("A.coarse1."+name,value,None,upper,strict=False,**kw4)
    for j,lower in enumerate([".33629922",".28179922",".32019922"]):
        check(f"A.coarse1.nonzero{j}",cabs(nompres[1][j]).inflate(D.upper()),lower,".34",source="R4",locator="3.1 (15)",domain="whole complex D_V ball around exact nominal V1")
    # The only use of |T'|<=9 is on [-1,1]; its extrema follow directly
    # from T'=3-12s^2, with s^2 in [0,1].
    check("A.coarse.T_derivative",(3-12*I(-1,1).square()).abs(),None,9,strict=False,**kw4)
    kw5=dict(source="R5",locator="3-4 (9)-(26)",domain="exact nominal composition or whole inherited Q1/D2 containing balls as indicated")
    v2bounds=[(".1533",".1542",".1381",".1393",".2063",".2079"),
              ("-.2160","-.2150",".1592",".1603",".2675",".2690"),
              ("-.2300","-.2290",".2452",".2463",".3355",".3370")]
    for j,row in enumerate(v2bounds):
        for k,val in enumerate([nompres[2][j][0],nompres[2][j][1],cabs(nompres[2][j])]):
            check(f"A.supp.V2.{j}.{k}",val,*row[2*k:2*k+2],**kw5)
    for j,lim in enumerate([(".04257250",".04318213"),(".07156964",".07235209"),(".11256404",".11356369")]):
        check(f"A.supp.V2.intensity{j}",abs2(nompres[2][j]),*lim,**kw5)
    check("A.supp.V2.norm2",norm2(nompres[2]),".22670618",".22909791",**kw5)
    check("A.supp.V2.norm",norm(nompres[2]),".4761",".4787",**kw5)
    pairlims=[("-.01132168","-.01062971",".05518525",".0559251","-.206","-.190"),
              ("-.00160388","-.00079611",".06921365",".0700623","-.024","-.011"),
              ("-.0167440","-.015849",".08974625",".090653","-.187","-.174")]
    for n,((j,k),row) in enumerate(zip(a.PAIRS,pairlims)):
        product=cmul(conj(nompres[2][j]),nompres[2][k])
        numerator=product[0 if n<2 else 1];den=cabs(nompres[2][j])*cabs(nompres[2][k])
        for name,value,lim in [("numerator",numerator,row[:2]),("denominator",den,row[2:4]),("quotient",numerator/den,row[4:])]:
            check(f"A.supp.pair2.{n}.{name}",value,*lim,**kw5)
        sn=product[1]/den
        check(f"A.supp.T2.{n}",3*sn-4*sn**3,*[("-.841","-.812"),("-1","-.9973"),("-.535","-.500")][n],**kw5)
    D2=I(".00004");Q1=Q;G2=65*D2+2*d;Q2=24*D2+d
    for name,value,upper in [
        ("H_Lipschitz",I("4.01")+3*I(".34").square(),"4.3568"),
        ("H_centre",I(".34")*(4+I(".34").square()),"1.4"),
        ("state_coefficient",1+I(".11")*I("4.3568")+I(".21")*4,"2.32"),
        ("parameter_coefficient",I(".11")*I(".34")+I("1.4")+I("1.36"),"2.8"),
        ("pre_error",I("2.32")*Q1+I("2.8")*d,".00004"),
        ("normalized_coefficient",I(2)/I(".20"),"10"),
        ("phase_coefficient",I(".18")*2*180,"65"),
        ("phase_error",G2,".00260002"),
        ("post_error",D2+I(".34")*G2,".00096001"),
        ("post_enlargement",Q2,".00096001"),
        ("chiral_error",I(".68")*Q2,".0006528068"),
        ("observation_error",I("1.236")*D2+I(".34")*Q2,".0003758434")]:
        check("A.coarse2."+name,value,None,upper,strict=False,source="R5",locator="4 (18)-(26)",domain="whole inherited Q1/D2 containing balls, original coefficient box",method="integer rational arithmetic")
    for j,lower in enumerate([".20626",".26746",".33546"]):
        check(f"A.coarse2.nonzero{j}",cabs(nompres[2][j]).inflate(D2.upper()),lower,".34",source="R5",locator="4.1 (19)",domain="whole complex D2 ball around nominal V2")
    # Norm and readout intermediate intervals, distinguished from final boxes.
    for n in [3,4]:
        for tag,val,lim in [
            ("nominal_norm",norm(nompres[n]),[(".4845",".4860"),(".5603",".5664")][n-3]),
            ("box_norm",norm(pres[n]),[(".48449",".48601"),(".56025",".56645")][n-3]),
            ("K",read[n]["K"],[(".20159",".20221"),(".22187",".22353")][n-3]),
            ("envelope",read[n]["E"]**n,[(".8409",".8413"),(".7937",".7942")][n-3])]:
            check(f"B.supp.{n}.{tag}",val,*lim,source="R6",locator="4.1-4.3",domain=a.BOXDOMAIN)
        err=I("1.236")*a.DN[n]+I(".37" if n==3 else ".425")*a.QN[n]
        check(f"B.supp.readout_error{n}",err,None,".000012" if n==3 else ".000051",source="R6",locator="4.3 (22)",domain="entire inherited original-box perturbation enclosure")
    check("B.supp.K2",read[2]["K"],".19919",".20011",source="R6",locator="4",domain=a.BOXDOMAIN)
    # Every printed strict distance margin, rather than sign alone.
    radius=[realnorm(z[:2]) for z in obs];height=[z[2].abs() for z in obs];centre=[realnorm(z) for z in obs]
    native=[read[1]["K"]*g["c"]*(1 if j!=1 else 0)+read[1]["C"][j]/2 for j in range(3)]
    rn=realnorm(native[:2])
    margins=[("native_slab",g["h"]-native[2],".01465"),("first_slab",g["h"]-height[1],".03922"),
             ("initial_above",obs[0][2]-g["h"],".0974"),
             ("native_host",g["r"]-rn,".1326"),("first_host",g["r"]-radius[1],".1796"),
             ("native_radial_approach",radius[0]-rn,".0133"),("native_vs_scheduled_radius",rn-radius[1],".03947"),
             ("native_squared_height",obs[0][2].square()-native[2].square(),".0556"),
             ("first_squared_height",obs[0][2].square()-obs[1][2].square(),".0645"),
             ("third_host",g["r"]-radius[3],".1485"),("fourth_host",g["r"]-radius[4],".1585"),
             ("third_slab",g["h"]-height[3],".1132"),("fourth_slab",g["h"]-height[4],".0701")]
    for i,j,mins in [(2,3,(".0149",".0136",".0199")),(0,3,(".0292",".2107",".1797")),
                     (3,4,(".0086","-.0394","-.0138")),(0,4,(".0392",".1676",".1594")),
                     (4,1,(".0157","-.03034","-.0080"))]:
        for key,seq,threshold in zip(["axis","throat","centre"],[radius,height,centre],mins):
            sign=-1 if threshold.startswith("-") else 1
            margins.append((f"{key}_{i}_{j}",sign*(seq[i]-seq[j]),threshold.lstrip("-")))
    for name,val,lower in margins:
        check("B.margin."+name,val,lower,None,source="R4" if name.startswith(("native","first","initial")) else "R6",locator="R4 5; R6 6 printed distance margins",domain=a.BOXDOMAIN)
    check("B.supp.second_centre_R6",centre[2],".1886",".195",source="R6",locator="6 distance table (stronger than manuscript lower .1866)",domain=a.BOXDOMAIN)
    correlated_fourth(a,data)
    polynomial_domains(a,data)
    remaining_readouts(a,data,ob)


def correlated_fourth(a,data):
    check=a.check
    u=I(".587",".614");v=I(".020",".038");lam=a.PBOX[2]
    kw=dict(source="R7",locator="6.2 correlated fourth-stage refinement",label="app:mechanism",
            domain="whole closed S4 x Lambda; later amplitude-ratio restrictions from whole inherited W4 balls")
    cu=cos(3*u);cuv=cos(3*(u+v));cv=cos(3*v)
    check("C.refine.cos3u",cu,"-.268","-.189",**kw)
    check("C.refine.cos3uv",cuv,"-.376","-.247",**kw)
    du=1+lam*(-6*cu-3*cuv)
    dv=lam*(3*cv-3*cuv)
    check("C.refine.derivative_u",du.abs(),None,"1.466",**kw)
    check("C.refine.derivative_v",dv.abs(),None,".702",**kw)
    dl=-2*sin(3*u)+sin(3*v)-sin(3*(u+v))
    check("C.refine.derivative_lambda",dl.abs(),None,"4",**kw)
    w=polynomial(a.CENTERS[3],a.PARAM);_,inc,ph=sync(w,a.PARAM[2])
    uh=ph[1]-ph[0];vh=ph[2]-ph[1];change=inc[1]-inc[0]
    for name,val,lim in [("uhat",uh,(".6004",".6007")),("d12hat",change,("-.47774","-.47750")),
                         ("uphat",uh+change,(".12266",".12320"))]:
        check("C.refine."+name,val,*lim,**kw)
    # Deviations refer to the actual image enclosure, not every point of S4.
    # Cover the entire inherited W4 complex balls, so the derivative segment
    # estimate is checked on its original, larger proof domain.
    phactual=[arg(z).inflate((a.RADII[4]/I(cabs(z).lower()-a.RADII[4].upper())).upper()) for z in a.WC[4]]
    for name,val,limit in [
        ("u_actual_deviation",(phactual[1]-phactual[0]-uh).abs(),".0133"),
        ("v_actual_deviation",(phactual[2]-phactual[1]-vh).abs(),".0083")]:
        check("C.refine."+name,val,None,limit,source="R7",locator="5.3 (27)",label="app:mechanism",
              domain="whole inherited W4 complex balls of radius .00151, relative to exact polynomial comparison phases")
    error=I("1.466")*I(".0133")+I(".702")*I(".0083")+4*a.DELTA
    check("C.refine.up_error",error,None,".025325",**kw)
    up=I(".12266",".12320").inflate(error.upper())
    check("C.refine.up_actual",up,".097",".149",source="R7",locator="5.3 (27)",label="app:mechanism",
          domain="actual-image enclosing phase balls; derivative segment contained in whole S4")
    # Dependence on v is preserved in v'=b v; b was proved over all S4.
    vp=I(".00182",".005586");up=I(".097",".149")
    amps=[cabs(z).inflate(Fraction(".00151")) for z in a.WC[4]]
    for j,lim in enumerate([(".17551",".17854"),(".32997",".33300"),(".41821",".42124")]):
        check(f"C.refine.amplitude{j}",amps[j],*lim,**kw)
    ratio=amps[2]/amps[1]
    check("C.refine.r3_r2",ratio,"1.255","1.277",**kw)
    # cot is decreasing on (0,pi), so use matched endpoint evaluation.
    cot=I.raw((cos(I(up.upper()))/sin(I(up.upper()))).lo,(cos(I(up.lower()))/sin(I(up.lower()))).hi)
    angular=cos(vp)+cot*sin(vp)
    check("C.refine.sine_ratio",angular,"1.012","1.058",**kw)
    q=ratio*angular
    check("C.refine.minusC2_C3",q,"1.270","1.351",**kw)
    check("C.refine.r3_r1",amps[2]/amps[0],None,"2.401",**kw)
    # sinc(up)>.9962 holds uniformly; monotonic sinc on this range.
    check("C.refine.sinc_up",sin(I(up.upper()))/I(up.upper()),".9962",None,**kw)
    t=amps[2]/amps[0]*sin(vp)/sin(up)
    check("C.refine.C1_C3",t,"0",".139",**kw)
    frac=1/(1+q.square()+t.square()).sqrt()
    check("C.refine.vertical_fraction",frac,".592",".620",**kw)
    contraction=I(".147")/I(".99975")*(I(".614")/(I(".9962")*I(".097")))
    check("C.refine.direction_contraction",contraction,None,".935",**kw)


def polynomial_domains(a,data):
    check=a.check
    _,boxes,_,pres,_=data
    kw=dict(source="R8",locator="7 signed polynomial component sums",label="sec:inclusion",domain=a.BOXDOMAIN)
    for n,diags,terms in [
        (3,[(".79570",".79573"),(".89279",".89282"),(".98867",".98872")],
         [(".14999",".15038"),("-.10174","-.10154"),(".06751",".06789"),(".06536",".06556")]),
        (4,[(".79795",".79804"),(".89172",".89185"),(".98660",".98677")],
         [(".05675",".05848"),("-.10890","-.10802"),(".09646",".09820"),(".07180",".07268")])]:
        z=boxes[n-1];eps,gg,_,*kk=a.PBOX
        diag=[1-2*gg+eps*(kk[j]-abs2(z[j])) for j in range(3)]
        for j,lim in enumerate(diags): check(f"D.polynomial{n}.diag{j}",diag[j],*lim,**kw)
        values=[diag[0]*z[0][0],gg*(z[1][0]+z[2][0]),diag[0]*z[0][1],gg*(z[1][1]+z[2][1])]
        for j,(val,lim) in enumerate(zip(values,terms)): check(f"D.polynomial{n}.signed_sum{j}",val,*lim,**kw)
        for j in range(3):
            diff=cabs(pres[n][j])-cabs(z[j])
            check(f"D.polynomial{n}.amplitude_change{j}",-diff if n==3 and j==0 else diff,"0",None,**kw)
    ph=[arg(z) for z in boxes[2]];u=ph[1]-ph[0];v=ph[2]-ph[1]
    for name,val,lim in [("u",u,("2.128","2.141")),("v",v,(".019",".028")),("mean",u+v/2,("2.140","2.153"))]:
        check("D.incoming_O2."+name,val,*lim,**kw)
    ph=[arg(z) for z in boxes[3]]
    check("D.polynomial.mean_O3_above_line",(ph[1]+ph[2])/2-ph[0]-PI/3,"0",None,**kw)
    ph=[arg(z) for z in pres[4]]
    check("D.polynomial.mean_V4_below_line",PI/3-((ph[1]+ph[2])/2-ph[0]),"0",None,**kw)


def remaining_readouts(a,data,ob):
    check=a.check
    nominal,boxes,nompres,pres,g=data
    obs,read=ob
    # Nominal early rotations and coordinates used in the older coarse proof.
    tables=[
        (1,[(".3224",".3230",".0947",".0957"),("-.2594","-.2587",".1111",".1118"),("-.2451","-.2444",".2062",".2069")],
         [("-.0266","-.0259"),("-.0903","-.0896"),(".0603",".0610")],
         [(".1963",".1984"),("-.2688","-.2674"),(".0697",".0718")],
         [(".9803",".9808",".1950",".1972"),(".9640",".9645","-.2657","-.2642"),(".9974",".9976",".0696",".0718")]),
        (2,[(".1876",".1899",".0838",".0864"),("-.2251","-.2221",".1464",".1501"),("-.2862","-.2829",".1775",".1808")],
         [(".0007",".0036"),("-.0591","-.0570"),(".0460",".0480")],
         [("-.3130","-.3075"),(".0470",".0580"),(".2545",".2610")],
         [(".9514",".9532","-.3080","-.3026"),(".9983",".9990",".0469",".0580"),(".9661",".9679",".2517",".2581")])]
    for n,coords,chirs,incs,rots in tables:
        _,delta,_=sync(nompres[n],a.PARAM[2])
        C=chiral(nominal[n])
        kw=dict(source="R3" if n==1 else "R5",locator="R3 7.3 (30); R5 3.2 (13)-(14)",domain="exact nominal composition")
        for j in range(3):
            for k in range(2): check(f"A.nominal{n}.post{j}.{k}",nominal[n][j][k],*coords[j][2*k:2*k+2],**kw)
            check(f"A.nominal{n}.increment{j}",delta[j],*incs[j],**kw)
            check(f"A.nominal{n}.rotation_cos{j}",cos(delta[j]),*rots[j][:2],**kw)
            check(f"A.nominal{n}.rotation_sin{j}",sin(delta[j]),*rots[j][2:],**kw)
            check(f"C.nominal{n}.chirality{j}",C[j],*chirs[j],**kw)
    for n,coords in [
        (1,[(".10551",".10602"),(".02345",".023885"),(".16735",".16787")]),
        (2,[("-.0661","-.0641"),("-.1446","-.1427"),("-.1098","-.1079")]),
        (3,[(".00055",".00130"),("-.13995","-.13875"),("-.09380","-.09265")]),
        (4,[("-.06735","-.06370"),(".1074",".1110"),(".13345",".13685")])]:
        z,details=observe(nominal[n],n,g,nompres[n])
        for j,lim in enumerate(coords):
            check(f"B.nominal{n}.coordinate{j}",z[j],*lim,source="R3" if n==1 else "R5" if n==2 else "R6",locator="nominal observation table",domain="exact nominal composition")
        if n>=3:
            check(f"B.nominal{n}.positive_amplitude",details["amplitude"].abs(),*[(".1132",".1138"),(".1309",".1322")][n-3],
                  source="R6",locator="4.1 / Appendix B.5",domain="exact nominal composition")
            cb=([(".0011",".0026"),("-.0523","-.0511"),(".0400",".0411")] if n==3 else
                [("-.0025",".0035"),("-.0118","-.0070"),(".0051",".0093")])
            for j,lim in enumerate(cb):
                check(f"C.nominal{n}.chirality{j}",details["C"][j],*lim,source="R6",locator="4.2",domain="exact nominal composition")
    check("B.sqrt3_over2",I(3).sqrt()/2,".8660254",".86602545",source="R6",locator="4.1",domain="exact radical")
    z,_=observe(nominal[1],0,g,nompres[1])
    for j,lim in enumerate([(".14848",".14899"),("-.04515","-.04480"),(".19193",".19244")]):
        check(f"B.nominal.native_only{j}",z[j],*lim,source="R3",locator="7 nominal native-only table",domain="exact nominal composition")
    # Earlier attribution table and residual sign-changing comparison points.
    E=read[0]["E"]
    for n,lims in [
        (1,[("-.01172","-.01093"),("-.00784","-.00581"),("-.01956","-.01674"),("-.007092","-.007028"),("-.2521","-.2504")]),
        (2,[("-.00201","-.00098"),("-.00401","-.00244"),("-.00602","-.00342"),(".00747",".00754"),(".01277",".01287")]),
        (3,[("-.01234","-.01104"),("-.01802","-.01533"),("-.03036","-.02637"),(".00697",".00707"),(".2485",".2509")])]:
        source="R5" if n==1 else "R6"
        nativeK=(E**n)*read[n]["f"]*(read[n+1]["K"]-read[n]["K"])
        nativeC=(read[n+1]["C"][2]-read[n]["C"][2])/2
        envelope=read[n+1]["K"]*(E**n)*(E-1)*read[n]["f"]
        clock=read[n+1]["K"]*(E**(n+1))*(read[n+1]["f"]-read[n]["f"])
        for name,val,lim in zip(["K","C","native","envelope","clock"],[nativeK,nativeC,nativeK+nativeC,envelope,clock],lims):
            check(f"C.earlier_attribution{n}.{name}",val,*lim,source=source,locator="R5 6 / R6 7",label="eq:attribution",domain=a.BOXDOMAIN)
        wn=read[n+1]["K"]*E**n*read[n]["f"]+read[n+1]["C"][2]/2
        we=read[n+1]["K"]*E**(n+1)*read[n]["f"]+read[n+1]["C"][2]/2
        if n==1:
            check("B.attribution2.native_height",wn,".14778",".15114",source=source,locator="6 (36)",domain=a.BOXDOMAIN)
            check("B.attribution2.envelope_height",we,".140688",".144112",source=source,locator="6 (36)",domain=a.BOXDOMAIN)
            check("B.attribution2.height_change",obs[2][2]-obs[1][2],"-.27808","-.27484",source=source,locator="6 (37)",domain=a.BOXDOMAIN)
        if n==3:
            check("B.attribution4.native_height",wn,"-.12426","-.11897",source=source,locator="7.2",domain=a.BOXDOMAIN)
            check("B.attribution4.envelope_height",we,None,"-.11190",source=source,locator="7.2",domain=a.BOXDOMAIN)
    rad=[realnorm(z[:2]) for z in obs];h=[z[2].abs() for z in obs]
    for name,val,limit in [
        ("slab",g["h"]-h[2],".0969"),("host",g["r"]-rad[2],".1286"),
        ("throat_vs_first",h[1]-h[2],".05714"),("throat_vs_initial",h[0]-h[2],".1944"),
        ("axis_vs_first",rad[2]-rad[1],".046"),("axis_vs_initial",rad[0]-rad[2],".0093")]:
        check("B.second_margin."+name,val,limit,None,source="R5",locator="5-7 distance table",domain=a.BOXDOMAIN)
