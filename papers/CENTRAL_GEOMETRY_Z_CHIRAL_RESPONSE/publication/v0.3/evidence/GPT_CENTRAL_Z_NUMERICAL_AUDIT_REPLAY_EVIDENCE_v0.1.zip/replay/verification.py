"""Audit self-checks, symbolic identities, nominal corroboration and provenance."""
import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import sys
from fractions import Fraction
from pathlib import Path
from rigorous import *


def self_checks():
    tests=[]
    def record(name,ok):
        assert ok,name
        tests.append(dict(id=name,status="PASS_SELF_CHECK"))
    def has(value,x):
        return value.lower() <= Fraction(x) <= value.upper()
    # Exact corner calculations test the arithmetic implementation, not the
    # nonlinear scientific assertions. Scientific proofs use whole intervals.
    cases=[("-3.7","-1.1"),("-2.1",".31"),("0","1.7"),("1.2","4.8")]
    for i,(aa,bb) in enumerate(cases):
        x=I(aa,bb);ends=[Fraction(aa),Fraction(bb)]
        record(f"square_{i}",all(has(x.square(),v*v) for v in ends) and (not (x.lo<=0<=x.hi) or has(x.square(),0)))
        for j,(cc,dd) in enumerate(cases):
            y=I(cc,dd);ys=[Fraction(cc),Fraction(dd)]
            record(f"add_multiply_{i}_{j}",all(has(x+y,v+w) and has(x*y,v*w) for v in ends for w in ys))
            if not y.lo<=0<=y.hi:
                record(f"divide_{i}_{j}",all(has(x/y,v/w) for v in ends for w in ys))
    for v in ["0","1","2","3","0.000000000001","17.31"]:
        r=I(v).sqrt();q=Fraction(v)
        record("sqrt_"+v,r.lower()**2 <= q <= r.upper()**2)
    for name,fn,exc in [
        ("zero_denominator",lambda:I(1)/I(-1,1),ZeroDivisionError),
        ("negative_root",lambda:I(-1,2).sqrt(),ValueError),
        ("binary64_rejected",lambda:I(0.1),TypeError),
        ("ambiguous_arg",lambda:arg((I(-2,-1),I("-1",".1"))),ValueError),
        ("uncertain_zero_sync",lambda:sync([(I(-1,1),I(-1,1))]*3,I(".17")),ValueError)]:
        caught=False
        try: fn()
        except exc: caught=True
        record(name,caught)
    record("pi_machin_width",PI.subset("3.141592653589793238462643383279","3.141592653589793238462643383280"))
    q=Fraction(1,5)
    tan2=2*q/(1-q*q);tan4=2*tan2/(1-tan2*tan2)
    record("machin_exact_tangent",(tan4-Fraction(1,239))/(1+tan4/Fraction(239))==1)
    record("atan_zero",has(atan(I(0)),0))
    # Endpoint cases straddle both implementation reductions .5 and 1.
    for x in [Fraction(1,2),Fraction(1),Fraction(2),Fraction(-2)]:
        rec=atan(I(x))+atan(I(1/x))
        target=PI/2 if x>0 else -PI/2
        record("atan_reciprocal_"+str(x),not(rec.hi<target.lo or target.hi<rec.lo))
        direct=atan_small_point(x) if abs(x)<=Fraction(1,2) else atan_point(x)
        record("atan_boundary_"+str(x),atan(I(x)).contains(direct))
    record("sin_extremum",sin(PI/2).contains(1) and sin(-PI/2).contains(-1))
    record("cos_extrema",cos(I(-1,1)).contains(1) and cos(PI).contains(-1))
    record("exp_zero",has(exp(I(0)),1))
    record("arg_positive_axis",arg((I(1),I(0))).contains(0))
    record("arg_negative_axis",arg((I(-1),I(0))).contains(PI))
    record("arg_zero",arg((I(0),I(0))).contains(0))
    zero=(I(0),I(0))
    z=[zero,(I(-1),I(0)),(I(1),I(0))]
    out,_,_=sync(z,I(".17"))
    record("sync_exact_zero_output",out[0][0].lo==out[0][0].hi==out[0][1].lo==out[0][1].hi==0)
    uncertain=[(I(-1,1),I(-1,1))]*3
    out,_,ph=sync(uncertain,I(0))
    record("lambda_zero_bypass",ph is None and all(x.lo==y.lo and x.hi==y.hi for c,d in zip(out,uncertain) for x,y in zip(c,d)))
    return tests


def symbolic_checks():
    import sympy as s
    checks=[]
    def prove(name,expressions,description):
        reduced=[s.expand(x) for x in expressions]
        assert all(x==0 for x in reduced),name
        checks.append(dict(id=name,status="VERIFIED_EXACT",method="SymPy exact polynomial expansion to zero",
                           description=description,source_dependency="supporting identities, not a new theorem programme"))
    x=s.Matrix(s.symbols("x0:3",real=True));y=s.Matrix(s.symbols("y0:3",real=True))
    eps,g=s.symbols("eps g",real=True);k=s.symbols("k0:3",real=True)
    L=s.ones(3)-3*s.eye(3)
    prove("L_squared",[v for v in L*L+3*L],"L3^2=-3L3")
    t=[x[j]**2+y[j]**2 for j in range(3)]
    hx=s.Matrix([x[j]*(k[j]-t[j]) for j in range(3)])
    hy=s.Matrix([y[j]*(k[j]-t[j]) for j in range(3)])
    dx=eps*hx+g*L*x;dy=eps*hy+g*L*y
    onsite=2*eps*sum(t[j]*(k[j]-t[j]) for j in range(3))
    pairs=sum((x[j]-x[l])**2+(y[j]-y[l])**2 for j in range(3) for l in range(j+1,3))
    budget=onsite-2*g*pairs+dx.dot(dx)+dy.dot(dy)
    exact=(x+dx).dot(x+dx)+(y+dy).dot(y+dy)-x.dot(x)-y.dot(y)
    prove("complete_norm_budget",[exact-budget],"Complete finite squared increment retained")
    B=s.Matrix(3,3,s.symbols("b0:9",real=True))
    prove("cofactor_transport",list((B*x).cross(B*y)-B.cofactor_matrix()*x.cross(y)),"Valid for every real B, including singular B")
    C=x.cross(y)
    prove("gram_chirality",[C.dot(C)-x.dot(x)*y.dot(y)+x.dot(y)**2],"||x cross y||^2=||x||^2||y||^2-(x dot y)^2")
    # Centroid and orthonormal witness identities use only these exact relations.
    c=s.Matrix(s.symbols("c0:3",real=True));b,ll=s.symbols("b L",positive=True)
    p=s.Matrix([-c[1]/b,c[0]/b,0]);q=c.cross(p)/ll
    prove("witness_p_orthogonal",[s.factor(c.dot(p)),s.factor(p.dot(q))],"p perpendicular to c and q")
    # Rational algebra after multiplying positive denominators.
    prove("witness_cross",list(s.simplify(p.cross(c.cross(p))*b**2-c*(c[0]**2+c[1]**2))),
          "p cross (c cross p)=c when b^2=c1^2+c2^2")
    # Trigonometric reductions are checked independently as finite symbolic
    # identities, with no interval-zero-overlap inference.
    u,v,lam,zeta=s.symbols("u v lam zeta",real=True)
    du=lam*(-2*s.sin(3*u)+s.sin(3*v)-s.sin(3*(u+v)))
    dv=lam*(s.sin(3*u)-s.sin(3*(u+v))-2*s.sin(3*v))
    targetdu=-3*lam*s.sin(3*(u+v/2))*s.cos(3*v/2)
    targetdv=-2*lam*s.sin(3*v/2)*(s.cos(3*(u+v/2))+2*s.cos(3*v/2))
    for name,expr in [("mean_phase_reduction",du+dv/2-targetdu),("splitting_reduction",dv-targetdv)]:
        reduced=s.trigsimp(s.expand_trig(expr))
        assert reduced==0,(name,reduced)
        checks.append(dict(id=name,status="VERIFIED_EXACT",method="SymPy exact trig expansion and simplification",
                           description="Same simultaneous increments; local phases unwrapped"))
    return checks


def nominal_crosscheck(a,data):
    import mpmath as mp
    mp.mp.dps=120
    f=mp.mpf
    root2,root3=mp.sqrt(2),mp.sqrt(3)
    aa=(1-root2/2)/2;hh=(root2-1)/2;rr=root3/6
    P=[root3*aa/6,-aa/2-rr/3,(2*hh+f(".5"))/3]
    c=[2*(P[j]-(f(".4635")*mp.cos(f(".732")) if j!=1 else 0)) for j in range(3)]
    dot=lambda x,y:sum(t*w for t,w in zip(x,y))
    cr=lambda x,y:[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
    b=mp.sqrt(c[0]**2+c[1]**2);ell=mp.sqrt(dot(c,c))
    X=mp.sqrt((9+mp.sqrt(81-4*ell**2))/2);Y=mp.sqrt((9-mp.sqrt(81-4*ell**2))/2)
    p=[-c[1]/b,c[0]/b,0];q=[t/ell for t in cr(c,p)]
    z=[X*p[j]+1j*Y*q[j] for j in range(3)]
    states=[z];pre=[None]
    eps,gg,ll=f(".1"),f(".2"),f(".17");kk=[2,3,4]
    # Independent polynomial expression and branch-independent pair cubic.
    for n in range(1,5):
        w=[z[j]+eps*z[j]*(kk[j]-abs(z[j])**2)+gg*(z[(j+1)%3]+z[(j+2)%3]-2*z[j]) for j in range(3)]
        units=[x/abs(x) for x in w]
        inc=[ll*sum(3*mp.im(mp.conj(units[j])*units[k])-4*mp.im(mp.conj(units[j])*units[k])**3 for k in range(3) if k!=j) for j in range(3)]
        z=[abs(w[j])*mp.exp(1j*(mp.arg(w[j])+inc[j])) for j in range(3)]
        states.append(z);pre.append(w)
    output=[];contained=True
    for n,z in enumerate(states):
        C=cr([mp.re(t) for t in z],[mp.im(t) for t in z])
        pair=[mp.im(mp.conj(z[1])*z[2]),mp.im(mp.conj(z[2])*z[0]),mp.im(mp.conj(z[0])*z[1])]
        assert max(abs(v-w) for v,w in zip(C,pair))<f("1e-110")
        kap=mp.sqrt(sum(abs(t)**2 for t in z));K=f(".618")*kap/(1+kap)
        amp=K*mp.exp(-f(".0577")*n)*mp.cos(n*mp.pi/2-f(".732"))
        direction=[mp.cos(n*mp.pi/6),mp.sin(n*mp.pi/6),1]
        Z=[amp*direction[j]+C[j]/2 for j in range(3)]
        values=[[mp.re(t),mp.im(t)] for t in z]
        checks=[]
        for j in range(3):
            for k in range(2):
                numeric=Fraction(mp.nstr(values[j][k],110))
                rigorous=data[0][n][j][k]
                checks.append(rigorous.lower()<=numeric<=rigorous.upper())
        rigorousZ,_=observe(data[0][n],n,data[4],data[2][n])
        for j in range(3):
            numeric=Fraction(mp.nstr(Z[j],110))
            checks.append(rigorousZ[j].lower()<=numeric<=rigorousZ[j].upper())
        contained=contained and all(checks)
        stringify=lambda x:mp.nstr(x,100)
        output.append(dict(n=n,omega=[[stringify(t) for t in row] for row in values],norm=stringify(kap),
                           chiral=[stringify(t) for t in C],Z=[stringify(t) for t in Z],
                           agrees_with_rigorous_nominal_enclosure=all(checks)))
    assert contained,"High-precision cross-check disagrees with rigorous point enclosure"
    return dict(status="NUMERICAL_CORROBORATION_ONLY",backend="mpmath",version=mp.__version__,
                decimal_precision=120,scientific_horizon="n=0..4 exactly",observations=output,
                note="Rounded high-precision values are not interval proofs and are never used to accept whole-domain claims.")


def verify_inputs(root,manifest):
    copied=[];originals=[]
    for row in manifest["inputs"]:
        if row.get("local_copy"):
            p=root/row["local_copy"]
            digest=hashlib.sha256(p.read_bytes()).hexdigest()
            assert digest==row["sha256"],("BLOCKED_SOURCE",str(p))
            copied.append(dict(path=row["local_copy"],sha256=digest,status="MATCH"))
        p=Path(row["path"])
        if p.is_file():
            digest=hashlib.sha256(p.read_bytes()).hexdigest()
            status="MATCH" if digest==row["sha256"] else "MISMATCH"
            assert status=="MATCH",("BLOCKED_SOURCE",str(p))
        else:
            digest=None;status="UNAVAILABLE_ON_REPLAY_HOST"
        originals.append(dict(path=str(p),sha256=digest,status=status))
    return dict(copied_inputs=copied,originals=originals,
                all_local_originals_preserved=all(x["status"]=="MATCH" for x in originals))


def environment():
    return dict(interpreter=sys.executable,python=sys.version,platform=platform.platform(),
                conda_default_env=os.environ.get("CONDA_DEFAULT_ENV"),
                packages={name:importlib.metadata.version(name) for name in ["mpmath","sympy"]},
                scientific_backend="audit-local integer rational interval arithmetic",
                project_imports="none; project source files were read-only text",
                installation="none",bytecode_disabled=bool(sys.dont_write_bytecode),
                temporary_directory=os.environ.get("TEMP"),cache_directory=os.environ.get("XDG_CACHE_HOME"))


BLOCKS={
 "SOURCE_IDENTITY":("Hash-matched immutable definitions and accepted v0.2",[]),
 "SUPPORTING_IDENTITIES":("Exact finite-step algebra and local phase reduction",["SOURCE_IDENTITY"]),
 "A_START":("Exact witness, positive radicals and original state inclusion",["SOURCE_IDENTITY","SUPPORTING_IDENTITIES"]),
 "A_CHAIN":("Comparison residuals, entire-domain sensitivities and recurrences",["A_START"]),
 "B_OBSERVATIONS":("Same-state readouts, finite sections and own-observation distances",["A_CHAIN","SUPPORTING_IDENTITIES"]),
 "C_MECHANISM":("Norm budgets, chirality, direction refinement and attribution",["A_CHAIN","SUPPORTING_IDENTITIES","D_THEOREMS"]),
 "D_THEOREMS":("Closed phase/amplitude products, weighted signs and mean-line examples",["SOURCE_IDENTITY","SUPPORTING_IDENTITIES"]),
 "D_APPLICATION":("Original-box phase inclusion and signed polynomial supply",["A_CHAIN","D_THEOREMS"]),
}
CLAIM_BLOCKS={
 "Z01":["SOURCE_IDENTITY"],"Z02":["SOURCE_IDENTITY","SUPPORTING_IDENTITIES"],
 "Z06":["A_START","B_OBSERVATIONS"],"Z07":["A_CHAIN","B_OBSERVATIONS"],
 "Z08":["A_CHAIN","B_OBSERVATIONS"],"Z09":["A_CHAIN","B_OBSERVATIONS"],
 "Z10":["A_CHAIN","B_OBSERVATIONS","C_MECHANISM"],
 "M01":["SUPPORTING_IDENTITIES"],"M02":["A_CHAIN","C_MECHANISM"],
 "M03":["SUPPORTING_IDENTITIES","C_MECHANISM"],"M04":["A_CHAIN","C_MECHANISM"],
 "M05":["A_CHAIN","C_MECHANISM"],"P01":["SUPPORTING_IDENTITIES"],
 "P02":["SUPPORTING_IDENTITIES","D_THEOREMS"],
 "P03":["D_THEOREMS"],"P04":["D_THEOREMS"],"P05":["D_THEOREMS"],
 "P06":["A_CHAIN","D_THEOREMS","D_APPLICATION"],"P07":["A_CHAIN","D_APPLICATION"],
 "E01":["A_CHAIN"]}


def block_for(cid):
    if cid.startswith(("A.initial","A.supp.constant","A.supp.star")): return "A_START"
    if cid.startswith("A."): return "A_CHAIN"
    if cid.startswith("B."): return "B_OBSERVATIONS"
    if cid.startswith("C."): return "C_MECHANISM"
    if cid.startswith(("D.actual","D.comparison","D.phase_error","D.polynomial","D.incoming")): return "D_APPLICATION"
    if cid.startswith("D."): return "D_THEOREMS"
    raise ValueError(cid)


def enrich_and_coverage(a,selftests,algebra,before,after,nominal):
    def closure(keys):
        result=set(keys)
        for key in keys: result.update(closure(BLOCKS[key][1]))
        return result
    for record in a.RESULTS:
        block=block_for(record["id"])
        record["proof_block"]=block
        record["dependencies"]+=BLOCKS[block][1]
        record["downstream_claims"]=[claim for claim,bs in CLAIM_BLOCKS.items() if block in closure(bs)]
        if record["manuscript_label"]=="app:certificate":
            record["manuscript_label"]={"A_START":"eq:contactstate; eq:initialxy; app:certificate",
                "A_CHAIN":"app:certificate","B_OBSERVATIONS":"prop:four; tab:observations; app:finite",
                "C_MECHANISM":"sec:mechanism; app:mechanism",
                "D_THEOREMS":"sec:domaintheorems; eq:meanlineexample",
                "D_APPLICATION":"sec:inclusion; app:inclusion"}[block]
        # Assertions on actual-image deviations use the preceding certified
        # raw balls; theorem products never depend on their reachability.
        if record["id"].startswith("C.refine"):
            record["dependencies"]+=["D_THEOREMS"]
    blocks=[]
    for key,(description,deps) in BLOCKS.items():
        records=[r for r in a.RESULTS if r["proof_block"]==key]
        bad=[r["id"] for r in records if r["status"] not in ("VERIFIED_EXACT","VERIFIED_RIGOROUS")]
        status="UNRESOLVED" if bad else "VERIFIED_RIGOROUS"
        if key in ("SOURCE_IDENTITY","SUPPORTING_IDENTITIES"): status="VERIFIED_EXACT"
        if key=="SOURCE_IDENTITY" and not after["all_local_originals_preserved"]:
            # Portable copied-source replay still checks exact copied bytes;
            # original path preservation cannot be independently rechecked.
            status="VERIFIED_EXACT_COPIES_ORIGINAL_PRESERVATION_UNAVAILABLE"
        blocks.append(dict(id=key,description=description,dependencies=deps,status=status,
                           scalar_bound_records=len(records),unresolved_or_failed=bad))
    statusmap={b["id"]:b["status"] for b in blocks}
    for b in blocks:
        if any(statusmap[d]=="UNRESOLVED" for d in closure(b["dependencies"])):
            b["status"]="UNRESOLVED"
    statusmap={b["id"]:b["status"] for b in blocks}
    rows=list(csv.DictReader((a.ROOT/"inputs/manuscript/CLAIM_SOURCE_MAP.csv").open(encoding="utf-8-sig")))
    fields=["claim_id","manuscript_label","claim","audit_scope","status","proof_blocks","record_count","limits"]
    with (a.ROOT/"CLAIM_AUDIT_COVERAGE.csv").open("w",newline="",encoding="utf-8") as out:
        writer=csv.DictWriter(out,fields);writer.writeheader()
        for row in rows:
            cid=row["claim_id"];bs=CLAIM_BLOCKS.get(cid,[])
            numeric=cid in ("Z06","Z07","Z08","Z09","Z10","M02","M04","M05","P03","P04","P05","P06","P07","E01")
            status=("VERIFIED_RIGOROUS" if all(statusmap[b].startswith("VERIFIED") for b in bs) else "UNRESOLVED") if bs else "OUTSIDE_NUMERICAL_SCOPE"
            scope="Required quantitative dependencies" if numeric else "Supporting definitions/identities only" if bs else "Symbolic, historical or geometric claim not re-proved as a whole"
            limits="No audit of whole geometry family, historical provenance argument, physical interpretation, or publication readiness."
            if cid=="M05": limits="Only existing proved directional bounds; explicitly unresolved direction/projection comparisons remain outside scope."
            if cid=="P04": limits="Absolute margin uses A4; arbitrary-positive-amplitude sign follows from each uniformly negative pair coefficient."
            if cid=="P06": limits="Inclusion only; no reachability claim for every point of the larger products."
            writer.writerow(dict(claim_id=cid,manuscript_label=row["manuscript_label"],claim=row["claim"],audit_scope=scope,status=status,
                                 proof_blocks=";".join(bs),record_count=sum(r["proof_block"] in bs for r in a.RESULTS),limits=limits))
    return dict(proof_blocks=blocks,self_checks=selftests,symbolic_identity_checks=algebra,
                input_verification_before=before,input_verification_after=after,environment=environment(),
                nominal_crosscheck_status=nominal["status"],
                counts=dict(substantive_numerical_blocks=6,supporting_blocks=2,scalar_bound_records=len(a.RESULTS),
                            arithmetic_self_checks=len(selftests),exact_identity_checks=len(algebra)),
                verdict="PASS_WITHIN_SCOPED_IDEAL_MATHEMATICS" if all(b["status"].startswith("VERIFIED") for b in blocks) else "UNRESOLVED_DEPENDENCIES")
