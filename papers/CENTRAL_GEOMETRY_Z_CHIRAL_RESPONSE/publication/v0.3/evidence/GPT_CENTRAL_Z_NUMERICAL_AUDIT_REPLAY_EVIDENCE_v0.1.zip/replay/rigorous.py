"""Standalone closed rational intervals. No floating-point arithmetic.

Endpoints are integers divided by 10**60. Every inexact operation rounds out.
Square roots use integer square-root inequalities. Transcendentals use finite
Taylor sums and explicit remainder intervals; pi uses Machin's identity.
This small implementation is auditable code, not a formally verified library.
"""
from fractions import Fraction
from math import isqrt, factorial

DIGITS = 60
SCALE = 10 ** DIGITS


def floorq(x):
    return x.numerator // x.denominator


def ceilq(x):
    return -((-x.numerator) // x.denominator)


class I:
    __slots__ = ("lo", "hi")

    def __init__(self, lo=0, hi=None):
        if isinstance(lo, I) and hi is None:
            self.lo, self.hi = lo.lo, lo.hi
            return
        if isinstance(lo, float) or isinstance(hi, float):
            raise TypeError("Scientific decimal inputs must be strings, not floats")
        a, b = Fraction(lo), Fraction(lo if hi is None else hi)
        if a > b:
            raise ValueError("Reversed interval")
        self.lo, self.hi = floorq(a*SCALE), ceilq(b*SCALE)

    @classmethod
    def raw(cls, a, b):
        if a > b:
            raise ValueError("Reversed endpoints")
        obj = object.__new__(cls)
        obj.lo, obj.hi = a, b
        return obj

    def __add__(self, other):
        b = I(other)
        return I.raw(self.lo+b.lo, self.hi+b.hi)

    __radd__ = __add__

    def __neg__(self):
        return I.raw(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-I(other))

    def __rsub__(self, other):
        return I(other) + (-self)

    def __mul__(self, other):
        b = I(other)
        p = [a*c for a in (self.lo,self.hi) for c in (b.lo,b.hi)]
        return I.raw(min(p)//SCALE, -((-max(p))//SCALE))

    __rmul__ = __mul__

    def reciprocal(self):
        if self.lo <= 0 <= self.hi:
            raise ZeroDivisionError("Denominator enclosure includes zero")
        return I(Fraction(SCALE,self.hi), Fraction(SCALE,self.lo))

    def __truediv__(self, other):
        return self * I(other).reciprocal()

    def __rtruediv__(self, other):
        return I(other) * self.reciprocal()

    def __pow__(self, n):
        if not isinstance(n, int) or n < 0:
            raise ValueError("Nonnegative integer powers only")
        if n == 0:
            return I(1)
        if n % 2 == 0:
            return self.square() ** (n//2) if n > 2 else self.square()
        return self * (self ** (n-1))

    def square(self):
        lower = 0 if self.lo <= 0 <= self.hi else min(self.lo**2,self.hi**2)
        upper = max(self.lo**2,self.hi**2)
        return I.raw(lower//SCALE, -((-upper)//SCALE))

    def sqrt(self):
        if self.lo < 0:
            raise ValueError("Negative radicand bound")
        a, b = isqrt(self.lo*SCALE), isqrt(self.hi*SCALE)
        return I.raw(a, b + (b*b < self.hi*SCALE))

    def abs(self):
        if self.lo >= 0:
            return self
        if self.hi <= 0:
            return -self
        return I.raw(0,max(-self.lo,self.hi))

    def hull(self, other):
        b = I(other)
        return I.raw(min(self.lo,b.lo),max(self.hi,b.hi))

    def intersect(self, other):
        b = I(other)
        return I.raw(max(self.lo,b.lo),min(self.hi,b.hi))

    def inflate(self, radius):
        r = I(radius)
        assert r.lo >= 0
        return I.raw(self.lo-r.hi,self.hi+r.hi)

    def subset(self, lo, hi, strict=True):
        a, b = Fraction(lo)*SCALE, Fraction(hi)*SCALE
        return self.lo > a and self.hi < b if strict else self.lo >= a and self.hi <= b

    def contains(self, x):
        b = I(x)
        return self.lo <= b.lo and b.hi <= self.hi

    def mid(self):
        return Fraction(self.lo+self.hi,2*SCALE)

    def radius(self):
        return Fraction(self.hi-self.lo,2*SCALE)

    def upper(self):
        return Fraction(self.hi,SCALE)

    def lower(self):
        return Fraction(self.lo,SCALE)

    def data(self):
        return {"lower_numerator":str(self.lo),"upper_numerator":str(self.hi),
                "denominator":str(SCALE),"endpoint_semantics":"closed",
                "display":self.display()}

    def display(self, digits=14):
        def fmt(n, upper):
            unit = 10**(DIGITS-digits)
            k = -((-n)//unit) if upper else n//unit
            sign = "-" if k < 0 else ""
            k=abs(k)
            return f"{sign}{k//10**digits}.{k%10**digits:0{digits}d}"
        return "["+fmt(self.lo,False)+", "+fmt(self.hi,True)+"]"

    def __repr__(self):
        return self.display()


def atan_small_point(x):
    """|x|<=1/2; alternating-series error <= |x|**223/223."""
    x = Fraction(x)
    assert abs(x) <= Fraction(1,2)
    y = I(x)
    term, total = y, y
    for k in range(1,111):
        term = -term * y.square()
        total += term/(2*k+1)
    err = abs(x)**223/223
    return total.inflate(err)


PI = 16*atan_small_point(Fraction(1,5))-4*atan_small_point(Fraction(1,239))


def atan_point(x):
    x = Fraction(x)
    if x < 0:
        return -atan_point(-x)
    if x > 1:
        return PI/2-atan_point(1/x)
    if x > Fraction(1,2):
        return PI/4+atan_small_point((x-1)/(x+1))
    return atan_small_point(x)


def atan(x):
    x = I(x)
    return I.raw(atan_point(x.lower()).lo, atan_point(x.upper()).hi)


def sincos_point(x):
    """Reduce by an integer multiple of pi/2; Taylor degrees 71/70.

    Chosen reduction index is arbitrary for validity; the asserted residual
    bound guarantees the Lagrange remainders used here.
    """
    x = Fraction(x)
    k = floorq(x/(PI.mid()/2)+Fraction(1,2))
    y = I(x)-k*PI/2
    assert y.abs().hi < SCALE
    yy = y.square()
    st, ct = y, I(1)
    sn, cs = st, ct
    for n in range(1,36):
        st = -st*yy/((2*n)*(2*n+1))
        ct = -ct*yy/((2*n-1)*(2*n))
        sn += st
        cs += ct
    sn = sn.inflate(Fraction(1,factorial(72)))
    cs = cs.inflate(Fraction(1,factorial(71)))
    return [(sn,cs),(cs,-sn),(-sn,-cs),(-cs,sn)][k%4]


def trig(x, cosine=False):
    x = I(x)
    # The generous index padding below is proved sufficient on this range:
    # 3 < pi < 4 and |pi-mid(pi)| < 10^-55, so replacing pi by
    # its midpoint moves an extremum index by much less than one.
    assert x.abs().upper() <= 100
    assert PI.subset(3,4) and PI.radius() < Fraction(1,10**55)
    a = sincos_point(x.lower())[int(cosine)]
    b = sincos_point(x.upper())[int(cosine)]
    result = a.hull(b)
    # All extrema are at k*pi/2. A deliberately generous integer range,
    # with interval overlap to decide inclusion, handles pi uncertainty.
    low = floorq(x.lower()/(PI.mid()/2))-3
    high = ceilq(x.upper()/(PI.mid()/2))+3
    for k in range(low, high+1):
        extremum = k*PI/2
        if extremum.hi >= x.lo and extremum.lo <= x.hi:
            values = (1,0,-1,0) if cosine else (0,1,0,-1)
            result = result.hull(values[k%4])
    return result.intersect(I(-1,1))


def sin(x):
    return trig(x)


def cos(x):
    return trig(x,True)


def exp_point(x):
    x = Fraction(x)
    assert abs(x) <= 1
    term, total = I(1), I(1)
    for n in range(1,81):
        term = term*I(x)/n
        total += term
    # e**|x| < 3 for |x|<=1, so Taylor remainder <=3/81!.
    return total.inflate(Fraction(3,factorial(81)))


def exp(x):
    x=I(x)
    return I.raw(exp_point(x.lower()).lo,exp_point(x.upper()).hi)


def arg(z):
    x,y=z
    if x.lo == x.hi == y.lo == y.hi == 0:
        return I(0)  # source Arg_0 convention, exact zero only
    if y.lo == y.hi == 0 and x.hi < 0:
        return PI
    if y.lo > 0:
        return PI/2-atan(x/y)
    if y.hi < 0:
        return -PI/2-atan(x/y)
    if x.lo > 0:
        return atan(y/x)
    raise ValueError("Argument rectangle crosses zero or negative-real cut")


def cadd(a,b): return (a[0]+b[0],a[1]+b[1])
def csub(a,b): return (a[0]-b[0],a[1]-b[1])
def cmul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def conj(a): return (a[0],-a[1])
def cscale(a,b): return (a[0]*b,a[1]*b)
def abs2(a): return a[0].square()+a[1].square()
def cabs(a): return abs2(a).sqrt()
def norm2(z): return sum((abs2(a) for a in z),I(0))
def norm(z): return norm2(z).sqrt()
def cross(x,y): return [x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
def chiral(z): return cross([a[0] for a in z],[a[1] for a in z])
def realnorm(v): return sum((x.square() for x in v),I(0)).sqrt()
def cvec(rows): return [(I(a),I(b)) for a,b in rows]
def inflated(z,r): return [(a.inflate(r),b.inflate(r)) for a,b in z]


def polynomial(z,p):
    eps,g,lam,*k=p
    total=(sum((v[0] for v in z),I(0)),sum((v[1] for v in z),I(0)))
    return [cadd(cscale(z[j],1-3*g+eps*(k[j]-abs2(z[j]))),cscale(total,g)) for j in range(3)]


def sync(v,lam):
    lam=I(lam)
    if lam.lo == lam.hi == 0:
        return list(v),[I(0)]*3,None  # exact source bypass, no phase extraction
    magnitudes=[cabs(a) for a in v]
    exactzeros=[x.lo == x.hi == y.lo == y.hi == 0 for x,y in v]
    if any(a.lo <= 0 and not zero for a,zero in zip(magnitudes,exactzeros)):
        raise ValueError("Nonzero domain not certified before synchronization")
    phases=[arg(a) for a in v]
    delta=[lam*sum((sin(3*(phases[m]-phases[j])) for m in range(3) if m!=j),I(0)) for j in range(3)]
    return [cmul(v[j],(cos(delta[j]),sin(delta[j]))) for j in range(3)],delta,phases


def initial():
    s2,s3=I(2).sqrt(),I(3).sqrt()
    a=(1-s2/2)/2
    h=(s2-1)/2
    r=s3/6
    P=[s3*a/6,-a/2-r/3,(2*h+I("0.5"))/3]
    c=cos(I(".732"))
    star=[2*(P[j]-(I(".4635")*c if j!=1 else 0)) for j in range(3)]
    b=(star[0].square()+star[1].square()).sqrt()
    L=realnorm(star)
    rad=81-4*L.square()
    X=((9+rad.sqrt())/2).sqrt()
    Y=((9-rad.sqrt())/2).sqrt()
    pb=[-star[1]/b,star[0]/b,I(0)]
    qb=[q/L for q in cross(star,pb)]
    z=[(X*pb[j],Y*qb[j]) for j in range(3)]
    alternate=[(-X*star[1]/b,-star[2]*star[0]/(X*b)),
               (X*star[0]/b,-star[2]*star[1]/(X*b)),(I(0),b/X)]
    return z,dict(a=a,h=h,r=r,P=P,c=c,star=star,b=b,L=L,X=X,Y=Y,radicand=rad,p=pb,q=qb,alternate=alternate)


def observe(z,n,geo,pre=None):
    assert 0 <= n <= 4
    kap=norm(pre if pre is not None else z)
    K=I(".618")*kap/(1+kap)
    E=exp(I("-.0577"))
    c,s=geo["c"],sin(I(".732"))
    f=[c,s,-c,-s,c][n]
    rt=I(3).sqrt()/2
    direction=[(I(1),I(0),I(1)),(rt,I(".5"),I(1)),
               (I(".5"),rt,I(1)),(I(0),I(1),I(1)),(I("-.5"),rt,I(1))][n]
    C=chiral(z)
    vector=[K*(E**n)*f*direction[j]+C[j]/2 for j in range(3)]
    return vector,dict(kappa=kap,K=K,E=E,f=f,d=direction,C=C,amplitude=K*(E**n)*f)
