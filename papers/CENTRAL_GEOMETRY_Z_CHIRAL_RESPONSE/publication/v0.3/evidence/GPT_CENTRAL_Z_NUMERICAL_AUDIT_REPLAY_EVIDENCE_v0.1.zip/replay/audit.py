"""Independent, finite-horizon audit; never imports project scientific code."""
import csv
import hashlib
import json
import sys
from pathlib import Path
from fractions import Fraction
from math import factorial
from rigorous import *

ROOT=Path(__file__).resolve().parent
RESULTS=[]
MANIFEST=json.loads((ROOT/"INPUT_MANIFEST.json").read_text(encoding="utf-8-sig"))
SOURCES={x["key"]:x for x in MANIFEST["inputs"] if "key" in x}
PARAM=[I(x) for x in (".1",".2",".17","2","3","4")]
DELTA=Fraction(1,10**8)
PBOX=[x.inflate(DELTA) for x in PARAM]
CENTERS=[cvec(row) for row in [
 [("1.461707","-.0233543"),("-2.609395","-.0130824"),("0",".2318499")],
 [(".322706",".095167"),("-.259081",".111445"),("-.244759",".206520")],
 [(".188739",".085078"),("-.223602",".148232"),("-.284600",".179065")],
 [(".072196",".121963"),("-.237006",".161219"),("-.305291",".199972")],
 [("-.102612",".144250"),("-.223813",".244521"),("-.284466",".308622")]]]
WC=[None]+[cvec(row) for row in [
 [(".3351004",".0300612"),("-.2793475",".0388329"),("-.2295376",".2233163")],
 [(".153744",".138649"),("-.215523",".159751"),("-.229524",".245724")],
 [(".048542",".133157"),("-.218805",".185171"),("-.288355",".223702")],
 [("-.050848",".169564"),("-.257977",".208159"),("-.334187",".253945")]]]
EN=[I(x) for x in (".000006",".000060",".000220",".001050",".003900")]
QN=[I(0)]+[I(x) for x in (".0000011",".0000033",".0000151",".0000557")]
DN=[I(0)]+[I(x) for x in (".00000025",".0000016",".0000047",".0000214")]
LIPS=[0,I(4),I(2),I("3.2"),I("2.6")]
RADII=[None,I(".000013"),I(".00009"),I(".00032"),I(".00151")]
MAGS=[None,[I(".28",".34")]*3,
      [I(".206",".209"),I(".267",".270"),I(".334",".338")],
      [I(".140",".144"),I(".284",".289"),I(".362",".369")],
      [I(".174",".181"),I(".328",".335"),I(".415",".424")]]
COSDOM=[None,[I(-1,1)]*3,[I(".45",".65"),I("-.10",".10"),I(".80",".90")],
        [I("-.91","-.82"),I("-.85","-.73"),I(".97","1")],
        [I("-.29","-.16"),I("-.39","-.23"),I(".98","1")]]
PAIRS=[(0,1),(0,2),(1,2)]
BOXDOMAIN="whole original closed 12-coordinate radius-1e-8 box; configuration fixed across all four updates"


def encode(x):
    if isinstance(x,I): return x.data()
    if isinstance(x,Fraction): return {"numerator":str(x.numerator),"denominator":str(x.denominator)}
    if isinstance(x,dict): return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [encode(v) for v in x]
    return x


def check(cid,value,lo=None,hi=None,*,source="R6",locator="",label="app:certificate",
          domain="exact rational comparison input",deps=(),method="outward rational interval evaluation",
          status=None,note="",strict=True):
    value=I(value)
    lower_ok=lo is None or (value.lo > Fraction(lo)*SCALE if strict else value.lo >= Fraction(lo)*SCALE)
    upper_ok=hi is None or (value.hi < Fraction(hi)*SCALE if strict else value.hi <= Fraction(hi)*SCALE)
    disjoint=(lo is not None and value.hi < Fraction(lo)*SCALE) or (hi is not None and value.lo > Fraction(hi)*SCALE)
    if status is not None and status.startswith("VERIFIED"):
        assert lower_ok and upper_ok, ("Invalid verified-status override",cid)
    exact=value.lo==value.hi and method=="integer rational arithmetic"
    stat=status or (("VERIFIED_EXACT" if exact else "VERIFIED_RIGOROUS") if lower_ok and upper_ok else "FAIL" if disjoint and domain.startswith("exact") else "UNRESOLVED")
    record=dict(id=cid,source_key=source,source_sha256=SOURCES[source]["sha256"],source_locator=locator,
                manuscript_label=label,hypothesis_domain=domain,claimed_bound={"lower":lo,"upper":hi,"strict":strict},
                obtained=value,status=stat,method=method,dependencies=list(deps),note=note)
    margins=[]
    if lo is not None: margins.append(value.lower()-Fraction(lo))
    if hi is not None: margins.append(Fraction(hi)-value.upper())
    record["certified_margin"]=min(margins) if margins else None
    RESULTS.append(record)
    if stat in ("FAIL","UNRESOLVED"): print(stat,cid,value.display(),lo,hi,flush=True)
    return stat


def identity(cid,a,b,**kw):
    # Enclosing zero corroborates equality, but symbolic proof is separately
    # required. Used as arithmetic consistency self-check, not equality proof.
    d=I(a)-I(b)
    assert d.lo <= 0 <= d.hi, (cid,d)
    return d


def save(extra):
    doc={"scope":"ideal real/complex mathematics; n=0..4 only; original fixed-per-input configuration",
         "backend":{"arithmetic":"integer fixed-grid outward rational intervals","decimal_grid_digits":DIGITS,
                    "pi":PI,"not_formal_verification":True},
         "checks":RESULTS,**extra}
    (ROOT/"AUDIT_RESULTS.json").write_text(json.dumps(encode(doc),indent=2),encoding="utf-8")


def starting_and_direct():
    z,g=initial()
    check("A.initial.radicand",g["radicand"],"0",source="R2",locator="Section 7 equations 22-26",domain="exact fan-contact construction")
    for key,lo,hi in [("b",".6934413",".6934422"),("X","2.9909076","2.9909079")]:
        check("A.initial."+key,g[key],lo,hi,locator="3.1",domain="exact fan-contact construction")
    coords=[("1.461705","1.461710"),("-2.609399","-2.609390"),("0","0"),
            ("-.0233545","-.0233541"),("-.0130826","-.0130822"),(".2318496",".2318503")]
    for j,v in enumerate([v[0] for v in z]+[v[1] for v in z]):
        check(f"A.initial.coordinate{j}",v,*coords[j],locator="3.1",strict=(j!=2))
    for j in range(3):
        for k in range(2): identity("initial alternate",z[j][k],g["alternate"][j][k])
        check(f"A.initial.center_distance{j}",cabs(csub(z[j],CENTERS[0][j])),None,".000006",locator="(8)")
        identity("initial chirality",chiral(z)[j],g["star"][j])
    identity("norm three",norm2(z),9)
    identity("basis p",sum((v.square() for v in g["p"]),I(0)),1)
    identity("basis q",sum((v.square() for v in g["q"]),I(0)),1)
    identity("basis orthogonal",sum((a*b for a,b in zip(g["p"],g["q"])),I(0)),0)
    nominal=[z]; boxes=[inflated(z,DELTA)]
    pres=[None]; nompres=[None]
    for n in range(1,5):
        vn=polynomial(nominal[-1],PARAM)
        zn,dn,pn=sync(vn,PARAM[2])
        v=polynomial(boxes[-1],PBOX)
        zz,d,p=sync(v,PBOX[2])
        nominal.append(zn);boxes.append(zz);pres.append(v);nompres.append(vn)
        width=max(x.upper()-x.lower() for c in zz for x in c)
        print("direct stage",n,"max coordinate width enclosed by",I(width).display(),flush=True)
    return nominal,boxes,nompres,pres,g


def chain(data):
    nominal,boxes,nompres,pres,g=data
    quotient=[
      [(".089706",".089711"),(".139012",".139016"),(".013736",".013741")],
      [(".051620",".051628"),(".148613",".148624"),(".034083",".034092")],
      [(".36453",".36457"),(".08325",".08327"),(".12625",".12628")],
      [(".29986",".29989"),(".10686",".10689"),(".13642",".13646")]]
    increments=[
      [(".19729",".19733"),("-.26812","-.26808"),(".07077",".07082")],
      [("-.31035","-.31030"),(".05243",".05248"),(".25784",".25791")],
      [("-.18495","-.18485"),(".10496",".10504"),(".07987",".07995")],
      [(".32690",".32703"),("-.15071","-.15060"),("-.17636","-.17625")]]
    rho=[I(x) for x in (0,".00002",".00004",".00005",".00005")]
    raw_rhs=[]
    for n in range(1,5):
        w=polynomial(CENTERS[n-1],PARAM)
        out,inc,phi=sync(w,PARAM[2])
        for j,(x,y) in enumerate(w):
            check(f"A.{n}.polynomial_coordinate_residual.{j}.real",(x-WC[n][j][0]).abs(),None,".000002",locator="3.2 pre-sync table")
            check(f"A.{n}.polynomial_coordinate_residual.{j}.imag",(y-WC[n][j][1]).abs(),None,".000002",locator="3.2 pre-sync table")
            check(f"A.{n}.polynomial_complex_residual.{j}",cabs(csub(w[j],WC[n][j])),None,".000003",locator="3.2")
            if n==1:
                t=y/x if j==0 else y/(-x) if j==1 else (-x-y)/(-x+y)
            elif n==2:
                t=(x-y)/(x+y) if j==0 else (-x-y)/(-x+y) if j==1 else (y+x)/(y-x)
            else:
                t=(x/y if n==3 else -x/y) if j==0 else (-x-y)/(-x+y)
            check(f"A.{n}.atan_quotient.{j}",t,*quotient[n-1][j],locator="3.2 quotient table")
            check(f"A.{n}.increment.{j}",inc[j],*increments[n-1][j],locator="3.2 increment table")
            check(f"A.{n}.full_residual.{j}",cabs(csub(out[j],CENTERS[n][j])),None,rho[n].upper(),locator="3.2 rho table")
            check(f"A.{n}.nominal_direct_error.{j}",cabs(csub(nominal[n][j],CENTERS[n][j])),None,EN[n].upper(),domain="exact nominal composition; independent direct interval enclosure",locator="3.4")
            check(f"A.{n}.original_variation.{j}",cabs(csub(boxes[n][j],nominal[n][j])),None,QN[n].upper(),domain=BOXDOMAIN,locator="3.4 Q table",method="direct interval composition; nominal error separately enclosed")
        # Certify polynomial derivative over the entire complex-ball hull,
        # using |center| +/- radius, not just a center Jacobian.
        R=EN[n-1]+(I(2).sqrt()*DELTA if n==1 else QN[n-1])
        mags=[cabs(v).inflate(R.upper()) for v in CENTERS[n-1]]
        eps,gg,ll,*kk=PBOX
        for j,m in enumerate(mags):
            eig1=1-2*gg+eps*(kk[j]-3*m.square())
            eig2=1-2*gg+eps*(kk[j]-m.square())
            own=max(eig1.abs().upper(),eig2.abs().upper())
            check(f"A.{n}.LG.row{j}",I(own)+2*gg.abs(),None,"1.6" if n==1 else "1.41",
                  locator="3.3 polynomial derivative",domain=f"entire complex balls center zhat{n-1}, radius {R.display()}, and original parameter box")
            checks=[(m*(kk[j]-m.square())).abs(),
                    cabs(cadd(cadd(CENTERS[n-1][(j+1)%3],CENTERS[n-1][(j+2)%3]),cscale(CENTERS[n-1][j],-2))).inflate(4*R.upper()),
                    eps.abs()*m]
            bounds=("10","11",".27") if n==1 else ("1.9","1.8",".046")
            for k,val in enumerate(checks):
                check(f"A.{n}.parameter_derivative.{j}.{k}",val,None,bounds[k],locator="3.4 parameter sensitivities",
                      domain="entire stated input balls and original parameter box")
        LG=I("1.6" if n==1 else "1.41")
        raw=LG*R+(I("21.27") if n==1 else I(4))*DELTA+I(".000003")
        raw_rhs.append(raw)
        check(f"A.{n}.raw_domain_radius",raw,None,RADII[n].upper(),locator="3.3-3.4 coverage induction",
              domain=BOXDOMAIN,method="induction from preceding EN, QN and independently checked derivative/residual bounds")
        # Each pre-sync segment lies in one of these balls. The positive
        # radial lower bound is established BEFORE phase derivatives.
        phib=[]
        for j in range(3):
            rm=cabs(WC[n][j]).inflate(RADII[n].upper())
            check(f"A.{n}.domain_magnitude.{j}",rm,MAGS[n][j].lower(),MAGS[n][j].upper(),
                  locator="3.3 magnitude domain",domain=f"whole complex ball about W{n}, radius {RADII[n].display()}")
            assert rm.lo>0
            phib.append(arg(WC[n][j]).inflate((RADII[n]/I(rm.lower())).upper()))
        if n>1:
            for q,(j,k) in enumerate(PAIRS):
                check(f"A.{n}.domain_cosine.{j}{k}",cos(3*(phib[k]-phib[j])),COSDOM[n][q].lower(),COSDOM[n][q].upper(),
                      locator="3.3 cosine domain",domain="whole convex pre-sync balls and all connecting segments",strict=(q!=2))
        mat=[[I(0) for k in range(3)] for j in range(3)]
        for a,(j,k) in zip(COSDOM[n],PAIRS): mat[j][k]=mat[k][j]=a
        for j in range(3):
            own=1-3*I(0,".18")*sum((mat[j][k] for k in range(3) if j!=k),I(0))
            bound=I(max(Fraction(1),own.abs().upper()))+I(".54")*sum((MAGS[n][j]/MAGS[n][k]*mat[j][k].abs() for k in range(3) if j!=k),I(0))
            check(f"A.{n}.sync_derivative.row{j}",bound,None,LIPS[n].upper(),locator="3.3 (9)",
                  domain="entire stated magnitude/cosine product; 0<=lambda<=.18, containing the entire original positive coefficient interval")
        check(f"A.{n}.nominal_recurrence",LIPS[n]*LG*EN[n-1]+rho[n],None,EN[n].upper(),
              locator="3.4 nominal recurrence",domain="exact recurrence substitution",method="exact decimal rationals",status=None)
        draw=(I("1.6")*I(2).sqrt()+I("21.27"))*DELTA if n==1 else I("1.41")*QN[n-1]+4*DELTA
        check(f"A.{n}.parameter_raw_recurrence",draw,None,DN[n].upper(),locator="3.4 (10)",domain=BOXDOMAIN)
        check(f"A.{n}.parameter_post_recurrence",LIPS[n]*DN[n]+2*I(max(x.upper() for x in MAGS[n]))*DELTA,None,QN[n].upper(),
              locator="3.4 (10)",domain=BOXDOMAIN)
    check("A.corrected_R6_arithmetic",raw_rhs[3],".001504831",".001504831",strict=False,locator="R6 3.4; R7 (5)",domain="exact decimal expression",status="VERIFIED_EXACT")
    check("A.historical_R6_overestimate",I(".001504871")-raw_rhs[3],"0",None,locator="R6 3.4",domain="exact decimal subtraction",status="VERIFIED_EXACT")
    for cid,value,bound in [
        ("atan13",I(Fraction(".365")**15/15),".00000002"),
        ("sin13",I(Fraction("1.5")**15/factorial(15)),".000000004"),
        ("cos12",I(Fraction("1.5")**14/factorial(14)),".000000004"),
        ("R8sin7",I(Fraction(".61")**9/factorial(9)),".000000033"),
        ("R8cos8",I(Fraction(".61")**10/factorial(10)),".000000002")]:
        check("A.remainder."+cid,value,None,bound,locator="R6 3.2 / R8 4; Taylor next-term bounds",domain="whole stated residual-argument range",method="exact rational factorial remainder")


def observations(data):
    nominal,boxes,nompres,pres,g=data
    obs=[]; details=[]
    bounds=[
        [None,None,(".3046",".3049")],
        [(".10550",".10603"),(".02344",".023895"),(".16734",".16788")],
        [("-.0665","-.0637"),("-.145","-.1423"),("-.1102","-.1075")],
        [(".0005",".0014"),("-.1400","-.1387"),("-.0939","-.0926")],
        [("-.0675","-.0636"),(".1073",".1111"),(".1333",".1370")]]
    rb=[(".1693",".1760"),(".10550",".1090"),(".155",".160"),(".1387",".1401"),(".1247",".1301")]
    cb=[(".3484",".3530"),(".1970",".2010"),(".1866",".195"),(".1667",".1687"),(".1825",".189")]
    rad=[];center=[];height=[]
    for n in range(5):
        z,dt=observe(boxes[n],n,g,pres[n])
        obs.append(z);details.append(dt)
        for j in range(3):
            if bounds[n][j]:
                check(f"B.observation{n}.coordinate{j}",z[j],*bounds[n][j],source="R4" if n<2 else "R5" if n==2 else "R6",
                      locator="R4 5.1 / R5 4 / R6 4",label="tab:observations; app:finite",domain=BOXDOMAIN)
        radius=(z[0].square()+z[1].square()).sqrt()
        ct=realnorm(z)
        rad.append(radius);center.append(ct);height.append(z[2].abs())
        for kind,v,b in [("axis",radius,rb[n]),("centre",ct,cb[n])]:
            check(f"B.observation{n}.{kind}",v,*b,locator="R4-R6 distance tables",label="tab:observations",domain=BOXDOMAIN)
        if n>0:
            check(f"B.observation{n}.host_radius_clearance",g["r"]-radius,"0",None,locator="Appendix A.2 host membership",domain=BOXDOMAIN,label="app:finite")
            check(f"B.observation{n}.central_slab",g["h"]-z[2].abs(),"0",None,locator="Appendix A.2 fan/notch exclusion",domain=BOXDOMAIN,label="app:finite")
    native,_=observe(boxes[1],0,g,pres[1])
    for j,b in enumerate([(".14847",".14900"),("-.04516","-.04479"),(".19192",".19245")]):
        check(f"B.native_only.coordinate{j}",native[j],*b,source="R4",locator="5.1",label="app:finite",domain=BOXDOMAIN)
    rn=(native[0].square()+native[1].square()).sqrt()
    check("B.native_only.exterior",rn-g["a"],".00197",None,source="R4",locator="5.3 (31)",label="app:finite",domain=BOXDOMAIN)
    eta=(1-obs[1][2]/g["h"])/2
    check("B.first.own_eta",eta,"0",".097",source="R4",locator="5.4",label="eq:firstinradius",domain=BOXDOMAIN)
    lower1=g["a"]*I(3).sqrt()*(1-eta)/2
    lower2=g["a"]*(1-I("1.5")*eta)
    for j,v in enumerate([lower1,lower2]):
        check(f"B.first.section_lower{j}",v,".1144",None,source="R4",locator="5.4 (32)-(34)",label="eq:firstinradius",domain=BOXDOMAIN)
        check(f"B.first.interior_clearance{j}",v-rad[1],".0054",None,source="R4",locator="5.4",label="app:finite",domain=BOXDOMAIN)
    check("B.second.exterior",rad[2]-g["a"],".0085",None,source="R5",locator="5",label="app:finite",domain=BOXDOMAIN)
    for n,b in [(3,(".723",".727")),(4,(".169",".179"))]:
        en=(1-obs[n][2]/g["h"])/2
        check(f"B.{n}.eta",en,*b,locator="5",label="app:finite",domain=BOXDOMAIN)
        if n==3:
            # q(eta)=1-eta+eta^2 increases for eta>1/2.
            outer=g["a"]*I(1-en.lower()+en.lower()**2,1-en.upper()+en.upper()**2).sqrt()
            check("B.third.outer_radius",outer,None,".1313",locator="5.1",label="app:finite",domain=BOXDOMAIN)
            check("B.third.exterior",rad[n]-outer,".0074",None,locator="5.1",label="app:finite",domain=BOXDOMAIN)
        else:
            x,y=obs[n][:2]; k=I(3).sqrt()/2
            wedge1=-k*en*y-(1-I("1.5")*en)*x
            wedge2=x*(I(".5")-en)+k*y
            support=-x/2+k*y; edge=g["a"]*k*(1-en)
            for name,v,lo,hi in [("wedge1",wedge1,".029",None),("wedge2",wedge2,".0705",None),
                                  ("support",support,".1247218",None),("edge",edge,None,".1055"),
                                  ("residual",support-edge,".0192",None)]:
                check("B.fourth."+name,v,lo,hi,locator="5.2 finite D3S4 edge",label="app:finite",domain=BOXDOMAIN,
                      note="Two positive determinants select the finite ray sector; line residual is not a 3D minimum-distance claim.")
    # Same-input comparisons: disjoint uniform intervals imply these without
    # replacing the initial observation by its central fan witness.
    for kind,series in [("axis",rad),("centre",center),("throat",height)]:
        for n in range(1,5):
            check(f"B.{kind}.initial_minus_{n}",series[0]-series[n],"0",None,locator="R4-R6 own-initial comparisons",domain=BOXDOMAIN)
        for a,b,sign in [(1,2,1 if kind=="axis" else -1),(2,3,-1),(3,4,-1 if kind=="axis" else 1),
                         (1,4,1 if kind=="axis" else -1)]:
            check(f"B.{kind}.comparison_{a}_{b}",(series[b]-series[a])*sign,"0",None,locator="R5-R6 distance comparisons",domain=BOXDOMAIN)
    check("B.native_only.own_initial_height",obs[0][2]-native[2],".11215",None,source="R4",locator="5.5 (35)",domain=BOXDOMAIN)
    check("B.scheduled.own_initial_height",obs[0][2]-obs[1][2],".13672",None,source="R4",locator="5.5 (35)",domain=BOXDOMAIN)
    check("B.native_only_above_scheduled",native[2]-obs[1][2],".02404",None,source="R4",locator="5.2 (28)",domain=BOXDOMAIN)
    # Nominal exact fan contact: actual triangle and its Gram barycentrics.
    a,h,r=g["a"],g["h"],g["r"]
    verts=[[I(0),-r,I(".5")],[I(0),-a,h],[I(3).sqrt()*a/2,-a/2,h]]
    p=g["P"]; b=[verts[1][j]-verts[0][j] for j in range(3)]; c=[verts[2][j]-verts[0][j] for j in range(3)]
    v=[p[j]-verts[0][j] for j in range(3)]
    dot=lambda x,y:sum((a*b for a,b in zip(x,y)),I(0))
    gram=dot(b,b)*dot(c,c)-dot(b,c).square()
    check("B.fan.Gram_positive",gram,"0",None,source="R2",locator="7 (22)",domain="exact initial fan-centroid witness")
    bary=[(dot(v,b)*dot(c,c)-dot(v,c)*dot(b,c))/gram,(dot(v,c)*dot(b,b)-dot(v,b)*dot(b,c))/gram]
    bary.append(1-bary[0]-bary[1])
    for j,t in enumerate(bary):
        identity("fan barycentric third",t,I(Fraction(1,3)))
        check(f"B.fan.barycentric{j}",t,"0","1",source="R2",locator="7 (22)",domain="exact nominal initial triangle; perturbations need not contact")
    nominal_obs,_=observe(nominal[0],0,g)
    for j in range(3): identity("initial observation centroid",nominal_obs[j],g["P"][j])
    return obs,details


def mechanism(data,obsdata):
    nominal,boxes,nompres,pres,g=data
    obs,read=obsdata
    onsitebounds=[
      [(".04269",".04274"),(".04642",".04650"),(".07989",".08000")],
      [(".01673",".01683"),(".04206",".04224"),(".08775",".08804")],
      [(".00782",".00809"),(".04756",".04834"),(".10236",".10366")]]
    pairbounds=[
      [(".33859",".33889"),(".33427",".33457"),(".00922",".00927")],
      [(".17363",".17440"),(".23245",".23332"),(".00460",".00474")],
      [(".09581",".09849"),(".14693",".15024"),(".00582",".00651")]]
    totals=[
      [(".16900",".16924"),("-.27310","-.27283"),(".03635",".03653"),("-.06775","-.06706")],
      [(".14654",".14711"),("-.16500","-.16426"),(".02510",".02562"),(".00664",".00847")],
      [(".15774",".16009"),("-.10210","-.09942"),(".02250",".02509"),(".07814",".08576")]]
    remparts=[
      [(".0263",".0265"),(".08184",".08194"),("-.07209","-.07161")],
      [(".0247",".0251"),(".04928",".04950"),("-.04950","-.04836")],
      [(".0273",".0281"),(".02982",".03064"),("-.03624","-.03203")]]
    comparisonI=[[".113195920325",".079542952586",".102557478481"],
                 [".042860676205",".071970580228",".113061434225"],
                 [".020087235785",".082163409997",".133191395465"]]
    terr=[[".000017",".000026",".000034"],[".000038",".000073",".000122"],[".000123",".000370",".000630"]]
    ckw=dict(source="R7",locator="3.1-3.4 (6)-(14)",label="tab:budget; app:mechanism",domain=BOXDOMAIN)
    budget=[]
    for n in range(1,4):
        z=boxes[n]; eps,gg,ll,*kk=PBOX
        intens=[abs2(v) for v in z]
        onsite=[2*eps*v*(k-v) for v,k in zip(intens,kk)]
        pairs=[abs2(csub(z[j],z[k])) for j,k in PAIRS]
        H=[cscale(z[j],kk[j]-intens[j]) for j in range(3)]
        L=[cadd(cadd(z[(j+1)%3],z[(j+2)%3]),cscale(z[j],-2)) for j in range(3)]
        inc=[cadd(cscale(H[j],eps),cscale(L[j],gg)) for j in range(3)]
        O=sum(onsite,I(0)); G=-2*gg*sum(pairs,I(0)); R=norm2(inc)
        A=eps.square()*norm2(H); B=gg.square()*norm2(L)
        mixed=2*eps*gg*sum((cmul(conj(H[j]),L[j])[0] for j in range(3)),I(0))
        identity("budget",O+G+R,norm2(pres[n+1])-norm2(z))
        identity("mixed",mixed,R-A-B)
        budget.append([O,G,R,O+G+R])
        for name,val,bnd in zip(["onsite","coupling","remainder","total"],budget[-1],totals[n-1]):
            check(f"C.norm.{n}.{name}",val,*bnd,**ckw)
        for j in range(3):
            check(f"C.norm.{n}.channel{j}",onsite[j],*onsitebounds[n-1][j],**ckw)
            check(f"C.norm.{n}.pair{PAIRS[j]}",pairs[j],*pairbounds[n-1][j],**ckw)
            check(f"C.norm.{n}.remainder_part{j}",[A,B,mixed][j],*remparts[n-1][j],**ckw)
            check(f"C.comparison.intensity{n}.{j}",abs2(CENTERS[n][j]),comparisonI[n-1][j],comparisonI[n-1][j],strict=False,
                  source="R7",locator="3.3 exact comparison table",domain="exact rational comparison vector",method="integer rational arithmetic")
            # Entire inherited error-ball estimate, independently substituted.
            t=EN[n]+QN[n]; M=I(MAGS[n][j].upper())
            allowance=2*PBOX[0]*PBOX[3+j]*2*M*t+I(".00000002")
            check(f"C.proof.onsite_error{n}.{j}",allowance,None,terr[n-1][j],source="R7",locator="3.3 (10)",domain="whole inherited error ball and parameter product")
        t=EN[n]+QN[n]; br=I("2.41")*t+4*DELTA+I(".000003")
        chat=[csub(WC[n+1][j],CENTERS[n][j]) for j in range(3)]
        claimedrem=[".036438669609",".025360851774",".023796891123"][n-1]
        check(f"C.comparison.remainder{n}",norm2(chat),claimedrem,claimedrem,strict=False,source="R7",locator="3.3",domain="exact rational comparison increment")
        lim=[".284",".232",".246"][n-1]
        check(f"C.proof.increment_moduli{n}",sum((cabs(v) for v in chat),I(0)),None,lim,source="R7",locator="3.3 (12)-(13)",domain="exact rational comparison increment")
        check(f"C.proof.remainder_error{n}",2*br*I(lim)+3*br.square(),None,[".000086",".000252",".001285"][n-1],source="R7",locator="3.3 (13)",domain="whole inherited increment-error product")
    for n,bs in enumerate([("-.10410","-.10359"),("-.01846","-.01715"),(".05564",".06067")]):
        check(f"C.norm.linear_subtotal{n+1}",budget[n][0]+budget[n][1],*bs,**ckw)
    for name,val,lo,hi in [
      ("coupling_1_2",budget[1][1]-budget[0][1],".10783",".10884"),
      ("coupling_2_3",budget[2][1]-budget[1][1],".06216",".06558"),
      ("onsite_1_2",budget[0][0]-budget[1][0],".02189",".02270"),
      ("onsite_2_3",budget[2][0]-budget[1][0],".01063",".01355"),
      ("remainder_1_2",budget[0][2]-budget[1][2],".01073",".01143"),
      ("remainder_2_3",budget[2][2]-budget[1][2],"-.00312","-.00001")]:
        check("C.norm.difference."+name,val,lo,hi,**ckw)
    objects=[boxes[2],pres[3],boxes[3],pres[4],boxes[4]]
    names=["O2","V3","O3","V4","O4"]
    componentbounds=[
     [(".00201",".00229"),("-.05814","-.05788"),(".04689",".04712")],
     [(".00423",".00466"),("-.04942","-.04909"),(".03798",".03827")],
     [(".00112",".00253"),("-.05222","-.05112"),(".04008",".04101")],
     [(".00290",".00520"),("-.04467","-.04283"),(".03237",".03394")],
     [(".00024",".00080"),("-.01177","-.00697"),(".00515",".00924")]]
    magbounds=[(".0745",".0749"),(".0622",".0627"),(".0649",".0665"),(".0537",".0564"),(".0086",".0150")]
    fracbounds=[(".627",".632"),(".607",".614"),(".608",".626"),(".584",".621"),(".592",".620")]
    passive=[(".652",".659"),(".527",".534"),(".550",".567"),(".335",".359"),(".053",".096")]
    cs=[]; mags=[]; fracs=[]
    for idx,(name,z) in enumerate(zip(names,objects)):
        C=chiral(z); mag=realnorm(C);cs.append(C);mags.append(mag);fracs.append(C[2]/mag)
        for j in range(3):
            check(f"C.chiral.{name}.component{j}",C[j],*componentbounds[idx][j],source="R7",locator="4.1 component table",label="tab:chiral; app:mechanism",domain=BOXDOMAIN)
        for kind,value,bs in [("magnitude",mag,magbounds[idx]),("fraction",C[2]/mag,fracbounds[idx]),("passive",2*mag/norm2(z),passive[idx])]:
            check(f"C.chiral.{name}.{kind}",value,*bs,source="R7",locator="6.1-6.3 tables",label="tab:chiral",domain=BOXDOMAIN,
                  note="Existing interval checked; no previously unresolved direction comparison is added.")
        x=[v[0] for v in z];y=[v[1] for v in z]
        gram=sum((a.square() for a in x),I(0))*sum((a.square() for a in y),I(0))-sum((a*b for a,b in zip(x,y)),I(0)).square()
        identity("Gram",gram,mag.square())
    changes=[[(0,1),("-.00914","-.00862"),("-.0127","-.0118")],
             [(1,2),(".00218",".00268"),(".0022",".0043")],
             [(0,2),("-.00696","-.00594"),("-.0100","-.0080")],
             [(2,3),("-.00864","-.00614"),("-.0128","-.0085")],
             [(3,4),("-.02800","-.02400"),("-.0478","-.0387")],
             [(2,4),("-.03586","-.03084"),("-.0579","-.0499")]]
    for (a,b),cb,mb in changes:
        for kind,val,lim in [("component3",cs[b][2]-cs[a][2],cb),("magnitude",mags[b]-mags[a],mb)]:
            check(f"C.changes.{names[a]}_{names[b]}.{kind}",val,*lim,source="R7",locator="4.2 / 6.1 difference tables",label="sec:mechanism",domain=BOXDOMAIN)
    for idx,b in enumerate([(".042",".049"),(".110",".123"),(".027",".064"),(".085",".161")]):
        check(f"C.direction.{names[idx]}.ratio",cs[idx][0]/cs[idx][2],*b,source="R7",locator="6.2 (31)",domain=BOXDOMAIN)
    check("C.direction.net_2_3_vertical_fraction",fracs[0]-fracs[2],"0",None,source="R7",locator="6.2",domain=BOXDOMAIN)
    check("C.direction.fourth_vs_second_fraction",fracs[0]-fracs[4],"0",None,source="R7",locator="6.2",domain=BOXDOMAIN)
    check("C.direction.fourth_sync_ratio_factor",(cs[4][0]/cs[4][2])/(cs[3][0]/cs[3][2]),None,".935",source="R7",locator="6.2 (32)",domain=BOXDOMAIN)
    # Cofactor evaluation uses the state-dependent real multiplier, not Jacobian.
    for n in (3,4):
        z=boxes[n-1]; eps,gg,ll,*kk=PBOX
        B=[[gg if j!=k else 1-2*gg+eps*(kk[j]-abs2(z[j])) for k in range(3)] for j in range(3)]
        cof=[]
        for j in range(3):
            row=[]
            for k in range(3):
                rr=[a for a in range(3) if a!=j];cc=[a for a in range(3) if a!=k]
                row.append((-1)**(j+k)*(B[rr[0]][cc[0]]*B[rr[1]][cc[1]]-B[rr[0]][cc[1]]*B[rr[1]][cc[0]]))
            cof.append(row)
        cofc=[sum((cof[j][k]*chiral(z)[k] for k in range(3)),I(0)) for j in range(3)]
        for j in range(3):
            identity("cofactor/direct",cofc[j],chiral(pres[n])[j])
            check(f"C.cofactor.stage{n}.{j}",cofc[j],*componentbounds[1 if n==3 else 3][j],source="R7",locator="4 (15)",domain=BOXDOMAIN)
        vv,dd,pp=sync(pres[n],PBOX[2])
        pbounds=([(".10430",".10473"),(".01562",".01596"),(".01389",".01418")] if n==3 else
                 [(".13792",".14023"),(".05913",".06097"),(".04765",".04922")])
        dbounds=([("-.031","-.019"),("-.272","-.258"),(".283",".297")] if n==3 else
                 [("-.048","-.003"),(".479",".528"),("-.503","-.452")])
        for q,(j,k) in enumerate([(1,2),(2,0),(0,1)]):
            pr=cmul(conj(pres[n][j]),pres[n][k]); d=dd[k]-dd[j]
            check(f"C.pair.stage{n}.{j}{k}.real",pr[0],*pbounds[q],source="R7",locator="5.1 (20)-(21)",domain=BOXDOMAIN)
            check(f"C.pair.stage{n}.{j}{k}.increment",d,*dbounds[q],source="R7",locator="5.1 table",domain=BOXDOMAIN)
            bypair=pr[1]*cos(d)+pr[0]*sin(d)
            identity("pair/direct chirality",bypair,chiral(boxes[n])[q])
            if q==2:
                limits=([("-.00169","-.00148"),(".00387",".00416")] if n==3 else
                        [("-.00421","-.00323"),("-.02378","-.02077")])
                for k2,val in enumerate([pr[1]*(cos(d)-1),pr[0]*sin(d)]):
                    check(f"C.pair.stage{n}.component3_term{k2}",val,*limits[k2],source="R7",locator="5.2 (22)-(23)",domain=BOXDOMAIN)
    # Preserve prescribed attribution order and cancel the shared V term.
    for n in (2,3):
        preC=chiral(pres[n+1]); oldC=read[n]["C"]; newC=read[n+1]["C"]
        oldK,newK=read[n]["K"],read[n+1]["K"]; E=read[n]["E"]; fn=read[n]["f"]
        nk=(E**n)*fn*(newK-oldK)
        pc=(preC[2]-oldC[2])/2;sc=(newC[2]-preC[2])/2
        subtotal=nk+(newC[2]-oldC[2])/2
        env=newK*(E**n)*(E-1)*fn
        clock=newK*(E**(n+1))*(read[n+1]["f"]-fn)
        bounds=([("-.00201","-.00098"),("-.00457","-.00431"),(".00109",".00134"),("-.00549","-.00395"),(".00747",".00754"),(".01277",".01287")] if n==2 else
                [("-.01234","-.01104"),("-.00432","-.00307"),("-.01400","-.01200"),("-.03027","-.02646"),(".00697",".00707"),(".2485",".2509")])
        for name,val,bnd in zip(["native_K","polynomial_chiral","sync_chiral","native_subtotal","envelope","clock"],[nk,pc,sc,subtotal,env,clock],bounds):
            check(f"C.attribution.{n}_{n+1}.{name}",val,*bnd,source="R7",locator="7 (37) attribution table",label="eq:attribution; sec:attribution",domain=BOXDOMAIN)
        identity("attribution telescoping",subtotal+env+clock,obs[n+1][2]-obs[n][2])


def phase_metrics(u,v,lam):
    mean=u+v/2;t=3*v/2
    # sin(t)/v = 3/2 sinc(t). Sinc is decreasing on these positive
    # t<1 domains; endpoint evaluation avoids an artificial quotient width.
    assert t.lo>0 and t.hi<SCALE
    sinc=I.raw((sin(I(t.upper()))/I(t.upper())).lo,(sin(I(t.lower()))/I(t.lower())).hi)
    b=1-3*lam*sinc*(cos(3*mean)+2*cos(t))
    vp=b*v
    shift=-3*lam*sin(3*mean)*cos(t)
    mp=mean+shift;up=mp-vp/2
    a12=sin(up+u)*sin(up-u)
    a13=sin(up+vp+u+v)*sin(up+vp-u-v)
    a23=sin((b+1)*v)*sin((b-1)*v)
    return dict(mean=mean,t=t,sinmean=sin(3*mean),cosmean=cos(3*mean),cost=cos(t),
                sin_over_v=I("1.5")*sinc,b=b,vp=vp,shift=shift,mp=mp,up=up,uvp=up+vp,
                a12=a12,a13=a13,a23=a23)


def phase_theorems(data):
    nominal,boxes,nompres,pres,g=data
    params=[(3,I("1.214","1.223"),I(".0404",".0447"),MAGS[3]),
            (4,I(".587",".614"),I(".020",".038"),[I(".174",".181"),I(".328",".335"),I(".415",".424")])]
    full=[]
    for stage,u,v,amps in params:
        # Closed rational partitions, including shared boundaries. These are
        # interval proofs over cells, never point samples or new trajectories.
        N=8; hulls={}
        for i in range(N):
            uu=I(u.lower()+(u.upper()-u.lower())*i/N,u.lower()+(u.upper()-u.lower())*(i+1)/N)
            for j in range(N):
                vv=I(v.lower()+(v.upper()-v.lower())*j/N,v.lower()+(v.upper()-v.lower())*(j+1)/N)
                m=phase_metrics(uu,vv,PBOX[2])
                m["D"]=(amps[0]*amps[1]).square()*m["a12"]+(amps[0]*amps[2]).square()*m["a13"]+(amps[1]*amps[2]).square()*m["a23"]
                for k,x in m.items(): hulls[k]=hulls[k].hull(x) if k in hulls else x
        domain=f"entire closed S{stage} x A{stage} x Lambda; 8x8 closed rational phase-cell cover; amplitudes and lambda unsplit"
        full.append(hulls)
        bounds=({"sinmean":("-.561","-.531"),"cosmean":("-.847","-.828"),"cost":(".9977","1"),
                 "sin_over_v":("1.4988","1.5"),"shift":(".27018",".28612"),"mp":("1.5043","1.5315"),
                 "b":(".402",".415"),"vp":(".0162",".0186"),"up":("1.495","1.524"),"uvp":("1.512","1.541"),
                 "a12":(".10",None),"a13":(".08",None),"a23":("-.002","-.0012"),"D":(".00034",None)} if stage==3 else
                {"sinmean":(".946",".977"),"cosmean":("-.323","-.218"),"cost":(".9983755","1"),
                 "sin_over_v":("1.49918775","1.5"),"mp":(".0987",".1514"),"b":(".091",".147"),
                 "vp":(".00182",".005586"),"up":(".095",".152"),"uvp":(".099",".155"),
                 "a12":(None,"-.28"),"a13":(None,"-.30"),"a23":(None,"-.00039"),"D":(None,"-.00248")})
        for k,lim in bounds.items():
            check(f"D.domain{stage}.{k}",hulls[k],*lim,source="R8",locator="4.2 (22)-(30)" if stage==3 else "4.3 (32)-(36)",
                  label="thm:gain" if stage==3 else "thm:loss",domain=domain,
                  method="closed-cell outward rational interval cover; monotonic sinc and explicit Taylor remainders")
        # Actual-image inclusion is checked separately, with lifted angles.
        ph=[arg(z) for z in pres[stage]];actualu=ph[1]-ph[0];actualv=ph[2]-ph[1]
        for key,x,lim in [("u",actualu,(u.lower(),u.upper())),("v",actualv,(v.lower(),v.upper()))]:
            check(f"D.actual{stage}.{key}",x,*lim,source="R8",locator="6 (actual-image inclusion)",label="eq:actualphase; app:inclusion",domain=BOXDOMAIN)
        for j,z in enumerate(pres[stage]):
            check(f"D.actual{stage}.amplitude{j}",cabs(z),amps[j].lower(),amps[j].upper(),source="R8",locator="6",domain=BOXDOMAIN)
        liftedbounds=([("1.214487","1.221613"),(".040439",".044611")] if stage==3 else
                     [(".58711",".61399"),(".02075",".03755")])
        for j,x in enumerate([actualu,actualv]):
            check(f"D.actual{stage}.tightphase{j}",x,*liftedbounds[j],source="R8",locator="6 (43)",label="eq:actualphase",domain=BOXDOMAIN)
        cp=[arg(z) for z in WC[stage]]
        for j,x in enumerate([cp[1]-cp[0],cp[2]-cp[1]]):
            lim=([("1.2179","1.2182"),(".04245",".04260")] if stage==3 else [(".6004",".6007"),(".0290",".0293")])[j]
            check(f"D.comparison{stage}.phase{j}",x,*lim,source="R8",locator="6",domain="exact rounded pre-sync comparison vector")
        errors=[(".002286",".001127",".000884"),(".00868",".00461",".00364")][stage-3]
        for j in range(3):
            check(f"D.phase_error{stage}.{j}",RADII[stage]/I(MAGS[stage][j].lower()),None,errors[j],source="R8",locator="6 phase-error allowances",domain="whole closed complex balls, nonzero already certified")
    # Exact reported final arithmetic, distinct from the independent margins.
    gain=I(".10")*(I(".140")*I(".284")).square()+I(".08")*(I(".140")*I(".362")).square()-I(".002")*(I(".289")*I(".369")).square()
    loss=I(".28")*(I(".174")*I(".328")).square()+I(".00039")*(I(".328")*I(".415")).square()+I(".30")*(I(".174")*I(".415")).square()
    check("D.report_gain_margin",gain,".000340818146238",".000340818146238",strict=False,source="R8",locator="(30)",domain="exact terminating-decimal expression")
    check("D.report_loss_margin",loss,".002483531096736",".002483531096736",strict=False,source="R8",locator="(36)",domain="exact terminating-decimal expression")
    v=I(".02",".04"); t=3*v/2
    sinc=I.raw((sin(I(t.upper()))/I(t.upper())).lo,(sin(I(t.lower()))/I(t.lower())).hi)
    b=1-3*PBOX[2]*sinc*(-1+2*cos(t));vp=b*v
    check("D.mean_line.contraction",b,".489",".493",source="R8",locator="5.1",label="eq:meanlineexample",domain="v in [.02,.04], lambda in Lambda; zeta=pi/3")
    check("D.mean_line.cosine_sum",cos(vp)+cos(v),"1.9984","2",source="R8",locator="5.1",domain="same full mean-line domain")
    # Exact factorization; sin product preserves vp=b*v correlation.
    pref=2*sin((1+b)*v/2)*sin((1-b)*v/2)
    for ratio,sgn in [(1,-1),(3,1)]:
        normalized=pref*(I(ratio**2)/2-(cos(vp)+cos(v)))
        check(f"D.mean_line.r1_over_rho{ratio}",normalized*sgn,"0",None,source="R8",locator="5.1 (37)",domain="all rho>0, same v and Lambda; response divided by rho^4")
    check("D.overshoot",-(sin(3*PBOX[2]).square()),None,"0",source="R8",locator="5.2 (39)",domain="v=0, zeta=pi/2, lambda in Lambda; response divided by positive r1^2(r2^2+r3^2)")
    return full


def main():
    import verification
    before=verification.verify_inputs(ROOT,MANIFEST)
    selftests=verification.self_checks()
    algebra=verification.symbolic_checks()
    print("arithmetic self-checks",len(selftests),"exact supporting identities",len(algebra),flush=True)
    data=starting_and_direct()
    globals()["DATA"]=data
    (ROOT/"tmp"/"direct_enclosures.json").write_text(json.dumps(encode({"nominal":data[0],"original_box":data[1],"pre":data[3]}),indent=2))
    chain(data)
    ob=observations(data)
    mechanism(data,ob)
    phase_theorems(data)
    import supplement
    supplement.run(sys.modules[__name__],data,ob)
    nominal=verification.nominal_crosscheck(sys.modules[__name__],data)
    (ROOT/"NOMINAL_CROSSCHECK.json").write_text(json.dumps(nominal,indent=2),encoding="utf-8")
    after=verification.verify_inputs(ROOT,MANIFEST)
    metadata=verification.enrich_and_coverage(sys.modules[__name__],selftests,algebra,before,after,nominal)
    metadata["original_box"]={"state_centre":data[0][0],"radius":DELTA,
                             "parameter_order":["epsilon","g","lambda","k1","k2","k3"],
                             "parameter_centre":PARAM,"parameter_closed_intervals":PBOX,
                             "configuration_reused_unchanged":True,"updates":4}
    metadata["whole_box_observations"]=[dict(n=n,coordinates=z,throat_distance=z[2].abs(),
         axis_distance=realnorm(z[:2]),centre_distance=realnorm(z),readout=ob[1][n],
         finite_band_status="not uniformly required at initial input" if n==0 else "INTERIOR" if n==1 else "EXTERIOR",
         host_status="INTERIOR" if n else "reference fan-centroid; perturbed full-host membership not claimed")
         for n,z in enumerate(ob[0])]
    save(metadata)
    print("completed",len(RESULTS),"scalar bound records; 6 numerical proof blocks plus 2 supporting blocks",flush=True)
    print("nominal mpmath cross-check: NUMERICAL_CORROBORATION_ONLY, all values agree",flush=True)
    print("original input identities before/after:",after["all_local_originals_preserved"],flush=True)
    print("VERDICT",metadata["verdict"],flush=True)
    if metadata["verdict"]!="PASS_WITHIN_SCOPED_IDEAL_MATHEMATICS": sys.exit(1)


if __name__=="__main__":
    main()
