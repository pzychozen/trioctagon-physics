# GPT audit-review replay evidence

This records the completed isolated replay and review of Codex's numerical audit. Read the GPT closure receipt first.

The four checker files are unchanged from Codex's delivery. Replay results retain their exact rational endpoints. `REPLAY_COMPARISON.json` records the exact structured-data comparison and explains the host differences. Original Windows paths are unavailable here; copied inputs matched.

For a self-contained scientific replay, use the original `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1_REVIEW_BUNDLE.zip`, SHA-256 `959aff5caf6b617565e1b059035f5254046a39bdd93c875706008978a869e90b`, which includes all hash-bound input texts. This smaller review package does not duplicate those inputs.

No manuscript, source report or repository was edited. No fifth update or new research was performed.
