"""Compare delivered versus portable replay evidence; no project imports."""
from pathlib import Path
from fractions import Fraction
import collections,csv,hashlib,json
root=Path('/mnt/data/gpt_central_z_audit_review'); d=root/'delivered'; r=root/'replay'
assert (r/'logs/gpt-replay-exit.txt').read_text().strip()=='0'
a=json.loads((d/'AUDIT_RESULTS.json').read_text());b=json.loads((r/'AUDIT_RESULTS.json').read_text())
fields=['checks','counts','original_box','whole_box_observations','self_checks','symbolic_identity_checks','nominal_crosscheck_status','backend','scope','verdict']
comp={k:a[k]==b[k] for k in fields}; assert all(comp.values())
nominal=json.loads((d/'NOMINAL_CROSSCHECK.json').read_text())==json.loads((r/'NOMINAL_CROSSCHECK.json').read_text())
direct=json.loads((d/'tmp/direct_enclosures.json').read_text())==json.loads((r/'tmp/direct_enclosures.json').read_text())
read_csv=lambda p:list(csv.DictReader(p.open(encoding='utf-8')))
coverage=read_csv(d/'CLAIM_AUDIT_COVERAGE.csv')==read_csv(r/'CLAIM_AUDIT_COVERAGE.csv')
assert nominal and direct and coverage
ids=[x['id'] for x in b['checks']]; assert len(ids)==len(set(ids))
for row in b['checks']:
    o=row['obtained']; lo=Fraction(int(o['lower_numerator']),int(o['denominator'])); hi=Fraction(int(o['upper_numerator']),int(o['denominator'])); assert lo<=hi
    claim=row['claimed_bound']; gaps=[]
    for side in ('lower','upper'):
        v=claim[side]
        if v is None: continue
        v=Fraction(int(v['numerator']),int(v['denominator'])) if isinstance(v,dict) else Fraction(v)
        gap=lo-v if side=='lower' else v-hi
        assert (gap>0 if claim['strict'] else gap>=0),(row['id'],side,gap)
        gaps.append(gap)
    margin=row['certified_margin']
    if gaps: assert Fraction(int(margin['numerator']),int(margin['denominator']))==min(gaps),row['id']
for row in json.loads((d/'OUTPUT_HASH_MANIFEST.json').read_text())['files']:
    p=d/row['path']; assert len(p.read_bytes())==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
for p in (d/'inputs').rglob('*'):
    if p.is_file(): assert p.read_bytes()==(r/p.relative_to(d)).read_bytes(),str(p)
for f in ['audit.py','rigorous.py','supplement.py','verification.py']:
    assert (d/f).read_bytes()==(r/f).read_bytes()
scopes=collections.Counter(x['audit_scope'] for x in read_csv(r/'CLAIM_AUDIT_COVERAGE.csv'))
record={'verdict':'ACCEPTED_WITHIN_SCOPED_IDEAL_MATHEMATICS','exit_code':0,'structured_field_matches':comp,'records_with_exact_bounds_rechecked':len(ids),'unique_scalar_record_ids':len(set(ids)),'same_nominal_corroboration':nominal,'same_direct_interval_enclosures':direct,'same_coverage_rows':coverage,'coverage_scope_counts':dict(scopes),'only_top_level_result_differences':[k for k in a if a[k]!=b[k]],'delivered_environment':a['environment'],'replay_environment':b['environment'],'replay_proof_blocks':b['proof_blocks'],'delivered_payload_preserved':True,'replay_checker_unchanged':True,'copied_inputs_preserved':True,'windows_original_paths_rechecked':False}
(root/'REPLAY_COMPARISON.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
