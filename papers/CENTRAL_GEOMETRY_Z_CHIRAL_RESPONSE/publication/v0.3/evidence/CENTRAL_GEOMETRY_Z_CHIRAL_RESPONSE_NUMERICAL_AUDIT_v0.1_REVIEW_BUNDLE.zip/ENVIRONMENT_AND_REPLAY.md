# Environment and replay

This package audits only the accepted ideal mathematical example through update four. It does not import any project code. All source files from the project are included only as hash-matched `.txt` reading material.

## Delivered environment

- OS reported by Python: `Windows-10-10.0.26200-SP0`.
- Conda environment: `torment`, activated before every Python execution.
- Interpreter: `C:\Users\Notandi\miniconda3\envs\torment\python.exe`.
- Python: `3.11.15 | packaged by Anaconda, Inc. | (main, Mar 11 2026, 17:12:15) [MSC v.1942 64 bit (AMD64)]`.
- Scientific enclosure backend: local `rigorous.py`, integer/Fraction arithmetic with outward endpoints on the `10^-60` grid.
- Installed supporting packages actually used: `sympy 1.14.0` for exact supporting identities; `mpmath 1.3.0` for a separate 120-digit nominal cross-check.
- No installation, upgrade, environment-file edit, repository import or repository test.

The standard library provides `fractions`, integer arithmetic, `math.isqrt`, `math.factorial`, file I/O, hashing, JSON/CSV and ZIP support. The replay script sets process-local temporary/cache locations within the audit workspace and disables bytecode writes. No persistent environment variable is changed.

## Exact final replay command

From Windows CMD:

```bat
cd /d C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1
replay.cmd
```

`replay.cmd` performs:

```bat
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
cd /d "%~dp0"
set "TEMP=%CD%\tmp"
set "TMP=%CD%\tmp"
set "XDG_CACHE_HOME=%CD%\tmp\cache"
set "PYTHONDONTWRITEBYTECODE=1"
python -B audit.py > logs\audit-console.txt 2>&1
```

It creates the local log/temp directories if necessary, prints the raw log, and returns the checker’s exit code. The actual tool host invoked it as `cmd /d /c replay.cmd`. Development runs likewise used `call ...\conda.bat activate torment && python -B audit.py` from this workspace, with logs retained locally. The review bundle contains the final raw console log.

The checker regenerates:

- `AUDIT_RESULTS.json`: exact rigorous endpoint records, proof blocks, self-checks, symbolic checks, environment, input preservation and original-box observations.
- `NOMINAL_CROSSCHECK.json`: separately labelled non-enclosing nominal values.
- `CLAIM_AUDIT_COVERAGE.csv`: all 37 accepted claim-map entries with audit scope and dependencies.
- `tmp/direct_enclosures.json`: nominal/original-box states and raw images through four updates.

Exit zero requires the scoped checks to pass. A failed assertion or input hash mismatch stops execution with a nonzero exit; insufficient enclosures are recorded as `UNRESOLVED`, not converted to false scientific claims.

## Reading the arithmetic

Every rigorous interval is closed, with exact integer numerator endpoints over the printed denominator. Human-readable displays round outward. Claimed open bounds require strict containment; non-strict rational equalities are identified separately. `certified_margin` is an exact rational minimum gap to a stated finite endpoint. It is a bound margin, not automatically a geometric distance.

The original state is regenerated from radical/basis formulas, not the rounded comparison centres. The same original coefficient intervals are passed at each stage. Interval products enlarge correlated image sets conservatively; they never redefine the input problem. The proof-domain partitions cover the entire S3/S4 rectangles and are unrelated to trajectory sampling.

The report documents the interval rounding rules, Taylor degrees/remainders, pi formula, phase lifts and nonzero safeguards. Constants and expected intervals in the checker are transcribed from hash-bound source texts; the checker independently computes their values rather than treating them as premises.

## Portable replay and preservation

The source copies needed for numerical replay are bundled. Their hashes are checked even if original Windows paths are absent on another host. When original paths are available, every listed original is hashed before and after the calculation. If unavailable on another host, copied-input checks still run, but original-path preservation is explicitly recorded as unavailable for that replay.

The supplied `PRESERVATION.json` is the delivered local before/after record, supplemented by a narrow read-only repository HEAD/status check. A portable scientific replay does not retroactively redo that repository check. It does not require importing or executing the repository.

If Conda is installed elsewhere, only the activation path in a copied `replay.cmd` needs adapting. Preserve the delivered package and its hashes separately before changing a replay copy. No dependency installation is part of these instructions; the recorded existing packages are required.

## Bundle and hashes

The bundle contains the checker, retained source texts, accepted review documents, report, replay instructions, exact results, coverage, preservation record, final raw log and `OUTPUT_HASH_MANIFEST.json`. The manifest lists exact hashes/sizes of payload files, excluding itself and the ZIP to avoid circular hashing.

`package_audit.py` builds the ZIP from those explicitly scoped payloads and verifies every zipped byte stream against its manifest. It writes `BUNDLE_RECEIPT.json` outside the ZIP with the ZIP’s size and SHA-256. Packaging has no scientific evaluator calls.

The exact packaging command is:

```bat
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
python -B package_audit.py
```

No fonts, credentials, binaries, environment dumps, manuscript PDF or completed-publication files are included. The accepted PDF/ZIP identities remain recorded as read-only provenance inputs.
