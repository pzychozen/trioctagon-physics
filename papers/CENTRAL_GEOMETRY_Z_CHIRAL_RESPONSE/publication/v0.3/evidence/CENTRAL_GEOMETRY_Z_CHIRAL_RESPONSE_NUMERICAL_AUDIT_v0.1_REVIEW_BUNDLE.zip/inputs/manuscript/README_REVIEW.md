# Central Geometry, Z Readouts, and Chiral Response

**v0.2 — local research draft for GPT and Hilmir's review**

The paper connects three established results: the finite central constriction and its surrounding space; the conditional spatial comparison of existing Z observations; and the native norm/chirality mechanisms, including finite synchronization gain/loss domains. It incorporates the reversal analysis and retains the exact original input box through update four.

This separately versioned draft addresses review E01-E06; v0.1 and all original reports are preserved. See `REVISION_DISPOSITION.md` for the point-by-point response and the author paragraph for Hilmir to refine before publication. This is a completed local review draft, not publication approval. The principal open review dependency is independent checking of the inherited numerical enclosure chain. Algebraic proof review and document compilation do not replace that check.

## Files

- `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.pdf` — compiled review paper, **28 pages**.
- `manuscript.tex` — editable LaTeX, including its bibliography.
- `figures/zero_plus_retained.png` — the sole used static figure.
- `REVISION_DISPOSITION.md` — point-by-point response to E01-E06 and provisional author wording.
- `CLAIM_SOURCE_MAP.csv` — principal statements, hypotheses, sources and review status.
- `PROOF_REVIEW_AND_EDITORIAL_NOTES.md` — fresh review, corrections and inherited obligations.
- `SOURCE_MANIFEST.json` — exact input paths, sizes and SHA-256 identities.
- `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2_REVIEW_BUNDLE.zip` — compact handoff containing the paper, source, used figure and review records.
- `build/review/PAGE_INSPECTION.md` — page inspection record. Intermediate logs and renders remain under `build/`; the ZIP omits caches, font files and rendered page images.

Original reports, the authoritative checkout and completed publications were preserved. The source revision actually read is `3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34`; the narrow tracked-file status was clean.

## What the review status means

The exact geometric and readout definitions, central algebraic proofs, symmetry signs and phase reduction were reviewed in writing. The phase-domain proofs stand independently of the trajectory table. Their final rational gain/loss margins and the R6 correction were checked manually.

The numerical comparison residuals and their downstream four-update bounds remain inherited from R3–R8. The appendices expose their constants, remainder methods, propagation recurrences and finite-region implications. They were not regenerated or relabeled as independent verification.

Unresolved projection/direction comparisons from R7 remain unresolved. The original fan-contact witness is not replaced by a state that satisfies a reversal condition. No physical flow, crystal motion or feedback law is inferred.

## Exact local document build in Windows CMD

The following commands use the already installed document executable and an existing local cache. They do not run project code. The bundled `build/fontconfig.xml` keeps its cache within this named draft workspace.

```bat
cd /d C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_MANUSCRIPT_v0.2
if not exist build mkdir build
if not exist build\review mkdir build\review
if not exist build\tectonic-cache xcopy "C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_MANUSCRIPT_v0.1\build\tectonic-cache" "build\tectonic-cache\" /E /I /Y
set "TECTONIC_CACHE_DIR=%CD%\build\tectonic-cache"
set "FONTCONFIG_FILE=%CD%\build\fontconfig.xml"
"C:\TORMENT\TRIOCTAGON_new\reconstruction\publication\paper_C\build\tools\tectonic\tectonic.exe" --only-cached --untrusted --keep-logs --keep-intermediates --outdir build manuscript.tex
copy /Y build\manuscript.pdf CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.pdf
"C:\Users\Notandi\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdfinfo.exe" CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.pdf
"C:\Users\Notandi\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe" -r 120 -png CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.pdf build\review\page
```

On another machine, use an existing XeLaTeX-compatible installation with the listed packages and TeX Gyre Pagella fonts, or arrange an appropriate Tectonic cache. The cache and fonts are deliberately not distributed in this ZIP. No software installation is part of this task.

The PDF has no unresolved references, missing glyph warnings or overfull boxes in the final build. Four underfull paragraph warnings remain; the affected pages were visually inspected and the spacing is readable. Compilation is document verification only. The complete local inspection record accompanies the bundle.

No Python was run. No scientific environment, including the user's `torment` environment, was installed into or modified. No automatic follow-up work or publication step is scheduled.
