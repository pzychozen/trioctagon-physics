# Proof review and editorial notes

20 October 2026 · Local manuscript v0.2 · For GPT and Hilmir's review

The manuscript consolidates R0–R9 into one argument with six supporting appendices. The claim/source map supplies statement-level provenance; the source manifest identifies the exact files by SHA-256. These records are a compact private review aid, not a new scientific report series or publication approval.

This separately versioned revision addresses E01–E06 in GPT's 20 October review. The following consolidation review and written-arithmetic record is retained from v0.1 except where explicitly corrected below; it is not a claim that the full audit was repeated for v0.2. The new pass re-read the affected source passages, corrected scope and provenance, restored the R4 supporting inequality, and performed document-only compilation and inspection. See `REVISION_DISPOSITION.md` for the point-by-point record and the short author paragraph awaiting Hilmir's review.

## What was freshly reviewed

Written algebra was used to review the actual shifted-index section, its determinant/area formula and positive throat; the surrounding-area complement; finite notch parameter signs and convexity tests; cone crossing and signed-angle threshold logic; the same-state fan witness; state/observer ordering; native versus envelope/clock attribution; proper/improper actions and full-Z residual signs; the norm expansion and cofactor identity; simultaneous phase reduction; the exact weighted finite-step criterion; and the logical separation between abstract phase domains and inclusion of actual inputs.

The domain proof retains its closed Cartesian-product quantifiers, positive-magnitude restrictions and finite-step effects. The fourth-domain loss sign extends to arbitrary positive amplitudes; its fixed absolute margin does not. The report's nonzero-component restriction on common-phase covariance is retained, while conjugation commutation includes the source's zero convention.

The draft does not infer contact from an infinite plane alone, a later observation from an equal-time identity, inverse-time evolution from forward commutation, or physical flow from section area.

## Written arithmetic and known corrections

The R6 correction is:

```text
1.41(0.001050 + 0.0000151) + 0.00000004 + 0.000003
= 0.001501791 + 0.00000004 + 0.000003
= 0.001504831 < 0.00151.
```

R6's printed `0.001504871` is slightly larger and still conservative. The original report is unchanged.

The final R8 gain-margin expansion was checked in writing:

```text
0.140 × 0.284 = 0.03976
0.140 × 0.362 = 0.05068
0.289 × 0.369 = 0.106641

0.1(0.03976)^2 + 0.08(0.05068)^2 − 0.002(0.106641)^2
= 0.00015808576 + 0.000205476992 − 0.000022744605762
= 0.000340818146238 > 0.00034.
```

The loss-margin expansion was checked in writing:

```text
0.174 × 0.328 = 0.057072
0.328 × 0.415 = 0.13612
0.174 × 0.415 = 0.07221

0.28(0.057072)^2 + 0.00039(0.13612)^2 + 0.30(0.07221)^2
= 0.00091201969152 + 0.000007226175216 + 0.00156428523
= 0.002483531096736 > 0.00248.
```

These are manual decimal expansions, not executed calculations. Intermediate component transcription errors in the working manuscript were corrected before delivery; the original R8 final margins did not change.

The finite notch formula contains `+ ζ_N j_k` between its radial and height terms, restored using R2 equations (7)–(8). The manifest-bound local R9 equation (11) actually omits the plus sign: its consecutive lines end in `)g_k` and begin `\zeta_Nj_k+`. A fresh literal read gives SHA-256 `3a5c402a0ce02421aa1997a4152ea2292d096acd4a03059adb083df04712a554`, exactly the manifest and GPT-review identity. The v0.1 statement that this local R9 already contained the sign was incorrect. There is no different source copy or substitution. The manuscript equation was already correct; v0.2 corrects its provenance account. Neither R2 nor R9 was edited.

Appendix A.2 now reproduces R4 §5.4 equations (32)–(34): the two actual triangle types bound the radial section by `L(eta) = min{a sqrt(3)(1-eta)/2, a(1-3eta/2)}`. At each perturbed first endpoint's own height, the inherited bounds `0 < eta_1 < .097`, `L(eta_1) > .1144` and `R_1 < .109` yield the interior clearance. The projections and star-shaped disk implication are written out. The numerical height/radical substitutions remain inherited; this restoration does not close their independent audit.

A draft overstatement about direction was caught by re-reading R7 §6.2 and removed. The supported conclusions are:

- Each polynomial stage and each synchronization stage changes direction.
- The complete 2 → 3 transition decreases the vertical fraction and therefore changes direction.
- The sign of the third synchronization's vertical-fraction change is unresolved by the supplied bounds.
- The fourth-update stage and net vertical-fraction changes, and the net 3 → 4 direction change, remain unresolved.

Two individually established stage changes do not establish their net change. Overlapping intervals do not imply mixed behavior or constancy.

## Inherited dependencies that remain open for independent audit

The quantitative four-update certificate is retained with explicit provenance, not upgraded to a newly executed or fully independent certificate. Its load-bearing inherited items are:

1. R3 §7.3 and R6 §3.1: exact initial radical/phase enclosures and inclusion in the comparison ball.
2. R6 §§3.2–3.4: polynomial residuals, arctangent quotients, synchronization increments and full-update residual bounds; coverage by the nonzero domains; nominal and original-box recurrences.
3. R4–R6: readout endpoint intervals. The geometric implications are shown in Appendix A, including the directional finite-edge argument at observation four.
4. R7 §§3–6: detailed norm-budget endpoint arithmetic, chiral component/magnitude bounds and correlated direction refinements. Their formulas and error allowances are carried into Appendix C.
5. R8 §6: actual-image phase inclusion, which reuses the preceding residual chain. Repetition of R6's results in R7 and R8 is not independent verification.

The intermediate trigonometric enclosures in the phase-domain theorems are reproduced with the alternating-polynomial remainder method and reviewed for sign, monotonicity and margin use. Every rational endpoint substitution has not been freshly re-expanded. The domain theorem proofs are independent of the trajectory outcome table; their application to the original input box depends on the inherited inclusion chain.

No contradictory source premise was identified. The above are explicit outstanding verification dependencies, not hidden claims of completed machine verification. No original interval, coefficient, state, geometry or schedule was silently changed.

## Editorial and bibliographic decisions

- The three main parts follow geometry → placed observations → native mechanism. R9 is integrated into the first two parts; it is not appended as a separate new programme.
- Bibliography entries use actual local report titles. In particular R7's report title is *Stage-by-Stage Explanation Through Update Four*, and R9's is *Z and the Central Crystal — Reversal and Upper/Lower Correspondence*. These differ slightly from work-order titles.
- R0–R2 are dated 19 October 2026; R3–R9 are dated 20 October 2026. The bibliography gives their shared year, version and unpublished status.
- Paper A's consulted title metadata supplies Hilmir's name but no explicit revision or date. Its exact source bytes are recorded instead of inventing metadata. Paper B v0.1.2, Paper C v1.0.1 and Paper E v0.1.1 are the editions consulted. Paper E's qualified status notice is not expanded into a new acceptance claim.
- Report authorship is not inferred from the manuscript's author. The manuscript follows established attribution practice and does not invent an affiliation, coauthor, DOI, destination journal or new licence.
- One retained atlas figure is used: candidate 00, PLUS, zero member, width-one host. It was visually inspected and copied byte for byte. The caption distinguishes its source parameter labels from observer time and states that no trajectory is depicted.
- The readable paper contains no absolute local source paths. The private manifest and source map carry file provenance. No private handoff, chat excerpt or discussion drawing is in the manuscript or ZIP.
- References are embedded in `manuscript.tex`; no separate `.bib` file is needed.
- E01 replaces the diagonal-flip description with the exact shifted-index connectivity statement. E02 retains simultaneous channel/label covariance and explicitly includes the fixed-configuration exceptions `Pk = k` and `epsilon = 0`; vanishing on a particular state is not a general identity.
- Section 12.3 explicitly assumes `lambda in [.16999999, .17000001]` throughout, including the finite-step overshoot example. The exact identities are not confused with the strict parameter-dependent inequalities.
- The exact witness locator is R2 §7. R8 already uses zeta for the phase mean; the crosswalk now records unchanged notation.
- The Section 1 author-facing paragraph remains provisional. It is reproduced in `REVISION_DISPOSITION.md` for Hilmir's refinement before publication; neither its retention nor GPT's proposed neutral alternative constitutes his approval.

## Document production and inspection

Compilation used the existing local Tectonic 0.17.0 executable directly, with a copy of v0.1's TeX cache confined to this draft's `build/` directory, `--only-cached`, and `--untrusted`. No older build script was run. The packages and cached TeX Gyre Pagella fonts selected in v0.1 were retained; no software was installed and no scientific environment was changed.

The source contains a retained image asset, so the existing local TeX tool was used to export the review PDF. The app's standalone compiler does not export a PDF and does not support additional project files.

Every page was rendered at 120 dpi and individually inspected at full-page readable resolution. The record is in `build/review/PAGE_INSPECTION.md`; compilation diagnostics are in `build/manuscript.log` and `build/compile-console.txt`. Final page count and final warning disposition are recorded there and in `README_REVIEW.md`.

Scientific-code execution, imports, simulations, tests, numerical evaluators, a fifth update, repository changes and publication actions were not performed. No Python was used, so the requested `torment` Conda environment was not invoked or modified.
