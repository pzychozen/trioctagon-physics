# Disposition of GPT review E01–E06

20 October 2026 · Local manuscript v0.2 · For GPT and Hilmir's review

This is a bounded revision of the preserved v0.1 draft in response to `GPT_REVIEW_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.1.md`, adopted as the task specification by the user's request. The review is not a new scientific source or publication clearance. No research, scientific-code execution, new update, new state, parameter sweep, repository change or publication action is part of this pass.

| Item | Disposition | Revised location |
|---|---|---|
| E01 | Replaced the diagonal-only description with the exact statement that refined shifted-index triangles replace the historical side connectivity. The source face lists and reports remain unchanged. | Section 2.1, p. 5; map G01 |
| E02 | Qualified permutation covariance: simultaneous channel/label permutation is a covariance; at fixed configuration `Pk=k` or `epsilon=0` suffice to cancel the displayed mismatch. Particular-state cancellation is distinguished from a general identity. The mismatch equation and separate common-phase/zero-component qualifications remain. | Section 10.2, p. 13; map Z12 |
| E03 | Explicitly imposed `lambda in Lambda = [.16999999,.17000001]` throughout the mean-line subsection, including the overshoot example. No strict inequality is claimed at `lambda=0`. | Section 12.3, p. 18; map P05 |
| E04 | Restored the actual-face bound `R(w,phi) >= min{a sqrt(3)(1-eta)/2, a(1-3eta/2)}`, its projection argument and the star-shaped disk implication. Applied the inherited `.097`, `.1144`, `.109` bounds at each perturbed endpoint's own height; numerical substitutions retain inherited status. | Appendix A.2, pp. 20–21, equation (A.1); map Z08 |
| E05 | Confirmed that the manifest-bound R9 omits the transverse plus sign. Corrected v0.1's mistaken claim that it was already present. The already-correct manuscript equation restores the sign using R2; R9 is preserved. | Appendix F, p. 27; notes; maps G06 and E02; manifest provenance note |
| E06 | Changed the exact fan witness citation to R2 §7 and recorded that R8's phase-mean zeta is unchanged notation. | Section 8, p. 11, and Appendix F, p. 27; map Z06 |

The source-map identifier E02 in the E05 row is an inherited claim ID, not the review's permutation item E02.

## R9 evidence reconciliation

The re-read local file is the same one identified in v0.1's manifest, with SHA-256:

```text
3a5c402a0ce02421aa1997a4152ea2292d096acd4a03059adb083df04712a554
```

Its literal equation (11) contains these consecutive lines:

```text
\left(2r-\frac{\sqrt3d}{2}\lambda_N\right)g_k
\zeta_Nj_k+\sigma(h+d\lambda_N)e_z:
```

There is no intervening plus sign. R2 equation (7) supplies the addition, and equation (8) supplies the corresponding plane. No alternate local copy was used. The error was in the v0.1 provenance description, not in the displayed manuscript notch equation.

## Short author passage for Hilmir's review

The existing Section 1 paragraph is retained provisionally and shown here explicitly:

> Hilmir's narrowing, guidance, and forward/reverse descriptions motivate these questions. They are exploratory geometric pictures, not experimental evidence for fluid transport or an instruction to make the crystal move. Here “mirror” names a mathematical comparison operation; it does not prescribe a mirror-switching process. The paper asks what the existing definitions establish, including the cases in which a proposed correspondence fails.

Hilmir may refine this before publication. Its retention does not certify testimony or approve it on his behalf. GPT's neutral alternative remains proposed wording only and has not been automatically substituted. No separate SRG Origins, G-derivative or 1/12 material is included.

## Review boundary and handoff

The abstract/front matter, Proposition 9.1 and Appendices B–F retain the distinction between symbolic/domain proofs and inherited numerical application. Initial radical inclusion, comparison-vector residuals, trigonometric endpoint substitutions, propagation bounds, detailed R7 norm/direction refinements, and complete independent actual-image inclusion remain audit obligations. Repeated intervals are not independent verification.

The original twelve-coordinate input box, each input's fixed configuration, geometry, placement, staged observer and four-update horizon are unchanged. The revised PDF, editable source and compact bundle are for review only. Document checks and page inspection are recorded separately in `build/review/`; the versioned sources and provenance records identify this pass.

The revised paper compiles to 28 A4 pages, all individually inspected. A contents-page reference to Part III was corrected to page 15 and re-inspected. The four remaining underfull paragraph warnings do not produce a visible layout blocker. These document operations do not close the scientific audit.
