# CODEX WORK ORDER
## Central Geometry, Z Readouts, and Chiral Response — Independent Numerical Audit v0.1

**Date:** 20 October 2026  
**Target:** The accepted, corrected local manuscript v0.2  
**Authority:** Hilmir has approved proceeding with the separately scoped numerical verification. GPT coordinates and reviews the returned evidence.  
**Purpose:** Check the calculations supporting the existing paper. Do not extend the research or edit the paper.

## 1. Authorization and stopping boundary

The user’s latest approval authorizes **writing and executing standalone scientific verification code for this audit only**. This is the explicit, narrow exception to the earlier source-reads-and-written-algebra-only restriction. The older reports must continue to describe truthfully what was done when they were written.

Authorized work consists of exact arithmetic, rigorously enclosed transcendental calculations, independent recomputation of the already specified four-update example, whole-domain bounds, and small self-checks of the new audit code. Supplemental high-precision evaluations may help detect mistakes, but cannot substitute for a rigorous enclosure certificate.

Not authorized: a fifth update; new trajectories, fitted inputs, parameter sweeps or exploratory simulations; imports or execution of project scientific modules, historical checkers, repository tests or application code; changes to the kernel, geometry, observer, manuscript, source reports, source manifests, repository, TORMENT, environment or publications. No dependency installation, upgrade, commit, push, release, DOI action or publication preparation.

E01–E06 remain closed as editorial corrections. A genuine scientific problem found during this audit must be reported as a **new audit finding**, not silently repaired or dismissed because the editing review closed. Publication remains a separate decision. This audit does not finalize or rewrite the author paragraph; its wording remains an author-review matter.

## 2. Immutable inputs and separate workspace

Authoritative scientific checkout, for source-text reads only:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

Accepted manuscript folder, read-only:

```text
C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_MANUSCRIPT_v0.2
```

Create all audit code and outputs under a new sibling folder:

```text
C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1
```

Do not overwrite an existing audit folder with different content. Use a separately named attempt directory when needed and identify the delivered attempt. Keep caches and temporary files inside that workspace. Use the existing Windows CMD workflow and `torment` Conda environment. No PowerShell requirement and no change to the environment. Record the actual interpreter, packages used and exact replay commands.

First read the **v0.2 bundled copies** of:

- `manuscript.tex`, particularly Proposition 9.1, Sections 11–12 and Appendices A–F;
- `PROOF_REVIEW_AND_EDITORIAL_NOTES.md`;
- `CLAIM_SOURCE_MAP.csv` and `SOURCE_MANIFEST.json`;
- `REVISION_DISPOSITION.md` and `README_REVIEW.md`.

Also read `GPT_REVISION_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.2.md`, where supplied. Do not accidentally use the separately uploaded v0.1 proof-review notes as the current record.

Accepted artifact identities, from the closure receipt:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| v0.2 review ZIP | 595068 | `37674d5df58596749855fc8d4c33c77e262e7b926ce2e7528c4dcec1b3b2a38c` |
| v0.2 `manuscript.tex` | 86681 | `02610193c2aebdf8b97b424f1837696dff79feb1f3079e038a0385dc4863640b` |
| v0.2 review PDF | 364084 | `f0b323bae4f552ee385e6a32f812c1842d88dc26423d129bcff2e74b7b332288` |
| v0.2 `REVISION_DISPOSITION.md` | 4940 | `ea7b5297d0fbf52a842d55ca1155776f083dc129a24273222e3742fb07931a9d` |

Verify these before treating the local package as the accepted input. Verify all scientific sources actually used against the source manifest. The recorded repository snapshot is `3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34`. A later checkout must not silently replace its definitions. Use hash-matched retained bytes or read-only retrieval of the recorded revision; do not reset, pull, checkout or modify the working tree to obtain them. Report missing or mismatched source dependencies precisely.

The ten reports are identified as R0–R9 in the manifest. The principal numerical dependencies are:

| Key | Report filename under the existing Codex reports area |
|---|---|
| R2 | `FULL_Z_AND_CENTRAL_PASSAGE_GEOMETRY_ANALYSIS_v0.1.md` |
| R3 | `FULL_Z_ONE_NATIVE_STEP_AND_PASSAGE_DISPLACEMENT_ANALYSIS_v0.1.md` |
| R4 | `FULL_Z_ONE_STEP_LOCAL_ROBUSTNESS_ANALYSIS_v0.1.md` |
| R5 | `FULL_Z_SECOND_STEP_NEGATIVE_CLOCK_SECTOR_ANALYSIS_v0.1.md` |
| R6 | `FULL_Z_THIRD_FOURTH_OBSERVATIONS_ANALYSIS_v0.1.md` |
| R7 | `NATIVE_NORM_GROWTH_AND_CHIRALITY_MECHANISM_ANALYSIS_v0.1.md` |
| R8 | `SYNCHRONIZER_PHASE_REGIONS_AND_CHIRALITY_RESPONSE_ANALYSIS_v0.1.md` |
| R9 | `Z_CRYSTAL_REVERSAL_AND_UPPER_LOWER_CORRESPONDENCE_ANALYSIS_v0.1.md` |

Use the manifest for exact report and primary-source paths. Read relevant definitions in `dynamics.py`, `readouts.py`, `z_manifold.py`, `z_diagnostics.py`, `_runner.py` and `_presets.py` **as text**. Do not import them. The audit must be a separately derived evaluator, not a call to the implementation it is meant to check.

## 3. Mathematical object being audited

The target is the manuscript’s **ideal real/complex mathematics**. All terminating decimals in its definitions and certificates denote exact rational numbers. Parse them from strings or integer numerator/denominator pairs; do not silently introduce binary64 literals and then treat them as exact decimals. This task does not certify the production binary64 implementation, physical measurement tolerance or runtime safety.

Retain the exact initial state and basis in R2/R3 and Appendix B, including the fan-centroid construction and its radicals. Rounded comparison vectors are enclosure centres only. They must never replace the actual initial state or exact successive images.

Retain the original closed twelve-coordinate box:

\[
\mathcal P_*=(\epsilon_*,g_*,\lambda_*,k_{1,*},k_{2,*},k_{3,*})
=(0.1,0.2,0.17,2,3,4),\qquad \delta=10^{-8}.
\]

All six real state coordinates and all six native coefficients vary independently and simultaneously by at most this radius about the original exact centre. **Each input chooses one configuration and uses that identical configuration through all four updates.** There is no reset, renormalization, later independent input perturbation, smaller-box fallback or retuned coefficient.

The independent native evaluator must use the complete staged formula:

\[
V=\Omega+\epsilon\Omega\odot(k-|\Omega|^2)+gL_3\Omega,
\qquad (L_3)_{jj}=-2,\quad (L_3)_{jk}=1\;(j\ne k),
\]
\[
\Delta_j=\lambda\sum_{m\ne j}\sin\bigl(3(\varphi_m-\varphi_j)\bigr),
\qquad \Omega_j^+=V_j e^{i\Delta_j}.
\]

Every increment uses the same pre-sync vector. Retain the source zero convention; prove the audited pre-sync domains exclude zero before using normalized components or phase derivatives. The branch-independent normalized-pair formulation may be used after that proof. Do not turn synchronization off or normalize the native state.

Keep PLUS zero geometry, centred coordinates, unit placement scale and zero additional azimuth. Keep the staged observation:

\[
\mathbf z_n=K_nE^nf_nd_n+\tfrac12C_n,
\quad K_n=0.618\frac{\|\Omega^{(n)}\|}{1+\|\Omega^{(n)}\|},
\quad E=e^{-0.0577},
\]
\[
f_n=\cos(n\pi/2-0.732),\quad
 d_n=(\cos(n\pi/6),\sin(n\pi/6),1),\quad
 C_n=\Re\Omega^{(n)}\times\Im\Omega^{(n)}.
\]

Use only n=0 through 4, with the native-update/observer-advance/observation schedule already documented. This recomputation is authorized verification of the existing example, not permission for further trajectory exploration.

## 4. Evidence standard and independence

Use two clearly distinguished levels:

**Pointwise numerical cross-check:** Independently evaluate the exact nominal starting state and its existing four images at high precision. Where practical compare equivalent expressions, such as cross products against pair-product chirality. This is useful evidence but not proof for the whole input box.

**Rigorous arithmetic certificate:** Independently check the source’s claimed enclosing intervals, strict margins, analytic remainder bounds and domain-wide sensitivity estimates using exact rational arithmetic or documented outward-rounded interval/ball arithmetic. A decimal evaluator, increased precision, agreement of two floating calculations, or checking all box corners does not by itself establish an enclosure for a nonlinear map.

Prefer an auditable exact-rational route where practical: positive-root bounds checked by squaring; certified pi enclosure; Taylor or alternating-series enclosures with justified ranges and remainders; exact rational endpoint substitution. A suitable already-installed validated-arithmetic package is also permitted, provided the relevant enclosure guarantees and rounding assumptions are recorded. If rigorous support is unavailable, report the limitation instead of relabelling numerical corroboration as certification.

Small exact self-checks of the new arithmetic code are authorized. Retain source, working precision, rounding policy, range-reduction choices, denominator/nonzero checks and error budgets. Test interval containment at mathematical branch boundaries used by the proof. These are audit self-checks, not permission to run repository tests.

Distinguish nominal approximation uncertainty from original-input variation and numerical evaluation error. The existing comparison-vector method is allowed only after independently checking its initial inclusion, residuals, domain coverage and propagation inequalities. Quoting the published Q values as an assumed starting certificate would leave the central obligation open.

Conservative product enclosures of correlated images are legitimate supersets. Describe them as such; do not model later parameter choices as newly independent. Analytic tightening or validated subdivision of a domain is permitted if the pieces cover the **unchanged original domain** and the union is certified. A subdivision must not become a parameter sweep or omit inconvenient regions. Wide intervals alone imply an inconclusive check, not genuine mixed behaviour or a false theorem.

Independent here means separate computation and proof checking rather than copying inherited results. It does not imply a separate human reviewer or a formal proof assistant certification.

## 5. Required audit blocks

### A. Exact starting state and four-stage certificate chain

Independently derive the fan-contact state from its original formulas. Check positive radicands, normalization identities, norm three, its actual chirality, and the supplied tight initial coordinate and comparison-ball bounds. Do not reconstruct a different state with the same norm and chirality.

For each of stages 1–4, check the inherited rational polynomial comparison values; arctangent quotient and phase-increment bounds where relied upon; full-update residual bounds; and the stage-specific nonzero domains. Recheck the derivative or finite-difference bounds on the **whole stated domains**, including sensitivity to the original parameter box. Confirm there is no circular use of a later nonzero/domain bound to prove its own inclusion.

Recompute the nominal-error and original-box-error recurrences from independently checked inputs. Audit R3–R6 and Appendix B, not merely the four final plotted points. Record the corrected R6 value `0.001504831` and verify that the original slightly larger printed number was conservative; preserve both historical source and correction provenance.

### B. Full-Z observations, finite geometry and distances

Recompute same-state norms, chiral vectors, saturated amplitudes, envelopes and clock factors. Check every endpoint enclosure used by Proposition 9.1 and the main observation table. Include the first native-only attribution endpoint, but do not insert it into the scheduled time series.

Using the actual zero-member faces and each input’s own height and total-vector azimuth, audit:

- initial exact fan-centroid membership at the reference state, without imposing it on perturbed inputs;
- first native-only exterior status and first scheduled interior status, including the restored `L(eta)` lower bound and its strict clearance;
- observation two’s exterior radius bound;
- observation three’s height-dependent containing bound;
- observation four’s two finite-edge wedge determinants and supporting-line residual, not an infinite-plane-only test;
- host membership, central-slab exclusion of fan/notch contacts, and all printed axial, radial and centre-distance comparisons.

In particular verify, rather than assume, the recorded inside/outside/outside/outside sequence. A radial margin is not automatically a minimum three-dimensional surface distance. Opposite endpoint heights do not prove an intervening passage or collision.

Relevant claim-map entries include Z06–Z10 and Appendix A. Do not expand the scope into a new geometry family, placement or physical interpretation.

### C. Norm, chirality, direction and attribution arithmetic

Audit the existing transitions 1→2, 2→3 and 3→4 for the norm budget; restrict detailed chiral-stage analysis to the already reported transitions 2→3 and 3→4. Include onsite channel terms, coupling pair differences, the finite squared increment and its signed mixed term.

Check pre-sync chirality from the cofactor expression and directly from the same pre-sync state. Independently check simultaneous pair-phase products, post-sync components and full magnitudes; the passive ratio `2||C||/kappa^2`; positive denominators; and the existing proved direction/projection inequalities. Include the correlated fourth-stage refinements that were necessary to determine signs.

Do not infer magnitude change from a single component, or net direction change from two separate stage changes. Claims explicitly unresolved in v0.2 remain outside this pass: do not add a new directional result to the paper merely because the audit evaluator suggests it.

Audit the native norm, polynomial chirality, synchronization chirality, envelope and clock attribution intervals, retaining the stipulated order and signs. This includes the exact cancellation of shared intermediate terms used to tighten bounds.

Relevant claim-map entries: M02–M05, Z10; Sections 11–12 and Appendix C. Source definitions M01/M03 are checked as necessary to ensure the evaluator and budget are auditing the same mathematical objects.

### D. Phase-domain theorems and their separate application

Independently certify the intermediate trigonometric bounds, finite-output ranges, positive pair weights and strict final margins in Theorems 12.2–12.3. The quantified domains are the entire closed products stated in the manuscript:

```text
S3 = [1.214, 1.223] × [0.0404, 0.0447]
A3 = [0.140, 0.144] × [0.284, 0.289] × [0.362, 0.369]
S4 = [0.587, 0.614] × [0.020, 0.038]
A4 = [0.174, 0.181] × [0.328, 0.335] × [0.415, 0.424]
Lambda = [0.16999999, 0.17000001]
```

The source’s `A`/`R` amplitude-box notation may differ; use the manuscript crosswalk, not a new domain. Check gain `D > 0.00034` and loss `D < -0.00248` as squared-magnitude statements. The fourth-domain loss **sign** for arbitrary positive amplitudes follows from a weighted inequality; its fixed absolute margin requires the amplitude box. A finite sample cannot prove the unbounded-positive-amplitude assertion.

Audit the numerical bounds supporting the same-mean-line gain/loss comparison and finite-step overshoot example under the restored Lambda hypothesis. Do not replace the weighted criterion by the sign of the mean-phase increment.

Separately verify that the actual original-box third/fourth pre-sync images lie in the independently certified phase-and-amplitude products. This requires the original residual chain, appropriate local phase lifts, interval inclusion and fixed-per-input configuration. Audit the signed polynomial component sums supporting the stated domain change. Do not infer reachability of every point in the larger product domains.

Relevant claim-map entries: P03–P07; Section 12 and Appendix D. Algebraic identities P01/P02 supply the definitions to audit, rather than an invitation to expand the theorem programme.

## 6. Findings, acceptance and dependency reporting

Build a compact claim/dependency coverage table from the accepted v0.2 map. Audit the numerical dependencies above and identify any other printed strict numerical claim in those proof chains that they require. Mark purely symbolic or historical claims outside this numerical scope instead of implying that all 37 claim-map rows were independently proved anew.

For each check provide: source key and exact hash; manuscript label and source equation/table locator; stated hypothesis/domain; claimed bound; independently obtained bound with explicit endpoint semantics; method and rounding/remainder justification; margin where meaningful; status; and downstream claims affected.

Use clear statuses, such as:

- `VERIFIED_EXACT` or `VERIFIED_RIGOROUS` for proof-supporting checks;
- `NUMERICAL_CORROBORATION_ONLY` for non-enclosing evaluations;
- `FAIL` for a disproved assertion;
- `UNRESOLVED` for insufficient proof bounds;
- `BLOCKED_SOURCE` for a missing or mismatched controlling input.

Do not mark a claim verified if a required dependency is merely quoted or unresolved. Avoid inflated totals from duplicate arithmetic; count distinct substantive checks separately from evaluator self-tests.

For a failed printed bound, first determine whether the issue is a transcription/arithmetic defect, a failed proof estimate, or a false scientific conclusion. Provide an exact or rigorously bounded witness where available. Describe the smallest proposed correction and which downstream results would require rechecking, **but edit no original artifact**. A new conservative estimate may be documented as a proposed audit repair, not substituted silently into the accepted v0.2.

Continue unaffected checks when safe. A clean report of a genuine problem is a successful audit outcome, not a reason to force a passing verdict. If resources or available arithmetic leave gaps, deliver the completed evidence and list the unresolved dependencies precisely.

## 7. Deliverables and reproducibility

Create one compact audit package in the new workspace containing:

1. `INDEPENDENT_NUMERICAL_AUDIT_REPORT.md`: a plain-language verdict first, followed by methods, claim coverage, findings, dependencies and exact limits. Separate whole-domain certification from nominal numerical corroboration.
2. Standalone checker source, normally `audit.py`, with any small local arithmetic helpers. No project-module imports. Include reasonable assertions and error handling.
3. `AUDIT_RESULTS.json`: exact hypotheses, claimed and checked bounds, statuses and dependency links; retain exact rationals or outward endpoints rather than rounded display values alone.
4. `INPUT_MANIFEST.json`, `ENVIRONMENT_AND_REPLAY.md` and raw console logs: input hashes, actual environment, arithmetic backend, precision, commands and preservation checks.
5. `CLAIM_AUDIT_COVERAGE.csv` and, only if necessary, `FINDINGS_AND_PROPOSED_CORRECTIONS.md`.
6. `CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1_REVIEW_BUNDLE.zip` with the audit evidence and an output hash manifest.

Keep the package self-contained for replay to the extent permissions and local inputs permit; otherwise list every required hash-bound input path. Do not include font files, credentials, unrelated source files or large environment dumps. No new PDF is required.

Run audit code from the isolated workspace, not from the repository. A suitable CMD replay pattern, after the named checker exists, is:

```bat
conda activate torment
cd /d C:\Users\Notandi\.codex\reports\CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1
python -B audit.py
```

Adapt only if the delivered entry point requires explicit input/output arguments, and document the exact command actually executed. `-B` avoids bytecode writes. Set any optional library caches within the audit workspace. Do not execute an old runner or checker to generate the audit data.

Record before/after identities of the accepted manuscript artifacts and every consulted original report/source. Read-only repository status may supplement those checks; do not claim an unperformed whole-machine audit. Identify any pre-existing unrelated modifications and preserve them.

## 8. Completion

Stop after delivering the audit evidence and an honest verdict for GPT and Hilmir. Do not revise the manuscript, declare publication clearance, approve the author paragraph, run a fifth update or launch the next task.

The desired outcome is **a reproducible answer to whether the existing paper’s numerical certificate and quantitative claims hold**, with any remaining gap made explicit. It is not more research, a new model, or a longer sequence of observations.
