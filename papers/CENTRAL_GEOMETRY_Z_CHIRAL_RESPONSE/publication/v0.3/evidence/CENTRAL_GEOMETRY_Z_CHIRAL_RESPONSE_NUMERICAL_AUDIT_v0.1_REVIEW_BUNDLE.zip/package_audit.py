"""Package and hash existing audit evidence only; no scientific calculations."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
NAME="CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_NUMERICAL_AUDIT_v0.1_REVIEW_BUNDLE.zip"
top=["INDEPENDENT_NUMERICAL_AUDIT_REPORT.md","ENVIRONMENT_AND_REPLAY.md",
     "audit.py","rigorous.py","supplement.py","verification.py","package_audit.py","replay.cmd",
     "AUDIT_RESULTS.json","NOMINAL_CROSSCHECK.json","INPUT_MANIFEST.json",
     "CLAIM_AUDIT_COVERAGE.csv","PRESERVATION.json","logs/audit-console.txt",
     "logs/repository-preservation.txt","tmp/direct_enclosures.json"]
files=[ROOT/x for x in top]+sorted(p for p in (ROOT/"inputs").rglob("*") if p.is_file())
records=[]
for p in files:
    data=p.read_bytes()
    records.append(dict(path=p.relative_to(ROOT).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest={"scope":"delivered audit payload; excludes this manifest, bundle and external receipt to avoid circular hashes",
          "files":records}
mf=ROOT/"OUTPUT_HASH_MANIFEST.json"
mf.write_text(json.dumps(manifest,indent=2),encoding="utf-8")
files.append(mf)
with zipfile.ZipFile(ROOT/NAME,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(2026,10,20,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes())
with zipfile.ZipFile(ROOT/NAME) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)
    for rec in records:
        data=z.read(rec["path"])
        assert len(data)==rec["bytes"] and hashlib.sha256(data).hexdigest()==rec["sha256"]
blob=(ROOT/NAME).read_bytes()
receipt=dict(bundle=NAME,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),
             payload_files=len(records),zip_integrity="PASS",manifest_payload_hashes="ALL_MATCH")
(ROOT/"BUNDLE_RECEIPT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
print(json.dumps(receipt,indent=2))
