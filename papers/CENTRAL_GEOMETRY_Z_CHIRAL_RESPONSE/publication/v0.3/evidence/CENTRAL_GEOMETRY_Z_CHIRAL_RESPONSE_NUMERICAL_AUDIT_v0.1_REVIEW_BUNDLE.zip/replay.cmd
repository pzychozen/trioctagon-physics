@echo off
setlocal
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
if errorlevel 1 exit /b 1
cd /d "%~dp0"
if not exist logs mkdir logs
if not exist tmp mkdir tmp
if not exist tmp\cache mkdir tmp\cache
set "TEMP=%CD%\tmp"
set "TMP=%CD%\tmp"
set "XDG_CACHE_HOME=%CD%\tmp\cache"
set "PYTHONDONTWRITEBYTECODE=1"
python -B audit.py > logs\audit-console.txt 2>&1
set "AUDIT_EXIT=%ERRORLEVEL%"
type logs\audit-console.txt
exit /b %AUDIT_EXIT%
