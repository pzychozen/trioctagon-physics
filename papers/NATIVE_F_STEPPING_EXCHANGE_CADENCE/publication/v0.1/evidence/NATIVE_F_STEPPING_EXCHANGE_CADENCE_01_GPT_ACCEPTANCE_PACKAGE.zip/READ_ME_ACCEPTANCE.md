# Native F stepping and exchange cadence acceptance package

Start with `NATIVE_F_STEPPING_EXCHANGE_CADENCE_01_GPT_ACCEPTANCE.md`. The machine-readable decision is `GPT_ACCEPTANCE.json`.

The accepted scope is the bounded F01–F12 investigation. The later receiving-and-recovery theorem under native stepping remains unproved, and no physical cadence is selected. No mathematical correction order is required.

## Package contents

- `submitted/` preserves all six supplied deliverables unchanged. The complete nested review ZIP contains the original issued sources and all Codex proof and verification records. `CORRECTIONS_AND_LIMITS.md` is an additional byte-identical convenience copy from that ZIP.
- `audits/accounting/` records the separate proof/source audit of F01–F06 and F10–F12.
- `audits/local/` records the separate F07–F09 audit and its exact-rational supporting check.
- `audits/provenance/` records the independent archive, original-input and source crosswalk audit.
- `replay/` contains the lead review's successful replay of the same eight submitted algebra groups, its one-line path adaptation and all execution records. The first missing-dependency attempt is retained. Runtime dependency directories and third-party packages are not bundled.
- `build_acceptance_package.py` records how this acceptance package was assembled and checked. It is a build record tied to the review workspace, not a portable installer or scientific trajectory script.
- `ACCEPTANCE_MANIFEST.json` lists every payload except itself, with exact byte lengths and SHA-256 hashes.

## Verification and use

The delivered external `.zip.sha256` identifies this outer archive. The external `NATIVE_F_STEPPING_EXCHANGE_CADENCE_01_GPT_PACKAGE_VERIFICATION.json` records CRC, safe names, exhaustive manifest checks, standalone equality and supplied-input preservation.

The nested review archive should retain SHA-256 `c11fb2373911ff33a4e0856f50c6b10e6c833bce7f07b175a7c3e39598b6d4f6`. It is 2,515,295 bytes. To follow the supplied proof's original `inputs/` paths, unpack that nested archive into a separate directory and read its own `READ_ME_REVIEW.md`.

The included audit records distinguish exact byte comparison, recorded execution evidence, replay and mathematical proof review. They do not claim fresh access to the Windows checkout or live remote GitHub state. No publication or successor research action is authorized by this package.
