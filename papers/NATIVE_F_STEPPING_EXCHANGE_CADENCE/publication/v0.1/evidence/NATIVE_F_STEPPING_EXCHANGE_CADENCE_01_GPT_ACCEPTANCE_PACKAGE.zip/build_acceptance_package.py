"""Assemble the bounded GPT acceptance and verify every delivered payload."""
from pathlib import Path, PurePosixPath
import datetime as dt
import hashlib
import json
import shutil
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
UPLOAD = WORKSPACE / 'upload'
SUBMISSION = ROOT / 'submission'
STAGE = ROOT / 'acceptance_package'
DELIVERY = ROOT / 'delivery'
TASK = 'NATIVE_F_STEPPING_EXCHANGE_CADENCE_01'
REPORT = TASK + '_GPT_ACCEPTANCE.md'
ZIP_NAME = TASK + '_GPT_ACCEPTANCE_PACKAGE.zip'
EXPECTED_INPUT_SHA = 'c11fb2373911ff33a4e0856f50c6b10e6c833bce7f07b175a7c3e39598b6d4f6'


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def copy(source, relative):
    target = STAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    assert target.read_bytes() == source.read_bytes()


assert not STAGE.exists(), 'Use a fresh stage; do not overwrite an existing acceptance package.'
STAGE.mkdir()
DELIVERY.mkdir(exist_ok=True)
provenance = json.loads((ROOT / 'audit_provenance/PACKAGE_AND_PROVENANCE_AUDIT.json').read_text())
accounting = json.loads((ROOT / 'audit_accounting/ACCOUNTING_AND_CADENCE_AUDIT.json').read_text())
local = json.loads((ROOT / 'audit_local/f07_f09_independent_exact_check.json').read_text())
replay = json.loads((ROOT / 'replay/REPLAY_COMPARISON.json').read_text())
assert provenance['status'] == local['status'] == replay['status'] == accounting['decision'] == 'PASS'
assert provenance['check_count'] == len(provenance['checks']) == 33
assert all(row['status'] == 'PASS' for row in provenance['checks'])
assert not accounting['mathematical_blockers'] and not accounting['required_corrections']
assert not local['scientific_corrections']
assert replay['group_count'] == 8 and replay['all_scientific_and_scope_fields_identical']

input_archive = UPLOAD / (TASK + '_REVIEW_PACKAGE.zip')
input_archive_bytes = input_archive.read_bytes()
assert identity(input_archive_bytes) == {'bytes': 2515295, 'sha256': EXPECTED_INPUT_SHA}
with zipfile.ZipFile(input_archive) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) == 201
    preservation = []
    for name in names:
        p = PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
        data = z.read(name)
        assert data == (SUBMISSION / name).read_bytes(), name
        preservation.append({'path': name, **identity(data), 'unchanged': True})

copy(ROOT / 'acceptance_report.md', REPORT)
copy(ROOT / 'acceptance_readme.md', 'READ_ME_ACCEPTANCE.md')
copy(Path(__file__), 'build_acceptance_package.py')
attachments = [
    (TASK + '_REVIEW_PACKAGE.zip', TASK + '_REVIEW_PACKAGE.zip'),
    (TASK + '_REVIEW_PACKAGE.zip.sha256', TASK + '_REVIEW_PACKAGE.zip.sha256'),
    (TASK + '_PROOF_REVIEW.md', TASK + '_PROOF_REVIEW.md'),
    (TASK + '_CLAIM_SOURCE_LEDGER.md', TASK + '_CLAIM_SOURCE_LEDGER.md'),
    ('CADENCE_STATUS.md', 'CADENCE_STATUS.md'),
    ('PACKAGE_VERIFICATION(6).json', 'PACKAGE_VERIFICATION.json'),
]
attachment_rows = []
for source_name, archive_name in attachments:
    source = UPLOAD / source_name
    copy(source, 'submitted/' + archive_name)
    attachment_rows.append({'received_name': source_name, 'package_path': 'submitted/' + archive_name,
                            **identity(source.read_bytes()), 'byte_identical': True})
copy(SUBMISSION / 'CORRECTIONS_AND_LIMITS.md', 'submitted/CORRECTIONS_AND_LIMITS.md')
for dirname, targetname in [('audit_accounting', 'accounting'), ('audit_local', 'local'), ('audit_provenance', 'provenance')]:
    for path in sorted((ROOT / dirname).iterdir()):
        if path.is_file() and path.suffix in {'.md', '.json', '.py'}:
            copy(path, 'audits/' + targetname + '/' + path.name)
for path in sorted((ROOT / 'replay').iterdir()):
    if path.is_file():
        copy(path, 'replay/' + path.name)

save(STAGE / 'INPUT_FINAL_PRESERVATION.json', {
    'status': 'PASS', 'checked_utc': now(),
    'submitted_archive': identity(input_archive_bytes),
    'extracted_submission_files_compared': 201,
    'all_extracted_submission_files_still_equal_archive': True,
    'supplied_attachment_copies': attachment_rows,
    'preservation_chain': 'The earlier provenance audit compared 169 input occurrences and 144 source identities with retained originals. The final checkpoint establishes that all 201 extracted submitted files remain unchanged after proof review and replay.',
    'records': preservation,
    'windows_checkout_freshly_inventoried': False,
})

acceptance = {
    'investigation': TASK, 'review_utc': now(), 'reviewer_role': 'GPT',
    'decision': 'ACCEPTED_WITH_STATED_SCOPE',
    'mathematical_corrections_required': [],
    'correction_order_required': False,
    'proof_obligations': {f'F{i:02d}': 'ACCEPTED_WITH_SUBMITTED_HYPOTHESES' for i in range(1, 13)},
    'documentary_corrections': [
        {'kind': 'stale locator', 'old': 'sources/SOURCE_IDENTITIES.json', 'delivered': 'inputs/SOURCE_IDENTITIES.json', 'resolved_in_review_records': True, 'input_edited': False},
        {'kind': 'stale staging prefix', 'old': 'publish_order/packet/publication_payload/papers/NATIVE_CAPACITY_RECEIVING_RECOVERY/publication/v0.1/', 'delivered': 'inputs/sources/receiving_recovery/publication/v0.1/', 'resolved_in_review_records': True, 'input_edited': False},
    ],
    'accepted_findings': [
        'Exact native and F-first hybrid equations with inherited solution hypotheses',
        'Finite-round accounts and native-baseline-corrected recovery ratios',
        'Exchange-invariant floor, moving capacity and external-preload envelope',
        'Exact first-jump baseline, sign threshold and exit from the old launch family',
        'Nonzero actual post-F source at every allowed positive phase',
        'Pointwise short-time initial supply and receiving before the next jump',
        'Fixed-detuning local capacity branch and exact asymptotic ceiling ratio',
        'One-step small-h limit and qualified fixed-finite-N limit',
        'Exact real-state dark witness with empty external preparation',
    ],
    'remaining_open': [
        'Later capacity-sized receiving and quantified native recovery for actual native-stepped launches and subsequent preloaded intervals',
        'Phase-uniform short-time interval',
        'Explicit certified phase neighborhood for the local capacity branch',
        'N proportional to 1/h cadence limit',
        'Uniform infinite-step bound',
        'Physical cadence or native clock identification',
    ],
    'counts': {'submitted_archive_members': 201, 'submitted_manifest_payloads': 200,
               'supplied_input_occurrences': 169, 'protected_source_identities': 144,
               'source_locators': 56, 'proof_obligations': 12, 'equation_tags': 59,
               'provenance_checks': 33, 'submitted_algebra_groups_replayed': 8,
               'recorded_original_support_replays': 2, 'shared_exact_quantities_reconciled': 18},
    'replay_scientific_and_scope_fields_exactly_equal': True,
    'replay_counting': 'The same eight groups replayed; no doubling of independent findings.',
    'source_preservation': 'All supplied materials preserved and compared; no fresh Windows checkout-wide snapshot.',
    'native_cadence_selected': False,
    'later_hybrid_receiving_and_recovery_theorem_proved': False,
    'author_publication_decision_recorded': False,
    'new_author_premise_needed_for_this_bounded_acceptance': False,
    'git_operations_performed_by_review': False, 'publication_performed': False,
    'scientific_input_edits': False, 'trajectory_simulations': False,
    'manuscript_prepared': False, 'successor_investigation_started': False,
    'submitted_archive': {'file': TASK + '_REVIEW_PACKAGE.zip', **identity(input_archive_bytes)},
}
save(STAGE / 'GPT_ACCEPTANCE.json', acceptance)

payloads = []
for path in sorted(STAGE.rglob('*')):
    if path.is_file():
        payloads.append({'path': path.relative_to(STAGE).as_posix(), **identity(path.read_bytes())})
save(STAGE / 'ACCEPTANCE_MANIFEST.json', {
    'task': TASK, 'kind': 'GPT acceptance payload manifest', 'created_utc': now(),
    'excludes_self': True, 'payload_count': len(payloads), 'files': payloads,
})
archive_path = DELIVERY / ZIP_NAME
assert not archive_path.exists()
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(STAGE.rglob('*')):
        if path.is_file():
            info = zipfile.ZipInfo(path.relative_to(STAGE).as_posix(), (2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            z.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

verified_members = []
with zipfile.ZipFile(archive_path) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) == len(set(n.casefold() for n in names))
    assert set(names) == {row['path'] for row in payloads} | {'ACCEPTANCE_MANIFEST.json'}
    manifest = json.loads(z.read('ACCEPTANCE_MANIFEST.json'))
    assert manifest['payload_count'] == len(manifest['files']) == len(names) - 1
    for info in z.infolist():
        p = PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename
        assert not stat.S_ISLNK(info.external_attr >> 16)
        data = z.read(info)
        assert data == (STAGE / info.filename).read_bytes()
        verified_members.append({'path': info.filename, **identity(data)})
    for row in manifest['files']:
        assert identity(z.read(row['path'])) == {k: row[k] for k in ['bytes', 'sha256']}
    assert z.read('submitted/' + TASK + '_REVIEW_PACKAGE.zip') == input_archive_bytes
    for row in attachment_rows:
        assert z.read(row['package_path']) == (UPLOAD / row['received_name']).read_bytes()
    assert z.read(REPORT) == (ROOT / 'acceptance_report.md').read_bytes()

archive_identity = identity(archive_path.read_bytes())
checksum = DELIVERY / (ZIP_NAME + '.sha256')
checksum.write_text(archive_identity['sha256'] + '  ' + ZIP_NAME + '\n')
assert checksum.read_text().split()[0] == archive_identity['sha256']
(DELIVERY / REPORT).write_bytes((STAGE / REPORT).read_bytes())
verification = {
    'task': TASK, 'status': 'PASS', 'verified_utc': now(),
    'scientific_disposition': acceptance['decision'],
    'archive': {'file': ZIP_NAME, **archive_identity},
    'safe_unique_members': len(verified_members),
    'manifest_payloads': len(payloads), 'CRC': 'PASS',
    'exhaustive_manifest': True, 'all_member_lengths_and_hashes_match': True,
    'all_members_equal_staged_files': True,
    'standalone_acceptance_report_equals_archive': True,
    'six_supplied_deliverables_preserved_byte_identically': True,
    'all_201_extracted_submission_files_unchanged_after_review': True,
    'replayed_algebra_groups': 8, 'all_scientific_and_scope_fields_exactly_match': True,
    'documentary_path_corrections': 2, 'mathematical_corrections_required': 0,
    'later_hybrid_theorem_remains_open': True, 'physical_cadence_selected': False,
    'git_operations': False, 'publication': False, 'successor_investigation': False,
    'payload_records': verified_members,
    'external_files': {'acceptance_report': identity((DELIVERY / REPORT).read_bytes()),
                       'checksum_sidecar': identity(checksum.read_bytes())},
    'self_hash_note': 'This receipt and archive checksum sidecar are outside the ZIP; no recursive checksum claim is made.',
}
save(DELIVERY / (TASK + '_GPT_PACKAGE_VERIFICATION.json'), verification)
print(json.dumps({k: v for k, v in verification.items() if k != 'payload_records'}, indent=2))
