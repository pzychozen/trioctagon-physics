"""Independent symbolic/rational reconstruction. No supplied scientific module import."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys
import sympy as S

W = Path(__file__).resolve().parent
R = S.Rational
groups = []
def group(name, claims, details):
    groups.append({"name": name, "claims": claims, "status": "PASS", "results": details})
def zero(expr):
    assert S.expand(expr) == 0, str(expr)
def vector_strings(v):
    return [str(S.factor(q)) for q in v]

# Reconstruct the general finite-prestage identity in six independent real variables.
ar = S.Matrix(S.symbols("a1:4", real=True))
br = S.Matrix(S.symbols("b1:4", real=True))
k = S.Matrix(S.symbols("k1:4", real=True))
eps, g, d, lam = S.symbols("eps g d lam", real=True)
L3 = S.ones(3) - 3*S.eye(3)
intensities = [ar[i]**2+br[i]**2 for i in range(3)]
ha = S.Matrix([(k[i]-intensities[i])*ar[i] for i in range(3)])
hb = S.Matrix([(k[i]-intensities[i])*br[i] for i in range(3)])
da, db = eps*ha+g*L3*ar, eps*hb+g*L3*br
edges = sum((ar[i]-ar[j])**2+(br[i]-br[j])**2 for i in range(3) for j in range(i+1,3))
lhs = (ar+da).dot(ar+da)+(br+db).dot(br+db)-ar.dot(ar)-br.dot(br)
rhs = 2*eps*sum(intensities[i]*(k[i]-intensities[i]) for i in range(3))-2*g*edges+da.dot(da)+db.dot(db)
zero(lhs-rhs)
zero((L3*ar).dot(L3*ar)+(L3*br).dot(L3*br)-3*edges)
zero(da.dot(da)+db.dot(db)-eps**2*(ha.dot(ha)+hb.dot(hb))
     -2*eps*g*(ha.dot(L3*ar)+hb.dot(L3*br))-g**2*((L3*ar).dot(L3*ar)+(L3*br).dot(L3*br)))
group("A01_general_finite_square", ["F01","F05"], {"symbolic_residuals": [0,0,0],
      "scope": "General six-real-variable prestage and edge-once/full-square identities; synchronization modulus preservation is proved in text."})

# q=c+i*s, reduced using c^2+s^2=1, independently from the component construction.
c, s, D = S.symbols("c s D", real=True)
real = S.Matrix([1-d+g*(c-1), c+2*g*(1-c), 1+d+g*(c-1)])
imag = S.Matrix([g*s, (1-2*g)*s, g*s])
def circle(expr):
    return S.factor(S.rem(S.Poly(S.expand(expr),s),S.Poly(s*s+c*c-1,s)).as_expr())
delta = circle(real.dot(real)+imag.dot(imag)-3)
zero(delta-(2*d*d-4*g*(2-3*g)*(1-c)))
fixed = {g:R(1,60), d:R(1,10000), lam:R(1,300)}
delta_D = S.factor(delta.subs(c,1-D).subs(fixed))
zero(delta_D-(R(1,50000000)-R(13,100)*D))
v1mod = circle(real[0]**2+imag[0]**2)
v3mod = circle(real[2]**2+imag[2]**2)
zero(v1mod-((1-d)**2-2*g*(1-d-g)*(1-c)))
zero(v3mod-v1mod-4*d*(1-g*(1-c)))
square_launch = circle((real-S.Matrix([1,c,1])).dot(real-S.Matrix([1,c,1]))+
                       (imag-S.Matrix([0,s,0])).dot(imag-S.Matrix([0,s,0])))
zero(square_launch-(2*d*d+12*g*g*(1-c)))
group("A02_first_jump_polynomials", ["F05","F06"], {"delta_I":str(delta_D),
      "baseline_over_alpha":str(delta_D/2), "general_delta_I":str(delta),
      "prestage_square":str(square_launch), "first_modulus_squared":str(v1mod),
      "third_minus_first":str(S.factor(v3mod-v1mod))})

# Rational signs from explicitly specified analytic cosine bounds, not float samples.
threshold = S.solve(delta_D,D)[0]
low, high = R(1,10000), R(1,1000)
positive_margin = S.factor(delta_D.subs(D,low**2/2))
negative_upper = S.factor(delta_D.subs(D,high**2/2-high**4/24))
assert positive_margin>0 and negative_upper<0
assert 0<low<high<=R(1,100)
group("A03_two_rational_witnesses", ["F05"], {"D_threshold":str(threshold),
      "phi_positive":str(low),"delta_I_lower":str(positive_margin),
      "phi_negative":str(high),"delta_I_upper":str(negative_upper),
      "analytic_dependency":"phi^2/2-phi^4/24 <= 1-cos(phi) <= phi^2/2 on the specified interval"})

# Oriented chirality and raw matrix signs without evaluating a trajectory.
cross = real.cross(imag)
A = S.factor(cross[2]/s)
zero(A-(1-3*g-d*(1-2*g)))
A_fixed = A.subs(fixed)
contract = 1-9*fixed[lam]
assert A_fixed>0 and contract>0
assert fixed[g]>0 and 1-fixed[d]-fixed[g]>0 and 1-2*fixed[g]>0
assert 6*fixed[lam]<1
z1,z2,z3 = S.symbols("chi1 chi2 chi3", real=True)
K0 = S.Matrix([[S.sqrt(2),S.sqrt(2),S.sqrt(3)],[S.sqrt(2),S.sqrt(2),-S.sqrt(3)]])
f0 = K0*S.Matrix([z1,z2,z3])
zero(f0.dot(f0)-(4*(z1+z2)**2+6*z3**2))
zero(f0[0]-f0[1]-2*S.sqrt(3)*z3)
group("A04_source_bound_constants_and_signs", ["F07"], {"A_star":str(A_fixed),
      "s_star":str(contract), "norm_lower_coefficient_over_G_squared_sin_squared":str(R(6,7)*contract**2*A_fixed**2),
      "raw_K_rows_without_G_over_sqrt7":[vector_strings(K0.row(i)) for i in range(2)],
      "analytical_dependencies":"Convex-angle and 3-Lipschitz/concavity proofs are in the review, not certified by these constant checks."})

# Jacobian reconstruction: at positive real r, angle derivative is diag(1/r)u.
rr = S.Matrix([1-fixed[d],1,1+fixed[d]])
u = S.Matrix([fixed[g],1-2*fixed[g],fixed[g]])
angle_derivative = S.diag(*[1/q for q in rr])*u
sync_jacobian = S.eye(3)+3*fixed[lam]*L3
t = S.simplify(S.diag(*rr)*sync_jacobian*angle_derivative)
sum_angles = sum(angle_derivative)
expected_t = contract*u+3*fixed[lam]*rr*sum_angles
assert all(S.simplify(q)==0 for q in t-expected_t)
assert all(S.simplify(q)==0 for q in rr.cross(t)-contract*rr.cross(u))
Q_from_t = S.factor(t.dot(t)-rr.dot(t)**2/rr.dot(rr))
Q_from_u = S.factor(contract**2*(u.dot(u)-rr.dot(u)**2/rr.dot(rr)))
assert Q_from_t == Q_from_u
assert Q_from_t == R(169832451759483,300000002000000)
group("A05_postsync_derivative_and_capacity_Q", ["F09"], {"r":vector_strings(rr),"u":vector_strings(u),
      "phase_derivatives":vector_strings(angle_derivative),"t":vector_strings(t),
      "r_cross_t":vector_strings(rr.cross(t)), "r_squared":str(rr.dot(rr)),
      "u_squared":str(u.dot(u)), "r_dot_u":str(rr.dot(u)), "Q":str(Q_from_t),
      "capacity_ratio_limit":str(2*Q_from_t),"approximation":str(S.N(2*Q_from_t,18))})

# Keep the unspecified second-order real coefficient. Its cancellation is essential.
R2,T2,RT,RV = S.symbols("R2 T2 RT RV", real=True)
I_second = T2+2*RV
absZ_second = 2*RV-T2+2*RT**2/R2
zero((I_second-absZ_second)/2-(T2-RT**2/R2))
P,Qv,Rv = S.symbols("P Q R", real=True)
zero((P+Qv)**2-((P-Qv)**2+4*Rv**2)-4*(P*Qv-Rv**2))
group("A06_capacity_even_expansion_identities", ["F09"], {"unknown_second_real_coefficient_cancels":True,
      "coefficient":"|t|^2-(r dot t)^2/|r|^2",
      "analytic_dependencies":"Real analyticity, conjugation parity, strict branch gap and nonzero |Z2| proved in text."})

# Explicit dark invariant/floor change, with alpha factored out.
Ir = rr.dot(rr)
h_e = (rr[0]-rr[1])**2/2
jr = Ir-2*h_e
assert Ir-3 == R(1,50000000)
assert h_e == R(1,200000000)
assert jr-3 == R(1,100000000)
assert Ir>jr and (Ir-Ir)/2 == 0
group("A07_dark_boundary_and_branch_gap", ["F04","F09","F11"], {"I_equals_Z2":str(Ir),
      "h_e":str(h_e), "j":str(jr), "delta_I":str(Ir-3), "delta_j":str(jr-3),
      "baseline_over_alpha":str((Ir-3)/2),"capacity":0,"C_projection_over_alpha":str(h_e)})

# Telescoping account and pointwise capacity identity are symbolic equalities.
Na,Nb,Ea,Eb,B,Lbefore,Lafter,Hbefore,Hafter = S.symbols("Na Nb Ea Eb B La Lb Ha Hb",real=True)
subbed = S.expand((Nb-Na-B)-(Ea-Eb)).subs(Nb,Na+B-(Eb-Ea))
zero(subbed)
zero((Hafter-Lafter)-(Hbefore-Lbefore)-((Hafter-Hbefore)-(Lafter-Lbefore)))
group("A08_accounting_residuals", ["F02","F03","F04"], {"baseline_subtracted_balance_residual":0,
      "delta_capacity_residual":0,"scope":"Arithmetic cross-check only; endpoint and nonnegativity proofs are in text."})

record = {"status":"PASS","utc":dt.datetime.now(dt.timezone.utc).isoformat(),
          "method":"Independent symbolic reconstruction before reading or running supplied checker implementations",
          "python":sys.version,"executable":sys.executable,"sympy":S.__version__,
          "group_count":len(groups),"groups":groups,"repository_modules_imported":False,
          "trajectory_evolution":False,"phase_or_parameter_sweep":False,"Git_operations":False,
          "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "limits":"Exact algebra support; no assertion of machine-formal verification of analysis or a receiving/recovery theorem."}
(W/"INDEPENDENT_ALGEBRA_RESULTS.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
print(json.dumps(record,indent=2))
