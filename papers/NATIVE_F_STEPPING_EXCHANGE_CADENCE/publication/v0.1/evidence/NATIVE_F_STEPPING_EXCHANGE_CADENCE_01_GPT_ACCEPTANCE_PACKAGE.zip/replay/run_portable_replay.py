"""Replay the reviewed, path-portable checker and compare its eight groups."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SUBMISSION = ROOT.parent / 'submission'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


scope = json.loads((ROOT / 'REPLAY_SCOPE.json').read_text())
original = SUBMISSION / 'independent_algebra.py'
portable = ROOT / 'independent_algebra_portable.py'
assert sha(original) == scope['original_sha256']
assert sha(portable) == scope['replay_copy_sha256']
old_assignment = 'W = Path("\\\\\\\\?\\\\" + str(Path(__file__).resolve().parent))'
new_assignment = 'W = Path(__file__).resolve().parent'
original_text = original.read_text()
assert original_text.count(old_assignment) == 1
assert portable.read_text() == original_text.replace(old_assignment, new_assignment, 1)

for source, target in [('REPLAY_STDOUT.json', 'ATTEMPT_01_STDOUT.txt'),
                       ('REPLAY_STDERR.txt', 'ATTEMPT_01_STDERR.txt')]:
    src = ROOT / source
    dst = ROOT / target
    if src.exists() and not dst.exists():
        src.rename(dst)

loader = ('import runpy, sys; '
          f'sys.path.insert(0, {str(ROOT / "dependencies")!r}); '
          f'runpy.run_path({str(portable)!r}, run_name="__main__")')
command = [sys.executable, '-I', '-B', '-c', loader]
started = dt.datetime.now(dt.timezone.utc).isoformat()
result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=120)
finished = dt.datetime.now(dt.timezone.utc).isoformat()
(ROOT / 'REPLAY_STDOUT.json').write_bytes(result.stdout)
(ROOT / 'REPLAY_STDERR.txt').write_bytes(result.stderr)
execution = {
    'started_utc': started, 'finished_utc': finished,
    'returncode': result.returncode, 'command': command,
    'cwd': str(ROOT), 'python': sys.version,
    'original_script_sha256_before': scope['original_sha256'],
    'original_script_sha256_after': sha(original),
    'replay_copy_sha256': sha(portable),
    'stdout_bytes': len(result.stdout), 'stderr_bytes': len(result.stderr),
    'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
    'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
    'first_attempt': 'Stopped at import because SymPy was absent; original stdout and traceback are retained as ATTEMPT_01 files.',
    'dependency_resolution': 'Installed SymPy 1.14.0 and mpmath 1.3.0 in this review-only dependencies directory; no global environment or source edits.',
    'scope': 'Replay of the submitted eight algebra groups; not eight new independent findings.'
}
save('REPLAY_EXECUTION.json', execution)
assert result.returncode == 0, result.stderr.decode(errors='replace')
assert not result.stderr
submitted = json.loads((SUBMISSION / 'INDEPENDENT_ALGEBRA_RESULTS.json').read_text())
replayed = json.loads((ROOT / 'INDEPENDENT_ALGEBRA_RESULTS.json').read_text())
assert json.loads(result.stdout) == replayed
rows = []
assert len(submitted['groups']) == len(replayed['groups']) == 8
for first, second in zip(submitted['groups'], replayed['groups']):
    rows.append({'name': first['name'], 'exact_group_equality': first == second,
                 'submitted_status': first['status'], 'replay_status': second['status']})
excluded_runtime_fields = ['utc', 'python', 'executable', 'script_sha256']
stable_submitted = {k: v for k, v in submitted.items() if k not in excluded_runtime_fields}
stable_replayed = {k: v for k, v in replayed.items() if k not in excluded_runtime_fields}
comparison = {
    'status': 'PASS' if stable_submitted == stable_replayed else 'FAIL',
    'group_count': len(rows), 'group_results': rows,
    'all_scientific_and_scope_fields_identical': stable_submitted == stable_replayed,
    'runtime_fields_excluded_from_equality': excluded_runtime_fields,
    'submitted_sympy': submitted['sympy'], 'replay_sympy': replayed['sympy'],
    'stdout_equals_written_result': True,
    'original_script_unchanged': sha(original) == scope['original_sha256'],
    'change_to_replay_copy': 'Windows output-directory prefix removed; scientific statements and assertions identical.',
    'group_counting': 'Eight submitted groups successfully replayed; do not add these as eight independent claims.',
    'method_field_note': scope['method_field_note']
}
save('REPLAY_COMPARISON.json', comparison)
assert comparison['status'] == 'PASS'
assert comparison['original_script_unchanged']
assert all(row['exact_group_equality'] and row['replay_status'] == 'PASS' for row in rows)
print(json.dumps(comparison, indent=2))
