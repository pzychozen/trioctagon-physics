# Independent audit: F07–F09

**Verdict: PASS. No scientific correction is required in F07–F09.**

Reviewed source: `submission/NATIVE_F_STEPPING_EXCHANGE_CADENCE_01_PROOF_REVIEW.md`, equations (33)–(53). The inherited P1 activity and wellposedness sources, P3 projection/capacity source, and native dynamics source were consulted for definitions and hypothesis matching. This is an audit of the submitted statements, not a successor investigation. No submitted checker was executed by this auditor, and no input or repository file was edited.

## F07: phase order and source lower bound

All three prestage coordinates have the form `A_i + B_i exp(i phi)` with strictly positive real coefficients. Consequently their phases lie strictly between zero and phi throughout `0 < phi <= 1/100`. The exact imaginary products have coefficients `284971/300000` and `1/300000`, establishing the claimed strict ordering without a numerical sweep or a branch-wrap assumption.

The simultaneous synchronizer has nonnegative convex-combination weights, with total off-diagonal weight at most `6 lambda = 1/50`. It preserves the phase cone. Subtracting the two phase updates and using the derivative bound for `sin(3u)` gives `Delta_plus >= (1 - 9 lambda) Delta = (97/100) Delta` for each initially ordered pair. Concavity and monotonicity of sine on the containing interval then justify the lower bound on the third cross-product component.

The registered source norm identity is exact:

`|K chi|^2 = (G^2/7) [4(chi_1+chi_2)^2 + 6 chi_3^2]`.

Combining these statements gives the submitted coefficient

`764090502142969 / 1050000000000000`

multiplying `G^2 sin(phi)^2`. The companion exact-arithmetic check confirms this fraction. The estimate establishes a nonzero source for every allowed positive phase and positive G; its coefficient is uniform over the interval. It does not establish a phase-independent positive floor as phi approaches zero. The submission correctly makes this distinction.

## F08: actual initial supply and receiving

The nonzero post-F source and empty external stores meet the hypotheses of the inherited activity result. The source theorem does not require the native launch to remain a unit-modulus vector. The submitted regularity invocation is adequate for the first-order carrier expansion; it does not require an extra derivative of a tent profile.

Writing `f0 = f(F Omega_phi)`, the first derivatives give `p(t) = eta t B f0 + o(t)`, `r_c(t) = o(t)` in the carrier norm, and hence `y(t) = eta m t f0 + o(t)`. Local boundedness of the native coupling yields `x(t)-x(0)=O(t^2)` and therefore `f(x(t))=f0+O(t^2)`. Direct integration gives the submitted coefficients:

| Quantity | Leading term |
| --- | --- |
| Native debit | `(eta^2 m / 2) |f0|^2 t^2` |
| Receiver amplitude | `(eta kappa m / (2 beta)) f0 t^2` |
| Receiver energy | `(eta^2 kappa^2 m^2 / (8 beta)) |f0|^2 t^4` |
| Native-to-carrier power | `eta^2 m |f0|^2 t` |
| Carrier-to-receiver power | `(eta^2 kappa^2 m^2 / (2 beta)) |f0|^2 t^3` |

The little-o remainders imply positivity for sufficiently small positive time after each fixed launch. The quantifiers are correctly pointwise in the positive phase and fixed finite positive exchange parameters. The hybrid conclusion is restricted to `0 < t < min(h, delta)`. It makes no unsupported assertion about a uniform delta, the value at the next jump, or later capacity-sized receiving and recovery.

## F09: local capacity branch and asymptotic coefficient

At zero phase the post-F state is `r = (1-d0, 1, 1+d0)`, where `d0=1/10000`. The two candidate capacity terms have `C_Z(r)=0` and `h_e(r)=d0^2/2>0`. Continuity therefore selects the `C_Z` branch in a sufficiently small phase neighborhood. This is a local assertion for the fixed nonzero detuning, not a whole-interval branch claim.

Differentiating the actual synchronized map gives

`t = (97/100) u + 3 lambda r sum_j(u_j/r_j)`,

where `u=(1/60,29/30,1/60)`. Its transverse part is confirmed exactly:

`r cross t = (-27647813,97,27642187)/30000000`.

The phase extraction is real analytic locally about the positive zero-phase prestage. Conjugation symmetry makes the real part even and imaginary part odd. The retained unknown second-order real coefficient cancels from `I-|Z_2|`; the claimed `O(phi^4)` capacity remainder is therefore justified. Independently expanding the modulus, or using the cross-product identity for `C_Z`, gives

`Q = |t|^2 - (r dot t)^2/|r|^2`

`  = (97/100)^2 (187/200 - 1/(3+2d0^2))`

`  = 169832451759483/300000002000000 > 0`.

The limit against the original launch capacity is

`2Q = 169832451759483/150000001000000`, approximately `1.132216337515111`.

The submission correctly interprets this as a comparison of capacity ceilings; it does not equate the ratio to achieved transfer or efficiency.

## Audit boundaries

No mathematical change is requested. The source lower bound, short-time activity, and local capacity asymptotic do not establish a later receiving-and-recovery theorem under repeated native stepping and do not select a physical cadence. Those limitations are stated correctly in the submission.

The companion checker is `f07_f09_independent_exact_check.py`; its generated result is `f07_f09_independent_exact_check.json`. The analytic arguments above were checked directly from the equations; the checker only verifies exact constants and identities, and uses no phase sweep.
