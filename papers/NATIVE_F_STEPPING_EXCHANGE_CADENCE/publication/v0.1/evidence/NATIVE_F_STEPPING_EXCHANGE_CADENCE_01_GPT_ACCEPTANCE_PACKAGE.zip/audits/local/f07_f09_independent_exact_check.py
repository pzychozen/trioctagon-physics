"""Independent exact-arithmetic audit of F07 and F09 constants.

Written for GPT review; imports no submitted implementation and runs no
submitted checker.  The phase inequalities and time asymptotics are covered
by the companion mathematical audit, not by sampling in this script.
"""

from fractions import Fraction as R
import json
from pathlib import Path


def dot(a, b):
    return sum((x * y for x, y in zip(a, b)), R(0))


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


d = R(1, 10000)
g = R(1, 60)
lam = R(1, 300)
s = 1 - 9 * lam
r = (1 - d, R(1), 1 + d)
u = (g, 1 - 2 * g, g)

# Each prestage coordinate is A_i + B_i exp(i phi), with A_i,B_i>0.
prestage_pairs = ((1 - d - g, g), (2 * g, 1 - 2 * g), (1 + d - g, g))
assert all(a > 0 and b > 0 for a, b in prestage_pairs)
assert 6 * lam == R(1, 50)
assert s == R(97, 100)

# Exact coefficients of Im(conj(v1) v2) and Im(conj(v3) v1).
A = prestage_pairs[0][0] * prestage_pairs[1][1] - prestage_pairs[0][1] * prestage_pairs[1][0]
cross31_coefficient = prestage_pairs[2][0] * prestage_pairs[0][1] - prestage_pairs[2][1] * prestage_pairs[0][0]
assert A == 1 - 3 * g - d * (1 - 2 * g) == R(284971, 300000)
assert cross31_coefficient == 2 * d * g == R(1, 300000)
source_lower_coefficient = R(6, 7) * s**2 * A**2
assert source_lower_coefficient == R(764090502142969, 1050000000000000)

# Post-F derivative and its component perpendicular to the zero-phase state.
S = sum((u[i] / r[i] for i in range(3)), R(0))
t = tuple(s * u[i] + 3 * lam * r[i] * S for i in range(3))
r2 = dot(r, r)
assert r2 == 3 + 2 * d**2
assert dot(u, u) == R(187, 200)
assert dot(r, u) == 1
ru = cross(r, u)
rt = cross(r, t)
assert ru == tuple(R(n, 300000) for n in (-285029, 1, 284971))
assert rt == tuple(s * c for c in ru)
assert rt == tuple(R(n, 30000000) for n in (-27647813, 97, 27642187))
Q = dot(t, t) - dot(r, t)**2 / r2
assert Q == dot(rt, rt) / r2
assert Q == s**2 * (R(187, 200) - 1 / r2)
assert Q == R(169832451759483, 300000002000000)
assert 2 * Q == R(169832451759483, 150000001000000)
assert Q > 0
zero_phase_branch_gap = d**2 / 2
assert zero_phase_branch_gap == R(1, 200000000) > 0

report = {
    "status": "PASS",
    "scope": "F07 and F09 exact constants; no submitted scripts executed",
    "phase_parameter_interval": "0 < phi <= 1/100",
    "g": str(g),
    "lambda": str(lam),
    "d0": str(d),
    "s_star": str(s),
    "prestage_12_imaginary_coefficient": str(A),
    "prestage_31_imaginary_coefficient": str(cross31_coefficient),
    "source_lower_coefficient_multiplying_G2_sin2_phi": str(source_lower_coefficient),
    "r": [str(x) for x in r],
    "u": [str(x) for x in u],
    "t": [str(x) for x in t],
    "r_cross_t": [str(x) for x in rt],
    "Q": str(Q),
    "capacity_ratio_limit_2Q": str(2 * Q),
    "capacity_ratio_limit_2Q_decimal_for_display": float(2 * Q),
    "zero_phase_h_e": str(zero_phase_branch_gap),
    "scientific_corrections": [],
}
output = Path(__file__).with_suffix(".json")
output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
