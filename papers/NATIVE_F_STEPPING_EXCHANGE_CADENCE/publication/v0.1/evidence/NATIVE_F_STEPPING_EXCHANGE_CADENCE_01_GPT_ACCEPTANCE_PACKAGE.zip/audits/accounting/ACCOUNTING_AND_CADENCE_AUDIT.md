# Independent accounting and cadence audit

**Decision: PASS for F01–F06 and F10–F12, within the submitted scope.** No mathematical correction or blocking qualification is required in these sections. This is a proof/source audit, not publication authorization or a receiving-and-recovery theorem for the hybrid.

## Reviewed material

- Submitted `NATIVE_F_STEPPING_EXCHANGE_CADENCE_01_PROOF_REVIEW.md`, assigned sections F01–F06 and F10–F12.
- Original issued `NATIVE_F_STEPPING_EXCHANGE_CADENCE_01_GPT_ANALYTICAL_START.md`.
- Actual native source `inputs/sources/native_code/dynamics.py`, read as text only.
- Accepted RX sources `wellposed.tex`, `hybrid.tex`, and `accounts.tex`.
- Accepted PC source `projection.tex`, including the arbitrary-preload and zero-drive qualifications.

## Findings

| Sections | Result and reason |
|---|---|
| F01 | The three-node prestage and synchronization agree with the source formula, including simultaneous evaluation, the zero convention, and the zero-strength bypass. Mathematical exactness is kept separate from floating-point evaluation. Exchange-first changes, resets, and coefficient scaling have not been introduced. |
| F01–F02 | The inherited global mild theorem actually supplies the assumptions used. Its proof constructs local mild solutions before using conservation, obtains H¹ strong solutions from H¹ preparation and H¹ tents, then passes integrated work identities to L² preparations by approximation. No H² tent regularity or differentiation of a general L² carrier is needed. The finite-dimensional native and receiver coordinates are C¹. |
| F02 | The finite-round index range is correct: a pre-jump initial state through N completed rounds includes jumps 0 through N−1. The arbitrary-window post-jump convention instead counts left-open/right-closed jumps. External coordinates do not jump, so no impulsive interface work enters. Per-port positive/negative parts are taken before summing. |
| F03 | Subtracting the native baseline gives exactly ΔH_N−B_N=E_a−E_b. Both recovery ratios require E_a>0; the adjusted ratio is at most one and is nonnegative precisely when E_b≤E_a. Initially empty external stores, a positive supply denominator, and the additional no-backflow condition for gross receiving retain their distinct roles. No positive recovery lower bound is inferred. |
| F04 | The two invariants Z₂ and j give L=α max(|Z₂|,j)/2. The native derivative calculation is valid for mild solutions because the native coordinates are C¹ and the port average is continuous. L is constant during exchange; C=H_N−L generally is not. The preload bound −E_n≤E(t)−E_n≤C(FΩ_n), the native-jump identity ΔC=b−ΔL, and the indexed cumulative floor bound all follow with correct signs and indices. No bound on total preloaded E by C alone is asserted. |
| F05 | The simultaneous launch prestage gives ΔI=2d₀²−4g(2−3g)(1−cos φ)=1/50000000−(13/100)(1−cos φ). The full finite square is retained. The rational positive and negative witnesses, unique threshold, and divergence of the ratio to the old vanishing launch ceiling are consistent. That ratio is not described as available capacity or efficiency. |
| F06 | The modulus identity for component 1 and the strictly positive component 3-minus-1 squared-modulus difference prove exit from the exact launch family. They do not prove exit from the larger coherent domain. A longer interval cannot supply missing initial hypotheses of the old theorem; the proof correctly avoids concluding that the old receiving/recovery behavior is impossible. |
| F10 | Strong continuity at the fixed state F̂X proves T_hX→F̂X without any continuity assumption on F at X. When F̂X≠X, the difference quotient norm diverges. For a fixed finite N, the additional continuity assumptions at every encountered native state, together with the inherited bounded-energy Lipschitz flow estimate, justify the induction. Neither N≈T/h nor uniform infinite-step dependence follows. The coherent launch native-only orbit has the inherited nonzero-prestage qualification; active hybrid preservation is not inferred. |
| F11 | A real native state has zero chirality and remains real under the mathematical native map, including zero prestages. With empty external stores its exchange segment is stationary by the inherited uniqueness theorem. At the aligned first jump the positive baseline is entirely a floor increment: ΔL=b and ΔC=0. The proof excludes the endpoint φ=0 from the strictly positive receiving launch and does not assert bitwise floating-point darkness or stationarity under arbitrary preload. |
| F12 | The status statement is supported: finite accounts, qualified cadence limits, and the dark witness do not establish later hybrid receiving/recovery, a selected cadence, a physical clock, a recurrent orbit, or a uniform infinite-step bound. |

## Inherited results versus present deductions

The exact native intensity identity, ordered F-first hybrid balance, global exchange well-posedness and dependence, integrated mild work accounts, retained receiver-stock ratio, and general projection-invariant ceiling are inherited results. The submission identifies them as such and uses their actual source hypotheses.

The explicit launch specialization and sign threshold, family-exit argument, moving-floor/jump-capacity bookkeeping, fixed-state small-h and qualified fixed-N limits, and real-state floor-gain witness are deductions verified in this audit. The argument does not promote the original analytical-start memo to an independent authority; its formulas are checked against the actual source equations and elementary algebra.

## Qualifications that must remain in any later presentation

1. F10's fixed-N convergence needs continuity of F at the finitely many encountered native states. Nonzero prestages suffice; the zero convention alone does not give general neighboring continuity.
2. The floor is invariant only inside an exchange segment and changes at a native jump. Capacity is a state-dependent ceiling and generally changes even during exchange.
3. Existing external preload must remain in stock and recovery accounts. The old empty-launch theorem cannot be re-applied after arbitrary hybrid rounds.
4. F11's stationary-dark conclusion requires empty external preparation and refers to the exact mathematical map.
5. No later receiving-and-recovery theorem or selected physical cadence is established.

The submitted text already contains these qualifications. No revision is requested from this audit.

## Audit conduct

Only text/source reads and creation of these internal audit artifacts were performed. Submitted scripts were not executed; no Git operation, source mutation, publication, or successor investigation was performed by this auditor. F07–F09 and package integrity are outside this audit assignment and require the other reviewers' results.
