"""Independent read-only provenance audit; submitted code is never imported or run."""
from __future__ import annotations

import ast
import datetime as dt
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

ROOT = Path('/workspace/scratch/ec350561671b')
HERE = Path(__file__).resolve().parent
SUB = ROOT / 'native_f_cadence_01/gpt_review/submission'
ORIGINAL = ROOT / 'native_f_cadence_01/packet'
OUTPUT = ROOT / 'output'
UPLOAD = ROOT / 'upload'
TASK = 'NATIVE_F_STEPPING_EXCHANGE_CADENCE_01'
checks = []


def check(name, condition, **details):
    row = {'name': name, 'status': 'PASS' if condition else 'FAIL'}
    row.update(details)
    checks.append(row)
    return bool(condition)


def load(path):
    return json.loads(path.read_bytes())


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def check_zip(path, expected_count):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        safe = all(not n.startswith('/') and '\\' not in n and ':' not in n
                   and '..' not in PurePosixPath(n).parts and not n.endswith('/')
                   for n in names)
        links = [i.filename for i in infos if stat.S_ISLNK(i.external_attr >> 16)]
        check(path.name + ':safe_unique_members', safe and not links
              and len(names) == len(set(names)) == expected_count,
              members=len(names), symlinks=links)
        check(path.name + ':CRC', archive.testzip() is None)
        return {n: archive.read(n) for n in names}


archive_path = UPLOAD / f'{TASK}_REVIEW_PACKAGE.zip'
archive_data = archive_path.read_bytes()
external = load(UPLOAD / 'PACKAGE_VERIFICATION(6).json')
sidecar = (UPLOAD / f'{TASK}_REVIEW_PACKAGE.zip.sha256').read_text().split()
archive_identity = identity(archive_data)
check('review_archive_external_sha256', archive_identity['sha256'] == sidecar[0]
      == external['archive']['sha256']
      == 'c11fb2373911ff33a4e0856f50c6b10e6c833bce7f07b175a7c3e39598b6d4f6')
check('review_archive_external_length', archive_identity['bytes']
      == external['archive']['bytes'] == 2515295)
members = check_zip(archive_path, 201)
manifest = load(SUB / 'REVIEW_MANIFEST.json')
manifest_rows = {r['path']: r for r in manifest['files']}
check('review_manifest_exhaustive', len(manifest_rows) == len(manifest['files']) == 200
      and set(manifest_rows) == set(members) - {'REVIEW_MANIFEST.json'}
      and manifest['self_excluded'] == 'REVIEW_MANIFEST.json'
      and manifest['payload_count'] == 200)
external_rows = {r['path']: r for r in external['files']}
check('external_receipt_exhaustive', len(external_rows) == len(external['files']) == 201
      and set(external_rows) == set(members))
archive_rows = []
for name, data in members.items():
    actual = identity(data)
    mr = manifest_rows.get(name)
    er = external_rows[name]
    extraction_match = (SUB / name).read_bytes() == data
    manifest_match = mr is None or all(mr[k] == v for k, v in actual.items())
    external_match = all(er[k] == v for k, v in actual.items()) and er['CRC'] == 'PASS'
    archive_rows.append({'path': name, **actual, 'extraction_match': extraction_match,
                         'manifest_match': manifest_match, 'external_receipt_match': external_match})
check('all_archive_bytes_manifests_and_extracted_copies', all(
    r['extraction_match'] and r['manifest_match'] and r['external_receipt_match']
    for r in archive_rows), count=len(archive_rows))
check('extraction_has_exact_archive_file_set',
      {str(p.relative_to(SUB)) for p in SUB.rglob('*') if p.is_file()} == set(members))
standalone_names = [f'{TASK}_PROOF_REVIEW.md', f'{TASK}_CLAIM_SOURCE_LEDGER.md', 'CADENCE_STATUS.md']
check('three_standalone_documents_match_archive', all(
    (UPLOAD / n).read_bytes() == members[n] for n in standalone_names), count=3)

issued_path = OUTPUT / f'{TASK}_CODEX_PACKET.zip'
issued_members = check_zip(issued_path, 164)
issued_identity = identity(issued_path.read_bytes())
issued_manifest = json.loads(issued_members['PACKET_MANIFEST.json'])
issued_manifest_rows = {r['path']: r for r in issued_manifest['files']}
check('issued_manifest_exhaustive_and_valid', len(issued_manifest_rows) == 163
      and set(issued_manifest_rows) == set(issued_members) - {'PACKET_MANIFEST.json'}
      and all(all(row[k] == v for k, v in identity(issued_members[name]).items())
              for name, row in issued_manifest_rows.items()))
check('issued_sidecar_original_archive', issued_identity['sha256']
      == (OUTPUT / f'{TASK}_CODEX_PACKET.zip.sha256').read_text().split()[0]
      == '439406dc9deead26f13bef68afbdd5de6c66c8e3c8fadfa8f5695d925be172a1')
check('all_164_retained_original_and_returned_members_equal', all(
    data == (ORIGINAL / name).read_bytes() == (SUB / 'inputs' / name).read_bytes()
    for name, data in issued_members.items()), count=164)

mapping = load(SUB / 'INPUT_PACKAGE_MAPPING.json')
baseline = load(SUB / 'INPUT_BASELINE.json')['files']
after = load(SUB / 'INPUT_AFTER.json')['files']
preservation = load(SUB / 'INPUT_PRESERVATION.json')
preservation_rows = {r['path']: r for r in preservation['files']}
original_keys = {r['original_path'] for r in mapping['records']}
review_keys = {r['review_path'] for r in mapping['records']}
expected_review_keys = {'inputs/' + n for n in issued_members} | {
    'incoming/' + f'{TASK}_' + suffix for suffix in (
        'CODEX_PACKET.zip', 'CODEX_PACKET.zip.sha256', 'CODEX_WORK_ORDER.md',
        'GPT_ANALYTICAL_START.md', 'PACKAGE_VERIFICATION.json')}
check('input_mapping_exact_169_occurrences', len(mapping['records']) == mapping['count'] == 169
      and len(original_keys) == len(review_keys) == 169 and review_keys == expected_review_keys
      and original_keys == set(baseline) == set(after) == set(preservation_rows))
input_rows = []
for row in mapping['records']:
    name = row['review_path']
    retained = (OUTPUT / name.removeprefix('incoming/') if name.startswith('incoming/')
                else ORIGINAL / name.removeprefix('inputs/'))
    original_data = retained.read_bytes()
    actual = identity(original_data)
    key = row['original_path']
    pr = preservation_rows[key]
    input_rows.append({'review_path': name, 'retained_original_path': str(retained), **actual,
        'returned_bytes_equal_retained_original': original_data == (SUB / name).read_bytes(),
        'mapping_matches': all(row[k] == v for k, v in actual.items()),
        'both_snapshots_match_original': baseline[key] == after[key] == actual,
        'preservation_record_matches': pr['before'] == pr['after'] == actual and pr['unchanged'] is True})
check('all_169_inputs_match_independently_retained_originals', all(
    all(r[k] for k in ('returned_bytes_equal_retained_original', 'mapping_matches',
        'both_snapshots_match_original', 'preservation_record_matches')) for r in input_rows), count=169)
input_verification = load(SUB / 'INPUT_VERIFICATION.json')
check('input_verification_records_reconcile', input_verification['archive'] == issued_identity
      and input_verification['safe_unique_members'] == 164
      and input_verification['manifest_payloads'] == 163
      and input_verification['protected_input_occurrences'] == preservation['protected_occurrences'] == 169
      and preservation['all_unchanged'] is True)

source_inventory = load(SUB / 'inputs/SOURCE_IDENTITIES.json')
source_rows = {r['packet_path']: r for r in source_inventory['sources']}
source_verification = load(SUB / 'SOURCE_VERIFICATION.json')
reported_sources = {r['packet_path']: r for r in source_verification['files']}
check('source_inventory_sets_exact_144', len(source_rows) == len(source_inventory['sources'])
      == source_inventory['source_count'] == source_verification['source_files'] == 144
      and set(source_rows) == set(reported_sources))
source_audit = []
for name, row in source_rows.items():
    data = (SUB / 'inputs' / name).read_bytes()
    actual = {**identity(data), 'git_blob': blob(data)}
    source_audit.append({'path': name, **actual,
        'source_inventory_matches': all(row[k] == v for k, v in actual.items()),
        'source_verification_matches': all(reported_sources[name][k] == v for k, v in actual.items()),
        'retained_original_matches': data == (ORIGINAL / name).read_bytes()})
check('all_144_source_sha256_git_blob_identities', all(
    r['source_inventory_matches'] and r['source_verification_matches'] and r['retained_original_matches']
    for r in source_audit), count=144)

locators = load(SUB / 'SOURCE_LOCATORS.json')
proof_path = SUB / f'{TASK}_PROOF_REVIEW.md'
proof = proof_path.read_text()
proof_lines = proof.splitlines()
ledger = (SUB / f'{TASK}_CLAIM_SOURCE_LEDGER.md').read_text()
locator_audit = []
for key, row in locators['locators'].items():
    data = (SUB / row['path']).read_bytes()
    text = data.decode('utf-8')
    line = text.splitlines()[row['line'] - 1]
    src_name = row['path'].removeprefix('inputs/')
    src = source_rows[src_name]
    expected_url = (f"https://github.com/pzychozen/trioctagon-physics/blob/{src['commit']}/"
                    f"{src['repository_path']}#L{row['line']}")
    target_match = (('\\label{' + row['key'] + '}') in line if row['kind'] == 'TeX label'
                    else bool(re.search(r'\b(?:def|class)\s+' + re.escape(row['key']) + r'\b', line)))
    ledger_text = f"{row['path']} — {row['key']}, line {row['line']}."
    locator_audit.append({'locator': key, 'path': row['path'], 'line': row['line'],
        'line_text_matches': line == row['line_text'], 'target_definition_matches': target_match,
        'identity_matches': row['sha256'] == identity(data)['sha256'] and row['git_blob'] == blob(data),
        'immutable_url_matches_source_inventory': row['immutable_url'] == expected_url,
        'ledger_contains_exact_locator': ledger_text in ledger})
check('all_56_source_locators_resolve', len(locator_audit) == locators['unique_source_locator_count'] == 56
      and all(all(v for k, v in row.items() if k.endswith('matches') or k.endswith('locator')
                  and k != 'locator' or k == 'immutable_url_matches_source_inventory')
              for row in locator_audit), count=len(locator_audit))
claim_ids = [r['id'] for r in locators['claims']]
expected_ids = [f'F{i:02}' for i in range(1, 13)]
check('all_12_claim_and_proof_sections', claim_ids == expected_ids
      and re.findall(r'^## (F\d\d)\b', proof, re.M) == expected_ids
      and re.findall(r'^## (F\d\d)\b', ledger, re.M) == expected_ids)
check('all_claim_proof_headings_and_source_references', all(
    proof_lines[r['proof']['line'] - 1] == r['proof']['heading']
    and r['proof']['path'] == proof_path.name
    and all(k in locators['locators'] for k in r['source_locators'])
    and f"Proof {r['id']} (line {r['proof']['line']});" in ledger
    for r in locators['claims']))
tags = re.findall(r'\\tag\{(\d+)\}', proof)
check('59_unique_equation_tags', len(tags) == len(set(tags)) == 59
      and set(tags) == {str(i) for i in range(1, 60)})
documents = standalone_names + ['CORRECTIONS_AND_LIMITS.md', 'COMPLETION_REPORT.md', 'READ_ME_REVIEW.md']
check('utf8_no_replacement_characters', all('\ufffd' not in (SUB / n).read_text(encoding='utf-8') for n in documents))
check('proof_display_delimiters_balanced', proof.count('\\[') == proof.count('\\]'))

corrections = (SUB / 'CORRECTIONS_AND_LIMITS.md').read_text()
old_one = 'sources/SOURCE_IDENTITIES.json'
old_prefix = 'publish_order/packet/publication_payload/papers/NATIVE_CAPACITY_RECEIVING_RECOVERY/publication/v0.1/'
check('two_stale_paths_correctly_identified_and_resolved',
      old_one in (SUB / 'inputs/analysis/NATIVE_MAP_AND_FIRST_JUMP.md').read_text()
      and not (SUB / 'inputs' / old_one).exists()
      and (SUB / 'inputs/SOURCE_IDENTITIES.json').is_file()
      and old_prefix in (SUB / 'inputs/analysis/CADENCE_LIMITS_AND_POSTF_LOCAL_GEOMETRY.md').read_text()
      and not (SUB / 'inputs' / old_prefix).exists()
      and (SUB / 'inputs/sources/receiving_recovery/publication/v0.1').is_dir()
      and all(s in corrections for s in (old_one, old_prefix, 'inputs/SOURCE_IDENTITIES.json',
            'inputs/sources/receiving_recovery/publication/v0.1/')))

algebra = load(SUB / 'INDEPENDENT_ALGEBRA_RESULTS.json')
algebra_log = load(SUB / 'INDEPENDENT_ALGEBRA_EXECUTION.log')
groups = {r['name']: r['results'] for r in algebra['groups']}
check('eight_algebra_group_records_and_log', len(groups) == len(algebra['groups']) == algebra['group_count'] == 8
      and all(r['status'] == 'PASS' for r in algebra['groups']) and algebra_log == algebra)
check('independent_algebra_script_hash_binding',
      identity((SUB / 'independent_algebra.py').read_bytes())['sha256'] == algebra['script_sha256'])
support = load(SUB / 'SUPPORT_COMPARISON.json')
replay_rows = []
for r in support['records']:
    name = r['script']
    data = (SUB / 'support_replay' / name).read_bytes()
    stdout = (SUB / 'support_replay' / (name + '.stdout.json')).read_bytes()
    replay_rows.append({'script': name,
        'script_matches_original_and_supplied_copy': data == (SUB / 'inputs/analysis' / name).read_bytes()
            == (ORIGINAL / 'analysis' / name).read_bytes(),
        'script_hash_binding': identity(data)['sha256'] == r['unchanged_copy_sha256'],
        'stdout_hash_binding': identity(stdout)['sha256'] == r['stdout_sha256'],
        'recorded_returncode_zero': r['returncode'] == 0,
        'stdout_status_pass': json.loads(stdout)['status'] == 'PASS',
        'stderr_empty': (SUB / 'support_replay' / (name + '.stderr.txt')).read_bytes() == b'',
        'recorded_start_after_independent_result': dt.datetime.fromisoformat(r['started_utc'])
            > dt.datetime.fromisoformat(algebra['utc'])})
check('two_replay_records_bind_to_preserved_bytes', len(replay_rows) == support['supplied_checker_replays'] == 2
      and all(all(v for k, v in r.items() if k != 'script') for r in replay_rows))
first = load(SUB / 'support_replay/first_jump_algebra.py.stdout.json')
local = load(SUB / 'support_replay/exact_local_checks.py.stdout.json')
check('first_replay_result_equals_supplied_result', first
      == load(SUB / 'support_replay/FIRST_JUMP_ALGEBRA.json')
      == load(SUB / 'inputs/analysis/FIRST_JUMP_ALGEBRA.json'))
g3 = groups['A03_two_rational_witnesses']
g4 = groups['A04_source_bound_constants_and_signs']
g5 = groups['A05_postsync_derivative_and_capacity_Q']
g7 = groups['A07_dark_boundary_and_branch_gap']
equal_pairs = [(first['threshold_one_minus_cos_phi'], g3['D_threshold']),
    (first['prestage_cross12_sin_coefficient'], g4['A_star']),
    (first['synchronization_gap_factor'], g4['s_star']),
    (first['uniform_drive_lower_bound_coefficient_G2_sin2phi'], g4['norm_lower_coefficient_over_G_squared_sin_squared']),
    (first['aligned_native_image'], g5['r']), (first['aligned_post_I_and_Z2'], g7['I_equals_Z2']),
    (first['aligned_post_he'], g7['h_e']), (first['aligned_post_j'], g7['j']),
    (first['exact_sign_bounds'][0]['delta_I_lower'], g3['delta_I_lower']),
    (first['exact_sign_bounds'][1]['delta_I_upper'], g3['delta_I_upper']),
    (local['r'], g5['r']), (local['b'], g5['u']), (local['s'], g4['s_star']),
    (local['postF_imaginary_derivative'], g5['t']), (local['chiral_derivative'], g5['r_cross_t']),
    (local['Q'], g5['Q']), (local['joint_capacity_ratio_limit'], g5['capacity_ratio_limit']),
    (local['kernel_projection_at_zero'], g7['C_projection_over_alpha'])]
check('18_shared_exact_quantities_reconcile', all(a == b for a, b in equal_pairs), count=len(equal_pairs))
doc_checks = load(SUB / 'DOCUMENT_CHECKS.json')
check('submitted_document_counts_reconcile', doc_checks['claim_sections'] == 12
      and doc_checks['unique_equation_tags'] == 59 and doc_checks['resolved_source_locators'] == 56
      and doc_checks['independent_algebra_groups'] == 8 and doc_checks['support_replays'] == 2)

# Static inspection is limited to imports and calls. It does not establish execution history.
static_rows = []
for name in ('independent_algebra.py', 'replay_support.py', 'prepare_inputs.py', 'make_ledger.py', 'verify_and_package.py'):
    tree = ast.parse((SUB / name).read_text())
    imports = sorted({a.name for node in ast.walk(tree) if isinstance(node, ast.Import) for a in node.names}
        | {node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)})
    calls = sorted({ast.unparse(node.func) for node in ast.walk(tree) if isinstance(node, ast.Call)})
    static_rows.append({'path': name, 'imports': imports, 'call_targets': calls,
                        'submitted_code_executed_by_this_audit': False})
scope = load(SUB / 'WORKSPACE_SCOPE.json')
check('workspace_record_correctly_bounds_preservation_claim',
      scope['Git_commands_executed'] is False
      and scope['original_checkout_read_or_written_by_scientific_scripts'] is False
      and scope['repository_modules_imported'] is False
      and scope['repository_mutation'] is False
      and scope['prior_publication_snapshots_are_historical'] is True
      and 'No fresh original-checkout snapshot was taken' in scope['preservation_scope']
      and 'no equality claim about all live checkout files is made' in scope['preservation_scope'])

result = {
    'task': TASK, 'audit': 'Independent package and provenance audit',
    'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'status': 'PASS' if all(r['status'] == 'PASS' for r in checks) else 'FAIL',
    'audit_script_sha256': identity(Path(__file__).read_bytes())['sha256'],
    'archive': {'path': str(archive_path), **archive_identity},
    'check_count': len(checks), 'checks': checks,
    'archive_file_records': archive_rows, 'input_occurrence_records': input_rows,
    'source_identity_records': source_audit, 'source_locator_records': locator_audit,
    'replay_record_consistency': replay_rows, 'submitted_script_static_inventory': static_rows,
    'workspace_scope_record': scope,
    'scope_and_limits': [
        'Only independently written audit code was executed. Submitted code was read as text or parsed as AST, never imported or run.',
        'No Git command, remote retrieval, scientific trajectory or successor investigation was performed by this audit.',
        'All 169 returned input occurrences were compared against independently retained original bytes; this establishes the preservation of supplied materials.',
        'Git blob identifiers were reconstructed locally from file bytes, not queried from a live remote.',
        'Algebra and replay checks here establish record and artifact consistency, not independent mathematical proof or independent observation of the submitted execution.',
        'Recorded timestamps place independent results before replays; they do not prove when source implementations were first read.',
        'The Windows checkout was not accessible to this audit. Submitted records expressly make no fresh checkout-wide equality claim; absence of prior actions cannot be proved by these files alone.',
        'The two stale source paths are documentary corrections; all issued inputs remain byte-identical to the retained originals.'
    ]
}
target = HERE / 'PACKAGE_AND_PROVENANCE_AUDIT.json'
target.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'checks': len(checks),
    'failed': [r for r in checks if r['status'] != 'PASS'], 'result': str(target)}, indent=2))
