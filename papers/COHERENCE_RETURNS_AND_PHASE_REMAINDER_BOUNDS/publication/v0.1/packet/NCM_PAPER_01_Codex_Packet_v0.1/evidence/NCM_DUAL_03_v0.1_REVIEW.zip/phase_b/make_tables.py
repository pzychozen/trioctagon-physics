"""Readable summaries from retained numbers only; zero native evaluations."""
import importlib.util,json,pathlib
import mpmath as mp
ROOT=pathlib.Path(__file__).resolve().parent
mp.mp.dps=80
def fmt(x,n=10):return mp.nstr(mp.mpf(x),n)
summary=json.loads((ROOT/'discovery_summary.json').read_text())
lines=['# All prescribed attempts','',
 'Numerical outcomes only. Relative return errors use raw state norm. LP1 means numerical coherence period one, not a certified root. No permutation or conjugation identification is applied.','',
 '| Seed | Iteration passes | F calls | Outcome / stop | Relative return error | Minimum prestage modulus |',
 '|---|---:|---:|---|---:|---:|']
for small in summary['attempts']:
 row=json.loads((ROOT/'attempts'/f"{small['id']}.json").read_text());m=row.get('metrics')
 lines.append(f"| {row['id']} | {len(row['iterations'])} | {row['F_attempts']} | {row['classification']} / {row['stop_reason']} | {fmt(m['return_relative']) if m else 'n/a'} | {fmt(m['min_prestage_modulus']) if m else 'n/a'} |")
(ROOT/'ATTEMPTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
groups=json.loads((ROOT/'numerical_groups.json').read_text())['groups']
lines=['# Numerical lower-period groups and readouts','',
 'These seven groups summarize 42 nominal lower-period solutions. They are not interval-validated roots or a complete branch classification. All H matrices and raw transitions remain in numerical_groups.json and attempts/*.json. Readout stages below are from the actual three native updates evaluated by the solver, not from a formula-generated continuation.','',
 '| Group / representative | Seed members | Three-step fitted phase (rad) | Largest relative H separation | Minimum prestage modulus |',
 '|---|---|---:|---:|---:|']
for g in groups:
 lines.append(f"| {g['group']} / {g['representative_seed']} | {', '.join(m['seed'] for m in g['members'])} | {fmt(g['mu_three_angle_radians'],14)} | {fmt(g['max_H_separation'])} | {fmt(g['min_prestage_modulus'])} |")
lines+=['','| Group | j(z0) | j(z1) | j(z2) | j(z3) |','|---|---:|---:|---:|---:|']
for g in groups:lines.append('| '+g['group']+' | '+' | '.join(fmt(x,16) for x in g['j_stages'])+' |')
lines+=['','H0,H1,H2 are numerically identical at the stated tolerance in every group. The fitted three-step phase is not a minimal coherence period. In an exact relative return, K(mu z)=mu K(z) implies j(F^(3m)z)=Im(mu^m K(z)); no extra native blocks were run and no EMA memory or clock was advanced. No exact finite order of these numerical multipliers is inferred.']
(ROOT/'READOUTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines[:15]))
