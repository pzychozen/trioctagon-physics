import importlib.util,json,pathlib
import mpmath as mp
ROOT=pathlib.Path(__file__).resolve().parent
local=ROOT/'native_math.py'
spec=importlib.util.spec_from_file_location('ncm_native_math',local if local.exists() else ROOT.parent/'native_math.py')
nm=importlib.util.module_from_spec(spec);spec.loader.exec_module(nm)

def number(x):return mp.nstr(x,90)
def encode(x):
 if isinstance(x,mp.matrix):return [[encode(x[i,j]) for j in range(x.cols)] for i in range(x.rows)]
 if isinstance(x,(mp.mpf,mp.mpc)):
  if isinstance(x,mp.mpc):return {'re':number(x.real),'im':number(x.imag)}
  return number(x)
 if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [encode(v) for v in x]
 return x
def decode_matrix(rows):
 return mp.matrix([[mp.mpc(x['re'],x['im']) if isinstance(x,dict) else mp.mpf(x) for x in row] for row in rows])
def save(name,data):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(encode(data),indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def pure_record(rec):
 return {'states':rec['states'],'stages':[{'V':r['V'],'kicks':r['kicks']} for r in rec['stages']]}

def metrics(x,pivot,rec):
 z=nm.unpack(x);mu=mp.mpc(x[6],x[7]);states=rec['states']
 norm=mp.norm(z);H=[nm.coherence(t) for t in states]
 denom=norm**2 if norm!=0 else mp.mpf(1)
 residual=mp.norm(states[3]-mu*z)
 seps=[mp.norm(H[i]-H[j])/denom for i,j in ((0,1),(0,2),(1,2))]
 corr=nm.correlate(z,states[3]) if norm!=0 else None
 return {'norm':norm,'max_modulus':nm.maxnorm(z),'pivot_real':z[pivot].real,
 'return_abs':residual,'return_relative':residual/norm if norm else mp.inf,
 'circle_error':abs(abs(mu)**2-1),'gauge_error':abs(z[pivot].imag),'mu_fitted':mu,'mu_corr':corr,
 'norm_return_relative':abs(mp.norm(states[3])-norm)/norm if norm else mp.inf,
 'min_prestage_modulus':min(abs(v) for r in rec['stages'] for v in r['V']),
 'pairwise_H_relative_separations_01_02_12':seps,'H_return_relative':mp.norm(H[3]-H[0])/denom,
 'H':H,'j':[mp.im(nm.cubic(t)) for t in states],
 'one_step_mu_corr':nm.correlate(z,states[1]) if norm else None,
 'one_step_phase_residual':mp.norm(states[1]-nm.correlate(z,states[1])*z)/norm if norm else mp.inf}

def classify(m):
 if m['norm']<mp.mpf('1e-25'):return 'zero_or_near_zero'
 if m['return_abs']>mp.mpf('1e-45') or m['return_relative']>mp.mpf('1e-40') or m['circle_error']>mp.mpf('1e-45') or m['gauge_error']>mp.mpf('1e-45'):
  return 'solver_failed'
 if m['max_modulus']>mp.sqrt(mp.mpf(1001)/1000)+mp.mpf('1e-35'):return 'necessary_amplitude_bound_violation'
 if m['pivot_real']<=mp.mpf('1e-25') or m['min_prestage_modulus']<=mp.mpf('1e-20'):return 'singular_or_near_degenerate'
 seps=m['pairwise_H_relative_separations_01_02_12']
 if max(seps)<mp.mpf('1e-25') and m['one_step_phase_residual']<mp.mpf('1e-25'):
  return 'lower_period_one_numerical'
 if min(seps)>mp.mpf('1e-12'):return 'unvalidated_period_three_candidate'
 return 'unresolved_H_separation'
