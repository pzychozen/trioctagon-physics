# NCM-DUAL-03 v0.1 — Native three-update coherence returns

## Give Codex this packet

Execute `WORK_ORDER.txt`. The investigation asks whether the unchanged native map at one previously studied parameter point has a genuinely three-stage **raw-coherence** return, and what phase remainder follows. It does not prescribe a twelve-update orbit.

Use Windows Command Prompt and the existing `torment` environment. Work only in a fresh external research directory. The exact paths, execution ceilings, source route and stop conditions are in the work order. No source-tree installation or `apply_candidate.py` command is needed.

## Contents and their roles

- `WORK_ORDER.txt`: controlling new assignment and scientific boundaries.
- `GPT_MATHEMATICAL_BRIEF.md`: proposed amplitude lemma, root formulation and existing-readout consequences, for independent review.
- `DISCOVERY_PLAN.json`: one exact coefficient tuple, 60 deterministic root-solver guesses and bounded computation. **Not executed.** Codex freezes actual solver choices before searching.
- `context/NCM_DUAL_02_REPORT.md`: unchanged prior report.
- `context/NCM_DUAL_02_GPT_REVIEW.md`: unchanged prior GPT review, including the conditional phase-sensitive diagnostic.
- `context/PRIOR_SOURCE_MANIFEST.json`: prior bounded source paths/hashes, not a present checkout certificate.
- `CONTEXT_LINEAGE.json`: provenance of the supplied copies.
- `PREPARATION_CHECKS.json`: packet and rational-arithmetic checks only, zero native evaluations.
- `MANIFEST.json`: exact byte identities of every other file in the packet.

Codex creates and tests the new research scripts; this packet is not a ready-run orbit solver. Do not replay the previous study merely because its report is included.

## Fixed mathematical point

`eps=1/10, g=1/60, lambda=1/300, k=(999/1000,1,1001/1000)`.

Target: `F^3(z)=mu*z`, `|mu|=1`, all three prestages regular, and minimal raw-coherence period three. The phase `mu` is unknown. Norm is not normalized away.

Analytical feasibility comes first. The proposed bound could reduce the search, but Codex must independently verify it. A proof of scoped exclusion can end the search. An unsuccessful finite search cannot be reported as a global absence theorem.

## One message to Codex

> Execute NCM-DUAL-03 v0.1 using the attached packet. Keep the published coefficients fixed, leave the return phase unknown, and independently verify the analytical bounds before the bounded state search. Validate any genuinely three-stage return or report the precise exclusion/uncertainty. Use Command Prompt and the existing torment environment. No Git, application/kernel changes, added motion law or publication. Return the complete bounded review package.
