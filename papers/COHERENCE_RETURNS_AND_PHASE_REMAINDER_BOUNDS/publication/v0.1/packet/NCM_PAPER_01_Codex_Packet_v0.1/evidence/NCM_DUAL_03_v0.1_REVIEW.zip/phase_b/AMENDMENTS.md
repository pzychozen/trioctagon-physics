# Chronology and plan amendments

1. Stage A began from the standalone work order. The companion packet was missing; no discovery was performed. The analytical deductions, implementation checks and explicitly interim snapshot were retained in the parent directory. That snapshot remains unchanged.
2. The author supplied `NCM_DUAL_03_Codex_Packet_v0.1.zip`. It was hashed and safely extracted under this fresh research root. The work order and prior report/manifest match the earlier inputs exactly. The mathematical brief's amplitude proof was independently checked against Stage A; no scientific conflict was found.
3. Amendment 01 resolved the missing input. The complete supplied 60-seed plan and actual solver were frozen in this directory at the timestamp in PLAN_FREEZE.json, with zero discovery evaluations before freezing.
4. All 60 starts were then executed once. There were no post-result solver changes, seed additions, parameter changes, chart restarts, phase targets, budget extensions or hidden retries. The direct regression pass was part of the frozen plan.

The final report in this directory supersedes only the interim task-status statement, not the preserved evidence. The older Stage A statements correctly describe what was available when they were written.
