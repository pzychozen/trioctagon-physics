import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
P=ROOT/'packet/NCM_DUAL_03_Codex_Packet_v0.1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'MANIFEST.json').read_text())
print('MANIFEST SCHEMA',json.dumps(manifest,indent=2))
comparison={
 'work_order_identical':sha(P/'WORK_ORDER.txt')==sha(ROOT.parent/'inputs/CODEX_NCM_DUAL_03_NATIVE_COHERENCE_RETURN_WORK_ORDER_v0.1.txt'),
 'prior_report_identical':sha(P/'context/NCM_DUAL_02_REPORT.md')==sha(ROOT.parent/'context/ACCEPTED_NCM_DUAL_02_REPORT.md'),
 'prior_manifest_identical':sha(P/'context/PRIOR_SOURCE_MANIFEST.json')==sha(ROOT.parent/'context/PRIOR_SOURCE_MANIFEST.json')}
(ROOT/'PACKET_CONTEXT_COMPARISON.json').write_text(json.dumps(comparison,indent=2)+'\n')
print('CONTEXT',json.dumps(comparison))
plan=json.loads((P/'DISCOVERY_PLAN.json').read_text())
for key,value in plan.items():
 if isinstance(value,list) and len(value)>10:
  print('LIST',key,'LENGTH',len(value))
  for row in value:print(json.dumps(row,ensure_ascii=False))
 else:print(key,json.dumps(value,ensure_ascii=False,indent=2))
