# Stage A — analytical results before discovery

This file records independent deductions before any search seed is evaluated. The work-order summary of the proposed amplitude lemma is available; the separately named GPT mathematical brief and discovery JSON have not yet been located. Their contents are not presumed. All coefficients below are the exact published rationals, checked against COHERENT:161–168 and DYNAMICS:87–104:

    epsilon=1/10, g=1/60, lambda=1/300,
    k=(999/1000,1,1001/1000).

Let K=1001/1000, kmin=999/1000, B_R={max |z_i|<=R}, and H(z)=zz†. The target is F³(z)=mu z, |mu|=1, z≠0, with all nine three-block prestage components nonzero and all three raw coherences distinct. Fixed points and phase-drifting relative equilibria have coherence period one, not three. Near-returns are numerical findings only. Zero has no nonzero phase gauge.

## A. Amplitude absorption and the finite-return bound

Write V_i=a_i(r_i)z_i+g(z_j+z_k), with a_i(r)=1−2g+epsilon k_i−epsilon r². Synchronization preserves every component modulus, including zero.

On B3, a_i(r)>=29/30+999/10000−9/10=4997/30000>0. Put A=29/30+1001/10000=32003/30000 and h(r)=Ar−r³/10. For 0<=r<=3,

    |F_i(z)|=|V_i|<=h(r_i)+1/10.

h has its maximum at sqrt(10A/3), inside [0,3]. Its squared maximum is 40A³/27. Exact rational comparison gives 40A³/27<49/25, hence max h<7/5. Thus F(B3) is strictly inside B_(3/2). This proof uses positivity before taking the modulus; dropping the absolute value without that check would be invalid.

For any R<=3/2, h'(r)=A−3r²/10>0 on [0,R]. Therefore

    max |F_i(z)| <= R[1+(K−R²)/10] = T(R),  z in B_R.

In particular T(3/2)<3/2, so B_(3/2) is invariant; T(sqrt K)=sqrt K, so B_(sqrt K) is invariant too.

Now suppose F^p(z)=mu z with |mu|=1, p>=1, and z in B3. The last output is in B_(3/2); equality of component moduli makes the initial state lie there as well. Every state of the finite block lies there. Take R to be the largest modulus among all components of the finite block. The final moduli equal the initial moduli, so a component attaining R is an output whose input lies in B_R. If R>sqrt K, the preceding inequality gives R<=T(R)<R, a contradiction. Hence all component moduli in the block are <=sqrt K. This part does not need regularity or a prescribed mu; it uses only finite return and unchanged moduli under synchronization. Outside B3 is not classified.

## B. An additional sector exclusion

The published coherent annulus/sector theorem excludes nonstationary coherence cycles that meet its invariant domain: convergent H cannot also be a nonconstant periodic sequence. Its hypotheses are retained exactly.

There is a further exclusion for a regular finite-return block in B3: if one stage's ordinary phases fit in a closed interval of width <=pi/6, then the return is a fixed state, not coherence period three. This needs no .9 lower amplitude bound.

Proof: the amplitude lemma bounds the entire block by sqrt K, so each self coefficient is at least 29/30−1/5000>0. All input components of a regular returning block are nonzero. Each prestage is a strictly positive combination of all three input rays. In a sector narrower than pi, a positive combination lies strictly between the extreme rays unless all rays agree. Therefore, if the phase width is positive and <=pi/6, the prestage width is strictly smaller. The inherited simultaneous phase lemma (COHERENT:318–344), now on a width strictly below pi/6 with lambda=1/300, keeps the prestage interval and cannot increase its width. Iteration keeps a nested ordinary interval with strictly decreasing width. The unique short containing-arc width is invariant under a common phase, so this contradicts finite raw-coherence return unless the initial width is zero.

When all phases agree, positivity keeps that common phase exactly fixed, all kicks vanish, and the amplitude update is the existing gradient step r^+=r−grad W(r), where

    W(r)=epsilon sum_i(r_i^4/4−k_i r_i²/2)
         +(g/2)sum_(i<j)(r_i−r_j)².

On the convex cube [0,sqrt K]^3 its Hessian has maximum eigenvalue at most L=epsilon(3K−kmin)+3g=313/1250<2. Both ends and the entire amplitude step segment are in that cube. Taylor's integral formula gives W(r^+)<=W(r)−(1−L/2)||grad W(r)||². A finite return forces every increment to vanish. Thus the aligned return is fixed and mu=1. This argument uses the amplitude potential only where synchronization vanishes; it does not assume that potential decreases through general dispersed-phase synchronization.

The complementary dispersed-phase region remains unexcluded. Positivity, small parameters, and two separate stage potentials do not supply a global Lyapunov theorem. The singular prestage boundary prevents an unqualified globally smooth derivative bound.

## C. A necessary phase-remainder bound for any regular three-return

This bound leaves mu unknown and does not impose a phase target. On B_(sqrt K), write V=(I+D_z)z with D_z=epsilon diag(k−|z|²)+gL3. D_z is Hermitian with spectrum in [−251/5000,1001/10000], so

    ||V−z||_2 <= (1001/10000)||z||_2,
    ||V||_2 <= (11001/10000)||z||_2.

Each phase kick has absolute value <=2lambda=1/150. Since |exp(ix)−1|<=|x|,

    ||Fz−z||_2 <= c ||z||_2,
    c=1001/10000+(11001/10000)/150=53717/500000.

For a regular three-return, choose the cyclic start with the largest Euclidean norm among its three stages. The multiplier mu is the same for each cyclic start by regular equivariance. Telescoping the three increments then gives

    |mu−1| <= 3c=161151/500000=0.322302.

Equivalently Re(mu)>=1−(3c)²/2 and |Arg(mu)|<=2 asin(3c/2). In particular mu cannot equal +i or −i, since their distance from 1 is sqrt(2)>3c. Therefore a genuine coherence-period-three orbit in this domain, if one exists, cannot yield a minimal full-state period twelve by an order-four phase remainder. This is not a theorem excluding all native twelve-cycles with other coherence periods, all phase roots of unity, or all motion. Exact full-state period is still unknown unless the actual mu has an independently proved exact order.

## D. Gauge and evaluator specification

Use six real state coordinates and mu=a+ib, with six real equations F³(z)−mu z=0, the circle a²+b²−1=0, and Im(z_j)=0 with Re(z_j)>0. A deterministic largest-modulus seed pivot (lowest-index ties) fixes the common-phase gauge; the pivot is fixed during a solve. The state is never amplitude-normalized. The common-phase neutral direction is removed by this gauge; a nonsingular augmented Jacobian must still be verified, not presumed.

The smooth regular evaluator computes delta_i=lambda sum Im[(V_j conjugate(V_i)/(|V_j||V_i|))³]. It refuses exact zero prestages. A separate direct evaluator uses Arg0(0)=0 and explicitly retains zero outputs. No epsilon denominator is permitted. Real directional derivatives obey

    dV_i=[1−2g+epsilon(k_i−|z_i|²)]dz_i
         −2epsilon z_i Re(conjugate(z_i)dz_i)+g(dz_j+dz_k),
    dtheta_i=Im(dV_i/V_i),
    ddelta_i=3lambda sum_(j!=i) Re(u_ji³)(dtheta_j−dtheta_i),
    dF_i=exp(i delta_i)[dV_i+iV_i ddelta_i],
    u_ji=V_j conjugate(V_i)/(|V_j||V_i|).

These are real derivatives. No holomorphic or complex-step derivative is asserted. Independent real finite differences can check the implementation without defining the mathematical Jacobian.

The full discovery implementation and exact 60-seed plan cannot be finalized without the supplied DISCOVERY_PLAN.json. No replacement seeds will be invented and no discovery seed has been evaluated at this stage.
