"""One bounded, predeclared run; refuses to overwrite an attempt ledger."""
import datetime,hashlib,importlib.util,json,pathlib,time
import mpmath as mp
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('common',ROOT/'common.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
nm=c.nm

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def admissible(x,pivot):
 z=nm.unpack(x)
 if not all(mp.isfinite(v) for v in x):return 'nonfinite_trial'
 if nm.maxnorm(z)>3:return 'outside_B3'
 if x[pivot]<=0:return 'nonpositive_fixed_gauge_pivot'
 return None

def solve(seed,counter):
 start=counter.attempted
 z=c.decode_matrix(seed['state_80d']);pivot=seed['pivot_exact']
 factor=mp.conj(z[pivot])/abs(z[pivot]);zg=z*factor;zg[pivot]=mp.mpc(abs(z[pivot]),0)
 row={'id':seed['id'],'pivot':pivot,'seed':seed,'gauge_factor':factor,'iterations':[],
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 current=None;x=None
 try:
  z3,initial=nm.block(zg,counter)
  corr=(zg.H*z3)[0];fallback=(corr==0)
  mu=mp.mpc(1) if fallback else corr/abs(corr)
  row['initial_correlation_fallback']=fallback
  row['initial_mu']=mu;row['initial_block']=c.pure_record(initial)
  x=mp.matrix(list(nm.pack(zg))+[mu.real,mu.imag]);scale=max(mp.mpf(1),mp.norm(zg))
  scaling=mp.diag([1/scale]*6+[mp.mpf(1),1/scale])
  row['fixed_residual_state_scale']=scale
  stop='max_iterations'
  for iteration in range(80):
   r,J,rec=nm.residual(x,pivot,counter,jacobian=True)
   current=rec;m=c.metrics(x,pivot,rec)
   item={'iteration':iteration,'x':x.copy(),'residual':r,'merit':mp.norm(scaling*r),
         'F_attempts_at_start':counter.attempted,'trials':[]}
   row['iterations'].append(item)
   if m['norm']<mp.mpf('1e-25'):
    stop='near_zero';break
   if m['return_abs']<=mp.mpf('1e-45') and m['return_relative']<=mp.mpf('1e-40') and m['circle_error']<=mp.mpf('1e-45') and m['gauge_error']<=mp.mpf('1e-45'):
    stop='numerical_convergence';break
   try:step=mp.lu_solve(scaling*J,-scaling*r)
   except (ZeroDivisionError,ValueError) as e:
    stop='singular_augmented_Jacobian';item['linear_solve_error']=str(e);break
   item['newton_step']=step
   merit=item['merit'];accepted=False
   for back in range(21):
    t=mp.mpf(1)/(2**back);trial=x+t*step
    reason=admissible(trial,pivot)
    trial_info={'backtrack':back,'t':t,'F_attempts_before':counter.attempted}
    if reason:
     trial_info['reason']=reason;item['trials'].append(trial_info);continue
    try:rt,_,rect=nm.residual(trial,pivot,counter)
    except nm.SingularPrestage:
     trial_info['reason']='exact_zero_prestage';item['trials'].append(trial_info);continue
    value=mp.norm(scaling*rt);trial_info['merit']=value
    if value<=(1-mp.mpf('0.0001')*t)*merit:
     trial_info['reason']='accepted';item['trials'].append(trial_info)
     x=trial;current=rect;accepted=True;break
    trial_info['reason']='insufficient_merit_decrease';item['trials'].append(trial_info)
   if not accepted:stop='line_search_failed';break
  row['stop_reason']=stop
 except nm.SingularPrestage:
  row['stop_reason']='singular_initial_or_current_block'
 except nm.BudgetExceeded:
  row['stop_reason']='global_budget_exhausted'
 except Exception as e:
  import traceback
  row['stop_reason']='execution_error';row['error']=traceback.format_exc()
 if x is not None and current is not None:
  row['last_x']=x
  row['last_block']=c.pure_record(current)
  row['metrics']=c.metrics(x,pivot,current)
  row['classification']=c.classify(row['metrics'])
 else:row['classification']='singular_or_unresolved_initial_block'
 row['F_attempts']=counter.attempted-start
 row['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return row

def main():
 mp.mp.dps=80
 freeze=json.loads((ROOT/'PLAN_FREEZE.json').read_text())
 for name,digest in freeze['sha256'].items():assert sha(ROOT/name)==digest,name
 plan=json.loads((ROOT/'resolved_plan.json').read_text())
 assert len(plan['seeds'])==60 and plan['parameters']==nm.PARAMETERS
 ledger=ROOT/'attempt_ledger.jsonl';assert not ledger.exists(),'Do not silently rerun discovery.'
 counter=nm.Counter(limit=120000,label='discovery')
 summary={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempts':[],
 'plan_freeze':freeze,'counter_start':counter.record()}
 with ledger.open('x',encoding='utf-8') as stream:
  for seed in plan['seeds']:
   if counter.attempted>=120000:
    row={'id':seed['id'],'stop_reason':'not_started_global_budget','classification':'budget_exhausted','F_attempts':0,'iterations':[]}
   else:row=solve(seed,counter)
   c.save('attempts/'+seed['id']+'.json',row)
   compact={k:row[k] for k in ('id','stop_reason','classification','F_attempts')}
   compact['iterations']=len(row['iterations'])
   summary['attempts'].append(compact)
   stream.write(json.dumps(compact)+'\n');stream.flush()
   print(json.dumps({**compact,'total_F_attempts':counter.attempted}),flush=True)
   summary['counter']=counter.record();c.save('discovery_summary.json',summary)
 summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 c.save('discovery_summary.json',summary)
 print('DISCOVERY_COMPLETE',json.dumps(counter.record()),flush=True)
if __name__=='__main__':main()
