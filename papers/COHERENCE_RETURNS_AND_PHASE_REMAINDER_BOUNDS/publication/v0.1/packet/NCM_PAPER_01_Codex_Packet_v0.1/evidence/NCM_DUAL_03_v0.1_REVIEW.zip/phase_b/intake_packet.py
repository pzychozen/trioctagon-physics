"""Safe, external-only intake of the newly supplied NCM-DUAL-03 packet."""
import datetime,hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
ZIP=pathlib.Path(r'C:\Users\Notandi\Downloads\NCM_DUAL_03_Codex_Packet_v0.1.zip')
def fp(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
raw=ZIP.read_bytes()
dest=ROOT/'packet'
assert not dest.exists()
dest.mkdir()
entries={}
with zipfile.ZipFile(ZIP) as z:
 for info in z.infolist():
  name=pathlib.PurePosixPath(info.filename)
  assert not name.is_absolute() and '..' not in name.parts and ':' not in info.filename and '\\' not in info.filename
  assert (info.external_attr>>16)&0o170000!=0o120000,'symlink entry refused'
  target=dest.joinpath(*name.parts)
  assert target.resolve().is_relative_to(dest.resolve())
  if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
  target.parent.mkdir(parents=True,exist_ok=True)
  b=z.read(info.filename)
  with target.open('xb') as f:f.write(b)
  entries[info.filename]=fp(b)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_path':str(ZIP),'archive':fp(raw),'members':entries}
(ROOT/'PACKET_INTAKE.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
