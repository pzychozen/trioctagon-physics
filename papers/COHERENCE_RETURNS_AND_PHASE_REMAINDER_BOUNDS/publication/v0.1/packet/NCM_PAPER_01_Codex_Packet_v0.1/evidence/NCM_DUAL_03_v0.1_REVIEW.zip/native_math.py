"""Standalone research transcription at ONE exact fixed parameter tuple.

No project imports. All derivatives are real. Call counters distinguish research
tests/discovery/validation; rejected exact-zero prestages are counted attempts.
"""
import mpmath as mp

PARAMETERS={'eps':'1/10','g':'1/60','lambda':'1/300','k':['999/1000','1','1001/1000']}


def rational(s):
    parts=s.split('/')
    return mp.mpf(parts[0])/mp.mpf(parts[1]) if len(parts)==2 else mp.mpf(s)


def parameters():
    return rational('1/10'),rational('1/60'),rational('1/300'),list(map(rational,PARAMETERS['k']))


class SingularPrestage(ValueError): pass
class BudgetExceeded(RuntimeError): pass


class Counter:
    def __init__(self,limit=None,label='tests'):
        self.limit=limit;self.label=label;self.attempted=0;self.completed=0;self.singular=0
    def charge(self):
        if self.limit is not None and self.attempted>=self.limit:raise BudgetExceeded(self.label)
        self.attempted+=1
    def record(self):
        return dict(label=self.label,attempted=self.attempted,completed=self.completed,singular=self.singular,limit=self.limit)


def pack(z):
    return mp.matrix([mp.re(v) for v in z]+[mp.im(v) for v in z])


def unpack(x):return mp.matrix([mp.mpc(x[i],x[i+3]) for i in range(3)])
def coherence(z):return z*z.H
def cubic(z):return z[0]*mp.conj(z[1])*z[2]
def maxnorm(x):return max(abs(v) for v in x)


def direct(z,counter=None,record=False):
    """Separately expressed direct Arg0 version, including its zero stratum."""
    if counter:counter.charge()
    e,g,lam,k=parameters()
    v=mp.matrix([z[i]+e*z[i]*(k[i]-z[i].real**2-z[i].imag**2)
                 +g*(z[(i+1)%3]+z[(i-1)%3]-2*z[i]) for i in range(3)])
    phases=[mp.arg(t) if t!=0 else mp.mpf(0) for t in v]
    kicks=[lam*(mp.sin(3*(phases[(i+1)%3]-phases[i]))+
                  mp.sin(3*(phases[(i-1)%3]-phases[i]))) for i in range(3)]
    out=mp.matrix([abs(v[i])*mp.exp(1j*(phases[i]+kicks[i])) if v[i]!=0 else mp.mpc(0) for i in range(3)])
    if counter:counter.completed+=1
    return (out,{'V':v,'kicks':mp.matrix(kicks)}) if record else out


def smooth(z,counter=None,jacobian=False,record=False):
    if counter:counter.charge()
    e,g,lam,k=parameters()
    a=[1-2*g+e*(k[i]-abs(z[i])**2) for i in range(3)]
    v=mp.matrix([a[i]*z[i]+g*(z[(i+1)%3]+z[(i+2)%3]) for i in range(3)])
    if any(t==0 for t in v):
        if counter:counter.singular+=1
        raise SingularPrestage('exact zero prestage; no repair')
    unit=[t/abs(t) for t in v]
    u3=[[((unit[j]*mp.conj(unit[i]))**3) for j in range(3)] for i in range(3)]
    kicks=[lam*sum(mp.im(u3[i][j]) for j in range(3) if j!=i) for i in range(3)]
    rot=[mp.exp(1j*d) for d in kicks]
    out=mp.matrix([v[i]*rot[i] for i in range(3)])
    J=None
    if jacobian:
        J=mp.matrix(6,6)
        for col in range(6):
            dz=mp.matrix([0,0,0]);dz[col%3]=1 if col<3 else 1j
            dv=[a[i]*dz[i]-2*e*z[i]*mp.re(mp.conj(z[i])*dz[i])
                +g*(dz[(i+1)%3]+dz[(i+2)%3]) for i in range(3)]
            dt=[mp.im(dv[i]/v[i]) for i in range(3)]
            dd=[3*lam*sum(mp.re(u3[i][j])*(dt[j]-dt[i]) for j in range(3) if j!=i) for i in range(3)]
            dout=pack(mp.matrix([rot[i]*(dv[i]+1j*v[i]*dd[i]) for i in range(3)]))
            J[:,col]=dout
    if counter:counter.completed+=1
    meta={'V':v,'kicks':mp.matrix(kicks),'J':J}
    return (out,meta) if (record or jacobian) else out


def block(z,counter=None,jacobian=False,record=False):
    states=[z.copy()];stages=[];J=mp.eye(6)
    for _ in range(3):
        z,info=smooth(z,counter,jacobian=jacobian,record=True)
        if jacobian:J=info['J']*J
        states.append(z.copy());stages.append(info)
    return z,{'states':states,'stages':stages,'J':J if jacobian else None}


def h_step(H):
    e,g,lam,k=parameters()
    M=mp.matrix([[g if i!=j else 1-2*g+e*(k[i]-H[i,i]) for j in range(3)] for i in range(3)])
    ht=M*H*M.T
    if any(mp.re(ht[i,i])<=0 for i in range(3)):raise SingularPrestage('nonpositive H prestage intensity')
    rho=[mp.sqrt(mp.re(ht[i,i])) for i in range(3)]
    d=[lam*sum(mp.im((ht[j,i]/(rho[j]*rho[i]))**3) for j in range(3) if j!=i) for i in range(3)]
    E=mp.diag([mp.exp(1j*t) for t in d])
    return E*ht*E.H


def gauge(z):
    pivot=max(range(3),key=lambda i:abs(z[i])) # first/lowest index on exact ties
    if z[pivot]==0:raise ValueError('zero input has no positive phase gauge')
    factor=mp.conj(z[pivot])/abs(z[pivot])
    out=z*factor
    out[pivot]=mp.mpc(abs(z[pivot]),0)
    return out,pivot,factor


def correlate(z,z3):
    denom=mp.re((z.H*z)[0])
    if denom==0:raise ValueError('zero input has undefined correlation')
    return (z.H*z3)[0]/denom


def initialize(z,counter):
    z,pivot,factor=gauge(z)
    z3,rec=block(z,counter)
    corr=(z.H*z3)[0]
    zero_corr=corr==0
    mu=mp.mpc(1) if zero_corr else corr/abs(corr)
    return mp.matrix(list(pack(z))+[mp.re(mu),mp.im(mu)]),pivot,{
        'gauge_factor':factor,'zero_correlation_fallback':zero_corr,'initial_block':rec}


def residual(x,pivot,counter=None,jacobian=False):
    z=unpack(x);mu=mp.mpc(x[6],x[7])
    z3,rec=block(z,counter,jacobian=jacobian)
    out=mp.matrix(list(pack(z3-mu*z))+[x[6]**2+x[7]**2-1,mp.im(z[pivot])])
    J=None
    if jacobian:
        J=mp.matrix(8,8)
        muR=mp.matrix(6,6)
        for i in range(3):
            muR[i,i]=x[6];muR[i,i+3]=-x[7]
            muR[i+3,i]=x[7];muR[i+3,i+3]=x[6]
        J[:6,:6]=rec['J']-muR
        J[:6,6]=-pack(z);J[:6,7]=-pack(1j*z)
        J[6,6]=2*x[6];J[6,7]=2*x[7]
        J[7,pivot+3]=1
    return out,J,rec
