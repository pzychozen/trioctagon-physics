"""New implementation checks at the fixed tuple; no discovery starts executed."""
import importlib.util,json,pathlib,sys,traceback
import mpmath as mp
import sympy as sp
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('native_math',ROOT/'native_math.py')
nm=importlib.util.module_from_spec(spec);spec.loader.exec_module(nm)
mp.mp.dps=80
checks=[];counter=nm.Counter(label='stage_a_tests')
def check(name,value,kind='software check'):
 checks.append({'name':name,'passed':bool(value),'kind':kind});print(('PASS ' if value else 'FAIL ')+name)
def near(a,b,tol='1e-65'):return nm.maxnorm(a-b)<mp.mpf(tol)
def run():
 R=sp.Rational;A=R(32003,30000);K=R(1001,1000)
 exact={'A':str(A),'B3_self_min':str(R(4997,30000)),
 'hmax_squared':str(40*A**3/27),'hmax_squared_margin_to_49_25':str(R(49,25)-40*A**3/27),
 'T_3_2':str(R(3,2)*(1+(K-R(9,4))/10)),
 'self_min_return':str(R(29,30)-R(1,5000)),
 'h_derivative_min_on_3_2':str(A-3*R(9,4)/10),
 'amplitude_hessian_L':str(R(1,10)*(3*K-R(999,1000))+R(3,60)),
 'step_chord_c':str(R(53717,500000)), 'three_return_chord_bound':str(R(161151,500000)),
 'phase_arc_bound_radians_display':mp.nstr(2*mp.asin(mp.mpf(161151)/1000000),60)}
 check('exact published coefficient strings',nm.PARAMETERS=={'eps':'1/10','g':'1/60','lambda':'1/300','k':['999/1000','1','1001/1000']})
 check('B3 self coefficient positive',R(4997,30000)>0,'exact rational inequality')
 check('h maximum inside interval',0<10*A/3<9,'exact rational inequality')
 check('B3 strict absorption bound',40*A**3/27<R(49,25),'exact rational inequality')
 check('h monotone through radius 3/2',A-3*R(9,4)/10>0,'exact rational inequality')
 check('radius 3/2 invariant',R(3,2)*(1+(K-R(9,4))/10)<R(3,2),'exact rational inequality')
 check('finite-return positivity and Hessian <2',R(29,30)-R(1,5000)>0 and R(313,1250)<2,'exact rational inequality')
 check('spectral perturbation range and chord bound',R(251,5000)<R(1001,10000) and R(1001,10000)+R(11001,10000)/150==R(53717,500000),'exact rational identity')
 check('quarter remainder excluded by chord inequality',R(161151,500000)**2<2,'exact rational inequality')
 z=mp.matrix([1+1j,1+1j,1-2j])
 direct=nm.direct(z,counter);smooth,meta=nm.smooth(z,counter,jacobian=True,record=True)
 check('direct Arg0 and smooth evaluator agree at published entrance',near(direct,smooth))
 check('raw H closure agreement',near(nm.coherence(smooth),nm.h_step(nm.coherence(z))))
 # An exact zero prestage at the actual coefficients, with no parameter change.
 singular=mp.matrix([0,1,-1]);d,md=nm.direct(singular,counter,record=True)
 check('Arg0 evaluator retains exact zero output',md['V'][0]==0 and d[0]==0)
 refused=False
 try:nm.smooth(singular,counter)
 except nm.SingularPrestage:refused=True
 check('regular evaluator refuses zero prestage without smoothing',refused)
 # Real Jacobian comparison, all six real directions, fixed diagnostic entrance.
 h=mp.mpf('1e-25');Jfd=mp.matrix(6,6);x=nm.pack(z)
 for j in range(6):
  dx=mp.matrix(6,1);dx[j]=h
  Jfd[:,j]=(nm.pack(nm.direct(nm.unpack(x+dx),counter))-nm.pack(nm.direct(nm.unpack(x-dx),counter)))/(2*h)
 check('analytic real Jacobian agrees with central differences',near(meta['J'],Jfd,'1e-45'))
 zg,pivot,fac=nm.gauge(z)
 check('gauge keeps raw norm and gives positive real pivot',abs(mp.norm(zg)-mp.norm(z))<mp.mpf('1e-70') and zg[pivot].imag==0 and zg[pivot].real>0)
 check('gauge deterministic tie rule',nm.gauge(mp.matrix([1,1,1]))[1]==0)
 mu=mp.exp(1j*mp.mpf('0.17'))
 check('correlation extracts unit multiplier without normalizing state',abs(nm.correlate(z,mu*z)-mu)<mp.mpf('1e-70'))
 zero_rejected=False
 try:nm.gauge(mp.matrix([0,0,0]))
 except ValueError:zero_rejected=True
 check('zero cannot obtain a positive gauge',zero_rejected)
 check('raw H distinguishes scale while projector does not',not near(nm.coherence(z),nm.coherence(2*z)) and near(nm.coherence(z)/(mp.norm(z)**2),nm.coherence(2*z)/(mp.norm(2*z)**2)))
 # Constructed non-orbit data checks only the polynomial diagnostic identity.
 check('K transforms by mu, not mu cubed',abs(nm.cubic(mu*z)-mu*nm.cubic(z))<mp.mpf('1e-65'))
 check('H discards common phase',near(nm.coherence(mu*z),nm.coherence(z)))
 # Simultaneous kick values are independently determined by the same prestage.
 phases=[mp.arg(t) for t in meta['V']]
 delta=mp.matrix([mp.mpf(1)/300*sum(mp.sin(3*(phases[j]-phases[i])) for j in range(3) if j!=i) for i in range(3)])
 check('all kicks use one prestage',near(delta,meta['kicks']))
 # Full augmented real Jacobian including circle and gauge, not holomorphic AD.
 xr=mp.matrix(list(nm.pack(zg))+[mp.re(mu),mp.im(mu)])
 rr,JJ,_=nm.residual(xr,pivot,counter,jacobian=True)
 direction=mp.matrix([mp.mpf(i-3)/7 for i in range(8)])
 rp=nm.residual(xr+h*direction,pivot,counter)[0]
 rm=nm.residual(xr-h*direction,pivot,counter)[0]
 check('eight-equation augmented Jacobian consistency',near(JJ*direction,(rp-rm)/(2*h),'1e-43'))
 check('test F counters include singular refusal and all derivative probes',counter.attempted==25 and counter.completed==24 and counter.singular==1)
 # Budget guard must refuse a new F call, not perform it uncounted.
 limited=nm.Counter(limit=0);rejected=False
 try:nm.direct(z,limited)
 except nm.BudgetExceeded:rejected=True
 check('budget guard prevents uncounted evaluations',rejected and limited.attempted==0)
 return exact
try:
 exact=run();error=None
except Exception:
 error=traceback.format_exc();exact={};print(error)
out={'checks':checks,'exact':exact,'test_F_calls':counter.record(),
 'totals':{'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'errors':int(error is not None)},
 'error':error,'discovery_seeds_evaluated':0,'precision':80}
(ROOT/'stage_a_results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out['totals']));print(json.dumps(counter.record()))
sys.exit(int(out['totals']['failed'] or out['totals']['errors']))
