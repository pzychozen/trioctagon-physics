"""Resolve supplied seeds and freeze plan; deliberately performs zero F calls."""
import datetime,fractions,hashlib,importlib.util,json,pathlib
import mpmath as mp
import sympy as sp
ROOT=pathlib.Path(__file__).resolve().parent
P=ROOT/'packet/NCM_DUAL_03_Codex_Packet_v0.1'
mp.mp.dps=80
assert not (ROOT/'PLAN_FREEZE.json').exists()
with (ROOT/'native_math.py').open('xb') as f:f.write((ROOT.parent/'native_math.py').read_bytes())
spec=importlib.util.spec_from_file_location('common',ROOT/'common.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
F=fractions.Fraction
checks=[]
def check(n,v):
 checks.append({'name':n,'passed':bool(v)});assert v,n
manifest=json.loads((P/'MANIFEST.json').read_text())
for item in manifest['files']:
 raw=(P/item['path']).read_bytes()
 check('packet member '+item['path'],len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'])
comparison=json.loads((ROOT/'PACKET_CONTEXT_COMPARISON.json').read_text());check('all context bytes agree',all(comparison.values()))
r=sp.Rational
check('brief a_min',1+r(999,10000)-r(1,30)==r(31997,30000))
check('brief a_max envelope',r(32003,30000)<r(27,25))
check('brief cubic peak comparison',r(49,25)-r(5832,3125)==r(293,3125)>0)
check('brief derivative lower bound',r(31997,30000)-r(3,10)*r(9,4)==r(11747,30000)>0)
plan=json.loads((P/'DISCOVERY_PLAN.json').read_text())
check('exact parameters match implementation',plan['parameters_exact_rational']==c.nm.PARAMETERS)
def rat(v):return c.nm.rational(v)
def phase(v):
 q=F(v)%2
 if q==0:return mp.mpc(1)
 if q==1:return mp.mpc(-1)
 if q==F(1,2):return mp.mpc(0,1)
 if q==F(3,2):return mp.mpc(0,-1)
 if q==F(1,6):return mp.mpc(mp.sqrt(3)/2,mp.mpf(1)/2)
 if q==F(11,6):return mp.mpc(mp.sqrt(3)/2,-mp.mpf(1)/2)
 if q==F(2,3):return mp.mpc(-mp.mpf(1)/2,mp.sqrt(3)/2)
 if q==F(4,3):return mp.mpc(-mp.mpf(1)/2,-mp.sqrt(3)/2)
 raise ValueError('unlisted supplied phase '+v)
seeds=[]
for seed in plan['seeds']:
 if seed['kind']=='exact_polar_seed':
  mods=seed['component_moduli_rational'];phases=seed['phase_pi_multipliers_rational']
  z=mp.matrix([rat(a)*phase(b) for a,b in zip(mods,phases)])
  squared=[F(a)**2 for a in mods]
 else:
  coords=seed['component_re_im_rational'];z=mp.matrix([mp.mpc(rat(a),rat(b)) for a,b in coords])
  squared=[F(a)**2+F(b)**2 for a,b in coords]
 pivot=max(range(3),key=lambda i:squared[i])
 check('seed admissible '+seed['id'],max(squared)<=9 and max(squared)>0)
 seeds.append({'id':seed['id'],'definition':seed,'state_80d':c.encode(z),
 'squared_moduli_exact':[str(t) for t in squared],'pivot_exact':pivot})
check('sixty exact ordered identities',[s['id'] for s in seeds]==[f'S{i:02d}' for i in range(1,61)])
check('polar and Cartesian counts',sum(s['definition']['kind']=='exact_polar_seed' for s in seeds)==54)
check('real mixed seeds have exact zero imaginary parts',all(c.decode_matrix(s['state_80d'])[i].imag==0 for s in seeds if s['definition'].get('phase_pattern','').startswith('real_mixed') for i in range(3)))
for i,j in ((54,55),(56,57),(58,59)):
 check('supplied Cartesian conjugates '+seeds[i]['id'],c.decode_matrix(seeds[j]['state_80d'])==c.decode_matrix(seeds[i]['state_80d']).conjugate())
base={'norm':mp.mpf(1),'max_modulus':mp.mpf(1),'pivot_real':mp.mpf(1),
 'return_abs':mp.mpf('1e-60'),'return_relative':mp.mpf('1e-60'),'circle_error':mp.mpf('1e-60'),
 'gauge_error':mp.mpf(0),'min_prestage_modulus':mp.mpf('.5'),
 'pairwise_H_relative_separations_01_02_12':[mp.mpf('1e-50')]*3,'one_step_phase_residual':mp.mpf('1e-50')}
check('classifier lower period fixture',c.classify(base)=='lower_period_one_numerical')
check('classifier zero fixture',c.classify({**base,'norm':mp.mpf('1e-30')})=='zero_or_near_zero')
check('classifier separated fixture',c.classify({**base,'pairwise_H_relative_separations_01_02_12':[mp.mpf('.1')]*3})=='unvalidated_period_three_candidate')
check('classifier uncertainty gap',c.classify({**base,'pairwise_H_relative_separations_01_02_12':[mp.mpf('1e-15')]*3})=='unresolved_H_separation')
check('classifier singular screen',c.classify({**base,'min_prestage_modulus':mp.mpf('1e-40')})=='singular_or_near_degenerate')
check('classifier small absolute residual cannot mask relative error',c.classify({**base,'return_relative':mp.mpf('.1')})=='solver_failed')
c.save('resolved_plan.json',{'schema':'NCM_DUAL_03_RESOLVED_SEARCH_V1','parameters':c.nm.PARAMETERS,
 'seed_plan_sha256':hashlib.sha256((P/'DISCOVERY_PLAN.json').read_bytes()).hexdigest(),
 'precision':80,'seeds':seeds,'native_F_evaluations_during_resolution':0,'solver':'PLAN.md'})
c.save('pre_search_tests.json',{'checks':checks,'passed':len(checks),'failed':0,'native_F_evaluations':0,
 'qualification':'Classifier fixtures are synthetic metrics, not claimed native roots.'})
names=['PLAN.md','resolved_plan.json','common.py','native_math.py','discover.py']
c.save('PLAN_FREEZE.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names},'F_evaluations_before_freeze_in_discovery':0})
print(json.dumps({'checks_passed':len(checks),'seeds':60,'F_calls':0,'plan_frozen':True}))
