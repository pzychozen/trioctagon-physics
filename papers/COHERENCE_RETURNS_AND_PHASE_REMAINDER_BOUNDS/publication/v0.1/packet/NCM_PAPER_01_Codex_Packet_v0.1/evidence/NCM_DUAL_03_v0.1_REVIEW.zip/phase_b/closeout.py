"""Final bounded preservation and self-contained review archive; no F calls."""
import ast,datetime,hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
P=ROOT/'packet/NCM_DUAL_03_Codex_Packet_v0.1'
ZIP=ROOT/'NCM_DUAL_03_v0.1_REVIEW.zip'
def fp(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
 assert not ZIP.exists() and not (ROOT/'ARCHIVE_RECEIPT.json').exists()
 initial=json.loads((BASE/'SOURCE_MANIFEST.before.json').read_text())
 stage_manifest=json.loads((BASE/'SOURCE_MANIFEST.json').read_text())
 sources={}
 for key,old in initial['files'].items():
  current=fp(pathlib.Path(old['path']).read_bytes())
  assert all(current[k]==old[k] for k in ('bytes','sha256')),key
  sources[key]={'path':old['path'],'before':{k:old[k] for k in ('bytes','sha256')},'after':current,
   'unchanged':True,'selection':stage_manifest['files'][key]['selections']}
 intake=json.loads((ROOT/'PACKET_INTAKE.json').read_text())
 actual=fp(pathlib.Path(intake['archive_path']).read_bytes());assert actual==intake['archive']
 packet={'archive_path':intake['archive_path'],'before':intake['archive'],'after':actual,'members':{}}
 for name,old in intake['members'].items():
  path=ROOT/'packet'/name;now=fp(path.read_bytes());assert old==now,name
  packet['members'][name]={'path':str(path),'before':old,'after':now,'unchanged':True,
   'inspection':'Complete packet member hash verification; brief/plan/review/start/lineage/manifest read, context report+manifest matched byte-for-byte; preparation-checks content not relied upon.'}
 save('SOURCE_MANIFEST.json',{'schema':'NCM_DUAL_03_FINAL_SOURCES_V1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'original_before_utc':initial['utc'],'original_inputs':sources,'supplied_packet':packet,
  'preservation_scope':'8 original inspected inputs, supplied ZIP and its 10 extracted members; not a whole-checkout audit.',
  'source_read_log':'../source_reads.json','prior_comparison':'../PRIOR_COMPARISON.json',
  'packet_context_comparison':json.loads((ROOT/'PACKET_CONTEXT_COMPARISON.json').read_text()),
  'unavailable_required_inputs':[]})
 freeze=json.loads((ROOT/'PLAN_FREEZE.json').read_text())
 for name,digest in freeze['sha256'].items():assert fp((ROOT/name).read_bytes())['sha256']==digest,name
 a=json.loads((ROOT/'analysis_results.json').read_text());d=json.loads((ROOT/'discovery_summary.json').read_text())
 tests=json.loads((BASE/'stage_a_results.json').read_text());pre=json.loads((ROOT/'pre_search_tests.json').read_text())
 assert a['classification_counts']=={'solver_failed':18,'lower_period_one_numerical':42}
 assert a['discovery_F_calls']==8211 and a['independent_regression_F_calls']==126
 assert a['genuine_period_three_candidates']==0 and len(d['attempts'])==60
 assert tests['totals']['passed']==25 and pre['passed']==87 and a['audit_totals']['passed']==68
 assert not tests['totals']['failed'] and not pre['failed'] and not a['audit_totals']['failed']
 assert max(r['iterations'] for r in d['attempts'])==80
 stage_receipt=json.loads((BASE/'STAGE_A_ARCHIVE_RECEIPT.json').read_text())
 assert fp(pathlib.Path(stage_receipt['archive_path']).read_bytes())==stage_receipt['archive']
 # This package intentionally contains all sixty attempts and every rejection history.
 assert len(list((ROOT/'attempts').glob('S*.json')))==60
 save('FINAL_AUDIT.json',{'status':'PASS','task_status':'COMPLETE_BOUNDED_INVESTIGATION',
  'genuine_period_three_validated':False,'no_global_nonexistence_claim':True,
  'all_sixty_attempts_present':True,'frozen_plan_and_code_unchanged':True,
  'original_sources_unchanged':8,'packet_members_unchanged':10,'supplied_archive_unchanged':True,
  'Stage_A_snapshot_unchanged':True,'new_F_evaluations_in_closeout':0,
  'checks':{'stage_A':25,'pre_search':87,'post_search':68},
  'F_counts':{'discovery':8211,'independent_regression_including_Stage_A_attempts':151,
             'total_attempted':8362,'total_completed':8361,'intentional_test_refusals':1,
             'local_validation':0,'optional_trace':0}})
 (ROOT/'CLOSEOUT.txt').write_text(
  'NCM-DUAL-03 v0.1 — COMPLETE BOUNDED INVESTIGATION\n'
  '60 prescribed starts executed once: 42 numerical coherence-period-one results, 18 numerical failures.\n'
  'Seven numerical lower-period groups. Zero genuine period-three candidates, zero validated period-three orbits.\n'
  '17 line-search failures and one iteration-limit failure; no failures discarded or silently retried.\n'
  '8211 discovery F evaluations; 151 independent regression/test F attempts (150 completed, one intentional zero refusal).\n'
  'Total: 8362 attempted, 8361 completed. 733 iteration passes, 691 Newton directions, 674 accepted steps.\n'
  'No candidate certification/precision escalation, optional native trace, observer-clock or EMA-memory update.\n'
  '25 Stage A checks, 87 pre-search checks, 68 post-search checks passed; zero test failures/errors.\n'
  'These checks do not certify the numerical roots or prove global nonexistence.\n'
  'Exact amplitude lemma confirmed; narrow-sector exclusion and necessary |mu-1|<=0.322302 bound proved for stated domains.\n'
  'Quarter-phase remainder excluded for regular three-returns in B3; other dispersed-phase three-returns remain unresolved.\n'
  'Eight original bounded source inputs unchanged; packet ZIP and ten extracted members unchanged; Stage A snapshot preserved.\n'
  'No whole-checkout preservation claim. No Git, application/kernel/lock/prior-paper edits, installation, UI, publication or new motion law.\n'
  'Environment: '+initial['environment']['executable']+'; '+initial['environment']['python'].replace('\n',' ')+'\n'
  'Versions: '+json.dumps(initial['environment']['versions'])+'\n'
  'Commands and replay details: COMMANDS.txt. Final report: REPORT.md. All attempt records: attempts/.\n'
  'Archive: NCM_DUAL_03_v0.1_REVIEW.zip. Member hashes inside; external ARCHIVE_RECEIPT.json binds archive and manifest.\n'
  'Stop here: no manuscript, larger search, different coefficient set or automatic successor task.\n',encoding='utf-8')
 # Preserve layout so the standalone Stage A and discovery implementations resolve locally.
 entries={}
 base_names=['native_math.py','test_stage_a.py','STAGE_A.md','stage_a_results.json','SOURCE_MANIFEST.before.json',
             'source_reads.json','PRIOR_COMPARISON.json','COMMANDS.txt','logs/stage_a_test_run_01.txt']
 for name in base_names:entries[name]=(BASE/name).read_bytes()
 root_names=['REPORT.md','PLAN.md','PLAN_FREEZE.json','resolved_plan.json','AMENDMENTS.md','COMMANDS.txt','CLOSEOUT.txt',
 'ATTEMPTS.md','READOUTS.md','native_math.py','common.py','discover.py','prepare.py','analyze.py','make_tables.py',
 'intake_packet.py','review_packet.py','closeout.py','PACKET_INTAKE.json','PACKET_CONTEXT_COMPARISON.json',
 'pre_search_tests.json','attempt_ledger.jsonl','discovery_summary.json','discovery_stdout.txt','analysis_results.json',
 'analysis_stdout.txt','independent_regression.json','numerical_groups.json','candidates.json','SOURCE_MANIFEST.json','FINAL_AUDIT.json']
 for name in root_names:entries['phase_b/'+name]=(ROOT/name).read_bytes()
 for p in sorted((ROOT/'attempts').glob('*.json')):entries['phase_b/attempts/'+p.name]=p.read_bytes()
 for p in sorted((ROOT/'packet').rglob('*')):
  if p.is_file():entries['phase_b/'+p.relative_to(ROOT).as_posix()]=p.read_bytes()
 readme='# NCM-DUAL-03 complete review package\n\nRead [the final report](phase_b/REPORT.md), [all 60 outcomes](phase_b/ATTEMPTS.md), and [the final closeout](phase_b/CLOSEOUT.txt).\n\nThe root-level Stage A proof/code/results are preserved preliminary evidence. The final resolved plan, execution, numerical findings and preservation manifest are under phase_b/. The supplied packet and all sixty raw attempt records are included. No genuine three-stage orbit is claimed; the finite search and exact exclusions have different scopes.\n'
 entries['README.md']=readme.encode('utf-8')
 memberdata={'schema':'NCM_DUAL_03_FINAL_ARCHIVE_MEMBERS_V1','members':{n:fp(b) for n,b in entries.items()},
             'self_exclusion':'Manifest itself is bound by the external archive receipt, not a self-hash loop.'}
 manifest_bytes=(json.dumps(memberdata,indent=2)+'\n').encode('utf-8')
 (ROOT/'MEMBER_MANIFEST.json').write_bytes(manifest_bytes);entries['MEMBER_MANIFEST.json']=manifest_bytes
 with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for name,raw in entries.items():z.writestr(name,raw)
 verified={}
 with zipfile.ZipFile(ZIP) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(entries) and set(z.namelist())==set(entries)
  for name,raw in entries.items():
   value=fp(z.read(name));assert value==fp(raw),name
   if name!='MEMBER_MANIFEST.json':assert value==memberdata['members'][name]
   verified[name]=value
 for row in sources.values():assert fp(pathlib.Path(row['path']).read_bytes())==row['after']
 assert fp(pathlib.Path(intake['archive_path']).read_bytes())==intake['archive']
 receipt={'status':'PASS','task_status':'COMPLETE_BOUNDED_INVESTIGATION','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'archive_path':str(ZIP),'archive':fp(ZIP.read_bytes()),'members_verified':len(verified),
  'member_hashes':verified,'zip_crc_passed':True,'original_inputs_unchanged_after_archive':8}
 save('ARCHIVE_RECEIPT.json',receipt)
 print(json.dumps({k:receipt[k] for k in ('status','task_status','archive_path','archive','members_verified')},indent=2))
if __name__=='__main__':main()
