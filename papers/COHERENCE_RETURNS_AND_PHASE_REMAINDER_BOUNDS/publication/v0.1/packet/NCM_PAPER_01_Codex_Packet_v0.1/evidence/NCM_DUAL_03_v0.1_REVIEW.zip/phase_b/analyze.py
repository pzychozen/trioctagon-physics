"""Read retained attempts; independent direct-formula regression, no new solves."""
import collections,hashlib,importlib.util,json,pathlib
import mpmath as mp
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('common',ROOT/'common.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
nm=c.nm;mp.mp.dps=80
def dec(x):
 if isinstance(x,dict) and set(x)=={'re','im'}:return mp.mpc(x['re'],x['im'])
 if isinstance(x,dict):return {k:dec(v) for k,v in x.items()}
 if isinstance(x,list):return [dec(v) for v in x]
 return x
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((ROOT/'discovery_summary.json').read_text())
counter=nm.Counter(limit=359,label='independent_regression_after_25_Stage_A_attempts')
counts=collections.Counter();stops=collections.Counter();trials=collections.Counter();groups=[];independent=[];failure_details=[]
audits=[]
def check(n,v):audits.append({'name':n,'passed':bool(v)});assert v,n
freeze=json.loads((ROOT/'PLAN_FREEZE.json').read_text())
check('all frozen inputs unchanged',all(sha(ROOT/n)==digest for n,digest in freeze['sha256'].items()))
check('all sixty starts recorded in prescribed order',[s['id'] for s in summary['attempts']]==[f'S{i:02d}' for i in range(1,61)])
calls=0;iteration_count=0;newton_directions=0;initial_fallback=[];genuine=[];maximum_direct_difference=mp.mpf(0)
for compact in summary['attempts']:
 row=json.loads((ROOT/'attempts'/f"{compact['id']}.json").read_text())
 id=row['id'];counts[row['classification']]+=1;stops[row['stop_reason']]+=1;calls+=row['F_attempts']
 iteration_count+=len(row['iterations']);newton_directions+=sum('newton_step' in it for it in row['iterations'])
 if row.get('initial_correlation_fallback'):initial_fallback.append(id)
 for it in row['iterations']:
  for trial in it['trials']:trials[trial['reason']]+=1
 # Independent accounting from initial 3, each Jacobian residual 3, and every evaluated trial 3.
 expected=3+3*len(row['iterations'])+3*sum(t['reason'] in ('accepted','insufficient_merit_decrease') for it in row['iterations'] for t in it['trials'])
 check('per-start call accounting '+id,expected==row['F_attempts'])
 if 'metrics' not in row:
  failure_details.append({'id':id,'reason':row['stop_reason']});continue
 metrics=row['metrics'];x=c.decode_matrix(row['last_x']);z=nm.unpack(x);mu=mp.mpc(x[6],x[7])
 if row['stop_reason']=='numerical_convergence':
  zd=z.copy();raw=[zd.copy()];pre=[]
  for _ in range(3):
   zd,info=nm.direct(zd,counter,record=True);raw.append(zd.copy());pre.append(info)
  retained=[c.decode_matrix(a) for a in row['last_block']['states']]
  diff=max(mp.norm(a-b) for a,b in zip(raw,retained));maximum_direct_difference=max(diff,maximum_direct_difference)
  err=mp.norm(zd-mu*z);rel=err/mp.norm(z)
  corr=nm.correlate(z,zd)
  status=diff<mp.mpf('1e-65') and err<mp.mpf('1e-44') and rel<mp.mpf('1e-39')
  independent.append({'id':id,'agreement_passed':status,'max_state_difference':diff,
   'direct_return_abs':err,'direct_return_relative':rel,'direct_mu_corr':corr,
   'direct_states':raw,'direct_stages':pre,'precision':80})
 if row['classification']=='lower_period_one_numerical':
  matched=None;transform=None
  for group in groups:
   representative=c.decode_matrix(group['representative_state'])
   states=[c.decode_matrix(t) for t in row['last_block']['states'][:3]]
   for stage,zs in enumerate(states):
    corr=(representative.H*zs)[0];factor=mp.conj(corr)/abs(corr) if corr else mp.mpc(1)
    discrepancy=mp.norm(factor*zs-representative)/max(mp.norm(representative),mp.norm(zs))
    if discrepancy<mp.mpf('1e-25'):
     matched=group;transform={'cycle_start':stage,'common_phase_factor':factor,'relative_discrepancy':discrepancy};break
   if matched:break
  if matched is None:
   matched={'group':f'G{len(groups)+1:02d}','representative_seed':id,'representative_state':c.encode(z),
    'mu_three_step':metrics['mu_fitted'],'mu_one_step':metrics['one_step_mu_corr'],
    'mu_three_angle_radians':mp.arg(mu),'min_prestage_modulus':metrics['min_prestage_modulus'],
    'max_H_separation':max(mp.mpf(v) for v in metrics['pairwise_H_relative_separations_01_02_12']),
    'H_stages':metrics['H'],'j_stages':metrics['j'],'members':[]}
   groups.append(matched);transform={'cycle_start':0,'common_phase_factor':mp.mpc(1),'relative_discrepancy':mp.mpf(0)}
  matched['members'].append({'seed':id,'transformation_to_representative':transform})
 elif row['classification']=='unvalidated_period_three_candidate':
  genuine.append({'seed':id,'return_abs':metrics['return_abs']})
 else:
  failure_details.append({'id':id,'reason':row['stop_reason'],'classification':row['classification'],
   'norm':metrics['norm'],'return_abs':metrics['return_abs'],'return_relative':metrics['return_relative'],
   'min_prestage_modulus':metrics['min_prestage_modulus'],
   'H_separations':metrics['pairwise_H_relative_separations_01_02_12']})
check('aggregate discovery accounting',calls==summary['counter']['attempted']==8211)
check('all per-start iteration ceilings',all(s['iterations']<=80 for s in summary['attempts']))
check('global discovery ceiling',calls<=120000)
check('all converged direct regressions pass',all(r['agreement_passed'] for r in independent))
check('independent regression ceiling including Stage A',counter.attempted+25<=384)
check('retained code identical to checked Stage A implementation',(ROOT/'native_math.py').read_bytes()==(ROOT.parent/'native_math.py').read_bytes())
c.save('independent_regression.json',{'counter':counter.record(),'prior_Stage_A_attempts':25,
 'rows':independent,'maximum_state_difference':maximum_direct_difference,'all_passed':all(r['agreement_passed'] for r in independent)})
c.save('numerical_groups.json',{'qualification':'Numerical common-phase/cycle-start groups, not uniqueness proofs; no permutation/conjugation identification.',
 'groups':groups})
c.save('candidates.json',{'genuine_period_three_candidates':genuine,'validated_candidates':[],
 'local_validation_attempted':False if not genuine else 'REQUIRED_NEXT',
 'reason':'No genuine-period-three numerical candidate; no certificate attempt or 120-digit candidate reevaluation triggered.' if not genuine else 'Candidate requires independent validation',
 'failed_attempts':failure_details})
out={'classification_counts':dict(counts),'stop_reasons':dict(stops),'trial_reasons':dict(trials),
 'discovery_F_calls':calls,'iteration_passes':iteration_count,'newton_directions':newton_directions,
 'independent_regression_F_calls':counter.attempted,'total_independent_regression_including_Stage_A':counter.attempted+25,
 'lower_period_numerical_groups':len(groups),'genuine_period_three_candidates':len(genuine),
 'initial_correlation_fallback_seeds':initial_fallback,'audit_checks':audits,
 'audit_totals':{'passed':len(audits),'failed':0},'failures':failure_details}
c.save('analysis_results.json',out)
print(json.dumps(c.encode({k:v for k,v in out.items() if k not in ('audit_checks','failures')}),indent=2))
print('GROUPS')
for group in groups:print(json.dumps(c.encode({k:group[k] for k in ('group','representative_seed','mu_three_angle_radians','min_prestage_modulus','max_H_separation')})))
print('FAILURES',json.dumps(c.encode(failure_details),indent=2))
