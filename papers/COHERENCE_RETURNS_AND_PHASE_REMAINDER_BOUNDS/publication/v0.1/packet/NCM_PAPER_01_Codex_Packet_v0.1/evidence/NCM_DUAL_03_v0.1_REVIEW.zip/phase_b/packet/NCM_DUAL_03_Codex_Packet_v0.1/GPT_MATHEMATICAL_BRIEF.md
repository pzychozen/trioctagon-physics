# GPT mathematical brief — NCM-DUAL-03 v0.1

31 October 2026. **Proposed analytical lead and research design for independent Codex review.** No new native trajectory or root search was executed while preparing this packet. The associated work order, not this brief, controls scope.

## 1. Why this one parameter point

The accepted NCM-DUAL-02 report records the published native point

\[
\epsilon=1/10,\quad g=1/60,\quad \lambda=1/300,\qquad
k=(999/1000,1,1001/1000).
\]

It supplies both an established turning example and a separately proved coherent convergence region. Those are useful references; neither gives a period-three orbit. This is also the D1 coefficient family's point h=1/10, eta=1/1000, but the inherited D1 result is a fixed-relative-shape branch, not a three-stage relative orbit. Do not vary h, eta, k or any other coefficient in this study.

We choose the finite state domain B3 = {max_i |z_i| <= 3}, independently of a desired phase. It contains the documented turning entrance. It is NOT the other parameter profile's previously proved radius-three domain. The following lemma is a fresh derivation for the present coefficients and must be reviewed independently.

## 2. Proposed amplitude lemma

Put

\[
a_i=1+\epsilon k_i-2g,\qquad
V_i=(a_i-r_i^2/10)z_i+g\sum_{j\ne i}z_j,\quad r_i=|z_i|.
\]

At these coefficients,

\[
\frac{31997}{30000}\le a_i\le\frac{32003}{30000}<\frac{27}{25}.
\]

On B3, every diagonal coefficient is positive:

\[
a_i-r_i^2/10\ge\frac{4997}{30000}>0.
\]

The triangle inequality consequently gives

\[
|V_i|\le a_i r_i-r_i^3/10+1/10
\le \frac{27}{25}r_i-r_i^3/10+1/10.
\]

The cubic on the right has its maximum on 0<=r<=3 at r=sqrt(18/5), so

\[
|V_i|\le\frac1{10}+\frac{18}{25}\sqrt{\frac{18}{5}}<\frac32.
\]

For the strict last inequality, both sides of
(18/25)sqrt(18/5) < 7/5 are positive and their squared difference is

\[
\frac{49}{25}-\frac{5832}{3125}=\frac{293}{3125}>0.
\]

The phase stage preserves each modulus, including zero components under the native convention. Thus this argument would prove **F(B3) is contained strictly in B_(3/2)**, and in particular B3 is forward invariant at this exact parameter point. It is a mathematical map bound, not a machine overflow theorem or an assertion about the geometric enclosing sphere.

### A stronger bound for any unit-multiplier returning block

Suppose z starts in B3 and F^p(z)=mu z with |mu|=1, for any finite p>=1. By the preceding bound, every state in this finite returning block, including z itself, has component moduli below 3/2.

For 0<=r<=3/2, f_i(r)=a_i r-r^3/10 is increasing because

\[
f_i'(r)=a_i-3r^2/10\ge\frac{11747}{30000}>0.
\]

Let M be the largest component modulus across the p states of the block. Then every output component obeys

\[
|F_i(z_n)|=|V_i(z_n)|
\le f_i(M)+2gM
\le M\left[1+\frac1{10}\left(\frac{1001}{1000}-M^2\right)\right].
\]

If M>sqrt(1001/1000), this is strictly smaller than M for EVERY output. But the block outputs have the same component-modulus collection as the inputs: the last is mu z. This contradicts the attainment of M. Therefore

\[
\boxed{\max_{0\le n<p,\ i}|F^n(z)_i|\le\sqrt{1001/1000}.}
\]

This deduction does not require assuming a future regularity domain. It is a finite-block modulus argument. It does not supply a positive lower bound, a common-phase sector, convergence, an existence proof, or an exclusion of all cycles. Mixed phases and small components remain relevant. Outside B3 is not classified by it.

Codex should check the proof and all exact fractions before using the lemma. If it fails, report the point of failure; do not silently impose the proposed bound as a constraint on the model.

## 3. The target return and what must not be fixed

The primary target is F^3(z)=mu z with |mu|=1, regular prestages, nonzero z, and genuinely different H=z z^dagger at the three stages. No quotient by positive amplitude is allowed. Do not constrain mu to i, -i, 1 or -1 during discovery.

Eight real unknowns (six state coordinates plus Re mu and Im mu), six real return equations, the unit-circle equation, and one phase gauge make a square system. Fix Im z_j=0 and retain Re z_j>0. Selecting z_j=1 would incorrectly fix amplitude as well as phase. The original z evolves without repeated gauge resets.

A smooth regular form of the phase kick is

\[
\delta_i=\lambda\sum_{j\ne i}\operatorname{Im}\!\left[\left(\frac{V_j\overline V_i}{|V_j||V_i|}\right)^3\right].
\]

Here the notation means **Im of the cubed quotient**, not the cube of Im. Implement with explicit parentheses. Its equivalence to the Arg0 formula holds only when all prestages are nonzero. On singular points, the native convention remains as it is; the regular return solver should flag its inapplicability rather than alter it.

An exact regular H-period-three orbit gives a repeated phase multiplier by the accepted NCM-DUAL-02 theorem. Exact full period twelve additionally requires mu of exact order four. A numerical phase close to a quarter-turn is not enough. The actual mu is a finding, not a design target.

## 4. Known exclusions and useful solver outcomes

The inherited coherent domain has every component modulus in [.9,1.1] and all ordinary phases contained in an interval of width at most pi/12, up to common rotation. Its trajectories converge to a fixed state. A periodic H sequence there converges and hence is constant, so it cannot have minimal H-period three. This says nothing about dispersed phases elsewhere in the amplitude bound above.

Fixed states, D1-like relative equilibria and the zero solution all solve some or all return equations. They must not be renamed period-three discoveries. In an exact regular three-return, minimal H-period divides three; it is either one or three. For certificates, prove strict pairwise separation of the three H matrices rather than infer it from a plotted loop.

A singular Jacobian can reflect a bad chart, the phase symmetry not removed, a lower-period solution, or an actual degeneracy. It is not automatically evidence for a branch, nonexistence, or a physical mode. Discovery and local proof are separate tasks.

An analytical exclusion of the whole declared domain can legitimately stop the finite search. An unsuccessful finite search cannot do the reverse and manufacture a whole-domain theorem.

## 5. Existing phase-sensitive readout

The report's EMA clarification provides an existing cubic scalar. With zero-based channel labels,

\[
K(z)=z_0\overline{z_1}z_2,\qquad j(z)=\operatorname{Im}K(z).
\]

For unit mu, K(mu z)=mu K(z). Under an established three-step return,

\[
j(F^{3m}z)=\operatorname{Im}(\mu^m K(z)).
\]

In the special conditional case mu=i and K(z)=a+ib, block values are b,a,-b,-a,b; for mu=-i they are b,-a,-b,a,b. The previous review contains the symbolic reasoning. This formula does not prove the orbit exists, drive its dynamics, give a cone frame, or specify the full EMA memory trajectory. Do not advance EMA memory or an observer clock in this task.

At a fixed observer clock/configuration, the staged Z readout is common-phase invariant and cannot distinguish those block phases. Neither fact establishes a spatial activation map or energy-flow law.

## 6. Source basis and evidence status

Controlling supplied context:
- `context/NCM_DUAL_02_REPORT.md`, especially native formula, regular-return theorem, inherited control scopes and paper-readiness boundary;
- `context/NCM_DUAL_02_GPT_REVIEW.md`, especially the conditional phase-sensitive readout and suggested existence problem;
- `context/PRIOR_SOURCE_MANIFEST.json`, for bounded source paths and earlier content identities only.

This brief adds the proposed amplitude estimate and the next experimental design. It does not assert a searched-for orbit, a new exclusion of all H-period-three solutions, or a physical interpretation. Source files and accepted papers remain unchanged.
