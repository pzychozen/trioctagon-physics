# Predeclared evaluation plan — NCM-DUAL-02

Written before any new recurrence evaluation. These are independent mathematical transcriptions, not kernel runs or official RunRecords. No project modules are imported. No parameters will be selected by visual resemblance or period search.

Use the exact equations in `DYNAMICS:87–104` and `D1:90–114`: amplitude/graph prestage, then simultaneous harmonic-three kicks, Arg0(0)=0, with exact zero outputs retained. Eight native cases, nine updates total; no case exceeds two updates. Evaluate once at 80 decimal digits with mpmath. Original rational values below define mathematical inputs; output decimals are diagnostic approximations, not certificates. Tolerance 1e-65 checks formula agreement; strict nonzero claims use the analytical arguments in REPORT.md where stated.

Let P(z0,z1,z2)=(z2,z0,z1), Q=iP, k*=(999/1000,1,1001/1000), and b=(1+i,1-i,2+i). Unless otherwise specified, eps=1/10, g=1/60, lambda=1/300.

| Case | Input | k / coefficient differences | Updates | Reason admissible independently of cone result |
|---|---|---|---:|---|
| N1 | (1,1,1) | k=(1,1,1) | 1 | Exact consensus fixed point for every real eps,g,lambda; tests F is not Q. |
| N2 | b | k=k* | 1 | Simple finite complex diagnostic with unequal intensities/phases; documented coherent-paper coefficients, but no claim b lies in its invariant domain. |
| N3 | Qb | k=P k* | 1 | Partner required by the proposed parameter-covariance identity; separate fixed configuration, not a parameter-changing orbit. |
| N4 | Qb | k=k* | 1 | Same input as N3 at unchanged coefficients tests the fixed-k restriction. |
| N5 | (1,-1,0) | eps=g=0, lambda=1/10, k=(1,1,1) | 1 | Exact zero-stratum witness from OBSERVABLES, not a selected trajectory. |
| N6 | exp(i*pi/6)(1,-1,0) | as N5 | 1 | Same-coherence partner in the inherited zero-stratum witness. |
| N7 | Q(1,-1,0) | as N5 | 1 | Tests the actual Q symmetry at that stratum, without replacing its zero convention. |
| N8 | (1/2,1/2,1/2) | k=(1,1,1) | 2 | Uniform positive line makes projector return explicit while its nonlinear amplitude changes. |

For N2, also compute the induced H formula directly from its input coherence, and compare with the same already-computed output; this is not another native trajectory. Compare N3 against Q times N2 output, N4 against that same output, and N6/N7 against N5. Check N8 against exact rational uniform-line expressions. These are validation comparisons, not further native cases.

Other work is exact matrix algebra, proof, or evaluation of fixed SRG constants: Pi/J/Q powers and state periods; cone three-leg products and no-own-axis-spin identity; matched tangent transport; SRG Fourier cycle and tensor identities. Frozen SRG displays use 80-digit mpmath and a single 100-digit recomputation for display stability, not interval certification. No native evaluation is repeated at another precision. Existing D1/M3/coherent certificates are read only. No old QA suite is executed.

The return theorem, its minimal-period argument, nonexistence for raw fixed SRG, and the fixed-frame loop obstruction require analytical proofs. A finite test count is not evidence of a global theorem or a proof of absence of other native orbits.
