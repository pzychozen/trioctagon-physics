"""Bounded hash-before-reading source intake. Text only; no project imports."""
import datetime,hashlib,importlib.metadata,json,pathlib,platform,sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(r'C:\TORMENT\TRIOCTAGON_new\trioctagon-physics')
PRIOR=ROOT.parent/'NATURAL_CORE_MOTION_DUALITY_01'
PUB=REPO/'SRG_REDISCOVERY/FINAL_MATHEMATICAL_BRIDGE/publication/v0.1'
FILES={
 'ORDER':pathlib.Path(r'C:\Users\Notandi\Downloads\CODEX_NCM_DUAL_02_EXISTING_EQUATION_INVESTIGATION_v0.1.txt'),
 'LEAD':pathlib.Path(r'C:\Users\Notandi\Downloads\GPT_INITIAL_ANALYSIS_NCM_DUAL_02.md'),
 'DUAL_REPORT':PRIOR/'REPORT.md','DUAL_RESULTS':PRIOR/'results.json','DUAL_MATH':PRIOR/'duality_math.py',
 'DYNAMICS':REPO/'kernel_physics/dynamics.py','FACE':REPO/'kernel_physics/face_state.py',
 'Z':REPO/'kernel_physics/z_manifold.py','PRESETS':REPO/'kernel_physics/_presets.py',
 'OBSERVABLES':REPO/'papers/NATIVE_RESPONSE_GEOMETRY/manuscript/observables_closure.tex',
 'D1':REPO/'papers/MEASUREMENT_AND_CHIRAL_DRIFT/v0.1/drift/manuscript.tex',
 'M3':REPO/'papers/PAPER_G/v0.1.1/source/paper_g.tex',
 'COHERENT':REPO/'papers/COLLECTIVE_TURNING_AND_COHERENT_RELAXATION/v0.1/main.tex',
 'BRIDGE':PUB/'SRG_FINAL_MATHEMATICAL_BRIDGE_v0.1.md','TARGET':PUB/'sources/TARGET.md','BOUNDARY':PUB/'sources/BOUNDARY.md',
 'SRG':REPO/'kernel_physics/srg.py',
 'SRGI':REPO/'SRG_REDISCOVERY/PAPERS/SRG_I_FOUNDATIONAL_RECONSTRUCTION/publication/v0.1.1/manuscript/SRG_I_v0.1.1.tex'}
def fp(path):
 raw=path.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def write(name,data):(ROOT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def intake():
 for name in ('inputs','logs','scratch','mplconfig'):(ROOT/name).mkdir(exist_ok=True)
 assert not (ROOT/'SOURCE_MANIFEST.before.json').exists()
 data={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(ROOT),'interpreter':sys.executable,'python':sys.version,'platform':platform.platform(),
 'versions':{name:importlib.metadata.version(name) for name in ('numpy','sympy','mpmath')},
 'source_route':'7cc1fa03af589818bcdcfaaac51838cc36c84253; locator only, not current revision',
 'files':{key:{'path':str(p),'available':p.is_file(),**(fp(p) if p.is_file() else {})} for key,p in FILES.items()},
 'lead_checks_script':'Not supplied among the two attachments or found by bounded Downloads name search; not relied upon or rerun'}
 write('SOURCE_MANIFEST.before.json',data)
 for key in ('ORDER','LEAD'):
  with (ROOT/'inputs'/FILES[key].name).open('xb') as f:f.write(FILES[key].read_bytes())
 print(json.dumps(data,indent=2))
def record(key,selection):
 path=ROOT/'source_reads.json';data=json.loads(path.read_text()) if path.exists() else []
 data.append({'source':key,**selection});write('source_reads.json',data)
def read(key,start,end):
 lines=FILES[key].read_text(encoding='utf-8').splitlines();record(key,{'first_line':start,'last_line':min(end,len(lines))})
 for n in range(start-1,min(end,len(lines))):print(f'{n+1}: {lines[n]}')
def find(key,terms):
 lines=FILES[key].read_text(encoding='utf-8').splitlines();record(key,{'find_terms':terms})
 for n,line in enumerate(lines):
  if any(t.lower() in line.lower() for t in terms):print(f'{n+1}: {line}')
if __name__=='__main__':
 if len(sys.argv)==1:intake()
 elif sys.argv[2]=='find':find(sys.argv[1],sys.argv[3:])
 else:read(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))
