"""Bounded source preservation and exclusive review-archive creation.

Run only once after report review. Reads declared sources; writes under ROOT.
No project imports, execution of old code, Git or network.
"""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT/'NCM_DUAL_02_v0.1_REVIEW.zip'
RECEIPT=ROOT/'ARCHIVE_RECEIPT.json'


def digest(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')


def closeout():
    assert not ARCHIVE.exists() and not RECEIPT.exists(), 'Do not overwrite a completed archive.'
    before=json.loads((ROOT/'SOURCE_MANIFEST.before.json').read_text(encoding='utf-8'))
    selections=json.loads((ROOT/'source_reads.json').read_text(encoding='utf-8'))
    files={}
    for key,old in before['files'].items():
        path=Path(old['path'])
        after=digest(path.read_bytes())
        unchanged=all(after[f]==old[f] for f in ('bytes','sha256'))
        assert unchanged, f'SOURCE CHANGED: {key}'
        chosen=[{k:v for k,v in rec.items() if k!='source'} for rec in selections if rec['source']==key]
        if key=='DUAL_RESULTS':
            chosen.append({'structured_data':'verify.py parsed JSON; branches[1/-1].three_leg_products.G_forward_CBA and O_forward_ACB compared; prior code never executed'})
        assert chosen, f'No recorded inspection selection: {key}'
        files[key]={'path':str(path),'before':{f:old[f] for f in ('bytes','sha256')},
                    'after':after,'unchanged':unchanged,'selections':chosen}
    manifest={'schema':'NCM_DUAL_02_BOUNDED_SOURCE_MANIFEST_V1',
              'before_utc':before['utc'],'after_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope':'18 declared inspected files only; not a whole-checkout/environment audit',
              'files':files,'unchanged_count':len(files),
              'unavailable_input':'GPT lead_checks script not supplied/found by bounded filename search; memo run not inherited as verification',
              'revision_locator_only':before['source_route']}
    write('SOURCE_MANIFEST.json',manifest)
    results=json.loads((ROOT/'results.json').read_text())
    assert results['totals']=={'checks':46,'passed':46,'failed':0,'errors':0,'native_cases':8,'native_updates':9}
    assert results['plan_sha256']==digest((ROOT/'CASES.md').read_bytes())['sha256']
    # Bounded check that the standalone verification has no checkout imports.
    tree=ast.parse((ROOT/'verify.py').read_text(encoding='utf-8'))
    imports=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Import):imports.extend(n.name for n in node.names)
        if isinstance(node,ast.ImportFrom):imports.append(node.module)
    allowed={'datetime','hashlib','importlib.metadata','json','pathlib','platform','sys','traceback','mpmath','sympy'}
    assert set(imports)<=allowed
    # Pure integer verification of the report's unequal-k prestage intensity proof.
    diff=(-16997)**2+34994**2-((-17003)**2+35006**2)
    assert diff*25000 == -29*30000**2
    write('REVIEW_AUDIT.json',{
        'checks':'Manifest/input-plan consistency, test totals, verifier imports, report rational intensity difference',
        'imports':imports,'native_evaluations_added':0,
        'unequal_k_intensity_difference':{'numerator':diff,'denominator':30000**2,'reduced':'-29/25000'},
        'sources_unchanged':len(files),'verification_passed':46,'all_passed':True})
    (ROOT/'CLOSEOUT.txt').write_text(
        'NCM-DUAL-02 v0.1 CLOSEOUT\n'
        'Author correction recorded: golden-ratio wording illustrative, not a controller requirement.\n'
        '46 mathematical verification checks passed; zero failed/errors.\n'
        '8 predeclared native cases, 9 updates total, maximum 2 per case. No searches or old certificate reruns.\n'
        '18/18 bounded inspected source files unchanged by SHA-256 and length at closeout.\n'
        'This is not a whole-checkout preservation claim.\n'
        'All task-authored files are under the fresh external research root.\n'
        'No Git, source/kernel/application/lock/prior-paper edits, installations, UI control, external services, publication, new motion law, or added clock.\n'
        'GPT lead checker was unavailable; its reported 19-check run was not relied on.\n'
        'The exact source theorems are inherited, not recertified. Decimal diagnostics are not interval certificates.\n'
        'Scientific outcome: source-grounded return criteria and scoped obstructions; no established native cone choreography.\n'
        'Readiness: useful bounded lemmas for review; not ready for a native-motion manuscript. Integration parked.\n'
        'Review ZIP: NCM_DUAL_02_v0.1_REVIEW.zip. MEMBER_MANIFEST.json inside; ARCHIVE_RECEIPT.json outside.\n'
        'The receipt records archive SHA-256, member-byte verification and the final source comparison.\n',encoding='utf-8')
    names=['REPORT.md','CLAIMS_AND_LIMITS.md','CASES.md','verify.py','read_sources.py','closeout.py',
           'results.json','SOURCE_MANIFEST.before.json','SOURCE_MANIFEST.json','source_reads.json',
           'REVIEW_AUDIT.json','COMMANDS.txt','CLOSEOUT.txt','logs/verification_run_01.txt',
           'inputs/CODEX_NCM_DUAL_02_EXISTING_EQUATION_INVESTIGATION_v0.1.txt',
           'inputs/GPT_INITIAL_ANALYSIS_NCM_DUAL_02.md']
    members={name:digest((ROOT/name).read_bytes()) for name in names}
    member_manifest={'schema':'NCM_DUAL_02_ARCHIVE_MEMBERS_V1',
                     'members':members,
                     'manifest_self_exclusion':'This manifest cannot contain its own digest; it is independently bound by the outer archive receipt.',
                     'excluded':'Archive and external receipt; live closeout stdout log; empty scratch/cache directories.'}
    write('MEMBER_MANIFEST.json',member_manifest)
    names.append('MEMBER_MANIFEST.json')
    with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name in names:archive.writestr(name,(ROOT/name).read_bytes())
    verified={}
    with zipfile.ZipFile(ARCHIVE,'r') as archive:
        assert archive.testzip() is None
        assert set(archive.namelist())==set(names) and len(archive.namelist())==len(names)
        for name in names:
            got=digest(archive.read(name)); expected=digest((ROOT/name).read_bytes())
            assert got==expected
            if name!='MEMBER_MANIFEST.json':assert got==members[name]
            verified[name]=got
    # Read-only guard once more after archive construction; no scientific replay.
    for key,row in files.items():assert digest(Path(row['path']).read_bytes())==row['after'],key
    receipt={'schema':'NCM_DUAL_02_ARCHIVE_RECEIPT_V1',
             'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'archive_path':str(ARCHIVE),'archive':digest(ARCHIVE.read_bytes()),
             'members_verified':len(verified),'member_hashes':verified,
             'zip_crc_passed':True,'bounded_sources_unchanged_after_archive':len(files),
             'status':'PASS'}
    write(RECEIPT.name,receipt)
    print(json.dumps({'status':'PASS','source_files_unchanged':len(files),
                      'math_checks_passed':46,'members_verified':len(verified),
                      'archive':receipt['archive'],'path':str(ARCHIVE)},indent=2))


if __name__=='__main__':closeout()
