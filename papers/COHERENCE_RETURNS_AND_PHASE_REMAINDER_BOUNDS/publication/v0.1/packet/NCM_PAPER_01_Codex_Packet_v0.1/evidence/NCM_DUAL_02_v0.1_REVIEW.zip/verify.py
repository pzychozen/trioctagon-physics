"""Independent bounded mathematics. No checkout/prior-code imports or executions.

Sources and the exact eight native cases are recorded in CASES.md and REPORT.md.
Run: conda activate torment, then python -X utf8 -I -B verify.py
"""
import datetime
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import traceback
import mpmath as mp
import sympy as sp

ROOT = Path(__file__).resolve().parent
mp.mp.dps = 80
I = sp.eye(3)
ex, ey, ez = [I[:, j] for j in range(3)]
P = sp.Matrix([[0, 0, 1], [1, 0, 0], [0, 1, 0]])
Q = sp.I * P
Hchart = sp.diag(1, 1, -1)
checks = []
results = {
    'schema': 'NCM_DUAL_02_INDEPENDENT_V1',
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'environment': {'python': sys.version, 'executable': sys.executable,
                    'platform': platform.platform(),
                    'versions': {n: importlib.metadata.version(n) for n in ('numpy', 'sympy', 'mpmath')}},
    'plan_sha256': hashlib.sha256((ROOT/'CASES.md').read_bytes()).hexdigest(),
    'method': 'Exact SymPy matrix identities and analytical proofs; 80-digit mpmath diagnostics, not intervals.',
    'native_cases': {}, 'exact': {}, 'checks': checks,
    'prohibited_activity': 'No project imports, old checker execution, parameter search, fitting, added clock, or integration.'
}


def exact(M):
    if isinstance(M, sp.MatrixBase):
        return [[str(sp.simplify(x)) for x in row] for row in M.tolist()]
    return str(sp.simplify(M))


def equal(a, b):
    d = a-b
    return all(sp.simplify(x) == 0 for x in d) if isinstance(d, sp.MatrixBase) else sp.simplify(d) == 0


def check(name, condition, evidence='exact algebra'):
    passed = bool(condition)
    checks.append({'name': name, 'passed': passed, 'evidence': evidence})
    print(('PASS ' if passed else 'FAIL ') + name)


def num(x):
    if isinstance(x, mp.matrix):
        return [[num(x[i,j]) for j in range(x.cols)] for i in range(x.rows)]
    z = mp.mpc(x)
    return {'re': mp.nstr(z.real, 76), 'im': mp.nstr(z.imag, 76)}


def maximum(M):
    return max(abs(x) for x in M)


def qact(z):
    return mp.matrix([1j*z[2], 1j*z[0], 1j*z[1]])


def outer(z):
    return z*z.H


def native_step(z, eps, g, lam, k):
    """Literal exact-formula transcription, including Arg0(0)=0.

    Product form v*exp(i*delta) equals source modulus reconstruction in
    exact mathematics, not a promise of bitwise complex128 agreement.
    """
    v = mp.matrix([z[i]+eps*z[i]*(k[i]-abs(z[i])**2)
                   +g*(sum(z)-3*z[i]) for i in range(3)])
    angles = [mp.arg(x) if x != 0 else mp.mpf(0) for x in v]
    delta = [lam*sum(mp.sin(3*(angles[j]-angles[i])) for j in range(3) if j != i)
             for i in range(3)]
    out = mp.matrix([x*mp.exp(1j*d) if x != 0 else mp.mpc(0) for x,d in zip(v, delta)])
    return out, v, delta


def native_cases():
    r = lambda a,b: mp.mpf(a)/b
    coeff = (r(1,10),r(1,60),r(1,300))
    k = [r(999,1000),mp.mpf(1),r(1001,1000)]
    one = [mp.mpf(1)]*3
    b = mp.matrix([1+1j,1-1j,2+1j])
    z0 = mp.matrix([1,-1,0])
    definitions = [
        ('N1',mp.matrix(one),one,coeff,1),
        ('N2',b,k,coeff,1),
        ('N3',qact(b),[k[2],k[0],k[1]],coeff,1),
        ('N4',qact(b),k,coeff,1),
        ('N5',z0,one,(mp.mpf(0),mp.mpf(0),r(1,10)),1),
        ('N6',mp.exp(1j*mp.pi/6)*z0,one,(mp.mpf(0),mp.mpf(0),r(1,10)),1),
        ('N7',qact(z0),one,(mp.mpf(0),mp.mpf(0),r(1,10)),1),
        ('N8',mp.matrix([r(1,2)]*3),one,coeff,2)
    ]
    state, prestage = {}, {}
    for name,z,ks,params,n in definitions:
        entry = {'input':num(z),'k':num(mp.matrix(ks)),
                 'eps_g_lambda':[num(v) for v in params], 'updates':n,'path':[]}
        for step in range(n):
            z,v,d = native_step(z,*params,ks)
            entry['path'].append({'prestage':num(v),'delta':num(mp.matrix(d)),
                                  'output':num(z),'all_prestage_nonzero':all(x != 0 for x in v)})
        state[name] = z; prestage[name] = v
        results['native_cases'][name] = entry
    tol = mp.mpf('1e-65')
    check('native budget: eight cases, nine updates, maximum two',
          len(definitions)==8 and sum(d[-1] for d in definitions)==9 and max(d[-1] for d in definitions)==2,
          'predeclared budget audit')
    check('N1 consensus fixed; Q differs',maximum(state['N1']-mp.matrix(one))==0 and maximum(qact(mp.matrix(one))-state['N1'])>1,
          'exact special case plus numerical transcription')
    check('N2/N3 nonzero prestages',all(x != 0 for x in prestage['N2']) and all(x != 0 for x in prestage['N3']), '80-digit diagnostic')
    residual = maximum(state['N3']-qact(state['N2']))
    mismatch = maximum(state['N4']-qact(state['N2']))
    results['native_diagnostics'] = {'covariance_residual':mp.nstr(residual,20),
                                     'fixed_k_mismatch':mp.nstr(mismatch,30)}
    check('N3 parameter covariance',residual<tol,'80-digit diagnostic; symbolic proof in report')
    check('N4 unequal fixed k mismatch',mismatch>mp.mpf('1e-5'),'80-digit counterexample diagnostic')
    # H-only formula from the already evaluated N2 input; not another trajectory.
    Hb = outer(b)
    M = mp.eye(3)+coeff[1]*mp.matrix([[-2,1,1],[1,-2,1],[1,1,-2]])
    for i in range(3): M[i,i] += coeff[0]*(k[i]-Hb[i,i])
    Ht = M*Hb*M.T
    dd = [coeff[2]*sum(mp.im((Ht[j,i]/mp.sqrt(Ht[j,j]*Ht[i,i]))**3)
                       for j in range(3) if j != i) for i in range(3)]
    Ud = mp.diag([mp.exp(1j*d) for d in dd])
    closure_error = maximum(Ud*Ht*Ud.H-outer(state['N2']))
    check('regular H closure agrees on N2',closure_error<tol,'80-digit diagnostic; exact derivation in report')
    results['native_diagnostics']['H_closure_residual'] = mp.nstr(closure_error,20)
    inp5,inp6 = z0,mp.exp(1j*mp.pi/6)*z0
    check('N5/N6 input coherence agrees',maximum(outer(inp5)-outer(inp6))<tol,'80-digit diagnostic; exact common-phase identity')
    check('zero convention retained',state['N5'][2]==0 and state['N6'][2]==0 and state['N7'][0]==0,'exact zeros in transcription')
    check('N5/N6 output coherence analytic witness',
          abs(outer(state['N5'])[0,1]+1)<tol and abs(outer(state['N6'])[0,1]+mp.exp(-1j/5))<mp.mpf('1e-16'),
          '80-digit diagnostic; -1 versus -exp(-i/5) proved in report')
    # Use exact rational mpmath construction for the stringent version too.
    check('zero witness high-precision agreement',abs(outer(state['N6'])[0,1]+mp.exp(-1j*mp.mpf(1)/5))<tol,'80-digit formula agreement')
    check('N7 Q covariance fails at zero stratum',maximum(state['N7']-qact(state['N5']))>mp.mpf('.09'),'80-digit diagnostic; exact e^(+/-i/10) witness')
    f = lambda x: x*(1+sp.Rational(1,10)*(1-x*x))
    r0 = sp.Rational(1,2); r1 = f(r0); r2 = f(r1)
    expected = mp.mpf(str(sp.numer(r2)))/int(sp.denom(r2))
    check('N8 two updates agree with rational uniform-line formula',maximum(state['N8']-mp.matrix([expected]*3))<tol,'exact rational special case and 80-digit transcription')
    check('projector return does not give repeated amplitude multiplier',r2 != (r1/r0)**2*r0)
    results['exact']['uniform_line'] = {'r0':str(r0),'r1':str(r1),'r2':str(r2),
                                       'false_constant_multiplier_prediction':str((r1/r0)**2*r0)}


def comparison_algebra():
    check('Pi order three and J/Pi commute',P**3==I and (sp.I*I)*P==P*(sp.I*I))
    check('Q powers 3,6,9,12',Q**3==-sp.I*I and Q**6==-I and Q**9==sp.I*I and Q**12==I)
    check('Q minimal operator order twelve',all(Q**n!=I for n in range(1,12)))
    z = sp.Matrix([1,2,3*sp.I]); h=z*z.conjugate().T
    check('Q example: full period twelve, coherence period three',
          next(n for n in range(1,13) if Q**n*z==z)==12 and
          next(n for n in range(1,4) if equal(P**n*h*(P**n).T,h))==3)
    w = -sp.Rational(1,2)+sp.I*sp.sqrt(3)/2
    eigenvalues = [sp.I, sp.I*w, sp.I*w**2]
    orders = [next(n for n in range(1,13) if equal(v**n,1)) for v in eigenvalues]
    check('Q eigenvalue orders 4,12,12',orders==[4,12,12])
    eps,g = sp.symbols('epsilon g',real=True)
    a=sp.Matrix(sp.symbols('a0:3',real=True)); k=sp.Matrix(sp.symbols('k0:3',real=True))
    L=sp.ones(3)-3*I
    M=I+eps*sp.diag(*(k-a))+g*L
    Mq=I+eps*sp.diag(*(P*k-P*a))+g*L
    check('amplitude parameter covariance as matrix identity',equal(Mq*Q,Q*M))
    # Common-phase invariance of Re(z) cross Im(z), and phase sensitivity of EMA cubic.
    theta=sp.symbols('theta',real=True)
    x=sp.Matrix(sp.symbols('x0:3',real=True)); y=sp.Matrix(sp.symbols('y0:3',real=True))
    xr=sp.cos(theta)*x-sp.sin(theta)*y; yr=sp.sin(theta)*x+sp.cos(theta)*y
    check('chiral readout discards common phase',equal(xr.cross(yr),x.cross(y)))
    check('EMA cubic can detect common phase: ones versus i ones',sp.im(1*sp.conjugate(1)*1)==0 and sp.im(sp.I*sp.conjugate(sp.I)*sp.I)==1)
    results['exact']['Q_example']={'z':exact(z),'full_period':12,'coherence_period':3,'eigenvalue_orders':orders}


def cone_algebra():
    prior_path = Path(json.loads((ROOT/'SOURCE_MANIFEST.before.json').read_text())['files']['DUAL_RESULTS']['path'])
    prior = json.loads(prior_path.read_text(encoding='utf-8'))
    theta=sp.symbols('theta',real=True)
    def maps(s,t):
        c,b=sp.cos(t),sp.sin(t)
        return [sp.Matrix([[c,b,0],[-b,c,0],[0,0,1]]),
                sp.Matrix([[1,0,0],[0,c,-s*b],[0,s*b,c]]),
                sp.Matrix([[c,0,b],[0,1,0],[-b,0,c]])]
    result={}
    for s in (1,-1):
        A,B,C=maps(s,sp.pi/2)
        G,O=C*B*A,A*C*B
        expectedG=sp.Matrix([[-s,0,0],[0,0,-s],[0,-1,0]])
        expectedO=sp.Matrix([[0,0,-s],[0,-s,0],[-1,0,0]])
        check(f'cone s={s}: signed three-leg products',G==expectedG and O==expectedO)
        retained=prior['branches'][str(s)]['three_leg_products']
        check(f'cone s={s}: products agree with retained results',exact(G)==retained['G_forward_CBA'] and exact(O)==retained['O_forward_ACB'],'independent algebra / retained JSON comparison')
        order=2 if s==1 else 4
        check(f'cone s={s}: product order {order}',G**order==I and O**order==I and all(G**n!=I and O**n!=I for n in range(1,order)))
        check(f'cone s={s}: noncommuting factors',A*B*ex!=B*A*ex)
        axes=[sp.Matrix([0,0,-1]),sp.Matrix([-s,0,0]),sp.Matrix([0,-1,0])]
        gt,ot=ex,ey
        no_spin=True; midpoint=True
        for leg in range(3):
            Rt=maps(s,theta)
            gv=Hchart*Rt[leg]*gt; ov=Hchart*Rt[(leg+1)%3]*ot
            no_spin &= equal(axes[leg].dot(gv),0) and equal(axes[(leg+1)%3].dot(ov),0)
            no_spin &= equal(axes[leg].cross(gv),gv.diff(theta)) and equal(axes[(leg+1)%3].cross(ov),ov.diff(theta))
            midpoint &= equal(gv.dot(ov),-sp.sin(theta)*sp.cos(theta))
            gt=[A,B,C][leg]*gt; ot=[A,B,C][(leg+1)%3]*ot
        check(f'cone s={s}: actual angular velocity has no own-axis component',no_spin)
        check(f'cone s={s}: equal-progress axis-dot identity',midpoint)
        F0=I
        g1,o1=Hchart*A*ex,Hchart*B*ey
        F1=sp.Matrix.hstack(g1,o1,g1.cross(o1))
        rigid_axis=sp.Matrix([-s,s,-1])/sp.sqrt(3)
        check(f'rigid s={s}: first leg 120deg with nonzero axial spin',
              sp.trace(F1)==0 and rigid_axis.dot(ex)!=0 and rigid_axis.dot(ey)!=0)
        rigid3=sp.diag(-s,-s,1)
        result[str(s)]={'G3_chart':exact(G),'O3_chart':exact(O),
                         'G3_computational':exact(Hchart*G*Hchart),
                         'O3_computational':exact(Hchart*O*Hchart),
                         'independent_frame_return_legs':3*order,
                         'label_return_legs':6 if s==1 else 3,
                         'pair_axes_return_legs':3,
                         'rigid3_computational':exact(rigid3),'rigid_frame_return_legs':6 if s==1 else 3}
    results['exact']['cone']=result
    # Matched transport proof uses only orthonormal columns, not mesh coordinates.
    angles=[0,2*sp.pi/3,4*sp.pi/3]
    E=[sp.Matrix.hstack(sp.Matrix([sp.cos(a),sp.sin(a),0]),ez) for a in angles]
    T=lambda i,j:E[i]*E[j].T
    check('matched tangent frames have E_i^T E_i=I2',all(equal(e.T*e,sp.eye(2)) for e in E))
    check('matched transport composition for all labels',all(equal(T(i,j)*T(j,k),T(i,k)) for i in range(3) for j in range(3) for k in range(3)))
    check('closed matched transport is identity on tangent plane',equal(T(0,2)*T(2,1)*T(1,0)*E[0],E[0]))
    # The model-independent vector identity used to identify parallel transport.
    u=sp.Matrix(sp.symbols('u0:3',real=True)); d=sp.Matrix(sp.symbols('d0:3',real=True)); v=sp.Matrix(sp.symbols('v0:3',real=True))
    check('parallel-transport vector triple identity',equal(u.cross(d).cross(v),d*(u.dot(v))-u*(d.dot(v))))


def srg_algebra():
    q,r,c=sp.symbols('q r c',real=True)
    w=-sp.Rational(1,2)+sp.I*sp.sqrt(3)/2
    f0=sp.ones(3,1)/sp.sqrt(3)
    Z=sp.diag(1,sp.conjugate(w),w)
    fs=[f0,Z*f0,Z**2*f0]
    p=f0*f0.T
    A=(q*I+(r-q)*p)*Z*(c*I+(1-c)*p)
    D=r*q*q*c*c
    check('SRG weighted Fourier cycle',all(equal(A*fs[j],[q,q*c,r*c][j]*fs[(j+1)%3]) for j in range(3)))
    check('SRG A cubed scalar in complete Fourier basis',equal(sp.Matrix.hstack(*fs).conjugate().T*sp.Matrix.hstack(*fs),I) and equal(A**3,D*I))
    # In Fourier coordinates A is a weighted permutation, allowing cheap tensor checks.
    Af=sp.Matrix([[0,0,r*c],[q,0,0],[0,q*c,0]])
    b0,b1=sp.symbols('b0 b1')
    Bdiag=sp.diag(b0,b1); U=sp.kronecker_product(Bdiag,Af)
    check('SRG tensor powers 3 and 12',equal(U**3,D*sp.kronecker_product(Bdiag**3,I)) and equal(U**12,D**4*sp.kronecker_product(Bdiag**12,I)))
    E=sp.Matrix.hstack(I,sp.zeros(3)); T=E.T
    check('SRG helicity extraction/injection intertwining in eigenbasis',equal(E*U,b0*Af*E) and equal(U*T,T*b0*Af) and E*T==I)
    def displays(dps):
        with mp.workdps(dps):
            alpha=61*mp.pi/125; beta=61*mp.pi/250
            t=mp.cos(alpha)*mp.cos(beta); delta=mp.asin(t); vartheta=mp.acos(t)
            Dv=mp.exp(-mp.mpf(269)/1000)*(mp.mpf(191)/500)**2
            return [vartheta*180/mp.pi,3*vartheta*180/mp.pi,12*delta*180/mp.pi,Dv,Dv**4,delta]
    a,b=displays(80),displays(100)
    check('fixed SRG display stability at 80/100 digits',all(abs(x-y)<mp.mpf('1e-75') for x,y in zip(a,b)),'high-precision display check, not interval proof')
    check('fixed SRG strict-bound diagnostic',0<a[5]<3*mp.pi/250 and 0<a[3]<1,'diagnostic for analytical strict bounds in report')
    results['srg_displays']={n:mp.nstr(v,65) for n,v in zip(['vartheta_degrees','three_vartheta_degrees','twelve_delta_degrees','D','D4','delta_radians'],b)}
    # Exact upper bound sufficient for distinct eigenvalues at steps 3 and 12.
    check('nonresonance bound is strictly below pi',sp.Rational(36,250)<1 and sp.Rational(18,250)<1)


if __name__ == '__main__':
    try:
        comparison_algebra()
        native_cases()
        cone_algebra()
        srg_algebra()
    except Exception:
        results['execution_error']=traceback.format_exc()
        print(results['execution_error'])
    results['totals']={'checks':len(checks),'passed':sum(c['passed'] for c in checks),
                       'failed':sum(not c['passed'] for c in checks),'errors':int('execution_error' in results),
                       'native_cases':len(results['native_cases']),
                       'native_updates':sum(c['updates'] for c in results['native_cases'].values())}
    (ROOT/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results['totals']))
    sys.exit(int(results['totals']['failed']>0 or results['totals']['errors']>0))
