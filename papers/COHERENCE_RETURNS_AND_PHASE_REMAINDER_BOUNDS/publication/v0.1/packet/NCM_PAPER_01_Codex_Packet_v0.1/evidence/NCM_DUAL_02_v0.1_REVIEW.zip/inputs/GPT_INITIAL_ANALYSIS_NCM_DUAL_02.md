# NCM-DUAL-02 — Initial equation-level analysis

**31 October 2026. GPT lead analysis for independent Codex review. Not a paper, native-motion certificate, or publication authorization.**

## Controlling author clarification

The author's latest clarification supersedes the literal controller interpretation in NCM-DUAL-01: “golden ratio” was a visual oversimplification of the cones/Tri-Octagon, not an operative requirement or a requested controller law for this motion. Do not search for a golden-ratio fit, assign it to cone dimensions or speed, or turn its absence into a blocker. Preserve historical equations' actual constants without changing them. Do not edit the completed NCM-DUAL-01 report retrospectively; record this clarification alongside it.

The author wants an investigation of whether the established mathematics supports the proposed duality/choreography. They do not want new forcing, clocks, recurrences, or pose rules invented to reproduce the sketch. The occurrence of 0,3,6,9,12 is a research lead, not an imposed numerical target.

## 1. What has and has not been established

NCM-DUAL-01 realizes the supplied station axes (x,y) → (y,z) → (z,x) with persistent signs, both inward branches, an independent quarter-turn interpolation, and a rigid comparator. The continuation beyond station 2 is explicitly an investigative choice. Equal-progress independent turns yield the 60-degree smaller pair-axis midpoint. In the near-first branch a three-leg loop restores cone labels while retaining a 90-degree roll of deliberately added markers, and four such loops restore the transported frames.

These are results about prescribed kinematics. The bounded source crosswalk did not recover a native-state-to-cone transport equation. That is not yet a proof that no useful relationship exists. The next question is whether the existing equations support a nontrivial comparison or deduction, and exactly which part of the choreography it covers.

The new lead checks in this packet use self-contained algebra. They do not rerun an old checker, import the project, generate a native trajectory, or verify the Windows installation. Nineteen checks passed under Python 3.13.5 / SymPy 1.14.0 / mpmath 1.3.0. Decimal values below are high-precision displays, not interval enclosures. Codex must review the reasoning, not inherit this memo as an accepted theorem.

## 2. An exact three-by-four algebra already available in the source mathematics

Let Pi cycle the three channel coordinates:

    Pi (z0,z1,z2)^T = (z2,z0,z1)^T.

Let J multiply the whole complex state by i. Then Pi^3=I, J^4=I and Pi J=J Pi. Define the COMPARISON operator Q=J Pi=i Pi. It follows exactly that

    Q^3  = -i I,
    Q^6  = -I,
    Q^9  = +i I,
    Q^12 = I.

Q has operator order twelve. This does not mean every individual state has minimal period twelve under Q: the equal-channel line has order four, and quotient observations may return sooner. An exact example z=(1,2,3i)^T has first state return twelve and first coherence return three under Q. This algebraic example is NOT a native trajectory.

The historical SRG-I reconstruction already proves J^2=-I and J^4=I and explicitly distinguishes this phase orbit from evolution. The channel cycle is part of the adopted three-channel geometry/representation. Combining them is a legitimate new comparison of inherited operations, not a new recurrence to install.

### Symmetry is not the update

For the native amplitude stage, write

    M(z;k)=I+epsilon diag(k-|z|^2)+g L3,
    V(z;k)=M(z;k) z.

Direct substitution gives

    V(i Pi z; Pi k) = i Pi V(z;k).

On the regular pre-synchronization domain, where all components of V are nonzero, the simultaneous phase stage preserves this covariance because it depends on phase differences. For equal k this becomes F(Qz;k)=QF(z;k). With unequal k it is parameter-covariance, not generally a symmetry of one fixed-parameter run. For nonzero phase strength, Arg0 at zero prevents a blanket global common-phase equivariance claim. At phase strength zero the amplitude covariance is global in the exact formulas.

Crucially, FQ=QF is NOT F=Q. With k=(1,1,1), z=(1,1,1), the native amplitude increment is zero, the graph increment is zero, and every phase increment is zero. Thus F(z)=z for all real epsilon, g and phase strength at that state, whereas Qz=iz. The actual update does not generally execute the twelvefold comparison orbit.

The cone rotations A,B_s,C are noncommuting spatial rotations. Pi and J commute. An equality of return counts is therefore much weaker than equivalence of the step operators, their representations, or the intermediate paths. The 60-degree cone midpoint is not supplied by Q's twelvefold order.

**Question for Codex:** Is there an inherited, dynamically meaningful restricted branch, quotient, or equivariant return relation that connects the two descriptions without promoting Q to a new update? State the domain and what is compared. Do not search by changing parameters until twelve appears.

## 3. The native coherence quotient supplies a genuine place to test hidden return information

The accepted observables/closure chapter defines

    H(z)=z z†.

For nonzero z, equality H(z')=H(z) is equivalent to z'=exp(i chi) z. This retains absolute amplitude and relative complex shape but forgets one common phase. The source proves an autonomous H update on its regular pre-state domain, not globally across the native zero convention.

Suppose an actual native trajectory remains in the regular equivariant domain, has nonzero state, and satisfies

    H(z_(n+p))=H(z_n).

Then z_(n+p)=mu z_n with |mu|=1. Equivariance allows iteration of the same p-step return as z_(n+mp)=mu^m z_n, while the required regularity persists. If p is the minimal coherence period and mu is a primitive q-th root of unity, the full-state period is pq. In particular, p=3 and mu=+i or -i would give a genuine twelve-update full-state return.

This is a conditional mechanism, NOT an existence proof of that native orbit. A non-root-of-unity mu gives relative-periodic rather than exactly periodic state evolution. If only the trace-normalized projector H/tr(H) returns, a magnitude multiplier may also remain; that is a different claim. Preserve the distinction between state, coherence, normalized ray, physical pose, and transported frame.

The accepted D1 branch already supplies F(z)=exp(i omega) z, hence stationary coherence with nonzero native phase advance. This proves that “a readout returns while the full state changes” is meaningful inside the established native model. D1 does not supply a three-step shape cycle, a prescribed quarter-turn, an attracting orbit, or a spatial cone pose.

The accepted M3 cycle and coherent-relaxation theorem provide other controls. Use their proved scopes rather than rerunning their certificates or claiming that they classify all native motion. In particular, a convergent coherent domain cannot contain a nontrivial sustained twelve-cycle; that does not classify the earlier turning entrance or all parameters.

### Memoryless maps cannot keep a history-dependent orientation after exact full-state return

If R(z) is a single-valued current-state readout, z_(n+p)=z_n implies R(z_(n+p))=R(z_n). A residual marked orientation after exact full-state return would therefore require information already carried elsewhere in the established state, or a newly chosen history-dependent transport. A history-dependent geometric diagnostic can be mathematically legitimate, but it must not be mislabeled as an existing native state variable.

Conversely, H returning while z changes phase leaves real information available in z. Whether that phase maps to the two cone frames is a separate representation problem. The two independent cone frame transports must not be collapsed into one scalar phase merely because their three-leg remainders are quarter-turns.

## 4. The fixed SRG transfer has a genuine three-step mechanism, but not this exact twelve-step return

The accepted Final Mathematical Bridge states, in the ordered channel Fourier basis,

    A f0=q f1,  A f1=qc f2,  A f2=rc f0,
    A^3=D I3,   D=r q^2 c^2,
    U=B tensor A,
    B=exp(-i alpha sigma_z) exp(-i beta sigma_x).

Here q=exp(-0.423), r=exp(0.577), c=1-0.618, alpha=2 pi (0.244), beta=pi (0.244). This is a fixed linear transfer used in a documented preparation/reduction route, not the nonlinear native recurrence.

Consequently

    U^3 = D (B^3 tensor I3),
    U^12 = D^4 (B^12 tensor I3).

A direction can return in the channel factor while scale and helicity information remain. This is a source-grounded comparison with visible versus hidden return. But its residual operator has to be calculated, not rounded into a quarter-turn.

### Exact short nonresonance argument at the frozen literals

Write tr(B)/2=cos(alpha)cos(beta)=t and eigenvalues exp(±i vartheta), vartheta=acos(t). The source constants give

    alpha=61 pi/125 = pi/2 - 3 pi/250,
    beta=61 pi/250,    0<beta<pi/2.

Thus 0<t<sin(3 pi/250). Let delta=asin(t), so

    0<delta<3 pi/250,
    vartheta=pi/2-delta.

The eigenvalues of B^12 are exp(∓12 i delta). Because 0<12 delta<36 pi/250<pi, they are distinct and B^12 is neither +I nor -I, nor any scalar matrix. B^3 is likewise not the exact opposite-quarter-phase pair from delta=0. This is an exact inequality argument; the decimals merely illustrate it.

D=exp(-0.269)*(0.382)^2 is strictly between zero and one. Hence ||U^(3m) psi||=D^m||psi||. In particular, there is no nonzero raw finite-period orbit of this fixed transfer: any claimed p-period would also give a 3p-period, contradicting contraction at multiples of three.

This does not prohibit returns of a normalized or projective observation. For example a helicity eigenvector can return projectively even though B^12 is not a scalar operator on the whole helicity space. State-specific exceptions must remain distinct from an operator identity.

80-digit evaluation gives:

| Quantity | Display value |
|---|---:|
| vartheta, internal eigenphase | 88.4443098768953 degrees |
| 3 vartheta | 265.332929630686 degrees |
| twelve-step remainder magnitude 12 delta | 18.6682814772564 degrees |
| D | 0.111506840437208 |
| D^4 | 0.000154598772296353 |

These are internal matrix phases and amplitude factors, not spatial cone angles or a physical spin rate. No source constant was changed. The source's exact helicity extraction is a valid linear reduction, but the accepted bridge explicitly distinguishes that transfer from the nonlinear native map.

## 5. The connection/transport comparison needs its own check

The native face-state decoder has matched transports

    T_ij=t_i t_j^T + e_z e_z^T,
    T_ij T_jk=T_ik

on their two-dimensional tangent domains. Closed matched label transport is identity. The near-first cone loop instead has a nontrivial quarter-turn on a carried transverse marker.

A single-valued, fixed change of frame at each label conjugates a closed-loop transport; it cannot turn identity into a nonidentity quarter-turn. Therefore simple frame-relabeling alone cannot identify these particular connections. This is a scoped obstruction, not a theorem against state-dependent geometry, other existing transports, or all native orientation phenomena.

Derive the cone loop's carried turn directly from its matrices. No external geometric-phase analogy is required. If standard curved-sphere parallel transport is used as interpretation, prove that its no-own-axis-spin convention actually agrees on these legs and label that convention as the specified kinematic transport, not as a force law furnished by the reference sphere.

## 6. What would count as progress toward a research paper

A useful outcome must add a source-grounded result about the established model: an exact correspondence on a stated domain, a native observable/return theorem, a nontrivial comparison with explicit limits, or a precise obstruction explaining why the tempting correspondence fails. Merely rediscovering Q^12=I, noncommuting rotations, or three-by-four arithmetic is not enough by itself to claim a new model mechanism.

The positive claim “the native model supports this choreography” needs an explicit map and an evolution statement, for example Amap(F^m z)=K(Amap(z)) on a specified domain, or a precisely weaker, justified result. Any count conversion, stage variable, normalization, orientation frame, gauge, or history dependence must be declared. A per-step fitted rotation or a pose indexed only by n mod 3 is an imposed animation, not a derived correspondence.

Do not insist that a useful partial connection reproduce every proxy cone dimension, every intermediate frame, or exactly twelve updates. Do state which original features it does and does not explain. If every plausible connection requires a new law, stop this motion-extension direction and report that; do not salvage it by forcing a fit or commissioning a kinematics-only paper contrary to the author's condition.

## Sources actually read for these leads

Reading ref: `7cc1fa03af589818bcdcfaaac51838cc36c84253`, repository `pzychozen/trioctagon-physics`. This is a reading baseline, not a claim about current HEAD. The following were read through the GitHub connector; no repository was cloned and no project module was executed. A separate attempt to obtain raw snapshots in the sandbox failed at DNS resolution; no raw source-byte verification is claimed here.

1. `SRG_REDISCOVERY/PAPERS/SRG_I_FOUNDATIONAL_RECONSTRUCTION/publication/v0.1.1/manuscript/SRG_I_v0.1.1.tex`, phase-order proposition and quarter-cycle discussion, source lines 740–790; later real coupled-field distinctions at 830–970. The historical J identity is not a new native evolution rule.
2. `papers/NATIVE_RESPONSE_GEOMETRY/manuscript/observables_closure.tex`, adopted decoder/matched connection (also available in the conversation source extracts), and closure chapter, source lines 135–300. Regularity and zero-stratum exceptions are controlling.
3. `papers/MEASUREMENT_AND_CHIRAL_DRIFT/v0.1/drift/manuscript.tex`, abstract and sections 1–2, source lines 1–145. Native relative equilibrium, inherited coefficients, phase convention, no spatial rotation identification.
4. `SRG_REDISCOVERY/FINAL_MATHEMATICAL_BRIDGE/publication/v0.1/SRG_FINAL_MATHEMATICAL_BRIDGE_v0.1.md`, section 3 equations F2–F7, section 5 equations N1–N3, and source guide. Fixed SRG versus nonlinear dynamics and accepted extraction.
5. Supplied `NCM-DUAL-01_v0.1_review.zip` and its report as available in conversation: section “Tested periodic extension,” equations for T_G,T_O, and the assumptions/limits table. Earlier check results are inherited, not rerun here.

The companion work order directs Codex to verify actual local sources, inspect only relevant additional accepted results, and independently challenge every new statement above.
