# Native finite capacity access — GPT acceptance package

Start with **NATIVE_FINITE_CAPACITY_ACCESS_01_GPT_REVIEW.md**.

**Disposition:** Accepted unchanged at the commissioned finite-parameter, combined-external-stock scope. No corrective Codex round is required. This is a project-internal investigation review, not publication authorization.

## Contents

- The signed-by-role GPT review report (not a cryptographic signature).
- `verification/REVIEW_VERIFICATION.json`: independently generated archive, source, preservation, scope and replay results.
- `verification/review_verify.py`: read-only input verifier used in this review.
- `replay/exact_checks.py` and `replay/EXACT_ALGEBRA_RESULTS.json`: an unchanged isolated copy of Codex's inspected checker and the fresh reviewer execution.
- `reference/NATIVE_FINITE_CAPACITY_ACCESS_01_CODEX_WORK_ORDER.md`: independently retrieved issued Library version 1.
- `accepted_submission/`: the exact received ZIP and checksum, standalone proof, completion report, ledger and original check results. The ZIP retains all selected defining sources and their original records.
- `REVIEW_MANIFEST.json`: exhaustive payload hashes with self-exclusion.

The review distinguishes live execution from recorded execution. No new remote download or live Windows preservation audit occurred. The original 77 input-preservation entries were reconciled against baseline; 74 actual delivered members and the separately retrieved issued order were checked. The originally issued input ZIP and its checksum are record-only items in this review. All 62 selected registry entries match their carried bytes; 59 were additionally matched to the previous separately uploaded publication payload, and two further records to separate uploads.

## Reproduction

For the eight algebra groups, use an installed Python with SymPy 1.14.0 and run:

    python -I -B replay/exact_checks.py

That overwrites only the result JSON in that replay directory, so preserve a copy of the review package before rerunning it. It executes no trajectories, historical helper, network call or repository operation. Runtime metadata will differ; the eight `checks` records are the mathematical replay comparison.

To reproduce `review_verify.py`, stage the original conversation uploads in a base directory, including the separately supplied prior `NATIVE_TRANSFER_CAPACITY_POLISH_PUBLISH_01_CLOSEOUT.zip` and adjacent checksum, `REMOTE_BYTE_COMPARISON.json`, and `PUBLICATION_RECEIPT(20261104-175454).md`. Stage the current submission ZIP, its checksum, standalone proof and completion report there too. Extract the current submission to `<work>/submission/`, place this package's reference and replay directories in `<work>/`, then run:

    python -I -B verification/review_verify.py --base <uploads-directory> --work <work>

The prior large publication archive is not duplicated here. Its exact identity and all 59 compared paths are in the verification JSON. No network is needed. The script writes `<work>/REVIEW_VERIFICATION.json` and leaves input files unchanged.

This package adds no new theorem, physical claim, manuscript, publication or successor work order. The geometric agenda remains carried by the original submitted sources and the review report.
