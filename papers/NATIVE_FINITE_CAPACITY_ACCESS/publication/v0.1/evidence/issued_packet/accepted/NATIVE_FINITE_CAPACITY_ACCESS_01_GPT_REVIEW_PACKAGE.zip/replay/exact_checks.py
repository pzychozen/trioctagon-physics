"""Eight focused exact-algebra groups for FA01. No trajectories or historical replays."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,sys
from fractions import Fraction as Q
import sympy as s

W=Path(__file__).resolve().parent
checks=[]
def zero(expr):
    assert s.simplify(s.expand(expr))==0,expr
def passed(id,title,evidence,boundary):
    checks.append(dict(id=id,title=title,status="PASS",evidence=evidence,scope_limit=boundary))
eta,alpha,beta,k,R,m,d,c,kappa,t,nu,Fmag=s.symbols(
    "eta alpha beta k R m d c kappa t nu Fmag",positive=True)

# EC01: original-variable weighting, including both propagation summands.
p,r,ps,rs,z1,z2,y1,y2=s.symbols("p r ps rs z1 z2 y1 y2",real=True)
receiver=-kappa*(z1*y1+z2*y2)+beta*(z1*kappa*y1/beta+z2*kappa*y2/beta)
zero(receiver)
propagation=-c*p*rs-c*r*ps
zero(propagation+c*(ps*r+p*rs))
passed("EC01","Original weighted cancellation",
       {"receiver_sum":str(s.simplify(receiver)),
        "propagation_density":"-c*d_s(p*r_c)"},
       "Periodic Sobolev integration and the regularized norm proof are written in the proof; scalar algebra alone does not establish them.")

# EC02: compute the actual polynomial drive derivative from the native cross-product equations.
av=s.Matrix(s.symbols("a1:4",real=True));bv=s.Matrix(s.symbols("b1:4",real=True))
K=s.Matrix(2,3,s.symbols("K0:6",real=True));yv=s.Matrix([y1,y2])
f=K*av.cross(bv);J=f.jacobian(list(av)+list(bv));mu=eta/(2*alpha)
w=K.T*yv;adot=mu*w.cross(bv);bdot=-mu*w.cross(av)
xdot=s.Matrix.vstack(adot,bdot)
for value in xdot+mu*J.T*yv:zero(value)
fdot=K*(adot.cross(bv)+av.cross(bdot))
for value in fdot+mu*J*J.T*yv:zero(value)
A0=eta*s.sqrt(m)*Fmag
drive_coefficient=eta*k**2*R**2*s.sqrt(m)/(2*alpha)
nu2=eta**2*m*k**2*R**2/(2*alpha)
zero(drive_coefficient*A0/Fmag-nu2)
passed("EC02","Native drive derivative and Volterra coefficient",
       {"derivative":"-eta_N*J*J.T*y/(2*alpha_N)",
        "nu_squared":str(nu2)},
       "The Jacobian/operator norm inequalities and continuity are proved analytically, not by symbolic sampling.")

# EC03: evaluate L U_ref plus constant forcing minus U_ref derivative.
space=s.symbols("s",real=True);fp,fm=s.symbols("f_plus f_minus",real=True)
bp=s.Function("b_plus")(space);bm=s.Function("b_minus")(space)
pref=eta*t*(bp*fp+bm*fm)
residual=s.Matrix([eta*(bp*fp+bm*fm)-s.diff(pref,t),
                   -c*s.diff(pref,space),
                   kappa*eta*t*m*fp/beta,kappa*eta*t*m*fm/beta])
expected=s.Matrix([0,-c*eta*t*(s.diff(bp,space)*fp+s.diff(bm,space)*fm),
                   kappa*eta*m*t*fp/beta,kappa*eta*m*t*fm/beta])
for value in residual-expected:zero(value)
weighted=eta**2*t**2*(fp**2+fm**2)*c**2*d+beta*(kappa*eta*m*t/beta)**2*(fp**2+fm**2)
sigma2=c**2*d/m+kappa**2*m/beta
zero(weighted-eta**2*m*(fp**2+fm**2)*sigma2*t**2)
passed("EC03","Both reference residuals and their weighted norm",
       {"carrier_sign":"negative second carrier coordinate",
        "receiver_sign":"positive",
        "squared_norm":str(s.factor(weighted)),
        "sigma_ext_squared":str(sigma2)},
       "Uses the inherited exact port identities; no tent second derivative or spatial discretization is taken.")

# EC04: general monomial kernel identity and exact comparison integral.
n=s.symbols("n",integer=True,nonnegative=True);tau=s.symbols("tau",positive=True)
kernel_monomial=s.integrate((t-tau)*tau**n,(tau,0,t))
zero(kernel_monomial-t**(n+2)/((n+1)*(n+2)))
zero(s.combsimp(s.factorial(2*n+3)-(2*n+3)*(2*n+2)*s.factorial(2*n+1)))
majorant=s.sinh(nu*t)/nu
zero(s.diff(majorant,t,2)-nu**2*majorant)
zero(majorant.subs(t,0));zero(s.diff(majorant,t).subs(t,0)-1)
zero(s.integrate(s.cosh(nu*tau)-1,(tau,0,t))-(majorant-t))
passed("EC04","Volterra monomial and comparison integral",
       {"kernel_on_t_power_n":str(s.factor(kernel_monomial)),
        "majorant":"sinh(nu*t)/nu",
        "integrated_drive_error":"sinh(nu*t)/nu-t"},
       "Positive-kernel iteration, boundedness on finite intervals and vanishing factorial remainder are proved in the written argument.")

# EC05: normalized yaw capacity, with positive denominators justified in the proof.
q,G=s.symbols("q G",real=True)
ratio=s.cancel(alpha*(10*G**2*(1-q**2)/7)/((8*G**2/7)*3*alpha*(1-q)))
zero(ratio-s.Rational(5,12)*(1+q))
zero(A0**2/(2*nu2)-alpha*Fmag**2/(k**2*R**2))
zero(alpha*(1-q)/(alpha*s.Rational(3,2))-s.Rational(2,3)*(1-q))
passed("EC05","Capacity normalization and storage conversion",
       {"capacity_factor":str(ratio),"C_joint_over_HN0":"2*(1-cos(phi))/3",
        "A0_squared_over_2nu_squared":"alpha_N*|f0|^2/(k^2*R^2)"},
       "q=cos(phi), sin(phi)^2=1-q^2 and the admitted phase ensures nonzero denominators. The old accessibility statistic is not redefined.")

# EC06: strict rational bounds, not floating point evaluations.
sqrt3_gap=Q(3)-Q(161,100)**2
assert sqrt3_gap>0
assert (Q(2)+Q(161,100))/4==Q(19,20)**2
j=s.symbols("j",integer=True,positive=True)
zero((2*j+2)*(2*j+3)-20-2*(j-1)*(2*j+7))
sinh_upper=Q(1)+Q(1,6)/(1-Q(1,20))
assert sinh_upper==Q(67,57)
sinh_gap=Q(19,16)-sinh_upper
assert sinh_gap==Q(11,912)>0
passed("EC06","Exact cosine and hyperbolic-sine rational certificates",
       {"3_minus_161_100_squared":str(sqrt3_gap),
        "cosine_squared_comparison":"(2+161/100)/4 = (19/20)^2",
        "tail_ratio_denominator_minus_20":"2*(j-1)*(2*j+7)",
        "geometric_sinh_upper":str(sinh_upper),
        "19_16_minus_upper":str(sinh_gap)},
       "Strictness of the series tail and monotonicity/positivity of cosine on the admitted interval are supplied in the proof.")

# EC07: positive bracket licenses squaring, then the strict quarter margin.
bracket=Q(7,4)-Q(19,16);coefficient=Q(5,12)*(1+Q(19,20))
assert bracket==Q(9,16)>0 and coefficient==Q(13,16)
margin=coefficient*bracket**2
assert margin==Q(1053,4096)
assert margin-Q(1,4)==Q(29,4096)>0
passed("EC07","Positive norm margin and final fraction",
       {"bracket_lower":"strictly greater than "+str(bracket),
        "factor_lower":"strictly greater than "+str(coefficient),
        "final_fraction":str(margin),"excess_over_quarter":str(margin-Q(1,4))},
       "Applies to actual total external stock only after the analytical comparison bound.")

# EC08: exact condition equivalence and restored units with R retained.
threshold=8*alpha*sigma2/(m*k**2*R**2)
zero(sigma2-nu2/4-(m*k**2*R**2/(8*alpha))*(threshold-eta**2))
# Dimensions represented as exponents of (carrier amplitude U, length L, time T, native amplitude A).
dim={
    "eta":(0,0,0,0),"kappa":(0,0,0,0),"alpha":(2,1,0,-2),
    "beta":(0,-1,2,0),"k":(1,1,-1,-2),"R":(0,0,0,1),
    "m":(0,-1,0,0),"d":(0,-3,0,0),"c":(0,1,-1,0),"f":(1,1,-1,0)}
def units(*terms):
    return tuple(sum(Q(power)*dim[name][i] for name,power in terms) for i in range(4))
time_rate_sq=(Q(0),Q(0),Q(-2),Q(0))
nu_units=units(("eta",2),("m",1),("k",2),("R",2),("alpha",-1))
prop_units=units(("c",2),("d",1),("m",-1))
recv_units=units(("kappa",2),("m",1),("beta",-1))
assert nu_units==prop_units==recv_units==time_rate_sq
A0_units=units(("eta",1),("m",Q(1,2)),("f",1))
assert A0_units==(Q(1),Q(1,2),Q(-1),Q(0))
threshold_units=tuple(a+b for a,b in zip(units(("alpha",1),("m",-1),("k",-2),("R",-2)),time_rate_sq))
assert threshold_units==(0,0,0,0)
passed("EC08","Finite regime equivalence and dimensions",
       {"threshold_eta_squared":str(threshold),
        "positive_multiplier":"m*k^2*R^2/(8*alpha_N)",
        "nu_squared_and_both_sigma_terms_units":"T^-2",
        "A0_units":"U*L^(1/2)/T","eta_squared_threshold_units":"1",
        "R_squared_retained_in_dimensional_formula":True},
       "Nonemptiness follows from positivity/finiteness of fixed coefficients, with one finite eta_N chosen before all phase trajectories.")

record={"utc":datetime.now(timezone.utc).isoformat(),"status":"PASS","task":W.name,
        "independent_check_groups":len(checks),"checks":checks,
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python":sys.executable,"python_version":sys.version,"sympy_version":s.__version__,
        "arithmetic":"Exact symbolic identities and rational inequalities; no floating-point certificate.",
        "scope":"New investigation's focused algebra only. No supplied readiness script or prior 18 AT/12 PC suite executed. No numerical trajectories, parameter scans or proof of regularity by software."}
assert len(checks)==8
(W/"EXACT_ALGEBRA_RESULTS.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"status":"PASS","groups":len(checks),"sympy":s.__version__,"script_sha256":record["script_sha256"]}))
