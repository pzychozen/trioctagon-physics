"""Independent FA01 delivery/replay checks. Reads inputs; writes reviewer JSON only.
No network, Git, simulations, PDF rendering, or supplied assembly scripts.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, hashlib, json, re, stat, sys, zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--base', type=Path, default=Path('/mnt/data'), help='Directory of original conversation uploads')
parser.add_argument('--work', type=Path, default=None, help='Review directory containing submission/, reference/, and replay/')
args = parser.parse_args()
BASE = args.base
WORK = args.work if args.work is not None else BASE / 'fa01_gpt_review'
SUB = WORK / 'submission'
OUT = WORK / 'REVIEW_VERIFICATION.json'

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def identity(data: bytes) -> dict:
    return {'bytes': len(data), 'sha256': digest(data)}

def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))

def verified_manifest(z, manifest_path: str, prefix: str = '') -> dict:
    manifest = json.loads(z.read(manifest_path))
    rows = manifest['files']
    expected = {prefix + row['path'] for row in rows}
    assert len(expected) == len(rows), 'Duplicate manifest paths'
    actual = {n for n in z.namelist() if not n.endswith('/') and n.startswith(prefix)}
    assert actual == expected | {manifest_path}, 'Manifest not exhaustive'
    for row in rows:
        assert identity(z.read(prefix + row['path'])) == {'bytes': row['bytes'], 'sha256': row['sha256']}, row['path']
    return {'status': 'PASS', 'payload_count': len(rows), 'manifest': manifest_path,
            'self_excluded': manifest.get('self_excluded')}

archive = BASE / 'NATIVE_FINITE_CAPACITY_ACCESS_01_REVIEW_PACKAGE.zip'
checksum = archive.with_suffix('.zip.sha256')
assert checksum.read_text().split()[0] == digest(archive.read_bytes())
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == len({n.casefold() for n in names})
    for info in z.infolist():
        p = PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename
        assert not stat.S_ISLNK(info.external_attr >> 16)
    assert z.testzip() is None
    top = verified_manifest(z, 'REVIEW_MANIFEST.json')
    nested = verified_manifest(z, 'inputs/PACKET_MANIFEST.json', 'inputs/')
    standalone = {}
    for name in ['NATIVE_FINITE_CAPACITY_ACCESS_01_PROOF.md', 'COMPLETION_REPORT.md']:
        assert (BASE / name).read_bytes() == z.read(name)
        standalone[name] = identity(z.read(name))
    # Ensure the materialized extracted submission has not changed during reviewer replay.
    for name in names:
        assert (SUB / name).read_bytes() == z.read(name), name

order_name = 'NATIVE_FINITE_CAPACITY_ACCESS_01_CODEX_WORK_ORDER.md'
original_order = WORK / 'reference' / order_name
assert original_order.read_bytes() == (SUB / 'inputs' / order_name).read_bytes()

registry = load(SUB / 'inputs/SOURCE_IDENTITIES.json')
assert registry['input_count'] == len(registry['inputs']) == 62
assert len({r['path'] for r in registry['inputs']}) == 62
for row in registry['inputs']:
    assert identity((SUB / 'inputs' / row['path']).read_bytes()) == {'bytes': row['bytes'], 'sha256': row['sha256']}, row['path']

# Previously uploaded publication closeout is an independent retained byte reference.
prior = BASE / 'NATIVE_TRANSFER_CAPACITY_POLISH_PUBLISH_01_CLOSEOUT.zip'
assert digest(prior.read_bytes()) == prior.with_suffix('.zip.sha256').read_text().split()[0]
prior_identity = identity(prior.read_bytes())
remote = load(BASE / 'REMOTE_BYTE_COMPARISON.json')
assert (BASE / 'REMOTE_BYTE_COMPARISON.json').read_bytes() == (SUB / 'inputs/publication_evidence/REMOTE_BYTE_COMPARISON.json').read_bytes()
assert (BASE / 'PUBLICATION_RECEIPT(20261104-175454).md').read_bytes() == (SUB / 'inputs/publication_evidence/PUBLICATION_RECEIPT.md').read_bytes()
remote_rows = {r['path']: r for r in remote['files']}
p3manifest = load(SUB / 'inputs/published/P3/PUBLICATION_MANIFEST.json')
p3root = 'papers/RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY/publication/v0.1/'
p3rows = {r['path']: r for r in p3manifest['files']}
byte_reference_rows = []
manifest_matches = 0
with zipfile.ZipFile(prior) as z:
    for row in registry['inputs']:
        repo_path = row.get('accepted_containment_path')
        if not repo_path:
            continue
        supplied = (SUB / 'inputs' / row['path']).read_bytes()
        reference_member = 'published_payload/' + repo_path
        assert supplied == z.read(reference_member), row['path']
        rr = remote_rows[repo_path]
        assert rr['matches'] and rr['http_status'] == 200
        assert rr['bytes'] == rr['remote_bytes'] == len(supplied)
        assert rr['sha256'] == rr['remote_sha256'] == digest(supplied)
        rel = repo_path.removeprefix(p3root)
        if rel in p3rows:
            pr = p3rows[rel]
            assert identity(supplied) == {'bytes': pr['bytes'], 'sha256': pr['sha256']}
            manifest_matches += 1
        else:
            assert rel == 'PUBLICATION_MANIFEST.json'
        byte_reference_rows.append({'input': row['path'], 'prior_archive_member': reference_member,
                                    **identity(supplied), 'byte_identical': True,
                                    'historical_remote_record_matches': True})
assert len(byte_reference_rows) == 59 and manifest_matches == 58

baseline = load(SUB / 'INPUT_BASELINE.json')
preservation = load(SUB / 'INPUT_PRESERVATION.json')
assert len(baseline['files']) == len(preservation['files']) == preservation['protected_count'] == 77
assert {r['source_path'] for r in preservation['files']} == set(baseline['files'])
physical_member_matches = 0
record_only = []
for row in preservation['files']:
    assert row['before'] == row['after'] == baseline['files'][row['source_path']]
    assert row['unchanged'] is True
    member = row['review_archive_path']
    if member:
        assert identity((SUB / member).read_bytes()) == row['before'], member
        physical_member_matches += 1
    elif row['source_path'].endswith(order_name):
        assert identity(original_order.read_bytes()) == row['before']
    else:
        record_only.append(row['source_path'])
assert physical_member_matches == 74 and len(record_only) == 2

# Compare only scientific check content; execution metadata necessarily differs.
codex = load(SUB / 'EXACT_ALGEBRA_RESULTS.json')
replay = load(WORK / 'replay/EXACT_ALGEBRA_RESULTS.json')
assert codex['checks'] == replay['checks']
assert codex['status'] == replay['status'] == 'PASS'
assert codex['independent_check_groups'] == replay['independent_check_groups'] == 8
assert codex['script_sha256'] == replay['script_sha256'] == digest((SUB / 'exact_checks.py').read_bytes())
assert (SUB / 'exact_checks.py').read_bytes() == (WORK / 'replay/exact_checks.py').read_bytes()

proof_name = 'NATIVE_FINITE_CAPACITY_ACCESS_01_PROOF.md'
ledger_name = 'NATIVE_FINITE_CAPACITY_ACCESS_01_CLAIM_SOURCE_LEDGER.md'
proof = (SUB / proof_name).read_text()
cross = load(SUB / 'CLAIM_CROSSWALK.json')
assert cross['proof_sha256'] == digest((SUB / proof_name).read_bytes())
assert cross['ledger_sha256'] == digest((SUB / ledger_name).read_bytes())
tags = re.findall(r'\\tag\{(FA\d+)\}', proof)
assert len(tags) == len(set(tags)) == 26
assert set(tags) == {f'FA{i:02}' for i in range(1,27)} == {r['group'] for r in cross['reverse']}
assert len(cross['inherited']) == 15 and len(cross['new']) == 7
analytical = load(SUB / 'ANALYTICAL_REVIEW.json')
for key, name in [('proof',proof_name),('claim_source_ledger',ledger_name),('exact_check_script','exact_checks.py'),('exact_check_results','EXACT_ALGEBRA_RESULTS.json')]:
    assert analytical[key] == identity((SUB/name).read_bytes())
labels = load(SUB / 'inputs/published/P3/verification/LABELS.json')
# Label file can be a mapping directly or under a labels field.
labelmap = labels.get('labels', labels)
inputverification = load(SUB / 'INPUT_VERIFICATION.json')
for label, expected in inputverification['label_locators_verified'].items():
    actual = labelmap[label]
    if isinstance(actual, dict):
        actual = [actual.get('number', actual.get('label')), actual.get('page')]
    assert actual == expected, (label,actual,expected)

result = {
 'task':'NATIVE_FINITE_CAPACITY_ACCESS_01_GPT_REVIEW',
 'reviewer':'GPT (single project-internal review)',
 'utc':datetime.now(timezone.utc).isoformat(), 'status':'PASS',
 'submission': {'archive':archive.name, **identity(archive.read_bytes()),
                'checksum_matches':True, 'unique_safe_paths':True, 'crc_pass':True,
                'members':len(names), 'manifest':top, 'nested_packet_manifest':nested,
                'standalone_matches':standalone, 'extracted_submission_unchanged':True},
 'issued_order':{'independent_reference':'Library file_00000000c05c81f68584cd19938f23ad version 1',
                 **identity(original_order.read_bytes()), 'matches_returned_copy':True},
 'source_verification':{'registry_rows':62,'all_registry_hashes_valid':True,
    'published_primary_rows':registry['published_primary_file_count'],
    'independent_previous_publication_archive':{'name':prior.name, **prior_identity, 'checksum_matches':True},
    'selected_sources_matching_previous_publication_payload':59,
    'historical_remote_record_matches':59,'historical_manifest_matches':58,
    'receipt_and_remote_record_match_separate_uploads':True,
    'source_rows':byte_reference_rows,
    'limitation':'62 registry hashes checked; 59 compare to prior publication payload and 2 additional records to separate uploads. The carried subsequent GPT closeout review is hash-verified within this packet, not independently retrieved.'},
 'preservation':{'before_after_records_reconciled':77,'delivered_input_members_checked':74,
                 'additional_standalone_order_independently_compared':1,
                 'original_packet_and_checksum_record_only':record_only,
                 'scope':'No access to live Windows filesystem. Original input ZIP and its checksum were not separately available; their two before/after entries are record consistency checks only.'},
 'replay':{'groups':8,'all_check_payloads_identical':True,'script_sha256':replay['script_sha256'],
           'python_version':replay['python_version'],'sympy_version':replay['sympy_version'],
           'scope':'Fresh execution of supplied exact_checks.py in an isolated copy after code inspection; same eight check groups, not eight additional mathematical results.'},
 'crosswalk':{'inherited_groups':15,'new_steps':7,'proof_groups':26,
              'proof_and_ledger_hashes_bound':True,'printed_locators_checked':len(inputverification['label_locators_verified'])},
 'not_performed':['Fresh remote retrieval','Git operations','Live Windows audit','PDF rendering or compilation',
                  'Numerical trajectories','Parameter scans','Historical AT/PC test suites','Successor investigation'],
 'verifier_sha256':digest(Path(__file__).read_bytes())
}
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:result[k] for k in ['status','submission','issued_order','preservation','replay','crosswalk']},indent=2))
