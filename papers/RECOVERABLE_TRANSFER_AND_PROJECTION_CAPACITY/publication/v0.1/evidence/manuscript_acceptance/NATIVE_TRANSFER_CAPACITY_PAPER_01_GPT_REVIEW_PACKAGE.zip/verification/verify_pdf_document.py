#!/usr/bin/env python3
"""Read-only PDF/document audit. Does not compile TeX or execute submitted code."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import subprocess
from pypdf import PdfReader

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pdf', type=Path, required=True)
    ap.add_argument('--submission', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    a = ap.parse_args()
    reader = PdfReader(a.pdf)
    names = set(reader.named_destinations)
    page_refs = {p.indirect_reference.idnum for p in reader.pages}
    internal, uris, broken = [], [], []
    for page_no, page in enumerate(reader.pages, 1):
        for annotation in page.get('/Annots', []):
            obj = annotation.get_object()
            action = obj.get('/A', {})
            if action.get('/S') == '/URI':
                uris.append({'page': page_no, 'uri': str(action['/URI'])})
            if action.get('/S') == '/GoTo' or '/Dest' in obj:
                dest = action.get('/D', obj.get('/Dest'))
                if isinstance(dest, str):
                    valid = dest in names
                    target = dest
                elif isinstance(dest, list) and dest:
                    valid = getattr(dest[0], 'idnum', None) in page_refs
                    target = str(dest)
                else:
                    valid, target = False, str(dest)
                item = {'page': page_no, 'target': target, 'resolves': valid}
                internal.append(item)
                if not valid:
                    broken.append(item)
    text_pages = [p.extract_text() for p in reader.pages]
    font_output = subprocess.run(['pdffonts', str(a.pdf)], check=True, text=True, capture_output=True).stdout
    font_rows = [line.split() for line in font_output.splitlines()[2:] if line.strip()]
    fonts = [{'name': r[0], 'embedded': r[-5] == 'yes', 'subset': r[-4] == 'yes', 'unicode_map': r[-3] == 'yes'} for r in font_rows]
    log = (a.submission/'delivery_support/build_final/main.log').read_text(errors='replace')
    warning_pattern = r'(^!|(?:LaTeX|Package\s+\S+|Class\s+\S+)(?:\s+Font)?\s+Warning:|(?:Overfull|Underfull)\s+\\[hv]box|undefined (?:references|citations))'
    log_findings = [line for line in log.splitlines() if re.search(warning_pattern, line, re.I)]
    result = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Independent read-only document audit of the supplied final PDF and build log. No root compilation or scientific replay.',
        'pdf': {'name': a.pdf.name, 'bytes': a.pdf.stat().st_size, 'sha256': sha(a.pdf)},
        'page_count': len(reader.pages),
        'page_boxes': sorted(set(tuple(float(v) for v in p.mediabox) for p in reader.pages)),
        'metadata': {str(k): str(v) for k, v in reader.metadata.items()},
        'named_destination_count': len(names),
        'internal_link_count': len(internal),
        'internal_links': internal,
        'unresolved_internal_links': broken,
        'external_links': uris,
        'external_target_scope': 'Targets compared with the supplied immutable P1/P2 identities; no fresh remote-byte verification performed in this manuscript review.',
        'fonts': fonts,
        'page_text': [{'page': i, 'characters': len(t), 'has_running_title': 'Recoverable transfer and projection capacity' in t, 'has_draft_header': 'v0.1 draft' in t, 'unresolved_reference_marker': '??' in t} for i, t in enumerate(text_pages, 1)],
        'submitted_build_log_findings': log_findings,
    }
    result['checks'] = {
        'fifteen_pages': len(reader.pages) == 15,
        'all_pages_have_text': all(t.strip() for t in text_pages),
        'all_internal_links_resolve': not broken,
        'all_fonts_embedded': bool(fonts) and all(f['embedded'] for f in fonts),
        'all_body_pages_have_headers': all(p['has_running_title'] and p['has_draft_header'] for p in result['page_text'][1:]),
        'no_unresolved_reference_markers': all(not p['unresolved_reference_marker'] for p in result['page_text']),
        'submitted_final_build_log_clean': not log_findings,
    }
    result['status'] = 'PASS' if all(result['checks'].values()) else 'REVIEW_NEEDED'
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
    print(json.dumps({'status': result['status'], 'checks': result['checks'], 'pages': len(reader.pages), 'fonts': len(fonts), 'internal_links': len(internal), 'external_links': len(uris)}, indent=2))

if __name__ == '__main__':
    main()
