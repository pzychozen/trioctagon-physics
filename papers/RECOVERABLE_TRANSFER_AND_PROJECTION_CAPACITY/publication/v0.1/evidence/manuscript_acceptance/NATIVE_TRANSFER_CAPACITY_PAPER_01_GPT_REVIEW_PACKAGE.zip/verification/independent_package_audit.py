#!/usr/bin/env python3
"""Independent, read-only audit of NATIVE_TRANSFER_CAPACITY_PAPER_01.

Reads the original submitted ZIP, the original issued packet, their checksum
sidecars, and the standalone submitted PDF. Does not extract archives, import
submitted code, run TeX, execute scientific checks, access the network, or inspect
the submitter's Windows filesystem. Only --output, when supplied, is written.
Uses the Python standard library. Exit status 0 means all checks passed.
"""

import argparse
import datetime
import hashlib
import json
import re
import stat
import sys
import zipfile
import zlib
from collections import Counter
from pathlib import Path


EDITION = "candidate_edition/papers/RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY/publication/v0.1/"
PACKET_COPY = "evidence/input_packet/"
PDF_NAME = "RECOVERABLE_TRANSFER_AND_PROJECTION_CAPACITY_v0.1.pdf"
ORDER_NAME = "NATIVE_TRANSFER_CAPACITY_PAPER_01_CODEX_WORK_ORDER.md"
SCIENTIFIC = re.compile(r"^(eq|thm|prop|lemma|tab):")
GROUPS = {f"AT{i:02d}" for i in range(1, 30)} | {f"PC{i:02d}" for i in range(1, 23)}


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def strict_json(data):
    def pairs(items):
        obj = {}
        for key, value in items:
            need(key not in obj, f"Duplicate JSON key: {key}")
            obj[key] = value
        return obj
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs)


def safe_path(name):
    need(isinstance(name, str) and name, "Empty/non-string member path")
    need(not name.startswith(("/", "\\")), f"Absolute path: {name}")
    need("\\" not in name and ":" not in name and "\x00" not in name,
         f"Nonportable path: {name}")
    parts = name.split("/")
    need(all(p not in ("", ".", "..") and not p.endswith((" ", ".")) for p in parts),
         f"Unsafe path component: {name}")


class Audit:
    def __init__(self):
        self.checks = []

    def run(self, name, operation):
        try:
            details = operation()
            self.checks.append({"check": name, "status": "PASS", "details": details})
            return details
        except Exception as exc:
            self.checks.append({"check": name, "status": "FAIL", "error": str(exc)})
            return None


def read_archive(path, expected_members):
    payloads = {}
    with zipfile.ZipFile(path, "r") as archive:
        members = archive.infolist()
        need(len(members) == expected_members,
             f"Expected {expected_members} members; found {len(members)}")
        names = [item.filename for item in members]
        need(len(names) == len(set(names)), "Duplicate ZIP member names")
        need(len(names) == len({n.casefold() for n in names}), "Case-folded path collision")
        for item in members:
            safe_path(item.filename)
            need(not item.is_dir(), f"Unexpected directory entry: {item.filename}")
            need(not (item.flag_bits & 1), f"Encrypted member: {item.filename}")
            kind = stat.S_IFMT(item.external_attr >> 16)
            need(kind in (0, stat.S_IFREG), f"Nonregular member: {item.filename}")
            data = archive.read(item)  # zipfile also verifies its recorded CRC.
            need(len(data) == item.file_size, f"Uncompressed-size mismatch: {item.filename}")
            need((zlib.crc32(data) & 0xFFFFFFFF) == item.CRC, f"CRC mismatch: {item.filename}")
            payloads[item.filename] = data
    return payloads


def rows_by_path(rows, field="path"):
    result = {}
    for row in rows:
        path = row[field]
        safe_path(path)
        need(path not in result, f"Duplicate record path: {path}")
        result[path] = row
    return result


def match_record(row, data, description):
    need({"bytes": row.get("bytes"), "sha256": row.get("sha256")} == identity(data),
         f"Byte identity mismatch: {description}")


def verify_manifest(payloads, filename, expected_payloads):
    record = strict_json(payloads[filename])
    need(record["self_excluded"] == filename, f"Wrong manifest self exclusion: {filename}")
    rows = rows_by_path(record["files"])
    expected = set(payloads) - {filename}
    need(len(rows) == expected_payloads, f"Wrong manifest payload count: {filename}")
    need(set(rows) == expected,
         f"Manifest coverage mismatch: {filename}; missing={sorted(expected-set(rows))}; extra={sorted(set(rows)-expected)}")
    for path, row in rows.items():
        match_record(row, payloads[path], path)
    return {"members": len(payloads), "manifest_payloads": len(rows),
            "manifest_identity": identity(payloads[filename])}


def checksum_sidecar(path, archive_data):
    text = path.read_text(encoding="utf-8-sig").strip()
    match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?([^\r\n]+)", text)
    need(match is not None, f"Invalid SHA-256 sidecar: {path}")
    need(match[1].lower() == identity(archive_data)["sha256"], f"Sidecar checksum mismatch: {path}")
    need(match[2] == path.name.removesuffix(".sha256"), f"Sidecar filename mismatch: {path}")
    return identity(path.read_bytes())


def brace_group(text, offset):
    need(offset < len(text) and text[offset] == "{", "Expected TeX brace group")
    start = offset + 1
    depth = 1
    offset += 1
    while offset < len(text):
        char = text[offset]
        if char == "\\":
            offset += 2
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return text[start:offset], offset + 1
        offset += 1
    raise ValueError("Unbalanced TeX brace group")


def parse_aux(data):
    labels = {}
    for line in data.decode("utf-8").splitlines():
        if not line.startswith("\\newlabel{"):
            continue
        label, at = brace_group(line, len("\\newlabel"))
        fields, _ = brace_group(line, at)
        number, at = brace_group(fields, 0)
        page, _ = brace_group(fields, at)
        need(label not in labels, f"Duplicate AUX label: {label}")
        need(page.isdigit(), f"Noninteger AUX page: {label}: {page}")
        labels[label] = {"number": number, "page": int(page)}
    return labels


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review-zip", type=Path, required=True)
    parser.add_argument("--issued-packet", type=Path, required=True)
    parser.add_argument("--standalone-pdf", type=Path, required=True)
    parser.add_argument("--output", type=Path, help="Write only this reviewer JSON result; otherwise print JSON")
    args = parser.parse_args()
    audit = Audit()
    input_paths = {
        "review_zip": args.review_zip,
        "review_zip_checksum": Path(str(args.review_zip) + ".sha256"),
        "issued_packet": args.issued_packet,
        "issued_packet_checksum": Path(str(args.issued_packet) + ".sha256"),
        "standalone_pdf": args.standalone_pdf,
    }
    if args.output:
        need(args.output.resolve() not in {p.resolve() for p in input_paths.values()},
             "Output must not overwrite an audit input")
        need(args.output.resolve() != Path(__file__).resolve(), "Output must not overwrite verifier")
    original_bytes = {}
    input_identities = {}
    try:
        for key, path in input_paths.items():
            original_bytes[key] = path.read_bytes()
            input_identities[key] = {"path": str(path.resolve()), **identity(original_bytes[key])}

        audit.run("submitted_zip_checksum", lambda: checksum_sidecar(input_paths["review_zip_checksum"], original_bytes["review_zip"]))
        audit.run("issued_packet_checksum", lambda: checksum_sidecar(input_paths["issued_packet_checksum"], original_bytes["issued_packet"]))
        outer = audit.run("outer_safe_unique_paths_and_crc", lambda: read_archive(args.review_zip, 133))
        packet = audit.run("issued_packet_safe_unique_paths_and_crc", lambda: read_archive(args.issued_packet, 60))
        # Payload bytes are internal working data; replace large check details by counts.
        for entry in audit.checks:
            if entry["check"].endswith("safe_unique_paths_and_crc") and entry["status"] == "PASS":
                entry["details"] = {"regular_file_members": len(entry["details"]),
                                    "all_crc_and_uncompressed_sizes_match": True,
                                    "unique_portable_safe_paths": True}
        need(outer is not None and packet is not None, "Cannot continue after archive validation failure")
        candidate = {name[len(EDITION):]: data for name, data in outer.items() if name.startswith(EDITION)}
        audit.run("outer_manifest", lambda: verify_manifest(outer, "REVIEW_PACKAGE_MANIFEST.json", 132))
        audit.run("candidate_manifest", lambda: verify_manifest(candidate, "CANDIDATE_MANIFEST.json", 88))
        audit.run("issued_packet_manifest", lambda: verify_manifest(packet, "PACKET_MANIFEST.json", 59))

        def exact_input_copies():
            copies = {path[len(PACKET_COPY):]: data for path, data in candidate.items() if path.startswith(PACKET_COPY)}
            need(len(copies) == 60 and set(copies) == set(packet), "Candidate packet-copy coverage mismatch")
            for path, data in packet.items():
                need(copies[path] == data, f"Changed issued input: {path}")
            return {"original_issued_members": 60, "exact_candidate_copies": 60,
                    "comparison": "Direct bytes from original issued ZIP versus submitted ZIP"}
        audit.run("all_60_issued_input_members_preserved", exact_input_copies)

        def pdf_copy():
            need(original_bytes["standalone_pdf"] == candidate[PDF_NAME], "Standalone PDF differs from packaged PDF")
            return identity(candidate[PDF_NAME])
        audit.run("standalone_equals_packaged_pdf", pdf_copy)

        source_record = strict_json(candidate["SOURCE_IDENTITIES.json"])
        issued_sources = strict_json(packet["SOURCE_IDENTITIES.json"])

        def protected_sources():
            rows = rows_by_path(issued_sources["inputs"])
            need(len(rows) == issued_sources["input_count"] == 52, "Wrong protected-source count")
            counts = Counter(path.split("/")[0] for path in rows)
            need(dict(counts) == {"published": 36, "accepted": 14, "context": 2}, "Wrong protected-source category counts")
            new_rows = rows_by_path(source_record["inputs"], "original_packet_path")
            for path, row in rows.items():
                match_record(row, packet[path], path)
                match_record(row, candidate[PACKET_COPY + path], PACKET_COPY + path)
                need(path in new_rows, f"Missing protected source in new registry: {path}")
                for key, value in row.items():
                    expected = PACKET_COPY + value if key == "path" else value
                    need(new_rows[path].get(key) == expected, f"Altered inherited source metadata: {path}: {key}")
            return {"protected_records": 52, "categories": dict(counts),
                    "original_registry_preserved": candidate[PACKET_COPY + "SOURCE_IDENTITIES.json"] == packet["SOURCE_IDENTITIES.json"],
                    "inherited_metadata_and_bytes_match": True}
        audit.run("52_protected_source_identity_records", protected_sources)

        def current_registry():
            rows = rows_by_path(source_record["inputs"], "original_packet_path")
            need(len(rows) == 60 and set(rows) == set(packet), "New source registry input coverage mismatch")
            for path, row in rows.items():
                need(row["path"] == PACKET_COPY + path, f"Wrong preserved input path: {path}")
                match_record(row, packet[path], path)
            new_rows = rows_by_path(source_record["new_manuscript_sources"])
            actual_sources = {p for p in candidate if p.startswith("manuscript/")}
            need(len(new_rows) == 11 and set(new_rows) == actual_sources, "New manuscript-source registry coverage mismatch")
            for path, row in new_rows.items():
                match_record(row, candidate[path], path)
            match_record(source_record["pdf"], candidate[PDF_NAME], PDF_NAME)
            return {"input_records": 60, "new_source_records": 11, "pdf_bound": True}
        audit.run("candidate_source_registry_complete_and_bound", current_registry)

        tex_sources = {p.removeprefix("manuscript/"): identity(data)["sha256"]
                       for p, data in candidate.items() if p.startswith("manuscript/") and p.endswith(".tex")}
        receipt = strict_json(candidate["verification/BUILD_RECEIPT.json"])

        def build_binding():
            need(len(tex_sources) == 10, "Expected ten TeX sources")
            need(receipt["sources"] == tex_sources, "Build receipt does not bind actual ten TeX sources")
            need(receipt["helper_sha256"] == identity(candidate["manuscript/build.py"])["sha256"], "Build helper hash mismatch")
            need({"bytes": receipt["pdf_bytes"], "sha256": receipt["pdf_sha256"]} == identity(candidate[PDF_NAME]), "Build receipt PDF identity mismatch")
            need(candidate["verification/BUILD_RECEIPT.json"] == outer["delivery_support/build_final/build_receipt.json"], "Final receipt copies differ")
            history = strict_json(candidate["verification/BUILD_HISTORY.json"])
            builds = {item["id"]: item["receipt"] for item in history["builds"]}
            need(len(builds) == len(history["builds"]), "Duplicate build-history ID")
            need(builds[history["final"]] == receipt, "History final receipt differs")
            need(builds["build_01"] == strict_json(outer["delivery_support/build_history/build_01_receipt.json"]), "Historical receipt copies differ")
            return {"tex_source_count": 10, "helper_bound": True, "pdf": identity(candidate[PDF_NAME]),
                    "final_receipt_copies_identical": True, "final_build_id": history["final"],
                    "scope": "Byte binding and submitted record consistency; compilation not independently rerun"}
        audit.run("build_receipt_source_helper_pdf_binding", build_binding)

        def crosswalk_binding():
            crosswalk = strict_json(candidate["verification/CROSSWALK.json"])
            need(crosswalk["pdf"] == identity(candidate[PDF_NAME]), "Crosswalk PDF binding mismatch")
            need(crosswalk["sources"] == tex_sources, "Crosswalk TeX bindings mismatch")
            aux = parse_aux(outer["delivery_support/build_final/main.aux"])
            recorded_labels = strict_json(candidate["verification/LABELS.json"])
            need(recorded_labels == aux, "LABELS.json differs from actual submitted final AUX")
            tex_labels = {}
            annotated = {}
            for filename in tex_sources:
                source_path = "manuscript/" + filename
                for line_number, line in enumerate(candidate[source_path].decode("utf-8").splitlines(), 1):
                    active = re.split(r"(?<!\\)%", line, maxsplit=1)[0]
                    for match in re.finditer(r"\\label\{([^{}]+)\}", active):
                        label = match[1]
                        need(label not in tex_labels, f"Duplicate TeX label: {label}")
                        tex_labels[label] = source_path
                        if SCIENTIFIC.match(label):
                            annotation = re.search(r"%\s*SRC:\s*(.*)$", line)
                            need(annotation is not None, f"Missing source annotation: {source_path}:{line_number}:{label}")
                            groups = annotation[1].split()
                            need(groups and len(groups) == len(set(groups)), f"Empty/duplicate groups: {label}")
                            need(set(groups) <= GROUPS | {"SYN01"}, f"Unknown source group: {label}")
                            annotated[label] = {"source": source_path, "accepted_groups": groups}
            need(set(tex_labels) == set(aux), "Actual TeX label set differs from final AUX")
            reverse = crosswalk["reverse"]
            need(len(reverse) == len(annotated) == 64, "Expected 64 scientific reverse labels")
            need(set(reverse) == set(annotated), "Reverse label coverage differs from actual scientific TeX labels")
            derived_forward = {group: set() for group in GROUPS}
            synthesis_labels = []
            for label, actual in annotated.items():
                row = reverse[label]
                need(row["source"] == actual["source"], f"Crosswalk source mismatch: {label}")
                need({"number": row["number"], "page": row["page"]} == aux[label], f"Crosswalk number/page mismatch: {label}")
                need(len(row["accepted_groups"]) == len(set(row["accepted_groups"])), f"Duplicate reverse groups: {label}")
                need(set(row["accepted_groups"]) == set(actual["accepted_groups"]), f"Crosswalk SRC groups mismatch: {label}")
                for group in actual["accepted_groups"]:
                    if group == "SYN01":
                        synthesis_labels.append(label)
                    else:
                        derived_forward[group].add(label)
            need(crosswalk["accepted_groups"] == 51 and set(crosswalk["forward"]) == GROUPS, "Wrong accepted-group coverage")
            for group, labels in crosswalk["forward"].items():
                need(labels and len(labels) == len(set(labels)), f"Empty/duplicate forward destinations: {group}")
                need(set(labels) == derived_forward[group], f"Forward/reverse TeX coverage mismatch: {group}")
            need(synthesis_labels == ["eq:synthesis"], "Unexpected SYN01 extent")
            return {"accepted_groups": 51, "AT_groups": 29, "PC_groups": 22,
                    "scientific_reverse_labels": 64, "all_TeX_and_AUX_labels": len(aux),
                    "SYN01_labels": synthesis_labels, "numbers_pages_sources_and_bidirectional_maps_match": True,
                    "aux_identity": identity(outer["delivery_support/build_final/main.aux"]),
                    "scope": "Reconstructed source annotations and AUX locators; substantive claims reviewed separately"}
        audit.run("independent_51_group_64_label_crosswalk", crosswalk_binding)

        def review_record_bindings():
            names = ["CROSSWALK.json", "DOCUMENT_CHECKS.json", "FIDELITY_REVIEW.json", "VISUAL_INSPECTION.json"]
            for name in names:
                row = strict_json(candidate["verification/" + name])
                need(row["pdf"] == identity(candidate[PDF_NAME]), f"Review record PDF binding mismatch: {name}")
                need(row["sources"] == tex_sources, f"Review record TeX binding mismatch: {name}")
            visual = strict_json(candidate["verification/VISUAL_INSPECTION.json"])
            need(visual["page_count"] == len(visual["pages"]) == 15, "Wrong supplied visual page count")
            need([row["page"] for row in visual["pages"]] == list(range(1, 16)), "Incomplete supplied visual page sequence")
            for row in visual["pages"]:
                path = row["render_archive_path"]
                safe_path(path)
                match_record(row, outer[path], path)
            return {"records": names, "each_binds_final_pdf_and_10_actual_TeX_sources": True,
                    "archived_render_identities_verified": 15,
                    "scope": "Binding of submitted review records and archived render bytes; independent visual review performed separately"}
        audit.run("crosswalk_document_fidelity_visual_record_bindings", review_record_bindings)

        def preservation_records():
            baseline = strict_json(outer["delivery_support/records/INPUT_BASELINE.json"])
            final = strict_json(candidate["verification/PRESERVATION_CHECK.json"])
            before = baseline["files"]
            after = {}
            for row in final["protected_files"]:
                path = row["path"]
                need(path not in after, f"Duplicate preservation record: {path}")
                after[path] = row
            need(len(before) == len(after) == final["protected_count"] == 63, "Wrong preservation-record counts")
            need(set(before) == set(after), "Baseline/final protected path sets differ")
            seen_packet = set()
            supplied = {}
            for windows_path, before_identity in before.items():
                row = after[windows_path]
                need(row.get("unchanged") is True, f"Record reports changed input: {windows_path}")
                need(before_identity == {"bytes": row["bytes"], "sha256": row["sha256"]}, f"Baseline/final identity disagreement: {windows_path}")
                normalized = windows_path.replace("\\", "/")
                marker = "/NATIVE_TRANSFER_CAPACITY_PAPER_01/inputs/"
                if marker in normalized:
                    path = normalized.split(marker, 1)[1]
                    need(path in packet and path not in seen_packet, f"Unexpected/repeated extracted-input record: {path}")
                    seen_packet.add(path)
                    expected = packet[path]
                else:
                    name = normalized.rsplit("/", 1)[-1]
                    need(name not in supplied, f"Repeated supplied-file record: {name}")
                    external = {
                        args.issued_packet.name: original_bytes["issued_packet"],
                        input_paths["issued_packet_checksum"].name: original_bytes["issued_packet_checksum"],
                        ORDER_NAME: packet[ORDER_NAME],
                    }
                    need(name in external, f"Unmapped supplied-file record: {name}")
                    supplied[name] = True
                    expected = external[name]
                match_record(before_identity, expected, windows_path)
            need(seen_packet == set(packet) and len(supplied) == 3, "Incomplete independent preservation mapping")
            copies = rows_by_path(final["candidate_input_copies"], "original_packet_path")
            need(len(copies) == final["copy_count"] == 60 and set(copies) == set(packet), "Final candidate-copy record coverage mismatch")
            for path, row in copies.items():
                need(row["path"] == PACKET_COPY + path, f"Wrong final candidate-copy path: {path}")
                match_record(row, candidate[PACKET_COPY + path], path)
            return {"reconciled_protected_records": 63, "extracted_packet_records": 60,
                    "supplied_file_records": 3, "candidate_copy_records": 60,
                    "baseline_identity": identity(outer["delivery_support/records/INPUT_BASELINE.json"]),
                    "final_record_identity": identity(candidate["verification/PRESERVATION_CHECK.json"]),
                    "scope": "Baseline and final supplied records agree and match original issued ZIP/sidecar/member bytes. The Windows filesystem was not accessed; ongoing or historical filesystem state is not independently certified. The Downloads order record is matched to the authoritative issued-packet member."}
        audit.run("preservation_baseline_final_record_reconciliation", preservation_records)

        def submitted_input_audit_consistency():
            data = candidate["verification/INPUT_VERIFICATION.json"]
            need(data == outer["delivery_support/records/INPUT_VERIFICATION.json"], "Input verification copies differ")
            row = strict_json(data)
            need(row["packet"] == identity(original_bytes["issued_packet"]), "Input verification issued-packet mismatch")
            for key, expected in {"members": 60, "manifest_payloads": 59, "registered_inputs": 52,
                                  "preserved_candidate_input_files": 60, "protected_files": 63}.items():
                need(row[key] == expected, f"Incorrect submitted input-verification count: {key}")
            nested_sidecars = [path for path in packet if path.endswith(".zip.sha256")]
            for path in nested_sidecars:
                contents = packet[path].decode("utf-8-sig").strip()
                match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?([^\r\n]+)", contents)
                archive = path.removesuffix(".sha256")
                need(match is not None and match[1].lower() == identity(packet[archive])["sha256"]
                     and match[2] == archive.rsplit("/", 1)[-1], f"Nested archive checksum mismatch: {path}")
            return {"counts_and_copy_identity_match": True, "nested_archive_checksum_pairs": len(nested_sidecars),
                    "nested_archives_not_expanded_or_executed": True}
        audit.run("submitted_input_record_and_nested_checksum_consistency", submitted_input_audit_consistency)

    except Exception as exc:
        audit.checks.append({"check": "audit_continuation", "status": "FAIL", "error": str(exc)})

    def inputs_still_unchanged():
        for key, data in original_bytes.items():
            need(input_paths[key].read_bytes() == data, f"Local audit input changed during verification: {key}")
        return {"local_input_files_compared": len(original_bytes), "all_bytes_unchanged": True}
    audit.run("local_audit_inputs_unchanged", inputs_still_unchanged)
    failures = [item for item in audit.checks if item["status"] == "FAIL"]
    report = {
        "schema_version": 1,
        "task": "NATIVE_TRANSFER_CAPACITY_PAPER_01_INDEPENDENT_PACKAGE_AUDIT",
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "status": "FAIL" if failures else "PASS",
        "method": "Independent Python standard-library byte and metadata audit; original archives are authority; no submitted verifier executed",
        "inputs": input_identities,
        "verifier": {"filename": Path(__file__).name, **identity(Path(__file__).read_bytes())},
        "checks_passed": len(audit.checks) - len(failures),
        "checks_failed": len(failures),
        "checks": audit.checks,
        "limitations": [
            "No TeX rebuild or independent compilation provenance attestation; receipt/source/PDF consistency and AUX label binding verified.",
            "No Windows filesystem access; supplied baseline/final records reconciled to authoritative archived bytes only.",
            "No nested historical archive execution, scientific replay, live publication check, or network access.",
            "Scientific fidelity and visual PDF review are separate reviewer tasks."
        ],
    }
    rendered = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
        print(json.dumps({"status": report["status"], "checks_passed": report["checks_passed"],
                          "checks_failed": report["checks_failed"], "result": str(args.output.resolve()),
                          "failures": failures}, indent=2))
    else:
        print(rendered, end="")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
