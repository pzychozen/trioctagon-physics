"""Focused immutable input verification. No Git, network, old suites or model runs."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,shutil,sys,zipfile
import sympy

W=Path(__file__).resolve().parent
D=Path("C:/Users/Notandi/Downloads")
TASK="NATIVE_PROJECTION_CAPACITY_01"
AT="NATIVE_ACCESSIBLE_TRANSFER_01"
I=W/"inputs"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ident=lambda p:{"bytes":p.stat().st_size,"sha256":sha(p)}
save=lambda n,x:(W/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
assert not I.exists(),"Do not overwrite preserved inputs."
packet=D/(TASK+"_CODEX_PACKET.zip")
checksum=D/(packet.name+".sha256")
order=D/(TASK+"_CODEX_WORK_ORDER.md")
assert checksum.read_text().split()[0]==sha(packet)=="72733488122126b36b8c0b06b13179da02db84c809965f5d99c142a4da71ec0c"
with zipfile.ZipFile(packet) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==len({n.casefold() for n in names})==23
    for n in names:
        p=PurePosixPath(n)
        assert not p.is_absolute() and ".." not in p.parts and ":" not in n and "\\" not in n
        assert n==str(p) and not n.endswith("/")
        assert ((z.getinfo(n).external_attr>>16)&0o170000)!=0o120000
    assert z.testzip() is None
    manifest=json.loads(z.read("PACKET_MANIFEST.json"))
    assert manifest["manifest_excludes_itself"] is True
    rows={r["path"]:r for r in manifest["files"]}
    assert len(rows)==len(manifest["files"])==manifest["payload_file_count"]==22
    assert set(names)==set(rows)|{"PACKET_MANIFEST.json"}
    for n,r in rows.items():
        b=z.read(n)
        assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"]
    assert z.read(order.name)==order.read_bytes(),"Source conflict: standalone order differs from packet."
    for n in names:
        dst=I/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(z.read(n))
registry=json.loads((I/"SOURCE_IDENTITIES.json").read_text(encoding="utf-8"))
baseline={str(p):ident(p) for p in [packet,checksum,order]}
for p in I.rglob("*"):
    if p.is_file():baseline[str(p)]=ident(p)
local=[]
for r in registry["source_files"]:
    p=I/r["path"]
    assert ident(p)=={k:r[k] for k in ["bytes","sha256"]}
    base=(W.parent/"NATIVE_RECIPROCAL_EXCHANGE_PAPER_PUBLISH_01/publication_worktree"
          if r["id"].startswith("P1.") else W.parent/"SAME_TRAJECTORY_NATIVE_CREDIT_PUBLISH_01/publication_worktree")
    q=base/r["repository_path"]
    assert q.read_bytes()==p.read_bytes()
    baseline[str(q)]=ident(q)
    local.append({"id":r["id"],"path":str(q),**ident(q)})
assert len(local)==7
for r in registry["accepted_and_context_inputs"]:
    assert ident(I/r["path"])=={k:r[k] for k in ["bytes","sha256"]}
prior=[]
for suffix in ["_PROOF.md","_CLAIM_SOURCE_LEDGER.md","_REVIEW_PACKAGE.zip","_REVIEW_PACKAGE.zip.sha256"]:
    name=AT+suffix
    p=I/"accepted_results"/name;q=W.parent/AT/name
    assert p.read_bytes()==q.read_bytes(),name
    baseline[str(q)]=ident(q);prior.append({"path":str(q),**ident(q)})
priorzip=I/"accepted_results"/(AT+"_REVIEW_PACKAGE.zip")
assert sha(priorzip)==(I/"accepted_results"/(AT+"_REVIEW_PACKAGE.zip.sha256")).read_text().split()[0]
with zipfile.ZipFile(priorzip) as z:
    for suffix in ["_PROOF.md","_CLAIM_SOURCE_LEDGER.md"]:
        name=AT+suffix
        assert z.read(name)==(I/"accepted_results"/name).read_bytes()
# Preserve all supplied content in focused handoff locations, with original metadata segregated.
for directory in ["sources","accepted_results","context","preparation_evidence"]:
    shutil.copytree(I/directory,W/directory)
for name in [order.name,TASK+"_SOURCE_ASSESSMENT.md"]:
    shutil.copyfile(I/name,W/name)
(W/"input_metadata").mkdir()
for name in ["SOURCE_IDENTITIES.json","PACKET_MANIFEST.json","READ_ME_FOR_CODEX.md"]:
    shutil.copyfile(I/name,W/"input_metadata"/name)
instruction_paths=[Path("C:/AGENTS.md"),Path("C:/TORMENT/AGENTS.md"),
                   W.parent.parent/"AGENTS.md",W.parent/"AGENTS.md",W/"AGENTS.md"]
assert not any(p.exists() for p in instruction_paths)
save("AGENTS_CHECK.json",{"checked":[{"path":str(p),"exists":False} for p in instruction_paths]})
save("INPUT_BASELINE.json",{"utc":datetime.now(timezone.utc).isoformat(),"files":baseline,
                          "scope":"Three supplied files, 23 preserved extracted inputs, seven local defining publication sources and four local accepted AT01 artifacts only."})
save("INPUT_VERIFICATION.json",{
    "utc":datetime.now(timezone.utc).isoformat(),"status":"PASS","packet":ident(packet),
    "packet_members":23,"manifest_payloads":22,"safe_unique_members_crc_sizes_hashes":True,
    "standalone_order_matches_packet":True,"standalone_order_governs":True,
    "focused_local_publication_sources":local,"prior_local_accepted_artifacts":prior,
    "accepted_zip_hash_matches_checksum":True,"accepted_loose_proof_and_ledger_match_inner_zip":True,
    "prior_scientific_suite_replayed":False,"protected_files":len(baseline)})
save("ENVIRONMENT.json",{
    "utc":datetime.now(timezone.utc).isoformat(),"python":sys.executable,"python_version":sys.version,
    "sympy_version":sympy.__version__,"activation":"cmd.exe: call conda activate torment",
    "installs":[],"git_operations":False,"network_requests":False,"old_scientific_suites_run":False})
print(json.dumps({"status":"PASS","packet_members":23,"payloads":22,"focused_sources":7,
                  "prior_accepted_local_artifacts":4,"protected_files":len(baseline),
                  "sympy":sympy.__version__}))
