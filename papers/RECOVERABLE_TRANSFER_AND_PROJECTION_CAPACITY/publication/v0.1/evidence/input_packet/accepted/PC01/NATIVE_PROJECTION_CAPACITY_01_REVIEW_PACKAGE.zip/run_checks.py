"""Capture one actual execution of the new standalone checker, without model imports."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,subprocess,sys
W=Path(__file__).resolve().parent
started=datetime.now(timezone.utc).isoformat()
argv=[sys.executable,"-I","-B",str(W/"exact_algebra_check.py")]
result=subprocess.run(argv,cwd=W,capture_output=True)
(W/"EXACT_ALGEBRA_RESULTS.json").write_bytes(result.stdout)
(W/"EXACT_ALGEBRA_STDERR.txt").write_bytes(result.stderr)
record={
    "started_utc":started,"finished_utc":datetime.now(timezone.utc).isoformat(),
    "activation":"cmd.exe: call conda activate torment && python -I -B run_checks.py",
    "argv":argv,"cwd":str(W),"exit_code":result.returncode,
    "checker_sha256":hashlib.sha256((W/"exact_algebra_check.py").read_bytes()).hexdigest(),
    "wrapper_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "stdout":"EXACT_ALGEBRA_RESULTS.json","stdout_sha256":hashlib.sha256(result.stdout).hexdigest(),
    "stderr":"EXACT_ALGEBRA_STDERR.txt","stderr_sha256":hashlib.sha256(result.stderr).hexdigest(),
    "scope":"One execution of new checker; no historical scientific suite replay."
}
(W/"EXACT_ALGEBRA_EXECUTION.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
if result.returncode:
    print(result.stdout.decode("utf-8",errors="replace"))
    print(result.stderr.decode("utf-8",errors="replace"))
    raise SystemExit(result.returncode)
data=json.loads(result.stdout)
assert data["passed"]==data["grouped_checks_executed"]==12 and not result.stderr
print(json.dumps({k:data[k] for k in ["status","grouped_checks_executed","passed","failed","sympy_version"]}))
