# Source assessment — projection geometry and exchange capacity

**Date:** 4 November 2026  
**Decision:** Issue NATIVE_PROJECTION_CAPACITY_01 as the next bounded Codex investigation.  
**Status:** The formulas below are proposed consequences of the existing equations. They await independent Codex proof and GPT acceptance.

## 1. Research state and why this comes next

NATIVE_ACCESSIBLE_TRANSFER_01 is accepted unchanged. It establishes finite-coupling receiver concentration, net native recovery and receiver charging/backflow in a prescribed early window. At q=1/5, the two specified fractions are at least 80/81. The absolute transferred stock has an inverse-square leading scale and accesses a vanishing fraction of the published invariant ceiling as κ increases.

The next issue is therefore useful accessible amount. Before attempting a long-time trajectory study or optimizing coupling, we have a short structural lead to check: the fixed two-port projection may impose an additional invariant and a smaller upper ceiling for every exchange time.

This lead was recorded in §6 of the preceding source assessment and expressly excluded from the accepted AT01 proof. It has not been silently promoted to an accepted result. The current user request now authorizes its independent investigation.

The reciprocal-exchange and same-trajectory papers are published with completed closeouts. AT01 is an accepted analytical investigation whose manuscript has not yet been prepared. No unresolved correction or missing geometric decision blocks this next order. A subsequent manuscript could present the accepted quantitative transfer result alongside a verified structural capacity result, if this investigation succeeds; that editorial decision follows review.

## 2. The source-based mechanism

P1 [power.tex, eq:core](https://github.com/pzychozen/trioctagon-physics/blob/273b1a6faaab19ea58748d00576439166eeef9ab/papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1/manuscript/power.tex) writes the native equation as

\[
\dot a=\mu w\times b,\qquad
\dot b=-\mu w\times a,\qquad
w=K^Ty,\qquad \mu=\eta_N/(2\alpha_N).
\]

The published K is fixed, real and rank two. Its real unit kernel direction is

\[
e=R_z(-\delta_g)e_x,\qquad Ke=0.
\]

Thus w always lies in the plane perpendicular to e. That is a constraint already present in the registration, not an added geometric premise.

The proposed native scalar is

\[
\mathcal J_K=I-2|e\cdot\Omega|^2,
\qquad I=|\Omega|^2.
\]

Direct differentiation suggests

\[
\dot I=-4\mu w\cdot(a\times b),\qquad
\frac d{dt}|e\cdot\Omega|^2=-2\mu w\cdot(a\times b),
\]

so \(\mathcal J_K\) would be conserved. It would also give the exact identity

\[
H_N(0)-H_N(t)
=\alpha_N\left(|e\cdot\Omega_0|^2-|e\cdot\Omega(t)|^2\right).
\]

This expresses the existing native debit through a fixed projection. It does not introduce another energy store.

The proof can use the C1 native variables already supplied by P1's global theorem, even for L2 carrier preparation. It needs no propagation limit, large receiver coupling, new PDE theorem or trajectory integration. A fresh immutable retrieval of power.tex agrees with the focused source copy; the packet records that identity check.

## 3. Smallest useful capacity conclusion

P1 [capacity.tex](https://github.com/pzychozen/trioctagon-physics/blob/273b1a6faaab19ea58748d00576439166eeef9ab/papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1/manuscript/capacity.tex) already proves conservation of \(Z_2=\Omega^T\Omega\), the floor \(I\ge|Z_2|\), and an upper ceiling that it explicitly does not claim to be attainable.

Combining that accepted invariant with the proposed one gives the target

\[
I(t)\ge\max\{|Z_0|,j_0\},\qquad
j_0=\mathcal J_K(\Omega_0),
\]
\[
C_{\rm joint}
=\frac{\alpha_N}{2}\left[I_0-\max(|Z_0|,j_0)\right]
=\min\left\{C_Z,\alpha_N|e\cdot\Omega_0|^2\right\}.
\]

For an initially empty carrier and receiver, this would imply

\[
0\le H_C(t)+H_R(t)\le C_{\rm joint}
\qquad\text{for every }t\ge0.
\]

Unlike AT01's certificate, this proposed restriction is not confined to a shrinking time window or a sufficiently large κ. It concerns the unchanged exchange equations at any fixed finite positive coupling.

The smallest decisive witness uses the already accepted launch family, with one fixed admissible yaw. For Ω0=(1,e^(iφ),1),

\[
j_0=1+2\sin(2\delta_g)\cos\phi.
\]

At δg=π/4 and 0<φ<π/12,

\[
j_0=1+2\cos\phi>\sqrt{9-8\sin^2\phi},
\]
\[
C_{\rm joint}=\alpha_N(1-\cos\phi)<C_Z.
\]

The drive remains nonzero, with \(|f_0|^2=10G^2\sin^2\phi/7\). A proof would therefore establish a strict reduction of the old ceiling for an active coherent launch, rather than relying only on an already inactive state.

The old ceiling would remain valid. The new result would show that it is non-sharp for this launch, as the published limitations already allow.

## 4. A bounded algebraic clarification

One short secondary lemma can identify exactly what the two invariants imply before any dynamical attainability question is asked.

For a prescribed complex Z and real j, the proposed feasible pairs satisfy

\[
j\ge-|Z|.
\]

The proposed exact algebraic minimum is

\[
\min_{Z_2(\Omega)=Z,\ \mathcal J_K(\Omega)=j}|\Omega|^2
=\max(|Z|,j).
\]

The work order supplies two explicit candidate constructions in an orthonormal basis adapted to e, including negative j and Z=0. Codex must verify them and the feasibility condition without dividing by a vanishing invariant.

This is a finite-dimensional statement about the full common invariant level set. It does not assert that a particular initially empty coupled trajectory reaches a minimizing state.

A second direct consequence to verify is

\[
C_{\rm joint}=0\quad\Longleftrightarrow\quad f(x_0)=0.
\]

For rank-two K, zero raw drive means the chirality is either zero or parallel to e. These correspond to the two possible zero terms in the proposed minimum formula for C_joint. For empty external preparation, the published activity and dark-state results then distinguish stationary launches from launches with initial supply. Preloaded carrier states retain the published different behavior.

## 5. Why algebraic sharpness cannot become a saturation claim

Let u be a real unit vector perpendicular to e and consider Ω0=u+i e. It has Z0=0 and j0=0 but is nonzero and has nonzero raw drive.

Its common algebraic level includes Ω*=0. Yet the published native-zero invariance and backward uniqueness prevent a nonzero native state from reaching zero at a finite exchange time. This example is outside the coherent launch family; its role is only to expose the logical difference between an algebraic minimum and an attained trajectory endpoint.

The task therefore stops at the conserved quantity, exact debit identity, sharp joint algebraic floor, zero-drive corollary and one non-dark strict-improvement witness. Actual maximum extraction, asymptotic saturation, orbit/control classification and parameter optimization remain separate research.

## 6. Independent assessment and collaboration

Independent analytical checks support the derivative signs, debit factor α_N, feasibility condition, equality constructions, zero-capacity equivalence and coherent witness. They also agree that no new physical axis or receiver location should be inferred from e. These are checks of the proposed order; they do not replace Codex's new proof or its later acceptance review.

The seven focused source files and the accepted AT01 result are sufficient to proceed. There is no reason to ask the author to recall parameters or resolve a new geometric assumption.

The central starting/meeting region, opposed cones, outward spreading and around–inward return, stationary supports and possible transfer elsewhere remain the larger goal. The next calculation examines a restriction inside the existing candidate on the way toward that goal. Native stepping/cadence, route correspondence, six-opening transport, linked gravity–magnetism, outer geometry and justified SRG integration remain in the continuing agenda.
