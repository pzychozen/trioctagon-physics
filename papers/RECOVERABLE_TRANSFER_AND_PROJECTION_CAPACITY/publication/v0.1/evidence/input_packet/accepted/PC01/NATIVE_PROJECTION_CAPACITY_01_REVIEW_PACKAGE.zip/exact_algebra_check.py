"""Twelve bounded symbolic groups for the projection-capacity investigation.

Run with the existing torment environment:
    python -I -B exact_algebra_check.py
Prints JSON and exits nonzero on failure. No trajectories, scans or old suites.
"""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,sys
import sympy as s

started=datetime.now(timezone.utc).isoformat()
delta,phi,theta=s.symbols("delta phi theta",real=True)
G,mu,alpha,eta=s.symbols("G mu alpha eta",positive=True)
a=s.Matrix(s.symbols("a1:4",real=True))
b=s.Matrix(s.symbols("b1:4",real=True))
w=s.Matrix(s.symbols("w1:4",real=True))
e3=s.Matrix([0,0,1])
K=G/s.sqrt(7)*s.Matrix([[2*s.sin(delta),2*s.cos(delta),s.sqrt(3)],
                        [2*s.sin(delta),2*s.cos(delta),-s.sqrt(3)]])
e=s.Matrix([s.cos(delta),-s.sin(delta),0])
ad=mu*w.cross(b);bd=-mu*w.cross(a)
cross=a.cross(b)
checks=[]

def check(identifier,description,labels,expressions,assumptions):
    residuals=[s.simplify(s.trigsimp(s.expand(expr))) for expr in expressions]
    checks.append({"id":identifier,"description":description,"proof_labels":labels,
                   "assumptions":assumptions,
                   "status":"PASS" if all(r==0 for r in residuals) else "FAIL",
                   "zero_residuals":[str(r) for r in residuals]})

check("S01","Published kernel convention, unit norm and rank certificate",["PC03","PC04"],
      list(K*e)+[e.dot(e)-1,(K*K.T).det()-48*G**4/49],
      "G>0 and real yaw; positive Gram determinant proves real rank two. No physical-axis interpretation.")

grad_a=s.Matrix([s.diff(w.dot(cross),x) for x in a])
grad_b=s.Matrix([s.diff(w.dot(cross),x) for x in b])
check("S02","Native gradient feedback and complex equation signs",["PC01"],
      list(ad+mu*grad_a)+list(bd+mu*grad_b)+list(ad+s.I*bd+s.I*mu*w.cross(a+s.I*b)),
      "All component vectors real; mu=eta_N/(2 alpha_N); w=K^T y held fixed for the state derivative.")

Idot=2*a.dot(ad)+2*b.dot(bd)
check("S03","Full intensity derivative sign",["PC06"],
      [Idot+4*mu*w.dot(cross)],
      "Real vectors; no division by intensity or chirality.")

hdot=2*a[2]*ad[2]+2*b[2]*bd[2]
check("S04","Kernel-projection derivative using perpendicular forcing",["PC07"],
      [(hdot+2*mu*w.dot(cross)).subs(w[2],0),
       hdot+2*mu*w.dot(cross)-2*mu*w[2]*cross[2]],
      "Right-handed basis with e=e3. The second identity exposes the term removed by w3=0.")

check("S05","Invariant derivative and exact debit/power factor",["PC07","PC08"],
      [(Idot-2*hdot).subs(w[2],0),
       (alpha*hdot+eta*w.dot(cross)).subs({w[2]:0,mu:eta/(2*alpha)}),
       (alpha*Idot/2-alpha*hdot).subs(w[2],0)],
      "w perpendicular to e and alpha>0. Integrating the invariant is justified in the written C1 argument.")

r,t=s.symbols("r t",nonnegative=True)
gamma=s.cos(theta)+s.I*s.sin(theta)
def metrics(O):
    norm=(s.conjugate(O).T*O)[0]
    bilinear=(O.T*O)[0]
    proj=s.conjugate(O[2])*O[2]
    return norm,bilinear,norm-2*proj

first=gamma*s.Matrix([s.sqrt(r),0,s.sqrt(t)])
I1,Z1,j1=metrics(first)
check("S06","Equality construction for -rho<=j<=rho including negative j",["PC15"],
      [I1-(r+t),Z1-gamma**2*(r+t),j1-(r-t)],
      "r,t>=0; rho=r+t, j=r-t, hence r=(rho+j)/2 and t=(rho-j)/2. Covers the whole first branch and zero coefficients.")

second=gamma*s.Matrix([s.sqrt(r+t),s.I*s.sqrt(t),0])
I2,Z2,j2=metrics(second)
check("S07","Equality construction for j>=rho including Z=0 and native zero",["PC16","PC17"],
      [I2-(r+2*t),Z2-gamma**2*r,j2-(r+2*t),
       Z2.subs(r,0),I2.subs({r:0,t:0})],
      "r,t>=0; rho=r, j=r+2t. If rho=0 take theta=0; t=0 then gives native zero.")

# One exact registered representative of u+i e uses u=e_z.
example=e3+s.I*e
example_I=(s.conjugate(example).T*example)[0]
example_Z=(example.T*example)[0]
example_h=(e.T*example)[0]
example_j=example_I-2*s.conjugate(example_h)*example_h
example_drive=K*e3.cross(e)
check("S08","Active zero-invariant-level example in the actual registration",["PC22"],
      [example_I-2,example_Z,example_j]
      +list(example_drive-s.Matrix([2*G/s.sqrt(7),2*G/s.sqrt(7)])),
      "u=e_z is unit and perpendicular to the published e; G>0 proves nonzero drive. This does not check reachability.")

launch_a=s.Matrix([1,s.cos(phi),1]);launch_b=s.Matrix([0,s.sin(phi),0])
launch_h=e.dot(launch_a)**2+e.dot(launch_b)**2
check("S09","Coherent-launch kernel projection and new invariant",["PC20"],
      [launch_h-(1-s.sin(2*delta)*s.cos(phi)),
       3-2*launch_h-(1+2*s.sin(2*delta)*s.cos(phi))],
      "Real phi,yaw; phase and intensity conditions for the admitted family are in the proof.")

C=s.symbols("C",real=True)
check("S10","Strict witness squared-gap factorization",["PC21"],
      [(1+2*C)**2-(9-8*(1-C**2))-4*C*(1-C)],
      "C=cos(phi), 0<phi<pi/12 implies 0<C<1, so 4C(1-C)>0; both compared quantities are positive.")

rho=s.symbols("rho",nonnegative=True)
check("S11","Strict-witness joint ceiling and old-ceiling gap",["PC21"],
      [alpha*launch_h.subs(delta,s.pi/4)-alpha*(1-s.cos(phi)),
       alpha/2*(3-rho)-alpha*(1-C)-alpha/2*(1+2*C-rho)],
      "Witness yaw fixed at pi/4; j0>rho from S10 plus positivity. This is not an attainability claim.")

witness_drive=(K*launch_a.cross(launch_b)).subs(delta,s.pi/4)
check("S12","Non-dark coherent witness drive magnitude",["PC21"],
      [witness_drive.dot(witness_drive)-10*G**2*s.sin(phi)**2/7],
      "G>0, 0<phi<pi/12 gives strict positive magnitude. Fixed yaw, no parameter scan.")

assert len(checks)==len({c["id"] for c in checks})==12
failed=sum(c["status"]=="FAIL" for c in checks)
report={
    "task":"NATIVE_PROJECTION_CAPACITY_01","started_utc":started,
    "finished_utc":datetime.now(timezone.utc).isoformat(),"python":sys.executable,
    "python_version":sys.version,"sympy_version":s.__version__,
    "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "grouped_checks_executed":len(checks),"passed":len(checks)-failed,
    "failed":failed,"status":"FAIL" if failed else "PASS","checks":checks,
    "scope":"New finite-dimensional derivative/construction/witness checks only. Written proof supplies feasibility, global minimum, zero-drive equivalence and dynamical nonattainment. No old suites, trajectory or document checks counted."
}
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(1 if failed else 0)
