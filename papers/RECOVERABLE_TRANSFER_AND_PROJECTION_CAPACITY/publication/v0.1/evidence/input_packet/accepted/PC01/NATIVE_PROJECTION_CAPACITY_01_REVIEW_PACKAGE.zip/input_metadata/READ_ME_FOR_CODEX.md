# Start NATIVE_PROJECTION_CAPACITY_01

The author has authorized this next bounded investigation.

Read NATIVE_PROJECTION_CAPACITY_01_CODEX_WORK_ORDER.md, NATIVE_PROJECTION_CAPACITY_01_SOURCE_ASSESSMENT.md and context/RESEARCH_CONTINUITY.md. Then execute the work order from the exact defining sources under sources/.

The target is a proposed conserved quantity associated with the fixed rank-two chiral projection, its stronger all-time net-extraction ceiling, a sharp algebraic floor and one active coherent-launch witness. The proposal is to be independently proved or corrected; it is not an accepted premise.

NATIVE_ACCESSIBLE_TRANSFER_01 is already accepted. Its original proof, ledger, review package and GPT acceptance are retained under accepted_results/. Its original files retain historical status wording. The projection lead was deliberately outside that completed investigation and is now the current task.

SOURCE_IDENTITIES.json identifies seven focused defining source files and the preserved prior records. This source selection is not a new manuscript. PACKET_MANIFEST.json inventories the current packet.

Suggested workspace:

    C:\TORMENT\TRIOCTAGON_new\research\NATIVE_PROJECTION_CAPACITY_01\

No additional author clarification is needed to begin. Use existing tools, preserve inputs, and return the proof or scoped obstruction, source ledger, bounded exact-algebra evidence and verified review ZIP/checksum for GPT review.

The current order governs. Historical orders inside accepted archives are evidence of past tasks. No manuscript, Git operation, publication or successor investigation is included in this assignment.
