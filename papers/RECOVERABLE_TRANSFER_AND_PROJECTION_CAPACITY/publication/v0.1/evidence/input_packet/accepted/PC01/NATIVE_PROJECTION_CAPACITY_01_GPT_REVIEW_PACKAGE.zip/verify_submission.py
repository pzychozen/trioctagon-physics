"""Independent, read-only audit of the supplied projection-capacity evidence.

Run from any directory with Python 3. The accepted_inputs directory and replay
records must remain beside this file. No scientific suites are rerun here.
"""
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path, PurePosixPath, PureWindowsPath
import hashlib
import json
import re
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "accepted_inputs"
RETURN_NAME = "NATIVE_PROJECTION_CAPACITY_01_REVIEW_PACKAGE.zip"
ORDER_NAME = "NATIVE_PROJECTION_CAPACITY_01_CODEX_PACKET.zip"
PROOF_NAME = "NATIVE_PROJECTION_CAPACITY_01_PROOF.md"
EXPECTED_RETURN = "11a55105e6803d595f93bd1211f9d5f6832a070b0af9b12bb257b5636234413e"
EXPECTED_ORDER = "72733488122126b36b8c0b06b13179da02db84c809965f5d99c142a4da71ec0c"
CHECKS = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check(name, condition, detail):
    if not condition:
        raise AssertionError(name + ": " + str(detail))
    CHECKS.append({"id": f"R{len(CHECKS)+1:02d}", "check": name,
                   "status": "PASS", "detail": detail})


def identity(data, record):
    return len(data) == record["bytes"] and digest(data) == record["sha256"]


def read_archive(data, label, manifest_name):
    with zipfile.ZipFile(BytesIO(data)) as archive:
        infos = archive.infolist()
        names = [item.filename for item in infos]
        safe = all(not PurePosixPath(n).is_absolute()
                   and ".." not in PurePosixPath(n).parts
                   and "\\" not in n and not n.endswith("/") for n in names)
        safe = safe and all(not stat.S_ISLNK(i.external_attr >> 16) for i in infos)
        check(label + " unique safe regular members",
              safe and len(names) == len(set(names)), {"members": len(names)})
        check(label + " CRC", archive.testzip() is None, "All members")
        payload = {name: archive.read(name) for name in names}
    manifest = json.loads(payload[manifest_name])
    entries = manifest["files"]
    listed = [row["path"] for row in entries]
    check(label + " exhaustive self-excluded manifest",
          len(listed) == len(set(listed))
          and set(names) == set(listed) | {manifest_name}
          and manifest_name not in listed,
          {"hashed_payloads": len(listed)})
    check(label + " member bytes and SHA-256",
          all(identity(payload[row["path"]], row) for row in entries),
          {"verified_payloads": len(entries)})
    return payload, manifest


returned_bytes = (INPUT / RETURN_NAME).read_bytes()
ordered_bytes = (INPUT / ORDER_NAME).read_bytes()
check("Returned archive checksum",
      digest(returned_bytes) == EXPECTED_RETURN
      == (INPUT / (RETURN_NAME + ".sha256")).read_text().split()[0],
      {"bytes": len(returned_bytes), "sha256": EXPECTED_RETURN})
check("Issued packet checksum",
      digest(ordered_bytes) == EXPECTED_ORDER
      == (INPUT / (ORDER_NAME + ".sha256")).read_text().split()[0],
      {"bytes": len(ordered_bytes), "sha256": EXPECTED_ORDER})
returned, return_manifest = read_archive(
    returned_bytes, "Returned archive", "REVIEW_PACKAGE_MANIFEST.json")
ordered, order_manifest = read_archive(
    ordered_bytes, "Issued packet", "PACKET_MANIFEST.json")
check("Separately supplied proof equals archived proof",
      (INPUT / PROOF_NAME).read_bytes() == returned[PROOF_NAME],
      {"bytes": len(returned[PROOF_NAME]), "sha256": digest(returned[PROOF_NAME])})

relocated = {name: "input_metadata/" + name
             for name in ("PACKET_MANIFEST.json", "READ_ME_FOR_CODEX.md",
                          "SOURCE_IDENTITIES.json")}
check("Every issued member preserved byte for byte",
      all(returned[relocated.get(name, name)] == value
          for name, value in ordered.items()),
      {"issued_members": len(ordered), "metadata_relocations": relocated})
original_registry = json.loads(ordered["SOURCE_IDENTITIES.json"])
registry = json.loads(returned["SOURCE_IDENTITIES.json"])
source_by_id = {row["id"]: row for row in registry["source_files"]}
sources = original_registry["source_files"]
check("Seven defining sources and immutable identities preserved",
      len(sources) == len(source_by_id) == 7
      and all(identity(returned[row["path"]], row)
              and all(source_by_id[row["id"]][key] == value
                      for key, value in row.items())
              for row in sources),
      {"focused_sources": len(sources)})
check("Eight accepted and historical context identities preserved",
      len(original_registry["accepted_and_context_inputs"]) == 8
      and all(identity(returned[row["path"]], row)
              for row in original_registry["accepted_and_context_inputs"]),
      {"preserved_inputs": 8})
check("Registry source labels match actual TeX",
      all(row["available_tex_labels"] ==
          re.findall(r"\\label\{([^}]+)\}", returned[row["path"]].decode())
          for row in registry["source_files"]), "All seven sources")

prior_zip_name = "accepted_results/NATIVE_ACCESSIBLE_TRANSFER_01_REVIEW_PACKAGE.zip"
prior_zip = returned[prior_zip_name]
with zipfile.ZipFile(BytesIO(prior_zip)) as previous:
    prior_match = all(
        returned["accepted_results/" + name] == previous.read(name)
        for name in ("NATIVE_ACCESSIBLE_TRANSFER_01_PROOF.md",
                     "NATIVE_ACCESSIBLE_TRANSFER_01_CLAIM_SOURCE_LEDGER.md"))
check("Prior accepted package and loose evidence agree",
      digest(prior_zip) ==
      "253ccda27a8c48c89dc52d24ab5c0485a4a9dcd841b7de33412bbc80c64b1c89"
      == returned[prior_zip_name + ".sha256"].decode().split()[0]
      and prior_match, "Exact previously accepted AT01 result; no old suite replay")

baseline = json.loads(returned["INPUT_BASELINE.json"])["files"]
preservation = json.loads(returned["PRESERVATION_CHECK.json"])
final = {row["path"]: row for row in preservation["protected_files"]}
check("37 Windows baseline/final records reconcile",
      len(baseline) == len(final) == 37 and set(baseline) == set(final)
      and all(final[name]["unchanged"] and
              all(final[name][key] == value for key, value in record.items())
              for name, record in baseline.items()),
      "Record reconciliation; not a live Windows filesystem audit")


def retained_bytes(windows_path):
    name = PureWindowsPath(windows_path).name
    if "\\Downloads\\" in windows_path:
        known = {RETURN_NAME: returned_bytes, ORDER_NAME: ordered_bytes,
                 ORDER_NAME + ".sha256": (INPUT / (ORDER_NAME + ".sha256")).read_bytes()}
        return known[name] if name in known else ordered[name]
    marker = "\\NATIVE_PROJECTION_CAPACITY_01\\inputs\\"
    if marker in windows_path:
        return ordered[windows_path.split(marker, 1)[1].replace("\\", "/")]
    if "\\publication_worktree\\" in windows_path:
        repo_path = windows_path.split("\\publication_worktree\\", 1)[1].replace("\\", "/")
        candidates = [row for row in sources if row["repository_path"] == repo_path]
        assert len(candidates) == 1
        return ordered[candidates[0]["path"]]
    if "\\research\\NATIVE_ACCESSIBLE_TRANSFER_01\\" in windows_path:
        return ordered["accepted_results/" + name]
    raise AssertionError("Unmapped protected input: " + windows_path)


check("All protected record identities match retained reference bytes",
      all(identity(retained_bytes(name), row) for name, row in baseline.items()),
      {"records_mapped": len(baseline),
       "limit": "Retained exact copies validate recorded identities, not current remote Windows state"})
copies = preservation["handoff_copies"]
check("23 handoff-copy records match both packets",
      len(copies) == 23 and len({r["path"] for r in copies}) == 23
      and all(row["unchanged_exact_copy"]
              and returned[row["path"]] == ordered[row["input_path"].removeprefix("inputs/")]
              and identity(returned[row["path"]], row) for row in copies),
      {"exact_copies": len(copies)})

proof = returned[PROOF_NAME].decode()
ledger = returned["NATIVE_PROJECTION_CAPACITY_01_CLAIM_SOURCE_LEDGER.md"].decode()
labels = re.findall(r"\\tag\{(PC\d+)\}", proof)
expected_labels = [f"PC{i:02d}" for i in range(1, 23)]
check("All 22 proof labels have ledger rows",
      labels == expected_labels
      and all(re.search(r"\|\s*" + label + r"\s*\|", ledger) for label in labels),
      {"claims": len(labels)})
document = json.loads(returned["DOCUMENT_CHECKS.json"])
references = document["source_label_references"]
check("Source-label references exist in exact defining sources",
      all(row["label"] in source_by_id[row["source"]]["available_tex_labels"]
          for row in references), {"references": len(references)})
links = []
for filename in (PROOF_NAME, "NATIVE_PROJECTION_CAPACITY_01_CLAIM_SOURCE_LEDGER.md"):
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", returned[filename].decode()):
        if not target.startswith(("http:", "https:", "#")):
            links.append(target.split("#", 1)[0])
check("Proof and ledger relative links resolve",
      all(target in returned for target in links), {"links": len(links)})

execution = json.loads(returned["EXACT_ALGEBRA_EXECUTION.json"])
reported = json.loads(returned["EXACT_ALGEBRA_RESULTS.json"])
check("Submitted execution identities reconcile",
      execution["exit_code"] == 0
      and execution["checker_sha256"] == digest(returned["exact_algebra_check.py"])
      and execution["wrapper_sha256"] == digest(returned["run_checks.py"])
      and execution["stdout_sha256"] == digest(returned[execution["stdout"]])
      and execution["stderr_sha256"] == digest(returned[execution["stderr"]])
      and reported["script_sha256"] == execution["checker_sha256"],
      "Checker, wrapper, output, stderr and recorded successful exit")
check("Twelve grouped checks pass without inflated counts",
      reported["grouped_checks_executed"] == reported["passed"] == 12
      and reported["failed"] == 0 and reported["status"] == "PASS"
      and [r["id"] for r in reported["checks"]] == [f"S{i:02d}" for i in range(1, 13)]
      and all(r["status"] == "PASS" and all(v == "0" for v in r["zero_residuals"])
              for r in reported["checks"]), "S01–S12; grouped residuals, not 12 theorem proofs")
replayed = json.loads((ROOT / "INDEPENDENT_ALGEBRA_RESULTS.json").read_text())
check("Independent replay matches every submitted symbolic result",
      replayed["checks"] == reported["checks"]
      and replayed["script_sha256"] == reported["script_sha256"]
      and replayed["status"] == "PASS"
      and replayed["passed"] == 12 and replayed["failed"] == 0,
      {"reviewer_python": replayed["python_version"],
       "reviewer_sympy": replayed["sympy_version"]})

print(json.dumps({
    "task": "NATIVE_PROJECTION_CAPACITY_01",
    "verified_utc": datetime.now(timezone.utc).isoformat(),
    "status": "PASS", "grouped_integrity_checks": len(CHECKS),
    "returned_archive_members": len(returned),
    "returned_hashed_payloads": len(return_manifest["files"]),
    "issued_members_preserved": len(ordered),
    "protected_records_reconciled": len(baseline),
    "scientific_boundary": "This audit checks evidence integrity and replay correspondence. Written proof review separately decides mathematical acceptance.",
    "preservation_boundary": "Codex's Windows records match all retained input identities. GPT did not access or audit the live Windows filesystem.",
    "checks": CHECKS
}, indent=2, ensure_ascii=False))
