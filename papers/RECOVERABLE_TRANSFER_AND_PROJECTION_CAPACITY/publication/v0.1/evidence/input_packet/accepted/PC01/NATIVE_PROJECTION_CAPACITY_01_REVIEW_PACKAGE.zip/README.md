# NATIVE_PROJECTION_CAPACITY_01 — review package

**Verdict: Established.** The proposed projection invariant and all bounded consequences are proved with formulas and hypotheses unchanged. This is a completed analytical investigation for GPT review.

Start with NATIVE_PROJECTION_CAPACITY_01_PROOF.md, then NATIVE_PROJECTION_CAPACITY_01_CLAIM_SOURCE_LEDGER.md. The theorem covers the unchanged fixed real rank-two exchange candidate at every finite positive constant receiver coupling, without a large-coupling threshold. It includes the joint all-time ceiling, full-level feasibility and minimum, zero-drive equivalence, an active strict-improvement witness and a checked finite-time nonattainment example. The written proof supplies the inequality, feasibility and uniqueness arguments.

The new standalone checker ran once: 12 grouped symbolic checks, all passing, no failed checks. Existing environment: Python 3.11.15, SymPy 1.14.0. To run only that checker from Command Prompt:

    call conda activate torment
    python -I -B exact_algebra_check.py

It prints a fresh JSON report to standard output without modifying retained evidence. EXACT_ALGEBRA_EXECUTION.json and EXACT_ALGEBRA_RESULTS.json preserve this investigation's actual run. Historical suites were not replayed; the 12 groups do not include document checks or earlier investigations.

The seven files under sources are exact defining-source selections from the two published editions, not a new compilable manuscript. SOURCE_IDENTITIES.json records their immutable commits and exact bytes. All supplied accepted_results, context and preparation_evidence files remain unchanged. The full accepted AT01 ZIP/checksum and subsequent GPT acceptance are included; historical pending-review text in that old ZIP is superseded by its preserved acceptance receipt.

The three files under input_metadata retain their original names, bytes and original packet scopes. The original packet manifest describes its 22 payloads under original paths, not this new package. The current exhaustive manifest is REVIEW_PACKAGE_MANIFEST.json; it hashes every other member and excludes only itself.

INPUT_VERIFICATION.json records the packet checksum, safe paths/CRC/manifest, exact match of the external work order, seven local publication sources and four local accepted AT01 artifacts. PRESERVATION_CHECK.json rechecks 37 protected files and all 23 copied supplied members. No broad audit of unrelated research occurred.

The final archive checksum and PACKAGE_VERIFICATION.json are adjacent external outputs, avoiding circular archive hashes. verify_review_package.py checks the checksum, safe unique names, CRCs, exhaustive manifest and all member sizes/hashes. Give it the ZIP path as an optional first argument; it prints the report without changing archive contents.

The structural ceiling is necessary, while algebraic sharpness is over the full common native invariant level. Neither implies that a coupled trajectory attains the ceiling. The accepted AT01 small-stock/high-recovery result remains intact. Useful accessible amounts, asymptotic saturation and spatial/physical correspondence remain open.

No installation, Git operation, manuscript, publication, parameter scan, trajectory computation, announcement or successor investigation occurred. GPT review of this new result is pending.
