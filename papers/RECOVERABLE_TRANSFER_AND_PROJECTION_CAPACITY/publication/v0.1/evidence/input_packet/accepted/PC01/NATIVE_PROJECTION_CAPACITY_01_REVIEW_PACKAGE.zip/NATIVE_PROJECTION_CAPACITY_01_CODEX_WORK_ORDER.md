# NATIVE_PROJECTION_CAPACITY_01 — Codex investigation order

**Author:** Hilmir Frímann Halldórsson (pzychozen)  
**Date:** 4 November 2026  
**Task:** A projection invariant and a sharper exchange-only capacity ceiling  
**Status:** Newly authorized bounded investigation; all new formulas below require independent verification  
**Suggested workspace:** C:\TORMENT\TRIOCTAGON_new\research\NATIVE_PROJECTION_CAPACITY_01\

## 1. Execute the next structural investigation

The author has requested the next Codex work order and authorized starting it. NATIVE_ACCESSIBLE_TRANSFER_01 is accepted unchanged. Its 80/81 result quantifies recovery of a small transferred stock in a prescribed early window. The projection-invariant lead was deliberately deferred there and is now the subject of this separate order.

**Determine whether the unchanged published rank-two exchange geometry supplies another conserved native quantity, yielding a stricter upper bound on net extraction valid throughout exchange time.**

Verify the invariant, the joint algebraic floor and one strict improvement for the existing non-dark coherent launch. Challenge the proposed formulas rather than accepting the assessment as proof. Complete this one structural investigation and return its evidence for GPT review. No additional author confirmation is needed.

The two preceding papers are published. The accepted accessible-transfer investigation has no manuscript or publication yet; that status does not prevent this expressly requested investigation.

## 2. Defining inputs

The packet's sources directory is an exact focused source selection, not a new compilable manuscript. SOURCE_IDENTITIES.json records hashes and immutable provenance.

| Key | Source | Use |
|---|---|---|
| P1 | Reciprocal Chiral Exchange v0.1, commit 273b1a6faaab19ea58748d00576439166eeef9ab | candidate.tex, power.tex, wellposed.tex, activity.tex, capacity.tex, interpretation.tex |
| P2 | Same-Trajectory Native Credit v0.1, commit 28e8a85c8fe1e6321328d4d7285b2560d1f98aa9 | problem.tex: exact launch, registration and drive |
| AT01 | Accepted NATIVE_ACCESSIBLE_TRANSFER_01 | Exact proof, ledger, original review ZIP/checksum and GPT acceptance receipt under accepted_results/ |

Read this order, NATIVE_PROJECTION_CAPACITY_01_SOURCE_ASSESSMENT.md and context/RESEARCH_CONTINUITY.md. Then read P1's defining core equation, invariant and solution theorem directly. The historical assessment records where the new lead came from; its proposed invariant was not accepted or used by AT01.

Use the supplied sources and existing local environment. Do not synchronize the repository, rerun earlier scientific suites or reconstruct missing source history. Hash only the focused inputs actually used and preserve them unchanged.

## 3. Fixed model and hypotheses

Retain the published exchange equations, fixed raw chiral registration, finite profiles, positive carrier speed and trial storages. In particular,

\[
x=(a,b),\quad \Omega=a+ib,\quad
f(x)=K(a\times b),\quad J(x)=D_xf(x),\quad
w=K^Ty,\quad y=\mathcal B^*p,
\]
\[
\dot a=\mu\,w\times b,\qquad
\dot b=-\mu\,w\times a,\qquad
\dot\Omega=-i\mu\,w\times\Omega,\qquad
\mu=\frac{\eta_N}{2\alpha_N}.
\]

Fix α_N, β_R, η_N>0 and any finite constant κ=η_R>0. The published positive registration gains make K a fixed real rank-two 2×3 matrix. No large-coupling condition from AT01 is needed for this proposed invariant.

Let e be a real unit vector spanning ker K. For the published registration,

\[
e=R_z(-\delta_g)e_x=(\cos\delta_g,-\sin\delta_g,0),
\qquad Ke=0,\qquad e\cdot w=0.
\]

Verify this against the exact matrix convention. Changing e to −e must leave every proposed quantity unchanged.

Use P1's global solution theorem. The invariant argument needs only the native C1 state and continuous bounded port output, which are available even for the published L2 carrier-preparation class. A new PDE well-posedness proof is not requested.

General invariant/floor statements may use arbitrary admitted initial native and external states. The nonnegative external-stock bound and launch-activity conclusions below require the explicitly empty carrier/receiver preparation. The special coherent launch is introduced separately.

## 4. Main proposed invariant and exact debit account

Define

\[
I=|\Omega|^2=|a|^2+|b|^2,\qquad
h_e=|e\cdot\Omega|^2=(e\cdot a)^2+(e\cdot b)^2,
\]
\[
\mathcal J_K=I-2h_e
=\Omega^\dagger(\mathrm{Id}-2ee^T)\Omega.
\]

Do not confuse the real scalar \(\mathcal J_K\) with the published Jacobian J(x), or the kernel direction e with the carrier energy density. The scalar need not be positive.

The proposed derivative identities are

\[
\dot I=-4\mu\,w\cdot(a\times b),\qquad
\dot h_e=-2\mu\,w\cdot(a\times b),\qquad
\dot{\mathcal J}_K=0.
\]

Derive these with correct signs from the published core equation and e·w=0. A coordinate proof or an explicitly justified reflection-matrix proof is suitable. Explain why differentiating the native variables is valid for the inherited solution class.

The associated proposed exact account is

\[
H_N(0)-H_N(t)=\alpha_N\{h_e(0)-h_e(t)\}.
\]

It is another expression for the same native debit, not an additional storage term or a new physical energy law.

## 5. Joint floor, structural ceiling and algebraic sharpness

Retain the already proved invariant

\[
Z_2(\Omega)=\Omega^T\Omega,\qquad
I^2-|Z_2|^2=4|a\times b|^2.
\]

Put \(Z_0=Z_2(\Omega_0)\), \(j_0=\mathcal J_K(\Omega_0)\). Verify the proposed all-time bound

\[
I(t)\ge\max\{|Z_0|,j_0\},
\]
\[
H_N(0)-H_N(t)\le C_{\rm joint}
:=\frac{\alpha_N}{2}\left[I_0-\max(|Z_0|,j_0)\right]
=\min\left\{
\frac{\alpha_N}{2}(I_0-|Z_0|),\ \alpha_N|e\cdot\Omega_0|^2
\right\}.
\]

Show that C_joint is nonnegative. For initially empty carrier and receiver, use the established total balance to conclude

\[
0\le H_C(t)+H_R(t)=H_N(0)-H_N(t)\le C_{\rm joint}
\qquad(t\ge0).
\]

For preloaded external states, the general upper bound concerns signed net native debit; it is not an upper bound on their entire pre-existing external stock.

### One bounded algebraic sharpness lemma

Determine the minimum over the full common native invariant level set:

\[
\min_{\Omega\in\mathbb C^3:
\,Z_2(\Omega)=Z,\ \mathcal J_K(\Omega)=j}|\Omega|^2.
\]

The proposed feasibility condition is \(j\ge-|Z|\), and the proposed minimum is \(\max(|Z|,j)\). Prove both directions of feasibility and construct equality states. Cover negative j, boundary cases, Z=0 and native zero explicitly.

A candidate route is to write Ω=h e+v with v perpendicular to e, giving

\[
Z=h^2+v^Tv,\qquad j=\|v\|^2-|h|^2.
\]

Here \(v^Tv\) is complex bilinear, while \(\|v\|^2=v^\dagger v\) is Hermitian. Their distinction matters.

For explicit constructions, take real orthonormal u,v in e-perp, set ρ=|Z|, and choose a unit complex γ with γ²ρ=Z when ρ>0; set γ=1 when ρ=0. Verify the candidates

\[
\Omega_*=\gamma\left[
\sqrt{\frac{\rho+j}{2}}u+
\sqrt{\frac{\rho-j}{2}}e\right]
\quad(-\rho\le j\le\rho),
\]
\[
\Omega_*=\gamma\left[
\sqrt{\frac{j+\rho}{2}}u+
i\sqrt{\frac{j-\rho}{2}}v\right]
\quad(j\ge\rho).
\]

This is sharpness among states satisfying the two invariant constraints in the full native state space. Do not restrict that minimization silently to the coherent launch family or identify a constructed minimizer as a reachable terminal state.

## 6. Two structural consequences to check

### Zero ceiling and zero drive

For the fixed real rank-two K, verify or refute

\[
C_{\rm joint}(\Omega_0)=0
\quad\Longleftrightarrow\quad
f(x_0)=0.
\]

The proposed reasoning separates \(a_0\times b_0=0\) from a nonzero cross product parallel to e. Native zero must be included without division by intensity or chirality.

Relate this to the inherited empty-launch statements: zero drive with empty external preparation is stationary; nonzero drive with η_N>0 gives initial supply. Do not claim that every zero-drive core remains stationary with a preloaded carrier.

### Strict improvement for a non-dark admitted launch

Use the existing family \(\Omega_0=(1,e^{i\phi},1)\), \(0<\phi<\pi/12\). Check

\[
I_0=3,\quad |Z_0|=\sqrt{9-8\sin^2\phi},\quad
h_e(0)=1-\sin(2\delta_g)\cos\phi,\quad
j_0=1+2\sin(2\delta_g)\cos\phi.
\]

One fixed admissible witness yaw, δ_g=π/4, is sufficient. The proposed conclusions are

\[
j_0=1+2\cos\phi>|Z_0|,\qquad
j_0^2-|Z_0|^2=4\cos\phi(1-\cos\phi)>0,
\]
\[
0<C_{\rm joint}=\alpha_N(1-\cos\phi)
<
C_Z:=\frac{\alpha_N}{2}\left(3-\sqrt{9-8\sin^2\phi}\right),
\]
\[
|f_0|^2=\frac{10G^2\sin^2\phi}{7}>0,
\qquad G=\kappa_{\rm in}\lambda_g.
\]

Thus the old ceiling would be strictly unreachable for this launch at every exchange time, while the launch remains active. This is not a claim that C_joint itself is reached. The yaw is an analytical witness selected before the trajectory, not a switched parameter or a preferred physical orientation.

A full yaw classification or optimization is unnecessary. Explain consistency with AT01: a stricter positive all-time ceiling can coexist with its positive first-window transfer and high recovered fraction.

## 7. Essential dynamical boundary

Algebraic sharpness and trajectory attainability are separate statements. Include a short checked example showing why that distinction cannot be dropped.

For a real unit u perpendicular to e, the proposed example Ω0=u+i e has

\[
I_0=2,\qquad Z_0=0,\qquad j_0=0,\qquad f(x_0)\ne0.
\]

Its common algebraic level contains Ω*=0. The published invariant-zero property and forward/backward uniqueness prevent a nonzero native state from reaching native zero at a finite exchange time. Check this reasoning carefully; it makes no claim about infinite-time approach.

This example is outside the restricted coherent launch family and serves only to distinguish algebraic minimization from a dynamical saturation assertion. Do not use it as a counterexample to the accepted coherent-launch theorems.

## 8. Scope, verification and deliverables

This is one structural theorem with finite-dimensional consequences. It does not request a trajectory, parameter scan, control/orbit classification, long-time saturation theorem, coupling optimization, new port, modified feedback or receiver, native F stepping, or spatial transfer map. Do not import AT01's κcert condition into an invariant proof that does not need it.

If the invariant or bound fails, identify the precise failure and deliver the narrowest valid result within the same equations. Record any necessary correction explicitly. A well-supported scoped obstruction is an acceptable outcome; changing the model to obtain success is outside the task.

Use the existing environment and a small standalone exact-algebra checker for useful derivative identities, equality constructions, witness formulas and signs. The written proof must establish the level-set feasibility, minimum and dynamical distinctions; algebra output alone cannot do that. Do not install packages or replay old suites.

Deliver in the new workspace:

1. NATIVE_PROJECTION_CAPACITY_01_PROOF.md with verdict, precise hypotheses, proof, equality constructions, zero-drive result, non-dark witness and limits.
2. NATIVE_PROJECTION_CAPACITY_01_CLAIM_SOURCE_LEDGER.md separating inherited facts, new definitions and proved deductions, corrected/rejected proposals, and unresolved dynamical interpretation.
3. The exact-algebra checker and actual execution record, with meaningful check counts.
4. Focused source identities, input-preservation checks and a concise completion record.
5. NATIVE_PROJECTION_CAPACITY_01_REVIEW_PACKAGE.zip and adjacent SHA-256 checksum, with exhaustive self-excluded manifest, safe unique members, CRC and hash verification.

Preserve published sources, the accepted AT01 result and supplied context unchanged. A focused input baseline/final comparison is sufficient; do not audit unrelated research.

Return **Established**, **Established with specified corrections**, or **Not established within this scope**, and the review package for GPT. No manuscript, Git operation, publication, announcement or successor investigation is included.

## 9. Geometric continuity and author involvement

The kernel direction is a mathematical consequence of the existing raw chiral registration. Do not identify it with a physical support, opening, field axis or receiver location without a separate correspondence argument.

The central starting/meeting region, opposed cones, outward spreading and around–inward return, stationary supports and possible transfer elsewhere remain the intended programme. The tentative 15–20% intuition is not a fitted target.

No new geometric choice is needed for this order. Ask the author when changing the registration, receiver law/location or physical route interpretation becomes necessary. Later directions remain useful accessible capacity beyond necessary ceilings, native stepping/cadence, intended route correspondence, six-opening transport, linked gravity–magnetism, outer geometry and justified SRG integration.
