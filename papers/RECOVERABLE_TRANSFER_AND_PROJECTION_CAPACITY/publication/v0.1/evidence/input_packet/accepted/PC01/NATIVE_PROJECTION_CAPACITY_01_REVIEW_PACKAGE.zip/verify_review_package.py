"""Read-only verification of the final review archive and adjacent checksum."""
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
import hashlib,json,sys,zipfile

TASK="NATIVE_PROJECTION_CAPACITY_01"
archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/(TASK+"_REVIEW_PACKAGE.zip")
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive.with_suffix(".zip.sha256").read_text(encoding="ascii").split()[0]==digest
checked=[]
with zipfile.ZipFile(archive) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==len({n.casefold() for n in names})
    for name in names:
        p=PurePosixPath(name)
        assert name and not p.is_absolute() and ".." not in p.parts
        assert "\\" not in name and ":" not in name and not name.endswith("/")
        assert str(p)==name and not any(part in {"",".",".."} for part in p.parts)
        assert ((z.getinfo(name).external_attr>>16)&0o170000)!=0o120000
    assert z.testzip() is None
    mn="REVIEW_PACKAGE_MANIFEST.json"
    manifest=json.loads(z.read(mn));assert manifest["self_excluded"]==mn
    entries={r["path"]:r for r in manifest["files"]}
    assert len(entries)==len(manifest["files"]) and mn not in entries
    assert set(names)==set(entries)|{mn}
    for name,row in entries.items():
        data=z.read(name)
        actual={"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
        assert actual=={k:row[k] for k in ["bytes","sha256"]},name
        checked.append({"path":name,**actual,"manifest_match":True})
    source_ids=json.loads(z.read("SOURCE_IDENTITIES.json"))
    assert len(source_ids["source_files"])==7
    for row in source_ids["source_files"]:
        assert row["sha256"]==entries[row["path"]]["sha256"]
    preservation=json.loads(z.read("PRESERVATION_CHECK.json"))
    assert preservation["status"]=="PASS" and preservation["protected_files_checked"]==37
    assert preservation["handoff_copies_checked"]==len(preservation["handoff_copies"])==23
    for row in preservation["handoff_copies"]:
        assert row["sha256"]==entries[row["path"]]["sha256"]
    prior="accepted_results/NATIVE_ACCESSIBLE_TRANSFER_01_REVIEW_PACKAGE.zip"
    assert hashlib.sha256(z.read(prior)).hexdigest()==z.read(prior+".sha256").decode("ascii").split()[0]
    assert entries[prior]["sha256"]=="253ccda27a8c48c89dc52d24ab5c0485a4a9dcd841b7de33412bbc80c64b1c89"
    result=json.loads(z.read("EXACT_ALGEBRA_RESULTS.json"))
    execution=json.loads(z.read("EXACT_ALGEBRA_EXECUTION.json"))
    assert result["status"]=="PASS" and result["passed"]==result["grouped_checks_executed"]==12
    assert result["failed"]==0 and execution["exit_code"]==0
    assert result["script_sha256"]==execution["checker_sha256"]==entries["exact_algebra_check.py"]["sha256"]
    assert execution["stdout_sha256"]==entries["EXACT_ALGEBRA_RESULTS.json"]["sha256"]
    assert z.read("EXACT_ALGEBRA_STDERR.txt")==b""
    assert "**Verdict: Established.**" in z.read(TASK+"_PROOF.md").decode("utf-8")
print(json.dumps({
    "utc":datetime.now(timezone.utc).isoformat(),"status":"PASS","archive":str(archive.resolve()),
    "bytes":archive.stat().st_size,"sha256":digest,"members":len(names),
    "manifest_payloads":len(checked),"safe_unique_members":True,"crc_pass":True,
    "exhaustive_manifest":True,"all_sizes_and_hashes_match":True,"adjacent_checksum_matches":True,
    "focused_source_identities_match":True,"all_23_preserved_handoff_copies_match":True,
    "accepted_AT01_archive_unchanged":True,"checker_execution_evidence_consistent":True,
    "payloads":checked,"scope":"Archive integrity, input identity and recorded execution consistency; not additional mathematical checks or GPT acceptance."
},indent=2,ensure_ascii=False))
