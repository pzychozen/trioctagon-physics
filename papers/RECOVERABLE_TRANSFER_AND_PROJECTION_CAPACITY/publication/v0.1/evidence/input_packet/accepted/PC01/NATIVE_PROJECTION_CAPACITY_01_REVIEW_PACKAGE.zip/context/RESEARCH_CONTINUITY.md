# Research continuity — projection-capacity investigation

**Date:** 4 November 2026

## Current status

| Work | Status |
|---|---|
| Reciprocal chiral exchange baseline | Published v0.1 at 273b1a6faaab19ea58748d00576439166eeef9ab; closeout complete |
| Same-trajectory native credit | Published v0.1 at 28e8a85c8fe1e6321328d4d7285b2560d1f98aa9; closeout complete |
| NATIVE_ACCESSIBLE_TRANSFER_01 | Accepted unchanged by GPT; quantitative early-window result complete; manuscript/publication not yet prepared |
| Projection-invariant lead | Recorded during the AT01 assessment, unused in its accepted proof |
| NATIVE_PROJECTION_CAPACITY_01 | Newly authorized investigation of that lead; proposed conclusions await Codex verification and GPT review |

The accepted AT01 result proves the specified receiver share and net recovery bounds, endpoint retention, charging and backflow, with large recovered fractions coexisting with small transferred stock. The q=1/5 guarantees refer to explicit intermediate-stock denominators. They do not establish full-time capacity attainment.

The current order asks whether the fixed rank-two registration creates a stronger all-time structural ceiling. A sharp algebraic floor is distinct from the actual maximum reached by a coupled solution.

## Sequence and scope

Complete the projection-capacity proof and review before choosing its successor. Useful accessible amounts beyond necessary ceilings and the first-window regime remain part of this same capacity/receiver direction.

The later sequence remains:

1. Native F stepping and exchange cadence, preserving the exact native baseline account.
2. Correspondence with the intended central outward–around–inward route and stationary supports.
3. Six-opening transport, retaining the distinction between central broken G boundaries and finite host-notch N regions.
4. Linked gravity–magnetism interpretation, with justified units, sources, forces and motion.
5. Later outer Tri-Octagon geometry and further justified SRG integration.

The accepted quantitative transfer result and a successfully reviewed projection-capacity result may inform one follow-on manuscript. That is an editorial option after review, not an automatic manuscript or publication action in this order.

## Collaboration

GPT leads formulation and review; Codex independently challenges bounded assignments and returns evidence. Existing equations and supplied files should carry the analysis. The author should not have to reconstruct old parameters.

The author welcomes creative associations, humor and spontaneous thoughts during research. Those exchanges do not reset the work's status or replace the agreed objective.

Preserve the central starting/meeting region, opposed cones, outward spreading and curved around–inward return, stationary supports and possible transfer elsewhere. The tentative 15–20%, possibly more, remains geometric intuition rather than a measured or fitted coefficient.

The carrier circle, intended tight toroid, close original enclosing sphere and extended-line sphere are distinct. The kernel direction of the raw chiral registration is not automatically a physical support, opening, field axis or receiver position.

No new geometric decision is needed for the current invariant calculation. Seek the author's intuition when a spatial interpretation remains genuinely ambiguous, a new geometric or receiving assumption is needed, or a choice changes the intended construction.

Historical sources retain their original dates and status wording. This record and the new order provide the current state without rewriting accepted evidence.
