"""Finalize records and bounded review package without changing protected inputs."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,re,zipfile

W=Path(__file__).resolve().parent
TASK="NATIVE_PROJECTION_CAPACITY_01"
utc=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ident=lambda p:{"bytes":p.stat().st_size,"sha256":sha(p)}
save=lambda n,x:(W/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")

result=json.loads((W/"EXACT_ALGEBRA_RESULTS.json").read_text(encoding="utf-8"))
execution=json.loads((W/"EXACT_ALGEBRA_EXECUTION.json").read_text(encoding="utf-8"))
assert result["status"]=="PASS" and result["grouped_checks_executed"]==result["passed"]==12
assert result["failed"]==0 and execution["exit_code"]==0
assert result["script_sha256"]==execution["checker_sha256"]==sha(W/"exact_algebra_check.py")
assert execution["stdout_sha256"]==sha(W/"EXACT_ALGEBRA_RESULTS.json")
assert execution["stderr_sha256"]==sha(W/"EXACT_ALGEBRA_STDERR.txt")
assert (W/"EXACT_ALGEBRA_STDERR.txt").read_bytes()==b""

original_registry=json.loads((W/"inputs/SOURCE_IDENTITIES.json").read_text(encoding="utf-8"))
original_manifest=json.loads((W/"inputs/PACKET_MANIFEST.json").read_text(encoding="utf-8"))
copy_map={}
for path in sorted((W/"inputs").rglob("*")):
    if not path.is_file():continue
    rel=path.relative_to(W/"inputs").as_posix()
    dest="input_metadata/"+rel if rel in {"SOURCE_IDENTITIES.json","PACKET_MANIFEST.json","READ_ME_FOR_CODEX.md"} else rel
    assert (W/dest).read_bytes()==path.read_bytes(),dest
    copy_map[dest]=rel
assert len(copy_map)==23
sources=[]
for row in original_registry["source_files"]:
    p=W/row["path"]
    assert ident(p)=={k:row[k] for k in ["bytes","sha256"]}
    sources.append({**row,"available_tex_labels":re.findall(r"\\label\{([^}]+)\}",p.read_text(encoding="utf-8")),
                    "verification_basis":"Exact supplied source and matching retained local publication bytes; no fresh remote retrieval."})
assert len(sources)==7
accepted_context=[
    {"path":dest,"original_packet_path":original,**ident(W/dest),
     "role":"Accepted AT01 result, unchanged" if dest.startswith("accepted_results/") else
            "Research continuity or historical context, unchanged" if dest.startswith("context/") else
            "Input provenance, original bytes and scope retained"}
    for dest,original in copy_map.items() if not dest.startswith("sources/")
]
save("SOURCE_IDENTITIES.json",{
    "task":TASK,"created_utc":utc(),"focused_source_count":7,"source_files":sources,
    "preserved_non_source_inputs":accepted_context,
    "packet":json.loads((W/"INPUT_VERIFICATION.json").read_text(encoding="utf-8"))["packet"],
    "original_registry":{"path":"input_metadata/SOURCE_IDENTITIES.json",**ident(W/"input_metadata/SOURCE_IDENTITIES.json")},
    "governing_input":TASK+"_CODEX_WORK_ORDER.md",
    "scope":"Seven exact focused published sources and all supplied accepted/context/provenance records. Current proof and checks are new; their identities are in REVIEW_PACKAGE_MANIFEST.json. Prior AT01 archive remains unchanged."
})

baseline=json.loads((W/"INPUT_BASELINE.json").read_text(encoding="utf-8"))
protected=[]
for name,expected in baseline["files"].items():
    p=Path(name)
    assert p.is_file() and ident(p)==expected,f"Protected input changed: {name}"
    protected.append({"path":name,**ident(p),"unchanged":True})
assert len(protected)==37
copy_records=[{"path":dest,"input_path":"inputs/"+original,**ident(W/dest),"unchanged_exact_copy":True}
              for dest,original in sorted(copy_map.items())]
save("PRESERVATION_CHECK.json",{
    "utc":utc(),"status":"PASS","baseline":"INPUT_BASELINE.json",
    "protected_files_checked":37,"protected_files":protected,
    "handoff_copies_checked":23,"handoff_copies":copy_records,
    "published_source_changes":0,"accepted_result_changes":0,"context_changes":0,
    "scope":"Only supplied files, focused seven publication sources, four local accepted AT01 artifacts, extracted inputs and exact handoff copies. No unrelated research audit."
})

proof_name=TASK+"_PROOF.md";ledger_name=TASK+"_CLAIM_SOURCE_LEDGER.md"
proof=(W/proof_name).read_text(encoding="utf-8")
ledger=(W/ledger_name).read_text(encoding="utf-8")
tags=re.findall(r"\\tag\{(PC\d\d)\}",proof)
assert tags==[f"PC{i:02d}" for i in range(1,23)]
assert proof.count(r"\[")==proof.count(r"\]")==22
assert all(f"| {tag} |" in ledger for tag in tags)
assert "**Verdict: Established.**" in proof
assert "Corrected or rejected proposals | None." in ledger
links=[]
for name in [proof_name,ledger_name]:
    text=(W/name).read_text(encoding="utf-8")
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)",text):
        if "://" not in target:
            assert (W/target).is_file(),(name,target)
            links.append({"document":name,"target":target,"exists":True})
lookup={row["id"]:row for row in sources}
references=[]
for line in ledger.splitlines():
    if not re.match(r"\| PC\d\d \|",line):continue
    current=None
    for token in re.findall(r"P[12]\.[a-z]+|(?:eq|sec|thm|prop):[A-Za-z0-9]+",line):
        if token.startswith(("P1.","P2.")):
            assert token in lookup,token
            current=token
        elif current:
            assert token in lookup[current]["available_tex_labels"],(current,token)
            references.append({"source":current,"label":token})
save("DOCUMENT_CHECKS.json",{
    "utc":utc(),"status":"PASS","proof_labels":tags,"ledger_covers_all_22_labels":True,
    "display_math_pairs":22,"relative_links":links,"source_label_references":references,
    "checker_evidence_matches_current_files":True,
    "scope":"Document/source-reference/integrity checks; not additional mathematics.",
    "review_note":"Written proof checked against exact defining sources. New GPT scientific review pending. Accepted AT01 status preserved.",
    "format":"Markdown analytical investigation. No new manuscript or PDF."
})

readme=f"""# {TASK} — review package

**Verdict: Established.** The proposed projection invariant and all bounded consequences are proved with formulas and hypotheses unchanged. This is a completed analytical investigation for GPT review.

Start with {proof_name}, then {ledger_name}. The theorem covers the unchanged fixed real rank-two exchange candidate at every finite positive constant receiver coupling, without a large-coupling threshold. It includes the joint all-time ceiling, full-level feasibility and minimum, zero-drive equivalence, an active strict-improvement witness and a checked finite-time nonattainment example. The written proof supplies the inequality, feasibility and uniqueness arguments.

The new standalone checker ran once: 12 grouped symbolic checks, all passing, no failed checks. Existing environment: Python 3.11.15, SymPy 1.14.0. To run only that checker from Command Prompt:

    call conda activate torment
    python -I -B exact_algebra_check.py

It prints a fresh JSON report to standard output without modifying retained evidence. EXACT_ALGEBRA_EXECUTION.json and EXACT_ALGEBRA_RESULTS.json preserve this investigation's actual run. Historical suites were not replayed; the 12 groups do not include document checks or earlier investigations.

The seven files under sources are exact defining-source selections from the two published editions, not a new compilable manuscript. SOURCE_IDENTITIES.json records their immutable commits and exact bytes. All supplied accepted_results, context and preparation_evidence files remain unchanged. The full accepted AT01 ZIP/checksum and subsequent GPT acceptance are included; historical pending-review text in that old ZIP is superseded by its preserved acceptance receipt.

The three files under input_metadata retain their original names, bytes and original packet scopes. The original packet manifest describes its 22 payloads under original paths, not this new package. The current exhaustive manifest is REVIEW_PACKAGE_MANIFEST.json; it hashes every other member and excludes only itself.

INPUT_VERIFICATION.json records the packet checksum, safe paths/CRC/manifest, exact match of the external work order, seven local publication sources and four local accepted AT01 artifacts. PRESERVATION_CHECK.json rechecks 37 protected files and all 23 copied supplied members. No broad audit of unrelated research occurred.

The final archive checksum and PACKAGE_VERIFICATION.json are adjacent external outputs, avoiding circular archive hashes. verify_review_package.py checks the checksum, safe unique names, CRCs, exhaustive manifest and all member sizes/hashes. Give it the ZIP path as an optional first argument; it prints the report without changing archive contents.

The structural ceiling is necessary, while algebraic sharpness is over the full common native invariant level. Neither implies that a coupled trajectory attains the ceiling. The accepted AT01 small-stock/high-recovery result remains intact. Useful accessible amounts, asymptotic saturation and spatial/physical correspondence remain open.

No installation, Git operation, manuscript, publication, parameter scan, trajectory computation, announcement or successor investigation occurred. GPT review of this new result is pending.
"""
(W/"README.md").write_text(readme,encoding="utf-8")
completion=f"""# {TASK} — completion record

**Date:** 4 November 2026. **Verdict:** Established.

The author authorized reading and executing the standalone work order. It matches the packet copy exactly. The work remained within this structural investigation; no additional confirmation was needed.

Established unchanged: the conserved scalar J_K=I-2|e dot Omega|²; the exact native debit alpha_N[h_e(0)-h_e(t)]; the joint all-time ceiling min(C_Z,alpha_N h_e(0)); feasibility j>=-|Z| and exact full-level minimum max(|Z|,j); zero joint ceiling iff zero raw drive; and the active coherent witness at fixed yaw pi/4 with C_joint=alpha_N(1-cos(phi))<C_Z. Negative j, zero Z, native zero and preloaded external-state interpretation are explicit.

The nonzero state u+i e shares Z=j=0 with native zero, but global forward/backward uniqueness prevents finite-time native-zero arrival. This establishes the required boundary between an algebraic minimum and a trajectory saturation claim; infinite-time approach remains unresolved.

Verification: one actual execution of 12 new grouped symbolic checks, 12 passed and zero failed, in cmd.exe with conda activate torment. Python 3.11.15 and SymPy 1.14.0 were already installed. The written proof supplies feasibility, minimum, zero-drive and dynamical reasoning; the checker is supporting algebra only.

The seven defining sources and accepted AT01 artifacts match the supplied identities and corresponding focused local copies. All 37 protected input files and all 23 copied supplied members remain unchanged. Document/source-label checks pass. No source conflict, material discrepancy or mathematical correction was found.

The review archive is assembled from an explicit allowlist with an exhaustive self-excluded manifest. Its final independently executed ZIP verification and SHA-256 are external in PACKAGE_VERIFICATION.json and the adjacent .zip.sha256, avoiding self-reference.

Limits: fixed rank-two exchange model and constant parameters; empty external preparation for nonnegative external-stock conclusions; no large-coupling restriction on the structural invariant; no proof of dynamical ceiling attainment, infinite-time saturation, physical-axis assignment or new geometric correspondence. The prior accepted result and research agenda are preserved.

GPT review of the new investigation remains pending. No manuscript, Git operation, publication, announcement or successor task was undertaken.
"""
(W/"COMPLETION_RECORD.md").write_text(completion,encoding="utf-8")

new_files=[
    "README.md",proof_name,ledger_name,"SOURCE_IDENTITIES.json","PRESERVATION_CHECK.json",
    "COMPLETION_RECORD.md","INPUT_BASELINE.json","INPUT_VERIFICATION.json","ENVIRONMENT.json",
    "AGENTS_CHECK.json","DOCUMENT_CHECKS.json","exact_algebra_check.py","run_checks.py",
    "EXACT_ALGEBRA_RESULTS.json","EXACT_ALGEBRA_STDERR.txt","EXACT_ALGEBRA_EXECUTION.json",
    "prepare_inputs.py","finalize_review.py","verify_review_package.py"
]
members=sorted(new_files+list(copy_map))
assert len(members)==len(set(members))==len({n.casefold() for n in members})
assert all((W/n).is_file() for n in members)
save("REVIEW_PACKAGE_MANIFEST.json",{
    "task":TASK,"created_utc":utc(),"self_excluded":"REVIEW_PACKAGE_MANIFEST.json",
    "scope":"Every current review member except this manifest. Historical packet and accepted-result manifests retain their original scopes.",
    "files":[{"path":n,**ident(W/n)} for n in members]
})
members=sorted(members+["REVIEW_PACKAGE_MANIFEST.json"])
archive=W/(TASK+"_REVIEW_PACKAGE.zip")
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in members:z.write(W/name,name)
(W/(archive.name+".sha256")).write_text(sha(archive)+"  "+archive.name+"\n",encoding="ascii")
print(json.dumps({"archive":str(archive),**ident(archive),"members":len(members),
                  "manifest_payloads":len(members)-1,"protected_files":37,"input_copies":23,
                  "status":"BUILT; independent verification follows"}))
