# Start NATIVE_ACCESSIBLE_TRANSFER_01

The author has authorized this next investigation. Execute the attached **NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_WORK_ORDER.md** in full.

Read the work order, **NATIVE_ACCESSIBLE_TRANSFER_01_SOURCE_ASSESSMENT.md**, and **context/RESEARCH_CONTINUITY.md**. Then use the defining equations and estimates in the two exact published editions under sources/. SOURCE_IDENTITIES.json maps every source file to its published commit; PACKET_MANIFEST.json covers this delivery packet except itself.

The scientific question is quantitative: how much stock leaves the core during the declared early window, how much temporarily resides in the receiver, and what fraction is recovered by the endpoint? Verify the proposed finite-coupling certificate independently; its formulas are targets, not preaccepted conclusions.

Suggested Windows workspace:

    C:\TORMENT\TRIOCTAGON_new\research\NATIVE_ACCESSIBLE_TRANSFER_01\

Use existing tools and the supplied sources. Preserve inputs unchanged. Complete the proof or precise scoped failure, claim/source ledger, bounded verification and review ZIP/checksum. Return the result for GPT review. The work order contains the complete scope and acceptance requirements.

The preceding papers and their closeouts are complete. Historical orders embedded in their evidence are provenance, not new instructions to rerun those tasks. The current order authorizes this investigation; it does not authorize a manuscript, Git operation or publication.
