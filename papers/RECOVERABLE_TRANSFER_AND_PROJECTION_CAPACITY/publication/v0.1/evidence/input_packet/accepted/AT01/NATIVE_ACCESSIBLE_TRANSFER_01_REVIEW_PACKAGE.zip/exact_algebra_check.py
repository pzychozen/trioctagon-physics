"""Bounded symbolic checks for AT01--AT29; no dynamics, scans, or source imports.

Run: call conda activate torment && python -I -B exact_algebra_check.py
Requires the existing SymPy installation. Prints one JSON report; exit 1 on failure.
Eighteen grouped checks, not a proof of PDE regularity or normalized inequalities.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys
import sympy as s

started = datetime.now(timezone.utc).isoformat()
w, beta, F, lam, eps, eta, kap, B1, B2, A, S = s.symbols(
    "omega beta F Lambda epsilon eta kappa B1 B2 A S", positive=True)
m, d, c, q = s.symbols("m d c q", positive=True)
theta, tau, phi = s.symbols("theta tau phi", real=True)
checks = []


def check(identifier, description, labels, expressions, assumptions):
    residuals = [s.simplify(s.trigsimp(s.expand(e))) for e in expressions]
    ok = all(e == 0 for e in residuals)
    checks.append({
        "id": identifier, "description": description, "proof_labels": labels,
        "assumptions": assumptions, "status": "PASS" if ok else "FAIL",
        "zero_residuals": [str(e) for e in residuals],
    })


check("S01", "Comparison scalar differential equations and zero preparation", ["AT10"],
      [s.diff(s.sin(w*tau)/w, tau) - (1-(1-s.cos(w*tau))),
       s.diff(1-s.cos(w*tau), tau) - w*s.sin(w*tau),
       s.sin(0), 1-s.cos(0)],
      "omega>0; m/beta=omega^2; spatial profile is fixed. Only scalar coefficients checked.")

check("S02", "Weighted comparison norm identity", ["AT14"],
      [s.sin(theta)**2+(1-s.cos(theta))**2-4*s.sin(theta/2)**2],
      "theta real; m/omega^2=beta; Lambda^2=beta|f0|^2 supplied in proof.")

check("S03", "Four comparison landmarks and different projection zeros", ["AT14", "AT16", "AT21"],
      [s.sin(s.pi), 1-s.cos(s.pi)-2, s.sin(2*s.pi), 1-s.cos(2*s.pi),
       (1-s.cos(s.pi/2))*s.sin(s.pi/2)-1,
       (1-s.cos(3*s.pi/2))*s.sin(3*s.pi/2)+1],
      "Exact symbolic landmarks; does not locate an extremum of the actual solution.")

check("S04", "Full-window absolute sine integral, split at pi", ["AT12"],
      [s.integrate(s.sin(theta), (theta, 0, s.pi))/w
       -s.integrate(s.sin(theta), (theta, s.pi, 2*s.pi))/w - 4/w],
      "omega>0; sine nonnegative on [0,pi] and nonpositive on [pi,2pi].")

check("S05", "Integrated quadratic native-drive residual", ["AT12"],
      [s.integrate(A*tau**2, (tau, 0, S))-A*S**3/3],
      "A,S>0; multiplying by sqrt(m)/kappa^2 gives the core-error term.")

check("S06", "Power scale D in equivalent normalizations", ["AT09"],
      [((m/w)*F**2 - w*beta*F**2).subs(m, beta*w**2)],
      "F=|f0|>0; m=beta*omega^2; Lambda=sqrt(beta)F.")

z1,z2,y1,y2,dz1,dz2,dy1,dy2 = s.symbols("z1 z2 y1 y2 dz1 dz2 dy1 dy2", real=True)
z0=s.Matrix([z1,z2]); y0=s.Matrix([y1,y2])
dz=s.Matrix([dz1,dz2]); dy=s.Matrix([dy1,dy2])
check("S07", "Full two-component receiver-product expansion", ["AT20"],
      [(z0+dz).dot(y0+dy)-z0.dot(y0)-z0.dot(dy)-dz.dot(y0)-dz.dot(dy)],
      "All eight entries real; both linear errors and the product error retained.")

linear = s.sqrt(m)*F*eps + (m/w)*F*eps/s.sqrt(beta)
product = s.sqrt(m)*eps**2/s.sqrt(beta)
check("S08", "Receiver-product error coefficients", ["AT21"],
      [(linear+product-w*(2*s.sqrt(beta)*F*eps+eps**2)).subs(m,beta*w**2)],
      "beta,omega,F,epsilon positive; triangle and Cauchy-Schwarz inequalities are in the proof.")

zh,yh = s.symbols("zh yh", real=True)
check("S09", "Original receiver-power conversion", ["AT21"],
      [kap*(eta*zh/kap)*(eta*yh/kap) - eta**2*zh*yh/kap],
      "Finite positive dimensionless eta,kappa; componentwise dot product scaling.")

check("S10", "Two threshold allocations", ["AT23"],
      [B1/(2*B1/(q*lam))-q*lam/2,
       B2/(s.sqrt(2*B2/(q*lam)))**2-q*lam/2],
      "B1,B2,q,Lambda>0. Inverse powers decrease for positive kappa; each threshold gives <=q Lambda/2.")

r = s.symbols("r", real=True)
check("S11", "Fraction comparison monotonicity and positive regime", ["AT18", "AT24"],
      [s.diff(r/(2-r),r)-2/(2-r)**2,
       1-(r/(2-r))**2 - 4*(1-r)/(2-r)**2],
      "0<=r<1 makes derivative and second expression positive; denominator is nonzero.")

check("S12", "Receiver half-margin throughout 0<q<=1/5", ["AT24"],
      [s.Rational(1,2)-2*q-q**2
       -(s.Rational(3,50)+(s.Rational(1,5)-q)*(s.Rational(11,5)+q)),
       (2*q+q**2).subs(q,s.Rational(1,5))-s.Rational(11,25)],
      "0<q<=1/5; displayed factorization is positive, including endpoint 3/50.")

check("S13", "Exact q=1/5 fraction and retention constants", ["AT24"],
      [(1-(q/(2-q))**2).subs(q,s.Rational(1,5))-s.Rational(80,81),
       ((q/(2-q))**2).subs(q,s.Rational(1,5))-s.Rational(1,81)],
      "Analytical tolerance only; not a measured transfer percentage.")

check("S14", "Absolute recovery lower-bound simplification", ["AT19"],
      [eta**2/(2*kap**2)*((2*lam-eps)**2-eps**2)
       -2*eta**2*lam*(lam-eps)/kap**2],
      "eta,kappa,Lambda>0; positivity additionally needs epsilon<Lambda.")

check("S15", "Stock sandwich deviations about leading coefficient", ["AT27", "AT28"],
      [(2*lam+eps)**2-4*lam**2-(4*lam*eps+eps**2),
       4*lam**2-(2*lam-eps)**2-(4*lam*eps-eps**2),
       eta**2/(2*kap**2)*4*lam**2-2*eta**2*lam**2/kap**2],
      "0<epsilon<2 Lambda; absolute lower deviation <=4 Lambda epsilon+epsilon^2.")

L=B1+B2
check("S16", "Finite inverse-power simplifications", ["AT27"],
      [L/kap-(B1/kap+B2/kap**2)-B2*(kap-1)/kap**2,
       eta**2/(2*kap**2)*(4*lam*L/kap+(L/kap)**2)
       -(2*eta**2*lam*L/kap**3+eta**2*L**2/(2*kap**4))],
      "kappa>=1 makes first factored difference nonnegative; all constants fixed.")

check("S17", "Launch invariant modulus for positive ceiling", ["AT26"],
      [(2+s.cos(2*phi))**2+s.sin(2*phi)**2-(9-8*s.sin(phi)**2)],
      "phi real; the written proof uses 0<phi<pi/12 to prove 0<|Z2|<3.")

# Unit exponent vectors in order (U,L,T,A_amp).
unit=lambda *v:s.Matrix(v)
dim_m=unit(0,-1,0,0); dim_d=unit(0,-3,0,0)
dim_c=unit(0,1,-1,0); dim_F=unit(1,1,-1,0)
dim_beta=unit(0,-1,2,0); dim_w=unit(0,0,-1,0)
dim_A=unit(1,1,-3,0); dim_S=unit(0,0,1,0)
dim_norm=unit(1,s.Rational(1,2),0,0); dim_power=unit(2,1,-1,0)
dim_Lambda=dim_beta/2+dim_F
dim_B1=dim_c+dim_d/2+dim_F-2*dim_w
dim_B2=dim_m/2+dim_A+3*dim_S
unit_residuals=[]
for vector in [dim_Lambda-dim_norm,dim_B1-dim_norm,dim_B2-dim_norm,
               dim_m-dim_w+2*dim_F-dim_power,
               dim_B1-dim_Lambda,dim_B2-dim_Lambda,
               2*dim_norm-unit(2,1,0,0)]:
    unit_residuals.extend(list(vector))
check("S18", "New constants, threshold ratios, stock and power dimensions", ["AT09", "AT21", "AT23", "AT27"],
      unit_residuals, "Inherited abstract units; numerical factors and couplings dimensionless. Not physical calibration.")

assert len(checks)==18 and len({x["id"] for x in checks})==18
report={
    "task":"NATIVE_ACCESSIBLE_TRANSFER_01", "started_utc":started,
    "finished_utc":datetime.now(timezone.utc).isoformat(),
    "python":sys.executable, "python_version":sys.version,
    "sympy_version":s.__version__,
    "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "grouped_checks_executed":len(checks),
    "passed":sum(c["status"]=="PASS" for c in checks),
    "failed":sum(c["status"]=="FAIL" for c in checks),
    "checks":checks,
    "scope":"Exact algebra and explicitly stated inequality allocations only. No PDE proof, trajectory, scan, historical-suite replay, document check, or physical validation counted."
}
report["status"]="PASS" if not report["failed"] else "FAIL"
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(0 if report["status"]=="PASS" else 1)
