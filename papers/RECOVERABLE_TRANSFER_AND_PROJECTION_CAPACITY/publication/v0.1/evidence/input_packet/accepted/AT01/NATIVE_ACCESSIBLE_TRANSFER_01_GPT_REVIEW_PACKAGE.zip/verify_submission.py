#!/usr/bin/env python3
"""Read-only integrity/provenance review. Writes only the review result JSON."""
from pathlib import Path, PurePosixPath, PureWindowsPath
from datetime import datetime, timezone
import hashlib
import json
import re
import stat
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SUB = HERE.parent / "submission"
ISSUED = ROOT / "accessible_transfer_order/packet"
ARCHIVE = ROOT / "upload/NATIVE_ACCESSIBLE_TRANSFER_01_REVIEW_PACKAGE.zip"
checks = []
def check(name, condition):
    checks.append({"check": name, "pass": bool(condition)})
def js(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def identity(data):
    return {"bytes":len(data), "sha256":hashlib.sha256(data).hexdigest()}
def recorded_id(entry):
    return {k:entry[k] for k in ("bytes","sha256")}
def files_at(path):
    return {q.relative_to(path).as_posix():q for q in path.rglob("*") if q.is_file()}
def safe(info):
    p=PurePosixPath(info.filename)
    return (not p.is_absolute() and ".." not in p.parts and ":" not in info.filename and
            "\\" not in info.filename and not stat.S_ISLNK((info.external_attr>>16)&0xFFFF))
archive_id=identity(ARCHIVE.read_bytes())
check("submitted_archive_supplied_sha256",
      archive_id["sha256"]=="253ccda27a8c48c89dc52d24ab5c0485a4a9dcd841b7de33412bbc80c64b1c89")
check("archive_sidecar_exact_identity",
      ARCHIVE.with_suffix(".zip.sha256").read_text().split()==[archive_id["sha256"],ARCHIVE.name])
manifest=js(SUB/"REVIEW_PACKAGE_MANIFEST.json")
with zipfile.ZipFile(ARCHIVE) as z:
    names=z.namelist()
    check("archive_unique_safe_44_members",len(names)==len(set(names))==44 and all(safe(i) for i in z.infolist()))
    check("archive_crc",z.testzip() is None)
    check("extracted_file_set_and_bytes",
          set(files_at(SUB))==set(names) and all((SUB/n).read_bytes()==z.read(n) for n in names))
    check("manifest_exhaustive_43_payloads",
          manifest["self_excluded"]=="REVIEW_PACKAGE_MANIFEST.json" and len(manifest["files"])==43 and
          len({r["path"] for r in manifest["files"]})==43 and
          {r["path"] for r in manifest["files"]}==set(names)-{"REVIEW_PACKAGE_MANIFEST.json"})
    check("all_manifest_sizes_and_hashes",
          all(identity(z.read(r["path"]))==recorded_id(r) for r in manifest["files"]))
check("standalone_proof_exact_archived_copy",
      (ROOT/"upload/NATIVE_ACCESSIBLE_TRANSFER_01_PROOF.md").read_bytes()==(SUB/"NATIVE_ACCESSIBLE_TRANSFER_01_PROOF.md").read_bytes())
for name in ["NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_WORK_ORDER.md","NATIVE_ACCESSIBLE_TRANSFER_01_SOURCE_ASSESSMENT.md"]:
    check("exact_issued_"+name,(SUB/name).read_bytes()==(ISSUED/name).read_bytes())

sources=js(SUB/"SOURCE_IDENTITIES.json")
source_checks=[]
for item in sources["source_files"]:
    b=(SUB/item["path"]).read_bytes()
    known=(ISSUED/item["packet_path"]).read_bytes()
    labels=re.findall(r"\\label\{([^}]+)\}",b.decode("utf-8-sig"))
    result={"id":item["id"],"path":item["path"],**identity(b),
            "exact_issued_source":b==known,
            "recorded_identity_correct":identity(b)==recorded_id(item),
            "recorded_labels_correct":labels==item["available_tex_labels"]}
    result["pass"]=all(result[k] for k in ["exact_issued_source","recorded_identity_correct","recorded_labels_correct"])
    source_checks.append(result)
check("thirteen_focused_sources_exact",
      len(source_checks)==sources["focused_source_count"]==13 and all(r["pass"] for r in source_checks))
check("source_tree_has_only_thirteen_registered_files",
      {"sources/"+p for p in files_at(SUB/"sources")}=={r["path"] for r in sources["source_files"]})
check("four_context_records_unchanged",
      len(sources["context_files"])==4 and all((SUB/r["path"]).read_bytes()==(ISSUED/r["path"]).read_bytes() and
          identity((SUB/r["path"]).read_bytes())==recorded_id(r) for r in sources["context_files"]))
metadata_mapping={
 "P1_PUBLICATION_MANIFEST.json":"sources/RECIPROCAL_CHIRAL_EXCHANGE/v0.1/PUBLICATION_MANIFEST.json",
 "P2_PUBLICATION_MANIFEST.json":"sources/SAME_TRAJECTORY_NATIVE_CREDIT/v0.1/PUBLICATION_MANIFEST.json",
 "PACKET_MANIFEST.json":"PACKET_MANIFEST.json",
 "READ_ME_FOR_CODEX.md":"READ_ME_FOR_CODEX.md",
 "SOURCE_IDENTITIES.json":"SOURCE_IDENTITIES.json",
}
check("five_original_metadata_copies_exact",
      all((SUB/"input_metadata"/a).read_bytes()==(ISSUED/b).read_bytes() for a,b in metadata_mapping.items()))
check("registered_order_and_assessment_identities",
      all(identity((SUB/r["path"]).read_bytes())==recorded_id(r) for r in sources["governing_and_assessment_inputs"]))

input_verification=js(SUB/"INPUT_VERIFICATION.json")
input_archive=ROOT/"accessible_transfer_order/NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_PACKET.zip"
check("issued_packet_identity_matches_recorded_input",
      identity(input_archive.read_bytes())==input_verification["packet"]==recorded_id(sources["packet"]))
issued_registry=js(ISSUED/"SOURCE_IDENTITIES.json")
check("all_115_issued_source_identities_still_match",
      len(issued_registry["files"])==115 and
      all(identity((ISSUED/r["packet_path"]).read_bytes())==recorded_id(r) for r in issued_registry["files"]))
baseline=js(SUB/"INPUT_BASELINE.json")["files"]
preservation=js(SUB/"PRESERVATION_CHECK.json")
final_records={r["path"]:r for r in preservation["protected_files"]}
check("247_windows_baseline_final_records_match",
      len(baseline)==len(final_records)==len(preservation["protected_files"])==preservation["protected_files_checked"]==247 and
      set(baseline)==set(final_records) and
      all(final_records[p]["unchanged"] is True and recorded_id(final_records[p])==v for p,v in baseline.items()))
local_published={r["path"]:r for r in input_verification["local_published_files"]}
supplied={
 input_archive.name:input_archive,
 input_archive.with_suffix(".zip.sha256").name:input_archive.with_suffix(".zip.sha256"),
 "NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_WORK_ORDER.md":ISSUED/"NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_WORK_ORDER.md",
 "NATIVE_ACCESSIBLE_TRANSFER_01_SOURCE_ASSESSMENT.md":ISSUED/"NATIVE_ACCESSIBLE_TRANSFER_01_SOURCE_ASSESSMENT.md",
}
protected_checks=[]
for winpath, ident in baseline.items():
    parts=PureWindowsPath(winpath).parts
    if winpath in local_published:
        local=ISSUED/local_published[winpath]["packet_path"]
        kind="retained published source equivalent"
    elif "inputs" in parts:
        local=ISSUED.joinpath(*parts[parts.index("inputs")+1:])
        kind="issued packet member"
    else:
        local=supplied.get(PureWindowsPath(winpath).name)
        kind="original supplied item"
    good=local is not None and local.is_file() and identity(local.read_bytes())==ident
    protected_checks.append({"windows_recorded_path":winpath,"mapped_local":str(local) if local else None,"mapping_kind":kind,"identity_agrees":good})
check("247_recorded_input_identities_reconcile_with_known_local_inputs",
      len(protected_checks)==247 and all(r["identity_agrees"] for r in protected_checks))
check("focused_preservation_records_match_registered_sources",
      preservation["focused_source_copies_checked"]==13 and
      all(r["unchanged_exact_copy"] is True and identity((SUB/r["path"]).read_bytes())==recorded_id(r)
          for r in preservation["focused_source_copies"]))

proof=(SUB/"NATIVE_ACCESSIBLE_TRANSFER_01_PROOF.md").read_text()
ledger=(SUB/"NATIVE_ACCESSIBLE_TRANSFER_01_CLAIM_SOURCE_LEDGER.md").read_text()
tags=re.findall(r"\\tag\{(AT\d+)\}",proof)
expected_tags=[f"AT{i:02d}" for i in range(1,30)]
check("29_unique_ordered_proof_labels_and_ledger_coverage",
      tags==expected_tags and all(f"| {t} |" in ledger for t in tags))
docs=js(SUB/"DOCUMENT_CHECKS.json")
source_by_id={r["id"]:r for r in sources["source_files"]}
check("all_61_recorded_source_label_references_exist",
      len(docs["source_label_references_checked"])==61 and
      all(r["source"] in source_by_id and r["label"] in source_by_id[r["source"]]["available_tex_labels"]
          for r in docs["source_label_references_checked"]))
check("recorded_relative_document_links_resolve",
      all((SUB/Path(r["document"]).parent/r["target"]).is_file() for r in docs["relative_links"]))

recorded=js(SUB/"EXACT_ALGEBRA_RESULTS.json")
run=js(SUB/"EXACT_ALGEBRA_EXECUTION.json")
fresh=js(HERE/"INDEPENDENT_ALGEBRA_RESULTS.json")
fresh_run=js(HERE/"INDEPENDENT_ALGEBRA_EXECUTION.json")
checker_hash=identity((SUB/"exact_algebra_check.py").read_bytes())["sha256"]
check("submitted_checker_execution_bound_to_exact_bytes",
      recorded["script_sha256"]==run["checker_sha256"]==checker_hash and run["exit_code"]==0 and
      run["stdout_sha256"]==identity((SUB/"EXACT_ALGEBRA_RESULTS.json").read_bytes())["sha256"] and
      run["stderr_sha256"]==identity((SUB/"EXACT_ALGEBRA_STDERR.txt").read_bytes())["sha256"] and
      (SUB/"EXACT_ALGEBRA_STDERR.txt").read_bytes()==b"")
check("independent_replay_exact_18_results",
      fresh_run["exit_code"]==0 and fresh["script_sha256"]==checker_hash and
      fresh["checks"]==recorded["checks"] and fresh["grouped_checks_executed"]==fresh["passed"]==18 and
      fresh["failed"]==0 and (HERE/"INDEPENDENT_ALGEBRA_STDERR.txt").read_bytes()==b"")

result={
 "task":"NATIVE_ACCESSIBLE_TRANSFER_01","reviewed_utc":datetime.now(timezone.utc).isoformat(),
 "status":"PASS" if all(r["pass"] for r in checks) else "FAIL",
 "archive":{**archive_id,"members":44,"hashed_payloads":43},
 "proof":identity((SUB/"NATIVE_ACCESSIBLE_TRANSFER_01_PROOF.md").read_bytes()),
 "claim_source_ledger":identity((SUB/"NATIVE_ACCESSIBLE_TRANSFER_01_CLAIM_SOURCE_LEDGER.md").read_bytes()),
 "grouped_document_integrity_checks":len(checks),
 "checks":checks,"source_files":source_checks,"protected_input_record_correspondence":protected_checks,
 "source_and_record_counts":{"focused_sources":13,"context_copies":4,"historical_metadata_copies":5,
                            "original_source_inventory":115,"windows_protected_input_records":247,
                            "proof_claim_labels":29,"source_label_references":61},
 "scope":"Independent artifact and known-input byte checks plus exact checker replay. The supplied Windows final-preservation assertions were reconciled with their baseline and known local input bytes; the live Windows filesystem was not accessed. These integrity checks are not additional mathematical identities.",
}
(HERE/"INDEPENDENT_PACKAGE_CHECKS.json").write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n")
print(json.dumps({"status":result["status"],"groups":len(checks),"failed":[r["check"] for r in checks if not r["pass"]],
                  "archive":result["archive"],"proof":result["proof"],"claim_source_ledger":result["claim_source_ledger"],
                  "counts":result["source_and_record_counts"]},indent=2))
raise SystemExit(0 if result["status"]=="PASS" else 1)
