"""Build bounded investigation records and review archive; never touches inputs or Git."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

W=Path(__file__).resolve().parent
TASK="NATIVE_ACCESSIBLE_TRANSFER_01"
utc=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
ident=lambda p:{"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())}
save=lambda name,data:(W/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
results=json.loads((W/"EXACT_ALGEBRA_RESULTS.json").read_text(encoding="utf-8"))
execution=json.loads((W/"EXACT_ALGEBRA_EXECUTION.json").read_text(encoding="utf-8"))
assert results["status"]=="PASS" and results["grouped_checks_executed"]==results["passed"]==18
assert results["failed"]==0 and execution["exit_code"]==0
assert results["script_sha256"]==execution["checker_sha256"]==ident(W/"exact_algebra_check.py")["sha256"]
assert execution["stdout_sha256"]==ident(W/"EXACT_ALGEBRA_RESULTS.json")["sha256"]
assert (W/"EXACT_ALGEBRA_STDERR.txt").read_bytes()==b""

registry=json.loads((W/"inputs/SOURCE_IDENTITIES.json").read_text(encoding="utf-8"))
source_rows=[]
for path in sorted((W/"sources").rglob("*.tex")):
    rel=path.relative_to(W).as_posix()
    paper=("RECIPROCAL_CHIRAL_EXCHANGE" if rel.split("/")[1]=="P1"
           else "SAME_TRAJECTORY_NATIVE_CREDIT")
    packet_path=f"sources/{paper}/v0.1/manuscript/{path.name}"
    row=next(r for r in registry["files"] if r["packet_path"]==packet_path)
    assert ident(path)=={k:row[k] for k in ["bytes","sha256"]}
    assert path.read_bytes()==(W/"inputs"/packet_path).read_bytes()
    source_rows.append({
        "id":f"{rel.split('/')[1]}.{path.stem}","path":rel,**ident(path),
        "paper":paper,"edition":"v0.1","source_commit":row["source_commit"],
        "packet_path":packet_path,"repository_path":row["repository_path"],
        "immutable_url":f"https://github.com/pzychozen/trioctagon-physics/blob/{row['source_commit']}/{row['repository_path']}",
        "available_tex_labels":re.findall(r"\\label\{([^}]+)\}",path.read_text(encoding="utf-8")),
        "role":"Defining mathematical source" if path.stem not in {"interpretation","conclusion"}
               else "Published interpretation and continuity",
        "identity_basis":"Exact supplied published edition, verified against original registry and retained local publication. No new network retrieval."
    })
assert len(source_rows)==13
input_names=[TASK+"_CODEX_WORK_ORDER.md",TASK+"_SOURCE_ASSESSMENT.md"]
context_rows=[]
for path in sorted((W/"context").glob("*")):
    assert path.is_file() and path.read_bytes()==(W/"inputs/context"/path.name).read_bytes()
    context_rows.append({"path":path.relative_to(W).as_posix(),**ident(path),
                         "role":"Unchanged historical/current research context; status wording read with current work order."})
assert len(context_rows)==4
for name in input_names:
    assert (W/name).read_bytes()==(W/"inputs"/name).read_bytes()
save("SOURCE_IDENTITIES.json",{
    "task":TASK,"created_utc":utc(),"source_files":source_rows,
    "focused_source_count":13,"context_files":context_rows,
    "governing_and_assessment_inputs":[{"path":n,**ident(W/n),"role":"Governing author-approved order" if "WORK_ORDER" in n else "GPT source assessment and proposals, independently evaluated"} for n in input_names],
    "packet":{"path":str(Path("C:/Users/Notandi/Downloads")/(TASK+"_CODEX_PACKET.zip")),
              **json.loads((W/"INPUT_VERIFICATION.json").read_text())["packet"]},
    "original_registry":{"path":"input_metadata/SOURCE_IDENTITIES.json",**ident(W/"input_metadata/SOURCE_IDENTITIES.json"),"inventoried_source_files":115},
    "scope_note":"This current registry identifies 13 exact focused TeX copies and four context files. The full 115-file source editions remain in local inputs and their immutable publications. Original nested manifests retain their own original scopes."
})

# Focused protected-input preservation: supplied files, extracted packet, local editions.
baseline=json.loads((W/"INPUT_BASELINE.json").read_text(encoding="utf-8"))
preserved=[]
for name,expected in baseline["files"].items():
    p=Path(name)
    assert p.is_file(),f"Missing protected file: {name}"
    actual=ident(p)
    assert actual==expected,f"Protected input changed: {name}"
    preserved.append({"path":name,**actual,"unchanged":True})
assert len(preserved)==247
focused=[]
for row in source_rows:
    focused.append({"path":row["path"],"packet_path":row["packet_path"],
                    **ident(W/row["path"]),"unchanged_exact_copy":True})
save("PRESERVATION_CHECK.json",{
    "utc":utc(),"status":"PASS","baseline":"INPUT_BASELINE.json",
    "protected_files_checked":247,"protected_files":preserved,
    "focused_source_copies_checked":13,"focused_source_copies":focused,
    "context_copies_checked":4,"context_copies_unchanged":True,
    "order_and_assessment_copies_unchanged":True,
    "input_metadata_copies_unchanged":True,
    "git_operations":False,"source_edits":False,
    "scope":"Focused task inputs only; no unrelated research or repository audit."
})
meta_mapping={
    "PACKET_MANIFEST.json":"PACKET_MANIFEST.json",
    "SOURCE_IDENTITIES.json":"SOURCE_IDENTITIES.json",
    "READ_ME_FOR_CODEX.md":"READ_ME_FOR_CODEX.md",
    "P1_PUBLICATION_MANIFEST.json":"sources/RECIPROCAL_CHIRAL_EXCHANGE/v0.1/PUBLICATION_MANIFEST.json",
    "P2_PUBLICATION_MANIFEST.json":"sources/SAME_TRAJECTORY_NATIVE_CREDIT/v0.1/PUBLICATION_MANIFEST.json"
}
for name,original in meta_mapping.items():
    assert (W/"input_metadata"/name).read_bytes()==(W/"inputs"/original).read_bytes()

proof_name=TASK+"_PROOF.md";ledger_name=TASK+"_CLAIM_SOURCE_LEDGER.md"
proof=(W/proof_name).read_text(encoding="utf-8")
ledger=(W/ledger_name).read_text(encoding="utf-8")
labels=re.findall(r"\\tag\{(AT\d\d)\}",proof)
expected_labels=[f"AT{i:02d}" for i in range(1,30)]
assert labels==expected_labels
assert all(f"| {label} |" in ledger for label in expected_labels)
assert proof.count(r"\[")==proof.count(r"\]")==29
assert "**Verdict: Established.**" in proof
assert "Corrected or rejected proposed formulas | None." in ledger
linked=[]
for name in [proof_name,ledger_name]:
    text=(W/name).read_text(encoding="utf-8")
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)",text):
        if "://" not in target:
            assert (W/target).is_file(),(name,target)
            linked.append({"document":name,"target":target,"exists":True})
source_label_checks=[]
# Validate every source-specific equation/theorem reference in ledger rows.
lookup={r["id"]:r for r in source_rows}
for line in ledger.splitlines():
    if not re.match(r"\| AT\d\d \|",line):
        continue
    current=None
    for token in re.findall(r"P[12]\.[a-z]+|(?:eq|thm|prop|sec):[A-Za-z0-9]+",line):
        if token.startswith(("P1.","P2.")):
            assert token in lookup,token
            current=token
        elif current:
            assert token in lookup[current]["available_tex_labels"],(current,token)
            source_label_checks.append({"source":current,"label":token})
save("DOCUMENT_CHECKS.json",{
    "utc":utc(),"status":"PASS","proof_tags":labels,"ledger_covers_all_29_tags":True,
    "display_math_pairs":29,"relative_links":linked,
    "source_label_references_checked":source_label_checks,
    "checker_evidence_matches_current_script":True,
    "scientific_check_count":18,
    "not_mathematical_checks":"These are document, source-reference and integrity checks; none adds to the 18 algebra groups.",
    "visual_scope":"Markdown analytical investigation only. No new PDF/manuscript requested or created.",
    "scientific_review":"Written proof inspected independently against supplied defining equations; GPT review remains pending."
})
readme=f"""# {TASK} — review package

**Verdict: Established.** The proposed finite-coupling certificate holds with its constants and hypotheses unchanged. This is the completed bounded investigation for GPT review, not a manuscript or publication.

Read {proof_name} first, then {ledger_name}. The proof carries the strong infinite-dimensional error estimate, weighted receiver/carrier projections, positive denominators, receiver-product bound, chronology, finite bounds and asymptotics. No algebra checker is a substitute for those arguments.

The existing torment environment executed 18 grouped exact-algebra checks, all passing. The checker, captured JSON output, empty stderr and execution record are included. To rerun only the standalone mathematics checker from this directory in Command Prompt:

    call conda activate torment
    python -I -B exact_algebra_check.py

This prints a fresh report to standard output without modifying retained evidence. Requires SymPy (recorded version 1.14.0), already installed in the author's environment. No package installation is part of this order.

The sources directory contains 13 exact focused TeX files from the two published editions. It is a defining-source selection, not a new compilable manuscript. SOURCE_IDENTITIES.json identifies their immutable commits and bytes. The four context records are preserved unchanged, including their historical status wording. The current standalone order supersedes historical next-task wording.

INPUT_VERIFICATION.json and INPUT_BASELINE.json record the supplied packet and full 115-file source verification. PRESERVATION_CHECK.json rechecks all 247 protected files plus the focused copies. The original packet, its checksum, and both complete editions remain unchanged in their original/local input locations. They are not duplicated in this focused review ZIP.

The five files under input_metadata retain their original bytes and original scopes. In particular, their source inventories and publication manifests describe the complete original packet/editions, not the current focused ZIP. REVIEW_PACKAGE_MANIFEST.json is the exhaustive manifest of this package; it hashes every other member and excludes only itself.

The adjacent ZIP checksum and external PACKAGE_VERIFICATION.json describe the final archive. They are external to avoid archive self-reference. verify_review_package.py independently checks safe unique paths, CRCs, exhaustive manifest coverage, every member size/hash and the adjacent checksum. Run it with the ZIP path as its optional first argument. It reads the archive and prints its verification report.

No Git operation, publication, manuscript, trajectory integration, parameter scan, historical scientific-suite replay, package installation or successor investigation was performed. GPT's review of the new proof remains pending. Capacity outside this window/regime, intended toroidal correspondence and the separate projection-invariant lead remain deferred.
"""
(W/"README.md").write_text(readme,encoding="utf-8")
completion=f"""# {TASK} — completion record

**Date:** 4 November 2026. **Verdict:** Established.

The author authorized execution of the standalone work order supplied outside the packet. That order and its assessment match the packet copies exactly. The external order governed; no further confirmation was required.

The proposed finite-coupling certificate is proved without changing its constants, hypotheses or normalization. In the explicit sufficient regime, receiver concentration and subsequent net native recovery are at least 1-(q/(2-q))², with q≤1/5. The separate receiver-power estimate proves exact charging at tq and backflow at tb. The accepted native-credit theorem applies at the same tb. The maximum window stock has leading term 2 eta_N² beta_R |f0|²/kappa²; the endpoint stock is O(kappa^-4), while the use of the invariant ceiling tends to zero.

Actual validation: one execution of 18 grouped symbolic checks, 18 passed, zero failed; no numerical trajectory. The written proof supplies regularity, inequalities, positive denominators and continuity. Document checks are counted separately. Environment: cmd.exe with conda activate torment, Python 3.11.15, SymPy 1.14.0, no installation.

Both complete supplied editions, all 115 local published source files and the original supplied files remain byte-identical: 247 protected files verified, plus 13 focused source copies and four unchanged context copies. No source conflict or material discrepancy was found. No scientific correction was needed.

The review ZIP is built from the explicit payload allowlist and current self-excluded manifest. The final independent archive verification and SHA-256 are recorded outside it as PACKAGE_VERIFICATION.json and the adjacent .zip.sha256, avoiding circular hashes.

Limits: finite constant-coupling regime and shrinking prescribed window only; no exact maximizing-time or period claim, monotone recovery assertion, full-time capacity attainment, permanent retention, spatial circuit or physical validation. The capacity denominator is a positive upper ceiling, not a proved achievable maximum. The projection-invariant lead and subsequent research agenda remain deferred.

GPT review of this new investigation is pending. No manuscript, Git operation, publication, announcement or successor investigation was undertaken.
"""
(W/"COMPLETION_RECORD.md").write_text(completion,encoding="utf-8")

fixed=[
    "README.md",proof_name,ledger_name,*input_names,"SOURCE_IDENTITIES.json",
    "PRESERVATION_CHECK.json","COMPLETION_RECORD.md","INPUT_BASELINE.json",
    "INPUT_VERIFICATION.json","ENVIRONMENT.json","AGENTS_CHECK.json","DOCUMENT_CHECKS.json",
    "exact_algebra_check.py","run_checks.py","EXACT_ALGEBRA_RESULTS.json",
    "EXACT_ALGEBRA_STDERR.txt","EXACT_ALGEBRA_EXECUTION.json",
    "prepare_inputs.py","finalize_review.py","verify_review_package.py"
]
members=sorted(fixed+[r["path"] for r in source_rows]+[r["path"] for r in context_rows]
               +["input_metadata/"+n for n in meta_mapping])
assert len(members)==len(set(members))==len({n.casefold() for n in members})
assert all((W/n).is_file() for n in members)
save("REVIEW_PACKAGE_MANIFEST.json",{
    "task":TASK,"created_utc":utc(),"self_excluded":"REVIEW_PACKAGE_MANIFEST.json",
    "scope":"All current review-package members other than this manifest; original manifests in input_metadata keep their historical scopes.",
    "files":[{"path":n,**ident(W/n)} for n in members]
})
members=sorted(members+["REVIEW_PACKAGE_MANIFEST.json"])
archive=W/(TASK+"_REVIEW_PACKAGE.zip")
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in members:
        z.write(W/name,name)
(W/(archive.name+".sha256")).write_text(ident(archive)["sha256"]+"  "+archive.name+"\n",encoding="ascii")
print(json.dumps({"archive":str(archive),**ident(archive),"members":len(members),
                  "manifest_payloads":len(members)-1,"protected_files":len(preserved),
                  "status":"BUILT; independent archive verification follows"}))
