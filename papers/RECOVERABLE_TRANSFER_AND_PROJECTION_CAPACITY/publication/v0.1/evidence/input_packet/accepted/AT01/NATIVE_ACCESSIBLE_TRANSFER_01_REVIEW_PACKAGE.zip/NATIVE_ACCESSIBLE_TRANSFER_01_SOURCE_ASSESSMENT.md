# Source assessment — accessible transfer and receiver behavior

**Date:** 4 November 2026  
**Lead:** GPT, with independent analytical and scope reviews  
**Disposition:** Begin NATIVE_ACCESSIBLE_TRANSFER_01 using the attached bounded Codex order. The proposed new certificate remains subject to Codex's independent proof and GPT review.

## 1. The useful next question

The published same-trajectory theorem establishes that an initially empty carrier/receiver launch can first debit the native core and later credit it on the same unchanged solution. It does not quantify a recovered fraction, and its threshold does not separately establish exact receiver backflow.

The next useful question is:

> Over one specified early comparison window, how much stock actually leaves the core, how much of that stock is temporarily in the receiver, and what fraction of it is back in the core by the end?

This is a bounded entry into the agreed accessible-transfer and receiver-behavior agenda. It measures actual exchange before attempting maximum extraction over arbitrary times or optimizing the candidate.

**Recommendation:** extend the published strong-solution comparison estimate through one full comparison oscillation. Certify the resulting stock, receiver-share, endpoint-retention and net native-recovery bounds at finite constant coupling. Give receiver power its own product-error estimate.

## 2. Published basis and its explicit open questions

[P1] [A Reciprocal Chiral Exchange Extension of the Tri-Octagon Model, v0.1](https://github.com/pzychozen/trioctagon-physics/tree/273b1a6faaab19ea58748d00576439166eeef9ab/papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1) defines the exact equations and proves global exchange evolution, matched storage accounts, empty-launch activity and the Z2 invariant ceiling. Its manuscript/capacity.tex explicitly distinguishes that ceiling from attainable extraction.

[P2] [Same-Trajectory Native Credit in the Reciprocal Chiral Exchange Candidate, v0.1](https://github.com/pzychozen/trioctagon-physics/tree/28e8a85c8fe1e6321328d4d7285b2560d1f98aa9/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1) proves a finite-coupling native-credit witness. Its manuscript/meaning.tex distinguishes comparison receiver backflow from a proved exact receiver sign and states that a small transferred stock does not determine its recovered fraction.

The source roles are:

| Source | Reused result | New obligation |
|---|---|---|
| P1 candidate.tex, power.tex | Exact interconnection, two-port powers and conservation | Keep the system unchanged |
| P1 wellposed.tex | Global solution and strong H1 preparation regularity | Use this regularity correctly in the longer error window |
| P1 activity.tex | Nonzero accepted launch and initial supply/receiving | Establish explicit later receiver behavior |
| P1 capacity.tex | Conserved Z2 and net-debit ceiling | Compare actual finite-window transfer with an upper ceiling, without assuming attainability |
| P2 problem.tex, theorem.tex | Exact launch, constants and native-credit threshold | Preserve the quantifier order and original accepted result |
| P2 energy.tex | External estimate and native drift on every finite scaled interval | Apply them at the chosen longer fixed scaled horizon |
| P2 comparison.tex | Exact strong-curve error equation and finite residual estimate | Extend the proof from 3π/(2ω) to 2π/ω |
| P2 meaning.tex, units.tex | Interpretation, scale distinctions and bookkeeping dimensions | Define denominators and time window; check new constants' units |

The full published editions are copied unchanged into the packet. Their manifests verify. Fresh commit-pinned retrievals of P2 comparison.tex and P1 capacity.tex also match the supplied source bytes exactly; preparation_evidence records those checks. Earlier completed publication review supplies the broader artifact provenance.

## 3. Smallest useful new claim

Use the same nonzero launch Ω0=(1,e^(iφ),1), 0<φ<π/12, with initially empty carrier and receiver. Fix all other admissible parameters and then select a sufficiently large finite constant receiver coupling κ.

Set

\[
t_\pi=\frac{\pi}{\omega\kappa},\qquad
t_{\rm b}=\frac{3\pi}{2\omega\kappa},\qquad
t_{2\pi}=\frac{2\pi}{\omega\kappa}.
\]

Define the exact external stock

\[
E_{\rm out}(t)=H_C(t)+H_R(t)=H_N(0)-H_N(t).
\]

The primary quantities are

\[
\mathcal S_\kappa=\frac{H_R(t_\pi)}{E_{\rm out}(t_\pi)},\qquad
\mathcal R_\kappa=
\frac{H_N(t_{2\pi})-H_N(t_\pi)}
     {E_{\rm out}(t_\pi)}.
\]

The first is a temporary receiver share. The second is net recovery during the declared interval, measured against the stock actually outside the core at its start. Positivity of this denominator is part of the proof.

The proposed result is that both fractions approach one with an explicit finite-coupling error bound. At the same time, the maximum stock outside the core during this window is of order κ^-2, while the endpoint stock is bounded by a quantity of order κ^-4. Exact receiver backflow at the existing native-credit witness follows from its own finite bound; the same calculation provides explicit receiver charging at π/(2ωκ).

This would give a quantitative result about recovery and transient receiving. It would not imply substantial extraction relative to initial core storage.

## 4. Why this route is promising

The already published comparison has

\[
\widehat p^{(0)}(\tau)
=\frac{\sin(\omega\tau)}{\omega}\mathcal Bf_0,\qquad
\widehat r^{(0)}=0,\qquad
\widehat z^{(0)}(\tau)=f_0(1-\cos(\omega\tau)).
\]

Write \(\Lambda=\sqrt{\beta_R}|f_0|>0\) and \(\theta=\omega\tau\). Its scaled stores are

\[
\widehat H_C^{(0)}=\frac{\Lambda^2}{2}\sin^2\theta,\quad
\widehat H_R^{(0)}=\frac{\Lambda^2}{2}(1-\cos\theta)^2,\quad
\|V_0(\tau)\|_{CR}=2\Lambda|\sin(\theta/2)|.
\]

At the half-period landmark, the comparison carrier is empty and the receiver norm is 2Λ. At the full-period landmark, its entire external state is zero. These zeros make the stronger endpoint bounds possible.

For \(S=2\pi/\omega\), the existing residual argument suggests

\[
\sup_{0\le\tau\le S}\|V_\kappa(\tau)-V_0(\tau)\|_{CR}
\le\varepsilon_\kappa,
\]
\[
\varepsilon_\kappa=
\frac{4c\sqrt d\,|f_0|}{\omega^2\kappa}
+\frac{\sqrt m\,A S^3}{3\kappa^2}.
\]

The only propagation change from the printed witness proof is the absolute sine integral: 4/ω over this longer horizon. The drift bound already holds on every finite scaled interval. Strong regularity remains available, and no second derivative of a tent is needed.

Triangle inequalities then suggest

\[
E_{\rm out}(t_\pi)\ge
\frac{\eta_N^2}{2\kappa^2}(2\Lambda-\varepsilon_\kappa)^2,
\]
\[
H_C(t_\pi),\ E_{\rm out}(t_{2\pi})
\le\frac{\eta_N^2\varepsilon_\kappa^2}{2\kappa^2}.
\]

Consequently, for \(\varepsilon_\kappa<\Lambda\),

\[
\mathcal S_\kappa,\mathcal R_\kappa
\ge1-\left(\frac{\varepsilon_\kappa}
{2\Lambda-\varepsilon_\kappa}\right)^2,
\]
\[
H_N(t_{2\pi})-H_N(t_\pi)
\ge\frac{2\eta_N^2}{\kappa^2}
\Lambda(\Lambda-\varepsilon_\kappa)>0.
\]

This last expression would quantify net recovery over an explicit interval, adding to the preceding paper's continuity-defined credit interval.

The receiver product requires a separate calculation. At the backflow witness its comparison value is -D, and the proposed bound is

\[
|\widehat z^T\widehat y+D|
\le\omega(2\Lambda\varepsilon_\kappa+\varepsilon_\kappa^2),
\qquad D=\omega\Lambda^2.
\]

A fixed proof tolerance \(0<q\le1/5\) and a finite threshold ensuring \(\varepsilon_\kappa\le q\Lambda\) therefore give a strict receiver-power margin. The work order supplies an explicit candidate threshold and asks Codex to verify every allocation independently. No tolerance is being fitted to a desired physical percentage.

Two independent analytical reviews agree with the proposed normalization and route. This assessment is preparation for the independent investigation, not the formal closeout of the new result.

## 5. What this would say about accessible capacity

The preserved invariant ceiling for this launch is

\[
C_{\rm inv}=\frac{\alpha_N}{2}
\left(3-\sqrt{9-8\sin^2\phi}\right)>0.
\]

For the actual finite-window maximum

\[
M_\kappa=\max_{0\le t\le t_{2\pi}}E_{\rm out}(t),
\]

the proposed comparison gives matching lower and upper leading order:

\[
M_\kappa=
\frac{2\eta_N^2\beta_R|f_0|^2}{\kappa^2}
+O(\kappa^{-3}).
\]

Thus \(M_\kappa/C_{\rm inv}\to0\), while the specified recovered fraction tends to one. The leading coefficient depends on the native coupling, receiver storage scale and accepted launch drive; the published drive formula can make the gain/yaw/phase dependence explicit.

The interpretation is precise: this regime exchanges a small stock very reversibly during a fast early window. It does not establish optimal transfer, long-time inaccessible capacity, permanent receiver retention, or a preferred coupling.

The actual trajectory need not be periodic. The half-period landmark need not be its maximum, and net recovery across an interval does not imply negative native power at every instant of that interval. The physical window shrinks as 1/κ, so endpoint residual bounds are not long-time decay.

## 6. Preserved structural lead for a subsequent capacity assessment

The independent structural analysis also identified a new possible sharpening of the invariant ceiling. It is recorded here to preserve the lead; **it is outside the current Codex obligations and has not received a separate acceptance review.**

For the published fixed registration,

\[
e=R_z(-\delta_g)e_x=(\cos\delta_g,-\sin\delta_g,0)
\]

spans ker K. With \(w=K^Ty\), \(e\cdot w=0\). P1 power.tex gives

\[
\dot a=\mu w\times b,\qquad
\dot b=-\mu w\times a,\qquad
\mu=\eta_N/(2\alpha_N).
\]

The proposed additional invariant is

\[
\mathcal J_K=I-2|e\cdot\Omega|^2.
\]

Indeed direct differentiation suggests
\(\dot I=-4\mu w\cdot(a\times b)\) and
\(\frac d{dt}|e\cdot\Omega|^2=-2\mu w\cdot(a\times b)\).
If separately confirmed, this yields the floor

\[
I(t)\ge\max\{|Z_2(\Omega_0)|,\mathcal J_K(\Omega_0)\}.
\]

For the accepted launch, \(\mathcal J_K(\Omega_0)=1+2\sin(2\delta_g)\cos\phi\). At yaw δg=π/4 it exceeds |Z2| because the difference of their squares is \(4\cos\phi(1-\cos\phi)>0\). The resulting proposed sharper ceiling is \(\alpha_N(1-\cos\phi)\).

This is a concrete later route toward understanding structural restrictions on capacity. Even a sharper ceiling would still require a separate attainability analysis. The present first-window certificate can use the accepted Z2 ceiling without relying on this new lead.

## 7. Collaboration and the next decision

No new geometric assumption is needed for this mathematical step. The author's central outward–around–inward picture remains the intended correspondence problem, with stationary supports and a possible portion going elsewhere.

Temporary receiver storage in the present reversible, collocated candidate does not yet identify that physical destination or a toroidal route. Its fractions should not be equated with the author's tentative 15–20% suggestion.

After the bounded result is reviewed, assess what it teaches about useful accessible amounts and receiver behavior before native stepping/cadence, route correspondence and six-opening transport. A new receiver law, spatial location or direction-changing interpretation is a point for the author's geometric intuition. This calculation is not such a point.
