"""Verify and preserve investigation inputs. No Git, model imports, or scientific replay."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,shutil,sys,zipfile
import sympy
W=Path(__file__).resolve().parent;I=W/'inputs'
D=Path('C:/Users/Notandi/Downloads')
PACKET='NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_PACKET.zip'
ORDER='NATIVE_ACCESSIBLE_TRANSFER_01_CODEX_WORK_ORDER.md'
ASSESS='NATIVE_ACCESSIBLE_TRANSFER_01_SOURCE_ASSESSMENT.md'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ident=lambda p:{'bytes':p.stat().st_size,'sha256':sha(p)}
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert not I.exists()
assert (D/(PACKET+'.sha256')).read_text().split()[0]==sha(D/PACKET)=='979caf68b6d56f827c55a763e3898383803d883fe41b2d3fb727dc915ceba8a2'
with zipfile.ZipFile(D/PACKET) as z:
    names=z.namelist();assert len(names)==len(set(names))==len({n.casefold() for n in names})==128
    for n in names:
        p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n and not n.endswith('/')
        assert ((z.getinfo(n).external_attr>>16)&0o170000)!=0o120000
    assert z.testzip() is None
    manifest=json.loads(z.read('PACKET_MANIFEST.json'))
    assert manifest['self_excluded']=='PACKET_MANIFEST.json'
    entries={x['path']:x for x in manifest['files']}
    assert len(entries)==len(manifest['files'])==127 and set(names)==set(entries)|{'PACKET_MANIFEST.json'}
    for n,e in entries.items():
        b=z.read(n);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],n
    assert z.read(ORDER)==(D/ORDER).read_bytes(),'Standalone order differs; inspect author-provided external order before proceeding.'
    assert z.read(ASSESS)==(D/ASSESS).read_bytes()
    for n in names:
        p=I/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
registry=json.loads((I/'SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
assert len(registry['files'])==115
assert {r['packet_path'] for r in registry['files']}=={n for n in names if n.startswith('sources/')}
roots={
 'RECIPROCAL_CHIRAL_EXCHANGE':W.parent/'NATIVE_RECIPROCAL_EXCHANGE_PAPER_PUBLISH_01/publication_worktree/papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1',
 'SAME_TRAJECTORY_NATIVE_CREDIT':W.parent/'SAME_TRAJECTORY_NATIVE_CREDIT_PUBLISH_01/publication_worktree/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1'}
baseline={str(D/n):ident(D/n) for n in [PACKET,PACKET+'.sha256',ORDER,ASSESS]}
for p in I.rglob('*'):
    if p.is_file():baseline[str(p)]=ident(p)
local=[]
for r in registry['files']:
    p=I/r['packet_path'];assert ident(p)=={k:r[k] for k in ['bytes','sha256']}
    rel=r['packet_path'].split('/v0.1/',1)[1];q=roots[r['paper']]/rel
    assert q.is_file() and q.read_bytes()==p.read_bytes(),str(q)
    baseline[str(q)]=ident(q);local.append({'path':str(q),'packet_path':r['packet_path'],**ident(q)})
editionchecks=[]
for paper,root in roots.items():
    directory=I/'sources'/paper/'v0.1'
    pm=json.loads((directory/'PUBLICATION_MANIFEST.json').read_text(encoding='utf-8'))
    rows=pm.get('files',pm.get('members'))
    assert {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}=={e['path'] for e in rows}|{'PUBLICATION_MANIFEST.json'}
    for e in rows:assert ident(directory/e['path'])=={k:e[k] for k in ['bytes','sha256']}
    editionchecks.append({'paper':paper,'files':len(rows)+1,'manifest_payloads':len(rows),'exhaustive_and_hashes_match':True})
paths=[Path('C:/AGENTS.md'),Path('C:/TORMENT/AGENTS.md'),W.parent.parent/'AGENTS.md',W.parent/'AGENTS.md',W/'AGENTS.md']
assert not any(p.exists() for p in paths)
save(W/'AGENTS_CHECK.json',{'checked':[{'path':str(p),'exists':False} for p in paths],'workspace':str(W)})
save(W/'INPUT_BASELINE.json',{'utc':datetime.now(timezone.utc).isoformat(),'files':baseline,
 'scope':'Four supplied files, 128 extracted input files, and 115 exact local published-edition files; no Git or repository-wide scan.'})
save(W/'INPUT_VERIFICATION.json',{'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','packet':ident(D/PACKET),
 'packet_members':128,'manifest_payloads':127,'safe_unique_paths_crc_sizes_hashes':True,
 'standalone_order_and_assessment_match_packet':True,'standalone_order_governs':True,
 'source_registry_files':115,'publication_manifest_checks':editionchecks,'local_published_files':local})
save(W/'ENVIRONMENT.json',{'utc':datetime.now(timezone.utc).isoformat(),'python':sys.executable,'python_version':sys.version,
 'sympy_version':sympy.__version__,'environment':'conda activate torment via cmd.exe','installs':[],
 'git_operations':False,'network_requests':False,'historical_scientific_helpers_run':False})
focused={
 'RECIPROCAL_CHIRAL_EXCHANGE':['candidate','power','wellposed','activity','capacity','interpretation'],
 'SAME_TRAJECTORY_NATIVE_CREDIT':['problem','theorem','energy','comparison','meaning','units','conclusion']}
for paper,sections in focused.items():
    key='P1' if paper=='RECIPROCAL_CHIRAL_EXCHANGE' else 'P2'
    for section in sections:
        src=I/'sources'/paper/'v0.1/manuscript'/(section+'.tex')
        dst=W/'sources'/key/'manuscript'/src.name;dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,dst)
for name in [ORDER,ASSESS]:shutil.copyfile(D/name,W/name)
shutil.copytree(I/'context',W/'context')
meta=W/'input_metadata';meta.mkdir()
for name in ['PACKET_MANIFEST.json','SOURCE_IDENTITIES.json','READ_ME_FOR_CODEX.md']:shutil.copyfile(I/name,meta/name)
for key,paper in [('P1','RECIPROCAL_CHIRAL_EXCHANGE'),('P2','SAME_TRAJECTORY_NATIVE_CREDIT')]:
    shutil.copyfile(I/'sources'/paper/'v0.1/PUBLICATION_MANIFEST.json',meta/(key+'_PUBLICATION_MANIFEST.json'))
print(json.dumps({'packet_members':128,'verified_source_files':115,'preserved_files':len(baseline),'focused_source_copies':13,
 'sympy':sympy.__version__,'publication_manifests':editionchecks}))
