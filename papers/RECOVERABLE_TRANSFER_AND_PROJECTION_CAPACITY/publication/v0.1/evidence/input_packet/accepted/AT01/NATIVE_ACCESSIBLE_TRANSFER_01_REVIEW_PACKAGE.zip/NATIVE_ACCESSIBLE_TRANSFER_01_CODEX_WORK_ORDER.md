# NATIVE_ACCESSIBLE_TRANSFER_01 — Codex investigation order

**Author:** Hilmir Frímann Halldórsson (pzychozen)  
**Date:** 4 November 2026  
**Task:** Quantitative native transfer, temporary receiving, and recovery in the first comparison-oscillation window  
**Status:** Authorized investigation; proposed certificate requires independent verification  
**Working platform:** Windows 11, existing torment environment  
**Suggested workspace:** C:\TORMENT\TRIOCTAGON_new\research\NATIVE_ACCESSIBLE_TRANSFER_01\

## 1. Execute this bounded investigation

The author has requested the next investigation and its Codex work order. The reciprocal-exchange paper and the same-trajectory native-credit paper, including their publication closeouts, are complete.

**Investigate the unchanged published exchange system now. Determine whether the proposed finite-coupling certificate below rigorously quantifies temporary receiver concentration and later net recovery of the same initially supplied stock, while bounding how much of the invariant-limited capacity is accessed during the stated window.**

Work independently from the defining sources. Challenge the proposal, constants, normalizations, and hypotheses. Supply a proof or a precise scoped failure. This is one analytical investigation of one launch family and one fixed comparison-time window. Its result will receive GPT review before any manuscript decision.

Use the supplied packet and existing local sources; no additional author confirmation is needed for this analysis. The author should not have to recover old parameters or files.

## 2. Authoritative inputs and reading order

Read this order and NATIVE_ACCESSIBLE_TRANSFER_01_SOURCE_ASSESSMENT.md first. The packet contains exact copies of both complete published editions:

| Key | Published source | Immutable commit | Packet directory |
|---|---|---|---|
| P1 | A Reciprocal Chiral Exchange Extension of the Tri-Octagon Model, v0.1 | 273b1a6faaab19ea58748d00576439166eeef9ab | sources/RECIPROCAL_CHIRAL_EXCHANGE/v0.1/ |
| P2 | Same-Trajectory Native Credit in the Reciprocal Chiral Exchange Candidate, v0.1 | 28e8a85c8fe1e6321328d4d7285b2560d1f98aa9 | sources/SAME_TRAJECTORY_NATIVE_CREDIT/v0.1/ |

Use P1 manuscript/candidate.tex, power.tex, wellposed.tex, activity.tex, and capacity.tex for the definition, global solution, accounts, launch, and invariant. Use P2 manuscript/problem.tex, theorem.tex, energy.tex, comparison.tex, meaning.tex, and units.tex for the accepted finite-coupling comparison and its limits.

SOURCE_IDENTITIES.json inventories the 115 exact source files. The nested publication manifests retain their original scopes. The context directory contains the completed publication review, the original agenda and geometric/collaborative record, and the current RESEARCH_CONTINUITY.md.

The source papers' preparation-time wording and historical work orders remain historical evidence. This order governs the present investigation. Use the exact supplied editions even if a local main checkout predates their publication; repository synchronization is not part of this task.

## 3. Fixed problem

Retain the exact registration, finite disjoint H1 tents, positive speed c, port operator B and adjoint B*, and trial stores from P1/P2. Explicitly fix α_N>0, β_R>0 and η_N>0. With x=(a,b), Ω=a+ib, f(x)=K(a×b), J=Df, and κ=η_R, the exchange equations are

\[
\dot x=-\frac{\eta_N}{2\alpha_N}J(x)^Ty,\qquad
p_t+c(r_c)_s=\mathcal B\{\eta_N f(x)-\kappa z\},
\]
\[
(r_c)_t+cp_s=0,\qquad
\dot z=\frac{\kappa}{\beta_R}y,\qquad y=\mathcal B^*p.
\]

Prepare the accepted family

\[
\Omega_0=(1,e^{i\phi},1),\qquad 0<\phi<\pi/12,\qquad
p(0)=r_c(0)=z(0)=0.
\]

Fix every other admissible parameter before choosing κ. Every investigated solution has a finite, constant κ; variation of κ compares different solutions, not a switched coupling. No invariance of the launch family or its initial coherent phase sector is assumed.

The established accounts are

\[
H_N=\frac{\alpha_N}{2}|x|^2,\quad
H_C=\frac12\int(p^2+r_c^2)\,ds,\quad
H_R=\frac{\beta_R}{2}|z|^2,
\]
\[
P_{NC}=\eta_N f^Ty,\quad P_{CR}=\kappa z^Ty,\qquad
\dot H_N=-P_{NC},\quad
\dot H_C=P_{NC}-P_{CR},\quad
\dot H_R=P_{CR}.
\]

Reuse the established global solution and strong regularity for this empty preparation. All powers are the full signed two-port sums.

## 4. Quantities to establish

Use the published scaling τ=κt and Vκ=(p-hat,r-hat,z-hat), where (p,r_c,z)=(η_N/κ)Vκ. Set

\[
m=\frac2{3\epsilon_c},\quad d=\frac2{\epsilon_c^3},\quad
\omega=\sqrt{m/\beta_R},\quad S=\frac{2\pi}{\omega},
\]
\[
t_\pi=\frac{\pi}{\omega\kappa},\quad
t_{\rm b}=\frac{3\pi}{2\omega\kappa},\quad
t_{2\pi}=\frac{S}{\kappa}.
\]

Also use the explicit receiving landmark \(t_{\rm q}=\pi/(2\omega\kappa)\) for the same receiver-power estimate with positive comparison sign.

These are comparison landmarks, not asserted exact extrema or an exact period of the nonlinear PDE trajectory.

Define the net native debit and maximum debit during this window:

\[
E_{\rm out}(t)=H_C(t)+H_R(t)=H_N(0)-H_N(t),\qquad
M_\kappa=\max_{0\le t\le t_{2\pi}}E_{\rm out}(t).
\]

The maximum exists by continuity on this compact window; its location need not be determined.

After proving \(E_{\rm out}(t_\pi)>0\), define

\[
\mathcal S_\kappa=\frac{H_R(t_\pi)}{E_{\rm out}(t_\pi)},\qquad
\mathcal R_\kappa=
\frac{H_N(t_{2\pi})-H_N(t_\pi)}{E_{\rm out}(t_\pi)}
=1-\frac{E_{\rm out}(t_{2\pi})}{E_{\rm out}(t_\pi)}.
\]

The first is the receiver share of the stock outside the core at the prescribed intermediate time. The second is the subsequent net native recovery, normalized by that same stock. Neither denominator is gross cumulative positive work or initial core storage; no tagged cohort is implied.

Once \(H_R(t_\pi)>0\) is proved, the endpoint retention ratio \(H_R(t_{2\pi})/H_R(t_\pi)\) measures remaining receiver storage relative to its charge at that prescribed time.

For capacity comparison retain the established positive ceiling

\[
C_{\rm inv}=\frac{\alpha_N}{2}
 \left(3-\sqrt{9-8\sin^2\phi}\right)>0,\qquad
\mathcal A_\kappa=\frac{M_\kappa}{C_{\rm inv}}.
\]

This measures window-specific use of the published upper ceiling, not a fraction of a proved attainable maximum.

## 5. Proposed certificate to verify

The formulas in this section are GPT's proposed new certificate, not accepted results. Verify them independently and correct any defect explicitly.

### 5.1 Extend the comparison estimate to the declared window

Reuse P2's constants

\[
R=\sqrt3,\quad k=\|K\|,\quad
F_{\max}=\frac{kR^2}{2},\qquad
A=\frac{\eta_N^2 k^2R^2mF_{\max}}{4\alpha_N},
\]

and set

\[
\Lambda=\sqrt{\beta_R}|f_0|>0,\qquad
B_1=\frac{4c\sqrt d\,|f_0|}{\omega^2},\qquad
B_2=\frac{\sqrt m\,A S^3}{3},\qquad
\varepsilon_\kappa=\frac{B_1}{\kappa}+\frac{B_2}{\kappa^2}.
\]

The proposed extension is

\[
\sup_{0\le\tau\le S}
\|V_\kappa(\tau)-V_0(\tau)\|_{CR}
\le\varepsilon_\kappa,
\]

with the same published comparison

\[
\widehat p^{(0)}=\frac{\sin(\omega\tau)}{\omega}\mathcal Bf_0,
\qquad\widehat r^{(0)}=0,\qquad
\widehat z^{(0)}=f_0(1-\cos(\omega\tau)).
\]

Derive this on [0,S] from the exact strong-solution difference equation. The absolute sine integral over this window is 4/ω. P2's all-finite-τ external and native-drift estimates provide the other term. Explain why extending the time horizon is legitimate; do not merely replace T by S in a theorem without its argument.

Keep c>0 in the exact system. Use only the first weak tent derivative in L2. Establish the difference's strong regularity before applying its energy estimate, as P2 does. Neither differentiating the residual into H1 nor operator-norm convergence of an unbounded generator is justified.

### 5.2 Transfer the norm estimate to actual stocks

Check

\[
\|V_0(\tau)\|_{CR}
=2\Lambda|\sin(\omega\tau/2)|.
\]

For \(\varepsilon_\kappa<2\Lambda\), the target inequalities are

\[
\frac{\eta_N^2}{2\kappa^2}(2\Lambda-\varepsilon_\kappa)^2
\le E_{\rm out}(t_\pi)
\le M_\kappa
\le\frac{\eta_N^2}{2\kappa^2}(2\Lambda+\varepsilon_\kappa)^2,
\]
\[
E_{\rm out}(t_{2\pi})
\le\frac{\eta_N^2\varepsilon_\kappa^2}{2\kappa^2},
\qquad
H_C(t_\pi)
\le\frac{\eta_N^2\varepsilon_\kappa^2}{2\kappa^2}.
\]

The small carrier bound at \(t_\pi\) and the full endpoint bound exploit different zeros of the comparison. Prove both with the appropriate weighted projections; do not infer receiver concentration from total storage alone.

The receiver projection also gives the direct target \(H_R(t_\pi)\ge\eta_N^2(2\Lambda-\varepsilon_\kappa)^2/(2\kappa^2)>0\).

Then establish

\[
1-\left(\frac{\varepsilon_\kappa}
                   {2\Lambda-\varepsilon_\kappa}\right)^2
\le\mathcal S_\kappa\le1,\qquad
1-\left(\frac{\varepsilon_\kappa}
                   {2\Lambda-\varepsilon_\kappa}\right)^2
\le\mathcal R_\kappa\le1,
\]

in a regime making the lower bound positive. Use the conservation identity for the recovery numerator. No monotone native recovery on the whole interval is assumed.

Record the immediate receiver-retention and absolute recovery consequences:

\[
\frac{H_R(t_{2\pi})}{H_R(t_\pi)}
\le\left(\frac{\varepsilon_\kappa}{2\Lambda-\varepsilon_\kappa}\right)^2,
\qquad
H_N(t_{2\pi})-H_N(t_\pi)
\ge\frac{2\eta_N^2}{\kappa^2}\Lambda(\Lambda-\varepsilon_\kappa)>0
\]

when \(\varepsilon_\kappa<\Lambda\). These are corollaries of the same endpoint estimates.

### 5.3 Give receiver backflow its own finite bound

At \(\tau_{\rm b}=3\pi/(2\omega)\), the comparison has
\(\widehat z^{(0)}=f_0\), \(\widehat y^{(0)}=-(m/\omega)f_0\).
Let \(D=(m/\omega)|f_0|^2=\omega\Lambda^2\), exactly as in P2.

The candidate product estimate is

\[
\left|\widehat z^T\widehat y+D\right|
\le 2\sqrt m\,|f_0|\varepsilon_\kappa
       +\omega\varepsilon_\kappa^2
=\omega(2\Lambda\varepsilon_\kappa+\varepsilon_\kappa^2).
\]

Account explicitly for both vector errors and their product. Convert back using

\[
P_{CR}(t_{\rm b})=\frac{\eta_N^2}{\kappa}
 \widehat z(\tau_{\rm b})^T\widehat y(\tau_{\rm b}).
\]

The earlier native-credit threshold alone is not a receiver-backflow theorem.

At \(t_{\rm q}\), the comparison receiver product is \(+D\). The identical product-error bound should provide an explicit exact charging witness there. Derive it from uniform error control, without evaluating the inherited fixed-κ short-time expansion at a κ-dependent landmark.

### 5.4 One explicit sufficient regime and its meaning

For any fixed proof tolerance \(0<q\le1/5\), a proposed joint threshold is

\[
\kappa_{\rm cert}(q)=
\max\left\{\kappa_{\rm crit},1,\frac{2B_1}{q\Lambda},
                  \sqrt{\frac{2B_2}{q\Lambda}}\right\},
\]

where κcrit is the unchanged accepted native-credit threshold in P2. Verify that every finite κ above this threshold gives

\[
\varepsilon_\kappa\le q\Lambda,\qquad
\mathcal S_\kappa,\mathcal R_\kappa
\ge1-\left(\frac q{2-q}\right)^2>0,
\qquad
P_{CR}(t_{\rm b})\le-\frac{\eta_N^2D}{2\kappa}<0.
\]

The symmetric receiver bound is \(P_{CR}(t_{\rm q})\ge\eta_N^2D/(2\kappa)>0\).

Import the existing native-credit result at the same witness; no new proof of that accepted theorem is requested. Initial exact receiver charging comes from the accepted empty-launch activity result. Continuity of the separately established receiver-power sign supplies a later backflow interval on that same solution.

The tolerance q is an analytical accuracy choice. It is not a physical coefficient, a fitted fraction, or the author's tentative diverted share. Optimize no constants.

Finally derive the bounded consequences, if the certificate holds:

\[
M_\kappa=\frac{2\eta_N^2\beta_R|f_0|^2}{\kappa^2}
 +O(\kappa^{-3}),\qquad
E_{\rm out}(t_{2\pi})=O(\kappa^{-4}),
\]
\[
\mathcal S_\kappa,\mathcal R_\kappa\longrightarrow1,\qquad
1-\mathcal S_\kappa,\;1-\mathcal R_\kappa=O(\kappa^{-2}),\qquad
\mathcal A_\kappa\longrightarrow0.
\]

All other parameters are fixed in these limits. Supply explicit finite bounds first, including a positive normalization denominator. Explain the leading dependence on η_N, β_R, the launch drive, and κ. Reuse the published expression for |f0|² if helpful; a parameter scan is unnecessary.

## 6. Bounded scope and scientific interpretation

The useful new result is quantitative control of the actual solution: transferred stock, temporary receiving, net recovery fraction, and exact receiver backflow. The published oscillator alone and the already published O(κ^-2) stock bound do not establish this new certificate.

A large recovered fraction of a small transferred stock is compatible with little use of the invariant ceiling. The shrinking window is not a long-time relaxation result, permanent retention or disposal, an exact periodic trajectory, a whole carrier circuit, or the intended spatial toroidal return. Do not identify \(t_\pi\) as the exact stock maximum without a separate proof.

Keep this task exchange-only. Coupling optimization, full-time capacity attainability, an irreversible receiver, native F stepping/cadence, new spatial assignments and six-opening registration belong to later work. The separate projection-invariant lead recorded in the assessment is preserved for a subsequent capacity assessment and is not an additional obligation here.

Use analytic estimates and a small standalone exact-algebra checker for genuinely useful identities and constant allocations. Do not substitute a discretized trajectory, fitted percentages, a parameter search, or repeated old test suites for the proof. No package installation or changes to the native kernel are needed.

If a proposed bound fails, identify the first failing step and give the narrowest justified repair within this same model, launch and window. Record changed constants and hypotheses explicitly. If the result cannot be repaired within this scope, deliver the obstruction or conditional result; do not redesign the candidate to manufacture success.

## 7. Deliverables and verification

Write all new work in the separate investigation workspace. Preserve both published editions and the supplied packet unchanged. Read applicable local instructions, and use focused input hashes rather than a broad audit of unrelated research.

Deliver:

1. NATIVE_ACCESSIBLE_TRANSFER_01_PROOF.md — verdict; exact hypotheses and quantities; complete finite-coupling proof or scoped failure; initial/late chronology; absolute versus relative transfer; limits of the conclusion.
2. NATIVE_ACCESSIBLE_TRANSFER_01_CLAIM_SOURCE_LEDGER.md — distinguish inherited results, new proved deductions, GPT proposals corrected or rejected, and unresolved interpretation. Cite precise source sections/equation labels and source identities.
3. A standalone exact-algebra check script and its execution record — symbolic identities and inequality allocations only. Report checks actually executed; do not count document checks as new mathematical identities.
4. SOURCE_IDENTITIES.json, PRESERVATION_CHECK.json, and a concise completion record — defining input hashes, unchanged-input verification, environment, genuine limitations or unresolved issues.
5. NATIVE_ACCESSIBLE_TRANSFER_01_REVIEW_PACKAGE.zip and adjacent .zip.sha256 — proof, ledger, checks, records and focused defining source copies, with an exhaustive self-excluded manifest and safe-member/CRC/hash verification.

The written proof must carry the infinite-dimensional error estimate and normalized-fraction argument; passing algebra checks cannot certify those by themselves.

Use a clear final verdict: **Established**, **Established with specified corrections**, or **Not established within the bounded scope**. Return the review package for GPT. No manuscript, Git operation, publication, announcement, or successor task is authorized by this investigation order.

## 8. Research continuity and author involvement

This is the first quantitative step within accessible transfer and receiver behavior. Later steps remain accessible capacity beyond this window and parameter regime, native stepping/cadence, intended route correspondence, six-opening transport, linked gravity–magnetism, later outer geometry and justified SRG integration.

Carry forward the author's central starting/meeting region, opposed cones, outward spreading and curved around–inward return, stationary supports, and possible transfer elsewhere. Preserve distinctions between the carrier circle, intended tight toroid and enclosing spheres. The tentative 15–20%, possibly more, is intuition rather than a calibration target.

No new geometric premise is required for the present certificate. Request author intuition when a genuine spatial interpretation, new receiving law/location or direction-changing geometric assumption becomes necessary. Otherwise proceed from the supplied equations and report the concrete result.
