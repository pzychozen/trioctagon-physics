"""Read-only independent ZIP/checksum verifier. Prints JSON; raises on discrepancy."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib
import json
import sys
import zipfile

TASK="NATIVE_ACCESSIBLE_TRANSFER_01"
archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/(TASK+"_REVIEW_PACKAGE.zip")
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive.with_suffix(".zip.sha256").read_text(encoding="ascii").split()[0]==digest
checked=[]
with zipfile.ZipFile(archive) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==len({n.casefold() for n in names})
    for name in names:
        p=PurePosixPath(name)
        assert name and not p.is_absolute() and ".." not in p.parts
        assert "\\" not in name and ":" not in name and not name.endswith("/")
        assert str(p)==name and not any(part in {"",".",".."} for part in p.parts)
        assert ((z.getinfo(name).external_attr>>16)&0o170000)!=0o120000
    assert z.testzip() is None
    manifest_name="REVIEW_PACKAGE_MANIFEST.json"
    manifest=json.loads(z.read(manifest_name))
    assert manifest["self_excluded"]==manifest_name
    entries={r["path"]:r for r in manifest["files"]}
    assert len(entries)==len(manifest["files"])
    assert set(entries)|{manifest_name}==set(names) and manifest_name not in entries
    for name,row in entries.items():
        data=z.read(name)
        actual={"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
        assert actual=={k:row[k] for k in ["bytes","sha256"]},name
        checked.append({"path":name,**actual,"manifest_match":True})
    sources=json.loads(z.read("SOURCE_IDENTITIES.json"))
    assert len(sources["source_files"])==13
    for row in sources["source_files"]:
        assert row["sha256"]==entries[row["path"]]["sha256"]
    results=json.loads(z.read("EXACT_ALGEBRA_RESULTS.json"))
    execution=json.loads(z.read("EXACT_ALGEBRA_EXECUTION.json"))
    assert results["status"]=="PASS" and results["passed"]==results["grouped_checks_executed"]==18
    assert results["failed"]==0 and execution["exit_code"]==0
    assert results["script_sha256"]==execution["checker_sha256"]==entries["exact_algebra_check.py"]["sha256"]
    assert execution["stdout_sha256"]==entries["EXACT_ALGEBRA_RESULTS.json"]["sha256"]
    assert z.read("EXACT_ALGEBRA_STDERR.txt")==b""
    proof=z.read(TASK+"_PROOF.md").decode("utf-8")
    assert "**Verdict: Established.**" in proof
print(json.dumps({
    "utc":datetime.now(timezone.utc).isoformat(),"status":"PASS","archive":str(archive.resolve()),
    "bytes":archive.stat().st_size,"sha256":digest,"members":len(names),
    "manifest_payloads":len(checked),"safe_unique_paths":True,"crc_pass":True,
    "exhaustive_manifest":True,"all_sizes_and_sha256_match":True,
    "adjacent_checksum_matches":True,"focused_source_identities_match":True,
    "executed_checker_evidence_consistent":True,"payloads":checked,
    "scope":"Archive integrity and evidence consistency, not additional mathematical identities or GPT acceptance."
},indent=2,ensure_ascii=False))
