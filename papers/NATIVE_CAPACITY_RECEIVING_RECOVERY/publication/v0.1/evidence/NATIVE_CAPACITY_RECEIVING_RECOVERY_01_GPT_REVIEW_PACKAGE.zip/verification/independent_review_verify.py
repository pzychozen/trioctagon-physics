"""Read-only independent artifact/source audit of RR01.

This verifier does not execute submitted scientific, packaging, or preparatory
code. The inspected exact-check script is replayed separately in an isolated
copy, and its output is compared here. Reference archives remain in /mnt/data;
they are not recursively duplicated in the reviewer package.
"""
from pathlib import Path, PurePosixPath, PureWindowsPath
import hashlib, json, re, zipfile, sys
from datetime import datetime, timezone

BASE = Path('/mnt/data')
ROOT = BASE / 'rr01_gpt_review'
SUB = ROOT / 'submission'
OUT = ROOT / 'verification'
OUT.mkdir(parents=True, exist_ok=True)
TASK = 'NATIVE_CAPACITY_RECEIVING_RECOVERY_01'
REPORT = {'review_date': '2026-11-05', 'executed_utc': datetime.now(timezone.utc).isoformat(),
          'review_type': 'independent supplied-byte and source audit; no remote access',
          'checks': {}}

def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def fileid(path):
    return ident(Path(path).read_bytes())

def loads(data):
    return json.loads(data.decode('utf-8-sig'))

def readjson(path):
    return loads(Path(path).read_bytes())

def matches(data, rec):
    got = ident(data)
    assert got == {'bytes': rec['bytes'], 'sha256': rec['sha256']}, (got, rec)
    return got

def open_checked(path, sidecar=None):
    p=Path(path); data=p.read_bytes()
    if sidecar:
        text=Path(sidecar).read_text(encoding='utf-8-sig').strip()
        assert text.split()[0] == hashlib.sha256(data).hexdigest(), p
    z=zipfile.ZipFile(p)
    names=z.namelist()
    assert len(names)==len(set(names)), 'duplicate ZIP name'
    for info in z.infolist():
        name=info.filename; pos=PurePosixPath(name)
        assert not pos.is_absolute() and '..' not in pos.parts and '\\' not in name
        assert not re.match(r'^[A-Za-z]:',name)
        assert ((info.external_attr >> 16) & 0o170000) != 0o120000
        assert not info.is_dir(), 'This compact archive should contain files only'
    assert z.testzip() is None
    return z

def verify_manifest(z, manifest_name, prefix=''):
    obj=loads(z.read(prefix+manifest_name)); records=obj['files']
    members={n[len(prefix):] for n in z.namelist() if n.startswith(prefix)}
    rows={r['path']:r for r in records}
    assert len(rows)==len(records)
    assert members==set(rows)|{manifest_name}, (manifest_name,members^set(rows))
    for name,rec in rows.items(): matches(z.read(prefix+name),rec)
    exclusion=obj.get('self_excluded',obj.get('excluded'))
    assert exclusion==manifest_name or exclusion==[manifest_name]
    return {'members':len(members),'manifest_payloads':len(rows),
            'exact_coverage':True,'sizes_sha256':True,'self_exclusion':True}

archive=BASE/(TASK+'_REVIEW_PACKAGE.zip')
z=open_checked(archive, str(archive)+'.sha256')
REPORT['checks']['submitted_archive']={**fileid(archive),'safe_unique_members':len(z.namelist()),
                                     'crc':True,**verify_manifest(z,'PACKAGE_MANIFEST.json')}
for name in z.namelist():
    assert (SUB/name).read_bytes()==z.read(name), name
REPORT['checks']['extracted_submission_matches_archive']=True
REPORT['checks']['carried_input_manifest']=verify_manifest(z,'PACKET_MANIFEST.json','inputs/')

standalone={TASK+'_PROOF.md':TASK+'_PROOF.md', TASK+'_CLAIM_SOURCE_LEDGER.md':TASK+'_CLAIM_SOURCE_LEDGER.md',
            'COMPLETION_REPORT(1).md':'COMPLETION_REPORT.md'}
REPORT['checks']['standalone_deliverables']={}
for local,member in standalone.items():
    data=(BASE/local).read_bytes(); assert data==z.read(member)
    REPORT['checks']['standalone_deliverables'][local]=ident(data)

issued_path=BASE/(TASK+'_CODEX_PACKET.zip')
issued=open_checked(issued_path,str(issued_path)+'.sha256')
REPORT['checks']['issued_packet']={**fileid(issued_path),**verify_manifest(issued,'PACKET_MANIFEST.json'), 'crc':True}
assert {'inputs/'+n for n in issued.namelist()}=={n for n in z.namelist() if n.startswith('inputs/')}
for n in issued.namelist(): assert issued.read(n)==z.read('inputs/'+n),n
REPORT['checks']['all_issued_members_preserved']=len(issued.namelist())
for local,member in [(TASK+'_CODEX_WORK_ORDER.md',TASK+'_CODEX_WORK_ORDER.md'),
                     (TASK+'_SOURCE_ASSESSMENT.md','SOURCE_ASSESSMENT.md')]:
    assert (BASE/local).read_bytes()==issued.read(member)==z.read('inputs/'+member)
REPORT['checks']['separate_order_and_assessment_match']=True

priorpath=BASE/'NATIVE_FINITE_CAPACITY_ACCESS_FIX_PUBLISH_01_CLOSEOUT.zip'
prior=open_checked(priorpath,str(priorpath)+'.sha256')
REPORT['checks']['prior_closeout_archive']={**fileid(priorpath),'crc':True,
                                         **verify_manifest(prior,'CLOSEOUT_MANIFEST.json')}
registry=loads(z.read('inputs/provenance/SELECTED_SOURCE_IDENTITIES.json'))
source_receipt=loads(z.read('SOURCE_IDENTITIES.json'))
assert fileid(priorpath)['sha256']==registry['source_archive_sha256']
assert source_receipt['source_archive']==fileid(priorpath)
rows=registry['source_records']; assert len(rows)==64
by_path={r['packet_path']:r for r in rows}
assert len(by_path)==64
source_actual={r['packet_path']:r for r in source_receipt['records']}
assert set(source_actual)==set(by_path)
manifest=loads(z.read('inputs/provenance/P4_PUBLICATION_MANIFEST.json'))
manifest_rows={r['path']:r for r in manifest['files']}
remote=loads(z.read('inputs/provenance/P4_REMOTE_BYTE_COMPARISON.json'))
remote_rows={r['path']:r for r in remote['files']}
manifest_n=remote_n=prior_n=separate_n=0
bindings=[]
edition='papers/NATIVE_FINITE_CAPACITY_ACCESS/publication/v0.1/'
for r in rows:
    data=z.read('inputs/'+r['packet_path']); got=matches(data,r)
    assert source_actual[r['packet_path']]['actual']==got
    for key,value in r.items(): assert source_actual[r['packet_path']][key]==value
    method=''
    if 'extracted_archive_member' in r:
        assert data==prior.read(r['extracted_archive_member'])
        method='separately mounted prior publication closeout'; prior_n+=1
        path=r['carried_repository_path']
        rr=remote_rows[path]
        assert rr['matches'] and rr['http_status']==200
        assert {'bytes':rr['remote_bytes'],'sha256':rr['remote_sha256']}==got
        assert {'bytes':rr['committed_blob_bytes'],'sha256':rr['committed_blob_sha256']}==got
        remote_n+=1
        rel=path.removeprefix(edition)
        if rel!='PUBLICATION_MANIFEST.json':
            assert matches(data,manifest_rows[rel])==got;manifest_n+=1
    else:
        ref=BASE/r['source_attachment']; assert data==ref.read_bytes()
        method='separately mounted conversation attachment: '+ref.name;separate_n+=1
    bindings.append({'packet_path':r['packet_path'],**got,'reference':method,'match':True})
assert (prior_n,separate_n,remote_n,manifest_n)==(61,3,61,60)
REPORT['checks']['sources']={'selected_entries':64,'actual_supplied_hashes':64,
    'prior_archive_byte_matches':prior_n,'separate_attachment_byte_matches':separate_n,
    'retained_remote_records_reconciled':remote_n,'retained_publication_manifest_entries':manifest_n,
    'fresh_remote_downloads':0}
(OUT/'SOURCE_COMPARISONS.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

baseline=loads(z.read('INPUT_BASELINE.json')); preservation=loads(z.read('INPUT_PRESERVATION.json'))
matches(z.read('INPUT_BASELINE.json'),preservation['baseline'])
assert len(baseline['files'])==len(preservation['files'])==82
assert {r['path'] for r in preservation['files']}==set(baseline['files'])
preserved=[]
for r in preservation['files']:
    assert r['before']==r['after']==baseline['files'][r['path']]
    key=r['path']; norm=key.replace('\\','/')
    marker='/NATIVE_CAPACITY_RECEIVING_RECOVERY_01/inputs/'
    if marker in norm:
        relative=norm.split(marker,1)[1]
        data=z.read('inputs/'+relative);origin='supplied input member'
        assert data==issued.read(relative)
    else:
        local=BASE/PureWindowsPath(key).name
        assert local.exists(),local
        data=local.read_bytes();origin='separately mounted original'
    actual=matches(data,r['before'])
    preserved.append({'recorded_windows_path':key,'reference':origin,**actual,'matches_before_after':True})
REPORT['checks']['preservation']={'before_after_records':82,'actual_bytes_matched':82,
    'separately_mounted_original_inputs':5,'issued_members_matched':77,
    'live_windows_filesystem_inspected':False}
(OUT/'PRESERVATION_RECONCILIATION.json').write_text(json.dumps(preserved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

cw=loads(z.read('CLAIM_CROSSWALK.json')); doc=loads(z.read('DOCUMENT_CHECKS.json'))
for obj in [cw,doc]:
    for name,rec in obj['bindings'].items():matches(z.read(name),rec)
proof=z.read(TASK+'_PROOF.md').decode('utf-8-sig')
ledger=z.read(TASK+'_CLAIM_SOURCE_LEDGER.md').decode('utf-8-sig')
assessment=z.read('inputs/SOURCE_ASSESSMENT.md').decode('utf-8-sig')
tags=re.findall(r'\\tag\{(RR\d+)\}',proof)
expected_rr=[f'RR{i:02}' for i in range(1,37)]
assert tags==expected_rr and cw['proof_displayed_locators']==expected_rr
pr_rows=re.findall(r'^\| (PR\d{2}) \|',ledger,re.M)
assert pr_rows==[f'PR{i:02}' for i in range(1,24)]
assert re.findall(r'\\tag\{(PR\d+)\}',assessment)==pr_rows
assert [r['proposal'] for r in cw['proposal_groups']]==pr_rows
source_groups={r['id']:r for r in cw['inherited_groups']}
assert list(source_groups)==[f'S{i:02}' for i in range(1,12)]
label_n=printed_n=0
for group in source_groups.values():
    src=z.read('inputs/'+group['path']);matches(src,group['identity'])
    text=src.decode('utf-8-sig')
    for label in group['labels']:
        assert '\\label{'+label['label']+'}' in text
        label_n+=1
        if 'printed_record' in label:
            paper=group['path'].split('/')[1]
            labels=loads(z.read(f'inputs/sources/{paper}/verification/LABELS.json'))
            found=labels.get('labels',labels)[label['label']]
            assert found==label['printed_record'],(label,found)
            printed_n+=1
assert label_n==41
mapped_checks=set()
for r in cw['proposal_groups']:
    assert set(r['proof_locators'])<=set(expected_rr)
    assert set(r['inherited_source_groups'])<=set(source_groups)
    mapped_checks.update(r['exact_check_groups'])
assert mapped_checks=={f'EC{i:02}' for i in range(1,15)}
REPORT['checks']['crosswalk']={'proposal_rows':23,'displayed_groups':36,'source_groups':11,
 'source_labels':label_n,'printed_source_label_records':printed_n,
 'written_obligations':len(cw['written_analytical_obligations']),
 'covered_check_groups':14,'proof_ledger_script_result_bindings':True}

original=loads(z.read('EXACT_ALGEBRA_RESULTS.json'))
replayed=readjson(ROOT/'replay/EXACT_ALGEBRA_RESULTS.json')
execution=loads(z.read('EXACT_CHECK_EXECUTION.json'))
replay_exec=readjson(ROOT/'replay/EXACT_CHECK_EXECUTION.json')
script=z.read('exact_checks.py');script_sha=ident(script)['sha256']
assert (ROOT/'replay/exact_checks.py').read_bytes()==script
assert original['script_sha256']==replayed['script_sha256']==execution['script_sha256']==script_sha
assert original['status']==replayed['status']=='PASS'
assert original['groups']==replayed['groups']
assert len(original['groups'])==14 and all(g['status']=='PASS' for g in original['groups'])
assert execution['results_sha256']==ident(z.read('EXACT_ALGEBRA_RESULTS.json'))['sha256']
assert replay_exec['results_sha256']==fileid(ROOT/'replay/EXACT_ALGEBRA_RESULTS.json')['sha256']
REPORT['checks']['exact_replay']={'status':'PASS','same_distinct_groups':14,
 'group_payloads_identical':True,'script_sha256':script_sha,
 'original_python':execution['python_version'],'review_python':replay_exec['python_version'],
 'original_sympy':execution['sympy_version'],'review_sympy':replay_exec['sympy_version'],
 'isolated':replay_exec['isolated_mode'],'no_bytecode':replay_exec['dont_write_bytecode'],
 'new_independent_scientific_groups_claimed':0}

# Every submission byte, including retained prep code and evidence, remains original.
for name in z.namelist():assert (SUB/name).read_bytes()==z.read(name)
REPORT['checks']['post_review_submission_unchanged']=True
REPORT['status']='PASS'
REPORT['limits']=[
 'This script verifies artifact identity and recorded provenance, not analytical truth.',
 'Mathematical review of regularity, scalar majorant, quantifiers, strict inequalities and interpretation is written separately.',
 'No live Windows filesystem, remote GitHub reads/downloads, Git operations, PDF build/render, parameter scans or numerical trajectories.',
 'The fourteen exact groups are a replay of the returned script, not fourteen additional independent discoveries.',
 'The prior publication archive is used read-only as a reference; no archived workflow/packaging/preparatory code is run.']
(OUT/'REVIEW_VERIFICATION.json').write_text(json.dumps(REPORT,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(REPORT,ensure_ascii=False,indent=2))
