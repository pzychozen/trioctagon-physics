"""Verify this extracted reviewer package using only the standard library."""
from pathlib import Path
import argparse,hashlib,json

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("root",type=Path,nargs="?",default=Path(__file__).resolve().parent)
    args=ap.parse_args();root=args.root.resolve()
    manifest=root/"REVIEW_MANIFEST.json"
    obj=json.loads(manifest.read_text(encoding="utf-8"))
    expected={r["path"]:r for r in obj["files"]}
    if len(expected)!=len(obj["files"]):raise ValueError("Duplicate manifest path")
    actual={str(p.relative_to(root)).replace("\\","/") for p in root.rglob("*") if p.is_file()}
    if actual!=set(expected)|{"REVIEW_MANIFEST.json"}:raise ValueError("Member-set mismatch")
    for name,r in expected.items():
        p=(root/name).resolve()
        if not p.is_relative_to(root):raise ValueError("Unsafe path")
        data=p.read_bytes()
        if len(data)!=r["bytes"] or hashlib.sha256(data).hexdigest()!=r["sha256"]:
            raise ValueError("Payload identity mismatch: "+name)
    print(json.dumps({"status":"PASS","members":len(actual),"payloads":len(expected)}))
if __name__=="__main__":main()
