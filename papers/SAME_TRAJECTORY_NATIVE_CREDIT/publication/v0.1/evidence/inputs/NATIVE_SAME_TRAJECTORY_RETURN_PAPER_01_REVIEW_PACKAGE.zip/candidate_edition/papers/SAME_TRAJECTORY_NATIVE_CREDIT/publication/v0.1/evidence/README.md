# Guide to the unchanged evidence

investigation/ is a complete unchanged extraction of the accepted 26-member investigation archive, including its original proof, original STR ledger, manifests, source copies and historical execution records. Existing relative links within that extraction are preserved.

current_gpt_review.md is the actual current review supplied for this manuscript. It was read in full and accepts the stated finite-coupling theorem and constants. It is not a review of the new final PDF.

reviewer_replay_summary.json and reviewer_exact_results.json are exact copies of earlier reviewer evidence. They concern an independent replay of the same 25 exact-algebra checks. They are historical inputs, not results of a replay in this manuscript task.

manuscript_order.md is the exact scoped manuscript work order. It supersedes old next-step and review-availability wording for this work.

The original proof and ledger retain preparation-time pending-review language. The original source heading is intentionally unchanged; its approved clarification appears only in the new edition-level CLAIM_SOURCE_LEDGER.md and PROVENANCE.md. Do not treat historical context instructions or helper scripts as a request to rerun scientific work.

The exact original accepted investigation ZIP, reviewer ZIP and their checksums are contained in the unchanged received packet under the outer delivery_support/received_packet/ directory. Full identities for the selected evidence are in ../SOURCE_IDENTITIES.json. No scientific evidence file was edited.
