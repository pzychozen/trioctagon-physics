# External review support

The candidate edition is the prospective paper payload. This separate directory contains review renders and production records, not future publication requirements.

- renders/: all ten final full-page PNGs at 125 dpi, each hashed by the candidate visual-inspection record.
- build_final/: final compiler transcript, TeX log, auxiliary labels and raw receipt. No fonts, caches or large build intermediates.
- build_initial_failure/: diagnostic for the resolved first-build font issue.
- received_packet/: the exact supplied input packet and its checksum. That packet preserves the original investigation ZIP/checksum and current reviewer ZIP/checksum.
- records/: input/archive checks, environment versions, focused baseline/preservation, final extracted PDF text and execution record.
- document_tools/: the actual manuscript preparation, checking and packaging scripts. They use local production paths and are audit records, not the portable build entry point. In particular, do not rerun extraction/preparation over an existing workspace.

To rebuild the paper, use the candidate edition's BUILD.md and manuscript/build.py. None of the preserved scientific evidence scripts were executed for this manuscript.
