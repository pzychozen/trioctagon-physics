"""Document inspection only. Run with the bundled interpreter containing pypdf."""
from pathlib import Path
from datetime import datetime, timezone
import collections, hashlib, json, re, sys, unicodedata
import pypdf
W=Path(__file__).resolve().parent
E=W/'candidate_edition/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1'
B=W/'builds/build_02'
V=E/'verification';V.mkdir(exist_ok=True)
pdf=E/'SAME_TRAJECTORY_NATIVE_CREDIT_v0.1.pdf'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
reader=pypdf.PdfReader(pdf,strict=True)
title='Same-Trajectory Native Credit in the Reciprocal Chiral Exchange Candidate'
author='Hilmir Frímann Halldórsson'
assert reader.metadata.title==title,reader.metadata.title
assert reader.metadata.author==author,ascii(reader.metadata.author)
assert 'draft for manuscript review' in reader.metadata.subject
assert '3 November 2026' in reader.metadata.subject
assert len(reader.pages)==10
page_records=[];font_records={};links=[];texts=[]
for n,p in enumerate(reader.pages,1):
    text=unicodedata.normalize('NFKC',p.extract_text())
    texts.append(text)
    assert '\ufffd' not in text and '??' not in text,(n,'text glyph/reference')
    assert len(text)>100
    if n>1:
        assert 'Same-trajectory native credit' in text and 'v0.1 draft' in text,(n,'header')
        assert text.strip().endswith(str(n)),(n,'page number')
    page_records.append({'page':n,'text_characters':len(text),'size_points':[float(x) for x in p.mediabox[2:]],'header_footer_checked':n>1})
    for ref in p['/Resources']['/Font'].values():
        font=ref.get_object()
        desc=font.get('/FontDescriptor')
        if not desc and '/DescendantFonts' in font:
            desc=font['/DescendantFonts'][0].get_object().get('/FontDescriptor')
        assert desc,dict(font)
        desc=desc.get_object()
        streamkey=next((x for x in ['/FontFile','/FontFile2','/FontFile3'] if x in desc),None)
        assert streamkey,dict(font)
        data=desc[streamkey].get_data()
        name=str(font['/BaseFont'])
        font_records[name]={'base_font':name,'subtype':str(font['/Subtype']),'embedded':True,
             'embedding_key':streamkey,'embedded_bytes':len(data),'embedded_sha256':hashlib.sha256(data).hexdigest()}
    for ref in p.get('/Annots',[]):
        a=ref.get_object()
        if a.get('/Subtype')!='/Link':continue
        action=a.get('/A',{});dest=a.get('/Dest')
        if action:
            action=action.get_object()
            if action.get('/S')=='/URI':
                uri=str(action['/URI']);kind='external' if uri.startswith('https://') else 'relative_evidence'
                if kind=='relative_evidence':assert (E/uri).is_file(),uri
                links.append({'page':n,'kind':kind,'target':uri,'local_exists':kind=='relative_evidence'})
            elif action.get('/S')=='/GoTo':
                dest=action['/D']
            else:raise AssertionError(('unexpected link',action))
        if dest:
            if isinstance(dest,str):assert dest in reader.named_destinations,str(dest)
            links.append({'page':n,'kind':'internal','target':str(dest)})
outlines=[]
def inspect_outline(items):
    for item in items:
        if isinstance(item,list):inspect_outline(item)
        else:
            n=reader.get_destination_page_number(item)+1
            assert 1<=n<=len(reader.pages)
            outlines.append({'title':item.title,'page':n})
inspect_outline(reader.outline)
assert len(outlines)>=8
sources=sorted((E/'manuscript').glob('*.tex'))
combined='\n'.join(p.read_text(encoding='utf-8') for p in sources)
labels=re.findall(r'\\label\{([^}]+)\}',combined)
assert len(labels)==len(set(labels))
refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',combined)
assert set(refs)<=set(labels)
bib=set(re.findall(r'\\bibitem\{([^}]+)\}',combined))
cites={x.strip() for group in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',combined) for x in group.split(',')}
assert cites<=bib
aux=(B/'main.aux').read_text(encoding='utf-8')
auxlabels={m[0]:{'number':m[1],'page':int(m[2])} for m in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^{}]*)\}\{(\d+)\}',aux)}
assert set(labels)==set(auxlabels),(set(labels)-set(auxlabels))
for p in sources:
    for label in re.findall(r'\\label\{([^}]+)\}',p.read_text(encoding='utf-8')):
        auxlabels[label]['source']='manuscript/'+p.name
log=(B/'main.log').read_text(encoding='utf-8')
warnings=[line for line in log.splitlines() if re.search(r'Warning|Overfull|Underfull|Missing character|undefined|^!',line)]
assert not warnings,warnings
receipt=json.loads((B/'build_receipt.json').read_text(encoding='utf-8'))
assert receipt['pdf_sha256']==sha(pdf)
assert receipt['sources']=={p.name:sha(p) for p in sources}
assert receipt['helper_sha256']==sha(E/'manuscript/build.py')
full='\n\n'.join('PAGE '+str(i+1)+'\n'+s for i,s in enumerate(texts))
(W/'FINAL_PDF_TEXT.txt').write_text(full,encoding='utf-8')
assert author in texts[0]
assert '3 November 2026' in texts[0] and 'Draft for manuscript review' in texts[0]
assert title in unicodedata.normalize('NFKC',reader.metadata.title)
assert len([l for l in links if l['kind']=='relative_evidence'])==3
records={'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','scope':'Document structure, links, fonts, labels, metadata and build identity; not a new scientific run.',
 'pdf_sha256':sha(pdf),'pdf_bytes':pdf.stat().st_size,'pages':page_records,'metadata':dict(reader.metadata),
 'python':sys.version,'pypdf':pypdf.__version__,'embedded_fonts':list(font_records.values()),'all_fonts_embedded':True,
 'font_package':'Latin Modern 2015/05/01 v1.6.1; AMSFonts/AMSSymb 2013/01/14 v3.01, as recorded in main.log',
 'bookmarks':outlines,'links':links,'source_labels':len(labels),'reference_occurrences':len(refs),'bibliography_keys':sorted(bib),
 'resolved_labels':auxlabels,'final_log_warnings':warnings,'source_pdf_helper_match_build_receipt':True}
save(V/'DOCUMENT_CHECKS.json',records)
save(V/'LABELS.json',auxlabels)
portable={k:v for k,v in receipt.items() if k not in ['command','python','build_dir']}
portable.update({'command_recipe':'python -I -B manuscript/build.py --tectonic EXISTING_TECTONIC --build-dir EXTERNAL_BUILD_DIRECTORY',
 'build_options':['--only-cached','--untrusted','--keep-logs','--keep-intermediates'],
 'font_package':records['font_package'],'document_inspector_python':sys.version,'pypdf':pypdf.__version__,
 'poppler':'26.07.0','intermediate_record':'External delivery_support/build_final/; not part of candidate edition'})
save(V/'BUILD_RECEIPT.json',portable)
print(json.dumps({'pages':len(reader.pages),'fonts':len(font_records),'bookmarks':len(outlines),'labels':len(labels),'links':len(links),'warnings':len(warnings),'pdf_sha256':sha(pdf)}))
