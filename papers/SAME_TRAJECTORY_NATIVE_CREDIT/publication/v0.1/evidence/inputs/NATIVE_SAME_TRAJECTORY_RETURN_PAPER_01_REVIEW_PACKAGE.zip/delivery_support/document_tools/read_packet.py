"""Validate and extract the supplied document packet, without executing evidence."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, io, json, zipfile
W=Path(__file__).resolve().parent
P=Path('C:/Users/Notandi/Downloads/NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_CODEX_PACKET.zip')
I=W/'inputs'
def idb(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert not I.exists(),'Preserve previous inputs'
packet=P.read_bytes()
with zipfile.ZipFile(io.BytesIO(packet)) as z:
    names=z.namelist();assert len(names)==len(set(names))
    assert z.testzip() is None
    manifest=json.loads(z.read('PACKET_MANIFEST.json'))
    assert set(names)==set(manifest['payloads'])|{'PACKET_MANIFEST.json'}
    for name,row in manifest['payloads'].items():assert idb(z.read(name))==row,name
    for name in names:
        rel=PurePosixPath(name)
        assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
        target=(I/name).resolve();assert target.is_relative_to(I.resolve())
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
accepted=I/'accepted_archive/NATIVE_SAME_TRAJECTORY_RETURN_01_REVIEW_PACKAGE.zip'
with zipfile.ZipFile(accepted) as z:
    am=json.loads(z.read('MEMBER_MANIFEST.json'))
    assert set(z.namelist())==set(am['payloads'])|{'MEMBER_MANIFEST.json'} and z.testzip() is None
    for name,row in am['payloads'].items():
        assert idb(z.read(name))==row
    for name in z.namelist():assert z.read(name)==(I/'accepted_investigation'/name).read_bytes(),name
assert accepted.with_name(accepted.name+'.sha256').read_text().split()[0]==idb(accepted.read_bytes())['sha256']
review=I/'current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW_PACKAGE.zip'
assert review.with_name(review.name+'.sha256').read_text().split()[0]==idb(review.read_bytes())['sha256']
with zipfile.ZipFile(review) as z:
    assert z.testzip() is None
    review_members=[{'path':e.filename,'bytes':e.file_size} for e in z.infolist()]
record={'checked_utc':datetime.now(timezone.utc).isoformat(),'packet':{'path':str(P),**idb(packet)},
    'packet_payloads':len(manifest['payloads']),'packet_members':len(names),'packet_manifest_crc_sizes_hashes_pass':True,
    'accepted_archive':idb(accepted.read_bytes()),'accepted_archive_members':len(am['payloads'])+1,
    'accepted_archive_manifest_crc_sizes_hashes_and_exact_extraction_pass':True,
    'review_archive':idb(review.read_bytes()),'review_archive_checksum_crc_pass':True,'review_members':review_members,
    'evidence_executed':False}
(W/'PACKET_CHECKS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
