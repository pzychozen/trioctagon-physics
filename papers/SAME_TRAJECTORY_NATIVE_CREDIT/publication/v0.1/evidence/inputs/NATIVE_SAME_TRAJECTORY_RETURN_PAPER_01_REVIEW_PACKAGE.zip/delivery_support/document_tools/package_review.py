"""Package the document and unchanged evidence; verify every final ZIP member."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,re,shutil,zipfile
W=Path(__file__).resolve().parent
E=W/'candidate_edition/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1'
D=W/'delivery_support'
archive=W/'NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_REVIEW_PACKAGE.zip'
assert not archive.exists(),'Preserve an existing delivered archive; choose a new revision explicitly.'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ident=lambda p:{'bytes':p.stat().st_size,'sha256':sha(p)}
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
write=lambda p,x:p.write_text(x.strip()+'\n',encoding='utf-8')
def cp(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    assert src.read_bytes()==dst.read_bytes()
pdf=E/'SAME_TRAJECTORY_NATIVE_CREDIT_v0.1.pdf';pdfid=ident(pdf)
receipt=json.loads((E/'verification/BUILD_RECEIPT.json').read_text(encoding='utf-8'))
assert receipt['pdf_sha256']==pdfid['sha256']
assert receipt['sources']=={p.name:sha(p) for p in sorted((E/'manuscript').glob('*.tex'))}
assert receipt['helper_sha256']==sha(E/'manuscript/build.py')
docs=json.loads((E/'verification/DOCUMENT_CHECKS.json').read_text(encoding='utf-8'))
vis=json.loads((E/'verification/VISUAL_INSPECTION.json').read_text(encoding='utf-8'))
cross=json.loads((E/'verification/LABEL_CROSSWALK.json').read_text(encoding='utf-8'))
assert all(x['pdf_sha256']==pdfid['sha256'] for x in [docs,vis,cross])
assert len(docs['pages'])==vis['pdf_pages']==len(vis['pages'])==10
assert all(p['inspection']=='PASS' for p in vis['pages'])
assert len(cross['R1_R30'])==30 and len(cross['STR01_STR28'])==28
assert cross['all_labels']==docs['resolved_labels']
assert all(p.suffix not in ['.aux','.log','.xdv','.png'] for p in E.rglob('*') if p.is_file())
# The new edition's local Markdown links, including every retained source-table link.
local_links=[]
for p in list(E.glob('*.md'))+list((E/'verification').glob('*.md'))+[E/'evidence/README.md']:
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if target.startswith(('https://','http://','#')):continue
        q=(p.parent/target.split('#')[0]).resolve()
        assert q.is_relative_to(E.resolve()) and q.exists(),(p,target)
        local_links.append({'source':p.relative_to(E).as_posix(),'target':target,'exists':True})
save(E/'verification/EDITORIAL_LINK_CHECKS.json',{'status':'PASS','pdf_sha256':pdfid['sha256'],'links':local_links,'scope':'New Markdown local links; PDF links separately checked in DOCUMENT_CHECKS.json; unchanged historical archive records retain original context.'})

# Final input audit, immediately before assembling the immutable review ZIP.
baseline=json.loads((W/'INPUT_BASELINE.json').read_text(encoding='utf-8'))
for path,expected in baseline['files'].items():assert ident(Path(path))==expected,path
for p in (W/'inputs/accepted_investigation').rglob('*'):
    if p.is_file():assert ident(p)==ident(E/'evidence/investigation'/p.relative_to(W/'inputs/accepted_investigation'))
assert ident(W/'inputs/current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW.md')==ident(E/'evidence/current_gpt_review.md')
with zipfile.ZipFile(W/'inputs/current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW_PACKAGE.zip') as rz:
    # Locate exact retained reviewer payloads by basename, independently of the enclosing folder.
    for local in ['reviewer_replay_summary.json','reviewer_exact_results.json']:
        data=(E/'evidence'/local).read_bytes()
        assert any(rz.read(n)==data for n in rz.namelist() if not n.endswith('/')),local
for p in sorted((W/'renders/build_02').glob('page-*.png')):
    cp(p,D/'renders'/p.name)
for entry in vis['pages']:
    assert ident(W/entry['render'])=={k:entry[k] for k in ['bytes','sha256']}
for name in ['main.log','main.aux','compiler.txt','build_receipt.json']:
    cp(W/'builds/build_02'/name,D/'build_final'/name)
cp(W/'builds/build_01/compiler.txt',D/'build_initial_failure/compiler.txt')
for name in ['AGENTS_CHECK.json','PACKET_CHECKS.json','REVIEW_ARCHIVE_CHECKS.json','ENVIRONMENT.json','INPUT_BASELINE.json','PRESERVATION_CHECKS.json','FINAL_PDF_TEXT.txt']:
    cp(W/name,D/'records'/name)
for name in ['read_packet.py','prepare_workspace.py','check_document.py','make_editorial.py','package_review.py']:
    cp(W/name,D/'document_tools'/name)
packet=Path('C:/Users/Notandi/Downloads/NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_CODEX_PACKET.zip')
cp(packet,D/'received_packet'/packet.name)
(D/'received_packet'/(packet.name+'.sha256')).write_text(sha(packet)+'  '+packet.name+'\n',encoding='ascii')
save(D/'records/EXECUTION_RECORD.json',{
 'utc':datetime.now(timezone.utc).isoformat(),'task':'NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01','status':'Complete for manuscript review',
 'date':'2026-11-03','pdf':pdfid,'page_count':10,'document_steps':[
 'Read current order, packet guide, current full review, accepted full proof and ledger, defining source sections and focused context/style.',
 'Verify original packet, nested archive manifests, exact identities and focused local source bytes; record 78-file baseline.',
 'Write ten LaTeX source files, including editable bibliography; use a standard-library-only document build helper.',
 'First cached/untrusted Tectonic build stopped on uncached italic 8pt font; equivalent notation removed that dependency.',
 'Second cached/untrusted build completed with no warnings; inspect structure, embedded fonts, metadata, labels, references and links.',
 'Render and visually inspect all ten final pages at 125 dpi; bind each render and final source to PDF identity.',
 'Create full R1-R30/STR01-STR28 claim crosswalk and new provenance clarification without modifying historical evidence.',
 'Recheck all protected input files and prepare manifest-covered review archive; verify every member, checksum and standalone PDF equality.'],
 'probe_errors_resolved':['A raw-template authoring submission containing literal backticks failed before file writes; corrected submission succeeded.',
 'A console-only inspection probe hit Windows encoding on a ligature; UTF-8 file-based inspection passed.',
 'A later optional inline font-inspection probe failed shell quoting before execution; existing final font inspection and recorded package versions suffice.'],
 'scientific_helpers_executed':False,'new_scientific_checks':0,'historical_distinct_exact_checks':25,'historical_independent_replay':True,
 'git_operations':False,'repository_writes':False,'commit':None,'push':False,'publication':False,'network_fetches':False,
 'installs':[],'persistent_environment_changes':False,'unresolved_issues':[],
 'review_status':'Underlying analytical acceptance received; GPT/author review of final manuscript pending.',
 'archive_verification':'Completed report is adjacent to the archive as PACKAGE_VERIFICATION.json to avoid a checksum/self-inclusion cycle.'})
write(D/'README.md','''
# External review support

The candidate edition is the prospective paper payload. This separate directory contains review renders and production records, not future publication requirements.

- renders/: all ten final full-page PNGs at 125 dpi, each hashed by the candidate visual-inspection record.
- build_final/: final compiler transcript, TeX log, auxiliary labels and raw receipt. No fonts, caches or large build intermediates.
- build_initial_failure/: diagnostic for the resolved first-build font issue.
- received_packet/: the exact supplied input packet and its checksum. That packet preserves the original investigation ZIP/checksum and current reviewer ZIP/checksum.
- records/: input/archive checks, environment versions, focused baseline/preservation, final extracted PDF text and execution record.
- document_tools/: the actual manuscript preparation, checking and packaging scripts. They use local production paths and are audit records, not the portable build entry point. In particular, do not rerun extraction/preparation over an existing workspace.

To rebuild the paper, use the candidate edition's BUILD.md and manuscript/build.py. None of the preserved scientific evidence scripts were executed for this manuscript.
''')
write(W/'REVIEW_README.md',f'''
# Completed manuscript for review

**Same-Trajectory Native Credit in the Reciprocal Chiral Exchange Candidate**

*A finite-coupling theorem for an initially empty carrier and receiver*

Hilmir Frímann Halldórsson (pzychozen), 3 November 2026. Research manuscript v0.1, **draft for manuscript review**, **10 pages**.

[Open the PDF](candidate_edition/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1/SAME_TRAJECTORY_NATIVE_CREDIT_v0.1.pdf)

[Edition README, sources and evidence](candidate_edition/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1/README.md)

[External production records and page renders](delivery_support/README.md)

The complete theorem and finite-error proof have been typeset, compiled and checked. All pages were visually inspected. The accepted analytical evidence is unchanged, and the new ledger records the approved source-heading clarification. GPT/author review of this final manuscript remains pending. No repository writes, commit, push or publication were performed.

Final PDF SHA-256: {pdfid['sha256']}

PACKAGE_MANIFEST.json identifies every other ZIP member by path, size and SHA-256; the manifest itself is excluded from its own entries. The adjacent .zip.sha256 file identifies the finished archive. The standalone and packaged PDFs are byte-identical. PACKAGE_VERIFICATION.json, adjacent to the finished ZIP, records the independent readback.
''')
# Candidate manifest is self-excluded, then fully covered by the outer ZIP manifest.
cm=E/'CANDIDATE_MANIFEST.json'
candidate_files=sorted(p for p in E.rglob('*') if p.is_file() and p!=cm)
save(cm,{'schema':1,'self_excluded':'CANDIDATE_MANIFEST.json','payload_count':len(candidate_files),
 'pdf_sha256':pdfid['sha256'],'files':[{'path':p.relative_to(E).as_posix(),**ident(p)} for p in candidate_files]})
files=[W/'REVIEW_README.md']+sorted(p for p in (W/'candidate_edition').rglob('*') if p.is_file())+sorted(p for p in D.rglob('*') if p.is_file())
members={p.relative_to(W).as_posix():p for p in files}
assert len(members)==len(files)
assert len({n.casefold() for n in members})==len(members)
for n in members:
    path=PurePosixPath(n);assert not path.is_absolute() and '..' not in path.parts and '\\' not in n
manifest={'schema':1,'task':'NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01','created_utc':datetime.now(timezone.utc).isoformat(),
 'status':'Draft for manuscript review; not published','self_excluded':'PACKAGE_MANIFEST.json',
 'payload_count':len(members),'total_zip_members':len(members)+1,'final_pdf':{'path':pdf.relative_to(W).as_posix(),**pdfid},
 'files':[{'path':n,**ident(p)} for n,p in members.items()]}
save(W/'PACKAGE_MANIFEST.json',manifest)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in members.items():z.write(p,n)
    z.write(W/'PACKAGE_MANIFEST.json','PACKAGE_MANIFEST.json')
with zipfile.ZipFile(archive) as z:
    infos=z.infolist();names=[x.filename for x in infos]
    assert len(names)==len(set(names))==len(members)+1
    assert len({n.casefold() for n in names})==len(names)
    assert set(names)==set(members)|{'PACKAGE_MANIFEST.json'}
    assert z.testzip() is None
    assert z.read('PACKAGE_MANIFEST.json')==(W/'PACKAGE_MANIFEST.json').read_bytes()
    for entry in manifest['files']:
        data=z.read(entry['path'])
        assert len(data)==entry['bytes']
        assert hashlib.sha256(data).hexdigest()==entry['sha256']
        assert data==members[entry['path']].read_bytes()
    assert z.read(pdf.relative_to(W).as_posix())==pdf.read_bytes()
checksum=archive.with_suffix('.zip.sha256')
checksum.write_text(sha(archive)+'  '+archive.name+'\n',encoding='ascii')
assert checksum.read_text(encoding='ascii').split()[0]==sha(archive)
report={'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','archive':{'filename':archive.name,**ident(archive)},
 'unique_members':len(members)+1,'manifest_hashed_payloads':len(members),'exact_member_set':True,'safe_unique_paths':True,
 'crc_all_pass':True,'all_sizes_and_sha256_match':True,'standalone_packaged_pdf_equal':True,'pdf':pdfid,
 'protected_input_files_unchanged':len(baseline['files']),'candidate_files':len(candidate_files)+1,'new_markdown_links_checked':len(local_links),
 'unresolved_issues':[],'publication':False}
save(W/'PACKAGE_VERIFICATION.json',report)
print(json.dumps(report))
