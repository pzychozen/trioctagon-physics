"""Generate editorial indexes and verification records. No model imports or scientific execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,shutil
W=Path(__file__).resolve().parent
E=W/'candidate_edition/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1'
I=W/'inputs'; V=E/'verification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ident=lambda p:{'bytes':p.stat().st_size,'sha256':sha(p)}
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
write=lambda p,s:p.write_text(s.strip()+'\n',encoding='utf-8')
labels=json.loads((V/'LABELS.json').read_text(encoding='utf-8'))
receipt=json.loads((V/'BUILD_RECEIPT.json').read_text(encoding='utf-8'))
pdfname='SAME_TRAJECTORY_NATIVE_CREDIT_v0.1.pdf'
pdfhash=sha(E/pdfname)
title='Same-Trajectory Native Credit in the Reciprocal Chiral Exchange Candidate'
commit='273b1a6faaab19ea58748d00576439166eeef9ab'
clarification='The seven published source IDs CANDIDATE through ACCEPTED_PROOF refer to unchanged complete files at edition commit '+commit+'. ORDER and CONTEXT identify the later investigation inputs retained separately in SOURCE_IDENTITIES.json.'
# Exact accepted R numbering, not the predecessor's equation numbering.
rmap={
1:('Registration and chiral drive',['eq:registration','eq:drive']),
2:('Finite disjoint tents and ports',['eq:tents','eq:ports']),
3:('Unchanged exchange system',['eq:system','eq:storages','eq:powers','eq:balances']),
4:('Empty coherent launch',['eq:preparation']),
5:('All constants and sufficient threshold',['eq:profilenorms','eq:gram','eq:constants','eq:errorconstants','eq:threshold','sec:units']),
6:('Explicit later native-power witness',['thm:credit','eq:witness','eq:allocation']),
7:('Closed credit interval and integrated gain',['eq:interval','eq:gain']),
8:('Empty-launch cumulative debit',['eq:cumulative']),
9:('Inherited global solution and strong regularity',['eq:regularity','sec:equations']),
10:('Exact row Gram matrix and operator norm',['eq:gram']),
11:('Nonzero drive for every fixed yaw',['eq:launchdrive']),
12:('Norms and first weak derivative of tents',['eq:profilenorms']),
13:('Ball bounds and convex-ball Lipschitz estimate',['eq:ballbounds']),
14:('Exact finite-coupling scaling',['eq:scaling']),
15:('Scaled system and original-power conversion',['eq:scaledsystem','eq:powerconversion']),
16:('Weighted external space and finite operator',['eq:externalnorm','eq:operator']),
17:('Propagation and receiver cancellation',['eq:skew']),
18:('Forced external norm inequality',['eq:forcedbound']),
19:('Exact external norm and port bounds',['eq:externalbounds','sec:forced']),
20:('Core and drive drift, factor one-fourth',['eq:coredrift','eq:drivedrift']),
21:('Explicit empty-start active-receiver comparison',['eq:comparison','eq:comparisonoutput','eq:comparisonbackflow']),
22:('Strict negative comparison coefficient',['eq:comparisonmargin']),
23:('Exact error equation and derivative regularity',['eq:error','sec:comparison']),
24:('Integrated error bound',['eq:errorintegral']),
25:('Finite error at the witness',['eq:finiteerror']),
26:('Complete total-power product decomposition',['eq:powerdecomposition']),
27:('Finite power error',['eq:powererror']),
28:('Inherited initial activity and same-solution chronology',['eq:initialactivity','sec:comparison']),
29:('Storage on fixed scaled windows',['eq:stockscale']),
30:('Invariant and initial-core extraction ceiling',['eq:invariant','eq:capacity'])
}
# Claim coverage includes interpretation and provenance, beyond the displayed R equations.
smap=[
('Raw chiral drive, fixed registration and original port ordering',[1],['sec:ports','eq:registration','eq:drive'],'CANDIDATE: eq:registration, eq:drive; ACCEPTED_PROOF: S1.'),
('Normalized disjoint periodic tents; exact m, d and first-derivative norms',[2,12],['eq:tents','eq:ports','eq:profilenorms'],'CANDIDATE: eq:tents, eq:ports; WELLPOSED: eq:profilenorms; ACCEPTED_PROOF: A9.'),
('Unchanged constant-coefficient exchange and empty preparation',[3,4],['eq:system','eq:preparation'],'CANDIDATE: eq:system; ACTIVITY: Proposition 4.1; ORDER: sections 2-3.'),
('Global uniqueness, conservation and strong regularity at each finite coupling',[9],['eq:balances','eq:regularity','sec:equations'],'WELLPOSED: Theorem 3.1, eq:strong; POWER: eq:balances.'),
('Yaw-independent K norm from both Gram eigenvalues',[10],['eq:gram'],'CANDIDATE: eq:registration; accepted calculation R10.'),
('R squared is 3; the launch drive is nonzero at every fixed yaw',[4,11],['eq:preparation','eq:gram','eq:launchdrive'],'ACTIVITY: Proposition 4.1, eq:nonzero; R11.'),
('f and J bounds and convex-ball Lipschitz bound',[13],['eq:ballbounds'],'WELLPOSED: eq:lipschitzbounds; POWER: eq:jacobian.'),
('Positive conserved total storage bounds the exact core by R',[19,20],['sec:forced','eq:externalbounds','eq:coredrift'],'POWER: eq:balances; WELLPOSED: conservation in Theorem 3.1.'),
('Exact time/state scaling and original total-power factor',[14,15],['eq:scaling','eq:scaledsystem','eq:powerconversion'],'CANDIDATE: eq:system; chain rule, R14-R15.'),
('Weighted energy cancellation and norm estimate, regularized at zero',[16,17,18],['eq:externalnorm','eq:operator','eq:skew','eq:forcedbound'],'POWER: periodic integration and matched loading; WELLPOSED: eq:strong; R16-R18.'),
('Exact external norm and port estimates before comparison',[19],['eq:externalbounds'],'R13, R16-R19 and empty preparation.'),
('Core and drive drift with the accepted A and factor one-fourth',[5,20],['eq:errorconstants','eq:coredrift','eq:drivedrift'],'R5, R13-R20.'),
('Explicit oscillator comparison and negative coefficient at T',[21,22],['eq:comparison','eq:comparisonoutput','eq:comparisonmargin'],'R21-R22; B*B=mI from WELLPOSED: eq:profilenorms.'),
('Known strong difference, exact negative first-derivative residual',[23],['sec:comparison','eq:error'],'WELLPOSED: eq:strong; R9, R21-R23; first weak derivative only.'),
('Absolute sine integral and finite propagation/core error',[24,25],['eq:errorintegral','eq:finiteerror'],'R18, R20, R23-R25.'),
('Full two-port power error, using actual output in the first term',[26,27],['eq:powerdecomposition','eq:powererror'],'R19-R27.'),
('Sufficient finite threshold, D>0 and two D/4 error allocations',[5,6,27],['eq:threshold','eq:witness','eq:allocation','thm:credit'],'R5-R6, R11, R27; other parameters fixed first.'),
('Closed later interval and strictly positive integrated native gain',[7],['eq:interval','eq:gain','sec:comparison'],'R7; POWER: eq:integrated; continuity of total power.'),
('Strict initial native supply and exact receiver charging',[28],['eq:initialactivity'],'ACTIVITY: Proposition 4.1, eq:initialreceiverpower; R28.'),
('Initial and later intervals belong to one unchanged unique solution',[6,7,28],['thm:credit','sec:comparison'],'WELLPOSED: Theorem 3.1; R6-R7 and R28; separate nonuniform small-time argument.'),
('Cumulative total native debit remains nonnegative',[8],['eq:cumulative','sec:account'],'POWER: eq:balances and eq:integrated; empty preparation.'),
('Correct dimensions of drift constant, power coefficients and ratios',[5],['sec:units'],'CANDIDATE: tab:units; accepted proof section 6 units table.'),
('External stock bound on fixed finite scaled windows',[29],['eq:stockscale','sec:scales'],'R14-R15, R19 and R29.'),
('Witness-power scaling and vanishing witness/circuit-time ratio',[6,15,27],['eq:powerscale','eq:traveltime','sec:scales'],'R6, R15, R27; proof section 6. All other parameters fixed.'),
('Comparison backflow distinguished from unproved exact receiver sign at t*',[21,22],['eq:comparisonbackflow','sec:account'],'R21-R22 and proof section 6; current review section 3.'),
('Unchanged invariant and net-extraction ceiling with initial-core denominator',[30],['eq:invariant','eq:capacity','sec:capacity'],'CAPACITY: Theorem 5.1, eq:Z2, eq:floor, eq:netcapacity, eq:coherentcapacity.'),
('Fast collocation and preserved geometric distinctions; bounded continuation',[],['sec:conclusion','eq:traveltime'],'INTERPRETATION: section 8; ORDER: section 6; current review sections 3 and 6; manuscript order section 5.'),
('Accepted analytical record, 25 distinct replayed checks, pending final PDF review',[],['sec:introduction','sec:conclusion'],'SOURCE_IDENTITIES.json; EXACT_CERTIFICATE_RESULTS.json; current GPT review sections 1-5; reviewer replay summary; new PROVENANCE.md.')
]
assert len(smap)==28 and set(rmap)==set(range(1,31))
def loc(keys):
    out=[]
    for k in keys:
        d=labels[k]
        prefix='Eq.' if k.startswith('eq:') else ('Theorem' if k.startswith('thm:') else 'Section')
        if d['number']=='A':prefix='Appendix'
        out.append(prefix+' '+d['number']+' (p. '+str(d['page'])+'; '+k+')')
    return '; '.join(out)
rrows=[]
for i,(claim,keys) in rmap.items():
    rrows.append({'accepted_locator':'R'+str(i),'claim':claim,'manuscript_labels':keys,'printed_locators':[dict(label=k,**labels[k]) for k in keys]})
srows=[]
for i,(claim,rs,keys,source) in enumerate(smap,1):
    srows.append({'accepted_locator':f'STR{i:02d}','claim':claim,'accepted_R':['R'+str(n) for n in rs],
       'manuscript_labels':keys,'printed_locators':[dict(label=k,**labels[k]) for k in keys],'foundations':source})
mapped={k for x in rrows+srows for k in x['manuscript_labels']}
assert {k for k in labels if k.startswith(('eq:','thm:'))}<=mapped
save(V/'LABEL_CROSSWALK.json',{'pdf_sha256':pdfhash,'sources':receipt['sources'],'R1_R30':rrows,'STR01_STR28':srows,'all_labels':labels,
 'all_displayed_equations_and_theorem_covered':True,'interpretive_additions':'Current review and manuscript order supply updated status and programme sequence; historical evidence remains unchanged.'})

oldids=json.loads((E/'evidence/investigation/SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
published=[]
for s in oldids['sources']:
    p=E/'evidence/investigation'/s['retained_as'];assert ident(p)=={k:s[k] for k in ['bytes','sha256']}
    published.append({k:s[k] for k in ['id','commit','immutable_url','edition_path','bytes','sha256']}|{'retained_as':p.relative_to(E).as_posix(),'role':'Unchanged published mathematical foundation'})
later=[]
for id_,rel,role in [
 ('ORDER','evidence/investigation/SUPPLIED_WORK_ORDER.md','Later investigation order, not a file of the predecessor edition'),
 ('CONTEXT','evidence/investigation/START_HERE_CONTEXT.md','Historical research context; current review/order supersede its next-step and availability wording'),
 ('INVESTIGATION_PROOF','evidence/investigation/NATIVE_SAME_TRAJECTORY_RETURN_01_PROOF.md','Accepted R1-R30 argument; historical preparation status retained'),
 ('INVESTIGATION_LEDGER','evidence/investigation/NATIVE_SAME_TRAJECTORY_RETURN_01_CLAIM_SOURCE_LEDGER.md','Unchanged historical STR01-STR28 ledger'),
 ('CURRENT_GPT_REVIEW','evidence/current_gpt_review.md','Current analytical acceptance, read in full; not final manuscript review'),
 ('MANUSCRIPT_ORDER','evidence/manuscript_order.md','Current scoped manuscript instruction'),
 ('REVIEWER_REPLAY_SUMMARY','evidence/reviewer_replay_summary.json','Prior independent replay of the same 25 exact checks'),
 ('REVIEWER_EXACT_RESULTS','evidence/reviewer_exact_results.json','Prior reviewer exact results; not run for this manuscript')]:
    p=E/rel;later.append({'id':id_,'retained_as':rel,'role':role,**ident(p),'commit':None})
save(E/'SOURCE_IDENTITIES.json',{'date':'2026-11-03','clarification':clarification,'published_sources':published,
 'later_inputs':later,'original_input_packet':{'delivery_path':'delivery_support/received_packet/NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_CODEX_PACKET.zip',
 **ident(Path('C:/Users/Notandi/Downloads/NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_CODEX_PACKET.zip'))},
 'identity_basis':'Supplied hashes, packet and nested manifests, unchanged local accepted files and seven unchanged predecessor files; no Git or network operation.',
 'historical_registry':'evidence/investigation/SOURCE_IDENTITIES.json'})

source_lines=[]
focused={
'CANDIDATE':'Section 1: registration, drive, tents, ports, stores, system, units.',
'POWER':'Section 2: Euler/Jacobian identity, native feedback, total powers and balances.',
'WELLPOSED':'Theorem 3.1 and proof: global/strong solutions, profile norms and Lipschitz bounds.',
'ACTIVITY':'Proposition 4.1: empty-launch expansions. Proposition 4.2 concerns different prepared data.',
'CAPACITY':'Theorem 5.1: invariant, floor and coherent-span net-extraction ceiling.',
'INTERPRETATION':'Section 8: collocation and geometric distinctions; historical open status.',
'ACCEPTED_PROOF':'S1-S4, A1-A16, B1-B4: finer predecessor proof locators; not the new R labels.'}
for s in published:source_lines.append('| '+s['id']+' | ['+s['edition_path']+']('+s['retained_as']+') | '+focused[s['id']]+' |')
ledger=['# Manuscript claim and source ledger','',
title,'','Research manuscript v0.1, draft for manuscript review. 3 November 2026. Final PDF: '+pdfhash+'.','',
clarification,'',
'This is new editorial material. The original proof and ledger remain byte-for-byte unchanged. Their pending-review and missing-review statements describe their historical preparation. The current analytical review is available, was read in full, and accepts the finite-coupling result without a mathematical correction. Review of this new PDF by GPT and the author remains pending.','',
'The provenance clarification narrows the old ledger heading to the seven published files. It changes no equation, theorem, source bytes or acceptance scope. ORDER and CONTEXT are later inputs; CURRENT_GPT_REVIEW and MANUSCRIPT_ORDER are separately identified in [SOURCE_IDENTITIES.json](SOURCE_IDENTITIES.json).','',
'## Exact inherited sources','','| ID | Retained complete file | Focused predecessor locator |','|---|---|---|',*source_lines,'',
'## Accepted claims to printed manuscript','','All STR labels below refer to the accepted investigation ledger. Claims classed as new in that historical ledger are the already accepted argument now typeset here. Mathematical premises, inequalities and regularity are justified by the written proof, not by symbolic PASS counts.','',
'| Accepted claim | Manuscript coverage | Foundation and scope |','|---|---|---|']
for row in srows:
    ledger.append('| '+row['accepted_locator']+': '+row['claim']+' | '+loc(row['manuscript_labels'])+' | '+row['foundations']+' |')
ledger+=['','## R1-R30 equation crosswalk','','The R numbers belong to the accepted same-trajectory report. They do not renumber the predecessor or the manuscript. The machine-readable crosswalk also includes final source hashes and every label: [LABEL_CROSSWALK.json](verification/LABEL_CROSSWALK.json).','',
'| Accepted report | Claim | Printed manuscript |','|---|---|---|']
for row in rrows:ledger.append('| '+row['accepted_locator']+' | '+row['claim']+' | '+loc(row['manuscript_labels'])+' |')
ledger+=['','No scientific replay or new trajectory calculation was performed for this manuscript. The supporting history is 25 distinct exact-algebra checks, independently replayed, not 50 distinct checks.']
write(E/'CLAIM_SOURCE_LEDGER.md','\n'.join(ledger))

write(E/'README.md',f'''
# {title}

*A finite-coupling theorem for an initially empty carrier and receiver*

Hilmir Frímann Halldórsson (pzychozen). Research manuscript v0.1, **draft for manuscript review**, finalized 3 November 2026. **10 pages. Ready for GPT/author manuscript review.**

[Read the PDF]({pdfname}) · [Editable LaTeX](manuscript/main.tex) · [Build recipe](BUILD.md)

For a fixed admitted coherent launch and an explicit sufficient finite receiver coupling, the unchanged reciprocal chiral exchange solution starts with an empty carrier and receiver, first supplies native trial storage, and later has strictly negative total native power. The paper gives the complete finite-error proof, its recovery interval and its quantitative limits.

The underlying investigation and constants have internal analytical acceptance. This final typeset manuscript awaits GPT/author review. It has not been published; there is no DOI or external peer-review claim.

- [Claim/source ledger](CLAIM_SOURCE_LEDGER.md) maps all R1-R30 and STR01-STR28 to printed equations, sections and pages.
- [Source identities](SOURCE_IDENTITIES.json) distinguish seven immutable predecessor files from later orders, context, investigation and review.
- [Provenance](PROVENANCE.md) records contributions, the accepted source-heading clarification and the exact evidence roles.
- [Fidelity review](verification/FIDELITY_REVIEW.md), [document checks](verification/DOCUMENT_CHECKS.json), [build receipt](verification/BUILD_RECEIPT.json) and [all-page visual inspection](verification/VISUAL_INSPECTION.json) identify the final PDF.
- [Evidence guide](evidence/README.md) introduces unchanged accepted records and their historical status wording.

The editable bibliography is manuscript/references.tex. Evidence helper scripts are historical records and are not build dependencies. Build products and full-page renders are outside this candidate payload.

Final PDF SHA-256: {pdfhash}

The delivery ZIP includes this complete candidate tree plus the exact received packet and external review/build records. Its member manifest covers every other member; the adjacent checksum covers the finished archive. No repository writes, Git operation, commit, push or next investigation were performed.
''')
write(E/'BUILD.md',r'''
# Document-only build

Build from this edition directory. On the author's Windows system, use Command Prompt:

    call conda activate torment
    python -I -B manuscript\build.py --tectonic C:\path\to\tectonic.exe --build-dir C:\outside-edition\new-build-directory

On another system, use an existing Python 3.9+ interpreter and Tectonic:

    python -I -B manuscript/build.py --tectonic /path/to/tectonic --build-dir /outside/edition/new-build-directory

Omitting --build-dir creates a new system-temporary directory. The helper rejects a build directory inside the edition. It requires only Python's standard library, builds all local TeX sources and bibliography, writes intermediates and logs externally, then copies the resulting PDF into this edition. Use a new external build directory for each attempt. The helper records final source, helper and PDF hashes after a successful build.

The exact production tools were Python 3.11.15 in conda environment torment; Tectonic 0.17.0; cached LaTeX2e 2021-11-15 patch level 1; article class 2021/10/04 v1.4n; Latin Modern package/font definitions 2015/05/01 v1.6.1; AMS fonts/symbols package 2013/01/14 v3.01. All 18 fonts referenced by the PDF are embedded. Their names and embedded-stream hashes are recorded in verification/DOCUMENT_CHECKS.json. No fonts are redistributed as separate build files.

Tectonic runs with --only-cached and --untrusted. There is no shell escape, scientific import, scientific replay, model simulation, Git operation or package installation. A pre-existing TeX resource cache with the listed packages and fonts is required. Missing resources cause a build failure; the helper does not fetch them. Cached Tectonic is sufficient on the production host. A different cache/compiler may alter PDF bytes or pagination, so a new build requires its own checks rather than reuse of this edition's verification records.

SOURCE_DATE_EPOCH is set to 3 November 2026 UTC. Windows font configuration and temporary paths are scoped to the child process and external build directory; the helper changes no persistent configuration.

The final successful run was build_02. Build_01 stopped on an unavailable 8-point italic font used by the word “for” inside the theorem. Replacing that text with parenthesized interval notation retained the identical quantified inequality and required no package fetch. The final run has zero undefined references, missing-glyph, overfull, underfull or other warning lines.

Document inspection used bundled Python 3.12.14 with pypdf 6.10.0. Rendering used Poppler pdftoppm 26.07.0 at 125 dpi. Every one of the ten final pages was visually inspected; the exact PDF and render hashes are recorded. The build itself does not depend on these inspection tools.

The delivery support directory retains the final compiler log, auxiliary labels and raw receipt, the failed-build diagnostic, environment versions, extraction/preservation records, inspection scripts and full-page renders. None are imports for the scientific argument.
''')
write(E/'PROVENANCE.md',f'''
# Provenance and editorial disposition

Research manuscript v0.1, draft for manuscript review. Finalization: 3 November 2026. Research author and direction: Hilmir Frímann Halldórsson (pzychozen).

GPT supplied formulation and internal analytical review of the investigation. Codex performed the independent investigation verification and this manuscript preparation, including document compilation, fidelity review, structure checks and visual inspection. These are contributions, not invented human coauthors. GPT/author review of this final PDF remains pending.

## Accepted mathematics and source status

The current analytical review supplied in the packet was read in full. It accepts the investigation at its explicit sufficient finite-coupling scope with all constants unchanged. The 25 distinct exact-algebra checks were independently replayed during the investigation/review history. This paper-production pass did not execute those scientific scripts, create 25 more identities, simulate a trajectory or extend the theorem.

The original proof's “review pending” language and historical ledger/context availability language are preserved as historical evidence. They do not describe the current analytical acceptance. That acceptance does not imply review of the newly typeset PDF or external peer review.

## Approved source-heading clarification

{clarification}

This is a provenance wording clarification in the new ledger only. The archived original ledger was not edited. No equation, theorem, constant or accepted conclusion changed.

## Identity and preservation

The received packet's 41-member unique set, 40 hashed payloads and manifest were checked before safe extraction. The original 26-member investigation archive and 12-member reviewer archive, their manifests and supplied checksums were verified. Exact copies of the accepted investigation extraction, current review and replay records are in evidence/. The exact received packet, containing both original archives, is retained in the delivery support directory.

All seven mathematical predecessor files used match their supplied commit-specific hashes and the retained prior publication edition. The focused input baseline covers 78 files: extracted inputs, the accepted investigation workspace, the seven predecessor files actually used and the received packet. The final preservation record verifies these bytes unchanged. This is a focused input check, not a repository-wide audit.

[SOURCE_IDENTITIES.json](SOURCE_IDENTITIES.json) records full identities and immutable locators. [CLAIM_SOURCE_LEDGER.md](CLAIM_SOURCE_LEDGER.md) and the machine-readable crosswalk connect all accepted R/STR claims with the printed manuscript.

## Document production

The final PDF has 10 pages and SHA-256 {pdfhash}. Its ten TeX files and build helper match the final build receipt. Final references, citations, local evidence links and bookmarks resolve; every referenced font is embedded. Every page was rendered at 125 dpi and visually checked.

One initial compilation failed on an uncached small italic font. An equivalent notation-only change removed that dependency. The second build succeeded with zero warnings and is the final inspected artifact. A console-only inspection probe encountered a Windows output-encoding error; file-based UTF-8 inspection then passed. These were document-tool issues, not scientific discrepancies. No installation or persistent environment change was made.

This candidate tree is isolated in the manuscript research workspace. No real repository path or prior edition was changed. No Git commands, network publication, commit or push were used. Publication and the next scientific investigation remain outside this order.

## Disposition

No unresolved mathematical/source conflict, build problem or visual defect was found within the commissioned scope. Ready for GPT/author manuscript review, not yet approved for publication.
''')
write(E/'evidence/README.md','''
# Guide to the unchanged evidence

investigation/ is a complete unchanged extraction of the accepted 26-member investigation archive, including its original proof, original STR ledger, manifests, source copies and historical execution records. Existing relative links within that extraction are preserved.

current_gpt_review.md is the actual current review supplied for this manuscript. It was read in full and accepts the stated finite-coupling theorem and constants. It is not a review of the new final PDF.

reviewer_replay_summary.json and reviewer_exact_results.json are exact copies of earlier reviewer evidence. They concern an independent replay of the same 25 exact-algebra checks. They are historical inputs, not results of a replay in this manuscript task.

manuscript_order.md is the exact scoped manuscript work order. It supersedes old next-step and review-availability wording for this work.

The original proof and ledger retain preparation-time pending-review language. The original source heading is intentionally unchanged; its approved clarification appears only in the new edition-level CLAIM_SOURCE_LEDGER.md and PROVENANCE.md. Do not treat historical context instructions or helper scripts as a request to rerun scientific work.

The exact original accepted investigation ZIP, reviewer ZIP and their checksums are contained in the unchanged received packet under the outer delivery_support/received_packet/ directory. Full identities for the selected evidence are in ../SOURCE_IDENTITIES.json. No scientific evidence file was edited.
''')

checks=[
('Fixed problem and periodic admissibility','Section 2, Eqs. (2.1)-(2.6)',
 'Retains raw two-port K with yaw and positive gains; normalized finite tents; shortest periodic separation condition as well as epsilon<eta; first weak derivative in L2; negative receiver loading and native factor 1/(2 alpha_N).'),
('Storage, signed powers and existence','Section 2.2, Eqs. (2.7)-(2.10)',
 'Positive quadratic trial stores, complete total signed port sum, three balances. The predecessor global/strong theorem supplies existence before any new cancellation argument. Empty H1 data and finite positive parameters satisfy its hypotheses. Native quartic V is distinguished.'),
('Launch and quantifier order','Section 2.3 and Theorem 3.1',
 'Omega0=(1,exp(i phi),1), 0<phi<pi/12, all external coordinates zero. R=sqrt(3), k=G sqrt(8/7), and both Gram eigenvalues retained. Squared drive G^2 sin^2(phi)(6+8 sin^2 yaw)/7 stays positive at every fixed yaw; individual zero port allowed. Geometry, phi and other parameters fixed before every finite kappa above threshold.'),
('Constants, witness and gain','Eqs. (3.1)-(3.6)',
 'Fmax=kR^2/2; omega=sqrt(m/beta_R); T=3pi/(2omega); D=m|f0|^2/omega>0. A=eta_N^2 k^2 R^2 m Fmax/(4 alpha_N). C1=3c sqrt(md)|f0|^2/omega^2; C2=m A T^3(Fmax+|f0|/3). Threshold max{1,4C1/D,sqrt(4C2/D)}. Witness -eta_N^2D/(2kappa); interval margin -eta_N^2D/(4kappa); gain eta_N^2D rho/(2kappa); 0<rho<t*/4. Unchanged accepted constants.'),
('Exact scaling and energy estimate','Eqs. (4.1)-(4.9)',
 'Native equation has eta_N^2/kappa^2; propagation c/kappa; receiver 1/beta_R. Original-power factor eta_N^2/kappa. Weighted beta_R norm and H1 operator domain retained; periodic and receiver terms cancel. Regularized norm at zero explicitly justified. Conservation and convex-ball Lipschitz bound precede comparison; external bounds sqrt(m)Fmax tau and mFmax tau.'),
('Native drift','Eqs. (4.10)-(4.11)',
 'Integration supplies one-fourth coefficient; drive drift A tau^2/kappa^2. The argument uses a conserved Euclidean ball, not coherent-family or phase-domain invariance.'),
('Comparison and error regularity','Eqs. (5.1)-(5.4)',
 'Complete sine/cosine oscillator, zero initial external state and active comparison receiver. Core freezing and omitted propagation are comparison features only. Exact-minus-explicit comparison has known strong regularity before estimating residual. Negative residual lies in second carrier component and uses B prime only; L2 suffices, with no second derivative or implicit smoothing.'),
('Finite-error and complete power bound','Eqs. (5.5)-(5.9)',
 'Absolute sine integral 3/omega; propagation term 3c sqrt(d)|f0|/(kappa omega^2) and core term sqrt(m)AT^3/(3kappa^2). Product decomposition uses actual y in first term and includes both errors. C1/kappa+C2/kappa^2 is allocated D/4+D/4. No unbounded-generator operator-norm convergence is asserted.'),
('Same-solution chronology','Section 5, Eq. (5.10)',
 'Continuous total power gives a closed later interval. Integrating the exact native balance gives strict gain. Inherited launch expansions are applied separately at each chosen finite kappa, never evaluated nonuniformly at T/kappa. Initial interval shortened into (0,t*/4); uniqueness identifies one unchanged solution.'),
('Energetic interpretation and receiver limitation','Section 6.1',
 'HN never exceeds HN(0); cumulative debit equals HC+HR. Later credit recovers earlier supply. Comparison receiver backflow is explicit; no finite exact P_CR(t*)<0 claim is made. Initial exact receiver activity remains part of the theorem.'),
('Scaled-window and capacity scope','Sections 6.2-6.3',
 'External-stock O(eta_N^2/kappa^2) bound is on fixed finite scaled windows, and witness-power expansion holds with all other parameters fixed. No long-time decay, substantial recovered fraction or capacity attainability is claimed. Z2 floor and coherent-span ceiling use initial core storage, with approximately 3.4074 percent as a bound rather than achieved share.'),
('Dimensions','Appendix A',
 'Drift A has U L/T^3, distinct from native-amplitude unit A and registration matrix. D,C1,C2 have power units U^2 L/T; threshold ratios are dimensionless. This is mathematical bookkeeping, not physical calibration.'),
('Geometry and continuation','Section 7',
 't*/(L_c/c) tends to zero with fixed geometry and c: fast collocation, not circuit evidence. Preserves central finite region, opposed cones, outward curvature/inward return, possible transfer elsewhere and stationary supports. Circle, toroid and two sphere constructions; N/G; exact O versus finite region remain distinct. No new receiver/route/six-opening map or field calibration. Current sequence and later gravity-magnetism/SRG directions retained compactly.'),
('Evidence and authorship','Cover, contributions, references and new editorial records',
 'Current review available and analytical acceptance completed; final manuscript review pending. 25 distinct checks independently replayed, not 50. No scientific rerun now. Author accents, date and draft status consistent. Seven immutable source files separated from later orders/context; only new ledger receives approved provenance clarification.')
]
f=['# Manuscript-fidelity review','',
 'Codex manuscript review, 3 November 2026. Disposition: PASS within the commissioned manuscript scope. This record is separate from the prior GPT analytical review and does not claim GPT/author approval of the final PDF.','',
 'Reviewed PDF SHA-256: '+pdfhash,'','The complete written argument and defining source sections were compared with the accepted report, original ledger and current analytical review. All R1-R30 and STR01-STR28 have printed locators in LABEL_CROSSWALK.json. Algebraic check counts are supporting historical evidence, not a substitute for these analytical checks.','',
 '## Scientific and editorial gates','']
for name,where,result in checks:f+=['### '+name,'',where+'. '+result,'']
f+=['## Artifact binding','','| Final source | SHA-256 |','|---|---|']
for name,h in receipt['sources'].items():f.append('| manuscript/'+name+' | '+h+' |')
f+=['| manuscript/build.py | '+receipt['helper_sha256']+' |','',
'The final source/PDF/helper binding is independently checked in DOCUMENT_CHECKS.json. The source-heading clarification and notation-only build fix change no accepted mathematical claim. No unresolved substantive discrepancy was identified.']
write(V/'FIDELITY_REVIEW.md','\n'.join(f))

notes=[
'Cover: complete title and subtitle, correct author accents, date, review status, abstract and contribution note; comfortable spacing.',
'Introduction and fixed problem: numbered sections, registration and finite-profile formulas readable; equation numbers and margins clear.',
'Profile norms, unchanged system, stores and regularity: formulas and boxed system fit; launch heading has its preparation below it.',
'Gram/drive calculation and complete Theorem 3.1: constants and threshold legible; witness, interval and gain retained on the same page.',
'Exact scaling and weighted energy: all factors and subscripts visible; cancellation and regularized-norm paragraph continue normally.',
'External estimates, drift and comparison: boxed/inline equations aligned; comparison distinguished; error-regularity paragraph continues to next page.',
'Finite residual, error and power proof: negative sign, first derivative, both error terms, D/4 allocations and initial-activity coefficients legible.',
'Proof completion and quantitative meaning: chronology/QED clear; cumulative account, comparison scope and scaled-window bounds fit.',
'Capacity and conclusion: initial-core denominator, geometric distinctions and continuation readable; contribution paragraph continues normally.',
'Contributions completion, units and bibliography: all table entries fit; accents, references and link text readable; footer 10 clear.'
]
renders=[]
for n,note in enumerate(notes,1):
    p=W/f'renders/build_02/page-{n:02d}.png'
    assert p.exists()
    renders.append({'page':n,'render':'delivery_support/renders/'+p.name,**ident(p),'inspection':'PASS','notes':note})
save(V/'VISUAL_INSPECTION.json',{'status':'PASS','inspector':'Codex visual inspection of every rendered page',
 'utc':datetime.now(timezone.utc).isoformat(),'pdf_sha256':pdfhash,'pdf_pages':10,'sources':receipt['sources'],
 'renderer':'Poppler pdftoppm 26.07.0, 125 dpi PNG','pages':renders,
 'checks':'Readable text and formulas, margins, signs/subscripts, page breaks and proof continuations, header/footer numbering, units table, references, author accents; embedding separately verified by document inspection.',
 'defects_found_in_final_build':[],'review_status':'Codex page inspection completed; GPT/author manuscript review pending.'})

baseline=json.loads((W/'INPUT_BASELINE.json').read_text(encoding='utf-8'))
preserved=[]
for path,identity in baseline['files'].items():
    actual=ident(Path(path));assert actual==identity,path
    preserved.append({'path':path,**actual,'unchanged':True})
pres={'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','checked_files':len(preserved),'files':preserved,
 'scope':'Focused 78-file baseline only: packet/extracted inputs, accepted investigation and seven predecessor sources actually used; no Git operation or repository-wide audit.'}
assert len(preserved)==78
save(W/'PRESERVATION_CHECKS.json',pres)
save(V/'PRESERVATION_CHECKS.json',pres)
# Confirm every copied scientific evidence file is byte-identical to the accepted extraction.
for p in (I/'accepted_investigation').rglob('*'):
    if p.is_file():assert p.read_bytes()==(E/'evidence/investigation'/p.relative_to(I/'accepted_investigation')).read_bytes()
assert (E/'evidence/current_gpt_review.md').read_bytes()==(I/'current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW.md').read_bytes()
assert (E/'evidence/manuscript_order.md').read_bytes()==(I/'NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_CODEX_WORK_ORDER.md').read_bytes()
print(json.dumps({'R_locators':len(rrows),'STR_claims':len(srows),'all_equations_covered':True,'preserved_inputs':len(preserved),'visual_pages':len(renders),'pdf_sha256':pdfhash}))
