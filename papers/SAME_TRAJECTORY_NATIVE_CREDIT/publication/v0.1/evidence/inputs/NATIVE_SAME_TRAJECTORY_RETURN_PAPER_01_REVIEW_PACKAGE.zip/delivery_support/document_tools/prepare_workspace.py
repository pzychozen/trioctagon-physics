"""Read-only baseline and evidence retention for manuscript authoring."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, shutil, subprocess, sys, zipfile
W=Path(__file__).resolve().parent;I=W/'inputs'
E=W/'candidate_edition/papers/SAME_TRAJECTORY_NATIVE_CREDIT/publication/v0.1'
OLD=W.parent/'NATIVE_SAME_TRAJECTORY_RETURN_01'
PUB=W.parent/'NATIVE_RECIPROCAL_EXCHANGE_PAPER_PUBLISH_01/publication_worktree/papers/RECIPROCAL_CHIRAL_EXCHANGE/publication/v0.1'
def ident(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(name,x):(W/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert not E.exists() and not (W/'INPUT_BASELINE.json').exists()
expected={
 'accepted_investigation/NATIVE_SAME_TRAJECTORY_RETURN_01_PROOF.md':(23338,'841b5e3a35d0f32cf083388eb1c4a07a60ac8075bc7f622ada76fe1f7591d39b'),
 'accepted_investigation/NATIVE_SAME_TRAJECTORY_RETURN_01_CLAIM_SOURCE_LEDGER.md':(12247,'00d2e4f722595af8fc44576db40a3770248b4ca2fdc963d0682ce87dd214a25f'),
 'accepted_archive/NATIVE_SAME_TRAJECTORY_RETURN_01_REVIEW_PACKAGE.zip':(86820,'c832f8f5a49ba88f77260aa7aaf02331af9a1da68c574eedfc68cad7eb1c67d3'),
 'current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW.md':(17542,'220669c0d6a503f7cdebfda6385df7ee26bdd3404cd251f0a1d010212c0e1709'),
 'current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW_PACKAGE.zip':(110258,'9c6329c76d7144a805c7e6b37f05e84c2cfb221d46a9c705673263e159314ae9'),
 'context/NATIVE_SAME_TRAJECTORY_RETURN_01_CODEX_WORK_ORDER.md':(25403,'ca3789fddb321e873daa0528e767f67fc45ceae00e1c856a99e106311253e61f')}
for name,(size,digest) in expected.items():assert ident(I/name)=={'bytes':size,'sha256':digest},name
source_record=json.loads((I/'accepted_investigation/SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
for row in source_record['sources']:
    rel=row['edition_path'];expected_id={k:row[k] for k in ('bytes','sha256')}
    assert ident(I/'accepted_investigation/sources'/rel)==ident(PUB/rel)==expected_id
protected={str(p):ident(p) for p in I.rglob('*') if p.is_file()}
for p in OLD.rglob('*'):
    if p.is_file():protected[str(p)]=ident(p)
for row in source_record['sources']:
    p=PUB/row['edition_path'];protected[str(p)]=ident(p)
packet=Path(json.loads((W/'PACKET_CHECKS.json').read_text())['packet']['path'])
protected[str(packet)]=ident(packet)
instructions=set()
for path in [W,*[Path(p).parent for p in protected]]:
    for parent in [path,*path.parents]:instructions.add(parent/'AGENTS.md')
found=[str(p) for p in sorted(instructions) if p.is_file()]
dump('AGENTS_CHECK.json',{'checked':[str(p) for p in sorted(instructions)],'found':found})
assert not found,'Read applicable instructions: '+repr(found)
dump('INPUT_BASELINE.json',{'utc':datetime.now(timezone.utc).isoformat(),'files':protected,
    'scope':'Received packet and extracted inputs; original accepted investigation workspace; seven predecessor publication files actually used. No Git/index/status or unrelated-machine audit.'})
for name in ['manuscript','evidence','verification']:(E/name).mkdir(parents=True,exist_ok=True)
shutil.copytree(I/'accepted_investigation',E/'evidence/investigation')
(E/'evidence/current_gpt_review.md').write_bytes((I/'current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW.md').read_bytes())
(E/'evidence/manuscript_order.md').write_bytes((I/'NATIVE_SAME_TRAJECTORY_RETURN_PAPER_01_CODEX_WORK_ORDER.md').read_bytes())
with zipfile.ZipFile(I/'current_review/NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW_PACKAGE.zip') as z:
    m=json.loads(z.read('REVIEW_MANIFEST.json'))
    assert set(z.namelist())==set(m['payloads'])|{'REVIEW_MANIFEST.json'} and z.testzip() is None
    for name,row in m['payloads'].items():
        b=z.read(name);assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==row
    assert z.read('NATIVE_SAME_TRAJECTORY_RETURN_01_GPT_REVIEW.md')==(E/'evidence/current_gpt_review.md').read_bytes()
    assert z.read('inputs/NATIVE_SAME_TRAJECTORY_RETURN_01_REVIEW_PACKAGE.zip')==(I/'accepted_archive/NATIVE_SAME_TRAJECTORY_RETURN_01_REVIEW_PACKAGE.zip').read_bytes()
    for old,new in [('SYMBOLIC_REPLAY_REVIEW.json','reviewer_replay_summary.json'),('reviewer_replay/EXACT_CERTIFICATE_RESULTS.json','reviewer_exact_results.json')]:
        (E/'evidence'/new).write_bytes(z.read(old))
    dump('REVIEW_ARCHIVE_CHECKS.json',{'pass':True,'members':len(z.namelist()),'hashed_payloads':len(m['payloads']),'manifest_crc_sizes_hashes_pass':True,'review_and_investigation_originals_match':True,'scientific_replay_performed':False})
tectonic=Path('C:/TORMENT/TRIOCTAGON_new/reconstruction/publication/paper_C/build/tools/tectonic/tectonic.exe')
poppler=Path('C:/Users/Notandi/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
def version(tool,*args):
    p=subprocess.run([str(tool),*args],capture_output=True,check=True)
    return (p.stdout+p.stderr).decode('utf-8',errors='replace').strip()
dump('ENVIRONMENT.json',{'utc':datetime.now(timezone.utc).isoformat(),'python':sys.executable,'version':sys.version,
    'torment_modules':{name:bool(importlib.util.find_spec(name)) for name in ['pypdf','PIL']},
    'tectonic':str(tectonic),'tectonic_version':version(tectonic,'--version'),
    'pdftoppm':str(poppler/'pdftoppm.exe'),'pdftoppm_version':version(poppler/'pdftoppm.exe','-v'),
    'pdfinfo':str(poppler/'pdfinfo.exe'),'pdfinfo_version':version(poppler/'pdfinfo.exe','-v'),
    'inspection_python':'C:/Users/Notandi/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
    'installs':[],'scientific_helpers_executed':False,'git_operations':False})
print(json.dumps({'accepted_identities':len(expected),'primary_sources':len(source_record['sources']),'protected_files':len(protected),'review_archive_verified':True,'candidate':str(E)}))
