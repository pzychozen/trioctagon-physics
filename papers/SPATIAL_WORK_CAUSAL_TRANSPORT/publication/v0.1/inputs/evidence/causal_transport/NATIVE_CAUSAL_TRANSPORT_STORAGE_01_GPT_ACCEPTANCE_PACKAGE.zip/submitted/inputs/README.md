# Next research: causal transport and storage

**Start with:** `NATIVE_CAUSAL_TRANSPORT_STORAGE_01_CODEX_WORK_ORDER.md`.

The author authorized the next research assessment. GPT has prepared one explicit proposed extension and seven proof targets, T01–T07. This packet asks Codex to independently challenge them. It is not an acceptance receipt.

The main files are the work order, complete analytical start, `CLAIM_LEDGER.json`, `SOURCE_MAP.md`, the updated research list under `context/`, and `PAPER_PLAN.md`. Preserved sources and accepted W evidence accompany them.

The candidate adds traveling states and a mathematical receiving field with positive storage, while retaining the old native/receiver equations and explicitly changing the carrier force. C6 appears exactly as a direct observation component; loaded and startup terms remain explicit. No physical G aperture, curved route, receiver placement or clock is selected.

The next paper is planned to combine W01–W05 with the reviewed findings of this candidate. Codex should return `NATIVE_CAUSAL_TRANSPORT_STORAGE_01_REVIEW.zip` and its SHA-256 for GPT review. This task contains no repository or publication action.
