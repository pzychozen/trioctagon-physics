"""Current source/proof crosswalk and document consistency checks, not a proof checker."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re
ROOT=Path(__file__).resolve().parent.parent
assert os.environ.get('CONDA_DEFAULT_ENV')=='torment'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
locators=[]
def locate(key,path,label,marker=None,first_heading=False):
    p=ROOT/path;lines=p.read_text(encoding='utf-8').splitlines()
    found=[i+1 for i,line in enumerate(lines) if (line.startswith('# ') if first_heading else marker in line)]
    if first_heading:found=found[:1]
    assert len(found)==1,(path,label,found)
    locators.append({'id':key+'/'+label,'source_key':key,'path':path,'locator':label,'line':found[0],'line_text':lines[found[0]-1],'bytes':p.stat().st_size,'sha256':sha(p)})
analytic='inputs/NATIVE_CAUSAL_TRANSPORT_STORAGE_01_GPT_ANALYTICAL_START.md'
for n in range(1,25):locate('NEW',analytic,f'N{n}',r'\tag{N'+str(n)+'}')
tex={
 'CC-C':('inputs/sources/CC/carrier.tex',['eq:C1','eq:storage','eq:C6']),
 'CC-G':('inputs/sources/CC/geometry.tex',['eq:vertices','eq:G','eq:circleconstants','eq:circle']),
 'RX-C':('inputs/sources/RX/candidate.tex',['eq:drive','eq:tents','eq:ports','eq:storages','eq:system']),
 'RX-P':('inputs/sources/RX/power.tex',['eq:jacobian','eq:localwork','eq:balances']),
 'RX-W':('inputs/sources/RX/wellposed.tex',['eq:profilenorms','eq:lipschitzbounds','eq:energynorm','eq:duhamel','eq:dependence','eq:H1estimate']),
 'RX-H':('inputs/sources/RX/hybrid.tex',['eq:tuple','eq:prestage','eq:nativemap','eq:hybrid','eq:hybridbalance']),
 'RX-A':('inputs/sources/RX/accounts.tex',['eq:baselinewindow']),
}
for key,(path,labels) in tex.items():
    for label in labels:locate(key,path,label,r'\label{'+label+'}')
for n in range(1,6):
    locate('W','inputs/accepted/spatial_work/NATIVE_SPATIAL_WORK_REGISTRATION_01_PROOF_REVIEW.md',f'R{n}',f'## R{n}. W{n:02d}')
locate('W-ACCEPT','inputs/accepted/spatial_work/GPT_ACCEPTANCE.json','disposition','"disposition": "ACCEPTED_W01_W05_AS_STATED_AT_SPECIFIED_ASSUMPTIONS"')
locate('CAD','inputs/accepted/cadence/CORRECTIONS_AND_LIMITS.md','limits','## Remaining gaps')
locate('GEO','inputs/context/GEOMETRY_MODEL_BOUNDARY.md','document',first_heading=True)
locate('STATUS','inputs/context/TRIOCTAGON_RESEARCH_STATUS_2026-11-10.md','document',first_heading=True)
locate('ORDER','inputs/NATIVE_CAUSAL_TRANSPORT_STORAGE_01_CODEX_WORK_ORDER.md','D01','Zero new activity also requires empty new states.')
write(ROOT/'SOURCE_LOCATORS.json',{'task':'NATIVE_CAUSAL_TRANSPORT_STORAGE_01','scope':'Current retained local paths and one-based exact source lines; historical manifests retain their original scope.','count':len(locators),'locators':locators})
byid={r['id']:r for r in locators}
def ids(key):return [r['id'] for r in locators if r['source_key']==key]
def new(start,end):return [f'NEW/N{n}' for n in range(start,end+1)]
claim_sources={
 'T01':new(1,6)+['W/R1','W/R2','CC-C/eq:C6']+ids('CC-G'),
 'T02':new(7,11)+['NEW/N1','W/R1'],
 'T03':new(12,14)+ids('RX-C')+ids('RX-P'),
 'T04':['NEW/N1','NEW/N12','NEW/N15']+ids('RX-W'),
 'T05':new(16,17)+['CC-C/eq:C6','W/R2','W/R3','W/R5'],
 'T06':['NEW/N18','ORDER/D01','CAD/limits']+ids('RX-H')+ids('RX-A'),
 'T07':new(19,24)+['NEW/N6','RX-W/eq:profilenorms','RX-W/eq:H1estimate','CC-G/eq:G','CC-G/eq:circle'],
}
groups={'T01':['E01'],'T02':['E03'],'T03':['E02','E04'],'T04':[],'T05':['E01'],'T06':['E01'],'T07':['E05']}
limits={
 'T01':['Fixed positive bounded geometry and mathematical product measures.','C need not be contractive; CC* need not be invertible.','Spatial C* is not W temporal K_G*.'],
 'T02':['Time-integrated a.e. traces only for general L2 data.','No corner compatibility, ambient route or delay derivative assumed.'],
 'T03':['Declared new stocks and coefficients, not inherited physical calibration.','Old z and new zeta counted separately; receiving need not be monotone.'],
 'T04':['Fixed positive minimum delay and fixed finite allowed parameters.','Forward mild energy-space result, not global H1 or backward flow.','Finite-horizon dependence on bounded energy sets, no zero-delay uniformity.','Conservation follows component identities; it is not assumed to obtain local existence.'],
 'T05':['Arbitrary profiles retain the positive startup term.','Complete-history identity requires near-law and profile compatibility on negative times.','Direct C6 term is not the complete loaded drive.','Line preparation energy is not W signed prehistory work.'],
 'T06':['Finite iterates and correct post-jump baseline count only.','No uniform infinite-step bound or singular-prestage continuity.','Zero coupling recovers RX for arbitrary added preparation.','D01: emptiness sufficient, not necessary, for inactivity.','Old trajectory-dependent theorems require new hypothesis checks at positive coupling.'],
 'T07':['Strict activity example uses carrier preload and x0=z0=0.','Temporary H1 continuity used only before incoming return.','Nonzero b does not imply nonzero J*b, positive net work or native credit.','A.e. trace conclusion; no physical route or all-six allocation claim.'],
}
findings={
 'T01':['Exact J/C factorization and pointwise block Gram matrix.','Strictly positive scalar block and explicit normal-vector kernel.'],
 'T02':['Both orientation formulas retain arbitrary startup data.','Translation/Fubini give representative-independent L2 time traces.','Strong energy-state continuity and exact integrated boundary balance.'],
 'T03':['All sqrt(2) factors and signs reproduce N12.','Original RX cancellation plus new boundary work gives augmented conservation.','Consistent abstract units for new metrics and force.'],
 'T04':['Method of steps makes incoming signals known on each slab.','Forced local contraction precedes an interaction-picture work estimate.','Slab bound prevents blowup noncircularly; induction and component balances prove global existence/conservation.','Unique product-continuous state and finite-horizon continuous dependence.'],
 'T05':['Exact arbitrary-profile and compatible-history identities N16/N17.','Return, load and positive startup terms retained; all terms causal.'],
 'T06':['Only x jumps; original tuple, convention and order retained.','Exact baseline identity and every-finite-iterate existence.','Correct decoupling for nonempty added states; explicit D01 stationary-nullspace counterexample.'],
 'T07':['Zero receiving through theta_- and zero incoming b before 2 theta_-.','Strict receiving via scalar integrating factor and positive-measure sublevels.','Uniform early receiving bound and epsilon threshold yield strict negative scalar incoming return.'],
}
proof_name='NATIVE_CAUSAL_TRANSPORT_STORAGE_01_PROOF_REVIEW.md';proof=ROOT/proof_name
text=proof.read_text(encoding='utf-8');lines=text.splitlines();sections={}
for n in range(1,9):
    found=[i+1 for i,line in enumerate(lines) if line.startswith(f'## R{n}. ')]
    assert len(found)==1;sections[n]=found[0]
initial=json.loads((ROOT/'inputs/CLAIM_LEDGER.json').read_text(encoding='utf-8'))
claims=[]
for n,c in enumerate(initial['claims'],1):
    id=c['id'];assert id==f'T{n:02d}'
    claims.append({'id':id,'title':c['title'],'status':'verified-as-stated','submitted_assumptions':c['assumptions'],'submitted_proof_location':c['proof_location'],'independent_challenge_targets':c['independent_challenge_targets'],'proof_location':{'path':proof_name,'section':f'R{n}','start_line':sections[n],'end_line':sections[n+1]-1,'sha256':sha(proof)},'source_locations':[byid[s] for s in claim_sources[id]],'findings':findings[id],'computation':{'groups':groups[id],'code':'checks/exact_checks.py' if groups[id] else None,'record':'logs/EXACT_CHECKS.json' if groups[id] else None,'scope':'Algebraic corroboration only; written proofs establish infinite-dimensional and quantified claims.'},'mathematical_correction':None,'documentary_corrections':['D01'] if id=='T06' else [],'limits':limits[id]})
d01={'id':'D01','kind':'work_order_necessity_wording','source_locator':byid['ORDER/D01'],'submitted_wording':'Zero new activity also requires empty new states.','corrected_statement':'At kappa=0, empty added states are sufficient, not necessary, for inactivity; arbitrary prepared added states may evolve.','counterexample':'u_plus=u_minus=0, zeta_0(X)=(0,h(X)n) nonzero with n perpendicular to the carrier plane. C*zeta_0=0; all boundary waves vanish and zeta stays constant.','proof_location':{'path':proof_name,'section':'R6.2'},'candidate_equations_changed':False,'analytical_start_section_8_already_correct':True,'effect_on_T06_analytical_claim':'verified-as-stated'}
write(ROOT/'CLAIM_LEDGER.json',{'task':'NATIVE_CAUSAL_TRANSPORT_STORAGE_01','reviewer':'Codex','date':'2026-11-10','disposition':'T01_T07_VERIFIED_AS_STATED_WITH_D01_WORK_ORDER_CLARIFICATION','gpt_author_acceptance':'Not claimed; returned for subsequent review.','claims':claims,'mathematical_corrections':[],'documentary_corrections':[d01],'logical_order_note':'R3 establishes port algebra; R4 proves local component work and slab continuation before deriving augmented conservation. No total conservation is assumed to obtain existence.','scope':'Independent local candidate assessment, not physical adoption, manuscript or publication.'})

identities=json.loads((ROOT/'INPUT_IDENTITIES.json').read_text(encoding='utf-8'))
for row in identities['files']:
    p=ROOT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
execution=json.loads((ROOT/'logs/EXECUTION_RECORD.json').read_text(encoding='utf-8'))
assert len(execution['executions'])==2 and all(row['exit_status']==0 for row in execution['executions'])
algebra=json.loads((ROOT/'logs/EXACT_CHECKS.json').read_text(encoding='utf-8'))
assert algebra['status']=='PASS' and algebra['group_count']==5 and all(row['status']=='PASS' for row in algebra['groups'])
tags=re.findall(r'\\tag\{(R[0-9]+\.[0-9]+)\}',text)
assert len(tags)==len(set(tags))
assert all(k in tags for k in re.findall(r'\((R[0-9]+\.[0-9]+)\)',text))
link_count=0
for name in (proof_name,'README.md','RESULT_SUMMARY.md','CORRECTIONS_AND_LIMITS.md'):
    content=(ROOT/name).read_text(encoding='utf-8')
    assert content.count('\\[')==content.count('\\]'),name
    assert content.count('\\(')==content.count('\\)'),name
    assert not re.search(r'\b(?:TODO|TBD|FIXME)\b',content),name
    for target in re.findall(r'\]\(([^)]+)\)',content):
        if '://' not in target:
            assert (ROOT/target.split('#')[0]).is_file(),(name,target)
            link_count+=1
result={'status':'PASS','observed_utc':datetime.now(timezone.utc).isoformat(),'command':'run_python.cmd checks\\prepare_records.py','source_locators':len(locators),'proof_equation_tags':len(tags),'current_local_links_resolved':link_count,'claims':{c['id']:c['status'] for c in claims},'mathematical_corrections':0,'documentary_clarifications':['D01'],'preserved_input_members_rechecked':len(identities['files']),'actual_algebra_groups_passed':5,'proof_sha256':sha(proof),'scope':'Document/provenance consistency; mathematical verification is the independent written proof.'}
write(ROOT/'logs/DOCUMENT_CHECKS.json',result)
print(json.dumps({k:result[k] for k in ('status','source_locators','proof_equation_tags','current_local_links_resolved','claims','documentary_clarifications')},indent=2))
