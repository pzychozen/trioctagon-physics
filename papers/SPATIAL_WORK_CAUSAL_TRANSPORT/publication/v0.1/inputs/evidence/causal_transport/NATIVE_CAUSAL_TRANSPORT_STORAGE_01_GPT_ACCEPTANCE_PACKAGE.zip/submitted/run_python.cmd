@echo off
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
if errorlevel 1 exit /b %errorlevel%
set PYTHONUTF8=1
cd /d C:\TORMENT\TRIOCTAGON_new\research\NATIVE_CAUSAL_TRANSPORT_STORAGE_01
python %*
exit /b %errorlevel%
