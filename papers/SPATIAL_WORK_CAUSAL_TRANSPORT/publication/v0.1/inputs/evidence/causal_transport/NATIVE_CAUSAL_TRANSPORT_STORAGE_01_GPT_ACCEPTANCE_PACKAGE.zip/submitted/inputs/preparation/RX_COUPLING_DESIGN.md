# Proposed causal delay-bank connection to retained RX

**Status:** constructive GPT mathematical candidate and proof development, not independent acceptance or adoption as a physical route.  
**Date:** 10 November 2026.  
**Scope:** a new causal connection with explicit positive storage; native/RX parameters, old native and z laws, and finite hybrid conventions retained. No publication audit or old-suite execution.

This note develops the isometric-fan-out formulation coordinated with root and `route_lemma_review`. Its main point is that the bounded C6 mixing operator can be used in an effort/flow transformer without requiring it to be a contraction. This does not make its loaded transfer identical to the original unloaded C6 observation.

| Proposed challenge target | Location below |
| --- | --- |
| T01 — J/C factorization, adjoints and CC* | §§1, 8 |
| T02 — transport characteristics and line power | §§2, 5 |
| T03 — closed RX/line/new-receiver balance | §§3–4 |
| T04 — global forward energy-space mild well-posedness | §6 |
| T05 — exact C6/startup/return relation | §5 |
| T06 — every finite hybrid iterate and kappa=0 decoupling | §7 |
| T07 — causal first-arrival/return bounds and nontrivial preloaded-carrier receiving | §8 |

## 1. Spaces, static delays and bounded maps

Fix one admitted static registered geometry, common width and hand. Let S be the periodic carrier of length L, and let G be the disjoint labeled union of the actual six broken arcs, with their mathematical arclength measure and total length M>0. These are the W01–W05 conventions; no aperture is closed and no surface power density is selected.

Use real Hilbert spaces

\[
\mathcal Q=L^2(S;\mathbb R^2),\qquad
\mathcal V=L^2(S\times G;\mathbb R^2),\qquad
\mathcal Z=L^2(G;\mathbb R^4).
\]

Write Q=(p,r_c), d(s,X)=|X−gamma(s)|, theta(s,X)=d(s,X)/c_e, and

\[
0<\theta_{\min}\le\theta(s,X)\le\theta_{\max}<\infty.
\]

The accepted clearance and finite geometry provide these bounds. The constants c_e>0 and g_o>0 remain symbolic and independent of the original carrier speed c. Let a_o=g_o/(4 pi), and A_s(p,r)=(p,r t_hat(s)), the source's 4-by-2 isometry.

Define

\[
(JQ)(s,X)=\frac{Q(s)}{\sqrt M},\qquad
(J^*v)(s)=\frac1{\sqrt M}\int_Gv(s,X)\,d\ell_X,
\quad J^*J=I,
\]
\[
(Cv)(X)=a_o\sqrt M\int_S\frac{A_sv(s,X)}{d(s,X)}\,ds,
\qquad
(C^*\zeta)(s,X)=\frac{a_o\sqrt M}{d(s,X)}A_s^*\zeta(X).
\]

Thus C is bounded, with `||C|| ≤ a_o sqrt(ML)/delta` for an admitted clearance delta>0. No norm-smallness or contraction condition is imposed. On complete histories, if D_theta denotes channelwise time delay, the original C6 operator factorizes exactly as

\[
\mathcal K_G=C D_\theta J.
\]

This is an observation factorization; it does not identify Q with a transported wave or define physical work units. All new coupling/storage normalizations below are explicit proposed mathematical choices. They provide a consistent quadratic account; they are not SI calibration or source-selected coefficients.

## 2. New transport state and its positive storage

For every pair e=(s,X), introduce two **new** R2-valued waves u_+(e,r,t), u_-(e,r,t) on `0<r<theta(e)`, satisfying

\[
\partial_tu_++\partial_ru_+=0,\qquad
\partial_tu_- -\partial_ru_-=0.
\]

The coordinate r is a travel-time coordinate, not a declared ambient curve, tube or material path. These waves are neither the original p,r_c nor the original carrier characteristics `(p±r_c)/sqrt(2)`.

Their energy space is the L2 space of the variable interval bundle, with

\[
E_{\rm tr}=\frac12\int_{S\times G}\int_0^{\theta(s,X)}
(|u_+|^2+|u_-|^2)\,dr\,ds\,d\ell_X\ge0.
\]

Use the boundary names

\[
a=u_+(0),\quad b=u_-(0),\qquad
c=u_+(\theta),\quad d=u_-(\theta).
\]

Here a travels into the bank from the carrier; b is its return; c arrives at G; d returns from the far interaction. The endpoint energy identity is

\[
\dot E_{\rm tr}
=\frac12(\|a\|^2-\|b\|^2+\|d\|^2-\|c\|^2).
\tag{T}
\]

For L2 initial lines and locally L2 boundary signals, the integrated version follows directly from the characteristic formulas and time translation. It does not require pointwise traces of arbitrary L2 initial data.

## 3. Proposed near and far interfaces

Choose symbolic kappa≥0 and beta_G>0, with kappa>0 for the nontrivial receiving witness. Keep all original RX native and old z-receiver equations, B/B*, stores and parameters unchanged. Add only the following declared carrier forcing:

\[
\boxed{a=\sqrt2\kappa JQ-b,\qquad
F=-\kappa^2Q+\sqrt2\kappa J^*b.}
\tag{N}
\]

The two components of F enter the p and r_c equations as in W05. This introduces bounded carrier damping and a causal return signal; it changes the extended trajectory and is not a claim that the unforced RX solution remains identical.

For a concrete far-end example, introduce a **new proposed distributed receiving state** zeta∈Z with

\[
H_G=\frac{\beta_G}{2}\|\zeta\|_{\mathcal Z}^2,
\qquad
\boxed{d=\sqrt2C^*\zeta-c,\qquad
\beta_G\dot\zeta=\sqrt2Cc-CC^*\zeta.}
\tag{G}
\]

Zeta is not the old two-component z. It is a declared mathematical receiver field indexed by the G test domain, not a recovered material receiver or an irreversible sink. Some components can be dynamically dark (for example the vector direction normal to the selected carrier plane); this does not invalidate the positive storage or balance.

The interface is an effort/flow connection. At the near end, effort `(a+b)/sqrt(2)=kappa JQ` and flow `(a−b)/sqrt(2)` have product `(||a||²−||b||²)/2`; F is minus the adjoint-transformed flow. At the far end, effort `(c+d)/sqrt(2)=C* zeta` and receiving flow `(c−d)/sqrt(2)` give the opposite line-end power. Since both directions are retained, C need not be contractive.

An alternative passive far component could be analyzed later by specifying its actual state, storage and matching effort/flow relation. “Arbitrary passive load” is not a well-posedness theorem without those definitions. The quadratic example above is enough for a complete present candidate.

## 4. Exact total balance

W05 gives

\[
\dot H_{\rm RX}=\langle Q,F\rangle
=-\kappa^2\|Q\|^2+\sqrt2\kappa\langle JQ,b\rangle.
\]

Using J*J=I and (N),

\[
\frac12(\|a\|^2-\|b\|^2)
=\kappa^2\|Q\|^2-\sqrt2\kappa\langle JQ,b\rangle
=-\dot H_{\rm RX}.
\]

Similarly, (G) gives

\[
\dot H_G=\sqrt2\langle C^*\zeta,c\rangle-\|C^*\zeta\|^2
=\frac12(\|c\|^2-\|d\|^2).
\]

Together with (T),

\[
\boxed{H_{\rm RX}(t)+E_{\rm tr}(t)+H_G(t)
=H_{\rm RX}(0)+E_{\rm tr}(0)+H_G(0).}
\tag{E}
\]

All three stores are nonnegative. H_RX already includes the original receiver store H_R; it is counted once. H_G can both gain and return storage. There is no assertion of monotonic receiving, irreversible dissipation, exact efficiency or physical energy calibration.

## 5. Startup terms, causality and the loaded transfer

For arbitrary finite-energy initial line profiles u_{±,0}, the exact incoming signals are, almost everywhere,

\[
b(e,t)=\begin{cases}u_{-,0}(e,t),&t<\theta(e),\\
d(e,t-\theta(e)),&t\ge\theta(e),\end{cases}
\]
\[
c(e,t)=\begin{cases}u_{+,0}(e,\theta(e)-t),&t<\theta(e),\\
a(e,t-\theta(e)),&t\ge\theta(e).
\end{cases}
\]

Let D_theta^+ be the one-sided delay with zero extension of its boundary input. Then `b=D_theta^+ d+rho_-` and `c=D_theta^+ a+rho_+`, where rho_- and rho_+ are exactly the displayed initial-profile terms. Each startup signal is locally L2; its full time-integrated squared norm equals the corresponding initial wave norm squared.

Consequently

\[
\beta_G\dot\zeta
=2\kappa C D_\theta^+JQ
-\sqrt2 C D_\theta^+b+\sqrt2C\rho_+-CC^*\zeta.
\tag{L}
\]

The shorter expression with `2 kappa K_G Q` and no rho term requires compatible complete boundary histories, including the negative-time near interface law. It does not follow from arbitrary initial line fields. The one-sided factor `C D_theta^+J` is algebraically C6 applied to a zero-extended Q; describing that algebra does not silently choose the original diagnostic's missing prehistory.

Under loading, the launched wave is `a=sqrt(2) kappa JQ−b`, not JQ. Thus c and the receiver drive are not the original C6 output: returned waves and the receiving field contribute to (L). The original C6 observation may still be evaluated separately on the actual Q history when that history is supplied. It remains a diagnostic, not the new receiver stock or its full loaded transfer.

Every return signal depends on earlier boundary data, with strictly positive delay. There is no advanced test input and no application of the finite-window Hilbert adjoint as an instantaneous force. Existing bank state, rather than a discarded prehistory integral, accounts for earlier transport content.

## 6. Forward global energy-space well-posedness: method-of-steps argument

**Proposed theorem.** For fixed bounded J,C, positive beta_G, finite kappa, and `0<theta_min≤theta≤theta_max<infinity`, the stated quadratic-load candidate has a unique global forward mild solution for every finite-energy preparation of RX, the two line fields and zeta. It satisfies (E). The finite-dimensional native/old-z variables are C1; Q and all state components are continuous in their energy spaces; zeta is H1 in time on finite intervals. No automatic H1 spatial regularity of Q or classical line trace compatibility is claimed for general finite-energy data.

**Construction.** Choose step length h≤theta_min. On `[nh,(n+1)h]`, incoming b,c are known from initial line profiles or already constructed boundary histories. Values at a single slab endpoint are irrelevant to L2 identities. The time translations in the characteristic formulas show that these known inputs are L2 on the slab.

The far equation is a Hilbert-space ODE with bounded nonnegative operator CC* and known L2 forcing. It has a unique continuous H1-time solution. The near subsystem is original semilinear RX, with the bounded linear term `−kappa² Q` and the known L2-time forcing `sqrt(2) kappa J* b`. The original carrier translation group and locally Lipschitz RX nonlinearity give a local mild solution by the same integral-contraction construction, now with a continuous inhomogeneous convolution. An L2 input is locally L1 in time, which suffices for that construction.

Form outgoing a,d from the boundary laws and then reconstruct the line fields by characteristics. The outgoing histories are locally L2 because Q,zeta are continuous and b,c are locally L2. This closes each method-of-steps slab without an implicit same-time boundary loop.

**Legitimate energy identity without extra spatial regularity.** Let S(t) be the original unitary carrier group and put B_0 q=(Bq,0). The mild formula implies that `v(t)=S(−t)Q(t)` is absolutely continuous whenever `B_0 q+F` is locally L1 in the carrier Hilbert space. Its derivative is `S(−t)(B_0 q+F)` almost everywhere. Since S(t) is unitary, the Hilbert-space chain rule gives

\[
\frac{d}{dt}\frac{\|Q(t)\|^2}{2}
=\langle Q(t),B_0q(t)+F(t)\rangle
\quad\hbox{a.e.}
\]

Thus no H1 carrier assumption or formal differentiation of its skew generator is needed. Native/old-z derivatives remain ordinary C1 identities. The line integrated identity is exact for L2 initial profiles and boundary histories by time translation/Fubini, and the far Hilbert-space ODE has the ordinary absolutely continuous squared-norm identity. Their sum proves (E) before continuation is invoked. This interaction-picture argument was also noted independently by `route_lemma_review` during coordination.

**Global continuation.** The nonnegative conserved total bounds native state, old receiver, Q, zeta and both line fields. On a slab the already known input has finite L2 norm, so the locally Lipschitz RX problem cannot have a finite blowup while these state norms remain bounded. Complete the slab, and iterate. Only finitely many slabs are needed on any finite horizon because theta_min>0. This establishes global forward existence, uniqueness and finite-horizon continuous dependence. Local Lipschitz dependence on bounded energy sets follows by the corresponding slab estimates. No uniform infinite-time regularity bound, positive theta_min→0 limit, or backward-group assertion is needed.

These are proof steps for the new candidate and require independent challenge before acceptance. The old RX theorem alone is not cited as proving the new interconnection.

## 7. Finite hybrid windows

At each original native F jump, change only the native x exactly as before. Q, old z, zeta and both line states remain unchanged; there are no new impulses. The continuous interconnection preserves the enlarged total, so post-jump endpoint windows obey

\[
\boxed{\Delta(H_{\rm RX}+E_{\rm tr}+H_G)
=\sum_{0<t_j\le T}\frac{\alpha_N}{2}
[I(F_{\rm native}\Omega(t_j^-))-I(\Omega(t_j^-))].}
\]

The tuple, Arg0 convention, F-first order and symbolic dwell remain inherited. A finite sequence of these well-defined jumps and global forward exchange stages gives a finite hybrid solution. Do not infer infinite-step bounds or global continuity through the native map's singular prestage strata. This preserves the original baseline accounting; it does not make the full native hybrid a physically closed conservative system.

At kappa=0, F=0 exactly and the entire original RX subsystem is autonomous and unchanged, even if the separate bank/new receiver is preloaded. The near bank endpoint becomes the lossless reflection a=−b. If that bank and zeta are also initially empty, they stay empty. This is actual decoupling, not only a limiting assertion. “Every finite hybrid iterate” does not assert uniform infinite-step energy bounds, old capacity invariants for the extension, or persistence of a native coherent domain under the new carrier interaction.

## 8. Nontrivial receiving witness from a carrier preload

This shows that the new receiver is active; it does not reuse or extend an old native-supply/capacity theorem. Assume kappa>0 here.

Take Q(s,0)=(P,0) with P>0 constant, x(0)=old z(0)=zeta(0)=0, and empty initial lines. This is a finite-energy **mild** preparation. Since a(0)=sqrt(2) kappa JQ0 is nonzero while the line is initially empty, it has a boundary corner incompatibility; it is not globally H1-compatible classical line data.

Before theta_min, c=d=zeta=0. Therefore b=0 for `0<t<2 theta_min`. On this interval the carrier is the original RX subsystem plus `−kappa²Q`. Its H1 preload, fixed H1 tents and continuous original ports give Q∈C_tH1 locally. Choose `0<epsilon<theta_min` so that `p(s,u)>P/2` for all s and `0≤u≤epsilon`.

For `theta_min<t<theta_min+epsilon`, the scalar arriving component is

\[
c_p(s,X,t)=\frac{\sqrt2\kappa}{\sqrt M}
\mathbf1_{t>\theta(s,X)}p(s,t-\theta(s,X)).
\]

It is nonnegative, and positive on every arriving channel. Moreover CC* is block diagonal between scalar and vector receiver components:

\[
CC^*\zeta(X)=a_o^2M\int_S\frac{\operatorname{diag}(1,\hat t\hat t^T)}{d(s,X)^2}\,ds\;\zeta(X).
\]

Writing m(X)=a_o² M∫_S d(s,X)^{-2}ds>0, the scalar zeta component satisfies

\[
\beta_G\partial_t\zeta_0(X,t)+m(X)\zeta_0(X,t)
=2\kappa a_o\int_{\theta(s,X)<t}
\frac{p(s,t-\theta(s,X))}{d(s,X)}\,ds.
\tag{R}
\]

The integrating-factor solution is nonnegative. For any t strictly above theta_min in this interval, choose a time v between theta_min and t. Continuity of theta on the compact circle/segment family provides a positive-measure pair patch with theta<v (a minimum at a segment endpoint still has one-sided neighboring patches). The right side is strictly positive on a positive-measure set of X and a nonempty time interval before t. Thus

\[
H_G(t)=0\quad(0\le t\le\theta_{\min}),\qquad
H_G(t)>0\quad(\theta_{\min}<t<\theta_{\min}+\epsilon).
\]

This onset statement belongs only to the stated positive preload, empty lines and empty new receiver. It is not a universal sharp-arrival theorem for arbitrary preparations. Native x=0 stays zero, so no native supply/recovery is claimed; the initial storage source is the carrier preload. The old z can receive as well and is included correctly in H_RX.

**A nontrivial return for this same preparation.** The earlier argument already gives b=0 for `t<2 theta_min`. One can also show a nonzero return immediately after that threshold, in the characteristic boundary representative, by shrinking epsilon. Choose the initial continuity interval with `|Q(s,u)|≤2P`. For `theta_min≤v≤theta_min+epsilon`,

\[
\|Cc(v)\|_{L^\infty_X}\le 2\sqrt2\kappa a_oPL/\delta,
\qquad
\|\zeta(v)\|_{L^\infty_X}
\le \frac{4\kappa a_oPL}{\beta_G\delta}(v-\theta_{\min}),
\]

because the pointwise matrix CC* is nonnegative and its exponential is a contraction. Hence the far term `sqrt(2) C* zeta` tends uniformly to zero at arrival. On every arriving channel, `c_p≥kappa P/sqrt(2M)`. Taking, for example, epsilon small enough that

\[
\epsilon<\frac{\beta_G\delta^2}{16a_o^2ML}
\]

in addition to the preceding continuity/delay restrictions makes the absolute value of the scalar `sqrt(2) C* zeta` smaller than half that lower bound. For `2 theta_min<t<2 theta_min+epsilon`, every channel with `theta(s,X)<t/2` therefore has

\[
b_p(s,X,t)=d_p(s,X,t-\theta(s,X))
< -\frac{\kappa P}{2\sqrt{2M}}<0.
\]

That channel sublevel set has positive product measure for every such t, so `||b(t)||_V>0`. No value at the single onset time is needed for an L2 boundary signal. These are preparation-specific first-onset statements for the proposed delay bank; they do not prove arrival or return for arbitrary initial states, nor a physical toroidal circuit.

## 9. What this candidate does and does not decide

The construction supplies actual causal extra forcing, a new transport state, a declared reversible receiving state and an exact nonnegative total storage. It provides a constructive alternative to treating an advanced history adjoint as a causal load. The zero near-coupling limit recovers the original RX subsystem, while bank/receiver states can remain a separate component.

It does not prove that C6 is the author's physical route, that the abstract delay coordinate follows a tight toroid, that G is a material aperture, or that the new receiver has a justified physical constitution. It does not preserve bare C6 as the full loaded through-transfer and does not identify a new wave with p or r_c. There is no selected diversion fraction, irreversibility, SI calibration or physical cadence. These remain distinct interpretation/model choices.

