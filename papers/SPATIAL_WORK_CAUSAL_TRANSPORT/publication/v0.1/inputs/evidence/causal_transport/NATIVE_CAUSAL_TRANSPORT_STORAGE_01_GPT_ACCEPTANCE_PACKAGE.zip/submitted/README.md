# NATIVE_CAUSAL_TRANSPORT_STORAGE_01: independent review return

Read the [result summary](RESULT_SUMMARY.md), then the [complete proof review](NATIVE_CAUSAL_TRANSPORT_STORAGE_01_PROOF_REVIEW.md).

T01-T07 are verified as stated in the analytical start, at their submitted assumptions. D01 corrects only necessity-sounding work-order wording about inactivity; no candidate equation or mathematical theorem is replaced. This is Codex's review for GPT/author assessment, not a physical-model adoption or publication order.

- [CLAIM_LEDGER.json](CLAIM_LEDGER.json): dispositions, assumptions, current source/proof locators, exact-check roles and limits.
- [CORRECTIONS_AND_LIMITS.md](CORRECTIONS_AND_LIMITS.md): D01 and all retained mathematical/physical qualifications.
- [INPUT_IDENTITIES.json](INPUT_IDENTITIES.json): preserved ZIP/member/source identity verification.
- [SOURCE_LOCATORS.json](SOURCE_LOCATORS.json): current one-based source line locators and hashes.
- `inputs/`: all unchanged supplied members, including accepted W evidence and the updated research list. The original supplied ZIP is also retained at the review root.
- `checks/` and `logs/`: independent check code, actual environment, outputs, commands and exit statuses.
- `MANIFEST.json`: self-excluded inventory of the complete review ZIP.

From this directory, use Command Prompt to rerun only the new task's validator and five algebra groups:

```bat
run_python.cmd checks\run_checks.py
```

The wrapper activates the existing `torment` environment. No packages were installed. The old accepted scientific investigations are inputs, not rerun tests. Functional-analytic and all-time conclusions are established in the written proofs.

The complete ZIP and its SHA-256 checksum are under `delivery/`, with an external archive verification receipt. The standalone proof also has a SHA-256 file. Historical records retain their original scope; current claim locators resolve to the retained files in this return.
