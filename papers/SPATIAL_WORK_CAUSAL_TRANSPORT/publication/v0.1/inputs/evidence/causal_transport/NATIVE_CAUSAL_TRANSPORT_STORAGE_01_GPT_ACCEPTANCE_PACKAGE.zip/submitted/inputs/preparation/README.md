# GPT internal preparation

These notes are internal design and adversarial checks used to prepare the proposed analytical start. They are not independent Codex acceptance. The final analytical start and CLAIM_LEDGER.json define T01–T07. Optional comparisons and stronger formulas in these notes are not additional commissioned claims.

No previous publication or accepted scientific suite was rerun. The new candidate, metrics and boundary conditions remain a mathematical proposal. Codex must challenge the proofs directly.
