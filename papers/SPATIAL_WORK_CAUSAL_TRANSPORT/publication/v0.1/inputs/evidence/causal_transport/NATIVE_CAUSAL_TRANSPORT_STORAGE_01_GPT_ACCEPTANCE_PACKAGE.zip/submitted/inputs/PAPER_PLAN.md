# Current paper decision

**Decision:** Complete the constructive candidate assessment before drafting the next manuscript. Combine accepted W01–W05 with the candidate's reviewed findings in one paper.

This is the editorial plan chosen after the author's 10 November request to update the list and start the next research. It does not reopen the already published central-route/six-opening paper.

## Intended argument

1. Establish the inherited spatial setting and summarize the accepted W observation/adjoint/work results with their finite-window and history qualifications.
2. Declare every new state, metric, coefficient and boundary relation in the proposed causal extension.
3. Prove its transport and coupled work accounts, with the correct energy-space existence and initial-preparation scope if verified.
4. State exactly how C6 remains a diagnostic/direct component, retaining load, return and startup terms.
5. Present the reviewed receiving/return witness and native-step account without transferring older capacity/recovery results automatically.
6. Explain what remains unassigned about the physical central/outward/curved-return route and the material role of G.

The paper should distinguish inherited definitions, proposed constitutive choices, proved mathematical properties and unestablished physical correspondences. Established delay-line methodology should be cited; general wave-variable passivity is not a novelty claim.

The manuscript plan does not assume the proposed candidate will pass. Corrections, restrictions or failure revealed by independent review determine the actual paper scope. If the constructive claims need a different candidate, resolve that change before commissioning a manuscript that presents it as a positive result.

## Gates

The current deliverable is a Codex proof-review packet. GPT reviews that return next. Manuscript drafting and author/manuscript review follow a sufficiently settled result. Publication is a later separately authorized action.

No page count, publication edition or final title is fixed at this stage. There is no need for a standalone W paper before the current constructive assessment.
