from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,platform,sys,zipfile
import sympy

ROOT=Path(__file__).resolve().parent.parent;INPUTS=ROOT/'inputs'
assert os.environ.get('CONDA_DEFAULT_ENV')=='torment'
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
manifest=json.loads((INPUTS/'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
sources=json.loads((INPUTS/'SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
archive=ROOT/'NATIVE_CAUSAL_TRANSPORT_STORAGE_01_CODEX_PACKET.zip'
assert archive.read_bytes()==(Path('C:/Users/Notandi/Downloads')/archive.name).read_bytes()
rows=[]
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist();assert len(names)==len(set(names))
    assert set(names)=={r['path'] for r in manifest['files']}|{'PACKET_MANIFEST.json'}
    assert set(names)=={p.relative_to(INPUTS).as_posix() for p in INPUTS.rglob('*') if p.is_file()}
    for name in names:
        data=(INPUTS/name).read_bytes();assert data==z.read(name)
        rows.append({'path':'inputs/'+name,'bytes':len(data),'sha256':sha(data),'matches_zip':True})
for r in manifest['files']:
    data=(INPUTS/r['path']).read_bytes()
    assert len(data)==r['bytes'] and sha(data)==r['sha256'],r['path']
assert len(manifest['files'])==manifest['file_count']
source_rows=[]
for r in sources['sources']:
    path=r.get('packet_path',r.get('path'));data=(INPUTS/path).read_bytes()
    assert len(data)==r['bytes'] and sha(data)==r['sha256'],path
    if r.get('expected_sha256'):assert sha(data)==r['expected_sha256'],path
    for key in ('git_blob','expected_git_blob'):
        if r.get(key):assert blob(data)==r[key],(path,key)
    source_rows.append({'path':'inputs/'+path,'bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'registered_identity_matches':True})
assert len(source_rows)==sources['source_count']
accepted=INPUTS/'accepted/spatial_work'
nested=accepted/'NATIVE_SPATIAL_WORK_REGISTRATION_01_GPT_ACCEPTANCE_PACKAGE.zip'
assert sha(nested.read_bytes())==nested.with_suffix('.zip.sha256').read_text(encoding='utf-8').split()[0]
acceptance=json.loads((accepted/'GPT_ACCEPTANCE.json').read_text(encoding='utf-8'))
proof=accepted/'NATIVE_SPATIAL_WORK_REGISTRATION_01_PROOF_REVIEW.md'
assert sha(proof.read_bytes())==acceptance['reviewed_proof']['sha256']
environment={'observed_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'conda_environment':os.environ.get('CONDA_DEFAULT_ENV'),'conda_prefix':os.environ.get('CONDA_PREFIX'),'sympy_version':sympy.__version__,'command':'run_python.cmd checks\\validate_inputs.py','working_directory':str(ROOT)}
result={'task':'NATIVE_CAUSAL_TRANSPORT_STORAGE_01','status':'PASS','environment':environment,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'matches_download':True},'packet_members':len(rows),'manifest_entries_verified':len(manifest['files']),'source_identities_verified':len(source_rows),'accepted_W_binding':{'acceptance_archive_sha256':sha(nested.read_bytes()),'supplied_checksum_matches':True,'proof_sha256':sha(proof.read_bytes()),'matches_acceptance_record':True},'discrepancies':[],'recovery_required':False,'files':rows,'source_checks':source_rows,'scope':'Local input identities only; accepted investigations and publication not re-executed or re-audited.'}
(ROOT/'INPUT_IDENTITIES.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(ROOT/'logs').mkdir(exist_ok=True)
(ROOT/'logs/ENVIRONMENT.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ('status','archive','packet_members','manifest_entries_verified','source_identities_verified','accepted_W_binding','discrepancies')},indent=2))
print(json.dumps(environment,indent=2))
