from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys
assert os.environ.get('CONDA_DEFAULT_ENV')=='torment'
ROOT=Path(__file__).resolve().parent.parent;(ROOT/'logs').mkdir(exist_ok=True)
records=[]
for name in ('validate_inputs','exact_checks'):
    command=[sys.executable,str(ROOT/'checks'/f'{name}.py')]
    start=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    (ROOT/'logs'/f'{name}.stdout.txt').write_text(result.stdout,encoding='utf-8')
    (ROOT/'logs'/f'{name}.stderr.txt').write_text(result.stderr,encoding='utf-8')
    records.append({'check':name,'command':command,'started_utc':start,'completed_utc':datetime.now(timezone.utc).isoformat(),'exit_status':result.returncode,'stdout':f'logs/{name}.stdout.txt','stderr':f'logs/{name}.stderr.txt'})
    print(result.stdout,end='');print(result.stderr,end='',file=sys.stderr)
    if result.returncode:break
(ROOT/'logs/EXECUTION_RECORD.json').write_text(json.dumps({'entry_command':'run_python.cmd checks\\run_checks.py','activation':'Command Prompt: conda activate torment','executions':records},indent=2)+'\n',encoding='utf-8')
sys.exit(records[-1]['exit_status'])
