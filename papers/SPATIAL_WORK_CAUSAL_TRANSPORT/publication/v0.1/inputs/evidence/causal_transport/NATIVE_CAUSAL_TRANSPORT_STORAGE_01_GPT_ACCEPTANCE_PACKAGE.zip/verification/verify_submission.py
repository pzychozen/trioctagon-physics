"""Verify the current T review's bytes and evidence links; run no scientific suite."""
from pathlib import Path
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parents[1]
UPLOAD = BASE / 'upload'
SUBMITTED = ROOT / 'submitted'
sha = lambda b: hashlib.sha256(b).hexdigest()
read_json = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))

archive = UPLOAD / 'NATIVE_CAUSAL_TRANSPORT_STORAGE_01_REVIEW.zip'
raw = archive.read_bytes()
expected = (UPLOAD / (archive.name + '.sha256')).read_text().split()[0]
assert sha(raw) == expected
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 90
    assert z.testzip() is None
    manifest = json.loads(z.read('MANIFEST.json'))
    assert manifest['file_count'] == len(manifest['files']) == 89
    assert {r['path'] for r in manifest['files']} == set(names) - {'MANIFEST.json'}
    for r in manifest['files']:
        b = z.read(r['path'])
        assert len(b) == r['bytes'] and sha(b) == r['sha256'], r['path']
    for n in names:
        assert z.read(n) == (SUBMITTED / n).read_bytes(), n
    for supplied, embedded in [
        ('NATIVE_CAUSAL_TRANSPORT_STORAGE_01_PROOF_REVIEW.md', 'NATIVE_CAUSAL_TRANSPORT_STORAGE_01_PROOF_REVIEW.md'),
        ('RESULT_SUMMARY(1).md', 'RESULT_SUMMARY.md')
    ]:
        assert (UPLOAD / supplied).read_bytes() == z.read(embedded), supplied
    proof = z.read('NATIVE_CAUSAL_TRANSPORT_STORAGE_01_PROOF_REVIEW.md')
    assert sha(proof) == z.read('NATIVE_CAUSAL_TRANSPORT_STORAGE_01_PROOF_REVIEW.md.sha256').decode().split()[0]
    packet_name = 'NATIVE_CAUSAL_TRANSPORT_STORAGE_01_CODEX_PACKET.zip'
    packet = z.read(packet_name)
    assert packet == (BASE / 'deliverables' / packet_name).read_bytes()
    with zipfile.ZipFile(io.BytesIO(packet)) as pz:
        pnames = pz.namelist()
        assert len(pnames) == 63 and pz.testzip() is None
        for n in pnames:
            assert pz.read(n) == z.read('inputs/' + n), n
        pm = json.loads(pz.read('PACKET_MANIFEST.json'))
        assert len(pm['files']) == pm['file_count'] == 62
        assert {r['path'] for r in pm['files']} == set(pnames) - {'PACKET_MANIFEST.json'}
        for r in pm['files']:
            b = pz.read(r['path'])
            assert len(b) == r['bytes'] and sha(b) == r['sha256'], r['path']
    identities = json.loads(z.read('inputs/SOURCE_IDENTITIES.json'))
    git_count = 0
    for r in identities['sources']:
        b = z.read('inputs/' + r['packet_path'])
        assert len(b) == r['bytes'] and sha(b) == r['sha256'], r['packet_path']
        if r.get('git_blob'):
            assert hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == r['git_blob']
            git_count += 1
    assert len(identities['sources']) == identities['source_count'] == 46
    locators = json.loads(z.read('SOURCE_LOCATORS.json'))
    assert len(locators['locators']) == locators['count'] == 61
    for r in locators['locators']:
        b = z.read(r['path'])
        assert len(b) == r['bytes'] and sha(b) == r['sha256'], r['id']
        lines = b.decode('utf-8-sig').splitlines()
        assert lines[r['line'] - 1] == r['line_text'], r['id']
    ledger = json.loads(z.read('CLAIM_LEDGER.json'))
    assert [r['id'] for r in ledger['claims']] == [f'T{i:02}' for i in range(1, 8)]
    for r in ledger['claims']:
        assert r['status'] == 'verified-as-stated'
        assert r['proof_location']['sha256'] == sha(proof), r['id']
    assert ledger['mathematical_corrections'] == []
    assert [r['id'] for r in ledger['documentary_corrections']] == ['D01']
    exact = json.loads(z.read('logs/EXACT_CHECKS.json'))
    assert exact['status'] == 'PASS' and exact['group_count'] == 5
    assert [r['id'] for r in exact['groups']] == [f'E{i:02}' for i in range(1, 6)]
    assert all(r['status'] == 'PASS' for r in exact['groups'])
    execution = json.loads(z.read('logs/EXECUTION_RECORD.json'))
    assert all(r['exit_status'] == 0 for r in execution['executions'])
    assert all(z.read(r['stderr']).strip() == b'' for r in execution['executions'])
    environment = json.loads(z.read('logs/ENVIRONMENT.json'))
    w_prefix = 'inputs/accepted/spatial_work/'
    wa = z.read(w_prefix + 'NATIVE_SPATIAL_WORK_REGISTRATION_01_GPT_ACCEPTANCE_PACKAGE.zip')
    assert sha(wa) == z.read(w_prefix + 'NATIVE_SPATIAL_WORK_REGISTRATION_01_GPT_ACCEPTANCE_PACKAGE.zip.sha256').decode().split()[0]
    wdecision = json.loads(z.read(w_prefix + 'GPT_ACCEPTANCE.json'))

report = {
    'task': 'NATIVE_CAUSAL_TRANSPORT_STORAGE_01_GPT_REVIEW',
    'date': '2026-11-10',
    'status': 'PASS',
    'review_archive': {'bytes':len(raw), 'sha256':sha(raw), 'members':len(names), 'crc':'PASS', 'manifest_files_verified':89},
    'standalone_proof_and_summary': 'exact matches',
    'proof_sha256':sha(proof),
    'original_gpt_packet': {'bytes':len(packet), 'sha256':sha(packet), 'matches_issued_packet':True, 'preserved_members':63, 'manifest_files_verified':62},
    'preserved_source_identities_verified':46,
    'preserved_git_blob_identities_verified':git_count,
    'source_locators_verified':61,
    'claim_proof_hashes_verified':7,
    'codex_reported_algebra_groups':5,
    'codex_reported_environment':environment,
    'codex_execution_statuses':[{'check':r['check'],'exit_status':r['exit_status']} for r in execution['executions']],
    'W_acceptance_archive_sha256':sha(wa),
    'scientific_code_execution_by_GPT':False,
    'scope':'Current submission integrity, source identity and evidence records only. Submitted scientific code was read, not rerun. Prior publications were not re-audited.'
}
(ROOT / 'GPT_INTEGRITY_AND_SCOPE_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='codex_reported_environment'},indent=2))
