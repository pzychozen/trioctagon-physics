# Causal transport/storage — GPT acceptance

T01–T07 are accepted as stated at their specified assumptions. D01 corrects the original work-order wording: empty added states are sufficient, not necessary, for inactivity at zero coupling. The candidate equations and analytical theorem do not change.

Read `NATIVE_CAUSAL_TRANSPORT_STORAGE_01_GPT_REVIEW.md` and `GPT_ACCEPTANCE.json` first. `submitted/` preserves all 90 returned archive members unchanged. `submitted_archive/` preserves the submitted review ZIP/checksum. `verification/` contains GPT's submission-integrity execution and direct mathematical/editorial subreviews.

The five scientific exact-algebra groups are Codex's recorded Windows executions. GPT inspected them and verified the current source chain; it did not rerun the scientific scripts. Mathematical acceptance does not adopt physical route/material correspondence or approve a future PDF/publication. The combined W+T manuscript is next.
