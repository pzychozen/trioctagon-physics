# Final analytical-start sanity review

**Task:** NATIVE_CAUSAL_TRANSPORT_STORAGE_01  
**Date:** 10 November 2026  
**Disposition:** **No concrete blocker found. No correction required by this targeted review.** The draft remains a proposed analytical start for independent Codex verification.

Reviewed the actual 431-line analytical start under **deliverables/NATIVE_CAUSAL_TRANSPORT_STORAGE_01/**, including T01–T07 and N1–N24. This review does not expand its theorem scope.

## Targeted findings

- **T04 local construction and energy:** The original RX polynomial coupling is locally Lipschitz in the stated energy space because the port averages are bounded. On each delay step, the incoming b,c are known L2 time functions. The interaction variable exp(−t A_c)Q has an absolutely continuous Duhamel formula, so the Hilbert norm chain rule justifies the carrier work identity without assuming Q is differentiable. Equation N15 supplies a coercive bound before any possible finite blowup. Local continuation on a finite step, followed by induction, is sound.
- **Traces and state continuity:** Time translation and integration in the fiber coordinate justify N8–N11 for L2 initial profiles and boundary inputs. They do not require fixed-time traces on arbitrary L2 states. The same translation construction supplies continuity of the transport state in its energy space. Choosing the step length no larger than the minimum delay leaves only null endpoint ambiguities. The stated finite-horizon continuous-dependence conclusion is supported by the corresponding bounded translation maps and local integral estimates.
- **All kappa cases:** The boundary-power cancellations N13–N14 hold for every finite kappa>=0. At kappa=0, the RX force is identically zero; the separate new subsystem can retain or exchange its own prepared energy, and the draft correctly reserves persistent emptiness for empty preparation. No claim about old RX receiving/credit/capacity theorems is improperly transferred to kappa>0.
- **T05 startup:** N16 includes the required initial forward-profile term. N17 properly requires a compatible launched history and the near boundary law at the needed negative times. The positive-time decomposition does not equate independent line preparation with a zero physical past. The signed W prehistory pairing is correctly kept separate from the new nonnegative transit stock.
- **T07 receiving:** Before twice the minimum delay, b=0, so the temporary H1 carrier regularity used in N21 follows from the damped original carrier equation with H1 tent forcing. It does not require classical compatibility at the initially empty line boundary. The scalar block of CC* is pointwise positive and decoupled from the vector block. For every time strictly above the minimum delay within the stated interval, continuity supplies a positive-measure strict delay sublevel and a nonzero preceding forcing interval; the scalar integrating factor proves N23.
- **T07 incoming return:** For a channel with theta<t/2 and t in the N24 interval, the direct scalar arrival exceeds kappa P/sqrt(2M). The displayed receiving-field estimate bounds the far scalar effort by
  \[
  \frac{4\sqrt2\,\kappa a_o^2\sqrt M\,P L}{\beta_G\delta_w^2}
  (t-\theta-\theta_-).
  \]
  The proposed epsilon restriction makes this strictly less than kappa P/(2 sqrt(2M)). Subtracting the direct arrival gives N24 with the correct strict sign. The delay sublevel has positive product measure. The distinction between an L2 trace statement and the explicit characteristic representative is legitimate, and the draft explicitly avoids inferring nonzero J*b, positive net carrier work, or native credit from nonzero b.
- **Units and interpretation:** The assignments in section 5 give the same U²L units to all proposed stocks and U/T to the added force. They are explicitly new mathematical bookkeeping, not a physical calibration. The state fibers, G arclength, G-indexed receiver, and the intended curved spatial route remain distinct.

The proposed claims are internally consistent at their stated fixed geometry, positive minimum delay, finite coefficients, and declared preparation classes. No source edit or publication check was performed.
