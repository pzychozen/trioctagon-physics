# Causal delay-state realization: design and scrutiny

**Status:** New GPT candidate mathematics for further scrutiny. No physical model, route, aperture, speed calibration, gain value, or receiving material is adopted.  
**Reviewer:** GPT route/operator agent  
**Date:** 10 November 2026

## 1. Main finding

An explicit transport state can reproduce the accepted C6 delay kernel exactly and carry a manifestly nonnegative quadratic storage. Closing that state passively to RX requires an actual port law.

Two constructions must be distinguished:

1. A scattering realization can have C6 as its exact externally driven forward transfer. Its boundary maps must be contractive in the chosen wave-power metrics, or completed by additional ports after suitable normalization. Boundedness of C6 alone is insufficient.
2. The proposed effort/flow coupling to RX works for every bounded mixing operator, without a scattering-contraction condition. Its loaded far equation contains the C6 direct term **and a causal return-wave term**. It therefore preserves C6 as a diagnostic/direct component, rather than asserting that the loaded receiver equals the original unloaded observation.

The second construction is the useful candidate with the inherited arbitrary C6 gain. The statements below derive both possibilities and their exact limits.

## 2. Retained definitions and spaces

Use one fixed admitted static geometry, the selected carrier \(S=\mathbb R/L\mathbb Z\), and the disjoint labeled union \(G\) of the six actual G arcs with summed arclength \(\mu\), \(0<M=\mu(G)<\infty\). From accepted W01–W03,

\[
0<\delta<d(s,X)\le D,\qquad
\theta(s,X)=d(s,X)/c_e,\qquad
0<\theta_{\min}\le\theta(s,X)\le\theta_{\max}<\infty.
\]

Let \(k(s,X)=a_o/d(s,X)>0\), \(A_s(p,r)=(p,r\hat t(s))\), and

\[
H=L^2(S;\mathbb R^2),\qquad
E=L^2(S\times G;\mathbb R^2),\qquad
Y=L^2(G;\mathbb R^4).
\]

All pairings here are mathematical Hilbert pairings. Their eventual physical units are additional model data.

The source identity is

\[
(\mathcal KQ)(X,t)=\int_S k(s,X)A_sQ(s,t-\theta(s,X))\,ds.
\tag{D1}
\]

The accepted source is the CC carrier equation C6 and W02–W03 in the retained W proof. W05 supplies \(H_{\rm base}'=\langle Q,F\rangle_H\) under added carrier forcing, with the original native and old receiver equations unchanged. Sources are preserved under:

**deliverables/NATIVE_SPATIAL_WORK_REGISTRATION_01_GPT_ACCEPTANCE/submitted/**.

## 3. Exact bounded factorization of C6

Define an isometric fan-out and a bounded mixing map:

\[
(JQ)(s,X)=M^{-1/2}Q(s),\qquad
(Cv)(X)=\sqrt M\int_S k(s,X)A_sv(s,X)\,ds.
\tag{D2}
\]

Then

\[
J^*v(s)=M^{-1/2}\int_Gv(s,X)\,d\mu(X),\qquad J^*J=I_H,
\]
\[
(C^*z)(s,X)=\sqrt M\,k(s,X)A_s^Tz(X).
\tag{D3}
\]

The exact norm of this particular mixing map is

\[
\|C\|^2=M\,\operatorname*{ess\,sup}_{X\in G}
\int_Sk(s,X)^2\,ds
\le a_o^2LM/\delta^2.
\tag{D4}
\]

To verify the equality, \(CC^*\) is pointwise multiplication on Y by
\[
M\int_Sk^2 A_sA_s^Tds
=M\begin{pmatrix}
\int_Sk^2ds&0\\
0&\int_Sk^2\hat t(s)\hat t(s)^Tds
\end{pmatrix}.
\]
The scalar block has the displayed norm; the vector block has no larger eigenvalue because \(|\hat t|=1\). No frame or component factor is missing.

For complete channel histories let
\[
(\mathcal Dv)(s,X,t)=v(s,X,t-\theta(s,X)).
\]
The exact identity is
\[
\boxed{\mathcal K=C\mathcal DJ.}
\tag{D5}
\]
J and C are stationary. This permits moving their fixed multiplication factors through the pairwise time translation, but does not permit replacing \(\mathcal D\) by a single common delay.

### General bounded fan-out

More generally choose a measurable positive weight \(j(s,X)\) such that
\[
\int_Gj(s,X)^2\,d\mu(X)=1
\quad\text{for almost every }s.
\]
Then \(J_jQ=jQ\) is isometric and
\[
C_jv(X)=\int_S \frac{k(s,X)}{j(s,X)}A_sv(s,X)\,ds
\]
still gives \(C_j\mathcal DJ_j=\mathcal K\). It is bounded provided
\[
B_j^2:=\operatorname*{ess\,sup}_X
\int_S k(s,X)^2/j(s,X)^2\,ds<\infty,
\]
and in fact \(\|C_j\|=B_j\). A weight that becomes too small can destroy this condition. The constant choice \(j=M^{-1/2}\) already supplies a fully adequate bounded factorization.

## 4. A transport state with nonnegative storage

Define the finite-measure fiber domain
\[
\mathfrak D=\{(s,X,\xi):0<\xi<\theta(s,X)\}.
\]
The coordinate \(\xi\) is travel time along an abstract delay fiber. No embedding of that fiber as a new spatial curve is asserted.

Take two fields \(u_+,u_-\in L^2(\mathfrak D;\mathbb R^2)\), with
\[
\partial_tu_++\partial_\xi u_+=0,\qquad
\partial_tu_--\partial_\xi u_-=0.
\tag{D6}
\]
Use the port traces
\[
a=u_+(0),\quad b=u_-(0),\qquad
c=u_+(\theta),\quad d=u_-(\theta).
\]
Thus a is launched near the carrier, c arrives at G, d is launched from G, and b returns near the carrier. These are pair-channel variables in E; labeling their endpoints does not assign physical material to them.

The candidate transit stock is
\[
\boxed{E_{\rm tr}(t)=\frac12
\int_{S\times G}\int_0^{\theta(s,X)}
\bigl(|u_+|^2+|u_-|^2\bigr)\,d\xi\,ds\,d\mu.}
\tag{D7}
\]
It is nonnegative by definition, rather than being defined as an accounting residual. Integration of (D6) yields
\[
\boxed{
E_{\rm tr}'=
\tfrac12(\|a\|_E^2-\|b\|_E^2)
-\tfrac12(\|c\|_E^2-\|d\|_E^2).}
\tag{D8}
\]

### Initial states, traces, and finite-energy meaning

For positive-time boundary data the characteristic solution is
\[
u_+(\xi,t)=
\begin{cases}
u_+^0(\xi-t),&t<\xi,\\
a(t-\xi),&t\ge\xi,
\end{cases}
\]
\[
u_-(\xi,t)=
\begin{cases}
u_-^0(\xi+t),&t<\theta-\xi,\\
d(t-(\theta-\xi)),&t\ge\theta-\xi.
\end{cases}
\tag{D9}
\]
Here and below all fields also depend on \((s,X)\).

For \(L^2\) initial fields and boundary inputs in \(L^2_{\rm loc}(dt;E)\), these formulas define a continuous \(L^2(\mathfrak D)\) state and arrival traces in \(L^2_{\rm loc}(dt;E)\). The integrated version of (D8) follows directly by changing \(\xi\) to the corresponding launch or initial-state coordinate. A fixed-time boundary evaluation is not claimed to be bounded on the state \(L^2\) space. Point traces require an appropriate stronger domain.

For example, putting \(\mathcal D^+\) for delay applied to zero-extended positive-time inputs,
\[
c=\mathcal D^+a+\rho_+,\qquad b=\mathcal D^+d+\rho_-,
\tag{D10}
\]
where
\[
\rho_+(s,X,t)=\mathbf1_{0<t<\theta}u_+^0(s,X,\theta-t),\quad
\rho_-(s,X,t)=\mathbf1_{0<t<\theta}u_-^0(s,X,t).
\]
Exactly
\[
\int_0^\infty\|\rho_\pm(t)\|_E^2dt=\|u_\pm^0\|_{L^2(\mathfrak D)}^2.
\tag{D11}
\]

For compatible complete boundary histories,
\[
u_+^0(\xi)=a(-\xi),\qquad u_-^0(\xi)=d(\xi-\theta),
\tag{D12}
\]
and the arrival formulas become \(c=\mathcal Da\), \(b=\mathcal Dd\). Arbitrary finite-energy PDE initial fields need not arise from a past RX trajectory or from the proposed boundary law at negative times. They must not silently be replaced by zero prehistory.

The initial stock (D7) is an actual positive memory stock in this new candidate. It is not the signed prehistory pairing \(W_{\rm pre}\) of accepted W05.

## 5. When C6 can be an exact passive scattering transfer

If a port amplitude has normalized incoming power \(\|q\|^2/2\), a passive system with zero initial stock and no other nonzero inputs must have input-output gain at most one. Therefore a bounded C6 observation is not automatically a passive scattering transfer in the unweighted H and Y norms.

### A simple sufficient normalization and lossless completion

Choose a symbolic \(\gamma\ge\|C\|\), and put \(C_0=C/\gamma\). This is a mathematical normalization; it has no adopted physical calibration. The raw observation remains \(Y_{\rm C6}=\gamma y\).

Let \(N=\ker J^*\). At the near junction take external input \(q\in H\), an auxiliary input \(h_{\rm in}\in N\), and set
\[
a=Jq+h_{\rm in},\qquad
q_{\rm out}=J^*b,\qquad
h_{\rm out}=(I-JJ^*)b.
\tag{D13}
\]
The decomposition \(E=\operatorname{ran}J\oplus N\) proves exact norm conservation at this junction.

At the far junction define bounded positive defect operators
\[
D_0=(I_E-C_0^*C_0)^{1/2},\qquad
\widehat D_0=(I_Y-C_0C_0^*)^{1/2}.
\]
For an external far incoming wave \(v\in Y\), impose
\[
\begin{pmatrix}y\\d\end{pmatrix}
=
\begin{pmatrix}
C_0&\widehat D_0\\
D_0&-C_0^*
\end{pmatrix}
\begin{pmatrix}c\\v\end{pmatrix}.
\tag{D14}
\]
This block map is unitary. Direct multiplication uses
\(C_0D_0=\widehat D_0C_0\), obtained first for polynomials in \(C_0^*C_0\) and \(C_0C_0^*\), then by uniform approximation to the square-root function. Thus
\(\|y\|^2+\|d\|^2=\|c\|^2+\|v\|^2\).

Combining this identity with (D8) and (D13),
\[
E_{\rm tr}'=\tfrac12
\bigl(\|q\|^2+\|h_{\rm in}\|^2+\|v\|^2
-\|q_{\rm out}\|^2-\|h_{\rm out}\|^2-\|y\|^2\bigr).
\tag{D15}
\]
This is a causal lossless scattering realization with all ports accounted for. With \(h_{\rm in}=v=0\), zero bank preparation, and an externally prescribed q,
\[
y=C_0\mathcal D^+Jq=\gamma^{-1}\mathcal K^+q.
\]
The raw C6 record is exactly \(\gamma y\). If the unnormalized C is already contractive, take \(\gamma=1\).

A one-way completion \(c\mapsto(C_0c,D_0c)\) is also isometric. Discarding its second output without declaring its power would be an accounting error. Interpreting the discarded output as a dissipative termination is an additional load choice.

### Uncommissioned comparison only

The inherited gain is arbitrary, so there is no source guarantee that raw C6 is a contraction in unit-normalized scattering metrics. Section 5 is only an alternative construction explaining the distinction between bounded observation and scattering power normalization. Sharp induced-norm optimization is not part of the proposed study. The effort/flow candidate below retains the inherited bounded C without this gain restriction.

## 6. Preferred candidate: causal effort/flow coupling without a gain restriction

Retain the simple J and C in (D2). Let \(\kappa\ge0\), \(\beta>0\) be finite symbolic candidate parameters, with no numerical or physical calibration selected. Introduce a new far state \(\zeta\in Y\), distinct from the existing RX receiver z, with
\[
H_\zeta=\frac{\beta}{2}\|\zeta\|_Y^2.
\]

At the near boundary impose
\[
a=\sqrt2\,\kappa JQ-b,\qquad
F=-\kappa^2J^*JQ+\sqrt2\,\kappa J^*b.
\tag{D16}
\]
Add F to the two carrier equations; retain the original native and old z equations. At the far boundary impose
\[
d=\sqrt2\,C^*\zeta-c,\qquad
\beta\dot\zeta=\sqrt2\,Cc-CC^*\zeta.
\tag{D17}
\]

These equations are an effort/flow transformer coupling, not an assertion that C is a scattering contraction. The corresponding same-time port efforts and flows are
\[
e_N=(a+b)/\sqrt2=\kappa JQ,\quad
f_N=(a-b)/\sqrt2,\quad F=-\kappa J^*f_N,
\]
\[
e_F=(c+d)/\sqrt2=C^*\zeta,\quad
f_F=(c-d)/\sqrt2,\quad \beta\dot\zeta=Cf_F.
\tag{D18}
\]
The near port power into the bank is \(\langle e_N,f_N\rangle_E\); the far port power out of it is \(\langle e_F,f_F\rangle_E\). Adjointness of the transformers preserves these signed pairings for arbitrary bounded C.

Indeed,
\[
\tfrac12(\|a\|^2-\|b\|^2)
=\kappa^2\|JQ\|^2-\sqrt2\,\kappa\langle JQ,b\rangle
=-\langle Q,F\rangle,
\]
\[
\tfrac12(\|c\|^2-\|d\|^2)
=\sqrt2\langle C^*\zeta,c\rangle-\|C^*\zeta\|^2
=\frac{dH_\zeta}{dt}.
\]
Therefore, using accepted RX's added-work identity,
\[
\boxed{\frac{d}{dt}
\bigl(H_{\rm base}+E_{\rm tr}+H_\zeta\bigr)=0.}
\tag{D19}
\]
Every stock is explicitly nonnegative. No bound \(\|C\|\le1\) is required; its finite boundedness suffices. The old \(H_R\) occurs once inside \(H_{\rm base}\).

This is reversible receiving in a new mathematical field state. It is not an irreversible absorber, nor does the equality identify physical energy units or a material location. The possible null directions of C and \(C^*\) are not claimed to be controllable or recoverable.

### Causality and the energy-space solution

Because \(\theta_{\min}>0\), take time slabs of length at most \(\theta_{\min}\). On each new slab, b and c are known from initial profiles or already constructed boundary values. Their \(L^2(dt;E)\) regularity follows from (D9)–(D11) and time translation. There is no instantaneous algebraic feedback loop.

The RX subsystem on that slab is its accepted locally Lipschitz semilinear evolution plus bounded damping and an \(L^2\) forcing \(\sqrt2\kappa J^*b\). The \(\zeta\) equation is a Hilbert-space linear equation with bounded operator \(CC^*\) and \(L^2\) forcing Cc. Local solutions therefore reconstruct the next boundary inputs a and d, allowing another step.

The global stock identity is valid at this energy regularity. For the carrier, with the accepted unitary free group S(t), \(S(-t)Q(t)\) is absolutely continuous whenever its source is locally time-integrable in H; differentiating its squared Hilbert norm gives the global carrier work identity almost everywhere. For the bank the integrated identity follows from (D9). The resulting conserved coercive stock bounds all state norms and rules out finite-time blowup, so the method continues over every finite interval.

This establishes the natural candidate regularity \(Q\in C_tH\), bank state continuous into its \(L^2\) space, and \(\zeta\in H^1_{\rm loc}(dt;Y)\). It does not automatically establish carrier \(H^1\) regularity, continuous point records, or pointwise bank boundary values at every time. In particular zero line preparation and \(Q(0)\ne0\) create a boundary corner; a mild energy solution remains valid without claiming globally compatible classical line data.

For finitely many original native jumps, keeping Q, z, the bank and \(\zeta\) continuous and applying the original native map to x gives
\[
\Delta(H_{\rm base}+E_{\rm tr}+H_\zeta)=B_N
\]
with the accepted post-jump endpoint convention. Quantitative receiving/recovery results proved for the old unextended trajectory do not automatically transfer to this modified evolution.

At \(\kappa=0\), F is exactly zero and the original RX subsystem is recovered independently of the bank preparation. The bank near boundary becomes \(a=-b\). Existing bank/far-state energy may still move within that separate subsystem; claiming zero new receiving therefore also requires zero bank and far-state preparation. With both zero, that subsystem remains zero. The constructive receiving regime uses \(\kappa>0\).

## 7. What is retained exactly, and the initial-history correction

For compatible complete histories obeying the near boundary law also at negative times, substitute \(c=\mathcal Da\) into (D17):
\[
\boxed{\beta\dot\zeta
=2\kappa\,\mathcal KQ
-\sqrt2\,C\mathcal Db
-CC^*\zeta.}
\tag{D20}
\]
Thus the original C6 kernel appears exactly in the direct term. The additional return and load terms are part of the candidate dynamics. Equating the complete loaded receiver to C6 would discard those terms.

For arbitrary initial PDE fields, the correct positive-time equation is instead
\[
\boxed{\beta\dot\zeta
=2\kappa\,\mathcal K^+Q
-\sqrt2\,C\mathcal D^+b
-CC^*\zeta+\sqrt2\,C\rho_+.}
\tag{D21}
\]
Here \(\mathcal K^+\) uses zero extension before time zero. The \(\rho_+\) term is generally nonzero and represents the forward field already in transit at preparation. Zero initial bank makes it vanish, but does not imply that an autonomous RX backward trajectory has zero prehistory.

The original observation can separately be computed from any supplied carrier history using (D1); it remains a diagnostic, not the definition of the new stock or loading power. Neither the transpose used in the same-time boundary transformers nor the causal return delay is the advanced finite-window Hilbert adjoint of W03.

## 8. Concrete limits and recommendation

The proposed effort-boundary model is an explicit candidate that supplies the missing causal state and a nonnegative intermediate storage. Its algebra, delay realization, and energy-space continuation are consistent at the stated finite bounded parameters. Its direct C6 term is exact under the history qualifications above.

The following remain distinct decisions or future results:

- A delay fiber indexed by \((s,X)\) does not identify a physical outward–around–inward curve, an aperture interior, or a field filling three-dimensional space.
- The actual G arclength remains a mathematical pairing measure. It has not become a physical receiving area or a prescribed allocation between openings.
- The new \(\zeta\), its metric \(\beta\), the coupling \(\kappa\), and the effort boundary laws are new candidate constitutive choices. No inherited source proves their physical adoption.
- Reading or copying Q into a memory bank without the reciprocal near force fails to account for the bank's incoming power. Observation memory by itself is not the passivity argument.
- Calling C contractive solely because it is bounded is false; effort/flow adjointness supplies the alternative exact cancellation.
- Preserving the original unloaded trajectory, exact raw C6 as the complete loaded receiving variable, and unrestricted new passive feedback cannot all be assumed at once. The candidate explicitly changes the carrier equation and distinguishes direct observation from loaded response.
- Arbitrary \(L^2\) initial bank states, compatible past boundary histories, and histories generated by the full candidate are different preparation classes.

**Recommendation:** develop and independently test the effort-boundary candidate (D6), (D16), and (D17), with the mild energy-space formulation and explicit preparation class. Keep the scattering normalization result as a comparison that explains why no gain restriction is needed for this different port interpretation. No public work order or manuscript was created by this internal design review.
