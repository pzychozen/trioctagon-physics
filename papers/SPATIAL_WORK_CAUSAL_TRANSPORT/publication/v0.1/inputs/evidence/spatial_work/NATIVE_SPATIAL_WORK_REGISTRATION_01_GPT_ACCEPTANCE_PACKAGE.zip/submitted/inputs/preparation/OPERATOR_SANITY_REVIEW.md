# Operator sanity review: proposed spatial work registration

**Status:** analytical-start sanity review, not final acceptance or a new receiver construction. No publication was rechecked and no scientific suite was run.

## Disposition

The proposed finite-window C6 map, norm bound, and adjoint formula are correct with the qualifications below. They support a bounded independent Codex work order. In particular, preserve the distinction between the observation-history class and actual reciprocal-exchange trajectories, and do not promote the Hilbert adjoint into a causal energetic port.

Take 0<T<infinity, a=g_o/(4*pi)>0, c_e>0, L>0, and the six labeled static G arcs with finite total arclength M. The direct sum treats the labels separately; shared endpoints have arclength measure zero. Let d(s,X)>=delta>0 be the inherited uniform clearance, tau(s,X)=d(s,X)/c_e, and choose tau_max>=sup tau. Put I=[-tau_max,T]. All geometry and observation parameters are fixed during this analysis.

## 1. The spacetime operator is bounded

Define A_s(p,r)=(p,r*t_hat(s)) in R4. Since the carrier tangent is unit, A_s is an isometry from R2 into R4. The proposed map is

    (KQ)(X,t)=a*integral_0^L A_s Q(s,t-tau(s,X))/d(s,X) ds.

Cauchy-Schwarz in s gives

    |KQ(X,t)|^2
      <= a^2*L/delta^2 * integral_0^L |Q(s,t-tau(s,X))|^2 ds.

For each fixed s,X, substitution u=t-tau maps [0,T] into I. Integrating in time and over the six arcs yields

    ||KQ||_Y^2 <= a^2*L*M/delta^2 * ||Q||_H^2,
    ||K|| <= a*sqrt(L*M)/delta.

There is no additional sqrt(2) or sqrt(T) factor. The two scalar carrier components have already been included in the Euclidean norm of A_sQ.

Although individual delayed values of an L2 representative are not point values, the formula defines an a.e. spacetime output independently of representatives. For fixed s,X, translation preserves null sets in the time variable; Fubini then handles s,X. The bounded map may equivalently be defined first on smooth histories and extended to H.

This is a mathematical observation/test-pairing bound using arclength on G, not a surface-power or material-flux law.

## 2. Point records require a stronger history class

C(I;H1_per(Gamma;R2)) is sufficient: in one spatial dimension H1 embeds continuously into C(Gamma), so the history has a jointly continuous representative. The retarded integral then gives continuous records on the static compact G sets times [0,T]. The entire required history must be supplied.

Do not infer bounded point evaluation from the H-to-Y estimate. For a fixed X0 and 0<t0<T, let u0(s)=t0-tau(s,X0). Its range stays inside I. Choose smooth nonzero v(s)>=0 and a smooth bump psi with psi(0)>0, and set

    p_epsilon(s,u)=epsilon^(-1/2)*v(s)*psi((u-u0(s))/epsilon),
    r_epsilon=0.

For sufficiently small epsilon, its H norm is fixed up to the chosen normalization, while U(X0,t0) is a positive constant times epsilon^(-1/2). Each history is smooth, but its point record is unbounded relative to the H norm. Thus the L2 spacetime theorem and the continuous-record theorem have genuinely different norms/hypotheses.

## 3. Finite-window adjoint and its support

Extend lambda(X,t) by zero outside [0,T]. Fubini and u=t-tau give the adjoint, for u in I,

    (K*lambda)(s,u)
      = a*sum_over_six_G integral_G
          ( lambda_0(X,u+tau),
            t_hat(s) dot lambda_v(X,u+tau) ) / d(s,X) dmu(X).

The zero extension is essential: it supplies the indicator 0<=u+tau<=T. If writing this formula outside its declared domain I, also include the indicator of I. The change of variables produces no Jacobian or delay-derivative factor, because only time is translated at fixed s,X. The formula is an a.e. Hilbert adjoint, and ||K*||=||K|| is bounded by the same constant.

This formula uses the ambient-vector component V. If instead output vectors are resolved as B_obs^T V in a declared local observation frame, the adjoint projection must use t_hat dot (B_obs lambda_v). The current ambient-vector formulation needs no such extra matrix.

Let tau_min=inf tau>0. The adjoint is supported within the union of intervals [-tau(s,X),T-tau(s,X)], hence within [-tau_max,T-tau_min]. It can act on negative u, i.e. on the prehistory part of H. Dropping that part changes the operator and the duality identity.

## 4. Advanced dependence and the short-window exception

Whenever an eligible region of positive measure has 0<=u<u+tau<T, K*lambda(s,u) generally depends on lambda at times later than u. The scalar channel has a positive kernel, so a future-supported scalar test provides a direct witness against interpreting it as a causal forward-time force.

However, if T<=tau_min, its restriction to u in [0,T] is zero a.e.; only possible endpoint equalities remain, which are null in time. Do not claim a nontrivial noncausal forward-time restriction for every T. Even in that short-window case the adjoint's negative-time part can be nonzero. The full adjoint acts between a future observation window and an earlier history interval; it is not automatically a causal physical interconnection.

## 5. Same present carrier state does not determine arbitrary-history records

On the continuous observation-history class, compare Q0=0 with Q1(s,u)=(phi(u),0), where phi>=0 is a smooth past bump supported inside (-tau_max,0). Choose its positive region to overlap delays contributing to a fixed G neighborhood. Both histories have the same present carrier state Q(s,0)=0, but the second has positive U at those observation points and, by continuity, on a nonempty initial time interval. For T>0 this also gives distinct Y outputs. A bump intersecting no relevant delayed time would not be a witness, so specify the overlap rather than choosing an arbitrary past bump.

These are arbitrary admissible C6 histories, not two proved RX solutions. In general this simple spatially constant time bump does not satisfy the fixed-profile carrier PDE. It proves no claim about reconstructibility from the current full native/carrier/receiver state. In fact, the inherited global unique autonomous RX flow determines its own past from a full state within that solution class; a contrary full-state assertion would require a separate model change or proof.

## 6. Added work gives a necessary accounting test

If sufficiently regular added carrier terms are introduced as

    p_t+c r_s=Bq+F_p,    r_t+c p_s=F_r,

while the original native and receiver equations are retained, their previous interface powers still cancel. Along a solution for which the energy identity is justified,

    H_base' = integral_Gamma (p F_p+r F_r) ds =: W_added.

For finite hybrid windows, add the correctly counted native jump sum to the integrated identity. This calculation alone does not establish existence, causality, stability, or a constitutive loading law for an unspecified feedback F.

If a hypothetical additional receiver has power P_G and no new route store is admitted, a closed matching account would require W_added=-P_G between jumps. With a transit store E_tr, the necessary relation is

    E_tr' = -W_added-P_G.

These are necessary balance relations only. Defining E_tr as a residual does not prove nonnegativity, material location, causal dynamics, or an admissible receiving mechanism.

## 7. The prehistory pairing cannot be discarded

The exact duality identity is

    <lambda,KQ>_Y
      = integral_0^T <Q(u),K*lambda(u)>_Gamma du
        + integral_-tau_max^0 <Q(u),K*lambda(u)>_Gamma du.

Call the second term P_hist. If one formally chooses F=-K*lambda only on the forward-time window and hypothetically identifies the receiving work integral with <lambda,KQ>_Y, then

    integral_0^T W_added du + <lambda,KQ>_Y = P_hist.

The sign is positive on the right. Full finite-window cancellation therefore does not follow from the adjoint identity after its negative-time portion is dropped. Zero prehistory is sufficient to make P_hist vanish, but not necessary: special test functions, disjoint supports, orthogonality, or cancellations may also do so. Say "unless the prehistory pairing vanishes," not "unless the history is zero."

Even when P_hist=0, this is an integrated identity, not an instantaneous power identity, and the forward-time adjoint generally still has advanced dependence. Neither it nor the observation pairing alone specifies a causal RX-like port or a new physical receiver. This is the useful bounded conclusion for the proposed independent investigation.
