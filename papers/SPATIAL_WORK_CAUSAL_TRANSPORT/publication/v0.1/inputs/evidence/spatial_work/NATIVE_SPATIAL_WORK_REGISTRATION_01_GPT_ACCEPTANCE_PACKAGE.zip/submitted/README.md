# NATIVE_SPATIAL_WORK_REGISTRATION_01: independent review return

Start with [RESULT_SUMMARY.md](RESULT_SUMMARY.md), then the [complete proof review](NATIVE_SPATIAL_WORK_REGISTRATION_01_PROOF_REVIEW.md).

W01-W05 are verified as stated at their submitted assumptions. This is Codex's independent disposition for GPT/author assessment, not an already-issued acceptance by them. This local research task makes no repository or publication change.

- [CLAIM_LEDGER.json](CLAIM_LEDGER.json): per-claim disposition, assumptions, source and proof locators, executed corroboration and limits.
- [CORRECTIONS_AND_LIMITS.md](CORRECTIONS_AND_LIMITS.md): no required mathematical correction; exact domain and interpretation boundaries.
- [INPUT_IDENTITIES.json](INPUT_IDENTITIES.json): local packet/source identity verification.
- [SOURCE_LOCATORS.json](SOURCE_LOCATORS.json): actual preserved source lines and hashes used by this review.
- `inputs/`: all unchanged members of the supplied packet. The original input ZIP is also retained at the review root.
- `checks/` and `logs/`: independent check code, actual environment, outputs, commands and exit statuses.
- `MANIFEST.json`: inventory of every other review-ZIP member, excluding itself and the external delivery directory.

To rerun the input validation and four independent algebra groups in the existing environment, use Command Prompt from this directory:

```bat
run_python.cmd checks\run_checks.py
```

The wrapper activates `torment` before Python. The written proofs establish the all-parameter geometry, L2/Fubini/density, regularity, causal/advanced dependence, arbitrary-history witness and conditional hybrid balance; the algebra script is supporting evidence only.

The complete review ZIP, its checksum and an archive verification receipt are under `delivery/`. The standalone proof also has a SHA-256 file. Historical preparation/acceptance records retain their original scope and paths; current locators resolve directly to this packet's retained files.
