from pathlib import Path
import hashlib, json, os, platform, sys, zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
INPUTS = ROOT / 'inputs'
assert os.environ.get('CONDA_DEFAULT_ENV') == 'torment'
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
manifest = json.loads((INPUTS/'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
sources = json.loads((INPUTS/'SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
archive = ROOT/'NATIVE_SPATIAL_WORK_REGISTRATION_01_CODEX_PACKET.zip'
download = Path('C:/Users/Notandi/Downloads')/archive.name
assert archive.read_bytes() == download.read_bytes()
rows = []
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(set(names)) == len(names)
    assert set(names) == {r['path'] for r in manifest['files']} | {'PACKET_MANIFEST.json'}
    assert set(names) == {p.relative_to(INPUTS).as_posix() for p in INPUTS.rglob('*') if p.is_file()}
    for name in names:
        data = (INPUTS/name).read_bytes()
        assert data == z.read(name)
        rows.append({'path':'inputs/'+name, 'bytes':len(data), 'sha256':sha(data), 'matches_zip':True})
for r in manifest['files']:
    data = (INPUTS/r['path']).read_bytes()
    assert len(data)==r['bytes'] and sha(data)==r['sha256'],r['path']
assert len(manifest['files']) == manifest['file_count']
source_rows=[]
for r in sources['sources']:
    data=(INPUTS/r['packet_path']).read_bytes()
    assert len(data)==r['bytes'] and sha(data)==r['sha256'],r['packet_path']
    for key in ('expected_sha256',):
        if r.get(key):assert sha(data)==r[key],(r['packet_path'],key)
    for key in ('git_blob','expected_git_blob'):
        if r.get(key):assert blob(data)==r[key],(r['packet_path'],key)
    source_rows.append({'path':'inputs/'+r['packet_path'],'bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'source_identity_matches':True})
assert len(source_rows)==sources['source_count']
environment={'observed_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'conda_environment':os.environ.get('CONDA_DEFAULT_ENV'),'conda_prefix':os.environ.get('CONDA_PREFIX'),'command':'run_python.cmd checks\\validate_inputs.py','working_directory':str(ROOT)}
try:
    import sympy
    environment['sympy_version']=sympy.__version__
except ImportError:
    environment['sympy_version']=None
result={'task':'NATIVE_SPATIAL_WORK_REGISTRATION_01','status':'PASS','environment':environment,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'matches_download':True},'packet_members':len(rows),'manifest_entries_verified':len(manifest['files']),'source_identities_verified':len(source_rows),'discrepancies':[],'recovery_required':False,'files':rows,'source_checks':source_rows,'scope':'Local supplied-input validation only; no remote publication audit, no independent re-verification of accepted foundations.'}
(ROOT/'INPUT_IDENTITIES.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(ROOT/'logs').mkdir(exist_ok=True)
(ROOT/'logs/ENVIRONMENT.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ('status','archive','packet_members','manifest_entries_verified','source_identities_verified','discrepancies')},indent=2))
print(json.dumps(environment,indent=2))
