# W05: added work and prehistory residual — GPT subreview

**Date:** 10 November 2026.  
**Reviewed submission:** `research/spatial_work_review/submitted/`.  
**Scope:** Complete proof sections R5–R6; W05 claim-ledger entry; corrections/limits and result summary; retained RX work, hybrid and regularity sources; static inspection of A03/A04 and their submitted execution records. No supplied script was executed. No prior publication, PDF, commit or CI was audited.

## Decision

**Accept W05 as stated at its explicit assumptions. No mathematical correction is required.** Its source attribution, conditional regularity, endpoint convention and interpretation are correct. Acceptance of the full W01–W05 submission also depends on the separate reviews of the earlier groups; this note does not substitute for those reviews.

The statement is an exact conditional work identity and a finite-window consequence of the proved Hilbert adjoint. It adopts no spatial load, material receiver, physical power measure or nonnegative transit state.

## 1. Original RX cancellation is preserved

R5.1 retains the original profile operator, stores and native/receiver equations from `inputs/sources/RX/candidate.tex`, `eq:drive`, `eq:ports`, `eq:storages`, `eq:system`:

\[
\dot x=-\frac{\eta_N}{2\alpha_N}J_f^Ty,
\quad \dot z=\frac{\eta_R}{\beta_R}y,
\quad y=\mathcal B^*p,
\quad q=\eta_N f-\eta_Rz.
\]

The homogeneous derivative identity `J_f x=2f` is exactly RX `power.tex`, `eq:jacobian`. Therefore the one-half feedback coefficient gives

\[
\dot H_N=-\eta_N f\cdot y,
\qquad \dot H_R=\eta_Rz\cdot y.
\]

For symbolic added carrier forces `(F_p,F_r)`, the local derivative is correctly

\[
e_t+j_s=p\mathcal Bq+pF_p+r_cF_r,
\qquad j=cp r_c.
\]

Both added terms carry a plus sign. Integrating periodically and using `∫p Bq=y·q` cancels the original native/receiver work and leaves

\[
\dot H_{\rm base}=P_{\rm add},\qquad
P_{\rm add}=\int_0^L(pF_p+r_cF_r)\,ds.
\]

This is a direct extension of RX `power.tex`, `eq:localwork`, `eq:balances`; it neither removes nor double-counts the existing receiver. The permitted nonnegative coupling parameters include the original zero-coupling limits; no receiving/activity theorem is improperly extended to those limits.

## 2. Regularity is correctly conditional

The submission assumes, for example, `Q ∈ C_t H1_per ∩ C_t^1 L2` on each exchange interval and integrable added work. At this regularity the time product rule is valid in L1 and the spatial product rule distributionally; periodic integration eliminates the flux derivative. This matches the role of the strong regularity in RX `wellposed.tex`, `eq:strong` and its strong-preparation proof.

The original RX global theorem is not used as an existence theorem for the newly forced system. R5.4 explicitly recognizes that a general L2 adjoint force need not have the stronger regularity invoked in R5.1 and that a sufficiently regular solution with the formal force is an assumption. The ledger and corrections/limits preserve this qualification. No additional regularity or well-posedness claim needs correction.

## 3. Native jumps and endpoints are exact

R5.2 preserves the exact native coefficient tuple, zero convention and F-first/exchange-second order of RX `hybrid.tex`, `eq:tuple`, `eq:nativemap`, `eq:hybrid`. The new force pair is distinguished from `F_native`.

Only native storage jumps; carrier and z do not. With post-jump endpoints, `H(T^+)−H(0^+)` counts exactly `0<t_j≤T`. A zero-time jump is already in the initial value; a jump at T is included. This is RX `accounts.tex`, `eq:baselinewindow`, `eq:windowbalances`, combined with `hybrid.tex`, `eq:hybridbalance`.

Thus the submitted identity

\[
\Delta H_{\rm base}-B_N=\int_0^T P_{\rm add}(t)\,dt
\]

has the correct sign and jump count. No hidden reservoir, impulsive port work or new cadence is introduced.

## 4. The negative-adjoint residual has the stated sign

The complete history pairing splits as

\[
W^{\rm test}=W_{\rm pre}+J_{\rm fwd}.
\]

For the explicitly formal force `F=−K_G*λ` restricted to forward times, `∫P_add=−J_fwd`. Substitution gives

\[
\boxed{\Delta H_{\rm base}+W^{\rm test}-B_N=W_{\rm pre}.}
\]

The **coefficient** of the prehistory term is positive; the pairing is signed. The proof, ledger, limits and result summary all make that distinction. Zero prehistory suffices to eliminate the residual but is not necessary: disjoint supports, orthogonality or cancellation can also eliminate it.

The short-window case is retained correctly. If `T≤θ_min`, the forward adjoint is zero almost everywhere, hence `ΔH_base=B_N` and `W_test=W_pre`. Those two pairings can be nonzero. With zero prehistory as well, the observation is zero almost everywhere on that short window. Endpoint equality contributes no time measure.

This remains integrated duality. It does not turn the longer-window advanced adjoint into causal instantaneous loading, and it does not establish an impossibility theorem for every causal extension.

## 5. A03/A04 code and records

I inspected `checks/exact_checks.py`, the stdout/stderr files, `logs/EXACT_CHECKS.json` and `logs/EXECUTION_RECORD.json`, without execution.

- **A03** forms a generic constant 2-by-3 K, differentiates `K(a×b)`, and checks `Jx−2f`, the native and receiver derivatives, the original port cancellation and the full local expression including both force components. This is appropriate algebraic corroboration. It does not claim to prove PDE regularity or jump summation.
- **A04** uses `Kq(t)=q(t−2)`, `q(u)=u+3`, and load `t+1`, with correct translated prehistory and forward limits. The displayed values agree with elementary integration: `(W_test,W_pre,J_fwd)` are `(7/3,7/3,0)`, `(26/3,26/3,0)`, and `(21,26/3,37/3)` at T=1,2,3. Negating the load produces `−26/3` prehistory; integrating `u+1` over `[-2,0]` gives zero despite nonzero history.
- The proof correctly calls these simple-delay/accounting examples, not actual RX trajectories or a proof of the geometry-dependent operator identity. `ΔH−B_N=−J_fwd` is the formal account in the example, not an independently simulated storage trajectory.
- The submitted records report Python 3.11.15, SymPy 1.14.0, four groups and exit status zero. The A03/A04 descriptions and exact values match the inspected script. This subreview does not claim a new replay or a live environment observation.

## 6. Disposition, ledger and scope

The W05 ledger's source locators and proof range point to the operative RX formulas and R5 argument. Its dependence on W03 is appropriate. `correction:null` is supported. R6, the corrections file and the result summary do not falsely claim that GPT/author acceptance was already issued.

The proposed transit relation `E_tr dot=−P_add−P_G` is a necessary balance only, conditional on declaring an additional receiving power and excluding other power terms. The submission explicitly does not manufacture a positive store by integrating a signed residual. Original `H_R` is already inside `H_base`. Material G placement, lambda's dual units, constitutive meaning and a causal connection remain unchosen.

The completed native feedback, same-trajectory credit, receiving/recovery, cadence and C/S/Q01 results remain current. Old missing-feedback statements are treated historically. No new later-direction priority is invented.

## Separate next-investigation judgment

If the programme continues after acceptance, the useful next mathematical question is whether an **explicit causal extension with nonnegative intermediate storage** can retain the existing C6 forward observation while supplying a valid power account. The mathematical target should be a narrowly specified candidate class or an existence/obstruction result, not another repetition that the present observation has no load.

There is analytical work possible before a new geometry choice: represent the existing symbolic delays with an explicit history/transport state; derive its true endpoint work and nonnegative storage; determine whether the exact C6 output can remain the observation and which additional port relations or gain conditions are needed. Keep the original RX native/z subsystem and its stores distinct. Such a study must label every added state and coupling as a proposed mathematical construction; an observation-memory realization alone is not a passive energetic realization.

No author decision is required merely to test such a declared mathematical candidate against W05. A genuine later author choice arises when selecting its physical spatial meaning—whether G represents a receiving interaction, a passage boundary, or observations of a separate transported field, and how any actual connection relates to the intended outward–around–inward route. The accepted sources do not uniquely make that choice. This is not a local-versus-elsewhere binary, does not select an aperture closure or physical clock, and should not be used to reopen the completed publications.

