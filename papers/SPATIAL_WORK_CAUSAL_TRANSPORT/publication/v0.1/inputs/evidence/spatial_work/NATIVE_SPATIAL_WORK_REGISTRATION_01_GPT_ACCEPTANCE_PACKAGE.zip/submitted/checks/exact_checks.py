"""Independent algebraic corroboration; the operator/quantifier proofs are written separately."""
from pathlib import Path
from datetime import datetime, timezone
import json, os, sys
import sympy as S

assert os.environ.get('CONDA_DEFAULT_ENV') == 'torment'
ROOT=Path(__file__).resolve().parent.parent
R=S.Rational
sqrt=S.sqrt
groups=[]
def zero(x):
    if isinstance(x,S.MatrixBase):
        assert all(S.simplify(y)==0 for y in x),x
    else:assert S.simplify(x)==0,x
def record(id,description,details):
    groups.append({'id':id,'status':'PASS','description':description,'details':details})
    print(id+' PASS: '+description)

# A01: exact constants and endpoint algebra, no separation recomputation.
rg=sqrt(3)/6; dg=1-sqrt(2)/2; ag=dg/2; hg=(sqrt(2)-1)/2; H0=R(1,2)
tau=S.symbols('tau',real=True); D2=1+tau**2/rg**2
R02=R(13,12)-sqrt(2)/2
v2=rg**2+ag**2-ag*rg
zero(H0-hg-dg)
zero(D2.subs(tau,hg)-(10-6*sqrt(2)))
zero(rg**2-ag**2-(6*sqrt(2)-7)/24)
assert 72>49 # both sides of 6 sqrt(2)>7 positive
zero(rg**2+hg**2+H0**2-R02)
zero(R02-(rg**2+tau**2+H0**2)-(hg**2-tau**2))
zero((D2*rg**2+H0**2)-(D2*ag**2+hg**2)-(D2*(rg**2-ag**2)+H0**2-hg**2))
zero(v2-((rg-ag/2)**2+3*ag**2/4))
record('A01','Radical identities, endpoint margins and positive horizontal squared length',{'R0_squared':str(R02),'Dstar_squared':str(S.simplify(D2.subs(tau,hg))),'rg2_minus_ag2':str(S.simplify(rg**2-ag**2)),'lower_tip_margin':str(hg**2-tau**2),'scope':'Exact symbolic identities; signs and all-parameter enclosure proved in R1.'})

# A02: explicitly form all twelve segments, including label k=2 wraparound.
e=[S.Matrix([S.cos(-S.pi/2+i*S.pi/3),S.sin(-S.pi/2+i*S.pi/3)]) for i in range(6)]
J=S.Matrix([[0,-1],[1,0]]); A=S.eye(2)-(tau/rg)*J
zero(A.T*A-D2*S.eye(2))
def xyz(v,z):return S.Matrix([v[0],v[1],z])
T=[xyz(ag*v,hg) for v in e]; B=[xyz(ag*A*v,-hg) for v in e]
U=[xyz(rg*e[2*k],H0) for k in range(3)]; Lo=[xyz(rg*A*e[2*k],-H0) for k in range(3)]
reflection=S.diag(-1,1,1); zero(reflection.T*reflection-S.eye(3))
edges=[]
for k in range(3):
    for hand,tips,elbows,expected in [('+',U,T,v2+dg**2),('-',Lo,B,D2*v2+dg**2)]:
        for side,difference in [('first',elbows[2*k+1]-tips[k]),('second',tips[(k+1)%3]-elbows[2*k+1])]:
            zero(difference.dot(difference)-expected)
            rd=reflection*difference;zero(rd.dot(rd)-expected)
            edges.append({'label':f'G{k}{hand}/{side}','squared_length':str(S.simplify(expected))})
chi=S.symbols('chi',real=True); tangent=S.Matrix([0,-S.sin(chi),S.cos(chi)])
zero(tangent.dot(tangent)-1);zero((reflection*tangent).dot(reflection*tangent)-1)
record('A02','All twelve labeled edge lengths, full reflection and unit tangent',{'edge_count':len(edges),'edges':edges,'scope':'Symbolic tau; no grid or optimized delay/separation calculation.'})

# A03: generic rank-independent Euler cancellation; the source's fixed K is a specialization.
a=S.Matrix(S.symbols('a0:3',real=True));b=S.Matrix(S.symbols('b0:3',real=True));x=a.col_join(b)
K=S.Matrix(2,3,S.symbols('k0:6',real=True));f=K*a.cross(b);Jac=f.jacobian(x)
zero(Jac*x-2*f)
y=S.Matrix(S.symbols('y0:2',real=True));z=S.Matrix(S.symbols('z0:2',real=True))
etaN,etaR,alpha,beta=S.symbols('etaN etaR alpha beta',positive=True)
xdot=-etaN/(2*alpha)*Jac.T*y;zdot=etaR/beta*y
PN=S.expand(alpha*x.dot(xdot));PR=S.expand(beta*z.dot(zdot))
zero(PN+etaN*f.dot(y));zero(PR-etaR*z.dot(y))
Padd=S.symbols('Padd');zero(PN+PR+(etaN*f-etaR*z).dot(y)+Padd-Padd)
p,r,ps,rs,c,bq,Fp,Fr=S.symbols('p r ps rs c bq Fp Fr')
pt=bq+Fp-c*rs;rt=Fr-c*ps
zero(p*pt+r*rt+c*(ps*r+p*rs)-(p*bq+p*Fp+r*Fr))
record('A03','Generic polynomial Euler identity, one-half feedback and both added-force signs',{'native_derivative':'-etaN f dot y','receiver_derivative':'etaR z dot y','total_derivative':'Padd','local_added_terms':'p Fp + r Fr','scope':'Symbolic algebra; PDE regularity and jump summation proved in R5.'})

# A04: exact finite-window simple-delay witnesses for the sign/window distinction.
u,t=S.symbols('u t',real=True);delay=R(2);q=u+3;load=t+1
cases=[]
for end in (R(1),R(2),R(3)):
    test=S.integrate(q.subs(u,t-delay)*load,(t,0,end))
    pre=S.integrate(q*load.subs(t,u+delay),(u,-delay,min(S.Integer(0),end-delay)))
    forward=S.integrate(q*load.subs(t,u+delay),(u,0,end-delay)) if end>delay else S.Integer(0)
    delta=-forward
    zero(delta+test-pre)
    if end<=delay:zero(forward)
    cases.append({'T':str(end),'delay':'2','W_test':str(test),'W_pre':str(pre),'forward_pairing':str(forward),'Delta_H_minus_BN':str(delta),'residual':str(S.simplify(delta+test-pre))})
assert cases[-1]['W_pre']=='26/3' and cases[-1]['forward_pairing']=='37/3'
negative_pre=-S.integrate((u+3)**2,(u,-2,0));assert negative_pre<0
cancellation=S.integrate(u+1,(u,-2,0));zero(cancellation)
record('A04','Exact delay-window residuals, signed prehistory and nonzero-history cancellation',{'cases':cases,'negative_load_W_pre':str(negative_pre),'nonzero_q_pre':'q(u)=u+1 on [-2,0], lambda=1 on [0,3]','cancelling_W_pre':str(cancellation),'scope':'Corroborating examples only; geometry-dependent duality proved in R3 and R5.'})

result={'task':'NATIVE_SPATIAL_WORK_REGISTRATION_01','observed_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'sympy':S.__version__,'status':'PASS','group_count':len(groups),'groups':groups,'not_claimed':['No numerical sweep proves a continuum claim','No rerun of accepted separation/cadence suites','No RX trajectory or newly forced-system existence test','No physical units/speed/receiver selection']}
(ROOT/'logs/EXACT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','independent_algebra_groups':len(groups)},indent=2))
