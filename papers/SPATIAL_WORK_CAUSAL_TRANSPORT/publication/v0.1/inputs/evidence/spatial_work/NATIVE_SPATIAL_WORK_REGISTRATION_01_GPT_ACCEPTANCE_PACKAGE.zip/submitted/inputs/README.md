# Next research packet: spatial observation and work compatibility

**Read first:** `NATIVE_SPATIAL_WORK_REGISTRATION_01_CODEX_WORK_ORDER.md`.

This packet commissions independent review of five proposed GPT results concerning the inherited C6 observation on the six actual G boundaries and its finite-window adjoint/work account. It includes the analytical start, claim ledger, exact preserved sources, accepted foundations and input identities.

The combined central-route/six-opening publication is closed on the author's confirmation. No publication audit is requested. This packet is a local research-verification task, not a manuscript or publication order.

## Contents

- Work order and GPT analytical start: the complete task and proposed proofs.
- `CLAIM_LEDGER.json`: W01–W05, assumptions and falsification targets.
- `SOURCE_MAP.md` and `SOURCE_IDENTITIES.json`: equation locations and preserved-input identities.
- `sources/` and `accepted/`: source equations and previously accepted foundations.
- `context/`: current status and preserved author geometry.
- `preparation/`: GPT internal source/derivation reviews, not independent Codex acceptance.
- `verification/PREPARATION_CHECKS.json`: packet construction and source-copy checks only.
- `PACKET_MANIFEST.json`: SHA-256 and size of every other member in this packet.

The return requested from Codex is `NATIVE_SPATIAL_WORK_REGISTRATION_01_REVIEW.zip` with its standalone proof review and SHA-256. All five groups remain pending independent review until that return is assessed.
