# Independent GPT scrutiny of W02–W04

**Task:** `NATIVE_SPATIAL_WORK_REGISTRATION_01`  
**Date:** 10 November 2026  
**Reviewer:** GPT, route/operator review agent  
**Recommendation:** **Accept W02–W04 as stated, with their submitted assumptions and limits. No required mathematical correction was found.** This is the scoped operator recommendation for the parent GPT assessment.

## Material and review method

I read the submitted proof's R2–R4 in full, the corresponding entries of `CLAIM_LEDGER.json`, `CORRECTIONS_AND_LIMITS.md`, and the issued analytical start's definitions and W02–W04. I checked the retained CC C6 and exterior-regularity source, the RX global evolution theorem, and the accepted central-route C05 statement for the relevant domain distinctions. W01's geometric distance and finite-length inputs are taken as supplied to this operator review.

The findings below come from independently checking the changes of variables, null-set arguments, support inequalities, and witnesses. No numerical check or previous preparation note is used as proof of these functional-analytic claims. No publication audit or science-suite execution was performed, and the submitted evidence was left unchanged.

## Disposition by claim

| Claim and submitted location | Disposition | Decisive check |
| --- | --- | --- |
| W02, proof R2, equations R2.1–R2.5, lines 138–202 | Accept as stated | Time integration makes the variable-delay pullback bounded and representative independent; the smooth graph-concentrated counterexample really has constant history norm and divergent point value. |
| W03, proof R3, equations R3.1–R3.2, lines 204–251 | Accept as stated | The adjoint uses the full history interval and zero-extended test. Its future-test witness gives a discrepancy on positive measure before the cutoff, with the short-window equality case treated correctly. |
| W04, proof R4, equation R4.1, lines 253–275 | Accept as stated | The explicit past bump overlaps an actual retarded time while leaving the complete present carrier state zero. Its domain is explicitly the arbitrary smooth history class, not generated RX trajectories. |

## 1. W02: the time integral resolves the apparent diagonal restriction

Write \(S=\mathbb R/L\mathbb Z\), \(G=\mathcal G_w\), \(M=\mu(G)\), \(\delta=\delta_w\), and \(\theta=\theta_X(s)\). For any representative \(Q\), the relevant pullback estimate is

\[
\int_G\int_S\int_0^T |Q(s,t-\theta_X(s))|^2\,dt\,ds\,d\mu(X)
\le M\|Q\|_{\mathcal H}^2.
\]

For each fixed \(s,X\), time translation has Jacobian one and sends the observation interval inside \(I\). This establishes the estimate without assuming a bounded restriction to a single curve in \((s,u)\)-space. The same integral is zero for a representative difference that vanishes almost everywhere. Tonelli/Fubini therefore establishes independence of representatives for almost every \((X,t)\). One can start with Borel representatives and then transfer to completed-measure representatives using this null-set result; equivalently, on each segment patch the transformation \((s,X,t)\mapsto(s,X,t-\theta_X(s))\) is a Lipschitz time shear with a Lipschitz inverse, so completed-measure measurability is also harmless here.

The pointwise-in-\((X,t)\) Cauchy–Schwarz inequality is used initially on smooth histories, and subsequently almost everywhere. Because \(A_s\) is an isometry, it gives exactly

\[
\|\mathcal K_GQ\|_{\mathcal Y}
\le \frac{a_o\sqrt{LM}}{\delta}\|Q\|_{\mathcal H}.
\]

No extra component factor or time-window factor is missing. This is an upper bound, not an identified sharp norm. The submitted width cancellation concerns the family of physical measure spaces and does not assert an identity between different-width domains or a time calibration. The a.e. cutoff statement follows from the same null-set argument applied below the cutoff, so its causality assertion is valid on the stated \(L^2\) spaces.

### Point records and the counterexample are compatible

The embedding \(H^1(S)\hookrightarrow C(S)\) makes a \(C(I;H^1(S))\) history jointly continuous. Compactness and positive clearance then give continuous records, including arc elbows and endpoints. No spatial derivative at an elbow is required.

For the counterexample in R2.3, \(u_0(s)=t_0-\theta_{X_0}(s)\) is smooth and periodic. The full graph lies inside \(I\) with a uniform positive margin: the lower margin is at least \(t_0\), and the upper margin is at least \(T-t_0+\theta_{\min}\). Thus one sufficiently small \(\epsilon\) works for every \(s\), and the exact norm calculation is legitimate:

\[
\|Q_\epsilon\|_{\mathcal H}^2
=\|v\|_{L^2(S)}^2\|\psi\|_{L^2(\mathbb R)}^2.
\]

At the chosen output point the delay aligns with the bump center for every \(s\), yielding a positive constant times \(\epsilon^{-1/2}\). Each history is smooth and belongs to the stronger regularity class, but their stronger norms need not remain bounded. Consequently the example establishes precisely the absence of a bounded point-evaluation extension from the history \(L^2\) norm. It does not challenge the separate continuous-record assertion.

## 2. W03: exact adjoint, history support, and both window regimes

The absolute pairing integral is bounded by

\[
\frac{a_o\sqrt{LM}}{\delta}
\|Q\|_{\mathcal H}\|\lambda\|_{\mathcal Y}.
\]

Thus its Fubini interchange is justified for the actual \(L^2\) domains. Holding \(s,X\) fixed and changing \(t\) to \(u=t-\theta_X(s)\) gives the stated load argument \(u+\theta_X(s)\), with the indicator \(0\le u+\theta_X(s)\le T\) supplied by zero extension. The transpose of the ambient embedding is

\[
A_s^T(\lambda_0,\lambda_v)
=(\lambda_0,\hat t(s)\cdot\lambda_v).
\]

No spatial change of variables has been made, so no derivative of the delay belongs in this formula. The declared domain \(u\in I\) already imposes the input-window restriction. An additional \(1_I\) would be needed only if presenting the formula as an operator on all real \(u\). The fixed-frame correction in R3.1 is correct. The direct adjoint estimate also proves its a.e. integral and representative independence; the asserted equality of adjoint/operator norms is distinct from attainment of the displayed norm bound.

For the fixed geometry, compactness turns the strict positive separation into actual delay extrema, including \(\theta_{\min}>\delta_w/c_e\). The support inclusion

\[
\operatorname{supp}\mathcal K_G^*\lambda
\subseteq S\times[-\theta_{\max},T-\theta_{\min}]
\]

is correct as an a.e. support statement. Particular tests can have zero negative-time component; retaining that component is nevertheless necessary for the general adjoint identity.

If \(T\le\theta_{\min}\), then every \(u>0\) has \(u+\theta_X(s)>T\). The forward restriction is therefore zero almost everywhere, including \(T=\theta_{\min}\), where the remaining possible \(u=0\) contribution is time-null. Positive early observation tests can still produce a nonzero negative-time adjoint. There is no conflict with nonzero outputs produced entirely from prehistory.

### The longer-window witness is genuinely a positive-measure witness

When \(T>\theta_{\min}\), strict inequality and continuity give a point of a segment interior with \(\theta_*<T\), even if the minimizing point was originally an elbow or tip. This avoids a measure-zero spatial witness. With the submitted choices,

\[
0<\epsilon<\min\{u_*/4,\theta_*/8,(T-u_*-\theta_*)/4\},
\]

the time bump centered at \(u_*+\theta_*\) and supported within radius \(3\epsilon\) is wholly later than \(u_*\) and earlier than \(T\). On the chosen circle/arc patches and \(u\in(u_*-\epsilon,u_*)\),

\[
\big|(u+\theta_X(s))-(u_*+\theta_*)\big|<2\epsilon.
\]

The translated test is thus positive throughout a spatial patch of positive arclength. The scalar kernel is positive, and the output discrepancy occupies a positive \(ds\,du\) set strictly before the cutoff, with \(u>0\). The test and zero input agree through the cutoff. This proves noncausality of the forward restriction as an operator on the unrestricted test space, for every fixed configuration and \(T>\theta_{\min}\). It does not depend on an individual representative's value at one point. The stated scope concerning direct adjoint feedback, rather than all causal extensions or restricted test protocols, is correct.

## 3. W04: the past-bump witness has the right domain and quantifiers

For every selected \(0<t_0<T\), the chosen retarded time satisfies
\(-T_{\rm hist}<u_*<t_0\). Both distances to these boundaries are strictly positive, even when the sufficient maximum-delay bound happens to be attained. The specified bump radius therefore exists and leaves a neighborhood of \(t_0\) on which both full carrier states are zero.

At \((X_0,t_0)\), the bump is positive on a carrier neighborhood of \(s_0\), hence on positive arclength. The positive scalar kernel gives strictly positive output. Joint continuity extends the output difference to a neighborhood of \((X_0,t_0)\) having positive arclength-time measure. If necessary that neighborhood can also be shrunk into the interval where the two carrier histories remain identically zero. Thus the witness does not rely on an isolated output point or an undefined \(L^2\) present-time trace: it is explicitly on smooth histories.

The phrase “past bump” is relative to the comparison time \(t_0\); its support need not be entirely at negative absolute time. The proof and issued analytical start agree on that fact. Neither claims that the witness is a solution of the fixed-profile C1 or RX equations. In general its spatially constant time-varying forcing would not match those fixed tents. The retained RX global uniqueness result concerns the full autonomous exchange state and must not be contradicted by extending this arbitrary-history witness to that domain. The submitted proof and ledger explicitly refrain from that extension and keep the actual common-phase information theorem separate.

## Final assessment

The proof, ledger, limits, and issued W02–W04 claims agree. I found no missing sign, integration factor, endpoint qualification, or hidden quantifier that requires correction. The substantive boundaries are already explicit: complete supplied history, a.e. \(L^2\) observations versus stronger point-record regularity, the short-window adjoint exception, and arbitrary histories versus actual RX trajectories. These boundaries should remain intact in any later acceptance summary or manuscript.
