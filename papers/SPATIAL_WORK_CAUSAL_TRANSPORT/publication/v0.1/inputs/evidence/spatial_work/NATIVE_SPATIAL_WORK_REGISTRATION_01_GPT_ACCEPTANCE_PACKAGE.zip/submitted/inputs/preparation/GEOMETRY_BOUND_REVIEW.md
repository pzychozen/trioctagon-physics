# New geometry-bound check for C6 restricted to G

**Status:** GPT analytical preparation for the next C6-on-G assessment. This checks only the newly proposed enclosure, delay-horizon and arclength bounds. It is not independent Codex acceptance, a repeat of the accepted separation proof, or a publication audit.

**Conclusion:** The proposed bounds are correct. The only notation qualification is that \(\tau\) in \(D(\tau)=\sqrt{1+\tau^2/r_g^2}\) denotes the width-one static parameter. Under common width \(w>0\), the dimensional parameter is \(\tau_w=w\tau\), so the same factor is \(D=\sqrt{1+\tau_w^2/(wr_g)^2}\).

## 1. Exact source definitions and endpoint labels

Source paths below are relative to `deliverables/NATIVE_CENTRAL_ROUTE_SIX_OPENING_PAPER_01/sources/`.

- **CG:** `remote/papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/manuscript.tex`, `eq:constants`, `eq:family`, `eq:faces` and following MINUS definition, `sec:openings`.
- **CC:** `remote/papers/NATIVE_INTENSITY_AND_CONDITIONAL_CARRIER_CROSSINGS/publication/v0.1/manuscript/geometry.tex`, `eq:constants`, `eq:directions`, `eq:vertices`, `eq:G`; `eq:circleconstants` and `eq:circle` for the carrier.
- **PG:** `remote/SRG_REDISCOVERY/PAPERS/PAIRED_GAP_GEOMETRY_OBSERVATION/publication/v0.1.1/geometry.tex`, `eq:circle` and `prop:balls`. PG's \(B_S\) is the present \(R_0\).

At width one,
\[
r_g=\frac{\sqrt3}{6},\quad
d_g=1-\frac{\sqrt2}{2},\quad
a_g=\frac{d_g}{2},\quad
h_g=\frac{\sqrt2-1}{2},\quad H_0=\frac12=h_g+d_g,
\]
\[
A_\tau=I-\frac{\tau}{r_g}J,\qquad
D(\tau)=\sqrt{1+\tau^2/r_g^2},\qquad
0\le\tau\le h_g,\qquad D(\tau)\le D_*=\sqrt{10-6\sqrt2}.
\]

Coordinates below are relative to the common center \(O\):
\[
T_i=(a_ge_i,h_g),\quad B_i=(a_gA_\tau e_i,-h_g),
\quad U_k=(r_ge_{2k},H_0),\quad L_k=(r_gA_\tau e_{2k},-H_0).
\]
The actual arcs are
\[
G_k^+=[U_k,T_{2k+1}]\cup[T_{2k+1},U_{k+1}],
\quad
G_k^-=[L_k,B_{2k+1}]\cup[B_{2k+1},L_{k+1}].
\]
The upper triples are \((U_0,T_1,U_1)\), \((U_1,T_3,U_2)\), \((U_2,T_5,U_0)\); lower triples replace \(U,T\) by \(L,B\). Thus \(U_3=U_0\), \(L_3=L_0\), and the last edge also has the same 60-degree horizontal endpoint angle. No tip-to-tip closing chord is included.

MINUS reflects the entire configuration by \(\operatorname{diag}(-1,1,1)\). It preserves the norms, distances and lengths below.

## 2. Every G point lies in the original-radius ball

Let
\[
R_0=\sqrt{\frac{13}{12}-\frac{\sqrt2}{2}}.
\]
The lower-tip squared norm is
\[
\|L_k\|^2=D(\tau)^2r_g^2+H_0^2
=r_g^2+\tau^2+H_0^2
\le r_g^2+h_g^2+H_0^2
=\frac{13}{12}-\frac{\sqrt2}{2}=R_0^2.
\]
Upper tips satisfy the same bound with \(D=1\). Elbows are smaller than their corresponding tips since \(a_g<r_g\) and \(h_g<H_0\):
\[
D^2a_g^2+h_g^2<D^2r_g^2+H_0^2.
\]
For an exact check of the radial comparison,
\[
r_g^2-a_g^2=\frac{6\sqrt2-7}{24}>0.
\]

Every point of each actual edge is a convex combination of its endpoints. Convexity of the Euclidean norm therefore gives \(\|X-O\|\le R_0\) on all six arcs. Reflection preserves it, and common scaling gives
\[
\boxed{\|X-O\|\le wR_0\qquad(X\in G_w).}
\]
Here \(O\) denotes the common center in the scaled registration. This derives central-G containment from its vertices; it does not assume \(G\) is part of the material host.

The family-wide radius bound is attained at lower fan tips when \(\tau=h_g\). It is thus sharp for this enclosing ball, though no claim about a physical wall follows.

## 3. Uniform upper distance and finite delay horizon

The inherited carrier satisfies
\[
\|\gamma_{j,w}(s_w)-O\|\le w(K_c+R_\Gamma),
\]
directly from its center \(O+wK_cu_j\) and radius \(wR_\Gamma\). Hence, for every actual G point, every carrier parameter and every geometric circle \(j\),
\[
d_X(s_w)=\|X-\gamma_{j,w}(s_w)\|
\le\|X-O\|+\|\gamma_{j,w}(s_w)-O\|
\le w(K_c+R_\Gamma+R_0).
\]
Therefore
\[
\boxed{T_{\rm hist}:=\frac{w(K_c+R_\Gamma+R_0)}{c_e}}
\]
is a uniform upper bound for the C6 delay when \(c_e>0\). Every required retarded time lies in \([t-T_{\rm hist},t]\). This is a sufficient history horizon, not an assertion that the actual largest delay attains the triangle-inequality bound.

Use a label such as \(T_{\rm hist}\) or \(T_{\rm delay,max}\) to distinguish this time bound from the static geometry parameter \(\tau\). No physical clock or speed value is selected. The accepted positive lower separation is not rederived here.

## 4. Exact total arclength of the six broken arcs

For either upper edge, adjacent tip/elbow directions differ by \(\pi/3\), so
\[
v_0^2:=\|r_ge_{2k}-a_ge_{2k+1}\|^2
=r_g^2+a_g^2-a_gr_g>0.
\]
The same expression holds for the other edge ending at \(U_{k+1}\). Its vertical difference has magnitude \(H_0-h_g=d_g\), giving upper-edge length
\[
\ell_+=\sqrt{v_0^2+d_g^2}.
\]
For a lower edge, \(A_\tau\) multiplies the horizontal length by \(D(\tau)\), while the vertical difference remains \(d_g\). Thus
\[
\ell_-(\tau)=\sqrt{D(\tau)^2v_0^2+d_g^2}.
\]
The entire three-dimensional edge must not be multiplied by \(D\): this source deformation acts only horizontally.

There are three upper arcs with two edges each and three lower arcs with two edges each. Consequently
\[
\boxed{
M_w(\tau)
=6w\left[
\sqrt{v_0^2+d_g^2}
+\sqrt{D(\tau)^2v_0^2+d_g^2}
\right].
}
\]
All edge interiors on one level lie in distinct open 60-degree angular sectors; their only shared points are the listed endpoints. The lower planar similarity preserves this property, and the two levels have opposite nonzero heights. Thus the formula is both the sum of the six labeled arc lengths and the one-dimensional Hausdorff measure of their union; shared endpoints have zero arclength.

Since \(v_0^2>0\) and \(D(\tau)\) increases on the admitted interval,
\[
\boxed{
M_w(\tau)\le
6w\left[
\sqrt{v_0^2+d_g^2}
+\sqrt{D_*^2v_0^2+d_g^2}
\right].
}
\]
The upper bound is attained at \(\tau=h_g\). At \(\tau=0\), the formula reduces to \(12w\sqrt{v_0^2+d_g^2}\), consistent with twelve equal actual edges. Both hands have exactly the same length.

## 5. Scope of the test measure

Arclength \(d\mathcal H^1|_{G_w}\), or the equivalent sum of arclength measures on the six labeled arcs, is a natural **mathematical test measure** for restricting an existing observation operator to these curves. Its finite mass is \(M_w(\tau)\).

It is not an aperture area, material density, flux measure, receiver stock or loading law. No missing closing edge, filled interior, thickness, normal, or transporting surface is introduced by these bounds.

