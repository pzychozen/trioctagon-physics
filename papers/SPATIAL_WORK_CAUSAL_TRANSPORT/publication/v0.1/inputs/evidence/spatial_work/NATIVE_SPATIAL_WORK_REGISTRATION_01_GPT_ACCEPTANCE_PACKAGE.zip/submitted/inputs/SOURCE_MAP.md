# Source map

The equations and accepted foundations below are preserved inputs. New claims W01–W05 are developed in the analytical start and await independent Codex review. Older source status paragraphs retain their historical context; `context/CONTINUATION_STATUS.md` controls the current programme status.

## Controlling sources

| Key | Packet files | Exact locations and role |
| --- | --- | --- |
| CC | `sources/CC/carrier.tex` | `eq:C1`, `eq:storage`, `eq:work`, `eq:characteristic`, `eq:C6`; conditional carrier, regularity, retarded observation and unloaded status. |
| CC geometry | `sources/CC/geometry.tex` | `eq:constants`, `eq:directions`, `eq:vertices`, `eq:G`, `eq:N`, `eq:circleconstants`, `eq:circle`, `eq:contacts`, `eq:tangents`; actual boundaries and positioned carrier. |
| RX | `sources/RX/candidate.tex` | `eq:drive`, `eq:tents`, `eq:ports`, `eq:storages`, `eq:system`; retained source, feedback, profiles, old receiver and energy metric. |
| RX power | `sources/RX/power.tex` | `eq:jacobian`, `eq:powers`, `eq:localwork`, `eq:balances`; Euler identity and exact reciprocal cancellation. |
| RX accounts | `sources/RX/accounts.tex` | `eq:baselinewindow`, `eq:windowbalances`, final paragraph; post-jump endpoint convention, complete jump count and distinction between z and C6. |
| RX hybrid | `sources/RX/hybrid.tex` | `eq:tuple`, `eq:nativemap`, `eq:hybrid`, `eq:hybridbalance`; native map and stage order. |
| RX regularity | `sources/RX/wellposed.tex` | Exchange regularity/global account at the original assumptions. This does not establish an unspecified new forcing law. |
| SO | `accepted/six_opening/` proof, GPT review, acceptance, claim/source ledger and limits | Proof V2–V18 supplies definitions and accepted >297/5000 common-width separation; V19–V21 and S04–S05 delimit observation/transport. These results are inputs, not new checks to repeat. |
| CR | `accepted/central_route/` proof, GPT review, acceptance and claim ledger | C01–C05 with GPT-review §5 Q01. Receiving alone does not identify completed travel; Q01 preserves both enclosing and inner-gap cut qualifications. C05 retains its conditional information scope. |
| PG | `sources/PG/geometry.tex` | `eq:circle`, `thm:circle`, `prop:balls`, `eq:macrocurve`; fixed carrier and original-radius ball. |
| CAD | `accepted/cadence/` proof, GPT acceptance, limits and status | Completed native F-stepping/cadence qualifications; no new clock or later receiving theorem is introduced. |

## Additional source/intention context

| Key | Packet files | Role |
| --- | --- | --- |
| PG observation | `sources/PG/observation.tex`, `sources/PG/closing.tex` | Fixed registered observations, information limits and historical physical-dictionary questions. Older missing-feedback language is superseded by RX. |
| CG | `sources/CG/manuscript.tex` | `eq:constants`, `eq:family`, `eq:faces`, `sec:openings`, `thm:cone`, `eq:fullface`, `eq:contactstate`; central static family and the established distinction between a placed readout and a material route. |
| AX | `sources/AX/spatial.tex`, `sources/AX/observations.tex` | Positioned native vectors/stationary axes and staged observation placements. |
| CC readouts | `sources/CC/readouts.tex`, `sources/CC/conclusion.tex` | Existing observables do not automatically become a material energy current. |
| CTX | `context/COLLABORATION_AND_GEOMETRY.md` | Author's central meeting region, opposed cones, outward spreading, curved return, possible elsewhere-transfer, stationary supports and permission to develop mathematical proposals. |
| STATUS | `context/CONTINUATION_STATUS.md` | Author-confirmed publication closeout and this next assessment's scope. The later programme directions had no strict order. |

## Provenance

`SOURCE_IDENTITIES.json` gives the exact byte count, SHA-256, available Git blob, repository path, reading commit and URL for each preserved source. The primary repository is `pzychozen/trioctagon-physics`. Each file retains its own immutable provenance, including `c3ee366bd6195bd7fa77efd0321214af4c2dc173`, the earlier `6b1ef6494a4d4c34398ba9d9e5a7afce1fb03f37` checkpoint for the preserved RX evidence, and the identified accepted local records. The two PG observation/closing files were newly recovered at `c3ee366bd6195bd7fa77efd0321214af4c2dc173` for this source assessment. An older file's provenance is not relabeled with the new publication commit.

`provenance/PARENT_SOURCE_IDENTITIES.json` is the unchanged earlier source ledger, retained to explain the accepted-input chain. `preparation/` contains GPT internal preparation only. `verification/PREPARATION_CHECKS.json` records packet/source-copy integrity; it is not scientific acceptance of W01–W05.

The new publication commit and CI are recorded only from the author's message. No claim in this packet depends on a fresh audit of its PDF or published files.
