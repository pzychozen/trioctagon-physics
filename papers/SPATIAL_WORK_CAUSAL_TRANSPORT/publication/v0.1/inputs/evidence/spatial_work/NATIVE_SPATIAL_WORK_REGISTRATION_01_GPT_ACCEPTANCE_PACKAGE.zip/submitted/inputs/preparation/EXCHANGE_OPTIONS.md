# Next spatial-registration assessment: exchange and observation options

**Date:** 10 November 2026.  
**Scope:** Source assessment after the user-confirmed publication closeout. No commit, PDF, CI or publication result was checked. No scientific suite, trajectory or supplied code was executed. Sources below are retained definitions, not new remote observations.

## Recommendation

Proceed with a bounded **power-compatibility assessment of the inherited retarded spatial observation**, provisionally `NATIVE_SPATIAL_POWER_COMPATIBILITY_01`. The new question is whether, and in what precise sense, the existing C6 map can supply a power-conjugate spatial port while retaining the accepted RX subsystem. This goes beyond the completed geometric correspondence without choosing a new receiver, aperture, transport path or coefficient.

**No author decision is needed for this analytical step.** C6 is a concrete existing candidate to examine, but neither its adoption as the intended route nor a matched loading extension is uniquely selected by the sources. Treat it as an inherited observation under examination, not as the chosen physical transport mechanism.

The useful new output is an exact distinction between the existing observation operator and the additional causal work operator/storage needed for loading. Do not merely repeat that G flux is undefined, and do not repeat the accepted clearance proof.

## Controlling source ledger

All paths are relative to `/workspace/scratch/55bf71e837ba/deliverables/NATIVE_CENTRAL_ROUTE_SIX_OPENING_PAPER_01/`. The author's context is under `context/`, rather than `sources/context/`.

| Source | Exact locators | What it supplies for the next step |
| --- | --- | --- |
| `sources/RX/candidate.tex` | `eq:registration`, `eq:drive`, `eq:ports`, `eq:storages`, `eq:system` | Raw native source; same-time distributed B/B* power pair; accepted trial stores and reciprocal state equations. The existing receiver has two abstract coordinates and no assigned material location. |
| `sources/RX/power.tex` | `eq:jacobian`, `eq:powers`, `eq:localwork`, `eq:balances`, final paragraph | Exact work cancellation; an explicitly noted power-preserving core perturbation with x·h=0 shows that a scalar power identity alone does not uniquely select dynamics. Such perturbations are not being added. |
| `sources/RX/accounts.tex` | `eq:perport`, `eq:Qdefinitions`, `eq:baselinewindow`, `eq:windowbalances`; final paragraph | Signed interface work and actual native jumps; C6 is expressly not the candidate receiver or its storage. Gross counts do not define a diversion fraction. |
| `sources/remote/papers/NATIVE_INTENSITY_AND_CONDITIONAL_CARRIER_CROSSINGS/publication/v0.1/manuscript/carrier.tex` | `eq:C1`, `eq:storage`, `eq:work`, `eq:characteristic`, **`eq:C6`** | C1 carrier energy and flux; a concrete off-carrier retarded history observation with fixed point/frame, positive independent speed/gain, straight-line delay and 1/d weighting. No C6 loading is specified. |
| Same CC manuscript, `geometry.tex` | `eq:G`, `eq:N`, `eq:cuts`, `eq:arcint` | Actual central broken G arcs, host N patches and one-dimensional cut accounts. G supplies no adopted aperture surface/normal. |
| Same CC manuscript, `readouts.tex` | `eq:decoder`, `eq:matched`, `eq:axes`, `eq:reconstruction`, `eq:Z` | Based vectors, tangent-plane isometry and staged readout placement are defined; none is a material flow or energetic loading law. |
| `sources/RR/interpretation.tex` | `sec:amount`, `sec:continuation` | Capacity-sized receiving and subsequent native recovery are completed at their stated exchange-only scope. The receiver remains reversible and unplaced. |
| `accepted/central_route/NATIVE_CENTRAL_ROUTE_CORRESPONDENCE_01_PROOF_REVIEW.md` and its GPT review | R26–R27; GPT review §6 | Exchange common-phase invariance and its conditional information limit; keep native singular-prestage and coupled-history qualifications. |
| `accepted/six_opening/NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01_PROOF_REVIEW.md` | V17–V20 | Existing positive clearance and its consequence for off-carrier C6 observations; no need to reprove these results. |
| `context/COLLABORATION_AND_GEOMETRY.md` | “The clarified picture”; “Scientific recommendations to carry forward” | Central meeting, outward spreading, around/inward return and possible elsewhere transfer are compatible parts of the intention. Stationary supports and distinct geometric objects remain fixed. |
| `context/TRIOCTAGON_FRESH_CHAT_HANDOFF_2026-11-09.md` | §§5, 7 | Use the supplied construction first; ask only at a concrete new spatial/modeling choice. Tentative diversion intuition is not a coefficient or required target. |

Historical CC remarks about missing reciprocal native debit describe the old uncoupled C1 construction. RX supplies that debit and a matched reversible receiver; same-trajectory credit, receiving/recovery and scoped cadence have since been completed. Those earlier status sentences must not become the premise of this next task.

## What is already positive and usable

The original exchange work is exact:

\[
y=B^*p,\qquad q=\eta_N f(x)-\eta_Rz,
\]
\[
\dot H_N=-\eta_N f^Ty,\qquad
\dot H_C=\eta_N f^Ty-\eta_Rz^Ty,\qquad
\dot H_R=\eta_Rz^Ty.
\]

Consequently the existing receiver cannot be reassigned to a new spatial output merely by replacing a label: its rate and carrier loading are already fixed by B/B*. The accepted circle and actual support images remain valid spatial registrations at the N contacts; their geometry is not being discarded.

C6 supplies a genuinely defined off-carrier observation. Write its ambient scalar/vector output as

\[
Y_X(t)=\int_0^{L_c}K_X(s)h(s,t-\tau_X(s))\,ds,
\quad h=(p,r_c),\quad
\tau_X(s)=|X-\gamma(s)|/c_e,
\]
\[
K_X(s)=\frac{g_o}{4\pi|X-\gamma(s)|}
\begin{pmatrix}1&0\\0&\widehat t(s)\end{pmatrix}.
\]

The last displayed matrix is 4-by-2: its lower block is the three-vector tangent in the second column. The source's declared orthonormal observation frame may be applied to that vector block without changing this issue. Use a distinct frame symbol to avoid collision with the RX profile operator B.

The accepted separation makes this kernel nonsingular at **every point of each actual static G boundary**, with the common-width qualification intact. It is possible to retain the entire pointwise family X∈G rather than arbitrarily select one sensor point, close an aperture, or introduce six averaging weights. No surface normal or boundary measure is needed to evaluate this pointwise family.

That gives a spatial observation correspondence, not a transported stock. Straight-line C6 delays do not describe an outward–around–inward path or supply a return branch. The encoded tangent field r_c t-hat is not the energy flux j=c p r_c, and squared output magnitude is not an accepted receiving store.

As a retained restriction, applying C6 at more G points cannot restore common-phase information absent from identical carrier histories. The accepted exchange invariance carries through the observation composition. This matters only for an intended outlet rule that genuinely depends on that phase; it is not a blanket obstruction to spatial observations or every future load.

## Exact analytical work available before any new model choice

The following are proposed targets for the next focused derivation/independent review, not assertions that a new model has already been accepted.

### 1. A usable G-indexed observation domain

Use the accepted clearance as an input. For a fixed static configuration (or the parameterized family of such configurations), set δ to an admitted uniform positive lower bound on distance and D to a finite upper bound. With the required history supplied on `[t−D/c_e,t]`, continuous time into periodic H1 gives continuous spatial representatives. The elementary bound

\[
|Y_X(t)|\le\frac{g_oL_c}{4\pi\delta}
\sup_{s,u}\sqrt{p(s,u)^2+r_c(s,u)^2}
\]

is a direct operator bound over the required history window, uniform in the retained G point family. This is a convenient domain statement for the power analysis, not another claim that clearance alone provides missing history. Keep τ_g static; no moving detector or physical clock is selected.

### 2. Compute the temporal adjoint with the finite-window endpoints retained

For a test output effort v(t) supported on a finite time interval, extend it by zero outside that interval. A change of variable u=t−τ_X(s) gives the exact formal pairing

\[
\int v(t)^TY_X(t)\,dt
=\int\!\int h(s,u)^T K_X(s)^T
v(u+\tau_X(s))\,ds\,du.
\]

The adjoint therefore contains an **advanced shift** of the test effort. Give the actual history domain and endpoint terms/zero-extension convention when proving the identity. This diagnoses why one cannot simply insert the same retarded C6 formula as the same-time adjoint feedback used by RX.

This does **not** prove that every causal spatial extension is impossible. An enlarged transport/memory realization can have additional storage and different endpoint ports; neither that realization nor its energy law is selected by C6 alone. Likewise, do not infer a causal no-go solely from writing a formal adjoint.

### 3. State the exact unchanged-subsystem work residual

As a compatibility calculation only, let symbols F_p,F_r denote hypothetical additional carrier forcing while the original native and z equations remain unchanged. Multiplication by p,r_c then requires

\[
\partial_te+\partial_sj=pBq+pF_p+r_cF_r,
\qquad
\dot H_{\rm tot}=\int(pF_p+r_cF_r)\,ds.
\]

Any future external receiving store must account for the negative of that added power (and any explicitly modeled dissipation or intermediate stock). Native F jumps retain their existing baseline increment. These are necessary work identities, not an adopted F_p,F_r or new receiver. They make clear exactly what a proposed spatial attachment must specify.

### 4. Separate a narrow history obstruction from claims about RX trajectories

On C6's admitted supplied-history class, different smooth histories can have identical present p,r_c but different retarded Y_X. With positive source-to-X distance, a smooth history can vanish at the present time and remain nonzero near its retarded sampling graph. Thus Y_X is not generally a function of the present carrier state on that history class, and cannot automatically be a memoryless power-conjugate output for it.

If used, prove this with an explicit smooth history and state the domain exactly. It is **not automatically** a theorem about arbitrary complete RX trajectories with prescribed empty launch, nor an impossibility theorem for extensions with additional history/transport state. Investigating that distinction is part of the bounded task.

## Alternatives actually present in the sources

| Existing construction | What it contributes | Why it does not uniquely finish the spatial work registration |
| --- | --- | --- |
| RX B/B* interfaces and receiver | Exact matched work and reversible storage | Carrier support at N is fixed; no material z position or G attachment follows. |
| C1 spatial cuts | A true one-dimensional flux j with explicit orientation | The unchanged curve has no G crossing parameters, as already accepted. |
| C6 | Concrete retarded source-to-spatial-point history map | It specifies observation, not a conjugate causal loading port or additional stock. |
| Decoder and tangent-plane “matched transport” | Exact based vectors and plane isometry | Their source explicitly denies material seam flow; they do not supply power across G. |
| Staged Z/macro placement | Defined points/directions and geometric labels | External settings, phase information limits and lack of a work relation remain; an observed cone is not emission. |

There is no dimension-count obstruction to two inputs producing six correlated observations. Conversely, a two-to-six map and total-power conservation would not uniquely choose its spatial weights or physical meaning. Do not select such a matrix, six receivers, or a measure merely to make the count match.

## Eventual author-dependent choice, if one remains

The unresolved physical choice is the **material role of G and the intervening connection**: whether G is to carry an interaction/receiving boundary or serve as a geometrical boundary of a separately specified transported field, and what physical connector/state transports and stores the exchanged quantity between the inherited C1 interfaces and that location. A surface-current account would additionally require an actual oriented surface and measure; the present broken arcs do not choose them.

That choice is not “local exchange versus transfer elsewhere.” Those are compatible in the author's picture. It is also not a reason to ask for a physical clock now. First complete the operator/work assessment above. If it leaves multiple admissible constructions, present their concrete consequences and ask one focused question about the spatial interaction role before selecting a new model. Do not ask the author to supply old equations or parameters.

