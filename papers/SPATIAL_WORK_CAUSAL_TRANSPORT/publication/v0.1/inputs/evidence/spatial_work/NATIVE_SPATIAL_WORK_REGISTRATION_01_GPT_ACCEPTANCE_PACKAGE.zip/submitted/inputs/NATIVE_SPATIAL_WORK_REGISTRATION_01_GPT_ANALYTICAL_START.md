# C6 observation and work compatibility at the six central boundaries

**Task:** `NATIVE_SPATIAL_WORK_REGISTRATION_01`  
**Prepared:** 10 November 2026  
**Status:** GPT analytical start for independent Codex review. W01–W05 below are proposed results with proofs, not an external verification receipt or an adopted transport model.

## 1. Question and inherited status

The combined central-route/six-opening paper is closed on the author's publication confirmation. This study uses its accepted mathematical foundations and older pinned source equations. It does not audit that publication.

The completed assessments distinguish receiving from a completed spatial circuit and establish strict separation between the retained carrier and each actual G boundary and individual hull. They leave additional spatial and work registration open. The present question is more specific:

> What does the existing C6 observation define on the six actual G boundaries, and what does its exact dual pairing require if one tries to use that observation in an additional work account?

C6 already supplies a retarded carrier-to-point observation. RX already supplies reciprocal native feedback, carrier work and reversible receiving. Their relationship can therefore be examined before selecting a new receiver, aperture surface, route curve or physical clock. The sources do not select C6 as the intended energetic route. [CC, RX, CR, SO]

The five proposed results are:

| Claim | Proposed result | Boundary of the result |
| --- | --- | --- |
| W01 | Exact G arclength and uniform finite-distance/history bounds. | Actual broken arcs; no aperture closure or material surface. |
| W02 | A bounded causal C6 operator on a space-time history space, with separate continuous-record regularity. | Its L2 estimate is not a bound for evaluation at one space-time point. |
| W03 | The exact finite-window adjoint, its prehistory part and qualified advanced dependence. | No general impossibility theorem for causal spatial extensions. |
| W04 | Equal present carrier states can give different C6 observations on the arbitrary history domain. | Not a pair of RX trajectories, and not a full-state reconstruction theorem. |
| W05 | Exact added-work and finite-window history residuals, conditional on stated added forcing. | No new force, receiving store or transit state is adopted. |

Source keys and exact locations are in `SOURCE_MAP.md`. The accepted C01–C05/Q01, S01–S05 and cadence qualifications remain in force. In particular, failed enclosing-profile containment is not a universal no-delay statement, and an undefined physical G aperture flux is not zero. [CR, SO]

## 2. Definitions and assumptions

### 2.1 Static geometry and common width

Use the inherited common registration and stationary supports. Let w>0 be the common host width. The constants below are width-one values; all positioned coordinates relative to O, carrier arclengths and geometric lengths are multiplied by w. Write the width-one static family parameter as tau_g in [0,h_g]; its dimensional counterpart is w tau_g. It is not time. MINUS reflects the whole registered construction by diag(-1,1,1), retaining the labels. [CC geometry, SO]

The central constants are

\[
r_g=\frac{\sqrt3}{6},\quad d_g=1-\frac{\sqrt2}{2},\quad
a_g=\frac{d_g}{2},\quad h_g=\frac{\sqrt2-1}{2},\quad
H_0=\frac12=h_g+d_g.
\]

Let J_perp be the horizontal quarter-turn, and set

\[
A_{\tau_g}=I-\frac{\tau_g}{r_g}J_\perp,\qquad
D(\tau_g)=\sqrt{1+\tau_g^2/r_g^2},\qquad
D_* =\sqrt{10-6\sqrt2}.
\]

Since A_tau^T A_tau=D(tau)^2 I, the deformation is a horizontal similarity. It does not multiply vertical lengths by D. For e_i=(cos(-pi/2+i pi/3),sin(-pi/2+i pi/3)), the width-one coordinates relative to O are

\[
T_i=(a_ge_i,h_g),\quad B_i=(a_gA_{\tau_g}e_i,-h_g),
\quad U_k=(r_ge_{2k},H_0),\quad L_k=(r_gA_{\tau_g}e_{2k},-H_0).
\]

The actual boundaries are the broken arcs

\[
G_k^+=[U_k,T_{2k+1}]\cup[T_{2k+1},U_{k+1}],\qquad
G_k^-=[L_k,B_{2k+1}]\cup[B_{2k+1},L_{k+1}],
\quad k=0,1,2,
\tag{1}
\]

with U_3=U_0, L_3=L_0 and ring indices modulo six. Use their scaled, positioned versions G_{k,w}^sigma. No tip-to-tip chord is added. [CC `eq:vertices`, `eq:G`]

Use the selected carrier Gamma_0 only, parametrized by physical arclength s in R/LZ:

\[
K_c=\frac{\sqrt3}{12}+\frac{\sqrt6}{4},\quad
a_c=\frac{K_c}{1+\sqrt3/2},\quad R_\Gamma=\frac{\sqrt7}{2}a_c,
\quad L=2\pi wR_\Gamma,
\]
\[
\gamma_w(s)=O+wK_cu+wR_\Gamma
\left[\cos\left(\frac{s}{wR_\Gamma}\right)u+
\sin\left(\frac{s}{wR_\Gamma}\right)e_z\right],
\qquad \hat t(s)=\gamma_w'(s),\quad |\hat t(s)|=1.
\tag{2}
\]

Here u=(0,1,0) in PLUS; apply the whole reflection for MINUS. Other inherited geometric circles satisfy the same bounds, but they are not additional active carriers. [CC `eq:circleconstants`, `eq:circle`; PG geometry]

The accepted SO theorem supplies, throughout this static family and both hands,

\[
d_X(s):=|X-\gamma_w(s)|>\delta_w,\qquad
\delta_w=\frac{297}{5000}w,
\quad X\in G_{k,w}^\sigma.
\tag{3}
\]

This is an inherited conservative Euclidean lower bound, not an optimized minimum. Its proof and the stronger individual-hull result are not repeated. [SO V17–V18]

### 2.2 C6 and the observation measure

Retain independent parameters g_o>0 and c_e>0, and put a_o=g_o/(4pi). For Q=(p,r_c), write the existing C6 output in ambient coordinates:

\[
Y(X,t)=\binom{U(X,t)}{V(X,t)}
=a_o\int_0^L\frac{\mathsf A_s Q(s,t-\vartheta_X(s))}{d_X(s)}\,ds,
\quad
\mathsf A_s(p,r_c)=(p,r_c\hat t(s)),\quad
\vartheta_X(s)=d_X(s)/c_e.
\tag{4}
\]

The matrix A_s is a 4-by-2 isometry: |A_s Q|=|Q|. The source's known orthonormal observation frame E gives (U,E^T V) instead; this is an orthogonal coordinate change. E is not RX's profile operator B. If a framed output is used, its adjoint vector term must contain t_hat dot (E lambda_v). Equation (4) fixes ambient coordinates throughout this assessment. [CC `eq:C6`]

Let mathcal G_w denote the disjoint labeled union of the six actual arcs. Give each arc its ordinary Euclidean arclength d ell and sum over labels. Shared endpoints have measure zero. This is a mathematical norm/test-pairing measure. It is not an adopted aperture area, power density, receiving weight or flux measure.

The observation formula assumes its whole retarded history is supplied. Empty carrier preparation at time zero specifies Q(0); it does not alone specify Q at negative times. Straight-line delay and 1/d weighting are inherited C6 assumptions. Neither the vector r_c t_hat nor a squared output norm is the inherited carrier flux j=c p r_c or a receiving store. [CC `eq:C6`, RX accounts]

## 3. W01 — finite geometry and history bounds

Set

\[
R_0=\sqrt{\frac{13}{12}-\frac{\sqrt2}{2}},\qquad
v_0^2=r_g^2+a_g^2-a_gr_g>0.
\]

R_0 is a Euclidean ball radius. It is not cylindrical radius, and using the ball as an enclosure does not assign it a material wall or central receiver. [PG geometry `prop:balls`; CR]

**W01a.** Every actual G point obeys |X-O|<=w R_0. Hence

\[
d_X(s)\le D_w:=w(K_c+R_\Gamma+R_0),\qquad
T_{\rm hist}:=D_w/c_e
\tag{5}
\]

is a uniform sufficient history horizon.

**Proof.** At width one, a lower tip satisfies

\[
|L_k|^2=D(\tau_g)^2r_g^2+H_0^2
=r_g^2+\tau_g^2+H_0^2
\le r_g^2+h_g^2+H_0^2=R_0^2.
\]

Upper tips use D=1. Elbows have smaller norms because a_g<r_g and h_g<H_0; exactly r_g^2-a_g^2=(6sqrt(2)-7)/24>0. Norm convexity extends the vertex bound along each actual segment. Scaling and reflection preserve it. The carrier has |gamma_w(s)-O|<=w(K_c+R_Gamma), and the triangle inequality proves (5). The radius bound is attained by lower tips at tau_g=h_g, but the upper distance D_w is only a sufficient bound. No sharp maximum-delay assertion follows.

**W01b.** The total labeled arclength is exactly

\[
M_w(\tau_g)=6w\left[
\sqrt{v_0^2+d_g^2}+\sqrt{D(\tau_g)^2v_0^2+d_g^2}
\right]
\le M_{w,*},
\tag{6}
\]
\[
M_{w,*}=6w\left[
\sqrt{v_0^2+d_g^2}+\sqrt{D_*^2v_0^2+d_g^2}
\right].
\]

**Proof.** Each upper edge connects horizontal directions separated by pi/3, including the wraparound edge. Its horizontal squared difference is v_0^2 and its vertical difference has magnitude d_g. For a lower edge only the horizontal difference gains factor D. There are six upper and six lower edges. This gives (6), with its maximum at tau_g=h_g. At tau_g=0 it reduces to twelve equal edge lengths. No closing chords enter this count. This proves the stated uniformity, without using or revisiting the SO separation proof.

## 4. W02 — the bounded causal history operator

Fix 0<T<infinity and one static configuration. Set I=[-T_hist,T] and

\[
\mathcal H=L^2((\mathbb R/L\mathbb Z)\times I;\mathbb R^2),
\qquad
\mathcal Y=\bigoplus_{k,\sigma}
L^2(G_{k,w}^\sigma\times[0,T];\mathbb R^4).
\tag{7}
\]

Use ds du on H and d ell dt on Y. Formula (4), initially on smooth histories, extends uniquely to a bounded linear map K_G:H->Y with

\[
\boxed{\|\mathcal K_GQ\|_{\mathcal Y}
\le \frac{a_o\sqrt{L M_w(\tau_g)}}{\delta_w}\,
\|Q\|_{\mathcal H}
\le \frac{a_o\sqrt{L M_{w,*}}}{\delta_w}\,
\|Q\|_{\mathcal H}.}
\tag{8}
\]

**Proof.** Cauchy–Schwarz in s and |A_s Q|=|Q| give

\[
|\mathcal K_GQ(X,t)|^2
\le \frac{a_o^2L}{\delta_w^2}
\int_0^L |Q(s,t-\vartheta_X(s))|^2ds.
\]

For fixed s,X, substitute u=t-vartheta_X(s). The Jacobian is one and the interval [-vartheta,T-vartheta] lies in I. Integrate in t and over the labeled G arcs, then apply Fubini. The result is the square of (8). No extra sqrt(2) or sqrt(T) factor is needed. Time translation and Fubini also show independence from choices of L2 representatives. Equivalently, the smooth formula extends by density. The output on this domain is defined almost everywhere in space and time.

Every contributing history time is strictly earlier than t by at least delta_w/c_e. Equality of input histories through a time t_1 therefore gives equality of outputs through t_1. This is the observation's causality; it is not a loading law. The norm constant is uniform in the static family and hand. Since L and M scale as w and delta as w, the displayed constant can be independent of w for fixed g_o. The necessary history horizon still scales as w/c_e. No clock calibration is inferred.

**Continuous records.** On C(I;H1_per(R/LZ;R2)), one-dimensional Sobolev embedding supplies a jointly continuous representative Q(s,u). Compactness and positive clearance then give continuous Y(X,t). Thus the original point-record interpretation is available with this stronger hypothesis. All required history must actually be provided. [CC exterior regularity]

**The L2 distinction is substantive.** Fix X_0 and 0<t_0<T. Put u_0(s)=t_0-vartheta_{X_0}(s), whose range lies strictly inside I. Let psi be a smooth compactly supported bump with psi(0)>0, and choose a nonzero smooth periodic v>=0. For small epsilon>0 define

\[
p_\epsilon(s,u)=\epsilon^{-1/2}v(s)
\psi((u-u_0(s))/\epsilon),\qquad r_{c,\epsilon}=0.
\]

The H norm is the fixed value ||v||_L2 ||psi||_L2, whereas

\[
U_\epsilon(X_0,t_0)
=a_o\epsilon^{-1/2}\psi(0)\int_0^L\frac{v(s)}{d_{X_0}(s)}ds
\longrightarrow+\infty.
\]

Each history is smooth. This proves that (8) does not bound evaluation at one (X,t) using only the H norm. It does not contradict the separately stated continuous-record result, whose stronger norm is not controlled by this construction.

## 5. W03 — exact finite-window adjoint

For lambda=(lambda_0,lambda_v) in Y, extend lambda by zero outside [0,T], writing lambda_tilde. The Hilbert adjoint K_G*:Y->H is, for u in I,

\[
\boxed{
(\mathcal K_G^*\lambda)(s,u)
=a_o\sum_{k,\sigma}\int_{G_{k,w}^\sigma}
\frac{\left(\widetilde\lambda_0(X,u+\vartheta_X(s)),\;
\hat t(s)\cdot\widetilde\lambda_v(X,u+\vartheta_X(s))\right)}{d_X(s)}d\ell_X.
}
\tag{9}
\]

It obeys ||K_G*||=||K_G|| with bound (8), and

\[
\langle\lambda,\mathcal K_GQ\rangle_{\mathcal Y}
=\langle Q,\mathcal K_G^*\lambda\rangle_{\mathcal H}.
\tag{10}
\]

**Proof.** First take smooth inputs/tests. Insert (4) into the left side and interchange the three finite integrations. At fixed s,X substitute u=t-vartheta_X(s), so the load is evaluated at u+vartheta_X(s). Zero extension gives exactly the indicator 0<=u+vartheta<=T. Transposition of A_s sends (lambda_0,lambda_v) to (lambda_0,t_hat dot lambda_v). There is no derivative of the delay: the substitution translates time while holding s,X fixed. The boundedness proof and Cauchy–Schwarz justify the pairing and extend (10) to the L2 spaces. This is the Riesz/Hilbert adjoint, with no physical work interpretation assumed.

Let vartheta_min=min_{s,X} vartheta_X(s)>0 for this fixed compact geometry. The adjoint is supported in a subset of [-T_hist,T-vartheta_min]. In particular it generally has a negative-time, prehistory component. Dropping u<0 changes (10).

**Advanced dependence and its qualification.** If T<=vartheta_min, the restriction of (9) to u in [0,T] is zero almost everywhere. An endpoint equality has zero time measure. The full adjoint can still act on prehistory.

If T>vartheta_min, choose interior points s_0,X_0 with vartheta_*=vartheta_{X_0}(s_0)<T, and 0<u_0<T-vartheta_*. Choose a nonnegative scalar load bump localized near X_0 and time u_0+vartheta_*, with time support wholly later than u_0; take lambda_v=0. By continuity and positivity of a_o/d, (K_G*lambda)_p is positive on a neighborhood of (s_0,u_0). This test and the zero test agree through u_0 but produce different adjoint values near u_0. Thus the nontrivial forward-time restriction is not, in general, a causal feedback from lambda to carrier force.

This identifies a limitation of directly using the mathematical adjoint as an RX-style same-time loading operator. It does not exclude causal realizations with additional propagation, memory, storage or different ports. C6 by itself specifies none of those realizations. The time-integrated adjoint identity is not an instantaneous power identity.

## 6. W04 — present carrier state versus arbitrary supplied history

On the smooth history class underlying (7), the present carrier state alone does not generally determine C6 output.

**Proof by explicit histories.** Fix X_0 in the interior of an actual G segment, 0<t_0<T and any carrier point s_0. Then

\[
u_*:=t_0-\vartheta_{X_0}(s_0)\in(-T_{\rm hist},t_0).
\]

Choose a smooth nonnegative time bump phi with phi(u_*)>0 and compact support inside (-T_hist,t_0). Set Q_0=0 and Q_1(s,u)=(phi(u),0), constant and periodic in s. Both are smooth, and Q_0(s,t_0)=Q_1(s,t_0)=0. For s in a neighborhood of s_0, phi(t_0-vartheta_{X_0}(s))>0. The positive scalar kernel gives U_1(X_0,t_0)>0 while U_0(X_0,t_0)=0. Continuity gives a difference on a nonempty observation neighborhood, as well as at the point.

These are arbitrary histories in the declared analytic domain of the observation formula. The bump is not asserted to solve C1 or RX. Therefore this proof does not establish two RX trajectories with the same current state, failure of reconstruction from the full (x,p,r_c,z) state, or a universal failure under a specified launch/history protocol. A dynamical restriction can reduce the history class and must be assessed separately if needed. This claim also does not replace the accepted common-phase information result. [CR C05 and its qualifications]

## 7. W05 — necessary work and history residuals

### 7.1 Retain the existing subsystem

For reference the RX exchange uses

\[
f(x)=K(a\times b),\quad x=(a,b),\quad J_f=D_xf,\quad J_fx=2f,
\]
\[
q=\eta_Nf(x)-\eta_Rz,\qquad y=\mathcal B^*p,
\quad \dot x=-\frac{\eta_N}{2\alpha_N}J_f^Ty,
\quad \dot z=\frac{\eta_R}{\beta_R}y,
\tag{11}
\]

with the original finite tent-profile operator B, parameters and registers. Its stores are

\[
H_N=\alpha_N|x|^2/2,\quad H_C=\frac12\int_0^L(p^2+r_c^2)ds,
\quad H_R=\beta_R|z|^2/2,\quad H_{\rm base}=H_N+H_C+H_R.
\tag{12}
\]

The existing z is an unplaced reversible receiver, not a G load or six new objects. RX supplies the matched native debit absent from the older uncoupled C1 comparison. Do not revive that superseded limitation. [RX `eq:system`, `eq:storages`, accounts]

### 7.2 Hypothetical added carrier forcing

Only for a compatibility calculation, write possible added terms as F=(F_p,F_r):

\[
p_t+c(r_c)_s=\mathcal Bq+F_p,\qquad
(r_c)_t+cp_s=F_r,
\tag{13}
\]

while retaining (11) exactly. No F is chosen by this notation. Conditional on a solution with regularity sufficient for the product/energy identity (for example, on each exchange interval Q in C H1_per intersect C1 L2), multiplication gives

\[
e_t+j_s=p\mathcal Bq+pF_p+r_cF_r,
\qquad e=(p^2+r_c^2)/2,\quad j=cp r_c.
\tag{14}
\]

Periodic integration, B/B* adjointness and J_f x=2f yield

\[
\boxed{\dot H_{\rm base}=P_{\rm add}(t),\qquad
P_{\rm add}(t)=\int_0^L[pF_p+r_cF_r]ds.}
\tag{15}
\]

**Proof.** The native and old receiver derivatives remain -eta_N f dot y and +eta_R z dot y. The carrier derivative is eta_N f dot y-eta_R z dot y+P_add. The original work cancels exactly. The local identity is distributional at the stated H1 regularity. This conditional derivation does not prove well-posedness for unspecified F. [RX power]

For a hybrid window [0,T], choose post-jump endpoint values and include jumps 0<t_j<=T, as in RX accounts. Let

\[
B_N=\sum_{0<t_j\le T}\frac{\alpha_N}{2}
[I(F_{\rm native}\Omega(t_j^-))-I(\Omega(t_j^-))].
\]

Here F_native is the unchanged native map, distinct from the added forcing pair F. Assuming only the original native jumps and no new impulses,

\[
\boxed{\Delta H_{\rm base}-B_N=\int_0^T P_{\rm add}(t)dt.}
\tag{16}
\]

The jump sum is zero for an exchange-only window. It is not additional port work. Native parameters, F-first/exchange-second order and existing finite-step qualifications are unchanged. [RX `eq:baselinewindow`, `eq:hybridbalance`; CAD]

### 7.3 A test work ansatz and the unavoidable history term

Define the mathematical pairing

\[
W^{\rm test}:=\langle\lambda,\mathcal K_GQ\rangle_{\mathcal Y},
\qquad
W_{\rm pre}:=\int_{-T_{\rm hist}}^0\int_0^L
Q(s,u)\cdot(\mathcal K_G^*\lambda)(s,u)\,ds\,du.
\tag{17}
\]

Calling W_test physical receiving work would be an additional ansatz, requiring suitable dual units and a constitutive meaning for lambda. Neither has been supplied by C6. The arclength pairing has no implied surface-power interpretation.

For the formal choice F=-K_G*lambda restricted to forward times [0,T], (10) and (16) give

\[
\boxed{\Delta H_{\rm base}+W^{\rm test}-B_N=W_{\rm pre}.}
\tag{18}
\]

**Proof.** Split the H pairing in (10) at u=0. Its forward part is -integral_0^T P_add. The remaining part is W_pre. Substitute (16); the right-hand sign in (18) is positive.

Thus forward-window cancellation with this test work fails unless the prehistory pairing vanishes. Zero prehistory is sufficient, not necessary; test supports, orthogonality or cancellation can also make W_pre zero. Even if it vanishes, (18) is only an integrated identity, and the adjoint generally retains the advanced dependence described in W03. No existence or causality for this formal added force is asserted.

### 7.4 Requirements for a future extension

If a future model declares an additional receiving power P_G and admits no intermediate store or external powers, its closed exchange account would require P_add=-P_G. If it explicitly introduces a transit store E_tr, the necessary balance becomes

\[
\dot E_{\rm tr}=-P_{\rm add}-P_G.
\tag{19}
\]

These are necessary accounting relations only. Defining E_tr from a residual does not establish nonnegativity, causal dynamics, material location, or an admissible transported quantity. Dissipation or external power, if later introduced, must appear explicitly with its own sign and meaning.

The exact problem is now narrower: a proposed extension must identify its spatial interaction and state, its causal loading, and a valid work/storage account. The observation formula and mathematical adjoint do not choose these. In particular they do not encode the author's outward–around–inward path, its return branch, or transfer elsewhere.

## 8. Review decision sought

Independently establish, correct or reject W01–W05 under these explicit assumptions. Preserve proof-level distinctions between a bounded history operator, point records, a Hilbert adjoint, a hypothetical integrated work pairing and a physical receiving mechanism.

If these results survive review, the completed contribution will be a precise observation-and-work compatibility assessment. A subsequent proposal can then address the missing causal transport/state connection with these requirements visible. A meaningful author choice should be asked only when concrete spatial proposals remain after that source and mathematical work; none is required to complete the present five claims.

This is not a manuscript/publication order. No new receiver, six-way allocation, curve, tube, aperture, observer schedule, physical speed or cadence value is selected. Gravity–magnetism correspondence remains linked; outer geometry and justified SRG integration remain later directions without a newly imposed strict order.
