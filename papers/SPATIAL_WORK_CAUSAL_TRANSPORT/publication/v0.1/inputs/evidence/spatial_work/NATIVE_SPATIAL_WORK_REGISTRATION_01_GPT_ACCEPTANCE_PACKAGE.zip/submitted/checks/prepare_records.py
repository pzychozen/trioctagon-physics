"""Resolve current source/proof locators and validate the review's documentary records."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re

ROOT=Path(__file__).resolve().parent.parent
assert os.environ.get('CONDA_DEFAULT_ENV')=='torment'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
specs={
 'CC-G':('inputs/sources/CC/geometry.tex',['eq:constants','eq:directions','eq:vertices','eq:G','eq:circleconstants','eq:circle']),
 'CC-C':('inputs/sources/CC/carrier.tex',['eq:C1','eq:storage','eq:C6']),
 'PG':('inputs/sources/PG/geometry.tex',['prop:balls']),
 'RX-C':('inputs/sources/RX/candidate.tex',['eq:drive','eq:tents','eq:ports','eq:storages','eq:system']),
 'RX-P':('inputs/sources/RX/power.tex',['eq:jacobian','eq:localwork','eq:balances']),
 'RX-A':('inputs/sources/RX/accounts.tex',['eq:baselinewindow','eq:windowbalances']),
 'RX-H':('inputs/sources/RX/hybrid.tex',['eq:tuple','eq:nativemap','eq:hybrid','eq:hybridbalance']),
}
locators=[]
for key,(path,labels) in specs.items():
    p=ROOT/path;lines=p.read_text(encoding='utf-8').splitlines()
    for label in labels:
        marker='\\label{'+label+'}'
        found=[i+1 for i,line in enumerate(lines) if marker in line]
        assert len(found)==1,(path,label,found)
        locators.append({'id':key+'/'+label,'source_key':key,'path':path,'locator':label,'line':found[0],'line_text':lines[found[0]-1],'sha256':sha(p),'bytes':p.stat().st_size})
extras=[
 ('SO','inputs/accepted/six_opening/NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01_PROOF_REVIEW.md',r'\tag{V17}','V17'),
 ('SO','inputs/accepted/six_opening/NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01_PROOF_REVIEW.md',r'\tag{V18}','V18'),
 ('SO','inputs/accepted/six_opening/NATIVE_SIX_OPENING_TRANSPORT_CORRESPONDENCE_01_PROOF_REVIEW.md','### C6 remains an unloaded observation','S04-C6'),
 ('SO-ACCEPT','inputs/accepted/six_opening/GPT_ACCEPTANCE.json','"disposition": "ACCEPTED_S01_S05_AS_STATED_AT_SPECIFIED_ASSUMPTIONS"','acceptance'),
 ('CR','inputs/accepted/central_route/NATIVE_CENTRAL_ROUTE_CORRESPONDENCE_01_GPT_REVIEW.md','## 5. Q01','Q01'),
 ('CR','inputs/accepted/central_route/NATIVE_CENTRAL_ROUTE_CORRESPONDENCE_01_PROOF_REVIEW.md','## C05','C05'),
 ('CAD','inputs/accepted/cadence/CORRECTIONS_AND_LIMITS.md','## Remaining gaps','limits'),
 ('CAD','inputs/accepted/cadence/CADENCE_STATUS.md','#','status'),
 ('CTX','inputs/context/CONTINUATION_STATUS.md','## Execution scope','scope'),
 ('CTX','inputs/context/COLLABORATION_AND_GEOMETRY.md','## The clarified picture','intention'),
]
for key,path,marker,label in extras:
    p=ROOT/path;lines=p.read_text(encoding='utf-8').splitlines()
    found=[i+1 for i,line in enumerate(lines) if marker in line]
    if marker=='#':found=found[:1]
    assert len(found)==1,(path,marker,found)
    locators.append({'id':key+'/'+label,'source_key':key,'path':path,'locator':label,'line':found[0],'line_text':lines[found[0]-1],'sha256':sha(p),'bytes':p.stat().st_size})
write(ROOT/'SOURCE_LOCATORS.json',{'task':'NATIVE_SPATIAL_WORK_REGISTRATION_01','scope':'Current retained paths, labels/headings and one-based lines used by this independent review. Historical registries retain their own scope.','count':len(locators),'locators':locators})

proof_name='NATIVE_SPATIAL_WORK_REGISTRATION_01_PROOF_REVIEW.md'
proof=ROOT/proof_name;prooftext=proof.read_text(encoding='utf-8');plines=prooftext.splitlines()
sections={}
for number in range(1,7):
    found=[i+1 for i,l in enumerate(plines) if l.startswith(f'## R{number}. ')]
    assert len(found)==1
    sections[number]=found[0]
source_keys={
 'W01':['CC-G','PG','SO','SO-ACCEPT'],
 'W02':['CC-C','SO'],
 'W03':['CC-C'],
 'W04':['CC-C','CR'],
 'W05':['RX-C','RX-P','RX-A','RX-H','CAD'],
}
corroboration={'W01':['A01','A02'],'W02':[],'W03':['A04'],'W04':[],'W05':['A03','A04']}
limits={
 'W01':['Common width and whole-construction reflection only.','Ball radius is not cylindrical radius; history ceiling is not optimized.','Actual arcs and mathematical arclength; no aperture/flux convention.','Accepted separation is an input, not rerun.'],
 'W02':['Complete supplied history including negative times.','Space-time a.e. output; no L2 single-point bound.','Point records use the stronger C(I;H1) hypothesis.','Width-uniform upper bound does not calibrate speed or time.'],
 'W03':['Zero extension of lambda and full prehistory domain are essential.','Forward restriction zero a.e. for T<=minimum delay.','Future-support witness applies for T>minimum delay.','No instantaneous physical power interpretation or universal causal-realization prohibition.','A04 is an arithmetic example, not the geometry-dependent proof.'],
 'W04':['Arbitrary smooth histories, not generated C1/RX solutions.','No full-state reconstruction, native invertibility or specified empty-launch conclusion.','Separate conditional common-phase information result retained.'],
 'W05':['Conditional sufficient regularity and integrable work; no new well-posedness theorem.','Original ports, native/old receiver equations and F-first order retained.','Finite native jumps, post-jump endpoints, no new impulses.','Prehistory pairing has a plus sign but is not necessarily nonnegative.','Zero prehistory is sufficient but not necessary for cancellation.','Formal adjoint loading is generally advanced on longer windows.','No adopted physical load/units, receiver or nonnegative transit state.'],
}
detail={
 'W01':['All six broken arcs and twelve segments including wraparound checked.','Endpoint ball inequality exact, attained by lower tips at maximum static parameter.','Total arclength and all-parameter upper bound exact.'],
 'W02':['Bound a_o sqrt(L M)/delta follows by time substitution and Tonelli.','Representative independence and unique density extension established.','Joint continuity and smooth narrow-graph counterexample established.'],
 'W03':['Both adjoint components and tangent projection derived directly.','Window indicator has unit time Jacobian; prehistory retained.','Noncausality witness is positive on a positive-measure set before cutoff.'],
 'W04':['Explicit compactly supported nonnegative bump contains an actual retarded time.','Present carrier values agree while observations differ on a neighborhood.'],
 'W05':['Euler factor and B/B* cancellation give p F_p+r_c F_r.','Native jump sum counted exactly on 0<t_j<=T.','Delta H_base+W_test-B_N=W_pre proved for geometry-dependent delays.','Short-window case and exact signed/cancelling examples checked.'],
}
original=json.loads((ROOT/'inputs/CLAIM_LEDGER.json').read_text(encoding='utf-8'))
claims=[]
for number,c in enumerate(original['claims'],1):
    id=c['id'];assert id==f'W{number:02d}'
    claims.append({'id':id,'title':c['title'],'submitted_result':c['proposed_result'],'status':'verified-as-stated','assumptions':c['assumptions'],'proof_location':{'path':proof_name,'section':f'R{number}','start_line':sections[number],'end_line':sections[number+1]-1,'sha256':sha(proof)},'source_locations':[r for r in locators if r['source_key'] in source_keys[id]],'depends_on_new_claims':{'W01':[],'W02':['W01'],'W03':['W01','W02'],'W04':['W01','W02'],'W05':['W03']}[id],'findings':detail[id],'computation':{'groups':corroboration[id],'code':'checks/exact_checks.py' if corroboration[id] else None,'record':None},'correction':None,'limits':limits[id]})

# Fill the corroboration record separately to keep null fields explicit for purely written arguments.
for c in claims:
    c['computation']['record']='logs/EXACT_CHECKS.json' if c['computation']['groups'] else None
write(ROOT/'CLAIM_LEDGER.json',{'task':'NATIVE_SPATIAL_WORK_REGISTRATION_01','reviewer':'Codex','review_date':'2026-11-10','disposition':'W01_W05_VERIFIED_AS_STATED_AT_SUBMITTED_ASSUMPTIONS','gpt_author_acceptance_of_this_review':'pending subsequent assessment','claims':claims,'mathematical_corrections':[],'accepted_foundations':['C01-C05 with Q01','S01-S05','native F/cadence qualifications'],'scope':'Local independent proof review only; no manuscript, kernel or publication work.'})

identities=json.loads((ROOT/'INPUT_IDENTITIES.json').read_text(encoding='utf-8'))
for row in identities['files']:
    p=ROOT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
executions=json.loads((ROOT/'logs/EXECUTION_RECORD.json').read_text(encoding='utf-8'))
assert len(executions['executions'])==2 and all(r['exit_status']==0 for r in executions['executions'])
algebra=json.loads((ROOT/'logs/EXACT_CHECKS.json').read_text(encoding='utf-8'))
assert algebra['status']=='PASS' and algebra['group_count']==4 and all(r['status']=='PASS' for r in algebra['groups'])
tags=re.findall(r'\\tag\{(R[0-9]+\.[0-9]+)\}',prooftext)
assert len(tags)==len(set(tags))
assert all(k in set(tags) for k in re.findall(r'\((R[0-9]+\.[0-9]+)\)',prooftext))
link_count=0
for name in (proof_name,'README.md','CORRECTIONS_AND_LIMITS.md','RESULT_SUMMARY.md'):
    text=(ROOT/name).read_text(encoding='utf-8')
    assert text.count('\\[')==text.count('\\]'),name
    assert text.count('\\(')==text.count('\\)'),name
    assert not re.search(r'\b(?:TODO|TBD|FIXME)\b',text),name
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if '://' not in target:
            assert (ROOT/target.split('#')[0]).is_file(),(name,target)
            link_count+=1
write(ROOT/'logs/DOCUMENT_CHECKS.json',{'status':'PASS','observed_utc':datetime.now(timezone.utc).isoformat(),'command':'run_python.cmd checks\\prepare_records.py','source_locators':len(locators),'proof_equation_tags':len(tags),'current_document_links_resolved':link_count,'claim_count':len(claims),'claim_statuses':{c['id']:c['status'] for c in claims},'preserved_packet_members_rechecked':len(identities['files']),'actual_algebra_groups_passed':4,'proof_sha256':sha(proof),'scope':'Document/provenance consistency only; written proofs supply mathematical verification.'})
print(json.dumps({'status':'PASS','source_locators':len(locators),'claims':len(claims),'equations':len(tags),'local_links':link_count},indent=2))
