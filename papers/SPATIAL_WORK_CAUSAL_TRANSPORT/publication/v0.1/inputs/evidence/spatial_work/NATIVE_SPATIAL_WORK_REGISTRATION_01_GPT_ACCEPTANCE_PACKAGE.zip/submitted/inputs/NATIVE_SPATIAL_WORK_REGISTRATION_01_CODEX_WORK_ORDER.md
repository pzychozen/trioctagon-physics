# Codex work order — C6 spatial observation and work compatibility

**Task ID:** `NATIVE_SPATIAL_WORK_REGISTRATION_01`  
**Date:** 10 November 2026  
**Requested outcome:** Independent proof review of W01–W05, with a complete local review packet for GPT and author review.

## 1. Start here

The author has confirmed successful publication of the combined central-route/six-opening paper and asked to move on without checking that publication. Treat the publication as closed. `context/CONTINUATION_STATUS.md` records the confirmation as author-reported, not as an audit performed for this task.

GPT has prepared a new analytical start using the existing C6 retarded observation and RX reciprocal exchange. The assessment asks what C6 defines on the six actual G boundaries and what follows from its exact mathematical dual/work pairing. It selects no new material receiver or transport mechanism.

Read, in order:

1. This work order and `context/CONTINUATION_STATUS.md`.
2. `NATIVE_SPATIAL_WORK_REGISTRATION_01_GPT_ANALYTICAL_START.md`.
3. `CLAIM_LEDGER.json` and `SOURCE_MAP.md`.
4. The cited preserved source sections and accepted qualifications needed for each claim.

The files under `preparation/` are GPT's internal source/derivation reviews. They explain preparation but are not independent Codex acceptance. Challenge the analytical start directly; do not turn those notes into your verification evidence.

## 2. Workspace and execution

Use the established local Windows project:

`C:\TORMENT\TRIOCTAGON_new\research\NATIVE_SPATIAL_WORK_REGISTRATION_01`

In Command Prompt:

```bat
conda activate torment
cd /d C:\TORMENT\TRIOCTAGON_new
```

Use the existing `torment` environment. The previous checks reported Python 3.11.15; record the actual current interpreter/version rather than treating that report as a new measurement. Do not modify the environment for convenience. If an optional symbolic package is absent, use exact arithmetic or a transparent manual derivation available in the existing environment before declaring a blocker.

Preserve this packet unchanged under `inputs/` in the task folder. If the folder already exists, inventory it and preserve existing work; use a distinct run/output directory as needed. Record local SHA-256/byte identities for the supplied inputs and compare them with `SOURCE_IDENTITIES.json` and `PACKET_MANIFEST.json`. This is new-task input validation, not a repeat of the published-file audit.

All exact source definitions needed for the five groups are supplied. Repository sources are pinned to the earlier reading checkpoint identified in their source ledger. The publication confirmation does not require fresh GitHub downloads. Recover routine source details from the packet or local project yourself; do not ask the author to reconstruct old coefficients or geometry.

## 3. Independent review groups

### W01 — actual G sets, arclength and finite history horizon

Derive the new bounds directly from the preserved vertices and circle:

- Check all six actual two-segment G arcs, including the last wraparound segment and common-width scaling.
- Check the enclosing **ball** radius `R_0`, its exact endpoint inequality, and its distinction from cylindrical radius.
- Check the triangle-inequality distance ceiling and sufficient C6 history horizon. It is not claimed to be the optimized maximum delay.
- Derive the exact total labeled arclength and its all-static-parameter upper bound. Only horizontal lengths gain the deformation factor D; do not scale the whole lower edge by D.
- Confirm both-hand invariance by the full reflection, with labels retained.

Use the accepted >297/5000 common-width clearance as an input. Do not rerun the previous S01–S05 investigation or substitute a new separation calculation. Arclength is used as a mathematical test/norm measure; no aperture, normal or physical flux weight is being selected.

### W02 — bounded causal history operator and correct regularity

Prove the stated map from the declared space-time L2 history space into L2 on the six G arcs and observation window. Check the time substitution, the exact sqrt(LM)/delta factor, and independence from representatives through Fubini/density. All required negative-time history must be included.

Separately verify the continuous-record statement for `C(I;H1_per)` histories. Check the narrow-graph example showing that evaluation at one `(X,t)` is unbounded in the L2 history norm. Do not replace a space-time estimate with an unjustified single-time trace or diagonal-sampling estimate. Confirm observation causality and the stated common-width uniformity without selecting numerical speeds or a physical time scale.

### W03 — finite-window adjoint and advanced dependence

Derive the adjoint from the pairing independently. Retain the zero extension outside `[0,T]`, the negative-time domain, both output components, and the ambient-vector/frame convention. Verify that no derivative of the delay or extra Jacobian arises in the time substitution.

Check both window regimes:

- If `T <= minimum delay`, the forward-time restriction of the adjoint is zero almost everywhere, even though its prehistory part can remain nonzero.
- If `T > minimum delay`, construct a positive scalar test with future support that witnesses noncausal dependence of the nontrivial forward-time restriction.

The conclusion concerns direct use of this particular Hilbert adjoint as feedback. It does not prohibit all causal systems with additional propagation, memory, storage or different ports. Do not present integrated duality as instantaneous power matching.

### W04 — scoped history-versus-present-state witness

Verify the explicit smooth histories, their identical present carrier values and different retarded C6 outputs. Check that the time bump overlaps an actual delayed sampling time and lies strictly inside the history domain.

These histories belong to the analytic domain of the observation formula. They are not claimed to be generated by C1/RX. Do not upgrade this witness into two actual RX solutions, a full-state nonreconstructibility result, a hybrid invertibility claim, or a universal conclusion under a specified empty-launch protocol. Keep the accepted common-phase information result separate.

### W05 — added work, native jumps and prehistory residual

With the existing native and old z-receiver equations unchanged, independently derive the local identity and total added-power residual for symbolic additional carrier forces `(F_p,F_r)`. Check the factor one-half in native feedback, the Euler identity, the original B/B* cancellation and the signs of both added terms.

For a finite hybrid window retain the source's post-jump endpoint convention and include only `0 < t_j <= T`. Preserve the native jump sum, F-first/exchange-second order and the distinction between native map F and additional force F.

Then independently derive the formal finite-window identity with `F = -K_G* lambda` restricted to forward times. The residual on the right must be the **positive prehistory pairing**. Zero prehistory is sufficient, not necessary, for that pairing to vanish. Check the short-window case as well. An exact simple-delay example may help catch a sign/window error, but cannot replace the proof for the geometry-dependent delays.

Confirm the limits of the result: it is a conditional balance identity, not well-posedness for unspecified force, a causal load construction, or a nonnegative transit-store theorem. Any proposed receiving or transit balance remains a requirement for a later model, not a newly adopted store defined from a residual.

## 4. Verification standard

Give a mathematical proof or a concrete counterexample for each substantive claim. Use exact algebra for the radical/length identities and exact changes of integration variables for the operator results. A decimal plot, finite grid or assertion copied from the analytical start does not establish the quantifiers.

Targeted scripts are appropriate where they check a real algebraic issue. Record their actual environment, command, output and exit status. Prefer a small set of independent checks over repeated parameter sweeps. Analytic claims about spaces, regularity, causality, measure-zero endpoints and arbitrary histories require written reasoning; label computational corroboration accordingly.

If a local wording or mathematical correction is needed, state the submitted claim, correction, proof/counterexample and impact. Complete every unaffected group. Do not silently alter an assumption to make a claim pass, or preserve a false proposed result because the packet calls it W01–W05. If the evidence shows that an operator, boundary or history is different from the supplied definition, resolve it against the source and report the discrepancy.

There is no author geometry decision required by the present five checks. If you discover a genuine decision that prevents one claim, first complete the source recovery and all independent work possible, identify the concrete alternatives and their consequences, and return one focused question. A desire to build a new spatial model is not a blocker to this assessment.

## 5. Deliverables

Return these files under the task folder:

| Deliverable | Contents |
| --- | --- |
| `NATIVE_SPATIAL_WORK_REGISTRATION_01_PROOF_REVIEW.md` | Complete independent proofs/dispositions for W01–W05, with source/equation crosswalk and precise assumptions. |
| `CLAIM_LEDGER.json` | Per-claim status, source locators, proof location, computation if any, correction and limits. Use pending/verified-as-stated/verified-with-correction/rejected/unresolved as appropriate. |
| `CORRECTIONS_AND_LIMITS.md` | Any required changes and the retained domain/interpretation limits, including the short-window and prehistory qualifications. |
| `INPUT_IDENTITIES.json` | The preserved-input identity check and any discrepancy/recovery record. |
| `checks/` and `logs/` | Any independent check code and actual execution output. Do not fabricate a test count or record an unexecuted check as passed. |
| `RESULT_SUMMARY.md` | A short plain-language account of what the review established and the precise remaining spatial-model question. |
| `delivery/NATIVE_SPATIAL_WORK_REGISTRATION_01_REVIEW.zip` | Preserved inputs, proofs, ledger, limits, checks and logs with a manifest. |
| `delivery/NATIVE_SPATIAL_WORK_REGISTRATION_01_REVIEW.zip.sha256` | SHA-256 of the completed review ZIP. |

Make the proof review readable on its own, while keeping exact source links and identities in the packet. The ZIP should contain the complete review evidence needed for GPT review.

## 6. Scope and closeout

This work is local research verification. Return the evidence for GPT review. It is not an order to write a manuscript, modify the native kernel, create a new receiver, or publish/commit/push changes. The previous publication authorization concerned the now-completed combined paper.

The completed central-route and six-opening results remain foundations, with Q01 and all stated limits preserved. C6 is an inherited observation being assessed, not an adopted physical gravity/magnetism field or a demonstrated outward–around–inward circuit. Continue the research in the order justified by the new findings; do not impose a new strict ordering on the previously unordered later directions.
