"""Freeze the complete review and reopen every archived member for hash verification."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parent.parent
assert os.environ.get('CONDA_DEFAULT_ENV')=='torment'
def sha(data):return hashlib.sha256(data).hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
command=[sys.executable,str(ROOT/'checks/prepare_records.py')]
start=datetime.now(timezone.utc).isoformat()
run=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
(ROOT/'logs/prepare_records.stdout.txt').write_text(run.stdout,encoding='utf-8')
(ROOT/'logs/prepare_records.stderr.txt').write_text(run.stderr,encoding='utf-8')
write(ROOT/'logs/PREPARE_RECORDS_EXECUTION.json',{'command':command,'parent_command':'run_python.cmd checks\\package_review.py','conda_environment':os.environ.get('CONDA_DEFAULT_ENV'),'started_utc':start,'completed_utc':datetime.now(timezone.utc).isoformat(),'exit_status':run.returncode,'stdout':'logs/prepare_records.stdout.txt','stderr':'logs/prepare_records.stderr.txt'})
print(run.stdout,end='');print(run.stderr,end='',file=sys.stderr)
if run.returncode:sys.exit(run.returncode)

proof_name='NATIVE_SPATIAL_WORK_REGISTRATION_01_PROOF_REVIEW.md'
proof=ROOT/proof_name
proof.with_suffix('.md.sha256').write_text(sha(proof.read_bytes())+'  '+proof_name+'\n',encoding='ascii')
required=['README.md','RESULT_SUMMARY.md',proof_name,proof_name+'.sha256','CLAIM_LEDGER.json','CORRECTIONS_AND_LIMITS.md','INPUT_IDENTITIES.json','SOURCE_LOCATORS.json','logs/ENVIRONMENT.json','logs/EXECUTION_RECORD.json','logs/EXACT_CHECKS.json','logs/DOCUMENT_CHECKS.json']
assert all((ROOT/p).is_file() for p in required)
ledger=json.loads((ROOT/'CLAIM_LEDGER.json').read_text(encoding='utf-8'))
assert len(ledger['claims'])==5 and all(c['status']=='verified-as-stated' for c in ledger['claims'])
for c in ledger['claims']:
    assert c['proof_location']['sha256']==sha(proof.read_bytes())
    for source in c['source_locations']:
        p=ROOT/source['path']
        assert sha(p.read_bytes())==source['sha256']
        assert p.read_text(encoding='utf-8').splitlines()[source['line']-1]==source['line_text']
inputs=json.loads((ROOT/'INPUT_IDENTITIES.json').read_text(encoding='utf-8'))
assert sha((ROOT/inputs['archive']['path']).read_bytes())==inputs['archive']['sha256']
with zipfile.ZipFile(ROOT/inputs['archive']['path']) as z:
    for row in inputs['files']:
        data=(ROOT/row['path']).read_bytes()
        assert sha(data)==row['sha256'] and data==z.read(row['path'].removeprefix('inputs/'))

files=sorted(p for p in ROOT.rglob('*') if p.is_file() and 'delivery' not in p.relative_to(ROOT).parts and '__pycache__' not in p.parts and p.name!='MANIFEST.json')
inventory={'task':'NATIVE_SPATIAL_WORK_REGISTRATION_01','created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Every other member of the review ZIP; excludes this manifest itself. External delivery archive, checksum and archive-verification receipt are not recursive members.','file_count':len(files),'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]}
manifest=ROOT/'MANIFEST.json';write(manifest,inventory)
delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True)
archive=delivery/'NATIVE_SPATIAL_WORK_REGISTRATION_01_REVIEW.zip'
assert not archive.exists(),'Preserve existing delivery; use a distinct output if deliberately rebuilding.'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[manifest]:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(files)+1
    assert set(z.namelist())=={r['path'] for r in inventory['files']}|{'MANIFEST.json'}
    assert z.read('MANIFEST.json')==manifest.read_bytes()
    for row in inventory['files']:
        data=z.read(row['path'])
        assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
    assert z.read(proof_name)==proof.read_bytes()
archive_sha=sha(archive.read_bytes())
archive.with_suffix('.zip.sha256').write_text(archive_sha+'  '+archive.name+'\n',encoding='ascii')
receipt={'task':'NATIVE_SPATIAL_WORK_REGISTRATION_01','completed_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_LOCAL_REVIEW','command':'run_python.cmd checks\\package_review.py','python':sys.version,'conda_environment':os.environ.get('CONDA_DEFAULT_ENV'),'archive':{'filename':archive.name,'bytes':archive.stat().st_size,'sha256':archive_sha,'members':len(files)+1,'manifest_entries':len(files),'all_members_reopened_and_verified':True,'zip_crc_check':'PASS'},'proof':{'path':proof_name,'bytes':proof.stat().st_size,'sha256':sha(proof.read_bytes()),'standalone_matches_archive':True},'claims':{c['id']:c['status'] for c in ledger['claims']},'input_members_preserved':52,'input_manifest_entries_verified':51,'source_identities_verified':37,'independent_exact_algebra_groups_passed':4,'source_locators_resolved':34,'mathematical_corrections':[],'gpt_author_acceptance':'Not claimed; returned for assessment.','repository_changes':'None made by this task.','publication_audit':'Not performed in this task.'}
write(delivery/'ARCHIVE_VERIFICATION.json',receipt)
print(json.dumps(receipt,indent=2))
