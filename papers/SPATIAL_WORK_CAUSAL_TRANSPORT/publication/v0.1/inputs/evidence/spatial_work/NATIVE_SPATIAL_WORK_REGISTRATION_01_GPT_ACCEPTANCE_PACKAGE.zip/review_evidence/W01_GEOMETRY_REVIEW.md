# W01 geometry review

**Task:** NATIVE_SPATIAL_WORK_REGISTRATION_01 — GPT review of the returned Codex research.  
**Scope:** W01, proof R1, its claim-ledger/limit entries, and supporting A01/A02 code and supplied logs.  
**Decision:** **ACCEPT W01 AS STATED at the submitted assumptions. No mathematical correction is required.**

This is a current research subreview, not a publication audit or a new work order. I did not execute the submitted checker, replay previous tests, or reprove the accepted six-opening separation theorem. Other W claims are outside this disposition.

## 1. Exact source and issued-start correspondence

The submitted R1 agrees with Sections 2.1 and 3 of `inputs/NATIVE_SPATIAL_WORK_REGISTRATION_01_GPT_ANALYTICAL_START.md`: equations (1)–(3), (5), and (6). The returned proof adds useful explicit endpoint, sign, and scaling explanations without changing those claims.

| Submitted component | Retained source and exact locator | Review finding |
| --- | --- | --- |
| Constants, \(A_\tau\), vertex coordinates and closed static interval | `inputs/sources/CC/geometry.tex`: `eq:constants`, `eq:directions`, `eq:vertices`; `inputs/sources/CG/manuscript.tex`: `eq:constants`, `eq:family` | Correct transcription. The lower map acts horizontally and includes both \(\tau_g=0\) and \(\tau_g=h_g\). |
| Actual six broken arcs and reflection | CC `eq:G` and following paragraph; CG `eq:faces` and full MINUS definition, `sec:openings` | Correct cyclic labels and whole-configuration reflection. No closing chord or aperture is introduced. |
| Selected carrier, constants and arclength tangent | CC `eq:circleconstants`, `eq:circle` | Correct carrier with common width and physical geometric arclength \(s\), not an unscaled angle. Only the selected \(j=0\) carrier is active. |
| Original enclosing-ball constant | `inputs/sources/PG/geometry.tex`: `prop:balls` | \(R_0=B_S=\sqrt{13/12-\sqrt2/2}\). R1 derives the G enclosure directly from G vertices; it does not presume G belongs to the material host. |
| Accepted positive lower distance | R0.1 cites accepted SO V17–V18 | Treated solely as an inherited input; no new separation proof or optimized-clearance claim is made. |

The W01 entry in `CLAIM_LEDGER.json` accurately points to R1, states the common-width/static-family/full-reflection assumptions, assigns A01/A02 as corroboration, and retains the limits on radius, delay, measure and inherited separation. Items 1, 4 and 10 of `CORRECTIONS_AND_LIMITS.md` agree with the proof.

## 2. Common width, labels and both hands

R0 explicitly calls \(\tau_g\) a normalized static geometry parameter. R1 first constructs width-one coordinates, then multiplies every centered coordinate by \(w>0\) before translation. Its lower similarity therefore uses
\[
D^2=1+\tau_g^2/r_g^2.
\]
Equivalently, dimensional lower displacement \(w\tau_g\) divided by dimensional radius \(wr_g\) gives the same ratio. There is no independent scaling of the lower geometry or carrier.

The actual upper triples are
\[
(U_0,T_1,U_1),\quad(U_1,T_3,U_2),\quad(U_2,T_5,U_0),
\]
and the lower triples replace \(U,T\) by \(L,B\). R1.2 explicitly includes \([T_5,U_0]\) and \([B_5,L_0]\). Their horizontal dot product is \(1/2\), exactly as on the other edges. The proof counts twelve actual segments, not six triangles or their perimeters.

MINUS is the centered orthogonal reflection \(S=\operatorname{diag}(-1,1,1)\) of the entire registered geometry, retaining labels. Orthogonality preserves norms and lengths. The selected carrier has \(u=(0,1,0)\) and lies in the plane fixed by \(S\); its centered curve and tangent are therefore fixed as well. The same distance bounds apply whether the argument is read as simultaneous reflection or as reflection of G against that unchanged selected carrier. No native-dynamics reflection law is needed.

## 3. Ball bound and sufficient history horizon

R1.3–R1.4 correctly establish
\[
r_g^2+h_g^2+H_0^2=R_0^2,\qquad
r_g^2-a_g^2=\frac{6\sqrt2-7}{24}>0.
\]
The strict radial comparison follows from positivity and \(72>49\). Together with \(0<h_g<H_0\), it makes each elbow smaller than a corresponding tip.

For every lower tip,
\[
|L_k|^2=r_g^2+\tau_g^2+H_0^2,\qquad
R_0^2-|L_k|^2=h_g^2-\tau_g^2\ge0.
\]
The normalized interval justifies the last sign. Upper tips correspond to the undeformed horizontal factor. Norm convexity then extends the endpoint bound to every point of each actual closed segment. Scaling gives
\[
|X-O|\le wR_0.
\]
This is a full Euclidean ball radius, including height. It is not a bound derived by confusing cylindrical radius with ball radius.

The family-wide ball radius is attained at lower tips for \(\tau_g=h_g\). Thus its sharpness statement is justified. It does not say every configuration requires that same radius or that the sphere is material.

The scaled carrier is
\[
\gamma_w(s)=O+wK_cu+wR_\Gamma
  \left(\cos\frac{s}{wR_\Gamma}\,u+
        \sin\frac{s}{wR_\Gamma}\,e_z\right).
\]
Differentiation cancels \(wR_\Gamma\), giving
\[
\hat t(s)=-\sin\chi\,u+\cos\chi\,e_z,\qquad|\hat t|=1.
\]
Consequently \(L=2\pi wR_\Gamma\) and the unit-tangent convention used downstream are consistent.

The triangle inequality proves
\[
d_X(s)\le D_w=w(K_c+R_\Gamma+R_0),\qquad
T_{\rm hist}=D_w/c_e.
\]
For \(t\in[0,T]\), every required retarded time lies in \([-T_{\rm hist},T]\). R1 explicitly distinguishes attainment of the G ball bound from possible simultaneous attainment in the triangle inequality. It correctly describes \(T_{\rm hist}\) as sufficient and unoptimized. No actual largest-delay value, selected physical speed, or physical clock is claimed.

## 4. Exact arclength and measure

R1.6 gives
\[
v_0^2=r_g^2+a_g^2-a_gr_g
     =(r_g-a_g/2)^2+\frac34a_g^2>0.
\]
Adjacent tip/elbow directions are separated by \(60^\circ\), including wraparound. The upper edge length is therefore
\[
\ell_+=\sqrt{v_0^2+d_g^2}.
\]
The lower map multiplies only the horizontal difference by \(D\), leaving vertical difference magnitude \(d_g\). Thus
\[
\ell_-(\tau_g)=\sqrt{D^2v_0^2+d_g^2}.
\]

There are six upper and six lower segments. Within each broken arc the two segments are noncollinear: its two tips have the same height, while its elbow has a different height. They share only the elbow. Hence
\[
M_w(\tau_g)=6w\left[
 \sqrt{v_0^2+d_g^2}+
 \sqrt{D^2v_0^2+d_g^2}
\right]
\]
is exactly the total measure of the defined **disjoint labeled union**. The chosen labeled measure does not depend on resolving multiplicity between distinct labels; shared endpoints have zero arclength.

Because \(v_0^2>0\), the lower edge length increases with \(\tau_g^2\). Thus \(M_{w,*}\), obtained by substituting \(D_*\), is the attained maximum over the normalized static interval; at zero the formula reduces to twelve equal edge lengths. Reflection leaves the same formula unchanged.

R0, R1 and the retained limits correctly identify arclength as a mathematical observation/test measure. It is not aperture area, flow weighting, receiver storage, a physical power density, or a loading law. W01 supplies neither filled G surfaces nor normals.

## 5. A01/A02: code and supplied evidence, without replay

I inspected the A01 and A02 blocks in `checks/exact_checks.py`, their detailed records in `logs/EXACT_CHECKS.json`, `logs/exact_checks.stdout.txt`, and the local execution record. I did **not** run the script or import its functions.

The supplied execution record identifies the Windows `torment` run of `checks/exact_checks.py` and exit status zero. The supplied stdout reports A01 and A02 PASS; the JSON contains the corresponding exact symbolic values and twelve edge records. Those are the submitted execution results, not a fresh GPT replay.

### A01

The code correctly encodes the constants, \(D^2=1+12\tau^2\), and these identities:

- \(H_0-h_g=d_g\);
- \(D(h_g)^2=10-6\sqrt2\);
- \(r_g^2-a_g^2=(6\sqrt2-7)/24\);
- the exact \(R_0^2\) identity and lower-tip margin \(h_g^2-\tau^2\);
- the elbow/tip squared-norm difference;
- the positive-sum decomposition of \(v_0^2\).

The printed expressions agree algebraically with R1. In particular, the recorded \(-7/24+\sqrt2/4\) is the stated radial difference.

Some checks are identity rearrangements; they are appropriately described as algebraic corroboration. The symbolic variable \(\tau\) is merely real in the code, so the code alone does not prove \(h_g^2-\tau^2\ge0\) on the admitted interval. R1 supplies that domain reasoning, endpoint convexity and all-parameter proof, and A01's recorded scope explicitly says so. No tautological identity is passed off as a separate continuum theorem.

### A02

The code freshly assembles the six \(e_i\), all source vertices, and the twelve endpoint differences. It uses \((k+1)\bmod3\) for the wraparound tips. Each computed squared difference is compared with the appropriate upper or lower expression, and each reflected difference is checked against the same expression.

The logged upper expression
\[
\frac{47}{24}-\frac54\sqrt2-\frac1{12}\sqrt3+\frac1{24}\sqrt6
\]
is exactly \(v_0^2+d_g^2\). The logged lower expression is exactly \((1+12\tau^2)v_0^2+d_g^2\). There are twelve records, with both sides of every upper and lower labeled arc present.

The selected tangent is encoded as \((0,-\sin\chi,\cos\chi)\); the code verifies its norm and reflected norm. Its derivation from the scaled carrier is supplied in R1, rather than claimed as a separately executed derivative check. The code does not evaluate a separation minimum, optimized delay, or geometric grid.

A01/A02 therefore corroborate the reported identities and endpoint implementation within their advertised scope. The proof, not the computational group count, supplies W01's universal quantifiers and measure interpretation.

## 6. Disposition

**Accept W01 as stated. No correction or additional qualification is needed beyond the qualifications already present in R0–R1, the issued start, the W01 ledger entry and the returned limits.**

The key distinction is already correctly maintained: the G enclosing radius and static-family arclength maximum are attained bounds, while the carrier-to-G distance ceiling and resulting history horizon are sufficient bounds. The result remains a mathematical observation-domain preparation on the actual stationary broken arcs, with common scale and both hands; it adopts no physical transport or receiving mechanism.

