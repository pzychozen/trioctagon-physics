# Proposed analytical start — response asymmetry and phase drift

14 November 2026. **GPT proposal awaiting independent Codex review.**

This document is not an accepted theorem. Inherited statements below are attributed to the supplied source texts. New combinations, normalized coefficients and local implications are proposed for challenge. The preparation helper checks only rational identities.

## 1. Match the coefficients, not the states

Use the unchanged triad map of `sources/dynamics.py`, and the D1 family

\[
(\epsilon,g,\lambda)=h(1,1/6,1/30),\quad 0<h\le1/4,
\quad k=\mathbf1+\xi,\quad \mathbf1^T\xi=0.
\]

The source's h is a mathematical small-step parameter, not the shell half-edge or physical time. The positive in-phase root selected near one solves

\[
r_i(1+\xi_i-r_i^2)+\tfrac16(L_3r)_i=0. \tag{P1}
\]

It is independent of h after division. At \(\xi=0\), the derivative in r is \(-2I+L_3/6\), whose eigenvalues are \(-2,-5/2,-5/2\). The implicit branch has

\[
r_i=1+\tfrac25\xi_i+O(\|\xi\|^2) \tag{P2}
\]

on the zero-sum plane. This is a specialization of the inherited positive-branch theorem, not a new global branch theorem. At h=0, (P1) selects the limiting branch; the identity map alone does not.

D1 already supplies the two analytic chiral branches from
\(z^*_{+,j}=2^{-1/2}e^{2\pi i j/3}\) and its conjugate, with a common sufficiently small coefficient neighborhood over \(0\le h\le1/4\); see D23–D30. They have **different states** from r, despite identical k, epsilon, g and lambda. Preserve that separation in every comparison.

## 2. Construct the complete in-phase response

Define the real matrix

\[
(\mathsf B_r)_{ij}=\frac{r_j}{6r_i}\quad(i\ne j),\qquad
(\mathsf B_r)_{ii}=-\frac16\sum_{j\ne i}\frac{r_j}{r_i}.
\]

Then GR1's phase prestage and complete response are

\[
P_h=I+h\mathsf B_r,\qquad
J_h=(I+hL_3/10)(I+h\mathsf B_r). \tag{P3}
\]

This uses the positive fixed equations; it is not a derivative at the chiral state. The first-order phase generator is
\(\mathsf G_r=\mathsf B_r+L_3/10\). Native composition also contains the h-squared product term.

Freeze

\[
\mathcal C=J_{01}J_{12}J_{20}-J_{02}J_{21}J_{10}.
\]

All off-diagonals vanish at h=0, so the cycle product has an exact h-cubed factor. This motivates the analytic continuation
\(\overline{\mathcal C}=\mathcal C/h^3\), not an arbitrary physical normalization.

For r=(a,b,c), let \(s_1=a+b+c\), \(s_2=ab+ac+bc\), \(s_3=abc\), and \(V_r=(a-b)(a-c)(b-c)\). Specializing the **corrected published** GR1 factorization gives the proposed exact identity

\[
\overline{\mathcal C}
=\frac{(1-3h/10)V_r}{60s_3^2}\,\mathcal K_h(r), \tag{P4}
\]

\[
\mathcal K_h(r)=\frac{h^2s_1^3}{360}
 +\left(\frac h{90}-\frac{h^2}{180}\right)s_1s_2
 +\left(\frac h{20}-\frac1{15}\right)s_3. \tag{P5}
\]

Here \(\mathcal K_h\) is the old \(\mathcal K/h\) on this family, with a removable limit. It is not a newly selected potential. The preparation script also checks (P4) by forming all entries of (P3), independently of substituting only into GR1's final factorization.

## 3. Reconcile the alternating factors

D1 uses

\[
\mathcal A(\xi)=(\xi_0-\xi_1)(\xi_1-\xi_2)(\xi_2-\xi_0),
\qquad \mathcal A(-\eta,0,\eta)=2\eta^3.
\]

GR1 uses the product over increasing pairs, which is \(-\mathcal A\). The response branch is permutation-equivariant by local uniqueness. Its pair differences are analytically divisible by the corresponding coefficient differences. On the zero-sum coefficient plane the resulting normalized response quotient should be symmetric and have no linear term.

Using (P2) and (P4)–(P5), the proposed response coefficient is

\[
\overline{\mathcal C}(h,\xi)=\mathcal A(\xi)
\left[a_C(h)+O(\|\xi\|^2)\right],\qquad
 a_C(h)=\frac{(1-3h/10)(8-18h-3h^2)}{112500}. \tag{P6}
\]

The remainder is to be proved in the **analytic quotient**, not inferred by dividing an undifferentiated fifth-order error by a nearly vanishing Vandermonde. This distinction is necessary for assertions near equal-coefficient planes.

D1 already proves analytic alternating divisibility and, with its fixed positive chirality convention,

\[
\nu_+(h,\xi)=\mathcal A(\xi)
\left[c_+(h)+O(\|\xi\|^2)\right],\qquad
c_+(h)=\frac{\sqrt3(33h^2-240h+688)}{6(1-3h)^3},\quad
\nu_-=-\nu_+. \tag{P7}
\]

The published coefficient was computed on \(\xi=\eta(-1,0,1)\). Its extension as the constant term of the symmetric quotient uses the inherited divisibility theorem, not a new arbitrary-direction jet calculation.

## 4. Candidate local zero/sign theorem

On \(0\le h\le1/4\), both proposed coefficients in (P6)–(P7) are positive. For example,

\[
1-3h/10\ge37/40,\qquad 8-18h-3h^2\ge53/16,
\qquad a_C(h)\ge1961/72000000>0.
\]

D1 gives positivity of c+ on the same compact interval. Verify the joint analytic/continuity hypotheses. If they hold, compactness supplies some common, not numerically quantified, heterogeneity neighborhood on which the full analytic quotients \(S_C\) and \(S_D\) remain positive.

Consequently, within that neighborhood:

- \(\overline{\mathcal C}=0\) and \(\nu_\pm=0\) precisely on the union of the three equal-coefficient planes.
- Off those planes, \(\operatorname{sgn}\nu_+=\operatorname{sgn}\overline{\mathcal C}=\operatorname{sgn}\mathcal A\), while the negative-chirality rate has the opposite sign.
- There is a positive analytic symmetric quotient
  \(\Theta=S_D/S_C\) extending across those planes, with

\[
\nu_\pm=\pm\Theta(h,\xi)\overline{\mathcal C}(h,\xi),\qquad
\Theta(h,0)=\frac{c_+(h)}{a_C(h)}. \tag{P8}
\]

This is an exact **branch-conditioned relationship between two different backgrounds** if proved. It is not an explicit all-orders formula for Theta. Merely defining a ratio where it is nonzero does not prove its analytic extension or positivity. A constant proportion is not proposed: the leading ratio already varies with h.

Do not promote this to an all-state, all-coefficient or all-ring theorem. Additional GR1 cancellation loci outside the local neighborhood remain possible, and D1 does not classify every drifting branch.

## 5. Generator limit without conflating rates

Equation (P4) at h=0 gives

\[
\overline{\mathcal C}(0,\xi)
=-\frac{(r_0-r_1)(r_0-r_2)(r_1-r_2)}{900r_0r_1r_2}. \tag{P9}
\]

Direct formation of the oriented product from the off-diagonal entries of
\(\mathsf G_r=\mathsf B_r+L_3/10\) should give exactly (P9).

At the symmetric coefficient point the normalized cubic coefficient is
\(a_C(0)=2/28125\), while the inherited drift coefficient is
\(c_+(0)=344\sqrt3/3\). Along \((-\eta,0,\eta)\), both are multiplied by two. The leading ratio at h=0 is \(1612500\sqrt3\); this is a mathematical normalization comparison, not a fitted universal physical constant.

For fixed sufficiently small pairwise-distinct xi, the proposed consequences are

\[
\mathcal C=h^3\overline{\mathcal C}(0,\xi)+O(h^4),\qquad
\nu_\pm=\nu_\pm(0,\xi)+O(h),\qquad
\omega_\pm=h\nu_\pm(0,\xi)+O(h^2).
\]

This is why raw response products and accumulated phase cannot be compared without specifying the step convention. No spacetime interpretation follows. The identity map at h=0 still has zero per-update advance.

## 6. A correspondence is not a branch selector

For fixed h>0 and small pairwise-distinct xi, the in-phase branch r is a native fixed state. The two D1 states have opposite nonzero common-phase advances. The response diagnostic above is evaluated at the **same designated in-phase branch** in all three comparisons.

Thus the same parameter tuple and the same assigned in-phase diagnostic coexist with realized advances 0, +omega and -omega, depending on the initial branch. That excludes choosing the actual signed advance from that diagnostic alone. It does not exclude the branch-conditioned law (P8), invalidate deterministic evolution from a full state, or show failure of a complete state/response observation.

This nonimplication uses inherited fixed-state and conjugation facts; its purpose is to state the explanatory limit of the new quantitative comparison. Do not sell those inherited facts as newly discovered counterexamples.

## 7. What was done in preparation

GPT reopened the source texts, checked later scope boundaries, and ran one small new SymPy algebra script. It checked (P4), the coefficient substitution in (P6), (P9), the fixed factor lower bound and nonconstancy of the leading ratio. It did not run a native trajectory, historical certificate, D1 jet solver, production system or Git write. Its source/output and actual environment are retained under `preparation/`.

The proposed uniform analytic comparison and interpretation remain for Codex to prove or correct. There is no mathematical acceptance or publication authorization in this analytical start.
