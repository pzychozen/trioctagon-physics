"""GPT preparation only: exact algebra, not an independent acceptance review.
No native kernel, historic verifier, trajectory or network call is executed.
"""
from pathlib import Path
import json, platform
import sympy as s
h, a, b, c, eta = s.symbols('h a b c eta', real=True)
r=[a,b,c]
L=s.ones(3)-3*s.eye(3)
B=s.Matrix(3,3,lambda i,j:r[j]/(6*r[i]) if i!=j else -sum(r[k]/r[i] for k in range(3) if k!=i)/6)
J=(s.eye(3)+h*L/10)*(s.eye(3)+h*B)
C=J[0,1]*J[1,2]*J[2,0]-J[0,2]*J[2,1]*J[1,0]
s1=a+b+c;s2=a*b+a*c+b*c;s3=a*b*c
V=(a-b)*(a-c)*(b-c)
Kh=(h*h*s1**3/s.Integer(360)+(h/s.Integer(90)-h*h/s.Integer(180))*s1*s2+(h/s.Integer(20)-s.Rational(1,15))*s3)
Cbar=(1-3*h/10)*V*Kh/(60*s3*s3)
assert s.factor(C-h**3*Cbar)==0
# Only the inherited first derivative of r is needed for a cubic coefficient.
# This tangent line is NOT treated as an exact finite-eta stationary branch.
Aline=2*eta**3
coefficient=s.factor(s.limit(Cbar.subs({a:1-2*eta/5,b:1,c:1+2*eta/5})/Aline,eta,0))
expected=(1-3*h/10)*(8-18*h-3*h*h)/s.Integer(112500)
assert s.factor(coefficient-expected)==0
cDrift=s.sqrt(3)*(33*h*h-240*h+688)/(6*(1-3*h)**3)
ratio=s.factor(cDrift/expected)
Cgen=B+L/10
Gcycle=Cgen[0,1]*Cgen[1,2]*Cgen[2,0]-Cgen[0,2]*Cgen[2,1]*Cgen[1,0]
assert s.factor(Cbar.subs(h,0)+V/(900*s3))==0
assert s.factor(Gcycle-Cbar.subs(h,0))==0
positive_response_lower=s.Rational(37,40)*s.Rational(53,16)/112500
assert positive_response_lower>0
# Nonconstant leading ratio; evaluated exactly without an eta fixture.
assert s.simplify(ratio.subs(h,s.Rational(1,10))-ratio.subs(h,0)) != 0
records={
 'status':'GPT_PREPARATION_IDENTITIES_CHECKED_NOT_CODEX_ACCEPTANCE',
 'python':platform.python_version(),'sympy':s.__version__,
 'exact_response_factor_identity':True,
 'response_cubic_coefficient':str(coefficient),
 'drift_cubic_coefficient_inherited_not_rederived':str(cDrift),
 'leading_rate_to_normalized_response_ratio':str(ratio),
 'response_coefficient_at_h0':str(expected.subs(h,0)),
 'leading_ratio_at_h0':str(ratio.subs(h,0)),
 'leading_ratio_at_h_1_10':str(ratio.subs(h,s.Rational(1,10))),
 'response_positive_lower_from_factor_bounds':str(positive_response_lower),
 'normalized_generator_cycle_identity':True,
 'scope':'Rational identities and leading-coefficient substitution only. No branch existence, uniform neighborhood, complete zero/sign theorem, or independent review is certified by this script.',
 'scientific_predecessor_executions':0,'trajectories':0,'repository_writes':0
}
Path(__file__).with_name('PREPARATION_ALGEBRA.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
