"""Verify this packet's byte manifest only. No scientific code is executed."""
from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
expected={entry['path']:entry for entry in manifest['files']}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='PACKET_MANIFEST.json' and '__pycache__' not in p.parts}
errors=[]
if actual!=set(expected):
    errors.append({'missing':sorted(set(expected)-actual),'extra':sorted(actual-set(expected))})
for name,entry in expected.items():
    p=root/name
    if not p.is_file(): continue
    data=p.read_bytes()
    if len(data)!=entry['bytes'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:
        errors.append({'mismatch':name})
print(json.dumps({'status':'FAIL' if errors else 'PASS','manifest_entries':len(expected),'errors':errors,'scope':'Packet byte identities only, not proof verification'},indent=2))
sys.exit(bool(errors))
