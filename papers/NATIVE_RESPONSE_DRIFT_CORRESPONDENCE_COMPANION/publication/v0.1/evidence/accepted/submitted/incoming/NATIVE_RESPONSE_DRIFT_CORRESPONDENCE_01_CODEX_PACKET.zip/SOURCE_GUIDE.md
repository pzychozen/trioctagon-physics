# Source guide — exact roles and locators

## Controlling mathematical sources

| Packet source | Reopen these passages | Role |
|---|---|---|
| `sources/NRG/response.tex` | `thm:branch`, `eq:fixed`, `eq:screen`; `eq:P`, `eq:SP`; `thm:cycle`, `eq:cycle`, **corrected** `eq:K`, `eq:cycleweak` | Native positive branch and response formulas. `eq:K` in this published source controls over any earlier report transcription. |
| `sources/drift.tex` | D1–D7; D12–D18; D20–D30; D36–D40; interpretation before Appendix A | Existing D1 family, regular domain, h=0 extension, uniform qualitative coefficient neighborhood, orientation and analytic divisibility, inherited nonzero coefficient. |
| `sources/D0.md` | Sections 3–8 | Historical reconciliation and symmetry derivation. Consume with D1's later nonzero-coefficient result. |
| `sources/D1_CLOSEOUT.md` | Accepted result, generator identity and qualifications | Accepted source scope; no historical numerical replay authorized. |
| `sources/dynamics.py` | `arg0`, `phase_sync`, `_advance`, `step3` | Read-only check of native conventions and stage order, not exact-arithmetic proof from binary64 code. |

The main response, drift and native-code bytes were matched to freshly reopened repository blobs at checkpoint `ae2c02c80c49dfcf266d3b27ebd21be76a938de1`. `SOURCE_IDENTITIES.json` binds the bytes, ancestor archive/member and actual verification scope. This checkpoint is a locator, not an instruction to reset any checkout or a claim about subsequent remote HEAD.

## Relevant completed work for the nonduplication gate

- `sources/NRG/spectral.tex`, `sources/NRG/discussion.tex`, `sources/NRG_LEDGER.md`: diagonal balance versus arbitrary SPD self-adjointness, quotient and ring differences. Do not infer a rotating trajectory from complex linear modes.
- `sources/potential/local.tex`, `sources/potential/discussion.tex`: qualified native-potential descent already completed.
- `sources/phase/reconstruction.tex`, `overlap.tex`, `observations.tex`, `setting.tex`: admitted-domain full-state/common-phase reconstruction already completed. Do not enlarge that coherent-sector theorem to D1's twisted branch without a separate argument.
- `sources/returns/main.tex`, `sources/NCM/NCM_DUAL_02_REPORT.md`: return-phase and recurrent-state distinctions; not an instruction to rerun searches.
- `sources/strength_pattern.tex`, `sources/LOCAL_RESEARCH_INDEX.md`: earlier information/response context and historical navigation. Retained pending/open statuses are not automatically current.

These are unchanged source snapshots recovered from the already supplied `NATIVE_TURNING_CAPTURE_01_REVIEW.zip`. The source subset is deliberately not a complete compilable paper bundle: source documents may contain historical relative bibliography/figure links. Do not compile them or treat missing presentation assets as missing mathematical premises.

## Additional local navigation to inspect, not supplied as original bytes

The retrieved Project/Library text of the following documents was read when commissioning this task; the packet does not claim to contain their original raw files:

- `C:/TORMENT/TRIOCTAGON_new/research/GRAVITY_NATIVE_RECOVERY_01/GRAVITY_OPEN_QUESTIONS.md`, 22 October 2026: “Unresolved mathematical relationships”, item 3.
- The sibling `GRAVITY_NEXT_INVESTIGATION.md` and `GRAVITY_ESTABLISHED_RESULTS.md`: navigation and the resolved-predecessor distinction. The old ranked energy/information/reconstruction questions are superseded at their completed scopes.
- Project research status dated 10 November 2026: later direction list. Its W/T publication-pending status is superseded by the subsequent confirmed publication, not carried forward as unfinished.

Search the current local corpus for later equivalent results. Paths for the recent closeouts are in the current conversation and repository catalog. Their full archives are unnecessary for the present algebra; do not perform another publication audit.

## Source roles versus new work

`GPT_ANALYTICAL_START.md` and `preparation/` are newly proposed reasoning, not inherited authority. They must be challenged. The old main formulas and coefficient theorem are inherited premises; this order does not reopen their proofs unless a concrete contradiction is found and documented.
