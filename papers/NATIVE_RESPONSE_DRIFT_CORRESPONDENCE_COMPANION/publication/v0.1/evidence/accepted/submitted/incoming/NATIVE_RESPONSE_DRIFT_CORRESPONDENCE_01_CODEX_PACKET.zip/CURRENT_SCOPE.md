# Current scope and retained agenda

14 November 2026. This is a commissioning note, not a new scientific result or a complete historical bibliography.

## Closed checkpoints — do not reopen

- SRG reconstruction studies, Volumes I–III and Final Mathematical Bridge: completed at their stated scopes.
- Native response, turning/relaxation, potential/descent, minimum coherence information, full-state/phase reconstruction and support axes: completed at stated scopes.
- Exchange/capacity, F cadence, central-route/six-opening, and W/T causal transport/storage: completed and published within candidate-model scope. Physical attachment remains separate.
- Original turning seed: certified entry at update 50 and inherited convergence; companion published at `035a32099605bac84bc739a94d001ab96c7c5f55`.
- M2–M3 alternating branch connection: complete for 0<mu<=1/200; companion published at `46bf10808b8694476b61b359be305a66a46d4614`. Full-range attraction remains unresolved, not an automatic next assignment.
- A–B outer-envelope classification: complete, reviewed and published at `ae2c02c80c49dfcf266d3b27ebd21be76a938de1`. Publication accepted on the author-supplied closeout; no fresh publication audit is commissioned.

## This commission

Native response-cycle asymmetry versus existing chiral common-phase drift at identical coefficients. It is a bounded comparison of two established constructions under the unchanged native map, with five proposed review claims. All new results are unaccepted until independently reviewed.

## Remaining directions retained, not silently launched

Gravity–magnetism correspondence; justified SRG-to-native integration; other specifically motivated outer/central geometric connections; physical route/load/clock and units; post-F receiving/recovery and other recorded candidate limitations. There is no new strict ordering among these wider directions.

Three-Way remains parked. TORMENT/memory redesign, epistemic dynamics and games remain parallel; existing TORMENT functionality is not being reopened or tested by this physics order. Physical applications and working software are not inferred from the formal comparison.

A future task needs its own specific gap, not another automatic refinement of the most recently published result. The author is not needed for routine coefficient recovery; involve them before a genuinely new geometric or physical choice.
