# Preparation evidence — not independent acceptance

`gpt_preparation_algebra.py` was newly written and run while preparing this commission. It reads no repository, uses no old scientific verifier and computes no trajectory. Its exact SymPy checks concern the response-matrix product/factorization, leading coefficient, generator cycle, and elementary rational comparisons.

`PREPARATION_ALGEBRA.json` records actual versions and outcomes. It does not prove a uniform branch neighborhood, full analytic zero-set correspondence, or the interpretation claim. Those require the written source-based argument and Codex review. Re-running this helper alone does not complete the assignment.
