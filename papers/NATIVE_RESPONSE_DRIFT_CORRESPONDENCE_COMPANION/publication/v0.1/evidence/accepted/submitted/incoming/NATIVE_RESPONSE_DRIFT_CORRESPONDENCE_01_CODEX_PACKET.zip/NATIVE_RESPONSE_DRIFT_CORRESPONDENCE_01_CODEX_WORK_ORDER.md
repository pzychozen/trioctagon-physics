# Codex investigation order — Native response asymmetry versus common-phase drift

**ID:** `NATIVE_RESPONSE_DRIFT_CORRESPONDENCE_01`  
**Date:** 14 November 2026  
**Author / operator:** Hilmir Frímann Halldórsson (pzychozen)  
**Scientific lead:** GPT  
**Assignment:** Independent analytical investigation and proof review; return to GPT and author.

## 1. Authorization and purpose

The author authorized GPT to select and prepare the next useful investigation without another general planning discussion. “Earn its place” means identify a precise unanswered question against the existing corpus before calculating. It does not mean continue the finished outer-envelope assignment indefinitely.

The completed outer-envelope companion is published at checkpoint `ae2c02c80c49dfcf266d3b27ebd21be76a938de1`. Its closeout is not a target for re-audit. Native turning capture, M2–M3 branch connection, the W/T transport paper, potential/descent, closed coherence and phase reconstruction are also completed at their documented scopes. Do not recommission them.

**Selected question:** On the existing D0/D1 parameter family, compare the GR1 cycle-product obstruction at its positive in-phase branch with the D1 common-phase rates on its two chiral branches. Determine their common parameter domain, exact local factorization, leading coefficients, zero/sign relationships and small-step limits, and explain what is and is not determined without specifying the native state/branch.

This is a quantitative correspondence between existing native objects. It supplies no new force, metric, state, feedback, spatial path, receiver or clock. It is part of the standing native-response / gravity–magnetism research direction, not an assertion that either physical theory has been derived.

## 2. Stage zero — bounded nonduplication check

Read `PRIOR_WORK_COMPARISON.md` and the exact source passages. Check the current local research index and relevant later sources for an existing **matched-family comparison** of GR1's cycle product and D1's phase rate, including the normalization by the mathematical step parameter.

The October gravity-recovery list is a navigation source, not current authority for every open status. Its potential/control and minimum-information items were subsequently answered; phase reconstruction is also complete. The selected item is the separately named “Response circulation versus trajectory drift” question. Do not reopen the completed items merely because that old list calls them open.

Inspect, at minimum: Native Response Geometry (`eq:cycle`, `eq:K`, `eq:cycleweak` and its spectral qualifications); D0/D1 and their final correction/closeout; Native Potential and Closed Coherence; Phase Reconstruction and Stationary Support Axes; collective turning/coherence returns; the recent alternating-branch companion. Search for equivalent formulations and changed notation, not only the task title. The accompanying source subset is a starting corpus, not proof of worldwide novelty.

Record exact paths, sections/labels and the logical difference. Use one disposition:

- `DISTINCT_GAP`: proceed with the five checks below.
- `ALREADY_ESTABLISHED`: return the existing theorem/crosswalk and stop. Do not manufacture a broader problem or call a rederivation new research.
- `PARTIALLY_ESTABLISHED`: retain inherited parts and investigate only the uncovered implication within this order.
- `SOURCE_BLOCKED`: identify the exact inaccessible premise and return the supported partial assessment; routine local source recovery is permitted.

No new modelling choice may be inserted to get a positive outcome.

## 3. Frozen mathematical object

Use the **three-channel native map only**, with its simultaneous prestage and simultaneous harmonic-three phase synchronization, in that order. Keep `Arg0(0)=0` and the lambda-zero implementation convention unchanged. All phase derivatives and equivariance arguments must stay on their regular nonzero-prestage domains.

Write `h_step` in prose/code to distinguish the mathematical D1 parameter (written h in its source) from the completed outer-geometry half-edge. In formulas below use h for that step parameter:

\[
0<h\leq1/4,\qquad (\epsilon,g,\lambda)=h(1,1/6,1/30),\qquad
k_i=1+\xi_i,\quad \sum_i\xi_i=0.
\]

Weak heterogeneity means an explicitly stated sufficiently small neighborhood of \(\xi=0\). No numerical radius is commissioned. Include h=0 only through the justified analytic/generator extensions; \(F_0=\mathrm{id}\) does not select a unique stationary state or a discrete drift rate.

Compare three branches of this **same ordered parameter tuple**:

1. The positive in-phase branch \(r(\xi)\) selected near \((1,1,1)\), satisfying the fixed equations after division by h.
2. The D1 gauge-fixed chiral branch from \(z^*_{+,j}=2^{-1/2}e^{2\pi i j/3}\).
3. Its conjugate branch from \(z^*_- =\overline{z^*_+}\).

The in-phase branch and chiral branches are different backgrounds, not parts of a proved common trajectory. Neither D1 branch is to be relabelled as an attracting orbit. Do not substitute the unrelated Paper G M2/M3 coefficients or the turning-capture witness.

Let \(J_h\) be the complete **in-phase phase-response matrix** in the inherited phase coordinates. Freeze the orientation

\[
\mathcal C=J_{01}J_{12}J_{20}-J_{02}J_{21}J_{10},\qquad
\mathcal A(\xi)=(\xi_0-\xi_1)(\xi_1-\xi_2)(\xi_2-\xi_0).
\]

Here \(\mathcal A(-\eta,0,\eta)=2\eta^3\), while the GR1 product over increasing pairs is \(-\mathcal A\). Keep that sign explicit. \(\mathcal C\) is not the area vector C, not the chiral scalar Gamma, and not GR2's Bloch coefficient.

The D1 rates satisfy \(F_h(z_\pm)=e^{ih\nu_\pm}z_\pm\), with small unwrapped per-update advance \(\omega_\pm=h\nu_\pm\). Rate, per-update phase and response cycle product are three different quantities.

## 4. Requested independent checks

### RD01 — Matched family and source/domain concordance

Verify that both inherited constructions actually exist at the common coefficients and on overlapping local heterogeneity domains. Derive the divided in-phase fixed equation, its h-independence, and the first coefficient derivative on the zero-sum plane. Reuse D1's reference, gauge and invertible border; do not rederive its full state jet or rerun its continuation tubes.

Prove any common-neighborhood statement you use, including extension at h=0. Compactness plus a uniform regular implicit-function setting may justify a qualitative common radius; a collection of pointwise radii alone is not an explicit radius. Do not claim uniform attraction or a quantitative basin at h=0.

### RD02 — Exact response factor and coefficient comparison

Independently derive \(J_h=(I+hL_3/10)(I+h\mathsf B_r)\) in the correct order, and verify the proposed analytic normalization \(\overline{\mathcal C}=\mathcal C/h^3\). Check its exact formula and the proposed coefficient

\[
a_C(h)=\frac{(1-3h/10)(8-18h-3h^2)}{112500}.
\]

Use the inherited, not newly claimed, D1 coefficient

\[
c_+(h)=\frac{\sqrt3(33h^2-240h+688)}{6(1-3h)^3}.
\]

Compare them under the same orientation and coefficient perturbation. Verify all factors of two and h. A fitted decimal or substitution of a truncated state as an exact branch is not acceptable.

### RD03 — Actual local zero and sign relationship

Determine whether there is a common qualitative neighborhood of \(\xi=0\), for \(0\le h\le1/4\), on which

\[
\overline{\mathcal C}=\mathcal A(\xi)S_C(h,\xi),\qquad
\nu_\pm=\pm\mathcal A(\xi)S_D(h,\xi)
\]

with symmetric real-analytic positive factors. If this holds, state the resulting complete **local** zero sets and signs, including equal-coefficient planes, and the branch-conditioned positive analytic ratio \(\nu_\pm=\pm\Theta\overline{\mathcal C}\).

Prove analytic divisibility before taking a ratio near a zero of the Vandermonde. One cannot divide a bare \(O(\|\xi\|^5)\) remainder by a cubic factor that can vanish or become arbitrarily small relative to \(\|\xi\|^3\). Distinguish an exact existence statement for \(\Theta(h,\xi)\) from the explicit **leading** formula \(\Theta(h,0)=c_+(h)/a_C(h)\).

If the proposed uniform sign/no-extra-zero result fails, give the precise corrected domain or obstruction. Do not silently shrink the task to the single direction \((-1,0,1)\).

### RD04 — Small-step limit and normalization

Verify the actual limit of \(\overline{\mathcal C}\) and relate it to the cycle product of the first-order in-phase response generator. Keep the generator, additive approximation, and native ordered product distinct.

Explain why \(\mathcal C=O(h^3)\), \(\omega=O(h)\), and a nonzero generator rate are compatible, at a fixed small heterogeneous coefficient tuple. These orders require the proved nonzero factors to claim nonzero leading behavior. They are not time calibration or a continuum physical limit.

Do not compare unnormalized zero values at h=0 to infer the absence of drift. Conversely a nonzero normalized scalar does not make the identity map at h=0 move.

### RD05 — What the correspondence can predict, and what it cannot

Produce an explicit logical table for fixed h>0 and a sufficiently small pairwise-distinct \(\xi\), identifying the stationary branch, the two conjugate chiral branches, the common in-phase response diagnostic, and their respective advances \(0,\omega_+,-\omega_+\).

Use this to state the limited non-determinacy result: the **in-phase branch's response diagnostic and coefficient tuple, without the actual state/branch selection, do not select the realized signed common-phase advance**. Do not claim that identical full current states can evolve differently, that full native reconstruction fails, or that all state-dependent response data are insufficient. The full state remains deterministic.

Branch-conditioned sign/zero correspondence is compatible with this limitation. A ratio between functions evaluated on different backgrounds is not a force law, causal transfer, a trajectory from one branch to the other, or a state-independent universal proportionality. The basic conjugation and stationary-state facts are inherited; the contribution is their placement in the matched quantitative comparison.

## 5. Analytical and computational execution

Prefer a written analytic argument with small exact symbolic checks. The preparation helper is deliberately limited and may be wrong; independently reconstruct the response matrix and factor/sign conventions. Do not treat the helper's saved `True` fields as premises.

Use existing Windows Command Prompt and environment:

```bat
conda activate torment
```

Suggested short external workspace: `C:\TORMENT\NRD01\run_20261114_01`. Choose a fresh suffix if it exists. Canonical physics checkout: `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`. No install, dependency update, production TORMENT access, global configuration change or repository write is authorized.

Allowed: local read/search, source-identity checks, symbolic expansions/factorizations of the new comparison, rational sign arguments and small deterministic algebra controls. No trajectories, broad parameter survey, old certificate replay, full D1 cubic-jet recomputation, new chiral continuation, ring spectral scan, radius optimization or physical-constant fitting.

A finite numerical fixture is not required. If used only as a diagnostic, declare its purpose first, stay within h in `{1/10,1/100}` and the inherited \(\xi=(-\eta,0,\eta)\), \(|\eta|\le1/1000\), and label it unvalidated unless a new rigorous enclosure is actually supplied. Do not adopt a numerical eta radius as a theorem. No more than four such diagnostics; no trajectories.

Keep any individual symbolic worker bounded (for example 300 seconds and a conservative memory ceiling). Preserve inconclusive or failed checks. Report what completed rather than silently extending into a large parameter study.

## 6. Challenge and acceptance requirements

At least these logical controls must be addressed in code or explicit exact arguments:

- Wrong Vandermonde orientation or dropping its factor two along \((-\eta,0,\eta)\) must be detected.
- Reversing the native stage order must not silently pass as the same response formula.
- Confusing raw \(\mathcal C\), \(\mathcal C/h^3\), \(\omega\), and \(\nu\) must be caught.
- Two equal coefficients give the qualified local zero case, not a nonzero sign test.
- Conjugation keeps the ordered coefficients and in-phase diagnostic fixed but reverses the chiral rate.
- A false claim of universal signed prediction from \(\mathcal C\) alone must be rejected using the actual branch distinction.

An algebraic identity count is not a theorem count. Disclose shared implementation components. Independent symbolic organization is useful; do not claim an independent arithmetic backend if it is the same one. Package hashes authenticate bytes, not proofs.

## 7. Deliverables

Return one compact review ZIP with:

- `RESULT_SUMMARY.md`: plain-language answer, novelty disposition, exact scope, what relates and what remains non-identifiable.
- `PROOF_REPORT.md`: complete argument, source labels, matched branch definitions, factorizations, limits, qualifications and any corrections to GPT's proposed start.
- `CLAIM_LEDGER.json`: RD01–RD05 dispositions, hypotheses, evidence paths and inherited/new distinctions.
- `PRIOR_WORK_COMPARISON.md`: completed bounded comparison, including later-source checks and any equivalent existing result.
- Exact-check source and outputs, logical/negative controls, actual environment and commands. No historical verifier output relabelled as new.
- Supplied packet preserved unchanged, compact consumed-source inventory, and before/after read-only repository preservation record. Do not distribute unrelated working files or private logs.
- Self-excluding archive manifest, external `.zip.sha256`, and final member-by-member archive audit.

No PDF or manuscript is required. A concise mathematical note in Markdown is sufficient. No figure is needed unless it explains a real distinction the text cannot; do not spend the assignment on presentation.

## 8. Stop conditions and author involvement

Stop after a supported proof/counterexample/qualified comparison and return for review. A scoped negative or partial outcome is acceptable. Do not force a publication, a physical interpretation or a successor study.

No geometry question is needed to start. Ask the author only if proceeding beyond this scope would require a genuinely new physical/geometric definition or a consequential design choice. Do not ask them to locate old equations, choose routine numerical settings, or re-explain the model.

**No manuscript commission, kernel/UI change, Git commit/push, external publication or TORMENT redesign is authorized by this order.**
