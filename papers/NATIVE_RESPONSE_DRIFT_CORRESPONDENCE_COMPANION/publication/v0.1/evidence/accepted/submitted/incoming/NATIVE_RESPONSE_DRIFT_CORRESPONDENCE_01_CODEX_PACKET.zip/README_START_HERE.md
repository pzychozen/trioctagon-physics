# Start here — Native response asymmetry versus common-phase drift

**Task:** `NATIVE_RESPONSE_DRIFT_CORRESPONDENCE_01`  
**Commissioned:** 14 November 2026  
**Author:** Hilmir Frímann Halldórsson (pzychozen)  
**GPT:** scientific direction and proposed analytical start.  
**Codex:** independent source comparison, proof challenge and verification.

## The question

On the already-studied native parameter family, what can the directional imbalance of the **in-phase response matrix** tell us about the **common-phase advance of the distinct chiral branches**? Compare them at identical ordered coefficients; do not treat different backgrounds as one state.

The outer-envelope A–B study is finished and published. This task returns to a precise previously recorded native-response/drift question. It is neither another shell classification nor a new gravity, magnetic-field or memory model.

## Read in order

1. `NATIVE_RESPONSE_DRIFT_CORRESPONDENCE_01_CODEX_WORK_ORDER.md` — controlling scope and stop conditions.
2. `PRIOR_WORK_COMPARISON.md` — what is already finished and the exact candidate gap.
3. `EXACT_CASE.json` and `GPT_ANALYTICAL_START.md` — frozen native family and five proposed checks.
4. `SOURCE_GUIDE.md`, the selected unchanged source texts, and `SOURCE_IDENTITIES.json`.
5. `CLAIM_LEDGER.json` — all new claims are proposed, not already accepted.

The supplied mathematical source texts suffice for the initial analytical assessment. Complete the bounded later-source check locally before treating the comparison as new. Recovering routine locators and coefficients is Codex's job, not the author's homework.

The preparation helper checks only a few exact rational identities. It is not the review, a branch theorem, or a target that Codex must accept. No old scientific verifier is authorized for replay.

**Return a proof/review package only. No manuscript, codebase change, commit, push, release or automatic successor task.**
