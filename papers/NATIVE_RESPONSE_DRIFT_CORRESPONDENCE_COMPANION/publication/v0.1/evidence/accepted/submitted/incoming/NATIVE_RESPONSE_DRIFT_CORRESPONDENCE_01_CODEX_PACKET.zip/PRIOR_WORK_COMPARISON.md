# Prior-work comparison — response asymmetry and native phase drift

**Prepared 14 November 2026. Preliminary bounded disposition: a precise comparison appears unclosed in the inspected sources; Codex must complete the later/local-source gate before new calculation.**

## The precise difference

The new target is not “does the model have response circulation?” or “does it drift?” Both were answered. It is a **matched-parameter theorem comparing the existing in-phase cycle-product obstruction with the existing chiral phase rates**, including exact local zero/sign behavior, distinct step scaling and the need to specify a branch.

The 22 October `GRAVITY_OPEN_QUESTIONS.md`, “Unresolved mathematical relationships,” item 3 explicitly records that the GR1/GR2 obstruction and D1 rate share alternating cubic factors but concern different backgrounds and outputs, with coefficients, zero loci, signs and magnitudes not identified. That is a navigation lead, not proof that no later source settled it.

## Inspected predecessors and exclusions

| Existing work | Result to reuse | Why the commissioned comparison is different |
|---|---|---|
| Native Response Geometry, `response.tex`: `thm:branch`, `eq:screen`, `eq:P`, `eq:SP`, `eq:cycle`, corrected `eq:K`, `eq:cycleweak` | Positive in-phase branch, complete ordered response, exact diagonal-cycle factorization, cubic coefficient on weak branches. | Does not evaluate D1's chiral drift at the same native coefficients or identify their local quotient/sign relationship. |
| Native Response Geometry, `spectral.tex` and theorem ledger | Triad dense SPD metrics and distinct larger-ring spectral obstructions. | A diagonal-balance obstruction is not an eigenvalue phase or an actual common-phase trajectory. No new spectral classification is commissioned. |
| Cubic Common-Phase Drift, D1–D4, D20, D23–D30, D36–D40 | Existing chiral branches, nonzero rate coefficient, analytic divisibility, gauge, generator limit and necessary drift balances. | Its discussion of in-phase response explicitly keeps backgrounds separate; it does not supply the matched quantitative comparison proposed here. Its finite roots and jet are inputs, not rerun targets. |
| D0 and D1 closeout | Orientation, conjugation/reflection distinctions; corrected generator/additive/native comparison. | Reuse these conventions; do not call cubic drift or its generator persistence new. |
| Native Potential and Closed Coherence | Qualified full-update potential descent; minimum raw coherence-coordinate counts. | Closes the old recovery's first two targets, not the present cross-background rate comparison. |
| Phase Reconstruction and Stationary Support Axes | Exact full-state reconstruction and common-phase accumulation on its admitted coherent domain; passive decoder. | Not a theorem that the in-phase response cycle product selects a chiral branch. Its narrow aligned domain must not silently be extended to D1's twisted states. |
| Collective turning, coherence returns and NCM-DUAL-02 | Existing transient turn, coherent convergence, return-phase conditions and local cancellation consequences. | Different observables/domains. This assignment does not search for a new rotating orbit or redo update-50 capture. |
| M2–M3 alternating-branch companion | Connected full-state two-cycles for another fixed coefficient family; full-range attraction still unresolved. | Different coefficients, an H-exchanged period-two branch, and zero full return phase. It is not D1's common-phase relative equilibrium family. |
| W/T and earlier exchange/receiving work | Conditional exchange/storage and observation mechanisms. | Added carrier/receiver states are absent from this native-only comparison; do not continue that extension sequence. |
| A–B outer-envelope companion | Complete static hull transition and face lattice, now published. | Completed. No more shell parameters, new hulls or material-boundary choices are part of this task. |

## Search/accounting performed for this commission

GPT consulted the Project/Library research list, gravity-recovery established/open/next-question documents, D0/D1 sources and closeout, native-response manuscript, later potential and reconstruction scopes, plus the retained native/returns/turning materials. Targeted searches used response/circulation/drift, coefficient comparison and their exact source labels. A GitHub code-search query returned no hits even though relevant files exist; that empty result is **not** evidence of exhaustive absence.

The controlling response and drift source blobs were reopened at `ae2c02c80c49dfcf266d3b27ebd21be76a938de1`. Their byte identities match the unchanged copies supplied here. The native implementation blob was also matched. The source inventory records which ancillary copies were read from retained evidence rather than freshly fetched at that checkpoint.

No worldwide novelty search was attempted. No PDF, source or scientific theorem was recertified simply to decide the task. No old “pending publication” or “open” sentence is treated as current when superseded by this conversation's accepted/publication record.

## Codex's required final gate

Reopen equivalent passages in relevant later/local documents, including newer ones not in the compact source subset. Record exact locator and coverage for any apparent match. If this matched-family comparison is already proved, return its precise source and stop. If a part is already proved, narrow the claim ledger to the actual missing implication; do not rebrand the existing result.
