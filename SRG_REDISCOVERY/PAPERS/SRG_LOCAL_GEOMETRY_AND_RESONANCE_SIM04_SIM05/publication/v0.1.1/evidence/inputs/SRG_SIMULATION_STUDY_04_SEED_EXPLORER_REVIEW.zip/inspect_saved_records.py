"""SIM04: static source reading and saved-record evaluation only.

Each transition evaluation starts afresh from the recorded incoming X and R.
Calculated endpoints/residuals are NEVER used as inputs for another transition.
No original import, original method execution, RNG use, simulation or fitting.
"""
from pathlib import Path
import csv,json,ast,sys,platform,hashlib
import numpy as np
import scipy
from scipy.spatial.distance import pdist,squareform
from scipy.sparse.csgraph import connected_components

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'analysis';OUT.mkdir(exist_ok=True)
def dump(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def csvout(name,rows):
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def read(name):
    with (ROOT/'originals'/name).open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f);rows=list(reader);return reader.fieldnames,rows
cols,raw=read('deep_trajectory.csv');mcols,mraw=read('pass_metrics.csv')
assert cols==['Pass','Glyph_ID','X','Y','Z','Resonance','VX','VY','VZ']
data=np.array([[float(r[c]) for c in cols] for r in raw]);assert data.shape==(1050,9) and np.isfinite(data).all()
keys=[(int(r['Pass']),int(r['Glyph_ID'])) for r in raw]
expected=[(p,i) for p in range(21) for i in range(50)]
assert keys==expected and len(set(keys))==1050
assert [int(r['pass']) for r in mraw]==list(range(1,21)) and len(mraw)==20
assert np.isfinite(np.array([[float(r[c]) for c in mcols] for r in mraw])).all()
states=data.reshape(21,50,9);X=states[:,:,2:5];R=states[:,:,5];V=states[:,:,6:9]
assert np.all(V[0]==0)
def H(t):return 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
def graph(x):
    d=squareform(pdist(x));order=np.argsort(d,axis=1);a=np.zeros((50,50))
    for i in range(50):a[i,order[i,1:6]]=1
    return d,a,order
def echo(x,r,d):
    similarity=1-np.abs(r[:,None]-r[None,:])/(max(r)+1e-8)
    strength=similarity*np.exp(-d/3)
    return [(i,j,float(strength[i,j])) for i in range(50) for j in range(i+1,50) if strength[i,j]>.85],strength
def geometry(x,r):
    active=np.where(np.abs(r)>=np.percentile(np.abs(r),75))[0]
    rel=x[active]-np.mean(x[active],axis=0)
    angles=np.array([np.arccos(np.clip(np.dot(rel[i],rel[j])/(np.linalg.norm(rel[i])*np.linalg.norm(rel[j])+1e-10),-1,1))*180/np.pi for i in range(len(rel)) for j in range(i+1,len(rel))])
    n=len(active)
    typ='sub-critical' if n<4 else ('tetrahedral' if np.mean(abs(angles-109.47))<30 else 'amorphous') if n<=5 else ('octahedral' if min(np.mean(np.minimum(abs(angles-90),abs(angles-180))),90)<25 else 'transitional') if n<=7 else 'higher_polyhedra'
    return {'type':typ,'active_ids':active.tolist(),'n_active':n,'mean_angle_degrees':float(angles.mean()),'angle_std_degrees':float(angles.std())}

summary=[];edges=[];corridor_rows=[];graphs=[];strengths=[];metric_errors=[];state_geometry=[]
for p in range(21):
    x,r,v=X[p],R[p],V[p];d,a,order=graph(x);graphs.append((d,a,order))
    corridors,strength=echo(x,r,d);strengths.append(strength)
    center=np.mean(x,axis=0);top=int(np.argmax(np.abs(r)))
    metric={'pass':p,'R_mean':float(np.mean(np.abs(r))),'R_max':float(np.max(np.abs(r))),'R_std':float(np.std(r)),'Rg':float(np.sqrt(np.mean(np.sum((x-center)**2,axis=1)))),'kinetic_energy':float(np.mean(np.sum(v**2,axis=1))),'n_corridors':len(corridors),'coherence':1. if np.std(r)<1e-12 else float(1-np.std(r)/(np.mean(np.abs(r))+1e-8)),'top_seed_id':top,'top_seed_R':float(r[top]),'top_seed_x':float(x[top,0]),'top_seed_y':float(x[top,1]),'top_seed_z':float(x[top,2])}
    if p:
        stored=mraw[p-1]
        for key in mcols[1:]:metric_errors.append({'pass':p,'metric':key,'stored':float(stored[key]),'recomputed':float(metric[key]),'absolute_error':abs(float(stored[key])-float(metric[key]))})
    old=graphs[p-1][1] if p else a
    churn=int(np.count_nonzero((a>0)&(old==0)))
    geom=geometry(x,r);state_geometry.append({'pass':p,**geom})
    summary.append({**metric,'R_min':float(r.min()),'centroid_x':float(center[0]),'centroid_y':float(center[1]),'centroid_z':float(center[2]),'minimum_pair_distance':float(pdist(x).min()),'maximum_pair_distance':float(pdist(x).max()),'new_directed_edges':churn,'glyphs_changing_neighbors':int(np.count_nonzero(np.any(a!=old,axis=1))),'weak_components':int(connected_components(a,directed=True,connection='weak')[0]),'strong_components':int(connected_components(a,directed=True,connection='strong')[0]),'neighbor_cutoff_min_gap':float(np.min(np.take_along_axis(d,order[:,6:7],axis=1)-np.take_along_axis(d,order[:,5:6],axis=1))),'geometry_label':geom['type'],'n_active':geom['n_active']})
    for i,j in zip(*np.where(a>0)):edges.append({'pass':p,'glyph':int(i),'neighbor':int(j),'distance':float(d[i,j])})
    for i,j,e in corridors:corridor_rows.append({'pass':p,'glyph_i':i,'glyph_j':j,'distance':float(d[i,j]),'resonance_difference':float(abs(r[i]-r[j])),'echo_strength':e})

transitions=[];residuals=[];checks=[]
for p in range(1,21):
    x,r=X[p-1],R[p-1];d,a,_=graphs[p-1]
    lap=np.zeros_like(x);q=r.copy()
    for i in range(50):
        neighbors=np.where(a[i]>0)[0]
        lap[i]=np.sum(x[neighbors]-x[i],axis=0)/len(neighbors)
        weights=1/(d[i,neighbors]+1e-8);weights/=weights.sum()
        q[i]+=.15*(np.sum(weights*r[neighbors])-r[i])
    diffusion=.05*lap+.15*np.tanh(lap)
    y=x+diffusion
    hmax=float(np.max(np.abs(H(np.linspace(0,p*.05*200,20000)))))+1e-12
    memory=1+.05*float(H(float(p)))/hmax;q*=memory
    center=np.average(y,axis=0,weights=np.abs(q)+1e-8)
    fusion=(center-y)*.03*q[:,None]
    sinus=1-.001*np.sin(p*.244*2*np.pi)
    pre=q*sinus;logs=np.log(np.abs(pre)+1e-9)
    predicted_r=np.sign(pre)*np.exp(np.clip(logs,-9.,9.))
    # This is only a deterministic-expression residual at recorded inputs.
    unexplained=X[p]-(y+fusion)
    v_error=V[p]-(X[p]-X[p-1]);r_error=R[p]-predicted_r
    for i in range(50):
        residuals.append({'pass':p,'glyph':i,'residual_x':float(unexplained[i,0]),'residual_y':float(unexplained[i,1]),'residual_z':float(unexplained[i,2]),'resonance_error':float(r_error[i]),'velocity_error_max':float(np.max(abs(v_error[i]))),'diffusion_norm':float(np.linalg.norm(diffusion[i])),'fusion_norm':float(np.linalg.norm(fusion[i]))})
    transitions.append({'pass':p,'H':float(H(float(p))),'Hmax_sampled':hmax,'memory_factor':memory,'sinusoidal_factor':float(sinus),'RPCO_lower_clip_count':int(np.sum(logs<-9)),'RPCO_upper_clip_count':int(np.sum(logs>9)),'pre_RPCO_min':float(pre.min()),'pre_RPCO_max':float(pre.max()),'velocity_max_abs_error':float(np.max(abs(v_error))),'resonance_max_abs_error':float(np.max(abs(r_error))),'diffusion_rms_norm':float(np.sqrt(np.mean(np.sum(diffusion**2,axis=1)))),'fusion_rms_norm':float(np.sqrt(np.mean(np.sum(fusion**2,axis=1)))),'position_residual_rms_norm':float(np.sqrt(np.mean(np.sum(unexplained**2,axis=1)))),'position_residual_max_abs':float(np.max(abs(unexplained))),'position_residual_mean':float(unexplained.mean()),'position_residual_std':float(unexplained.std()),'mean_resonance_after_neighbor_exchange_before_memory':float(np.mean(q/memory))})

tol=1e-12
for key in mcols[1:]:
    subset=[r for r in metric_errors if r['metric']==key];err=max(r['absolute_error'] for r in subset)
    allowed=0 if key in ['n_corridors','top_seed_id'] else tol
    checks.append({'check':'post-state metric '+key,'samples':20,'max_absolute_discrepancy':err,'absolute_tolerance':allowed,'pass':err<=allowed})
for key in ['velocity_max_abs_error','resonance_max_abs_error']:
    err=max(r[key] for r in transitions);checks.append({'check':key,'samples':3000 if key.startswith('velocity') else 1000,'max_absolute_discrepancy':err,'absolute_tolerance':tol,'pass':err<=tol})
assert all(c['pass'] for c in checks)
rr=np.array([[r[k] for k in ['residual_x','residual_y','residual_z']] for r in residuals])
triad=np.argsort(-np.abs(R[-1]))[:3].tolist()
pairs=[(triad[i],triad[j]) for i in range(3) for j in range(i+1,3)]
triad_history=[{'pass':p,**{f'd_{i}_{j}':float(np.linalg.norm(X[p,i]-X[p,j])) for i,j in pairs}} for p in range(21)]
first=corridor_rows[0];i,j=first['glyph_i'],first['glyph_j']
corridor_history=[{'pass':p,'glyph_i':i,'glyph_j':j,'distance':float(graphs[p][0][i,j]),'resonance_i':float(R[p,i]),'resonance_j':float(R[p,j]),'echo_strength':float(strengths[p][i,j])} for p in range(21)]
turns=[]
for p in range(2,21):
    for i in range(50):
        prev=V[p-1,i];cur=V[p,i];norm=np.linalg.norm(prev)*np.linalg.norm(cur)
        turns.append({'pass':p,'glyph':i,'angle_degrees':float(np.degrees(np.arccos(np.clip(np.dot(prev,cur)/norm,-1,1)))),'previous_speed':float(np.linalg.norm(prev)),'speed':float(np.linalg.norm(cur))})
turns.sort(key=lambda a:a['angle_degrees'],reverse=True)
churn=max(summary[1:],key=lambda r:r['new_directed_edges']);p=churn['pass']
churn_glyphs=[]
for i in range(50):
    old=set(np.where(graphs[p-1][1][i]>0)[0].tolist());new=set(np.where(graphs[p][1][i]>0)[0].tolist())
    if old!=new:churn_glyphs.append({'glyph':i,'old_neighbors':sorted(old),'new_neighbors':sorted(new),'removed':sorted(old-new),'added':sorted(new-old),'old_position':X[p-1,i].tolist(),'new_position':X[p,i].tolist()})
source=(ROOT/'originals/srg_seed_explorer.py').read_text(encoding='utf-8');tree=ast.parse(source)
definitions=[{'name':n.name,'first_line':n.lineno,'last_line':n.end_lineno,'kind':type(n).__name__} for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
definitions.sort(key=lambda r:r['first_line'])
dump('source_structure.json',{'lines':len(source.splitlines()),'definitions':definitions,'imports':[ast.unparse(n) for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))],'plotting_or_animation_calls':[{'line':n.lineno,'call':ast.unparse(n.func)} for n in ast.walk(tree) if isinstance(n,ast.Call) and any(s in ast.unparse(n.func).lower() for s in ['savefig','plot','animate','imshow'])]})
dump('checks.json',{'method':'Independent NumPy/SciPy evaluation on stored states; no original import or state propagation','runtime':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform()},'state_rows':len(raw),'metric_rows':len(mraw),'row_order':'Pass 0..20 outer, Glyph_ID 0..49 inner; original order retained','duplicate_keys':len(raw)-len(set(keys)),'missing_keys':0,'nonfinite_values':0,'initial_V_all_zero':True,'metrics_align_to_same_numbered_post_state':True,'checks':checks,'all_checks_pass':True,'neighbor_boundary_min_gap':min(r['neighbor_cutoff_min_gap'] for r in summary),'minimum_pair_distance':min(r['minimum_pair_distance'] for r in summary),'RPCO_total_clipped':sum(r['RPCO_lower_clip_count']+r['RPCO_upper_clip_count'] for r in transitions),'position_residual':{'components':rr.size,'mean':float(rr.mean()),'population_std':float(rr.std()),'rms':float(np.sqrt(np.mean(rr**2))),'max_absolute':float(np.max(abs(rr))),'interpretation':'Unresolved additive residual after source deterministic terms; compatible scale with source sigma=.01 is not recovery of RNG draws, distribution proof or recurrence reproduction.'}})
dump('episodes.json',{'initial':summary[0],'final':summary[-1],'top_seed_sequence':[r['top_seed_id'] for r in summary],'final_top_three':triad,'triad_final_distances':triad_history[-1],'first_corridor':first,'maximum_neighbor_turnover':churn,'turnover_glyphs':churn_glyphs,'largest_turns':turns[:5],'glyph38_pass6_to20_displacement':float(np.linalg.norm(X[20,38]-X[6,38])),'glyph38_pass6_to20_path_length':float(np.linalg.norm(np.diff(X[6:21,38],axis=0),axis=1).sum()),'geometry':state_geometry[-1]})
csvout('state_summary.csv',summary);csvout('transition_checks.csv',transitions);csvout('metric_comparisons.csv',metric_errors);csvout('position_residuals.csv',residuals);csvout('directed_neighbors.csv',edges);csvout('echo_corridors.csv',corridor_rows);csvout('final_triad_history.csv',triad_history);csvout('first_corridor_history.csv',corridor_history);dump('geometry_observer.json',state_geometry)
print((OUT/'checks.json').read_text(encoding='utf-8'))
print((OUT/'episodes.json').read_text(encoding='utf-8'))
