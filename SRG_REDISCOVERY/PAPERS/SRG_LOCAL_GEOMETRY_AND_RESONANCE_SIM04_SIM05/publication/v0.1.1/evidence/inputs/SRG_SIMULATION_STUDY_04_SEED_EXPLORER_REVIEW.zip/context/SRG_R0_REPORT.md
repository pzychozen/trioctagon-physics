# SRG-R0: recovered recurrence, source differences and surviving evidence

10 October 2026. Source recovery by Codex for Hilmir Frímann Halldórsson; mathematical decision remains with GPT. This is a local research result, not publication or implementation approval.

**Complete executable recurrences survive, but there is no single canonical SRG equation shared by the archive.** The July position engine evolves a real `N x 3` array; the older tetrahedral engine evolves wrapped positions, velocities and binary rules; the March engines evolve positions plus real resonance, with distinct dark-field and frequency-band variants. The November six-component complex-linear operator and the URF action/algorithm are different objects.

The July position engine's complete step is

\[
Y_i=X_i+0.05\Delta_i+0.15\tanh\Delta_i,\qquad
Z_i=0.95Y_i+0.05\bar Y+\xi_i,\quad \xi_i\sim N(0,0.02^2I_3),
\]
\[
X_i^+=\operatorname{diag}(1,1,1-0.001\sin(2\pi\,0.244s))Z_i.
\]

Its directed five-neighbor graph is fixed from the initial positions. It has **no resonance state and no zeta coupling**. `GAMMA=0.577`, `LAMBDA_VP=0.618` and the calculated breathing amplitude are unused. The companion CSV generator explicitly makes synthetic test data; its outputs must not be mistaken for this recurrence's trajectory.

The March `GoldenTowerFieldII` has a complete different update: recompute optional breathing bound from incoming resonance; rebuild neighbors; diffuse positions; exchange resonance with inverse-distance and log-frequency weights; apply imposed frequency modulation and explicitly golden-ratio-targeted mixing; apply scheduled `H(t)`; fuse within each assigned band; clip resonance; add position noise; record diagnostics. Section 2 gives every stage and the simpler precursor variants.

The visually verified March paper equation is

\[
\pi e\varphi\,\gamma(\omega)=\zeta\!\left(2\log_\varphi(\omega/\omega_0)+3\right).
\]

**In the tower experiment this is a post-run parameter calculation, not a measured coupling or an update coefficient.** Frequencies are assigned at initialization. In a different March dark-field engine, the literal `0.08699` does enter a cross-coupling term. URF instead puts the target in an action penalty while leaving `GammaEstimate` undefined. These roles cannot be combined into a claim that the tower derives the target.

The principal discrepancies are: signed RPCO versus claimed negative-to-positive inversion; claimed toroidal bounds absent from the March glyph engines; a position-only July engine cited as a resonance engine; a saved `R_max` promoted to a uniform condensate value; and an algebraically recomputed breathing bound described as an independent field. The stored breathing frequency is also the first nonzero FFT bin of the chosen window.

**First next experiment:** the paired, bounded `GoldenTowerFieldII` clipping audit in section 6, retaining every raw state and pre-clipping value. It asks whether changing breathing strength has any causal effect when the clip is inactive, and whether the reported slow frequency survives a change in analysis window. The experiment is prepared but **not run**.

## 1. Recovered models and source/version rationale

Source notation below:

* `O/...` means the unchanged original under `OLD_MATERIAL/`.
* `M/...` means the unchanged local source under `../research_files/archive_members/Zenodo_research/19023429/simulations.zip/`. This is an extracted source directory, not a newly launched archive. Exact full originals are copied into `selected_sources/MARCH_19023429/`.
* `P01`–`P19` identify PDFs in [pdf_inventory.json](pdf_inventory.json). Page citations are physical PDF pages; the selected pages' printed numbers agree with physical numbers.
* Script line numbers refer to original files, with numbered copies in `numbered_sources/`. Full absolute paths, byte sizes and SHA-256 identities are in [source_manifest.json](source_manifest.json) and [external_and_selected_sources.json](external_and_selected_sources.json).

| Version / source | Actual role and carrier | Recovery status |
|---|---|---|
| July patch: `O/recursive_field_evolve.py` | Stochastic position dynamics, real `N x 3`, static graph | Complete standalone update; not a scalar-resonance engine |
| `O/Simulations_Trash/Simulations_part_1/plot_1.py` | Wrapped 3D centers, velocities, binary rule states; scheduled force | Complete callback update; saved transitions directly support it |
| `O/Simulations_Trash/Simulations_part_2/3Dtriangles.py` | Same center/velocity construction without binary rule switching | Complete distinct callback variant |
| `O/Simulations_Trash/Simulations_part_2/recursive_attractor.py` | Three 2D wrapped particles, pairwise forces, velocities | Complete distinct recurrence |
| Early vector-field scripts | Mixture of genuine recurrences and fields sampled at prescribed times | Classified separately in coverage ledger; no zeta coupling |
| July manuscripts P01/P02/P03 | Resonance/echo/phase definitions, proposed pipeline and interpretations | Several operative rules or cited scripts missing; cannot equate with position patch |
| `M/srg_seed_explorer.py`, `GlyphField` | Positions, real resonance, finite-difference velocity, pass count, history | Complete; simplest March resonance engine |
| `M/srg_infinity.py`, `GlyphFieldInfinity` | Adds real dark resonance and imposed cross-coupling | Complete different model; selected saved metrics inspected |
| `M/srg_condensate_breaking.py`, `GlyphFieldUniverse` | Horizon-restricted graph, optional assigned frequencies, prescribed breathing | Complete source; distinct local in-place fusion |
| `M/srg_golden_tower.py`, `GoldenTowerField` | Assigned frequency bands, targeted resonance mixing | Complete; static zeta-map analysis is separate |
| `M/srg_golden_tower_II.py`, `GoldenTowerFieldII` | Adds algebraic breathing, enhanced mixing, lock observer | Complete representative recurrence selected for next experiment |
| `M/srg_breathing_collision.py`, `BreathingField` | Simplified band field, algebraic breathing, merger utility | Complete source variant; not identical to Tower II |
| P15, November fixed SRG | Fixed linear transfer on `C^2 tensor C^3` | Reuse corrected Bridge/QSM; no fresh native experiment |
| P19, URF | Action with lock penalty and schematic field loop | No complete executable estimator/coupled recurrence recovered in this bounded chain |
| `SRG_INTEGRATION_SPEC.md` | Proposed memory subsystem with assigned oscillation and target relaxation | Proposal evidence only; not historical glyph execution authority |

Internal dates, not October copy times: P07 says July 11, 2025; P06 July 13; P03 July 14; P01/P02/P04/P05 July 15; P19 **September 6, 2025**; P15 November 24, 2025; P18 and the March scripts March 14, 2026. Thus “March URF” would be an incorrect date for the located `URF_core.pdf`. Filename numbering does not establish development order. The documented “patch” calls itself a reconstruction, not proof that it generated earlier figures.

The local March PDF SHA-256 is `30dc89e026446eaf5b4d75293fd2b06a5eade83ec91e067a8c76a38fb7a59462`; URF is `60f0fd7188135c73fe2cae9287026384c302bfa120570f855ae1ddaf18f13322`. The corpus manifest identifies the March archive as `731b980fa2f09a8f433c4ff92bd0fcbb455e563790bdf85c556b111b36abd477`; the final provenance receipt checks actual archive/member bytes. This establishes local source identity, not independent verification of deposit history or original run environment.

## 2. State, update order, equations, domains and zero rules

### 2.1 July position-only engine

Source: `O/recursive_field_evolve.py`: constants 7–11; helpers 16–40; `evolve_field` 45–78; example driver 83–93. The displayed equations at the start of this report are its complete recurrence.

Initialization: driver samples 50 positions uniformly from `[-1,1]^3`, without an explicit seed, and requests 60 steps. The function default is 50 steps. For each row `i`, it stores indices `argsort(distance)[1:6]` once, before the loop. At step `s=0,...,steps-1`, `Delta_i` is the average of `X_j-X_i` over that fixed directed neighbor set; an empty set gives zero. All Laplacians use the same incoming array. Fusion uses the mean of **already diffused** positions, then noise is added, then only the Z coordinate is scaled. The list stores post-update arrays, not the initial state. The driver exports only its last array as `X,Y,Z`, without IDs or step numbers.

Stored/auxiliary variables: positions, static adjacency, loop counter, output history and NumPy global RNG state. `amp=breathing_amp(s)` is evaluated but never applied. `LAMBDA_VP` and `GAMMA` are not consumed. `H(t)` is not called. There is no evolving resonance, velocity, phase, glyph identity, echo set or compression-bound variable.

Domain: intended floating real arrays with exactly three columns, finite nonempty N, integer nonnegative step count. There is no validation, wrapping, norm normalization, reseeding, finite-value repair or convergence stop. For N=1 the Laplacian/fusion vanish, but noise remains; the zero position is not an absorbing stochastic state. Coincident positions are nonsingular but `argsort(...)[1:]` assumes the first zero-distance entry is self; ties can admit self and discard another coincident row. Preserve that code behavior. Gaussian noise is unbounded. “Hz” is a source comment; the function uses the integer step directly, so the operational parameter is cycles per step unless a time calibration is separately supplied.

### 2.2 Older tetrahedral recurrence and callback time

Source: `O/Simulations_Trash/Simulations_part_1/plot_1.py`, initialization 9–17, `H` 36–45, damping 47–49, GRF 51–54, energy 57–61, callback 100–149, rule initialization 152–153 and animation 156–167.

The dynamic state is `(x_i,v_i,b_i)`, i=0,...,7, with `x_i in [0,10)^3`, `v_i in R^3`, `b_i in {0,1}`. Initial positions are `10*rand(8,3)`; velocities are `.2*(rand(8,3)-.5)`; b starts at zero; no seed is saved in the script. The regular tetrahedron vertices are fixed display offsets, not separately evolving geometry.

One callback with externally supplied frame `f` computes `t=.1 f` and freezes

\[
g=\frac1{1+\frac18\sum_i\|v_i\|},\qquad
H(t)=2e^{-.5t}\cos t+e^{-.3t}\sin t+1.5e^{-.7t}+e^{-.4t}.
\]

Then **in index order, in place**:

\[
c_i=\tfrac18\sum_jx_j\text{ (using current, partially updated positions)},\quad
d_i=((c_i-x_i+5)\bmod10)-5;
\]
\[
b_i\leftarrow1-b_i\quad\text{if }g>.5\text{ and a fresh uniform draw}<.01;
\]
\[
w_i=v_i+.1gH(t)(1-2b_i)\frac{d_i}{\|d_i\|+.01},\quad
v_i^+=\frac{w_i}{1+\log(1+|w_i|)},\quad x_i^+=(x_i+.1v_i^+)\bmod10.
\]

Damping is componentwise. After all rows, energy is `.5*sum_i ||v_i||^2`; the same total energy and pre-update g are written on all eight rows. No potential energy exists beyond a zero placeholder. Binary switching is the stochastic input; velocities are actual carried state here, unlike the March diagnostic velocities.

`detect_teleport` (64–71) takes the norm of `mod(new-old,10)`, not the minimal wrapped displacement. A tiny negative displacement can therefore be classified as a large jump. It prints events but does not change this recurrence. At coincidence the force is zero because of the `.01` denominator. A fully coincident, zero-velocity configuration is position/velocity stationary even if b flips. Nonfinite inputs have no recovery policy.

The animation has `frames=200`, but saving and displaying can invoke callbacks more than once and restart frame numbering without resetting state. **A saved frame number is not a unique recursion count.** The surviving logs confirm this distinction (section 5). The exact future execution of the GUI is not a seed-reproducible headless run contract.

`3Dtriangles.py` 74–104 omits b and switching, uses the same centroid force and damping, and specifies 2000 frames. `recursive_attractor.py` 38–61 instead uses three 2D positions, `wrap(u)=(u+1)%2-1`, pairwise force `sum_{j!=i} wrap(x_j-x_i)/(norm+.001)`, dt=.05, 500 steps, and the same damping, again in place. Its zero initial velocities are carried forward, not regenerated. Neither contains a spectral lock target.

### 2.3 March basic resonance engine: complete `GlyphField` pass

Source: `M/srg_seed_explorer.py`, helpers 32–47; constructor/history 60–89; graph/coupling 91–124; `evolve_pass` 139–178; observers 185–293.

State is `X in R^(N x 3), R in R^N, V in R^(N x 3), pass_count, history` plus RNG state. The constructor optionally calls `np.random.seed(seed)`, then draws X uniform over the source spatial range and R over `R_init_range`; V=0, pass=0 and an initial history record is saved. Defaults: R in [0,.1], coordinates in [-5,5], k=5, alpha=.05, beta=.15, lambda_H=.05, L=9, theta_lock=.244. `lambda_vp=.618` and `gamma_srg=.0870` are stored but unused by the update.

For the next pass p (incremented first, hence p=1 on the first call):

1. Compute old Euclidean distances `d_ij`, directed k-nearest sets `N_i` using `argsort[1:k+1]`, and `Delta_i=mean_{j in N_i}(X_j-X_i)` (zero if empty). Set `Y=X+.05 Delta+.15 tanh(Delta)` synchronously. [91–109, 141–149]
2. Normalize `w_ij=(d_ij+1e-8)^(-1)` within each old neighbor set. Set `Q_i=R_i+.15(sum_j w_ij R_j-R_i)`; empty-neighbor rows keep R. Old R is used for every row. [111–124, 151–152]
3. Compute `hmax_p=max(abs(H(linspace(0,10*p,20000))))+1e-12`. Set `Q <- (1+.05 H(p)/hmax_p) Q`. This normalization is recomputed per pass and is not a carried feedback memory. [45–47, 155–158]
4. `c=sum_i (|Q_i|+1e-8)Y_i / sum_i(|Q_i|+1e-8)`; `Y_i <- Y_i+.03 Q_i(c-Y_i)`. Negative resonance would reverse the fusion direction. [160–163]
5. `Q <- [1-.001 sin(2 pi .244 p)] Q`. [165–166]
6. `R_i^+=C_L(Q_i)`, with **the exact implemented signed operator**
   \[
   C_L(x)=\operatorname{sgn}(x)\exp\{\operatorname{clip}(\log(|x|+10^{-9}),-L,L)\}.
   \]
   [38–43, 168–169]
7. `X^+=Y+Normal(0,.01)` independently per coordinate; V is new position minus the previous stored position. Append a full state record. [171–178]

No toroidal wrap or spatial clamp is present. No step-length multiplier is inserted. Coherence is `1-std(R)/(mean(abs(R))+1e-8)`, except near-zero std returns one (268–274); it is a diagnostic and can be negative. “Seed” is a top-five absolute-resonance ranking. Geometry labels use thresholds on angle distributions of the top quartile; they do not certify exact polyhedra. Echo corridors are thresholded functions of resonance similarity and distance; not an additional causal update.

### 2.4 March infinity variant: where the coupling actually acts

Source: `M/srg_infinity.py` 43–55, 70–95, 98–137, 162–205. Initialize an additional real D field as `.01*uniform(R_range)`. Here `H_MAX` is sampled once on 50,000 points over [0,100], with `+1e-12`; the bounded check obtains `4.500000000001`.

With the same old neighbor weights and position diffusion as 2.3, replace resonance stage 2 by

\[
Q_i=R_i+.15(\bar R_i-R_i)+.01c_pD_i,\quad
E_i=D_i+.075(\bar D_i-D_i)+.01c_pR_i,
\]
\[
c_p=.08699\sin(.244p+\pi/2).
\]

Cross terms are skipped for rows with no neighbors, because of the early `continue`. Multiply Q by `1+.05H(p)/H_MAX` and E by `1+.05H(p+pi/2)/H_MAX`. Fuse positions using Q exactly as in 2.3; multiply Q only by `1-.001sin(2*pi*.244*p)`; apply C_9 to both Q and E; add position noise of standard deviation `.01/(1+.01p)`; V=Xnew-Xold; record. Thus `.244` appears both as a radian increment in the cross sine and as cycles/pass in the vesica factor. `H(p+pi/2)` is a time shift of a damped multicomponent schedule, not proof of phase orthogonality of an independently evolving complex field.

The coefficient `.08699` is an explicit approximate target input. The code does not estimate it. D and R remain real arrays; names “matter”, “dark” and their squared-sum “energies” are source interpretations/diagnostics. Curvature uses post-update positions on the old adjacency; echo distances use old distances. These stage distinctions matter when comparing observations.

### 2.5 Full golden-tower II update and its variants

Source: `M/srg_golden_tower_II.py` 31–46, constructor 62–109, graph 111–127, update 129–216, observers 218–254. This complete original is bundled. The audited runnable excerpt preserves lines 31–254 verbatim and supplies only the necessary NumPy/SciPy imports; see [audited_excerpt_manifest.json](audited_excerpt_manifest.json).

Carrier: X,R,V,p and RNG as above, **fixed** `band_id`, `natural_freq`, tower arrays and configuration; stored diagnostics `metrics_history`, `band_history`, `L_history`, `lock_times`. There is no evolving phase or natural frequency. Initialization draws X and R first, constructs band indices

\[
I=\{-\lfloor B/2\rfloor,\ldots,\lfloor B/2\rfloor\}[0:B],\quad \omega_b=.244\varphi^{I_b},\quad\varphi=(1+\sqrt5)/2,
\]

then shuffles the modulo-B assignment `band_id[i]=i%B`. This is equal occupancy up to a one-row remainder, not random band creation. V=0, p=0. Defaults are N supplied, B supplied, R range [0,.3], X range [-5,5], alpha=.05, beta=.15, k=5, sigma=3, mixing strength eta=.001, lambda_H=.05, L_base=9, no horizon, breathing off, breathing epsilon=.5.

The following pseudocode preserves every operative stage, including source branch conditions. It is a mathematical transcription, not an alternative implementation:

```text
p += 1; old_X = X.copy()
if breathing:
    L = 9 * (1 + epsilon * mean(abs(R)))        # incoming R, lines 134-138
    append (p,L,incoming_mean_R) to L_history
else:
    retain stored L (constructor value 9)

d = pairwise Euclidean distances of incoming X
if horizon is None:
    N_i = argsort(d_i)[1:k+1]                  # lines 111-127
else:
    candidates = {j != i: d_ij < horizon}
    N_i = first k candidates sorted by distance
Delta_i = mean(X_j-X_i over N_i), or zero
Y = X + .05*Delta + .15*tanh(Delta)             # synchronous, 142-148

Q = R.copy()                                   # all right sides below use old R
for i in index order:                          # 150-188
    if N_i empty: continue
    a_ij = exp(-sigma*log(omega_j/omega_i)^2)/(d_ij+1e-8)
    if sum_j a_ij < 1e-10: continue
    w_ij = a_ij / sum_j a_ij
    Q_i += .15*(sum_j w_ij*R_j - R_i)
    Q_i *= 1 + .01*sin(2*pi*omega_i*p)
    for j in N_i:
        if abs(omega_i-omega_j) > .01:
            for q in [-2,-1,1,2]:
                Q_i += eta*exp(-5*(log(omega_i/omega_j)-log(phi^q))^2)*R_j
            f_sum = omega_i + omega_j
            f_diff = abs(omega_i-omega_j)
            for omega_b in the assigned tower:
                if abs(f_sum-omega_b)/omega_b < .2: Q_i += .5*eta*R_j
                if f_diff > .01 and abs(f_diff-omega_b)/omega_b < .2:
                    Q_i += .5*eta*R_j

Q *= 1 + .05*H(p)/H_MAX                        # 192-194
for each fixed band b:                         # 196-206
    if count(b) < 2: continue
    c_b = weighted mean of Y_i in b, weights abs(Q_i)+1e-8
    for i in b: Y_i += .02*Q_i*(c_b-Y_i)         # c_b computed once per band
R = signed_RPCO(Q,L,eps=1e-9)                   # 208-209
X = Y + Normal(0, .01/(1+.01*p), shape(X))       # 211-213
V = X-old_X
record statistics and first lock observations  # 215-254
```

`H_MAX` is the source's once-sampled [0,100] maximum plus epsilon (line 46). The frequency kernel uses **old positions/distances**. The optional horizon limits neighbor exchange, but same-band fusion still uses all band members, including distant ones: it is not a strict causal-isolation boundary for the whole model.

Observation: per band, `R_b=abs(R[band])`; coherence `1-std(R_b)/(mean(R_b)+1e-10)`; survival `mean(R_b)>.01`; first lock is the first pass with coherence>.7 **and** mean>.01. Lock is recorded, not a stopping rule or a force. Global output stores mean/max absolute resonance. Mean GRF is the average of individual `1/(1+||V_i||)`, different from the reciprocal of one plus mean speed. [218–250]

Domain and edge behavior: finite real X,R; positive frequencies; integer N>=1,B>=1; meaningful standard configuration k>=1, L>=0, sigma>=0. These are safe working domains, not source-enforced validators. With no neighbors or weight sum<1e-10, that row skips frequency modulation and nonlinear mixing, but still receives global memory, subsequent fusion if applicable, clipping and noise. Equal-distance ties inherit NumPy sort behavior; horizon mode explicitly removes self, unrestricted mode relies on the first sorted element being self. `d+1e-8` prevents a distance pole. The code has no nonfinite repair, norm renormalization, boundaries, convergence stop or internal reseeding after construction. The driver requests a finite number of passes. If all R=0, resonance remains zero and L=9, while X can still diffuse and receive noise. At x=0 the signed RPCO returns exactly zero; for nonzero x its magnitude lies in [exp(-L),exp(L)]. The lower clip is therefore amplification of very small nonzero magnitudes, not universal compression.

`L_p=9(1+epsilon*mean|R_(p-1)|)` is a derived scalar overwritten every pass, not an independently initialized dynamical degree of freedom. Its feedback to R occurs only through the clip. Where `-L<log(|Q|+1e-9)<L`, the exact mathematical expression is `Q+1e-9*sgn(Q)`, independent of L; the same floating operations are used for all inactive bounds. Changing L can matter at either clipping boundary. This conditional statement does not assert that clipping is absent on all historical trajectories.

Other March variants, kept distinct:

| Source | Difference from the complete Tower II rule |
|---|---|
| `srg_golden_tower.py` 50–190 | Random independent band assignment; `freq_amplitude=1` stored but unused; fixed L=9; only `+.001 exp(-10(log(omega_i/omega_j)-log(phi))^2)R_j` mixing for differing frequencies; no horizon; no breathing; same main spatial/memory/fusion/noise ordering |
| `srg_condensate_breaking.py` 60–203 | Frequencies drawn from four listed values if enabled; frequency kernel uses squared **frequency difference**, not log ratio. No explicit mixing terms. Optional bound `9[1+.3 sin(2*pi*.244*p) exp(-.01p)]` is externally prescribed. With a horizon, each local fusion center uses current in-place neighbor positions; without it, one global weighted center. This is not the Tower II band-fusion map. |
| `srg_breathing_collision.py` 63–174 | Equal band allocation; algebraic L always recalculated; no nonlinear mixing terms; otherwise band exchange/memory/fusion/noise. `R_trace` is allocated but not appended by `evolve_pass`; `L_trace` and mean-R trace are pre-update readouts. |
| Same, `merge_fields` 181–198 | Constructor consumes RNG, then concatenates states; pass becomes the maximum of input passes; stored L is averaged. The next step overwrites that average from concatenated R, so averaged L is not independent carried memory. Default coupling width can replace a nondefault input setting. |

### 2.6 Fixed linear SRG and incomplete paper recurrences

Retained corrected Bridge A6–A7 and reconciled QSM §3 give, in helicity-major order,

\[
\Psi^+=(B\otimes A)\Psi,\quad
B=e^{-i\alpha\sigma_z}e^{-i\beta\sigma_x},\quad
A=[qI+(r-q)P]Z[cI+(1-c)P],
\]
\[
P=ss^\dagger,\ s=(1,1,1)^T/\sqrt3,\quad
Z=\operatorname{diag}(1,e^{-2\pi i/3},e^{-4\pi i/3}),
\]
with q=exp(-.423), r=exp(.577), c=.382, alpha=2*pi*.244, beta=pi*.244. This follows the paper factor order `U_REFU U_TGMO U_flip U_RPCO` (P15 pp.5–6). It is a fixed preparation/transfer map, with zero mapped to zero. Optional normalization has a nonzero-denominator domain and discards amplitude. Retained facts: A^3=q^2 r c^2 I; raw fixed U is a strict contraction; relative spectral condition numbers follow the 1,e,e cycle, while fixed additive output error can be amplified under inversion. No suite was rerun. The paper's “normalization preserved” prose and infinitesimal Hamiltonian expressions do not replace this actual finite product; retain the corrected Bridge generator-sign qualifications.

P03 pp.7–8 gives `Theta_i(t+1)=C[Theta_i(t)+Delta_T Theta_i(t)+sum f]`, with `f=R_j cos(phi_ij)H_i/(1+d_ij^2)` and `Delta_T Theta_i(t)=Theta_i(t+1)-2Theta_i(t)+Theta_i(t-1)`. This is **implicit in the unknown next state**, not the explicit nearest-neighbor Laplacian used by the surviving engines. In the uncompressed branch substitution cancels the unknown and leaves a compatibility condition, not a unique successor. The threshold, phase/echo-set updates, carrier typing and branch/solver rule are not fully supplied. P03 also gives a partner-dependent min compressor (p.6) and a different threshold compressor (p.8); neither should be silently replaced by signed RPCO.

P07 p.5 leaves `Nonlinear(D(t))`, the discrete Laplacian helper/boundaries and precise memory-stage composition unspecified. P02 pp.5–7 names additional scripts and pass files that do not survive in OLD_MATERIAL. P19 Algorithm 1 likewise leaves operators/estimation undefined (section 4). For these particular manuscript constructions: **NO_COMPLETE_RECURRENCE_RECOVERED**. This does not apply to the complete executable versions above.

## 3. Formula/constant provenance and paper-versus-code discrepancies

Evidence labels used here: **source definition**, **derived identity**, **numerical evidence**, **historical interpretation**, **new proposal**, **unresolved**. A definition can be mathematically well formed without being independently measured.

| Formula or constant | Type/domain; source locator | Executable role and evidence status |
|---|---|---|
| `H(t)=2e^(-.5t)cos t+e^(-.3t)sin t+1.5e^(-.7t)+e^(-.4t)` | Real prescribed function, t>=0 in these drivers; O Reading material/REFU.py 5–16; P18 p.4 | **Source definition.** Active schedule in tetrahedral/March versions; not endogenous trajectory memory. Coefficients are specified choices; no fitting data recovered. |
| `.05,.15,.03,.02,.01,.001` | Gains, noise scales, sinusoidal amplitudes; equations/line ranges in §2 | **Source definitions / tuned choices**, not geometric identities. Distinguish .02 July noise from .02 March band fusion. |
| `.618` | July constant; P15 p.5 lambda_c | Named golden/Vesica compression approximation by source; unused in July engine, used as fixed projector strength in P15. Exact phi inverse is not the literal. |
| `.577` | O position engine line 10 labels Euler–Mascheroni; P15 p.6 Gamma | Approximation label exists in July source; exact stored decimal in fixed transfer. Neither `.577` nor Euler–Mascheroni equals gamma_star=.0869947. |
| `.423=1-.577` | P15 p.6 eta | **Derived decimal arithmetic** within the fixed chosen parameter set; not an independently derived mathematical constant. |
| `.382=1-.618` | P15 partial projector; QSM fixed c | **Derived decimal arithmetic** and implemented literal. Do not substitute phi^(-2). The full-family parameters need not obey the frozen numerical complements. |
| `.244` | P06 p.4 says approximately .244 Hz from curvature harmonics, without operational derivation there; July engine line 11; M tower line 34 | **Source choice / unresolved upstream derivation.** Operationally cycles/step in sin(2*pi*.244*p); radians/pass in infinity cross sine; turns in fixed alpha=2*pi*.244; retained QSM distinguishes native .244 radians. Shared digits do not establish conversion or causality. |
| `phi=(1+sqrt(5))/2`, `omega_b=.244 phi^n` | Positive real tower; P18 p.7, M Tower II 31,75–84 | Exact definition of phi; **assigned frequency spacing**. Golden-ratio proximity targets also explicitly enter mixing (174–188), so golden preference is partly designed into the update. |
| `pi,e` | P18 p.4; ordinary mathematical constants | pi converts cycles to radians; e occurs in exponential schedules/clips; their product with phi in the lock normalization is a **source definition**, not selected by the recovered graph. |
| `zeta(3)/(pi e phi)=.08699474751703501` | P18 p.4; M resonance_lock_analysis 24–44 and saved JSON | **Derived identity conditional on assigned lock equation.** P01 p.3 claims empirical observation but the independent estimator data is absent. `.08699` is an active approximate input in infinity; `.0870` is unused in basic GlyphField. |
| `g_m=zeta(2m+1)/(pi e phi), m>=1` | P18 p.5 | **Source definition.** `m=n+1` produces `2n+3` for n>=0; **derived identity**, not explanation of family selection. |
| Spectral `+3` | P18 p.7; Tower I zeta map and Tower II 292–298 | Odd-zeta index shift as above. Does not explain 3 spatial coordinates, 3 corridor labels, cubic field stabilization or a third phase harmonic. |
| Other 3s | X has three coordinates; P15 has three corridor basis labels and 1/sqrt(3) normalization; URF quartic energy derivative gives a cubic | Separate carrier choices and algebraic consequences. The normalized rank-one P has entries 1/3. No recovered rule identifies them with the spectral +3. |
| `sqrt(3)/2` | Retained Bridge review A1: equal-radius equal-separation lens/triangle geometry | **Derived geometric identity** for unit equilateral altitude/half-chord. Not a coefficient of the selected glyph updates; no map from it to zeta coupling recovered. |
| `L=9`, `eps_rpc=1e-9` | March signed RPCO | **Source choices**. eps means the inactive operator is not mathematically exactly identity on nonzero input. P07's different unsigned expression uses L=10 and eps=1e-6. |
| `1e-8`, `1e-10`, `.7`, `.01`, `.95`, `.66`, `.012` | Distance/weight safeguards and source thresholds | Numerical guards / observer choices. `.95` cosine-graph threshold, `.66/.012` July seed filter, `.7/.01` Tower II lock observer have different roles. |
| `L_p=9(1+epsilon mean|R_(p-1)|)` | P18 p.8; Tower II 134–138 | **Source definition**, algebraic readout with conditional clipping feedback. Not a separate differential equation for L. |

For all main formulas the domains and operative stage citations are in §2. Reference-path hashes are preserved even where a result is retained rather than freshly derived.

| Paper statement | Recovered implementation or evidence | Assessment |
|---|---|---|
| P02 p.5 cites `recursive_field_evolve.py` for resonance feedback, H and overlap fusion | Surviving script evolves only positions; no R,H or overlap threshold | Different/incomplete source versions; no repair inferred |
| P05 p.2 lists breathing amplitude as implemented | Script calculates `amp` at line 63 but does not use it | Inactive calculation; `.618` and `.577` also unused |
| P07 p.3 says sign is retained | Printed Python is `exp(clip(log(abs(x)+eps)*sign(x)))`, always positive, zero -> 1 | Formula contradicts prose; distinct from March signed C |
| P18 p.4 signed formula says negative inputs invert to positive | Signed C(-2) is approximately -2.000000001, not +.5 | Visually verified formula/prose conflict; finite counterexample checked |
| Same “negative reals map into (0,1)” | Even the unsigned inverse maps -a to 1/(a+eps) when unclipped, which can exceed one | Range claim also fails without a magnitude restriction |
| P18 p.4 TGMO ensures finite toroidal spatial extent | March engines have no wrapping; only neighbor diffusion/fusion and Gaussian noise | No hard spatial bound established |
| P18 p.5 GRF uses reciprocal of mean speed | March per-band/infinity mean GRF averages reciprocals | Distinct diagnostics; tetrahedral engine does use reciprocal of mean speed |
| P18 p.6 all R approach .176329 with variance below 1e-6 | Saved t=200 has max .176329, mean .151203, std .020442 | Saved endpoint is not that uniform state; no saved t>200 trace here proves later convergence |
| P18 p.7 equilibrium couplings “match precisely” | CSV column is `gamma_predicted` from assigned frequencies; no measured gamma | Numerical evaluation of a definition, not independent measurement |
| P18 p.8 universally self-sustained L oscillation | L computed from incoming R; FFT subtracts mean only, 150 samples; peak .0066667=1/150 | Periodicity/independent-field interpretation unresolved; window/trend control needed |
| P17 p.9 GRF is designed exponential decay, curves do not intersect | `plot_1.py` GRF is velocity-derived; p.10 displayed curves visibly intersect | Those figures are a different construction; no verified raw-data linkage |
| P15 p.4 normalization preserved | Retained fixed U is nonunitary and contracts raw norm | Raw transfer and normalized display must be distinguished |

## 4. Coupling/lock causal trace and unresolved spectral map

### 4.1 Four incompatible meanings of gamma

1. **Historical empirical claim:** P01 pp.3–4 describes gamma as calibrated/empirical, on the order of .1, with the lock relation not derived from first principles. Neither a per-run independently measured gamma column nor its estimator is present in the inspected July code/data chain. P06 supplies the same lock equation as a cosmological interpretation. Those statements are **historical interpretation / unresolved measurement provenance**.
2. **URF target and estimator:** P19 p.2 explicitly supplies
   \[
   \mathcal L_{lock}=-\Lambda_{lock}(\pi e\varphi-\gamma^{-1}\zeta(3))^2-\rho(\gamma-\widehat\gamma(\Psi,\Phi,C))^2.
   \]
   The first term inserts the fixed residual-zero target gamma_star. An independently estimated gamma_hat could provide separate information, but Algorithm 1 p.13 only says `GammaEstimate({Phi_a}, spectra, zeta(3))`. Its definition, fit objective, spectrum-to-scalar map, discretization, kernel, inverse-Laplacian boundaries and update law for gamma are not supplied. The printed loop records a residual after an unspecified estimate; it does not explicitly perform the penalty-driven gamma update described in prose. P19 pp.8–9 and 11–12 continue to call gamma emergent and tuned. The target is fully specified; its independent estimator and complete coupled dynamics are **unresolved**. Placeholder-looking run metadata, including `a1b2c3d4` and ellipses, is not a verified execution receipt.
3. **March dynamical coefficient:** `.08699` is fed into infinity cross-coupling; `.0870` in `GlyphField` and `.08699` in `GlyphFieldUniverse` are unused fields. No iterative estimation of gamma occurs there.
4. **March static map:** Tower II's `evolve_pass` never calls zeta or reads `LOCK_PRODUCT`. After 200 passes, `experiment_master_equation_verification` (262–368) calculates n from the **assigned** omega, sets `gamma_predicted=zeta(2n+3)/LOCK_PRODUCT` only if argument>1.01, otherwise NaN, and compares it with the observed lock time. The scalar does not determine that lock observer's .7/.01 thresholds. Saved lock time is an observation of coherence, not satisfaction of the zeta equation.

In the integration **proposal**, `master_equation_gamma` (192–205) uses a 100-term series, falls back to a fixed gamma below/equal s=1, and `evolve_breathing` (271–295) relaxes `R` toward the explicitly inserted `.176329` at rate `.01*state.gamma`, while assigning a sinusoidal L. This is a different target-relaxation construction. It is not evidence that `.176329` or an autonomous heartbeat emerged in the historical glyph recurrence; nothing from that proposal was installed or executed.

### 4.2 Frequency, index and domain

P18 p.7 equation (12) and §7.4 are visually clear: gamma has the argument omega and the zeta argument ends in +3; §7.4 explicitly calls it static. No unresolved transcription ambiguity remains on this page.

On the positive-frequency domain, s=`2 log_phi(omega/omega0)+3`. Ordinary-series evaluation requires s>1, equivalently omega>omega0/phi; equality is the pole. Positive omega below that threshold would need a declared analytic-continuation interpretation. The tower dynamics can assign lower bands without evaluating this map there: the verification code leaves their gamma predictions NaN. Therefore a pole outside the evaluated subset is not a contradiction in the position/resonance evolution.

The one-based family `g_m=zeta(2m+1)/(pi e phi)` and zero-based tower match under **m=n+1, n>=0**. This is algebraic indexing. The choice of the odd-zeta family, its normalization and the golden band assignment is still supplied by the source. Natural frequencies never mutate in these engines. FFT peaks of the measured resonance time series are a different observable; source labels above .5 cycles/pass also require discrete-time aliasing care and cannot automatically be identified with unaliased oscillation frequencies.

### 4.3 Geometry–Zeta and fixed preparation

**NO_SOURCE_MAP_ESTABLISHED.** In the bounded July/March/URF/fixed-reference chain, no documented rule selects the auxiliary cycle operator `A_N=N^2(-Delta_N)`, its zero-mode omission, inverse-three-halves trace (inverse cube of frequencies), or multiplier `4*pi^2/(e*phi)` from a recovered historical glyph trajectory. The supplied Geometry–Zeta construction and its full-cycle/repeated-triad distinction remain valid scoped context. This is absence of a source map in this search, not a universal impossibility claim.

No identification among the native triad, native six-site ring, fixed complex six-component carrier and real glyph array was introduced. Reconciled QSM and corrected Bridge acceptance are retained; the earlier unqualified Bridge prose is not promoted over its adversarial corrections. The centre display convention gives no new causal state variable or physical location for the recursion.

## 5. Surviving simulations, checks and coverage limits

### 5.1 Older data with actual source connections

[saved_data_checks.json](saved_data_checks.json) records the numerical evidence. No original launcher or module was run.

| Saved artifact | Inspected evidence and supported linkage |
|---|---|
| `PLOT_1_tetrahedral_states_20250712_015421.csv` | 8,736 rows = 1,092 eight-body callback blocks, frames 0–199, 7,136 repeated `(Step,Tetrahedron)` keys. In row order, wrapped position increment=.1*new velocity to 4.45e-15. Ten sampled consecutive blocks match the full in-place `plot_1.py` velocity equation to 1.12e-16, conditional on the stored binary rule outcomes. Energy residual <=6.67e-16. |
| `tetrahedral_states_20250712_015647.csv` | 3,520 rows = 440 callback blocks, same frame range, 1,920 repeated keys. Same position identity to 4.45e-15; ten sampled full velocity transitions to 2.78e-16; energy residual <=4.45e-16. |
| `tetrahedral_states_curvature_20250712_062601.csv` | 1,600 rows, 200 unique steps x 8 bodies, with Curvature, Adjusted_DT, Teleport_Flag and Emotional_Energy. Position increments match the stored row-specific Adjusted_DT and new velocity to 3.56e-15; kinetic energy to 1.12e-16. Its full generating velocity/curvature/time-adjustment rule is absent from the inspected executable set. Do not substitute `plot_1.py`'s fixed dt. |
| `symbolic_glyphs_resonance_pass.csv` family | 166 rows with Step/Tetrahedron/velocity/curvature and derived fields. All 166 keys join the curvature log and coordinates match exactly as parsed floats. This is a selected derived trail, not 166 independent initial glyphs. |
| `ProtoSRG_1_Recursive_Embedding.csv` | 166 rows, rich inherited schema plus Recursive_Weight/Tier. Coordinates agree with the 166-row glyph data; not the 50-row assigned straight/noisy trajectory generated by the top-level utility, nor the patch driver's X/Y/Z-only final state. |
| `ProtoSRG1_MultiFit_Results.csv` and alias | 166 rows; the script normalizes weights, evaluates a cubic interpolation at the original sample indices, computes PCA of X/Y/normalized weight, and assigns quantile tiers. Those features are postprocessing, not a recovered force law. |
| Echo corridor CSV pair | Two 3,073-row tables survive. `echo_map_2.py` compares pairwise spatial distances between steps of one selected `Glyph_8b2038` trail, min-max normalizes distance and filters below .1. This is an observer of a selected path, not a bidirectional coupling engine. |
| `refu_memory_curve.txt`, `rpco_field_values.txt`, `tgmo_orbit_values.txt` | 1,000 / 10,000 / 200 samples respectively; match assigned helper formulas within 5e-6, the five-decimal export precision. TGMO's fixed azimuth gives a sampled minor circle, not a full 2D torus state. Duplicate originals under Reading material and Simulations_part_2 are hash-grouped. |

These matches strengthen source linkage without recovering the original RNG state or GUI callback schedule. The binary rule draw sequence was not reconstructed. No claim of byte-for-byte simulation reproduction is made.

The July seed dataset name is misleading as a lineage guarantee: its surviving schema must be read directly, not assumed to be paper Pass 0. There are no saved `symbolic_glyphs_resonance_pass1/2/3.csv` sequences or `SRG_final_field.csv` in OLD_MATERIAL. Nor do the specifically named `glyph_trail_tracker.py`, `find_resonance_peaks.py`, `cluster_resonant_events.py`, `recursive_weight_normalizer.py`, `srg_field_animate.py` survive there. Existing differently named analysis utilities recover parts of the observation pipeline, not those missing iterations.

`generate_research_csv.py` seeds NumPy with 42, makes 200 random positions/resonance/GRF/curvature values, 50 noisy points around prescribed linspace coordinates, squared linspace weights, and random cluster IDs. P05 p.3 explicitly calls it a synthetic test utility. That classification **does not** imply the older, richer 166-row data came from it; the schemas and traced coordinates say otherwise.

### 5.2 March saved results

There are 23 CSVs, one JSON result file, seven Python scripts, six Markdown notes and a TeX manuscript in the selected March archive directory. All are preserved compactly, with schema/row counts in [csv_evidence_summary.json](csv_evidence_summary.json). Numerical claims below are readings or reanalyses of saved files, not fresh historical runs.

* `deep_trajectory.csv`: 1,050 raw state rows = 50 glyphs x passes 0–20, with positions, resonance and velocity. The source driver is `srg_seed_explorer.py` 599–674, seed 2038, default [0,.1] resonance; `pass_metrics.csv` has 20 aggregate rows. This is the clearest saved March full-state trace.
* `srg_infinity_asymptotic.csv`: 200 aggregate rows from the source's 50-glyph, seed-2038, R-range [0,.3] experiment (282–288). At pass 200: R_max=.1763290586527628, R_mean=.1512033957426239, R_std=.020441937084602, coherence=.8648050486415766, dark/matter squared-sum ratio=3.712091178e-5. No full state or >200-pass trajectory is saved by this file. Its maximum matches the paper's proposed condensate number; its variance does not demonstrate a uniform condensate. Continued periodic forcing and epsilon offsets also preclude treating a finite endpoint as a proved exact autonomous fixed point.
* `master_equation_verification.csv`: 90 band records, 45 finite gamma predictions. The source filter gives 44 finite locked records with lock_time<200. Reanalysis gives Pearson r=-.16012940601139478. High-index mean gamma=.0724554086490398 is an average of **predicted** values. This is not an equilibrium gamma measurement.
* `tower_height.csv`: 30 configuration/trial rows spanning 2–20 bands; `tower_phase_diagram.csv`: 25 configurations spanning 2–12 bands and widths .5–8. Their survival_rate columns are one throughout. They document those trials and the chosen survival threshold, not universal indestructibility. Assigned frequency labels remain fixed by construction.
* `self_coupled_breathing.csv`: seven epsilon settings 0,.1,.5,1,2,5,10, all with identical final R_mean=.5489832686504329. Nonzero-epsilon rows report f=.006666666666666667. Source lines 382–418 use N=80, B=4, seed=2038, 200 passes and the last 150 samples after removing only their mean. That peak equals the first FFT bin. The saved means, standard deviations and ranges of L scale linearly with epsilon, consistent with the defined algebraic readout. The raw L time series and clipping activation counts are not in this CSV. A sustained oscillator is not established by this statistic alone.
* Eight heartbeat fingerprints, merger summaries, horizon/multifrequency summaries and perturbation tables survive. They have no saved complete per-run state/RNG checkpoints. They are retained for audit; R0 does not re-certify every collision or symmetry-breaking interpretation. `resonance_lock_results.json` records algebraically solved gamma and six **NaN** eigenmode lock times, not successful locks. Its geometry labels are assigned strings. NaN is retained verbatim as historical nonstandard JSON content.

Reproducibility gaps: several scripts use absolute `/sessions/...` output directories and execute `os.makedirs` or analysis at import time; none was imported. Basic seed-family trials use `hash(label)%1000` (line 324), making nominal seeds process-hash-dependent unless PYTHONHASHSEED or the realized seed is saved. Some multi-seed drivers use `seed=None`. Saved trial numbers do not by themselves recover random streams. All engines use NumPy's global RNG, so interleaving field instances changes which noise each receives. The local original software versions are not recorded sufficiently for bitwise regeneration.

### 5.3 What R0 actually checked

* Read-only manifest/hash survey of all 97 OLD_MATERIAL files: 79,909,479 bytes; 85 distinct hashes; 35 scripts, 21 CSVs, 6 text samples, 17 PDFs, 11 PNGs, 7 MP4s; no reparse points or nested archives there.
* Static reading of all OLD Python sources (duplicate aliases reused), complete operative March classes and relevant drivers/observers. The report focuses on representative complete recurrences, not a fabricated combined model. Third-party library internals were not audited.
* Text extraction for all 17 old PDFs and the two local primary leads; 28 selected equation/constant/figure pages rendered with bundled Poppler and visually inspected. The exact selected page list is in [page_image_ledger.json](page_image_ledger.json). This is not a cover-to-cover mathematical review of every supporting manuscript. The original PNG/MP4 files were inventoried and hashed, not decoded or provenance-matched to raw records. File-by-file roles and limits are in [SOURCE_COVERAGE.md](SOURCE_COVERAGE.md).
* Bounded standalone checker: 11 scoped records pass, including **two total update calls** on line-exact audited excerpts, negative/zero/clipping counterexamples, one H-normalization evaluation, an index identity and three sampled-formula comparisons. Not 11 independent theorems. No full historical simulation ran.
* Saved-data analysis: table schemas, source-consistent row ordering, position/energy identities, 20 sampled eight-body transitions across two logs, exact coordinate joins, and one saved lock correlation. An initial analysis incorrectly grouped repeated frames for energy and assumed fixed dt in the curvature log; inspection resolved both by using eight-row callback blocks and saved Adjusted_DT. Final results retain the corrected conventions explicitly.
* Retained, not rerun: supplied Geometry–Zeta 44/44 and sector 20/20 receipts; corrected Bridge and reconciled QSM results. No native, full Bridge, QSM or auxiliary suite was launched.
* The proposed next harness is syntax-checked only. Its 2,400-pass experiment is not part of R0's executed checks.

Runtime: Python 3.11.15, NumPy 2.4.4, SciPy 1.17.1, pandas 3.0.3 in `conda activate torment` for analysis/checks. PDF parsing used the already bundled Python/pypdf because torment lacks a PDF parser; rendering used bundled Poppler. No packages were installed or environment configuration changed.

## 6. One bounded next experiment

**NEW PROPOSAL: determine whether Tower II breathing is causally active at source-scale resonance, and whether its slow FFT peak is a window artifact.** Use the complete Tower II version above, not the simplified collision field and not a native kernel.

Prepared [next_experiment.py](next_experiment.py) loads the audited line-exact core only. It runs two paired epsilon settings `{0,1}` for seeds `{2038,42}`, N=80, four bands, 600 passes each, **2,400 total passes maximum**. Source values: X uniform [-5,5]^3, R uniform [0,.3], k=5, alpha=.05, beta=.15, lambda_H=.05, L_base=9, sigma=2, nonlinear strength=.001, no horizon. These values occur in the source experiment; the longer bound and additional paired seed are new design choices. Both members of each pair reset to the same seed and execute the same random-draw schedule. No forcing term is removed.

The wrapper's RPCO instrumentation only records its input/bound and calls the copied operator unchanged. It stores:

* `*_raw.npz`: positions/velocities `(601,80,3)`, real resonance `(601,80)`, pre-RPCO resonance `(600,80)`, L used `(600,)`, fixed frequencies and band labels; initial state retained.
* `*_diagnostics.csv`: pass, L, raw resonance mean/min/max/std, mean GRF, H and source-scale diagnostics. Newly labelled diagnostics: squared resonance sum (not a physical energy), radius of gyration, clipping count/log-margin, maximum raw state changes.
* `experiment_results.json`: exact configuration, versions, lock times, paired maximum differences, and FFT analyses on trace slices `[50:200]`, `[50:350]`, `[50:600]`, with both source-style mean removal and newly proposed linear detrending.

The supervisor kills its worker after **180 seconds**; finite array sizes bound state storage (four raw arrays sets are tens of MB, with expected process memory below 512 MB; this is a size estimate, not an OS memory cap). It sets single-thread library environment variables only for that subprocess, stops on nonfinite values, and refuses to overwrite an existing output directory or write outside SRG_REDISCOVERY. If the wall limit is reached, the run is incomplete, not a negative scientific result. Expected output is under 100 MB; no figures/UI/network are required.

Exact Windows CMD invocation, after GPT's separate next-run decision:

```bat
call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
cd /d C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R0_SOURCE_RECOVERY
set PYTHONDONTWRITEBYTECODE=1
python next_experiment.py --execute --output C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R0_SOURCE_RECOVERY\NEXT_EXPERIMENT_RUN_01
```

Interpretation rules:

1. If every preclip value stays inside both bounds and paired raw trajectories agree, L is a passive readout **along those runs**; this does not refute clipping feedback elsewhere. If trajectories first separate at clipping, report the first activation and its stage. If they separate before clipping, investigate random-stream/implementation differences before interpreting it as physics.
2. A peak that tracks `1/window_length` and changes after detrending is not evidence for a stable intrinsic period. A persistent nonzero peak across longer windows needs inspection of the raw trace, multiple cycles and uncertainty/resolution; do not infer an autonomous oscillator while assigned sine forcing remains.
3. Zero, negative and small-magnitude/clip-active operator controls already have finite R0 checks. In the recommendation, comparisons of epsilon are a **source-exposed parameter control**; no new feedback or removed-force model is silently introduced. Distinct seeds test reproducibility, not universality.
4. Retain raw scale. Do not normalize away contraction or label squared R “probability”/physical intensity. L and clipping activity are source-related compression readouts; radius of gyration is explicitly a new diagnostic, not invented information compression.

This model currently supports a **standalone stochastic dynamical experiment**. The zeta relation separately supports a static parameter map. The fixed six-component system supports preparation/extraction under its retained contracts. No physical centre force, particle label or native handoff is recommended.

## 7. Administrative closeout and review package

The requested start package was found extracted directly into `SRG_REDISCOVERY`, rather than inside a same-named subfolder. `READ_THIS_FIRST.md`, the GPT review, original supplied ZIP context and the work order were read. Before writing, no `R0_SOURCE_RECOVERY` or prior local R0 result directory existed; the supplied package describes a prepared assignment, not completed recovery. It was not overwritten.

All new files are below `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R0_SOURCE_RECOVERY`. No Git commands or Git metadata edits, original-source edits, kernel/UI changes, publication edits, installs or external distribution were performed. Final integrity checks confirm all 97 OLD_MATERIAL files are unchanged, all 106 selected copies match their still-unchanged originals, and all seven starting-package payloads match its manifest. See [INTEGRITY_RECEIPT.json](INTEGRITY_RECEIPT.json). The actual March ZIP matches the corpus hash and all 38 selected members match the archive bytes; see [march_archive_verification.json](march_archive_verification.json).

`SRG_R0_GPT_REVIEW.zip` contains this report, the complete manifests and evidence ledgers, selected complete original source scripts and CSVs, March/URF primary PDFs, PDF text extractions and selected page images with original path/hash/page bounds, corrected Bridge/QSM references, retained receipts, audited excerpt/checker code and the **unexecuted** next-experiment harness. Extracted text is labelled as text, not original PDF bytes; its page coverage is recorded in the PDF inventory. The ZIP excludes original videos, original old-PDF collection and unrelated repository material. Package entry hashes are in `PACKAGE_MANIFEST.json` inside the ZIP; its self-exclusion is explicit. [REVIEW_START_HERE.md](REVIEW_START_HERE.md) gives a short review order. The original archive is not the review package.

The main review questions are mathematical/source gaps, not requests for Hilmir to recall equations: (a) is an independent `GammaEstimate`/spectral normalization source available beyond this bounded chain; (b) which original code created the curvature/Adjusted_DT log and the missing multi-pass resonance files; (c) should the next experiment first adjudicate clipping causality and the FFT-window interpretation as proposed? None blocks delivery of the recovered executable recurrences. No additional user approval is needed for this completed R0 recovery.
