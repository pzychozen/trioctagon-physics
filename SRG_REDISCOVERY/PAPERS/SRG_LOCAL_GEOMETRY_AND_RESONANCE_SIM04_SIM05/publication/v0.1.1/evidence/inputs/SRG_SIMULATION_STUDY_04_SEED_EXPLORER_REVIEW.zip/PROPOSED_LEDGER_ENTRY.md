# Proposed ledger entry — not applied

## SIM04 — March seed explorer and saved resonance-field trace

**Status:** IN REVIEW, 23 October 2026. Scientific lead GPT; author/research director Hilmir Frímann Halldórsson; research engineering Codex. Study order does not assert historical precedence or direct descent from Volume I.

**Source:** `research_files/archive_members/Zenodo_research/19023429/simulations.zip/srg_seed_explorer.py`, also recovered under `R0_SOURCE_RECOVERY/selected_sources/MARCH_19023429/`. SHA-256 `0c8ec661624bd100212b29d75dd184cacf2adbf5d173584e3817460d9fd6ea10`; header date March 14, 2026. Complete 755-line source read as text; never imported or launched.

**Evidence:** `deep_trajectory.csv`, SHA-256 `7bcb5ceb18a65977c3c13b7c848962d897775a93aa0a2e3a6713c339ac3a4ee3`: 1,050 rows, 50 IDs × passes 0–20 in original order. `pass_metrics.csv`, SHA-256 `f6d4484d654b4f88f1fa32024f6f88b3f7065ff67192d52d7124223f9e15d063`: 20 post-pass rows. All source/data copies match the March archive. Driver/run linkage strongly ATTRIBUTED; initializer RNG/software fingerprint remains missing. No original matching figure/movie located in the bounded evidence package. Four figures are new visualizations of historical data.

**Construction:** X,R are the operative state; V is measured ΔX, not retained momentum. Rebuilt directed five-neighbor graph; synchronous normalized local position displacement and incoming-distance-weighted resonance exchange; prescribed integer-pass H multiplier; one global resonance-weighted fusion center; small prescribed sine in R; signed log/clip/exp RPCO; additive positional noise. History records initial and each post-update state. No spatial wrap. Stored `lambda_vp` and `gamma_srg` are unused. Seeds, coherence, corridors and geometry are observers.

**Observed:** radius of gyration 5.38637→4.18646; coherence .40683→.85634. Top ID 3→40→38 at passes 3/6, with continued movement of 38. First corridor 5/43 at pass 7. Final top three 38/23/8 are within .06774, still distinct. Newly evaluated nearest-neighbor graphs have 1→2→3 weak components across the record, despite global fusion. `higher_polyhedra` occurs already at initialization because 13 active points select its unconditional branch.

**Verification:** all 240 aggregate values and 3,000 V components match exactly as parsed doubles; 1,000 conditional resonance expressions differ by at most 1.39e−17 with tolerance 1e−12. Positional residual std .0100155 is compatible in scale with source σ=.01, not recovery of random draws or full recurrence reproduction. No clipping in the evaluated transitions. Original source, accepted work and canonical ledger preserved.

**Limits:** no universal merger, long-time equilibrium, polyhedral proof, physical-energy/gravity or master-equation claim. Review package: `SRG_SIMULATION_STUDY_04_SEED_EXPLORER/`. No new simulation, publication or next study. Apply a ledger entry only after a separate review decision; this file does not mark acceptance.
