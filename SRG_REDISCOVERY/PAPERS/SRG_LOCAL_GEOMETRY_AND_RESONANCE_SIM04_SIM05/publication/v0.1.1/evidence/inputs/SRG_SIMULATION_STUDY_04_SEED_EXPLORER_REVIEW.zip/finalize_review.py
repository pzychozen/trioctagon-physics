"""Seal this review without changing any original, ledger or repository metadata."""
from pathlib import Path
import hashlib,json,zipfile,datetime,re,ast,shutil
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[1]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(name,data):(ROOT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(path):return json.loads(path.read_text(encoding='utf-8'))
archive=ROOT/'SRG_SIMULATION_STUDY_04_SEED_EXPLORER_REVIEW.zip'
assert not archive.exists(),'Existing sealed review must not be overwritten'
comparison=REPO/'SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/CROSS_STUDY_MECHANISM_MAP.md'
supplement=ROOT/'PRESERVATION_COMPARISON_CONTEXT.json'
if not supplement.exists():
    dump(supplement.name,{'note':'Additional accepted comparison source read after independent SIM04 analysis; no write to its original.','files':[{'path':str(comparison),'bytes':comparison.stat().st_size,'sha256':sha(comparison)}]})
shutil.copyfile(comparison,ROOT/'context/VOLUME_I_CROSS_STUDY_MECHANISM_MAP.md')
baseline=load(ROOT/'PRESERVATION_BASELINE.json')['files']+load(supplement)['files']
for row in baseline:
    p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
copies=[]
for row in load(ROOT/'SOURCE_PROVENANCE.json')['files']:
    p=ROOT/row['new_copy'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
    copies.append({'path':row['new_copy'],'bytes':p.stat().st_size,'sha256':sha(p),'matches_original':True})
checks=load(ROOT/'analysis/checks.json');assert checks['all_checks_pass']
required=['START_HERE.md','CONSTRUCTION.md','ORIGINAL_EVIDENCE.md','VERIFICATION_AND_LIMITS.md','PROPOSED_LEDGER_ENTRY.md']
source=(ROOT/'originals/srg_seed_explorer.py').read_text(encoding='utf-8');assert len(source.splitlines())==755
# Static guard for the new calculation scripts. Original source remains data.
guard=[]
for name in ['inspect_saved_records.py','plot_historical_records.py']:
    tree=ast.parse((ROOT/name).read_text(encoding='utf-8'));forbidden=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.Import,ast.ImportFrom)) and 'srg_seed_explorer' in ast.unparse(node):forbidden.append(ast.unparse(node))
        if isinstance(node,ast.Call):
            call=ast.unparse(node.func)
            if 'random' in call or 'evolve' in call or call in ['exec','eval','compile']:forbidden.append(call)
    assert not forbidden,(name,forbidden)
    guard.append({'script':name,'original_import_or_execution_or_rng_or_evolve_calls':forbidden,'pass':True})
dump('PRESERVATION_RECEIPT.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Inspected original/context files only; not a whole repository audit','protected_files':len(baseline),'all_unchanged':True,'files':baseline,'original_copies':copies,'ledger_unchanged':True,'writes_confined_to_new_study_directory':True,'git_writes':False,'kernel_changes':False,'new_simulation':False})
links=[]
for name in required:
    p=ROOT/name;assert p.exists()
    for label,link in re.findall(r'!?\[([^\]]*)\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if re.match(r'https?://',link):continue
        target=ROOT/link.split('#')[0]
        assert target.exists(),(name,link)
        links.append({'document':name,'target':link,'exists':True})
dump('PACKAGE_VALIDATION.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_status':'IN REVIEW','required_documents':required,'link_checks':links,'source_lines_read':755,'static_analysis_guards':guard,'numeric_checks_record':'analysis/checks.json','source_and_data_provenance':'SOURCE_PROVENANCE.json','figures':{'count':4,'pngs_visually_inspected':True,'all_labeled_new_visualization_of_historical_data':True,'F02_has_fixed_axes_and_color_scale':True,'no_original_movie_claim':True},'no_scientific_acceptance_claim':True,'no_canonical_ledger_edit':True})
paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and '.matplotlib_cache' not in p.parts and p.name not in ['MANIFEST.json','DELIVERY_RECEIPT.json',archive.name])
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'study':'SRG_SIMULATION_STUDY_04_SEED_EXPLORER','status':'IN REVIEW','classification':'Historical source construction and saved-record inspection; no new simulation','self_exclusion':'This manifest does not hash itself. ZIP identity is in adjacent DELIVERY_RECEIPT.json. Matplotlib cache is not a review artifact.','files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]}
dump('MANIFEST.json',manifest)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in paths+[ROOT/'MANIFEST.json']:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={'MANIFEST.json'}|{r['path'] for r in manifest['files']}
    for r in manifest['files']:
        b=z.read(r['path']);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
delivery={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'IN REVIEW','zip':archive.name,'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive),'zip_members':len(manifest['files'])+1,'manifest_sha256':sha(ROOT/'MANIFEST.json'),'all_zip_member_hashes_verified':True,'preserved_files':len(baseline),'originals_unchanged':True,'no_new_simulation':True}
dump('DELIVERY_RECEIPT.json',delivery)
print(json.dumps(delivery,indent=2))
