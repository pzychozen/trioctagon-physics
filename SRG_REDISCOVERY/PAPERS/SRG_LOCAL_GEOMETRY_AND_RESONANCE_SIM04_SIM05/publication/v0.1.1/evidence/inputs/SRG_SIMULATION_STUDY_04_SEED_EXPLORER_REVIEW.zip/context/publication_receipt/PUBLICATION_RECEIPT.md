# Publication receipt — SRG Simulation Reconstruction, Volume I v0.1.1

The exact GPT-accepted PUB-01 edition is published on `main` in `pzychozen/trioctagon-physics`. All **502 files (72,789,875 bytes)** were checked in the Git index, in the publication commit, and against **freshly downloaded bytes from that immutable remote commit**. Every comparison passed. The existing static publication verifier passed locally and on the downloaded edition. The accepted payload was not rebuilt or edited.

Owner authorization in the conversation activated the attached execution order. GPT's acceptance identifies the exact payload; it was not treated as owner permission by itself.

## Identity and scope

- Publication commit: `63469551eb04c17bfbedb6b8fce057c5890cbba8`.
- Sole parent: `170e638ecc0438f911c4ceb8091ffb1b574652fe`.
- Resolved remote `main`: `63469551eb04c17bfbedb6b8fce057c5890cbba8`.
- Exactly one commit; normal `git push origin main`; all 502 changes are additions under `SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1`.
- Exact paths, lengths and hashes: [EXACT_PUBLICATION_FILE_LIST.json](EXACT_PUBLICATION_FILE_LIST.json).
- Approved closeout ZIP SHA-256: `aa051f95931850bd5b2e898a2aaf3bcc3a65987c65427f639d9fcec429d4caec`.
- Manifest SHA-256: `e71386570f5bc48c93c9b17b7c039c490cc39757c5ea0875601f72e64a7725b8` (501 manifest rows plus the independently checked manifest file = 502 files).
- PDF: 3,712,962 bytes; SHA-256 `56489c2a4702ca05686cf47bd91faf6cf1981126f48191b8fb5b2b40aea61b9a`.
- Completed UTC: 2026-10-22T23:20:16.369951+00:00.

## Byte verification

| Stage | Result | Detailed record |
| --- | --- | --- |
| Local accepted scope/archive/attributes | PASS | preflight.json; attributes.json |
| Exact index name/status and blobs | 502/502 match; manifest separately checked | stage_verification.json |
| Commit parent, changed paths and blobs | 502/502 match; no other changed paths | commit_verification.json |
| Fresh commit-pinned HTTPS downloads | 502/502 match; 72,789,875 bytes | remote_byte_verification.json |
| Unchanged static integrity verifier | PASS locally and on downloaded bytes | local_static_verifier.txt; remote_static_verifier.txt |

The remote directory was created empty. Every file was downloaded separately from `raw.githubusercontent.com` at the full commit ID, with no reuse of local payload or Git objects. The download record includes each URL, HTTP status, byte count, expected/actual SHA-256, and response metadata. The static checker is the existing read-only publication checker, not a scientific calculation or simulation.

## Access and browser observations

The immutable landing page renders correctly; manuscript LaTeX, claim register, figure/media register and evidence index are accessible. Screenshot inspection of GitHub's PDF viewer showed the manuscript cover. Both original movie file pages expose Raw/View raw links. GitHub declines searchable previews of both original CSV logs because they are too large. These are preview limitations only: both movies and both logs were downloaded and matched their accepted hashes. Full per-item observations and immutable links are in [remote_access_inspection.json](remote_access_inspection.json).

- [commit](https://github.com/pzychozen/trioctagon-physics/commit/63469551eb04c17bfbedb6b8fce057c5890cbba8)
- [landing](https://github.com/pzychozen/trioctagon-physics/tree/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1)
- [pdf](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/MANUSCRIPT/volume_i.pdf)
- [pdf download](https://raw.githubusercontent.com/pzychozen/trioctagon-physics/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/MANUSCRIPT/volume_i.pdf)
- [manuscript source](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/MANUSCRIPT/volume_i.tex)
- [evidence index](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/EXTERNAL_EVIDENCE_INDEX.md)
- [evidence tree](https://github.com/pzychozen/trioctagon-physics/tree/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/evidence/SRG_REDISCOVERY)
- [claim register](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/CLAIM_EVIDENCE_MATRIX.md)
- [figure register](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/FIGURE_AND_MEDIA_REGISTER.md)
- [manifest](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/PUBLICATION_FILE_MANIFEST.json)

## Preservation and repository state

All **5,202 protected-file SHA-256 comparisons** passed, including historical sources, accepted research, prior publication closeout materials, accepted R1, canonical ledger, kernels and protected navigation files. The independent filesystem inventory found the same **32,525 files with unchanged sizes and modification timestamps** outside this execution workspace and the recorded exclusions. This broader metadata check is not described as a full-repository content-hash check.

Tracked working files and the index are clean after the commit; existing unrelated untracked work remains present. The before/after untracked listings match after excluding this execution workspace and the newly tracked publication files. Git's recursive untracked listing reported Windows filename-too-long warnings for unrelated archived working folders; the extended-path filesystem inventory covers those separately. See `git_untracked_listing_warnings.txt` and `preservation_verification.json`. No Git attributes, configuration or hooks were changed, disabled or bypassed. The exact publication paths did not produce staging warnings.

Root/SRG README additions were not applied. The accepted edition's preparation notices remain unchanged historical records. This receipt supplies the actual publication status without changing the sealed 502-file edition. No second commit stores this receipt.

## Automatic CI observation

- [Kernel distribution certification](https://github.com/pzychozen/trioctagon-physics/actions/runs/39870603081): `in_progress`, conclusion `None`, event `push` (observed 2026-10-22T23:20:16.358581+00:00).

The normal push triggered the repository's configured workflow. Codex only read its status; it did not dispatch, retry, cancel, or expand CI work. This observation is separate from the successful publication byte verification.

## Review package

This workspace contains the receipts, exact scope, index/commit/download comparisons, preservation baseline and results, execution logs, owner-order copy, GPT final acceptance archive and inspection helpers. The compact review ZIP excludes the duplicate 72.8 MB remote download tree and the older 64.7 MB accepted payload ZIP; their identities remain recorded. `REVIEW_PACKAGE_MANIFEST.json` hashes all ZIP payload members, with the ZIP identity in the adjacent `DELIVERY_RECEIPT.json`.

Publication verification is complete. No new simulation, scientific checker rerun, rebuild, research, release, force-push, visibility change or next investigation was performed. Stop for GPT and Hilmir review.
