"""Copy/hash narrowly selected existing evidence. Never import original scripts."""
from pathlib import Path
import hashlib,json,zipfile,shutil,datetime
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
R0=REPO/'SRG_REDISCOVERY/R0_SOURCE_RECOVERY'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(path,data):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert not (ROOT/'PRESERVATION_BASELINE.json').exists()
names=['srg_seed_explorer.py','deep_trajectory.csv','pass_metrics.csv','SRG_Deep_Analysis.md']
records=json.loads((R0/'external_and_selected_sources.json').read_text(encoding='utf-8'))
selected=[r for r in records if Path(r['original_path']).name in names]
assert len(selected)==4
archive_record=json.loads((R0/'march_archive_verification.json').read_text(encoding='utf-8'))
archive=Path(archive_record['original_path']);assert sha(archive)==archive_record['sha256']
protected={archive};provenance=[]
with zipfile.ZipFile(archive) as z:
    members=[{'path':i.filename,'bytes':i.file_size,'timestamp':i.date_time} for i in z.infolist()]
    for r in selected:
        original=Path(r['original_path']);copy=R0/r['package_path'];name=original.name
        assert original.stat().st_size==r['bytes'] and sha(original)==r['sha256'] and sha(copy)==r['sha256']
        content=z.read(name);assert hashlib.sha256(content).hexdigest()==r['sha256']
        out=ROOT/'originals'/name;out.parent.mkdir(exist_ok=True);out.write_bytes(content)
        protected.update([original,copy])
        provenance.append({**r,'archive_member':name,'new_copy':'originals/'+name,'archive_member_matches':True})
write('analysis/archive_members.json',members)
write('SOURCE_PROVENANCE.json',{'archive':str(archive),'archive_sha256':sha(archive),'files':provenance,'attribution':'Archive membership and bytes verified; driver/run linkage assessed separately; no original execution asserted.'})
references=['SRG_R0_REPORT.md','source_manifest.json','external_and_selected_sources.json','csv_evidence_summary.json','saved_data_checks.json','SOURCE_COVERAGE.md','SOURCE_COVERAGE.json','march_archive_verification.json']
for name in references:protected.add(R0/name)
instructions=[Path('C:/Users/Notandi/Downloads/SRG_SIMULATION_04_SEED_EXPLORER_CODEX_WORK_ORDER.md'),Path('C:/Users/Notandi/Downloads/SRG_R0_REPORT.md')]
for p in instructions:
    out=ROOT/'context'/p.name;out.parent.mkdir(exist_ok=True);shutil.copyfile(p,out);protected.add(p)
write('analysis/r0_context_identity.json',{'downloaded_report_sha256':sha(instructions[1]),'retained_r0_report_sha256':sha(R0/'SRG_R0_REPORT.md'),'identical':sha(instructions[1])==sha(R0/'SRG_R0_REPORT.md')})
for name in ['csv_evidence_summary.json','saved_data_checks.json','SOURCE_COVERAGE.json']:
    data=json.loads((R0/name).read_text(encoding='utf-8'))
    def relevant(x):return any(n in json.dumps(x,ensure_ascii=False) for n in names[:3])
    if isinstance(data,list):data=[r for r in data if relevant(r)]
    elif isinstance(data,dict):data={k:v for k,v in data.items() if relevant({k:v})}
    write('analysis/r0_selected_'+name,data)
ledger=REPO/'SRG_REDISCOVERY/SIMULATION_RECONSTRUCTION_RESEARCH/SIMULATION_STUDY_LEDGER.md';protected.add(ledger)
pub=REPO/'SRG_REDISCOVERY/PUBLICATION_WORK/V1_PUBLISH'
for name in ['PUBLICATION_RECEIPT.md','PUBLICATION_RECEIPT.json','DELIVERY_RECEIPT.json']:
    p=pub/name;protected.add(p);out=ROOT/'context/publication_receipt'/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
source=(ROOT/'originals/srg_seed_explorer.py').read_text(encoding='utf-8')
(ROOT/'analysis/srg_seed_explorer_numbered.txt').write_text(''.join(f'{i:04d}: {line}\n' for i,line in enumerate(source.splitlines(),1)),encoding='utf-8')
write('PRESERVATION_BASELINE.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Files inspected or used for this selected study; no whole-repository audit','files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(protected)]})
print(json.dumps({'originals':provenance,'archive_members':len(members),'media_members':[r['path'] for r in members if Path(r['path']).suffix.lower() in ['.png','.jpg','.jpeg','.mp4','.gif','.svg','.pdf']],'protected_files':len(protected)},indent=2))
