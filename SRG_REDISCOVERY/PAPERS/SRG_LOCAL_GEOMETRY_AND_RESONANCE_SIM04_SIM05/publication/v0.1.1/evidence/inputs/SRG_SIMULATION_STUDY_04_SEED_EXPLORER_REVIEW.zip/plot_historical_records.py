"""New visualizations of existing CSV states; no interpolation, dynamics or RNG."""
from pathlib import Path
import os,csv,json,hashlib
ROOT=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(ROOT/'.matplotlib_cache')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse.csgraph import connected_components

def table(path):
    with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def values(rows,col):return np.array([float(r[col]) for r in rows])
raw=table(ROOT/'originals/deep_trajectory.csv');S=np.array([[float(r[k]) for k in ['X','Y','Z','Resonance','VX','VY','VZ']] for r in raw]).reshape(21,50,7)
X=S[:,:,:3];R=S[:,:,3];V=S[:,:,4:]
summary=table(ROOT/'analysis/state_summary.csv');trans=table(ROOT/'analysis/transition_checks.csv');triad=table(ROOT/'analysis/final_triad_history.csv');first=table(ROOT/'analysis/first_corridor_history.csv');edges=table(ROOT/'analysis/directed_neighbors.csv')
out=ROOT/'figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,'axes.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','svg.fonttype':'none'})
blue='#245b85';orange='#c26623';green='#25806d';purple='#855099';p=np.arange(21);colors={3:blue,40:orange,38:green,23:purple,8:'#bc4a64',5:'#805e2e',43:'#5b698b'}
register=[]
def save(fig,name,title,caption,inputs):
    fig.suptitle(title,x=.06,ha='left',fontsize=17,fontweight='bold')
    fig.text(.06,.018,'NEW VISUALIZATION OF HISTORICAL DATA  |  SIM04  |  21 saved states, no new simulation',fontsize=9,color='#555555')
    fig.subplots_adjust(left=.08,right=.88 if name=='F02_position_views' else .96,bottom=.12,top=.87,wspace=.33,hspace=.42)
    for ext in ['png','svg']:fig.savefig(out/(name+'.'+ext),dpi=180)
    register.append({'id':name,'title':title,'classification':'new visualization of historical data','caption':caption,'inputs':inputs,'files':[name+'.png',name+'.svg']});plt.close(fig)

fig,axes=plt.subplots(2,2,figsize=(12,8))
ax=axes[0,0];ax.plot(p,values(summary,'Rg'),color=blue,marker='o',ms=3);ax.set(xlabel='Recorded pass',ylabel='Radius of gyration',title='A. Spatial spread decreases')
ax=axes[0,1];ax.fill_between(p,values(summary,'R_min'),values(summary,'R_max'),color=green,alpha=.15,label='min–max');ax.plot(p,values(summary,'R_mean'),color=green,label='mean');ax.set(xlabel='Recorded pass',ylabel='Resonance',title='B. Resonance values become closer');ax.legend(frameon=False)
ax=axes[1,0];ax.plot(p,values(summary,'coherence'),color=purple,marker='o',ms=3);ax.set(xlabel='Recorded pass',ylabel='1 − std(R) / (mean(|R|) + ε)',title='C. Source “coherence” is a spread statistic')
ax=axes[1,1];ax.plot(p[1:],values(summary,'kinetic_energy')[1:],color=orange,marker='o',ms=3);ax.set(xlabel='Recorded pass',ylabel='Mean squared displacement per pass',title='D. Motion generally slows; it does not stop')
save(fig,'F01_recorded_overview','Contraction and resonance smoothing over 20 recorded passes','All points are saved states; pass 0 metrics are newly calculated, while passes 1–20 reproduce the original aggregate CSV. Panel D excludes the initialization V=0 to avoid presenting its first step as spontaneous acceleration of retained momentum. No physical-energy units are implied.',['originals/deep_trajectory.csv','originals/pass_metrics.csv','analysis/state_summary.csv'])

fig,axes=plt.subplots(2,3,figsize=(13,8))
for col,step in enumerate([0,10,20]):
    for row,(a,b,ylab) in enumerate([(0,1,'Y'),(0,2,'Z')]):
        ax=axes[row,col]
        for i in range(50):ax.plot(X[:step+1,i,a],X[:step+1,i,b],color='#99a4a8',lw=.6,alpha=.5)
        sc=ax.scatter(X[step,:,a],X[step,:,b],c=R[step],cmap='viridis',vmin=0,vmax=.1,s=26,zorder=3)
        ax.set(xlim=(-5.5,5.5),ylim=(-5.5,5.5),xlabel='X',ylabel=ylab,title=f'Pass {step} · X–{ylab}');ax.set_aspect('equal')
cax=fig.add_axes([.92,.25,.015,.5]);fig.colorbar(sc,cax=cax,label='Resonance (fixed scale)')
save(fig,'F02_position_views','The same 50 points, viewed on fixed coordinate scales','Orthographic XY/XZ projections at passes 0, 10 and 20. Color uses the fixed resonance scale 0–0.1 (dark purple to yellow); gray segments connect consecutive recorded samples and do not reveal motion between passes. Projection overlap does not imply 3D coincidence. No wrapping or per-panel rescaling is used.',['originals/deep_trajectory.csv'])

fig,axes=plt.subplots(2,2,figsize=(12,8))
ax=axes[0,0]
for i in [3,40,38]:ax.plot(p,R[:,i],label=f'Glyph {i}',color=colors[i])
ax.axvline(3,color='#888',ls=':',lw=1);ax.axvline(6,color='#888',ls=':',lw=1);ax.set(xlabel='Recorded pass',ylabel='Resonance',title='A. Highest-resonance identity: 3 → 40 → 38');ax.legend(frameon=False)
ax=axes[0,1]
for col,color in zip(['d_38_23','d_38_8','d_23_8'],[green,purple,orange]):ax.plot(p,values(triad,col),label=col[2:].replace('_',' / '),color=color)
ax.set(xlabel='Recorded pass',ylabel='3D pair distance',yscale='log',title='B. The final top three approach one another');ax.legend(frameon=False,title='Glyph pair')
ax=axes[1,0];ax.plot(p,values(first,'echo_strength'),color=blue);ax.axhline(.85,color=orange,ls='--',label='observer threshold 0.85');ax.scatter([7],[values(first,'echo_strength')[7]],color=orange,zorder=4);ax.set(xlabel='Recorded pass',ylabel='Echo strength (glyphs 5 / 43)',title='C. First detected corridor appears at pass 7');ax.legend(frameon=False)
ax=axes[1,1];ax.plot(p,values(summary,'n_corridors'),color=green,marker='o',ms=3);ax.set(xlabel='Recorded pass',ylabel='Pairs with echo strength > 0.85',title='D. More pairs cross the observer threshold')
save(fig,'F03_identifiable_episodes','Stable rank, continued movement, and close pairs','Rank is an observer, not leadership or a force. Final top-three IDs 38, 23, 8 have pair distances 0.0340–0.0677 at pass 20, still distinct. The first echo pair is 5/43, not the highest-resonance glyph. Echo counts do not drive the update.',['originals/deep_trajectory.csv','analysis/final_triad_history.csv','analysis/first_corridor_history.csv','analysis/state_summary.csv'])

fig,axes=plt.subplots(2,2,figsize=(12,8))
ax=axes[0,0]
for col,label,color in [('diffusion_rms_norm','local position term',blue),('fusion_rms_norm','global fusion term',green),('position_residual_rms_norm','unresolved position residual',orange)]:ax.plot(np.arange(1,21),values(trans,col),label=label,color=color)
ax.set(xlabel='Incoming recorded state → pass',ylabel='RMS vector norm',yscale='log',title='A. Source terms evaluated at stored inputs');ax.legend(frameon=False,fontsize=9)
ax=axes[0,1];ax.plot(np.arange(1,21),values(trans,'memory_factor')-1,color=purple,label='H factor − 1');ax.plot(np.arange(1,21),values(trans,'sinusoidal_factor')-1,color=orange,label='sinusoidal factor − 1');ax.set(xlabel='Pass',ylabel='Multiplicative change',title='B. Prescribed schedules, not historical memory');ax.legend(frameon=False,fontsize=9)
ax=axes[1,0];ax.bar(p,values(summary,'new_directed_edges'),color=blue,alpha=.8);ax.set(xlabel='Graph at saved pass',ylabel='New directed edges versus previous pass',title='C. Local neighborhoods continue to change')
ax=axes[1,1];ax.step(p,values(summary,'weak_components'),where='post',color=green,marker='.',label='weak components');ax.step(p,values(summary,'strong_components'),where='post',color=purple,marker='.',label='strong components');ax.set(xlabel='Graph at saved pass',ylabel='Component count',title='D. Neighbor graph separates as spread shrinks');ax.legend(frameon=False,fontsize=9)
save(fig,'F04_terms_and_neighbors','Smoothing does not make the neighbor graph one connected group','A: algebraic terms read each stored incoming state independently; no output advances a trajectory. Residual contains the unsaved random increment and numerical/provenance uncertainty. D: newly introduced graph diagnostics; weak ignores edge direction, strong requires directed reachability. Global fusion still couples all points even when this local graph splits. Graph at pass 20 is diagnostic only; no pass-21 transition is present.',['analysis/transition_checks.csv','analysis/state_summary.csv'])

# Read-only component memberships, to make the graph observation inspectable.
components=[]
for step in [0,4,5,19,20]:
    a=np.zeros((50,50))
    for row in edges:
        if int(row['pass'])==step:a[int(row['glyph']),int(row['neighbor'])]=1
    for connection in ['weak','strong']:
        count,labels=connected_components(a,directed=True,connection=connection)
        components.append({'pass':step,'connection':connection,'count':int(count),'groups':[np.where(labels==i)[0].tolist() for i in range(count)]})
(ROOT/'analysis/graph_components.json').write_text(json.dumps(components,indent=2)+'\n',encoding='utf-8')
(ROOT/'FIGURE_REGISTER.json').write_text(json.dumps(register,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'figures':len(register),'matplotlib':matplotlib.__version__,'final_weak_groups':[r for r in components if r['pass']==20 and r['connection']=='weak']},indent=2))
