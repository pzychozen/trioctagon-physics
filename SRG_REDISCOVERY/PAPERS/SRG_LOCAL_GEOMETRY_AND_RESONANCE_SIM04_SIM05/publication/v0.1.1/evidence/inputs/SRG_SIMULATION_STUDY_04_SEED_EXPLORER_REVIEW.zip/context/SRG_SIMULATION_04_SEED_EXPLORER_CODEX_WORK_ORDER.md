# CODEX WORK ORDER — SRG_SIMULATION_STUDY_04_SEED_EXPLORER

**Prepared:** 23 October 2026  
**Author and research director:** Hilmir Frímann Halldórsson  
**Scientific lead:** GPT  
**Research engineer:** Codex  
**Status:** Prepared for Hilmir's review and forwarding. This study has not been launched in this chat.  
**Mode:** One historical program; construction, original evidence and explanation.

## 1. Purpose and selected target

Understand the original `srg_seed_explorer.py` program and the saved run represented by `deep_trajectory.csv` and `pass_metrics.csv`. Explain what the moving points carry, how their neighbors and resonance affect the next update, what the surviving records actually show, and how the program turns those records into observations.

The existing R0 report, dated 10 October 2026, identifies a complete `GlyphField` implementation and a particularly useful full-state record: 50 glyphs across passes 0–20, comprising 1,050 rows, accompanied by 20 aggregate metric rows. These are retained inventory findings to verify against the files, not new measurements made for this order. This combination of source and ordered state evidence is the reason for selecting this program.

This is a **March 2026 resonance-field model**, distinct from the three moving-center programs in Volume I. SIM04 denotes our study order. It does not assert historical precedence, direct descent from `plot_1.py`, or equivalence with fixed-grid, glyph/echo, tower, dark-field or production-kernel models.

## 2. Repository and existing evidence

Authoritative Windows repository:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`

Research root:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY`

Proposed new study directory:

`SRG_REDISCOVERY\SRG_SIMULATION_STUDY_04_SEED_EXPLORER`

Primary recovered source copy:

`SRG_REDISCOVERY\R0_SOURCE_RECOVERY\selected_sources\MARCH_19023429\srg_seed_explorer.py`

Use the existing R0 records to resolve the exact original source and data locations:

- `R0_SOURCE_RECOVERY\SRG_R0_REPORT.md`, especially §§1, 2.3, 5.2 and 5.3.
- `source_manifest.json`, `external_and_selected_sources.json`, `csv_evidence_summary.json`, `saved_data_checks.json` and the retained source coverage records in that same package, as relevant.
- The already recovered March archive members associated with `Zenodo_research/19023429/simulations.zip`.
- `deep_trajectory.csv` and `pass_metrics.csv`, resolved through those records rather than a guessed directory or similarly named later copy.

R0 points to source lines 599–674 for the saved deep-exploration driver, seed 2038 and the default initial resonance interval [0, 0.1]. Inspect the actual driver before accepting its relation to these files. Line numbers here are navigation aids from R0, not substitutes for reading the full source.

Recover only this program's directly relevant source, records and attributable visuals. Reuse the existing inventory. If a named file cannot be resolved, report the specific gap and what existing record was checked; do not restart an archive-wide search or ask Hilmir to reconstruct old parameters from memory.

## 3. Read and explain the complete construction

Read the unchanged script as text, including initialization, helper functions, update stages, observers, experiment drivers, plotting and export code. Do not import it: R0 records import-time filesystem and analysis side effects in this source collection.

Produce an ordinary-language walkthrough and an exact equation transcription in execution order. Establish:

1. **Carried state:** positions, resonance, the variable named velocity, pass count, history and random-number state. Determine which variables cause later movement and which are computed only for observation. In particular, verify R0's finding that `V` is a position difference, rather than retained momentum driving the next pass.
2. **Geometry and neighbors:** when distances and the directed nearest-neighbor graph are rebuilt; which stage uses incoming positions; what happens with coincident points or an empty neighbor set; whether each calculation is synchronous or updates rows in place.
3. **Position and resonance updates:** the separate position-diffusion and distance-weighted resonance exchanges, their ordering, and the states each reads.
4. **Time-dependent response:** how pass number enters `H`, how its normalization is sampled and recomputed, and whether any recorded history feeds this response.
5. **Fusion and compression:** which intermediate resonance weights the spatial center, how it changes motion, where the sinusoidal factor enters, and the exact signed logarithm/clipping/exponential operation and its offsets.
6. **Noise and recording:** where random increments enter, when the initial state and subsequent states are saved, and when each reported metric is measured.
7. **Observers and labels:** what “seed,” “coherence,” geometry labels and echo corridors actually calculate, and whether any such observer changes the dynamics. Track active and unused constants from the actual expressions.

Use original names while defining them through their operations. Do not infer physical units, intelligence, optimization, toroidal wrapping or a master-equation mechanism from labels. R0 reports no spatial wrapping in this program; verify that distinction explicitly.

## 4. Inspect the original records and visual evidence

Read the saved CSVs in their original order. Establish their schemas, glyph identifiers, pass labels, missing or duplicated records, finite values and completeness. Check whether the expected 50 × 21 state records and 20 metric records are present, and establish their actual alignment. Preserve pass 0 if it is the initial state.

Trace the relation between source, driver and exports using the strongest available evidence. A seed written in a driver is not proof of historical execution identity or recovery of the original software environment. State whether the relation is directly recorded, strongly attributed, ambiguous or missing.

Read-only scripts over copies of the existing records are permitted within this proposed assignment. Useful checks include saved position differences against `V`, summary metrics recomputed from the corresponding saved states, and deterministic source expressions evaluated at declared recorded inputs. These checks must not call `evolve_pass`, import the original program, generate fresh random draws, reconstruct a new trajectory or advance a simulated state.

If a transition includes an unsaved random increment, separate the deterministic contribution from the unresolved residual. Do not claim exact recurrence reproduction merely because a residual is small or looks like noise. Record the comparison method, tolerance and maximum discrepancy wherever a consistency claim is made.

Locate and inspect any original figures or recordings directly attributable to this program and run. An asset's filename alone is insufficient to establish linkage. If a matching original visual does not survive, say so. Plots made solely from saved state records are allowed and must be labeled **new visualization of historical data**; they are not a recovered original movie or a new simulation.

Select a few clear episodes from the actual records: for example changes in neighborhood, relative motion, spatial spread, or resonance distribution. Let the data determine which episodes deserve explanation. Explain what moves and changes across successive passes, using identifiable glyphs and pass numbers. Do not choose episodes to force a remembered path-inheritance or gravity story.

The short surviving record can support observations over its recorded window. It cannot by itself establish long-time convergence, a universal attractor or a conservation law.

## 5. Compare only after understanding this program

After its independent construction and evidence analysis, give one short comparison with Volume I: carried momentum versus a measured position difference; whole-group centroid response versus local neighbors and resonance-weighted fusion; asynchronous versus synchronous stages; prescribed clock response; stochastic contributions; and wrapping versus unbounded coordinates where supported by source.

Keep earlier accepted mathematics available as context. Do not reopen the tower, amplitude, geometry-response or master-equation investigations. In particular, an old proposed experiment in the R0 report is not authorization to run it now.

## 6. Review deliverable

Prepare one review ZIP in the new study directory, with:

- `START_HERE.md`: a clear explanation for Hilmir of what this original simulation does, its most useful observed behavior and the principal unresolved questions.
- `CONSTRUCTION.md`: source-linked state definitions, exact equations, execution order, observers and export construction.
- `ORIGINAL_EVIDENCE.md`: source/run attribution, saved-data chronology, useful episodes and captioned original or newly plotted historical evidence.
- `VERIFICATION_AND_LIMITS.md`: checks actually performed, numerical discrepancies, missing provenance and preservation results.
- A compact manifest, relevant unchanged source/data copies or exact references, and any read-only analysis scripts and outputs needed to inspect the findings.

Distinguish **ORIGINAL**, **ATTRIBUTED**, **OBSERVED**, **DERIVED**, **HYPOTHESIS** and **MISSING/AMBIGUOUS**. No new **REPRODUCED** run is part of this assignment. Do not label the study accepted or published before GPT/Hilmir review. Include a proposed short ledger entry in the package; leave the existing cumulative ledger unchanged during this assignment.

Use Windows Command Prompt and the established `torment` environment for any authorized record analysis. Do not install or update packages merely to make an old launcher run.

## 7. Boundaries and stopping point

All writes are confined to the new study directory. Preserve historical source, media, logs, accepted papers and unrelated work. No new simulation, parameter sweep, original application launch, kernel/UI integration, staging, commit, push or publication is included.

If the proposed directory already contains work, inspect and report its status before choosing a new output location; do not overwrite an existing study silently. Use scoped preservation checks for the files actually inspected, without re-auditing the whole repository.

Stop after returning the construction-and-evidence package for discussion. If missing chronology would justify a new replay, describe a specific proposed replay and its purpose, but do not run it. Do not select or start SIM05.

**Working cadence: Observe → Understand → Discuss → Preserve → Continue.**

## Publication checkpoint carried forward

Volume I v0.1.1 remains scientifically accepted. A read-only check on 23 October 2026 confirms `main` at `63469551eb04c17bfbedb6b8fce057c5890cbba8`, with sole parent `170e638ecc0438f911c4ceb8091ffb1b574652fe`, and exactly 502 added files confined to its publication directory. The published manifest's 501 listed paths and byte sizes agree with the Git tree; the manifest itself is the additional file.

This check does **not** establish that all 502 remote byte streams match the independently accepted payload. Codex's final post-push receipt remains outstanding in the material reviewed. The frozen PUB-01 preparation records are not that receipt. Keep this administrative qualification separate from the accepted scientific chapters and from SIM04.

Primary remote checkpoints:

- [Volume I commit](https://github.com/pzychozen/trioctagon-physics/commit/63469551eb04c17bfbedb6b8fce057c5890cbba8)
- [Immutable publication tree](https://api.github.com/repos/pzychozen/trioctagon-physics/git/trees/cc15a42d348472117c51b6bfa5da81c52482f0bb?recursive=1)
- [Immutable publication manifest](https://github.com/pzychozen/trioctagon-physics/blob/63469551eb04c17bfbedb6b8fce057c5890cbba8/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/PUBLICATION_FILE_MANIFEST.json)

Selection basis: existing `SRG_R0_REPORT.md` §§1, 2.3 and 5.2–5.3; the two supplied 23 October handoffs govern current scope and supersede R0's earlier proposed next experiment.
