"""Independent review of supplied historical SIM04 CSV states.

No supplied Python module is imported or executed. Every formula evaluation
uses one separately stored incoming state; no computed state is propagated,
and no random values are generated. All output is a new analysis of historical
data, not a simulation or recovery of the original random-number stream.
"""
from pathlib import Path
import csv
import hashlib
import json
import platform
import numpy as np
import scipy
from scipy.spatial.distance import pdist, squareform

ROOT = Path(__file__).resolve().parents[1] / 'input'
OUT = Path(__file__).resolve().parent


def read_csv(path):
    with path.open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def components(adjacency, strong=False):
    """Small independent reachability implementation, not a library clusterer."""
    def reach(seed, graph):
        seen, todo = {seed}, [seed]
        while todo:
            i = todo.pop()
            for j in np.flatnonzero(graph[i]):
                j = int(j)
                if j not in seen:
                    seen.add(j)
                    todo.append(j)
        return seen
    remaining = set(range(len(adjacency)))
    groups = []
    while remaining:
        i = min(remaining)
        group = (reach(i, adjacency) & reach(i, adjacency.T)) if strong else reach(i, adjacency | adjacency.T)
        groups.append(sorted(group))
        remaining -= group
    return groups


def h_function(t):
    return 2*np.exp(-.5*t)*np.cos(t) + np.exp(-.3*t)*np.sin(t) + 1.5*np.exp(-.7*t) + np.exp(-.4*t)


rows = read_csv(ROOT / 'originals/deep_trajectory.csv')
metrics = read_csv(ROOT / 'originals/pass_metrics.csv')
keys = [(int(r['Pass']), int(r['Glyph_ID'])) for r in rows]
expected = [(p, i) for p in range(21) for i in range(50)]
assert keys == expected
assert [int(r['pass']) for r in metrics] == list(range(1, 21))
states = np.array([[float(row[c]) for c in ['X','Y','Z','Resonance','VX','VY','VZ']] for row in rows]).reshape(21,50,7)
assert np.isfinite(states).all()
positions = states[:,:,:3]
resonance = states[:,:,3]
velocity = states[:,:,4:]
state_diagnostics, adjacencies, weights, corridor_records = [], [], [], []
metric_errors = {k: [] for k in metrics[0] if k != 'pass'}

for p in range(21):
    x, r, v = positions[p], resonance[p], velocity[p]
    d = squareform(pdist(x))
    nn = np.argsort(d, axis=1)[:,1:6]
    adj = np.zeros((50,50), dtype=bool)
    adj[np.arange(50)[:,None], nn] = True
    w = np.zeros((50,50))
    w[adj] = 1/(d[adj] + 1e-8)
    w /= w.sum(axis=1, keepdims=True)
    adjacencies.append(adj)
    weights.append(w)
    echo_score = (1-np.abs(r[:,None]-r[None,:])/(r.max()+1e-8))*np.exp(-d/3)
    pairs = np.argwhere(np.triu(echo_score > .85, 1))
    for i,j in pairs:
        corridor_records.append({'pass':p,'i':int(i),'j':int(j),'distance':float(d[i,j]),'score':float(echo_score[i,j])})
    top = int(np.argmax(np.abs(r)))
    rg = float(np.sqrt(np.mean(np.sum((x-x.mean(axis=0))**2, axis=1))))
    values = {
        'R_mean':float(np.abs(r).mean()), 'R_max':float(np.abs(r).max()),
        'R_std':float(np.std(r)), 'Rg':rg,
        'kinetic_energy':float(np.mean(np.sum(v*v,axis=1))),
        'n_corridors':len(pairs),
        'coherence':float(1-np.std(r)/(np.abs(r).mean()+1e-8)) if np.std(r)>=1e-12 else 1.,
        'top_seed_id':top, 'top_seed_R':float(r[top]),
        'top_seed_x':float(x[top,0]),'top_seed_y':float(x[top,1]),'top_seed_z':float(x[top,2])
    }
    if p:
        for k,value in values.items():
            metric_errors[k].append(abs(value-float(metrics[p-1][k])))
    weak = components(adj)
    strong = components(adj, strong=True)
    sorted_d = np.sort(d,axis=1)
    state_diagnostics.append({
        'pass':p, **values, 'R_min':float(r.min()),'R_range':float(np.ptp(r)),
        'weak_groups':weak, 'strong_groups':strong,
        'weak_count':len(weak),'strong_count':len(strong),
        'pair_distance_min':float(pdist(x).min()), 'diameter':float(d.max()),
        'neighbor_cutoff_gap_min':float((sorted_d[:,6]-sorted_d[:,5]).min()),
        'new_directed_edges':int(np.count_nonzero(adj & ~adjacencies[p-1])) if p else 0,
        'changed_neighbor_rows':int(np.any(adj != adjacencies[p-1],axis=1).sum()) if p else 0,
        'active_geometry_count':int((np.abs(r)>=np.percentile(np.abs(r),75)).sum()),
    })

transitions, residuals, resonance_errors = [], [], []
gain_product = 1.
affine_offset = 0.
normalized_states = [resonance[0].copy()]
for p in range(1,21):
    # All inputs are original saved data, never an earlier computed endpoint.
    x,r = positions[p-1], resonance[p-1]
    adj,w = adjacencies[p-1],weights[p-1]
    lap = adj.astype(float)@x/5-x
    local = .05*lap+.15*np.tanh(lap)
    y = x+local
    averaged = w@r
    mixed = .85*r+.15*averaged
    hmax = float(np.max(np.abs(h_function(np.linspace(0,10*p,20000)))))+1e-12
    hf = 1+.05*h_function(float(p))/hmax
    intermediate = hf*mixed
    center_weights = np.abs(intermediate)+1e-8
    center = np.sum(y*center_weights[:,None],axis=0)/center_weights.sum()
    fusion = .03*intermediate[:,None]*(center-y)
    residual = positions[p]-(y+fusion)
    residuals.append(residual)
    bf = 1-.001*np.sin(2*np.pi*.244*p)
    z = bf*intermediate
    logmag = np.log(np.abs(z)+1e-9)
    predicted_r = np.sign(z)*np.exp(np.clip(logmag,-9,9))
    error = resonance[p]-predicted_r
    resonance_errors.append(error)
    common = float(hf*bf)
    gain_product *= common
    affine_offset = common*affine_offset+1e-9
    normalized = (resonance[p]-affine_offset)/gain_product
    normalized_states.append(normalized)
    mean_term_mixing = common*(mixed.mean()-r.mean())
    mean_term_common = (common-1)*r.mean()
    transitions.append({
        'to_pass':p,'incoming_weak_components':state_diagnostics[p-1]['weak_count'],
        'resonance_max_abs_error':float(np.max(np.abs(error))),
        'velocity_max_abs_error':float(np.max(np.abs(velocity[p]-(positions[p]-positions[p-1])))),
        'hmax':hmax,'memory_factor':float(hf),'breathing_factor':float(bf),'common_factor':common,
        'gain_product':gain_product,'affine_offset':affine_offset,
        'clip_low_count':int(np.count_nonzero(logmag<-9)),'clip_high_count':int(np.count_nonzero(logmag>9)),
        'preclip_min':float(z.min()),'preclip_max':float(z.max()),
        'local_rms_vector':float(np.sqrt(np.mean(np.sum(local*local,axis=1)))),
        'fusion_rms_vector':float(np.sqrt(np.mean(np.sum(fusion*fusion,axis=1)))),
        'residual_rms_vector':float(np.sqrt(np.mean(np.sum(residual*residual,axis=1)))),
        'mean_change_from_mixing':float(mean_term_mixing),'mean_change_from_common_factor':float(mean_term_common),
        'mean_change_from_rpco_offset':1e-9,
        'mean_change_decomposition_error':float(resonance[p].mean()-r.mean()-mean_term_mixing-mean_term_common-1e-9),
        'normalized_min':float(normalized.min()),'normalized_max':float(normalized.max()),
        'normalized_range':float(np.ptp(normalized)),
        'normalized_exchange_max_error':float(np.max(np.abs(normalized-(.85*np.eye(50)+.15*w)@normalized_states[p-1]))),
    })

# Final weak-group membership is held fixed only as an analysis partition.
final_groups = state_diagnostics[-1]['weak_groups']
final_group_stats = []
partition_variance = []
for p in range(21):
    r = resonance[p]
    mean = r.mean()
    within = sum(len(g)*float(np.var(r[g])) for g in final_groups)/50
    between = sum(len(g)*(float(r[g].mean())-mean)**2 for g in final_groups)/50
    partition_variance.append({'pass':p,'within':within,'between':between,'total':float(np.var(r)),
        'between_fraction':between/float(np.var(r)),
        'fixed_final_group_means':[float(r[g].mean()) for g in final_groups]})
for group in final_groups:
    r, x = resonance[-1,group], positions[-1,group]
    final_group_stats.append({'ids':group,'size':len(group),'R_mean':float(r.mean()),'R_std':float(np.std(r)),
       'R_min':float(r.min()),'R_max':float(r.max()),
       'centroid':x.mean(axis=0).tolist(),'diameter':float(pdist(x).max()),
       'radius_gyration':float(np.sqrt(np.mean(np.sum((x-x.mean(axis=0))**2,axis=1))))})

second_groups = state_diagnostics[5]['weak_groups']
stable_split_5_to_19 = all(d['weak_groups']==second_groups for d in state_diagnostics[5:20])
top3 = np.argsort(-resonance[-1])[:3].tolist()
top3_d = {'%s_%s'%(i,j):float(np.linalg.norm(positions[-1,i]-positions[-1,j])) for ai,i in enumerate(top3) for j in top3[ai+1:]}
leader_motion = {'endpoint_distance_6_to_20':float(np.linalg.norm(positions[20,38]-positions[6,38])),
                 'saved_step_path_length_6_to_20':float(np.linalg.norm(np.diff(positions[6:21,38],axis=0),axis=1).sum())}
six_group = next(group for group in final_groups if len(group)==6)
six_episode = {}
for p in (5,20):
    x, r = positions[p,six_group], resonance[p,six_group]
    six_episode[str(p)] = {
      'members_are_actual_weak_component':six_group in state_diagnostics[p]['weak_groups'],
      'R_mean':float(r.mean()),'R_std':float(r.std()),'R_range':float(np.ptp(r)),
      'diameter':float(pdist(x).max()),
      'Rg':float(np.sqrt(np.mean(np.sum((x-x.mean(axis=0))**2,axis=1)))),
      'directed_internal_edge_count':int(adjacencies[p][np.ix_(six_group,six_group)].sum()),
      'directed_external_edge_count':int(adjacencies[p][six_group].sum()-adjacencies[p][np.ix_(six_group,six_group)].sum()),
    }
all_resid = np.array(residuals).ravel()
all_rerr = np.array(resonance_errors)
checks = {
 'method':'Independent matrix/reachability calculations on each saved input; no original import, state propagation, RNG or simulation.',
 'runtime':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
 'source_sha256':hashlib.sha256((ROOT/'originals/srg_seed_explorer.py').read_bytes()).hexdigest(),
 'trajectory_sha256':hashlib.sha256((ROOT/'originals/deep_trajectory.csv').read_bytes()).hexdigest(),
 'metric_sha256':hashlib.sha256((ROOT/'originals/pass_metrics.csv').read_bytes()).hexdigest(),
 'state_rows':len(rows),'metric_rows':len(metrics),'state_schema_exact':list(rows[0])==['Pass','Glyph_ID','X','Y','Z','Resonance','VX','VY','VZ'],
 'key_order_exact':keys==expected,'finite_states':bool(np.isfinite(states).all()),'initial_velocity_zero':bool(np.all(velocity[0]==0)),
 'metric_value_count':sum(len(v) for v in metric_errors.values()),
 'metric_max_abs_errors':{k:float(max(v)) for k,v in metric_errors.items()},
 'velocity_component_count':int(velocity[1:].size),
 'velocity_max_abs_error':float(np.max(np.abs(velocity[1:]-np.diff(positions,axis=0)))),
 'resonance_count':int(all_rerr.size),'resonance_max_abs_error':float(np.abs(all_rerr).max()),
 'total_clip_activations':sum(t['clip_low_count']+t['clip_high_count'] for t in transitions),
 'residual_component_count':len(all_resid),'residual_mean':float(all_resid.mean()),'residual_std':float(all_resid.std()),'residual_rms':float(np.sqrt(np.mean(all_resid**2))),'residual_max_abs':float(np.abs(all_resid).max()),
 'Rg_strict_decrease':bool(np.all(np.diff([s['Rg'] for s in state_diagnostics])<0)),
 'Rstd_strict_decrease':bool(np.all(np.diff([s['R_std'] for s in state_diagnostics])<0)),
 'Rcoherence_strict_increase':bool(np.all(np.diff([s['coherence'] for s in state_diagnostics])>0)),
 'Rmax_strict_decrease':bool(np.all(np.diff([s['R_max'] for s in state_diagnostics])<0)),
 'Rmean_relative_increase':float(resonance[-1].mean()/resonance[0].mean()-1),
 'Rg_fraction_reduction':1-state_diagnostics[-1]['Rg']/state_diagnostics[0]['Rg'],
 'Rstd_fraction_reduction':1-float(resonance[-1].std()/resonance[0].std()),
 'Rvariance_fraction_reduction':1-float(resonance[-1].var()/resonance[0].var()),
 'local_graph_sequence':[(s['pass'],s['weak_count'],s['strong_count']) for s in state_diagnostics],
 'two_weak_partition_5_to_19_unchanged':stable_split_5_to_19,
 'two_weak_partition_at_5':second_groups,
 'final_group_stats':final_group_stats,
 'top_seed_sequence':[s['top_seed_id'] for s in state_diagnostics],
 'leader_motion':leader_motion,'first_corridor':corridor_records[0],
 'final_top3':top3,'final_top3_pair_distances':top3_d,
 'final_top3_weak_group_size':next(len(g) for g in final_groups if set(top3).issubset(g)),
 'final_top3_strong_group_size':next(len(g) for g in state_diagnostics[-1]['strong_groups'] if set(top3).issubset(g)),
 'six_component_episode':six_episode,
 'neighbor_cutoff_min_gap':min(s['neighbor_cutoff_gap_min'] for s in state_diagnostics),
 'minimum_pair_distance':min(s['pair_distance_min'] for s in state_diagnostics),
 'normalized_range_fraction_reduction':1-np.ptp(normalized_states[-1])/np.ptp(normalized_states[0]),
 'normalized_range_nonincreasing':bool(np.all(np.diff(np.ptp(normalized_states,axis=1))<=1e-15)),
 'normalized_min_nondecreasing':bool(np.all(np.diff(np.min(normalized_states,axis=1))>=-1e-15)),
 'normalized_max_nonincreasing':bool(np.all(np.diff(np.max(normalized_states,axis=1))<=1e-15)),
 'total_mean_change_from_mixing':sum(t['mean_change_from_mixing'] for t in transitions),
 'total_mean_change_from_common_factor':sum(t['mean_change_from_common_factor'] for t in transitions),
 'total_mean_change_from_rpco_offset':sum(t['mean_change_from_rpco_offset'] for t in transitions),
 'first_and_last':{'initial':state_diagnostics[0],'final':state_diagnostics[-1]},
 'final_partition_variance':partition_variance[-1],
 'warning':'No Gaussian-distribution or historical RNG-identity claim. Final pass-20 graph was not consumed by a saved pass-21 update. Fixed final partitions at earlier passes are retrospective diagnostics, not original components.',
}
OUT.mkdir(parents=True,exist_ok=True)
for filename,obj in [('independent_checks.json',checks),('state_diagnostics.json',state_diagnostics),('transition_diagnostics.json',transitions),('fixed_final_partition_variance.json',partition_variance)]:
    (OUT/filename).write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps(checks,indent=2))
