# Data and script map

No script in the offline-analysis or verification path constructs a field or calls `evolve_pass`. `run_bounded.py` is the only new file with a state-advance call site, and its delivered budget is exhausted.

| Artifact | Shape / interpretation |
|---|---|
| replay/{reference,captured}/states_and_rng.npz | X,V:201×50×3 float64; R,D:201×50 float64; pass:201 integers,0–200 |
| rng_keys / rng_pos / rng_has_gauss / rng_cached_gaussian in each NPZ | Complete MT19937 NumPy legacy `get_state` fields at201 boundaries; algorithm name in EXECUTION.json; keys201×624 uint32 |
| rng_before_* and rng_after_* | Explicit200 pre/post-call checkpoints; verified equal to adjacent boundary states, including cached Gaussian float bits |
| replay/captured/glyph_states.csv | 10,050 rows, pass-major then ID0–49; pass,glyph_id,X,Y,Z,R,D,VX,VY,VZ; Python float text round-trips to exact stored binary values |
| metrics.json / metrics.csv | 200 original-source metric dictionaries/rows; JSON byte equality used between executions |
| analysis/intermediate_terms.npz | Transition index0 means incoming pass0→output pass1; scalar-field arrays200×50, spatial arrays200×50×3, center200×3; boolean clip/sign arrays |
| analysis/graph_arrays.npz | neighbors201×50×5 and weak_labels201×50, computed on saved boundary positions; graph at p drives p+1 |
| analysis/field_geometry.csv | All201 unweighted centered covariance/Rg/diameter and field summaries |
| analysis/component_geometry.csv | Actual weak components at each boundary, IDs, sizes, field means/spreads and spatial geometry |
| analysis/selected_groups.json | Fixed final component memberships, selection rule names, and all passes at which each set is an actual component |
| analysis/selected_group_geometry.csv | Geometry for those fixed memberships at every boundary; retrospective status explicit |
| analysis/stage_summary.csv, stage_windows.csv | Per-pass and declared-window RMS; scalar RMS averages50 components, spatial RMS averages150 coordinates |
| analysis/squared_amplitude_stages.csv | Ordered sums of squares before/after local mixing, cross term, H, sine (R only), RPCO; path budget, no alternate trajectories |
| analysis/clipping_events.csv | All active clips with pass, glyph, field, boundary, pre/post values |
| analysis/historical_replay_per_pass.csv | Every pass/column comparison, exact and declared-near flags; includes pass column |
| analysis/historical_replay_columns.csv | Counts/max errors per column |
| analysis/offline_metric_errors.csv | Independently recomputed stage-correct metric minus recorded metric |
| analysis/leader_intervals.csv | Every constant-argmax interval, with fixed-ID path length and endpoint displacement; one-state intervals have zero within-interval length |
| analysis/SIM04_six_geometry.csv | 16 fixed six-point historical states, covariance divisor6, continuous geometry |
| analysis/SIM04_six_normalized_pairs.csv | 16×15 pairs, fixed glyph IDs, distance and distance/Rg |
| analysis/*checks.json | Scalar summaries, declared tolerances and finite conclusions used by the review documents |

Some derived CSVs use the column `pass_` to avoid Python's reserved keyword. It is the same integer native pass label, without renumbering. Scientific values use float64; JSON finite values and readable CSVs preserve sufficient digits. NPZ is the exact binary authority.

`prepare.py` extracts the unchanged core from original source text and records provenance. `complete_context.py` copies the specifically consulted prior reports. `analyze_saved.py` computes conditional stages and geometry. `detail_and_figures.py` prepares the additional tables and all seven static figure pairs. `verify_package.py` reads and verifies the package without writes. `finalize_package.py` creates scoped preservation and ZIP receipts only. The complete command/environment record is in VERIFICATION_AND_LIMITS.md and ENVIRONMENT.json.

Only the root manifest describes this new package. Contextual manifests and receipts describe their unchanged earlier bundles, sometimes including referenced files intentionally not recopied here. Old contextual links retain their original meaning. The evidence needed for the seven new review documents is directly included and separately indexed.
