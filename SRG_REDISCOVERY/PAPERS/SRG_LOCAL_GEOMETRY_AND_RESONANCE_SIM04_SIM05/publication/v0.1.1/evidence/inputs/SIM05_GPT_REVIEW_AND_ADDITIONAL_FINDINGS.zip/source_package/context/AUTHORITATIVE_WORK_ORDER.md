# CODEX WORK ORDER — SIM05: Infinity, with SIM04 geometry completion

**Date:** 23 October 2026  
**Author and research director:** Hilmir Frímann Halldórsson / pzychozen  
**Scientific lead:** GPT  
**Research engineer:** Codex  
**Status:** **AUTHORIZED — ready for Codex execution within the bounds below.**  
**Purpose:** Reconstruct the original SRG programs, understand their actual mechanisms and geometry, and prepare a coherent research manuscript.

Hilmir has authorized GPT to choose the next original simulations, direct bounded refinement and mathematical analysis with Codex, and decide when the reconstruction is sufficient for a paper. He does not need to select the next model or answer routine implementation questions. GPT selects **`srg_infinity.py` / `GlyphFieldInfinity`** as SIM05. This order is the next assignment after the accepted SIM04 review; earlier SIM04 instructions to stop before SIM05 applied to that completed assignment.

## 1. Decision and scope

Complete one new source study, plus two small companions:

1. **SIM05 Infinity:** recover the exact construction, inspect its historical aggregate record and accompanying account, and produce one faithful 200-pass replay with complete state capture and a reference equivalence check.
2. **SIM04 geometry addendum:** use its existing historical coordinates to explain the six-point group's three-dimensional shape separately from its contraction and graph connectivity. No SIM04 rerun.
3. **Source-family map:** explain how the studied programs relate and how they should be organized in papers. This is a compact synthesis of existing evidence, not a new archive-wide investigation.

The new simulation budget is **one selected configuration, executed at most twice, 200 passes per execution: 400 `evolve_pass` calls total**. The second execution is for reference/capture equivalence, not another scientific trial. Every advance used for debugging, smoke checks or validation counts toward that cap. No additional seeds, extensions, parameter sweeps or ablations are authorized by this order.

All writes belong inside the new study directory. Original source and data, accepted studies and publications, the cumulative ledger, kernels and unrelated work remain preserved. This is a research reconstruction, with no live integration, Git writes or publication step.

## 2. Why Infinity is next

SIM04 established the baseline March moving-resonance construction: positions, one real amplitude per point, rebuilt local neighbors, local averaging, scheduled H modulation, one global fusion center and positional noise. Its source stores `gamma_srg=.0870` without using it in the update.

Infinity adds a second **real** amplitude array, named `dark_resonance`, and an explicit cross-field term with the literal coefficient **`.08699`**. This is a particularly useful next question: **where does the SRG coupling actually enter the executable construction, and what does it do at each update?** Its value is an imposed source coefficient, not an independently measured or emergently estimated constant.

This is a demonstrated relationship between constructions. It is not proof of historical descent, equivalence of trajectories, or physical identification of the second field with dark matter. Study numbers are review order.

## 3. Authoritative location and input identities

Repository:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`

Research root:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY`

New output directory:

`SRG_REDISCOVERY\SRG_SIMULATION_STUDY_05_INFINITY`

Primary recovered inputs:

`SRG_REDISCOVERY\R0_SOURCE_RECOVERY\selected_sources\MARCH_19023429\`

| File | Bytes | SHA-256 of the reviewed copy |
| --- | ---: | --- |
| `srg_infinity.py` | 33,529 | `742e40f1b4326f3ea5c8c88bd59aec7ee5a2bb942755a0fbc1861ce7c5eddf9d` |
| `srg_infinity_asymptotic.csv` | 70,327 | `116159914e9b1ee844d4e2992af3859bb6cf0eb1cf6472d09265cd2ae1bc6ed7` |
| `SRG_Infinity_Seeds.md` | 7,040 | `d105b46d734d1adb7babb65d469340862cdc07ff0abb172a3126aec153c6845d` |

GPT read these actual files while preparing this order. They were extracted from the retained `SRG_R0_GPT_REVIEW.zip`. Resolve the authoritative original March archive members through the existing R0 manifest, `external_and_selected_sources.json` and archive verification records. Reuse the recovered copies; do not launch a new broad recovery search.

Also consult:

- R0 report §§1, 2.3–2.5, 4.1 and 5.2, using the actual source to settle details.
- The accepted SIM04 package and GPT review provided in this handoff.
- The accepted Volume I mechanism map and publication receipt as historical context.
- Existing accepted tower/geometry/amplitude results only where they already resolve a source or mathematical question.

The historical Infinity CSV contains **200 aggregate rows, passes 1–200, with 21 columns including the pass label**. It includes the leading point's coordinates but not the complete arrays of all positions and both fields. Do not infer the full historical 3D geometry or per-point transitions from these aggregates.

If the output directory already exists, inspect its status. Reuse an incomplete matching assignment only after recording what is already there; otherwise choose a clearly named sibling revision directory and preserve prior contents. Report a source-identity mismatch rather than silently substituting another version.

## 4. Read the complete source and reconstruct the update

Read the entire original as text, including all experiments and observers. **Do not import or launch the original script.** It creates an absolute `/sessions/...` output directory at import time, and its main block runs several additional experiments outside this assignment.

Useful verified source locations are H at lines 43–47, RPCO at 49–53, H_MAX at 55, `GlyphFieldInfinity` at 61–275, `evolve_pass` at 162–205, metrics at 207–268 and the selected driver at 282–349. Treat these as navigation aids; cite the actual copied source.

Produce a readable construction account and exact equations in execution order. Establish the state, which variables drive subsequent updates, and the distinction between causal state, schedules and observers. Cover:

1. Initialization of positions, R, D, V, pass counter and the global NumPy RNG. D begins as an independent uniform draw multiplied by 0.01; it is not a complex or phase variable.
2. Rebuilt directed five-neighbor graph from incoming coordinates, tie/self-selection behavior and synchronous local movement.
3. Inverse-distance coupling of both real fields, including the early skip when a row has no neighbors.
4. Separate H schedules for R and D; the once-sampled H_MAX; the two different uses of `.244` in sine arguments.
5. The global fusion center and the resonance stage it reads. Determine exactly where D can affect positions through its effect on R.
6. The R-only vesica multiplier, signed RPCO on both fields, decaying positional noise and displacement-only V.
7. All metrics and their timing. In particular, curvature uses the new positions with the old adjacency; echo scores use old distances with updated amplitudes. Preserve these conventions when reproducing historical metrics.

The expected cross-field structure to verify is

`Q_i = R_i + .15 (weighted_neighbor_R_i - R_i) + .01 c_p D_i`,

`E_i = D_i + .075 (weighted_neighbor_D_i - D_i) + .01 c_p R_i`,

where `c_p = .08699 sin(.244 p + pi/2)` and all right-hand-side amplitudes are incoming values. Explain the distinct units of phase increments in `.244 p` versus `2 pi .244 p`. A shifted, damped H function does not by itself establish phase orthogonality of an evolving complex field.

The source's `dark_energy` and `matter_energy` are sums of squared real amplitudes, `sum(D_i^2)` and `sum(R_i^2)`. Its per-glyph GRF is `1/(1+speed)` and its reported mean GRF averages those reciprocals. Define these quantities operationally before discussing their names.

## 5. Historical evidence and claim audit

Read the historical CSV in its saved order and inspect its schema, completeness, pass sequence and finite values. Check every algebraic identity available from its columns, including the ratio of the two sums of squares, the coherence expression and the relation between the maximum and the leading amplitude. Account for floating-point precision and definitions using absolute values.

Compare the source, CSV and `SRG_Infinity_Seeds.md` claim by claim. Use a compact evidence table rather than reproducing its narrative as established fact. In particular:

- Distinguish the endpoint maximum **0.176329...** from the endpoint mean **0.151203...** and nonzero standard deviation **0.0204419...**. Determine exactly what the aggregate record establishes about uniformity.
- Separate small changes in an observable over the last ten passes from an exact fixed point, infinite-time limit or stationary coordinates.
- Distinguish observer-selected seed candidates, a close subset, a local graph component and the whole field.
- Trace claims about golden ratios, polyhedral signatures, radial profiles, self-sustaining behavior and dark-field suppression to the particular experiment and evidence that could support them.
- Explain whether surviving figures or printed outputs actually belong to the selected run. Historical notes alone are not raw numerical evidence.

Other experiment functions are **source-only review context**. Do not execute memory-death, golden-structure, zeta-tower, anatomy or broader drivers. Static issues worth checking include the eigengeometry observer's multiplication of coordinates by amplitudes before forming its inertia-like tensor; broad angle-matching windows; and the time at which `dark_at_50` is actually copied inside `experiment_memory_death`. For its principal-moment shape labels, check the inequality `I_max <= I_other1 + I_other2` before accepting the source's ratio branches. These checks clarify original claims without expanding the run budget or silently correcting the historical code.

A missing raw history is an explicit evidence limit. Preserve historical claims as historical claims, including ones contradicted by their own retained numerical records.

## 6. Authorized faithful replay and exact budget

### Configuration

Use the selected original `experiment_asymptotic` configuration, verified against source lines 287–288:

- `GlyphFieldInfinity(50, R_range=(0, 0.3), spatial_range=(-5, 5), seed=2038)`.
- Exactly **200 passes**; record the initialized state as pass 0.
- All source defaults and all update terms retained.
- No changes to coupling, noise, H, compression, geometry or observer thresholds.

This is a **new, source-faithful replay in the recorded current environment**, not recovery of the lost full historical trajectory. It is authorized because complete per-glyph historical states are absent and needed to understand the construction and 3D behavior.

### Isolated executable core

Copy only the required unchanged definitions into an isolated module inside the new study directory: H, RPCO, the exact H_MAX assignment and `GlyphFieldInfinity`, with the imports they require. Preserve the original code expressions and statement order. Record original line ranges, source hashes and a mechanical slice/AST comparison; do not rewrite the update into a new vectorized algorithm. Document any EOL normalization of the executable copy while keeping the original bytes untouched.

Exclude the original output-directory setup, main block and experimental drivers. Implement a small external runner for the verified selected constructor and pass count. Do not install packages or run the full historical launcher to obtain its output.

### Reference and capture

Run no more than these two sequential executions in an isolated process/environment:

1. **Reference:** unchanged audited core, capturing boundary states externally without changing the numerical body.
2. **Captured replay:** identical initialization and RNG state, with external recording sufficient for the deliverables.

Compare the initial state and every pass boundary for X, R, D, V, pass count, source metric outputs and complete NumPy RNG state. Require bitwise equality between these two executions in the same environment. Copy arrays before later mutation; preserve full precision in the machine-readable record. Metadata timestamps or filenames are excluded from numerical equality.

All debug/smoke advances count toward the **400-call total cap**. Do syntax, source and observer-static checks before spending that budget. If the extraction or equality gate fails, report the first divergence and deliver unaffected source/historical analysis. Do not tune coefficients, change seeds or keep launching attempts to obtain a match.

### Required capture

Retain 201 states × 50 stable row identities = **10,050 per-glyph records** for the captured replay, containing pass, glyph ID, XYZ, R, D and V. Preserve an exact array format as well as readable tables, configuration and dependency versions, source/excerpt identity, complete RNG state after initialization and before/after every pass, and all 200 source metric rows. Preserve reference states or lossless per-state comparison evidence sufficient to inspect a failure.

Recording must not consume draws from the simulator's RNG or interleave another field's evolution. If actual noise draws are captured, use a transparent observer that returns the unchanged draw and verify sequence/state equality. Otherwise retain RNG checkpoints and label offline position residuals as residuals; do not relabel them as directly observed draw arrays.

Compare the replay metrics with all matching historical columns. Report exact/near agreement and discrepancies per column and pass. Agreement strengthens attribution; it does not independently recover the historical software environment or original random-stream provenance. A mismatch is a result to explain and preserve, not permission to fit the old table.

## 7. Replay analysis: explain the mechanism and 3D motion

Use the captured boundary states as the fixed inputs to **offline** analysis. Do not advance new states during this stage.

Recompute intermediate terms from each saved incoming state: local spatial increment, local R and D exchanges, cross-field increments, separate H effects, R-only sine effect, pre/post RPCO values, fusion increment and position residual. Record sign changes and lower/upper clipping activations separately for R and D. Compare conditional next-field values and position decomposition with saved outputs using declared tolerances and maximum discrepancies.

The main questions are:

1. How large are the cross-field increments compared with local mixing and scheduled modulation, and how do their signs change?
2. Is the second field merely small, identically zero, locally structured or changing sign in this particular replay? Keep squared-sum ratios distinct from per-glyph amplitude ratios.
3. Which operations continue when H becomes small? Distinguish reduced scheduled contribution from absence of all forcing, clipping offsets or noise.
4. How do local components and spatial groups evolve, and how does global fusion continue to connect them?
5. What does a stable highest rank mean when positions and both fields are inspected directly?

Describe observed finite behavior and source-derived identities. A long-lived appearance over 200 passes is not an infinite-time theorem. No gamma-zero experiment, removal of H, alternative compression channel, longer run or seed search belongs in this order.

For 3D evidence, use equal axis scaling, fixed point identities and documented color/selection conventions. Provide whole-field views at representative saved passes such as 0, 20, 100 and 200, with close views of at most two informative groups selected by a stated rule. Show the local graph only where it helps explain a specific event; avoid an unreadable full edge web. Explain whether a selected set is an actual component or simply a ranked subset.

Use continuous, rotation-invariant quantities for geometric description: centered covariance eigenvalues/fractions, radius of gyration and pair distances. State which centroid and weighting are used. A surface or named polyhedron must not be inferred from a point count, an angle histogram or three unequal principal values. A plotted fusion center must use its actual intermediate-stage definition, not a weighted center of an arbitrary saved endpoint.

Static figures are the required paper evidence. One self-contained rotatable viewer or a short discrete-state animation is optional if already supported without installation; it must show only saved states, preserve equal spatial scaling, and clearly identify replay evidence. Do not build a new website, UI system or interpolated physical trajectory.

## 8. Small SIM04 3D addendum — historical data only

Write this addendum under the **new** study directory, keeping the accepted SIM04 package unchanged. Use its existing `deep_trajectory.csv` and retained graph checks; do not rerun SIM04.

Question: **Does the compact six-point group simply shrink, or does its relative three-dimensional shape also change?**

Primary set: IDs **10, 15, 27, 30, 33, 47**, saved passes **5–20**, where the same six form an actual weak component. Whole-field context may use passes 0, 5, 10 and 20. The final top trio may appear in one context inset within its wider component; this is not a new triad project.

For each of the 16 group states, form `Y_i = X_i - mean(X)` and `C = (1/6) sum_i Y_i Y_i^T`. Report:

- Diameter and radius of gyration, reusing the accepted definitions.
- The three nonnegative eigenvalues in descending order and their fractions of `trace(C)`, with a stated numerical-zero convention.
- All 15 pair distances divided by Rg, retaining pair IDs rather than silently substituting ranked pairs between passes.

These quantities separate shrinking scale from relative shape. Report continuous evidence for three-dimensional spread or near-planarity; do not invent categorical thresholds or assign a named solid. The group's diameter has a small pass-18-to-19 rebound, so do not describe its diameter as strictly decreasing.

Produce one readable composite figure or two compact figures: whole-field context and six-point detail, including a centered/Rg-normalized comparison. Keep the same coordinate orientation across normalized views unless a rigid alignment is explicitly documented; centering and scaling alone do not remove rotation. Equal scaling is required for actual geometry. If edges are drawn, say that 15 undirected display links represent 30 directed selections, not physical faces. Avoid filled hulls or fabricated surface meshes.

Label all these outputs **new visualization/analysis of SIM04 historical data**, separately from the new SIM05 replay. This should remain an appendix-sized completion, not an open-ended shape search.

## 9. Relationship map and paper decision

Prepare one compact source-family table with columns for actual state, neighbor rule, carried velocity, local update ordering, fusion, schedules, randomness, boundaries, observers, surviving evidence and demonstrated relation. Mark a relation as shared mathematics, source variation, explicit historical attribution or unresolved; do not use development arrows unsupported by the records.

The editorial direction is:

| Family | Treatment |
| --- | --- |
| SIM01–SIM03: moving centers with carried velocity | Retain the published Volume I and its accepted distinctions |
| SIM04 and Infinity: March moving points with resonance fields | Core of a separate March reconstruction paper / provisional Volume II, with each recurrence defined separately |
| Tower II and its frequency/breathing relatives | One subsequent representative study, using existing accepted mathematics and a verified source-difference table for the other variants |
| July position-only patch and incomplete glyph/echo pipeline | Explicit source/provenance context; no automatic identification with a complete resonance engine |
| January fixed-grid models, fixed complex-linear SRG and URF action | Distinct mathematical objects; cite existing work without reopening them in this assignment |

SIM04 and Infinity can belong in the same comparative paper because their shared operations and specific differences can be stated. Their recorded trajectories are not a controlled one-factor comparison. Both using seed 2038 does not control for the changed R interval, additional D initialization draws, different noise schedule, H normalization or observer timing. Do not attribute cross-run behavior solely to the second field.

**Reconstruction finish line:** after Infinity, GPT intends one bounded representative Tower II construction/evidence study and a concise source-difference account of Universe/condensate, Tower I and BreathingField/collision. Reuse prior accepted results. Then draft the March reconstruction manuscript. Further full studies are not the default; remaining gaps can be recorded as gaps. A further engine would require GPT to identify a specific central mechanism that the chosen representatives and existing evidence cannot explain.

The manuscript is ready to draft when each included model has a precise state/update/observer definition, source-to-output attribution, understandable motion/geometry evidence, explicit relationships and a clear boundary between observed, reproduced and unsupported historical claims. It need not solve every missing provenance link or establish one canonical equation for all historical uses of the SRG name.

Do not start Tower II or draft the full manuscript in this assignment. Return this bounded package to GPT; GPT will review it and issue the final representative-study or manuscript order. Hilmir need not decide that routing now.

## 10. Deliverables and acceptance criteria

Return one `SRG_SIMULATION_STUDY_05_INFINITY_REVIEW.zip` with:

- `START_HERE.md`: short, ordinary-language account for Hilmir: what carries over, what changes, the most useful findings, and where this fits in the reconstruction.
- `CONSTRUCTION.md`: exact state, equations, execution order and observers, linked to original source.
- `HISTORICAL_EVIDENCE_AND_CLAIMS.md`: the original 200-row record, source/run attribution and historical claim audit.
- `REPLAY_AND_3D_ANALYSIS.md`: replay identity, reference equivalence, actual per-stage findings and readable 3D evidence.
- `SIM04_3D_ADDENDUM.md`: the bounded historical geometry completion.
- `MODEL_FAMILIES_AND_PAPER_PLAN.md`: the compact map and the explicit finish line above.
- `VERIFICATION_AND_LIMITS.md`: checks actually performed, run count, maximum discrepancies, provenance limits and preservation results.
- Unchanged relevant originals, isolated executable core and runner, exact state/RNG capture, all plotted data, analysis scripts, a figure register and manifest.
- A **proposed** ledger addition covering GPT's SIM04 acceptance and SIM05's review status; leave the canonical ledger unchanged.

Use **ORIGINAL**, **ATTRIBUTED**, **OBSERVED IN HISTORICAL DATA**, **REPRODUCED**, **DERIVED**, **HYPOTHESIS** and **MISSING/AMBIGUOUS** for the relevant claims. A replay observation should be labeled as such even if its aggregate metrics match the historical table. Do not mark SIM05 accepted or published before GPT review.

The minimum acceptance gates are intact source/data identities; exact isolated-core correspondence; faithful run configuration; the 400-update cap; reference/capture equality; complete state and RNG records; correctly staged observations; readable geometry figures; and explicit separation of historical claims from new replay evidence. If a replay gate fails, deliver the completed source and historical analysis with the precise blocker rather than leaving all work unfinished.

Use Windows Command Prompt and the established `torment` environment. Record actual versions. Do not install/update dependencies, run broad test suites or repeat earlier accepted studies. Additional tests must address a concrete unresolved correctness question within this order.

## 11. Preservation and stop

Baseline only the historical inputs and existing accepted context actually inspected; compare them on completion. Hash executable extracts and resulting evidence. Preserve the original notes even where their claims require correction in the new analysis. No old numerical code is repaired in place, and no accepted paper is silently revised.

Volume I's final publication receipt has now been received. It records 502/502 remote-byte matches at commit `63469551eb04c17bfbedb6b8fce057c5890cbba8`; GPT checked its identity and consistency, without repeating the full remote audit. Do not carry the earlier missing-receipt statement forward or rerun that publication audit.

**Stop after returning the review ZIP and a concise summary to GPT.** No parameter expansion, next engine, production integration, commit, push or publication is part of this assignment. Routine choices inside the specified scope are Codex's to complete; new scientific scope returns to GPT rather than requiring Hilmir to steer while resting.

**Working sequence: understand the original → inspect surviving evidence → capture one faithful replay where necessary → explain the geometry and mathematics → review → write the reconstruction paper.**
