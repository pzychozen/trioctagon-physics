"""Read-only SIM05 audit. No simulator import or evolve calls.
Every conditional calculation starts from a saved boundary. Noise is decoded
from saved RNG checkpoints, not generated along a new simulation trajectory.
Usage: python independent_audit.py INPUT_DIRECTORY OUTPUT_DIRECTORY
"""
from pathlib import Path
import ast, csv, hashlib, json, sys, platform
import numpy as np
from scipy.sparse.csgraph import connected_components

ROOT=Path(sys.argv[1]).resolve()
OUT=Path(sys.argv[2]).resolve(); OUT.mkdir(parents=True,exist_ok=True)
if OUT==ROOT or ROOT in OUT.parents: raise ValueError('Output must be outside sealed input package')

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):
    def conv(x):
        if isinstance(x,np.ndarray):return x.tolist()
        if isinstance(x,np.generic):return x.item()
        raise TypeError(str(type(x)))
    (OUT/name).write_text(json.dumps(obj,indent=2,default=conv,allow_nan=False)+'\n',encoding='utf-8')
def rows(name):
    with (ROOT/name).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def numeric_rows(name):return [{k:float(v) for k,v in r.items()} for r in rows(name)]
def maxerr(a,b):return float(np.max(np.abs(np.asarray(a)-np.asarray(b))))
def same(a,b):return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()
def H(t):return 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
def clip(x):return np.sign(x)*np.exp(np.clip(np.log(np.abs(x)+1e-9),-9,9))
def geom(x):
    y=x-x.mean(axis=0);c=y.T@y/len(x);ev=np.linalg.eigvalsh(c)[::-1]
    ds=np.linalg.norm(x[:,None,:]-x[None,:,:],axis=2)
    return dict(N=len(x),centroid=x.mean(axis=0),Rg=float(np.sqrt(np.trace(c))),diameter=float(ds.max()),eigenvalues=ev,fractions=ev/ev.sum())
def graph(x):
    # Independent direct Euclidean distances, not the submitted pdist/squareform path.
    ds=np.sqrt(np.sum((x[:,None,:]-x[None,:,:])**2,axis=2))
    nn=np.argsort(ds,axis=1)[:,1:6]; adj=np.zeros((len(x),len(x)),dtype=bool)
    adj[np.arange(len(x))[:,None],nn]=True
    nw,wl=connected_components(adj,directed=True,connection='weak')
    ns,sl=connected_components(adj,directed=True,connection='strong')
    return ds,nn,adj,nw,wl,ns,sl

def rng_tuple(z,prefix,index):
    return ('MT19937',z[prefix+'keys'][index].copy(),int(z[prefix+'pos'][index]),int(z[prefix+'has_gauss'][index]),float(z[prefix+'cached_gaussian'][index]))
def same_rng(a,b):
    return a[0]==b[0] and np.array_equal(a[1],b[1]) and a[2]==b[2] and a[3]==b[3] and np.float64(a[4]).tobytes()==np.float64(b[4]).tobytes()

manifest=json.loads((ROOT/'MANIFEST.json').read_text())
integrity=[]
for r in manifest['files']:
    p=ROOT/r['path']; ok=p.is_file() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    integrity.append(dict(path=r['path'],ok=ok))
assert all(r['ok'] for r in integrity)
assert len({r['path'] for r in integrity})==127
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
assert actual=={r['path'] for r in integrity}|{'MANIFEST.json'}
source=(ROOT/'originals/srg_infinity.py').read_text(encoding='utf-8')
lines=source.splitlines(keepends=True)
expected='import numpy as np\nimport pandas as pd\nfrom scipy.spatial.distance import pdist, squareform\n\n'+''.join(lines[42:55])+'\n'+''.join(lines[60:275])
core=(ROOT/'audited_core.py').read_text(encoding='utf-8')
assert core==expected
orig_ast=ast.parse(source);core_ast=ast.parse(core)
for k in ['H','rpco','GlyphFieldInfinity']:
    a=next(n for n in orig_ast.body if getattr(n,'name',None)==k)
    b=next(n for n in core_ast.body if getattr(n,'name',None)==k)
    assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
assert (ROOT/'context/AUTHORITATIVE_WORK_ORDER.md').read_bytes()==(ROOT/'context/EMBEDDED_WORK_ORDER.md').read_bytes()
identity=json.loads((ROOT/'CORE_IDENTITY.json').read_text())
assert sha(ROOT/'originals/srg_infinity.py')==identity['original_sha256']
assert sha(ROOT/'audited_core.py')==identity['core_sha256']

with np.load(ROOT/'replay/captured/states_and_rng.npz',allow_pickle=False) as f:z={k:f[k] for k in f.files}
with np.load(ROOT/'replay/reference/states_and_rng.npz',allow_pickle=False) as f:zr={k:f[k] for k in f.files}
assert z.keys()==zr.keys()
assert all(same(z[k],zr[k]) for k in z)
assert (ROOT/'replay/reference/metrics.json').read_bytes()==(ROOT/'replay/captured/metrics.json').read_bytes()
assert np.array_equal(z['pass'],np.arange(201))
for name in ['X','R','D','V']:assert np.isfinite(z[name]).all()
assert np.all(z['V'][0]==0)
assert np.array_equal(z['V'][1:],np.diff(z['X'],axis=0))
for k in ['keys','pos','has_gauss','cached_gaussian']:
    assert same(z['rng_'+k][:-1],z['rng_before_'+k])
    assert same(z['rng_'+k][1:],z['rng_after_'+k])
call_logs={}
for label in ['reference','captured']:
    logs=[json.loads(t) for t in (ROOT/f'replay/{label}/CALL_LOG.jsonl').read_text().splitlines()]
    assert [r['call'] for r in logs]==list(range(1,201))
    execution=json.loads((ROOT/f'replay/{label}/EXECUTION.json').read_text())
    assert execution['complete_calls']==200
    call_logs[label]=len(logs)
budget=json.loads((ROOT/'RUN_BUDGET.json').read_text());assert budget['completed_calls']==400
records=numeric_rows('replay/captured/glyph_states.csv');assert len(records)==10050
for t,r in enumerate(records):
    p,i=divmod(t,50);assert r['pass']==p and r['glyph_id']==i
    assert same(np.array([r[k] for k in ['X','Y','Z']]),z['X'][p,i])
    assert same(np.array([r[k] for k in ['VX','VY','VZ']]),z['V'][p,i])
    assert r['R']==z['R'][p,i] and r['D']==z['D'][p,i]
metrics=json.loads((ROOT/'replay/captured/metrics.json').read_text());assert len(metrics)==200
historical=numeric_rows('originals/srg_infinity_asymptotic.csv')
assert len(historical)==200 and [r['pass'] for r in historical]==list(range(1,201))
cols=[k for k in historical[0] if k!='pass'];assert len(cols)==20
hist_errors={k:max(abs(h[k]-m[k]) for h,m in zip(historical,metrics)) for k in cols}
exact={k:sum(h[k]==m[k] for h,m in zip(historical,metrics)) for k in cols}
assert all(np.isclose(h[k],m[k],atol=1e-12,rtol=1e-10) for h,m in zip(historical,metrics) for k in cols)
with np.load(ROOT/'analysis/graph_arrays.npz',allow_pickle=False) as f:sg={k:f[k] for k in f.files}
with np.load(ROOT/'analysis/intermediate_terms.npz',allow_pickle=False) as f:st={k:f[k] for k in f.files}
M=float(np.max(np.abs(H(np.linspace(0,100,50000)))))+1e-12
errors={k:0. for k in ['R','D','X_with_checkpoint_noise','residual_vs_checkpoint_noise','velocity']}
metric_error={k:0. for k in metrics[0]}
stage_errors={k:0. for k in st}
noise_rng_matches=0;clip_events=[];gr=[];labels=[];graphs=[]
all_neighbors_match=True;all_partitions_match=True;smallgap=float('inf');self_edges=0
for p in range(201):
    x=z['X'][p];d,nn,A,nw,wl,ns,sl=graph(x)
    labels.append(wl);graphs.append((d,nn,A))
    all_neighbors_match &= np.array_equal(nn,sg['neighbors'][p])
    all_partitions_match &= np.array_equal(wl[:,None]==wl[None,:],sg['weak_labels'][p,:,None]==sg['weak_labels'][p,None,:])
    ordered=np.sort(d,axis=1);smallgap=min(smallgap,float(np.min(ordered[:,6]-ordered[:,5])))
    self_edges+=int(np.trace(A))
    gr.append(dict(pass_=p,weak=nw,strong=ns,sizes=[int((wl==k).sum()) for k in range(nw)]))
    if p==200:break
    t=p+1;r=z['R'][p];dd=z['D'][p];xp=z['X'][t];rp=z['R'][t];dp=z['D'][t];v=z['V'][t]
    lap=np.array([np.mean(x[np.flatnonzero(A[i])]-x[i],axis=0) for i in range(50)])
    local_x=.05*lap+.15*np.tanh(lap)
    Y=x+local_x
    W=np.zeros((50,50))
    for i in range(50):
        ids=np.flatnonzero(A[i]);w=1/(d[i,ids]+1e-8);W[i,ids]=w/w.sum()
    wr=np.sum(W*r[None,:],axis=1);wd=np.sum(W*dd[None,:],axis=1)
    local_r=.15*(wr-r);local_d=.075*(wd-dd)
    cross=.08699*np.sin(.244*t+np.pi/2)
    cr=.01*cross*dd;cd=.01*cross*r
    Q=r+local_r+cr;E=dd+local_d+cd
    U=Q*(1+.05*H(t)/M);Z=E*(1+.05*H(t+np.pi/2)/M)
    C=np.average(Y,axis=0,weights=np.abs(U)+1e-8)
    F=.03*U[:,None]*(C-Y)
    P=U*(1-.001*np.sin(.244*t*2*np.pi))
    Rnext=clip(P);Dnext=clip(Z)
    lowerR=np.log(np.abs(P)+1e-9)<-9;upperR=np.log(np.abs(P)+1e-9)>9
    lowerD=np.log(np.abs(Z)+1e-9)<-9;upperD=np.log(np.abs(Z)+1e-9)>9
    for channel,mask,inp,out in [('R',lowerR,P,Rnext),('D',lowerD,Z,Dnext)]:
        for i in np.flatnonzero(mask):clip_events.append(dict(pass_=t,glyph=int(i),channel=channel,side='lower',input=float(inp[i]),output=float(out[i])))
    assert not upperR.any() and not upperD.any()
    residual=xp-(Y+F)
    rng=np.random.RandomState(0);rng.set_state(rng_tuple(z,'rng_before_',p))
    noise=rng.normal(0,.01/(1+.01*t),(50,3))
    noise_rng_matches+=int(same_rng(rng.get_state(),rng_tuple(z,'rng_after_',p)))
    errors['R']=max(errors['R'],maxerr(Rnext,rp));errors['D']=max(errors['D'],maxerr(Dnext,dp))
    errors['X_with_checkpoint_noise']=max(errors['X_with_checkpoint_noise'],maxerr(Y+F+noise,xp))
    errors['residual_vs_checkpoint_noise']=max(errors['residual_vs_checkpoint_noise'],maxerr(residual,noise))
    errors['velocity']=max(errors['velocity'],maxerr(xp-x,v))
    calc=dict(local_X=local_x,local_R=local_r,local_D=local_d,cross_R=cr,cross_D=cd,Q=Q,E=E,H_effect_R=U-Q,H_effect_D=Z-E,post_H_R=U,post_H_D=Z,fusion_center=C,fusion=F,sine_effect_R=P-U,pre_RPCO_R=P,pre_RPCO_D=Z,post_RPCO_R=Rnext,post_RPCO_D=Dnext,position_residual=residual,lower_R=lowerR,upper_R=upperR,lower_D=lowerD,upper_D=upperD,sign_change_R=np.sign(rp)!=np.sign(r),sign_change_D=np.sign(dp)!=np.sign(dd))
    for k,val in calc.items():
        if st[k].dtype==bool:assert np.array_equal(st[k][p],val),(k,p)
        else:stage_errors[k]=max(stage_errors[k],maxerr(st[k][p],val))
    # Full independent observation transcription with preserved source staging.
    curvature=[]
    for i in range(50):
        nbr=np.flatnonzero(A[i]);vv=xp[nbr]-xp[i];aa=[]
        for j in range(len(vv)):
            for k in range(j+1,len(vv)):
                cc=np.dot(vv[j],vv[k])/(np.linalg.norm(vv[j])*np.linalg.norm(vv[k])+1e-10)
                aa.append(np.arccos(np.clip(cc,-1,1)))
        curvature.append(np.std(aa))
    curvature=np.array(curvature);speed=np.linalg.norm(v,axis=1);retention=1/(1+speed)
    mx=np.abs(rp).max();mean=np.abs(rp).mean();std=rp.std();b=int(np.argmax(np.abs(rp)))
    echoes=(1-np.abs(rp[:,None]-rp[None,:])/(mx+1e-8))*np.exp(-d/3)>.85
    mask=(np.abs(rp)/(mx+1e-10)>.66)&(curvature>.012)
    obs=dict(pass_=t,R_max=mx,R_mean=mean,R_std=std,dark_energy=np.sum(dp**2),matter_energy=np.sum(rp**2),dark_matter_ratio=np.sum(dp**2)/(np.sum(rp**2)+1e-12),Rg=np.sqrt(np.mean(np.sum((xp-xp.mean(axis=0))**2,axis=1))),coherence=1-std/(mean+1e-8),n_echo_corridors=int(np.triu(echoes,1).sum()),n_infinity_seeds=int(mask.sum()),top_seed_id=b,top_seed_R=rp[b],top_seed_grf=retention[b],top_seed_curvature=curvature[b],mean_grf=retention.mean(),H_value=H(t),mean_curvature=curvature.mean(),top_seed_x=xp[b,0],top_seed_y=xp[b,1],top_seed_z=xp[b,2])
    obs['pass']=obs.pop('pass_')
    for k,val in obs.items():metric_error[k]=max(metric_error[k],abs(float(val)-metrics[p][k]))
    if t==200: final_echo=echoes;final_mask=mask;final_curvature=curvature
assert all_neighbors_match and all_partitions_match and self_edges==0 and smallgap>0
assert noise_rng_matches==200
assert all(v<1e-12 for v in errors.values())
assert max(metric_error.values())<1e-12 and max(stage_errors.values())<1e-12

wl=labels[-1];groups=[]
for k in np.unique(wl):
    ids=np.flatnonzero(wl==k);gg=geom(z['X'][-1,ids]);rr=z['R'][-1,ids];dd=z['D'][-1,ids]
    groups.append(dict(label=int(k),ids=ids,**gg,R_mean=rr.mean(),R_std=rr.std(),R_range=np.ptp(rr),D_mean=dd.mean(),D_std=dd.std(),D_range=np.ptp(dd),candidate_count=int(final_mask[ids].sum()),internal_echo_pairs=int(np.triu(final_echo[np.ix_(ids,ids)],1).sum())))
partition_same=[np.array_equal(l[:,None]==l[None,:],wl[:,None]==wl[None,:]) for l in labels]
first_stable=next(p for p in range(201) if all(partition_same[p:]))
var={}
for name in ['R','D']:
    field=z[name][-1];tot=float(field.var());within=sum(float(np.var(field[g['ids']]))*g['N']/50 for g in groups)
    between=sum(g['N']/50*(float(field[g['ids']].mean())-float(field.mean()))**2 for g in groups)
    var[name]=dict(total=tot,within=within,between=between,between_fraction=between/tot,within_fraction=within/tot)
internal=(wl[:,None]==wl[None,:]);cross_echo=int(np.triu(final_echo&~internal,1).sum())
missing_internal=int(np.triu(internal&~final_echo,1).sum())
non_candidates=np.flatnonzero(~final_mask)
# The terminal mean-field reduction is checked only conditionally, never iterated.
reduction=[]
for p in [33,50,100,150,199]:
    t=p+1;g=.0008699*np.sin(.244*t+np.pi/2);a=(1+.05*H(t)/M)*(1-.001*np.sin(.244*t*2*np.pi));b=1+.05*H(t+np.pi/2)/M
    for group in groups:
        ids=group['ids'];r=z['R'][p,ids].mean();d=z['D'][p,ids].mean()
        pr=clip(a*(r+g*d));pd=clip(b*(d+g*r))
        reduction.append(dict(incoming_pass=p,group=int(group['label']),R_error=float(abs(pr-z['R'][t,ids].mean())),D_error=float(abs(pd-z['D'][t,ids].mean()))))
# SIM04 addendum: original CSV only.
s04=numeric_rows('originals/SIM04/deep_trajectory.csv')
print('SIM04_COLUMNS',list(s04[0]))
save('integrity.json',dict(manifest_count=len(integrity),all_pass=True,records=integrity,original_sha256=identity['original_sha256'],core_slice_and_ast_match=True,work_orders_identical=True))
save('verification.json',dict(environment=dict(python=sys.version,numpy=np.__version__,platform=platform.platform()),new_simulator_updates=0,original_imported=False,boundaries=201,point_records=10050,reference_arrays=len(z),reference_bitwise=True,documented_call_logs=call_logs,documented_budget=budget,all_positions_finite=True,conditional_error_max=errors,intermediate_error_max=stage_errors,metric_error_max=metric_error,checkpoint_noise_after_rng_matches=noise_rng_matches,graph_neighbors_match=all_neighbors_match,graph_partitions_match=all_partitions_match,minimum_neighbor_cutoff_gap=smallgap,self_edges=self_edges,clipping_events=clip_events,historical_metric_errors=hist_errors,historical_exact_per_column=exact,historical_exact_total=sum(exact.values()),historical_all_within_declared_tolerance=True))
save('findings.json',dict(graph_changes=[r for j,r in enumerate(gr) if j==0 or r['weak']!=gr[j-1]['weak']],first_stable_final_partition=first_stable,final_groups=groups,final_field=geom(z['X'][-1]),initial_field=geom(z['X'][0]),variance=var,final_echo_total=int(np.triu(final_echo,1).sum()),cross_group_echo_pairs=cross_echo,missing_internal_echo_pairs=missing_internal,non_candidate_ids=non_candidates,non_candidate_R_ratio=z['R'][-1,non_candidates]/np.max(z['R'][-1]),final_curvature_min=float(final_curvature.min()),conditional_group_reduction=reduction,R_initial_mean=float(z['R'][0].mean()),R_final_mean=float(z['R'][-1].mean()),D_min=float(z['D'].min()),D_max=float(z['D'].max()),last_step_mean_displacement=float(np.linalg.norm(z['V'][-1],axis=1).mean()),last_step_max_displacement=float(np.linalg.norm(z['V'][-1],axis=1).max()),final_top_gap=float(np.diff(np.sort(z['R'][-1]))[-1]),final_top_group_range=float(np.ptp(z['R'][-1,wl==wl[np.argmax(z['R'][-1])]]))))
print(json.dumps(dict(manifest=127,conditional_errors=errors,metric_max=max(metric_error.values()),checkpoint_noise_matches=noise_rng_matches,historical_max=max(hist_errors.values()),historical_exact=sum(exact.values()),groups=[(g['N'],g['R_mean'],g['diameter']) for g in groups],echo_pairs=int(np.triu(final_echo,1).sum()),cross_echo=cross_echo,missing_internal=missing_internal,non_candidates=non_candidates.tolist(),reduction=reduction[-5:]),indent=2))
