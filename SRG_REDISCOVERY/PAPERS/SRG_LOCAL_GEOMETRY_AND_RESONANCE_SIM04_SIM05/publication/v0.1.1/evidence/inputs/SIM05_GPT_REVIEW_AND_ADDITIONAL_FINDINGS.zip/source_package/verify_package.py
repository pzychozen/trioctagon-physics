"""Read-only review verifier. No historical imports, evolution or file writes."""
from pathlib import Path
import json,hashlib,csv
import numpy as np
ROOT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def verify():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8'))
    for f in manifest['files']:
        p=(ROOT/f['path']).resolve();assert p.is_relative_to(ROOT)
        b=p.read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
    a=np.load(ROOT/'replay/reference/states_and_rng.npz');b=np.load(ROOT/'replay/captured/states_and_rng.npz')
    assert a.files==b.files
    for k in a.files:assert a[k].shape==b[k].shape and a[k].dtype==b[k].dtype and a[k].tobytes()==b[k].tobytes(),k
    for k in ['keys','pos','has_gauss','cached_gaussian']:
        assert b['rng_'+k][:-1].tobytes()==b['rng_before_'+k].tobytes()
        assert b['rng_'+k][1:].tobytes()==b['rng_after_'+k].tobytes()
    assert b['X'].shape==(201,50,3) and b['R'].shape==(201,50) and b['D'].shape==(201,50)
    assert np.array_equal(b['pass'],np.arange(201))
    assert np.array_equal(b['V'][1:],np.diff(b['X'],axis=0))
    assert all(np.isfinite(b[k]).all() for k in ['X','R','D','V'])
    assert (ROOT/'replay/reference/metrics.json').read_bytes()==(ROOT/'replay/captured/metrics.json').read_bytes()
    calls=0
    for label in ['reference','captured']:
        lines=(ROOT/f'replay/{label}/CALL_LOG.jsonl').read_text().splitlines();assert [json.loads(l)['call'] for l in lines]==list(range(1,201));calls+=len(lines)
    assert calls==400 and json.loads((ROOT/'RUN_BUDGET.json').read_text())['completed_calls']==400
    with (ROOT/'replay/captured/glyph_states.csv').open(newline='',encoding='utf-8') as h:rows=list(csv.DictReader(h))
    assert len(rows)==10050
    for n,row in enumerate(rows):
        p,i=divmod(n,50);assert int(row['pass'])==p and int(row['glyph_id'])==i
        expected=np.r_[b['X'][p,i],b['R'][p,i],b['D'][p,i],b['V'][p,i]]
        got=np.array([float(row[c]) for c in ['X','Y','Z','R','D','VX','VY','VZ']])
        assert got.tobytes()==expected.tobytes()
    with (ROOT/'originals/srg_infinity_asymptotic.csv').open(newline='',encoding='utf-8') as h:hr=list(csv.DictReader(h))
    assert len(hr)==200
    for p,row in enumerate(hr,1):
        assert int(row['pass'])==p and all(np.isfinite(float(v)) for v in row.values())
        for c,lo,hi in [('top_seed_id',0,49),('n_echo_corridors',0,1225),('n_infinity_seeds',0,50)]:
            v=float(row[c]);assert v==int(v) and lo<=v<=hi
        assert float(row['R_mean'])>1e-12 and float(row['dark_energy'])>0 and float(row['matter_energy'])>0
    return dict(manifest_files=len(manifest['files']),all_payload_hashes_match=True,bitwise_reference_match=True,rng_continuity=True,readable_table_exact_float_roundtrip=True,glyph_records=10050,source_calls=400,historical_schema_domains=True)
if __name__=='__main__':print(json.dumps(verify(),indent=2))
