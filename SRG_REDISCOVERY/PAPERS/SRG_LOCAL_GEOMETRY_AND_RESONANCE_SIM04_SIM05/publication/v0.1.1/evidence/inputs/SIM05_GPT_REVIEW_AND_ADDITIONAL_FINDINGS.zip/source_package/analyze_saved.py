"""Offline inspection ONLY: each transition starts from saved arrays.
No constructor, random draws, evolve calls, or propagation of computed states.
"""
from pathlib import Path
import csv, json, os, itertools, hashlib
import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform
from scipy.sparse.csgraph import connected_components
from audited_core import H, H_MAX, rpco
ROOT=Path(__file__).resolve().parent
A=ROOT/'analysis';A.mkdir(exist_ok=True)
def dump(name,o):
    (A/name).write_text(json.dumps(o,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def savecsv(name,rows):pd.DataFrame(rows).to_csv(A/name,index=False,float_format='%.17g')
def read(name):return pd.read_csv(name,float_precision='round_trip')
def graph(x):
    d=squareform(pdist(x));idx=np.argsort(d,axis=1)[:,1:6];adj=np.zeros_like(d)
    for i in range(len(x)):adj[i,idx[i]]=1
    return d,idx,adj
def geometry(x):
    y=x-x.mean(0);cov=y.T@y/len(x);raw=np.linalg.eigvalsh(cov)[::-1]
    tol=1e-12*max(1.,float(np.trace(cov)))
    assert raw.min()>=-tol
    ev=np.maximum(raw,0);tr=ev.sum();fr=ev/tr if tr>1e-24 else np.zeros(3)
    return dict(Rg=float(np.sqrt(np.mean(np.sum(y*y,axis=1)))),diameter=float(pdist(x).max()) if len(x)>1 else 0.,lambda1=float(ev[0]),lambda2=float(ev[1]),lambda3=float(ev[2]),fraction1=float(fr[0]),fraction2=float(fr[1]),fraction3=float(fr[2]),raw_min_eigenvalue=float(raw.min()))
def metrics(x,r,d,v,p,adj,dist):
    cur=np.zeros(50)
    for i in range(50):
        n=np.where(adj[i]>0)[0];angles=[]
        for j,k in itertools.combinations(n,2):
            a=x[j]-x[i];b=x[k]-x[i]
            angles.append(np.arccos(np.clip(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-10),-1,1)))
        cur[i]=np.std(angles) if angles else 0
    mx=np.max(abs(r));mean=np.mean(abs(r));grf=1/(1+np.linalg.norm(v,axis=1));top=int(np.argmax(abs(r)))
    echoes=sum((1-abs(r[i]-r[j])/(mx+1e-8))*np.exp(-dist[i,j]/3)>.85 for i,j in itertools.combinations(range(50),2))
    return dict(pass_=p,R_max=float(mx),R_mean=float(mean),R_std=float(np.std(r)),dark_energy=float(sum(d*d)),matter_energy=float(sum(r*r)),dark_matter_ratio=float(np.sum(d*d)/(np.sum(r*r)+1e-12)),Rg=geometry(x)['Rg'],coherence=float(1-np.std(r)/(mean+1e-8)) if mean>1e-12 else 0,n_echo_corridors=int(echoes),n_infinity_seeds=int(np.sum((abs(r)/(mx+1e-10)>.66)&(cur>.012))),top_seed_id=top,top_seed_R=float(r[top]),top_seed_grf=float(grf[top]),top_seed_curvature=float(cur[top]),mean_grf=float(np.mean(grf)),H_value=float(H(p)),mean_curvature=float(np.mean(cur)),top_seed_x=float(x[top,0]),top_seed_y=float(x[top,1]),top_seed_z=float(x[top,2]))
def main():
    assert json.loads((ROOT/'REFERENCE_EQUIVALENCE.json').read_text())['all_pass']
    z=np.load(ROOT/'replay/captured/states_and_rng.npz');X=z['X'];R=z['R'];D=z['D'];V=z['V']
    assert X.shape==(201,50,3) and np.array_equal(z['pass'],np.arange(201))
    assert all(np.isfinite(z[k]).all() for k in ['X','R','D','V'])
    assert np.array_equal(V[1:],np.diff(X,axis=0))
    hist=read(ROOT/'originals/srg_infinity_asymptotic.csv');rep=read(ROOT/'replay/captured/metrics.csv')
    assert hist.shape==(200,21) and np.array_equal(hist['pass'],np.arange(1,201)) and np.isfinite(hist.to_numpy()).all()
    assert list(hist.columns)==list(rep.columns)
    differences=[];colchecks=[]
    for c in hist.columns:
        h=hist[c].to_numpy();r=rep[c].to_numpy();err=abs(r-h);near=err<=1e-12+1e-10*abs(h)
        colchecks.append(dict(column=c,exact_count=int(np.sum(h==r)),near_count=int(near.sum()),max_abs=float(err.max()),max_abs_pass=int(np.argmax(err)+1)))
        for p in range(200):differences.append(dict(pass_=p+1,column=c,historical=float(h[p]),replayed=float(r[p]),difference=float(r[p]-h[p]),exact=bool(h[p]==r[p]),near=bool(near[p])))
    savecsv('historical_replay_columns.csv',colchecks);savecsv('historical_replay_per_pass.csv',differences)
    hchecks={}
    hchecks['ratio_max_error']=float(abs(hist.dark_matter_ratio-hist.dark_energy/(hist.matter_energy+1e-12)).max())
    hchecks['coherence_max_error']=float(abs(hist.coherence-(1-hist.R_std/(hist.R_mean+1e-8))).max())
    hchecks['max_top_amplitude_error']=float(abs(hist.R_max-abs(hist.top_seed_R)).max())
    hchecks['H_max_error']=float(abs(hist.H_value-H(hist['pass'].to_numpy())).max())
    hchecks['same_sign_energy_identity_max_error']=float(abs(hist.matter_energy-50*(hist.R_std**2+hist.R_mean**2)).max())
    stable=hist.top_seed_id.to_numpy()[1:]==hist.top_seed_id.to_numpy()[:-1]
    speed=np.linalg.norm(np.diff(hist[['top_seed_x','top_seed_y','top_seed_z']].to_numpy(),axis=0),axis=1)
    hchecks['stable_top_transitions']=int(stable.sum());hchecks['stable_top_grf_max_error']=float(abs(hist.top_seed_grf.to_numpy()[1:][stable]-1/(1+speed[stable])).max())
    hchecks['last10_Rmax_population_CV']=float(np.std(hist.R_max.to_numpy()[-10:])/np.mean(hist.R_max.to_numpy()[-10:]))
    hchecks['last10_Rg_population_CV']=float(np.std(hist.Rg.to_numpy()[-10:])/np.mean(hist.Rg.to_numpy()[-10:]))
    hchecks['last20_top_ids']=sorted(set(map(int,hist.top_seed_id.iloc[-20:])))
    hchecks['endpoint']=hist.iloc[-1].to_dict();hchecks['dark_ratio_increasing_transitions']=int(np.sum(np.diff(hist.dark_matter_ratio)>0))
    hchecks['schema_rows']=200;hchecks['schema_columns']=21
    assert hchecks['ratio_max_error']<1e-12 and hchecks['coherence_max_error']<1e-12 and hchecks['max_top_amplitude_error']<1e-12
    dump('historical_checks.json',hchecks)
    stage={k:[] for k in ['local_X','local_R','local_D','cross_R','cross_D','Q','E','H_effect_R','H_effect_D','post_H_R','post_H_D','fusion_center','fusion','sine_effect_R','pre_RPCO_R','pre_RPCO_D','post_RPCO_R','post_RPCO_D','position_residual','lower_R','upper_R','lower_D','upper_D','sign_change_R','sign_change_D']}
    summaries=[];metric_errors=[];graphs=[];geom=[];neighbors=[];glabels=[];components=[]
    for p in range(201):
        dist,idx,adj=graph(X[p]);neighbors.append(idx)
        nw,lw=connected_components(adj,directed=True,connection='weak');ns,ls=connected_components(adj,directed=True,connection='strong');glabels.append(lw)
        sizes=[int(np.sum(lw==j)) for j in range(nw)]
        graphs.append(dict(pass_=p,weak=int(nw),strong=int(ns),weak_sizes=';'.join(map(str,sizes)),self_edges=int(np.trace(adj)),min_neighbor_cutoff_gap=float(np.min(np.sort(dist,axis=1)[:,6]-np.sort(dist,axis=1)[:,5]))))
        geom.append(dict(pass_=p,**geometry(X[p]),mean_R=float(np.mean(R[p])),std_R=float(np.std(R[p])),min_D=float(D[p].min()),max_D=float(D[p].max()),mean_D=float(D[p].mean()),std_D=float(D[p].std()),negative_D=int(np.sum(D[p]<0)),zero_D=int(np.sum(D[p]==0)),mean_speed=float(np.linalg.norm(V[p],axis=1).mean())))
        for j in range(nw):
            ids=np.where(lw==j)[0];components.append(dict(pass_=p,component=int(j),ids=';'.join(map(str,ids)),size=len(ids),mean_R=float(R[p,ids].mean()),mean_D=float(D[p,ids].mean()),std_D=float(D[p,ids].std()),**geometry(X[p,ids])))
        if p==200:continue
        t=p+1;x=X[p];r=R[p];d=D[p];lap=np.zeros_like(x);lr=np.zeros(50);ld=np.zeros(50);cr=np.zeros(50);cd=np.zeros(50)
        q=r.copy();e=d.copy();c=.08699*np.sin(.244*t+np.pi/2)
        for i in range(50):
            nn=np.where(adj[i]>0)[0]
            if len(nn)==0:continue
            lap[i]=np.mean(x[nn]-x[i],axis=0)
            w=1/(dist[i,nn]+1e-8);w/=w.sum()
            lr[i]=.15*(np.sum(w*r[nn])-r[i]);ld[i]=.15*.5*(np.sum(w*d[nn])-d[i])
            cr[i]=c*d[i]*.01;cd[i]=c*r[i]*.01
            q[i]+=lr[i];q[i]+=cr[i];e[i]+=ld[i];e[i]+=cd[i]
        lx=.05*lap+.15*np.tanh(lap);y=x+lx
        hr=q*(1+.05*H(t)/H_MAX);hd=e*(1+.05*H(t+np.pi/2)/H_MAX)
        center=np.average(y,axis=0,weights=abs(hr)+1e-8);fusion=(center-y)*.03*hr[:,None]
        pr=hr*(1-.001*np.sin(t*.244*2*np.pi));pd_=hd.copy()
        rr=rpco(pr);dd=rpco(pd_);res=X[t]-(y+fusion)
        vals=dict(local_X=lx,local_R=lr,local_D=ld,cross_R=cr,cross_D=cd,Q=q,E=e,H_effect_R=hr-q,H_effect_D=hd-e,post_H_R=hr,post_H_D=hd,fusion_center=center,fusion=fusion,sine_effect_R=pr-hr,pre_RPCO_R=pr,pre_RPCO_D=pd_,post_RPCO_R=rr,post_RPCO_D=dd,position_residual=res,lower_R=np.log(abs(pr)+1e-9)<-9,upper_R=np.log(abs(pr)+1e-9)>9,lower_D=np.log(abs(pd_)+1e-9)<-9,upper_D=np.log(abs(pd_)+1e-9)>9,sign_change_R=np.sign(r)!=np.sign(R[t]),sign_change_D=np.sign(d)!=np.sign(D[t]))
        for k,v in vals.items():stage[k].append(v)
        row=dict(pass_=t,cross_coefficient=float(c),H_R=float(H(t)),H_D=float(H(t+np.pi/2)),noise_sigma=.01/(1+.01*t),R_max_error=float(abs(rr-R[t]).max()),D_max_error=float(abs(dd-D[t]).max()),position_decomposition_error=float(abs(X[t]-(x+lx+fusion+res)).max()),residual_std=float(res.std()),residual_max_abs=float(abs(res).max()))
        for k in ['local_R','local_D','cross_R','cross_D','H_effect_R','H_effect_D','sine_effect_R','local_X','fusion','position_residual']:row[k+'_rms']=float(np.sqrt(np.mean(vals[k]**2)))
        for k in ['lower_R','upper_R','lower_D','upper_D','sign_change_R','sign_change_D']:row[k+'_count']=int(vals[k].sum())
        summaries.append(row)
        calc=metrics(X[t],R[t],D[t],V[t],t,adj,dist);calc['pass']=calc.pop('pass_')
        for k,vv in calc.items():metric_errors.append(dict(pass_=t,column=k,error=float(vv-rep.iloc[p][k])))
    arrays={k:np.asarray(v) for k,v in stage.items()};np.savez_compressed(A/'intermediate_terms.npz',**arrays)
    np.savez_compressed(A/'graph_arrays.npz',neighbors=np.asarray(neighbors),weak_labels=np.asarray(glabels))
    savecsv('stage_summary.csv',summaries);savecsv('offline_metric_errors.csv',metric_errors);savecsv('graph_summary.csv',graphs);savecsv('field_geometry.csv',geom);savecsv('component_geometry.csv',components)
    # Fixed final components selected for two views: containing max-|R| and min-R points.
    labels=np.asarray(glabels);chosen=[]
    for tag,i in [('final_highest_R_component',int(np.argmax(abs(R[-1])))),('final_lowest_R_component',int(np.argmin(R[-1])))]:
        ids=np.where(labels[-1]==labels[-1,i])[0].tolist()
        if not any(c['ids']==ids for c in chosen):chosen.append(dict(name=tag,ids=ids,actual_component_passes=[p for p in range(201) if set(np.where(labels[p]==labels[p,ids[0]])[0])==set(ids)]))
    dump('selected_groups.json',chosen)
    selectedrows=[]
    for g in chosen:
        for p in range(201):selectedrows.append(dict(selection=g['name'],pass_=p,**geometry(X[p,g['ids']]),actual_component=p in g['actual_component_passes']))
    savecsv('selected_group_geometry.csv',selectedrows)
    leader=int(np.argmax(abs(R[-1])));start=200
    while start>0 and int(np.argmax(abs(R[start-1])))==leader:start-=1
    result=dict(max_R_conditional_error=max(s['R_max_error'] for s in summaries),max_D_conditional_error=max(s['D_max_error'] for s in summaries),max_position_decomposition_error=max(s['position_decomposition_error'] for s in summaries),offline_metrics_max_error=max(abs(s['error']) for s in metric_errors),clipping={k:int(arrays[k].sum()) for k in ['lower_R','upper_R','lower_D','upper_D']},sign_changes={k:int(arrays[k].sum()) for k in ['sign_change_R','sign_change_D']},D_negative_states=int(np.sum(np.any(D<0,axis=1))),D_min=float(D.min()),D_max=float(D.max()),D_final_negative=int(np.sum(D[-1]<0)),R_min=float(R.min()),residual_mean=float(arrays['position_residual'].mean()),residual_std=float(arrays['position_residual'].std()),final_leader=leader,final_leader_start=start,leader_path_length=float(np.linalg.norm(np.diff(X[start:,leader],axis=0),axis=1).sum()),leader_endpoint_displacement=float(np.linalg.norm(X[-1,leader]-X[start,leader])),graph_count_changes=[graphs[p] for p in range(201) if p==0 or graphs[p]['weak']!=graphs[p-1]['weak']],historical_near_all=all(x['near_count']==200 for x in colchecks),historical_exact_values=sum(x['exact_count'] for x in colchecks),tolerance_absolute=1e-12)
    assert max(result['max_R_conditional_error'],result['max_D_conditional_error'],result['offline_metrics_max_error'])<=1e-12
    for k in ['local_R','local_D','cross_R','cross_D','H_effect_R','H_effect_D','sine_effect_R']:
        result[k+'_overall_rms']=float(np.sqrt(np.mean(arrays[k]**2)))
    # SIM04 fixed six identities. These are existing saved data, never an evolution.
    h4=read(ROOT/'originals/SIM04/deep_trajectory.csv');ids=[10,15,27,30,33,47]
    x4=h4[['X','Y','Z']].to_numpy().reshape(21,50,3);g4=[];pairs=[]
    assert np.array_equal(h4.Pass.to_numpy(),np.repeat(np.arange(21),50)) and np.array_equal(h4.Glyph_ID.to_numpy(),np.tile(np.arange(50),21))
    retained=read(ROOT/'context/SIM04/analysis/directed_neighbors.csv')
    print('SIM04 retained neighbor columns:',list(retained.columns))
    for p in range(5,21):
        dd,ii,aa=graph(x4[p]);n,l=connected_components(aa,directed=True,connection='weak')
        assert set(np.where(l==l[ids[0]])[0])==set(ids)
        gm=geometry(x4[p,ids]);g4.append(dict(pass_=p,**gm))
        for i,j in itertools.combinations(ids,2):pairs.append(dict(pass_=p,glyph_i=i,glyph_j=j,distance=float(np.linalg.norm(x4[p,i]-x4[p,j])),distance_over_Rg=float(np.linalg.norm(x4[p,i]-x4[p,j])/gm['Rg'])))
    savecsv('SIM04_six_geometry.csv',g4);savecsv('SIM04_six_normalized_pairs.csv',pairs)
    dump('SIM04_geometry_checks.json',dict(actual_six_component_all_16_passes=True,initial=g4[0],final=g4[-1],diameter_18_to_19=g4[14]['diameter']-g4[13]['diameter'],pair_count=240,centroid='unweighted arithmetic',covariance_divisor=6,zero_trace_threshold=1e-24,negative_eigenvalue_tolerance='1e-12 * max(1,trace); clamp roundoff negatives to zero',alignment='none; same coordinate orientation'))
    dump('analysis_checks.json',result)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
