# GPT mathematical review — completed SRG-R2

Review SRG_R2_REPORT.md and RAW_DATA_README.md first. This package contains completed execution, not a proposed run. The human-authorized task used exactly two preflight calls and two 600-pass eta=0 controls, reusing accepted R1 eta=.001/epsilon=0 baselines. No historical core or prior result was edited.

The main new numerical result is a reduction of net mean-resonance gain by 99.6553% / 99.4654%, while compaction persists but is weaker. The residual approximately 5% gain has a positive H path-budget contribution of comparable size. All noise and RNG comparisons are exact. No clipping or Q>50 crossing occurred.

Review priorities:

1. Independently verify the source-conditioned Q=m(DP+K)R map, identity/underflow branches, positive-cone assumptions and row-bound qualifications.
2. Check the ordered phi/sum/difference/H/RPCO/residual budget and distinguish it from the actual causal control.
3. Check the diffusion coordinate-box proof, non-hull counterexample, conditional fusion proof and overshoot counterexample.
4. Assess the paired remaining-budget decomposition: changed P contributes, but is smaller than the R component in the chosen ordering; this does not isolate a separate causal geometry effect.
5. Inspect first-pass Q and same-pass X/V divergence, preserved random streams, complete raw arrays, and source/preflight execution hash binding.
6. Assess the descriptive three-window spectra without promoting imposed frequency peaks or legacy flags into emergent-oscillator evidence.
7. Evaluate the single proposed next H-off comparison. It has not been executed or automatically authorized by this package.

The accepted R1 raw ZIP is referenced by SHA-256 aa9a538979d773deb363e7a14398cc2f8b794840fdc9e40a9cf46586516e6f18, rather than duplicated. Its raw data are needed to independently regenerate baseline stages, while this ZIP contains their new derived evidence and complete new control records.

FINAL_CHECKS_01 records a corrected metadata-key error in postprocessing only; FINAL_CHECKS_02 is the successful result. The Rg² increase-count JSON label has a missing minus sign, explicitly documented as a 1e−14 implementation threshold. Neither issue changed source state, numerical tolerance or trajectory count.
