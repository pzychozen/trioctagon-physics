# OC06 — January signed-grid two-step accessibility

## 1. One site, two passes, and a gap that matters

Imagine a periodic grid containing just one site. Looking one place left or right returns to that same site; so does looking in either direction along the other axis. All neighbor-minus-center differences cancel. Before multiplication and compression, a value y therefore becomes

\[
P(y)=y+\frac1{10}\tanh y.
\tag{1}
\]

The signed compressor can output zero, or a positive or negative value whose magnitude is at least u=e^-10. It can never output a nonzero magnitude smaller than u.

This missing interval matters on the second pass. With second gain 1, a nonzero first output already has magnitude at least u; (1) makes its magnitude larger still. The compressor cannot return it to the floor u. Zero also cannot reach either signed floor. Thus neither +u nor -u is reachable after two passes at second gain 1, from any initial value or any positive first gain.

With second gain 1/2, an intermediate value +u or -u does reach its respective floor: halving (1) puts its magnitude safely inside the floor-capture interval. Such an intermediate value has a first-pass precursor for every positive first gain.

| Specified second gain | A possible first output | Second result | Can any initial value reach the indicated signed floor after two passes? |
|---|---|---|---|
| 1 | +u | Approximately 0.0000509399227356141, greater than u | No, for either sign; proof covers every first output |
| 1/2 | +u | Exactly +u in exact-real arithmetic | Yes; the negative case follows by oddness |

Here u is approximately 0.0000453999297624849. These are separate scalar evaluations and proofs, not two executed historical program passes.

The singleton is permitted by the unchanged two-dimensional periodic stencil as a mathematical input shape. The historical app's size menu offers 64, 128 and 256, not 1. We do not describe this example as a selectable historical app run. The study explicitly chooses the source's signed mode; the app initially selects paper mode.

## 2. Scope, sources and definitions

Date: 12 October 2026. Completed bounded analysis for GPT scientific review. The model here is January's finite periodic-index field. Tower II's moving particles, adjacency guards and amplitude equations are not premises.

The final local handoff was read before investigation and remains unchanged. The accepted OC02 theorem that P is a global smooth diffeomorphism is an input; its checker and proof suite were not rerun. The historical sources were only read as text. The two gains below are specified positive mathematical parameters, not certified consecutive outputs of the historical H schedule.

All source paths below are relative to:

C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY

| ID | Read-only input |
|---|---|
| J1 | EQUATION_OPERATOR_LINEAGE_01/sources/january/tgmo.py.txt |
| J2 | EQUATION_OPERATOR_LINEAGE_01/sources/january/refu.py.txt |
| J3 | EQUATION_OPERATOR_LINEAGE_01/sources/january/app.py.txt |
| G | ORIGINS_PUBLICATION_PREP_20261011/SRG_NEXT_CHAT_HANDOFF_FINAL_20261011.zip, member updates/OC02_SIGNED_PLATEAUS_REPORT.md |
| A | Same handoff, updates/REQUIRED_SOURCE_AND_NOTATION_ADDENDUM.md |
| M | OPERATOR_COMPOSITION_02_SIGNED_PLATEAUS/CLAIM_SOURCE_MAP.md |

| Definition or premise | Physical source lines |
|---|---|
| Periodic second difference; dimensional acceptance; anisotropic sum | J1:4–5, 19–40 |
| Embedding angle labels: theta major, phi minor | J1:62–76; A:13–31 |
| RPCO paper/signed distinction and epsilon inside log | J2:37–67 |
| TGMO and nonlinear term both use incoming Theta; nonlinear term has no extra step-size factor | J2:109–120 |
| Gain applied before RPCO | J2:122–138 |
| App parameters and initial mode | J3:44–66 |
| D(Theta)=Theta and kappa*tanh(D/scale) | J3:234–238 |
| Source schedule uses t=n*dt | J2:173–191 |
| Accepted one-step capture cell and endpoint exclusions | G:224–267, equations (12)–(13) |
| Accepted global diffeomorphism of P | G:238–252, Theorem 2 |
| One-step conclusions do not themselves establish later access | G:267–269 |

Full byte counts and SHA-256 identities are in CLOSEOUT.md and CHECK_RESULTS.json. J2's original UTF-8 BOM is included in its hash; decoding it for line inspection does not modify the file.

Let N,M be positive integers and d=NM. Indices are taken modulo their respective axis lengths, counting both directed incidences even if they return to the same site:

\[
(\mathcal L X)_{ij}
=X_{i+1,j}-2X_{ij}+X_{i-1,j}
+\frac{25}{9}(X_{i,j+1}-2X_{ij}+X_{i,j-1}).
\tag{2}
\]

This is the source's constant-coefficient index stencil with a=1 and b=3/5. It is not an embedded-torus Laplace–Beltrami operator. A02 clarifies the embedding's angle names without replacing (2).

With the app parameters h=1/20, kappa=1/10 and scale=1,

\[
T=I+\frac1{20}\mathcal L,\qquad
P(X)=TX+\frac1{10}\tanh X,
\tag{3}
\]

where tanh acts coordinatewise. There is no additional factor h multiplying the nonlinear term. For this study set

\[
u=e^{-10},\quad v=e^{10},\quad \varepsilon=10^{-6},
\quad f=u-\varepsilon>0,\quad m>0.
\tag{4}
\]

The source has generic RPCO defaults L=9, epsilon=10^-9, but the January app supplies L=10 and epsilon=10^-6. Equation (4) uses the app setting accepted in OC02, not the generic defaults or Tower II's parameters.

The explicitly selected signed compressor and field map are

\[
C_s(q)=
\begin{cases}
0,&q=0,\\
\operatorname{sgn}(q)\min\{v,\max\{u,|q|+\varepsilon\}\},&q\ne0,
\end{cases}
\qquad
F_m(X)=C_s(mP(X)).
\tag{5}
\]

C_s acts coordinatewise in F_m. The equivalence of (5) to sign(q) exp(clip(log(|q|+epsilon),-10,10)) uses monotonicity of log and exp. Zero is not a signed floor point.

We use **G, Theorem 2**: P is a global smooth diffeomorphism on R^d for every finite positive N,M. The needed reason is that DP is uniformly positive definite, with T bounded below by 11/45, and P is the gradient of a coercive strictly convex potential after subtraction of any linear functional; hence it has a unique preimage of every point and a smooth inverse. This is citation of the accepted theorem, not a new numerical verification or reclassification of its fixed patterns.

## 3. The scalar range and every inverse fiber

**Theorem A.** The entire scalar range of C_s is

\[
S=\{0\}\cup[-v,-u]\cup[u,v].
\tag{6}
\]

**Proof, forward inclusion.** A zero argument gives zero. Every nonzero argument retains its sign and has output magnitude between u and v, including the endpoints, by (5).

**Proof, reverse inclusion.** Zero has the witness q=0. For any nonzero y in S, choose q=sign(y)(|y|-epsilon). Since |y|>=u>epsilon, this q has the desired nonzero sign and |q|+epsilon=|y|. Clipping therefore returns y, including |y|=u and |y|=v. QED.

For precision about endpoints, define the set of all scalar preimages J(y)={q:C_s(q)=y}. Its complete description is:

| Output y | Entire scalar fiber J(y) |
|---|---|
| 0 | {0} |
| +u | (0,u-epsilon] |
| -u | [-(u-epsilon),0) |
| u<abs(y)<v | {y-epsilon sign(y)} |
| +v | [v-epsilon,infinity) |
| -v | (-infinity,-(v-epsilon)] |
| y outside S | Empty |

To prove the table, a nonzero output has the same sign as its input. The floor condition is 0<|q|+epsilon<=u with q nonzero, equivalently 0<|q|<=f. The ceiling condition is |q|+epsilon>=v; between endpoints the equality |q|+epsilon=|y| determines one q. Only q=0 can give zero. These conditions exhaust (5).

In particular, the floor fiber excludes zero but includes its far endpoint; the ceiling fibers include their near endpoints. The signed compressor is many-to-one and has a gap between zero and either floor. It is not invertible as an ordinary function.

## 4. Exact first-pass image

**Corollary A1.** For every m_1>0,

\[
F_{m_1}(\mathbb R^d)=S^d.
\tag{7}
\]

**Proof.** Every output coordinate is in S by Theorem A, which proves one inclusion. Conversely let Y be any vector in S^d. Choose each z_i in J(Y_i), for example the witnesses used in the reverse inclusion above. Since P is onto and m_1 is positive, the unique vector X=P^-1(z/m_1) satisfies m_1 P(X)=z. Thus F_m1(X)=Y. This proves the reverse inclusion for arbitrary Y, without an input truncation or sampling assumption. QED.

This is a range statement over all real fields. It does not describe the historical initialization distribution, floating-point representability or the chance of drawing a witness.

The complete first-stage precursor set for any Y in S^d is

\[
\mathcal I_{m_1}(Y)
=\left\{P^{-1}(z/m_1):z\in\prod_{i=1}^{d}J(Y_i)\right\}.
\tag{8}
\]

Indeed, F_m1(X)=Y if and only if m_1P(X) lies in that Cartesian product. Here P^-1 is a single-valued inverse. The left side is a set of preimages under the many-to-one map F_m1. Equation (8) includes zero coordinates, signed floors, ordinary interior outputs and ceilings. No numerical inverse solve is needed.

## 5. Two-step access: necessity, sufficiency and all precursors

For a sign vector sigma in {-1,+1}^d and specified m_2>0, the accepted one-step capture cell is

\[
\mathcal B_{m_2,\sigma}
=\{Y:0<\sigma_i m_2P(Y)_i\le f\text{ for all }i\}.
\tag{9}
\]

Its strict lower bound excludes zero arguments. Its non-strict upper bound includes exact floor endpoints.

**Theorem B.** For any specified positive gain pair m_1,m_2,

\[
\exists X:\ F_{m_2}(F_{m_1}(X))=u\sigma
\quad\Longleftrightarrow\quad
S^d\cap\mathcal B_{m_2,\sigma}\ne\varnothing.
\tag{10}
\]

**Necessity.** Given a precursor X, put Y=F_m1(X). By (7), Y is in S^d. The assertion F_m2(Y)=u sigma is exactly (9), by the scalar floor fibers. Hence Y lies in the intersection.

**Sufficiency.** Given Y in the intersection, (8) supplies at least one first-stage precursor X for every m_1>0. Equation (9) then ensures F_m2(Y)=u sigma. QED.

More fully, the entire set of two-step precursors is

\[
\boxed{
\mathcal A^{(2)}_{m_1,m_2,\sigma}
=\bigcup_{Y\in S^d\cap\mathcal B_{m_2,\sigma}}
\left\{P^{-1}(z/m_1):z\in\prod_iJ(Y_i)\right\}.
}
\tag{11}
\]

Both inclusions follow from the two directions just proved and the complete fibers in (8). For a given initial X the criterion is simply F_m1(X) in B; it is not asserted that every X reaches the target.

The two-step set is empty exactly when the intersection in (10) is empty. It is nonempty exactly when that intersection is nonempty. Its **nonemptiness** is independent of m_1 as long as m_1>0, because (7) is independent of m_1. The individual precursors and the geometry of their set still depend on the factor 1/m_1 inside P^-1 in (11). No statement about the measure or probability of that set follows just from this existence equivalence.

For comparison, every one-step capture cell in (9) is nonempty: choose a vector z with 0<sigma_i m_2 z_i<f for every i and take Y=P^-1(z). Two-step capture imposes the extra requirement Y in S^d. The inability of the first compressor to produce arbitrarily small nonzero coordinates is therefore a genuine possible obstruction, even when one-step capture is possible.

This is access **at the second pass**, whether or not the initial state or first output was already the target. It is not a first-arrival definition and not the unrestricted eventual basin over an unbounded number of passes.

## 6. Singleton contrast and its exact threshold

For N=M=1, every directed periodic neighbor incidence equals y. Thus

\[
\mathcal L y=(y-2y+y)+\frac{25}{9}(y-2y+y)=0,
\qquad P(y)=y+\frac1{10}\tanh y.
\tag{12}
\]

The function is odd and strictly increasing because

\[
P'(y)=1+\frac1{10}\operatorname{sech}^2 y>0.
\tag{13}
\]

For y>0, P(y)>y; by oddness, its sign is preserved and |P(y)|>|y| for every nonzero y.

### Second gain 1: universal obstruction

A possible intermediate output belongs to S. If Y=0, then P(Y)=0 and the second output is zero, which is neither signed target. If Y is nonzero then |Y|>=u, so

\[
|P(Y)|\ge P(u)>u>u-\varepsilon=f.
\tag{14}
\]

The floor-fiber condition fails for either sign. This proves S intersect B_(1,+1) and S intersect B_(1,-1) are both empty. By (10), no initial value reaches either target after two passes, for every m_1>0. This proof covers all possible intermediate outputs, not merely the trial Y=u in the opening table.

### Second gain 1/2: rigorous witnesses

For x>0, 0<tanh x<x, since tanh(0)=0 and its derivative is positive and less than one away from zero. Also e<3: in the exponential series, n!>=2^(n-1) for n>=2, with a strict inequality from n=3 onwards, so e<1+1+sum_(n>=2)2^-(n-1)=3. Consequently u=e^-10>3^-10=1/59049>epsilon.

We obtain

\[
0<\frac12P(u)<\frac{11}{20}u<u-\varepsilon,
\tag{15}
\]

where the last inequality follows from

\[
\frac9{20}u-\varepsilon
>\frac9{20\cdot59049}-\frac1{10^6}
=\frac{43439}{6561000000}>0.
\tag{16}
\]

Therefore Y=+u belongs to S intersect B_(1/2,+1), and Y=-u belongs to S intersect B_(1/2,-1). Both targets are reachable for every positive first gain. One explicit family of precursors is

\[
X=P^{-1}\!\left(\frac{\sigma z}{m_1}\right),
\qquad 0<z\le f,\qquad \sigma\in\{-1,+1\}.
\tag{17}
\]

Here the first output is sigma u and the second output is the same signed floor at gain 1/2. This family demonstrates existence; formula (11) gives the full two-step set, including any other admissible intermediate outputs.

### Exact singleton cutoff

The same monotonicity argument gives a complete criterion within this singleton example:

\[
m_\star=\frac{u-\varepsilon}{P(u)}
=\frac{e^{-10}-10^{-6}}{e^{-10}+\tanh(e^{-10})/10},
\qquad
\boxed{\text{a signed target is reachable iff }0<m_2\le m_\star.}
\tag{18}
\]

For necessity, the smallest possible nonzero |P(Y)| over Y in S is P(u). For sufficiency choose Y=sigma u. Equality m_2=m_star is included, because the upper floor-fiber endpoint is included. Equations (14)–(16) prove 1/2<m_star<1. This cutoff is a deduction within the requested singleton calculation, not a gain sweep or a statement about the historical schedule.

Equivalently, the admissible singleton intermediates for sign sigma are Y=sigma y with

\[
u\le y\le \min\{v,P^{-1}(f/m_2)\},
\tag{19}
\]

provided the upper endpoint is at least u. This uses the scalar increasing P^-1; if the upper endpoint is below u the set is empty. There are no opposite-sign or zero intermediate witnesses in the singleton, since P preserves sign.

The 80-digit corroboration gives

\[
\begin{aligned}
m_\star&\approx0.889066849332978844244640589821,\\
f-\tfrac12P(u)&\approx0.000019429968394677787018,\\
P(u)-f&\approx0.000005539992973129277500.
\end{aligned}
\tag{20}
\]

The positive rational margin (16) and the monotonicity proof, rather than these decimals, certify the contrast.

## 7. What is settled, and what is still separate

| Question | Result or limitation |
|---|---|
| Entire one-pass image for every positive gain | Exactly S^d, including zero, floors and ceilings |
| Exact condition for two-step existence in any finite dimension | Nonempty S^d intersect B; necessary and sufficient |
| Complete precursor description | Equation (11), with all scalar fibers included |
| Dependence on first positive gain | Nonemptiness is independent; precursor identities and geometry need not be |
| Singleton | Both signs accessible iff 0<m_2<=m_star; gain 1 obstructed, gain 1/2 accessible |
| Higher-dimensional explicit classification | Not supplied by the intersection criterion alone |
| Basin volume or sampling probability | Not established |
| Target fixedness at later gains | Separate condition F_m(u sigma)=u sigma |
| Attainability of the gain pair on the source's schedule | Not established |
| Historical initialization or binary floating-point execution | Not sampled or certified |

In higher dimensions, a zero intermediate coordinate need not stay zero: neighbors can contribute through T. The set S^d must therefore keep its zero coordinates; the singleton's sign-preservation obstruction must not be extended coordinatewise to coupled fields.

OC02's already accepted common fixed patterns provide particular nonempty cases without reclassification: if u sigma is known to be fixed at the chosen second gain, then Y=u sigma is in S^d intersect B and (10) applies. In particular this implication applies to its established common fixed patterns over [1/2,3/2]. It does not show that every sign pattern has such an intermediate or that a target stays fixed under an arbitrary later gain.

Positive gain 1/2 and positive gain 1 belong to the interval studied in OC02. Membership in that interval is not a proof that either value, or a chosen pair with m_1, is attained exactly on consecutive ticks of the normalized historical schedule. No schedule samples were generated here.

Theorem B answers the exact existence question through a geometric intersection. Turning that condition into a combinatorial classification for general N,M would require additional analysis. No dimensions, patterns or gain intervals beyond the specified finite checks were searched.

## 8. Executed evidence and candidate disposition

CHECK_RESULTS.json records eight executed groups, all PASS:

1. Source and input identities, with handoff archive CRC verification.
2. January source contracts, A02 angle convention, signed selection and singleton menu qualification.
3. Exact scalar-fiber endpoint identities.
4. Onto-witness and positive-gain inverse scaling algebra.
5. Singleton periodic-stencil cancellation, oddness and derivative identity.
6. Rigorous rational bounds for the singleton contrast.
7. Eleven fixed scalar compressor cases and four singleton sign/gain cases at 80 digits.
8. Consumed physical-input hashes unchanged after the checks.

The eleven cases are zero plus, for each sign, a floor interior input, floor endpoint, ordinary interior input, ceiling endpoint and ceiling interior input. The four singleton cases evaluate the second-stage scalar formula at Y=+u or -u and gain 1/2 or 1. No first-stage inverse was solved numerically, no field was evolved and no old source or checker was called.

The proposed range theorem, equivalence and singleton contrast are retained with proofs. The complete fibers and cutoff (18) are deductions in this report. The small-grid/app-menu qualification is a source-based clarification. None of these statements changes the original operators or the accepted one-step results.

## NEXT_QUESTION

For the unchanged 1×2 periodic stencil and the opposite-sign target (+u,-u), derive an explicit two-step access or obstruction criterion from S^2 intersect B, including intermediate vectors with a zero coordinate. This is one finite-dimensional recommendation, not a calculation started here.
