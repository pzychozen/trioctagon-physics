"""Additional read-only checks on SIM05 and the SIM04 saved-state addendum.
No simulation imports, evolve calls, new trajectory, or writes to the input.
"""
from pathlib import Path
import csv, hashlib, json, sys, zipfile
import numpy as np
from scipy.sparse.csgraph import connected_components
ROOT=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve()
def rows(f):
    with (ROOT/f).open(newline='',encoding='utf-8-sig') as h:return list(csv.DictReader(h))
def save(name,obj):
    def default(x):
        if isinstance(x,np.ndarray):return x.tolist()
        if isinstance(x,np.generic):return x.item()
        raise TypeError(type(x))
    (OUT/name).write_text(json.dumps(obj,indent=2,default=default,allow_nan=False)+'\n')
def graph(x):
    dist=np.linalg.norm(x[:,None]-x[None,:],axis=2);nn=np.argsort(dist,axis=1)[:,1:6]
    a=np.zeros((len(x),len(x)),bool);a[np.arange(len(x))[:,None],nn]=True
    _,lab=connected_components(a,directed=True,connection='weak')
    return a,lab,dist
raw=rows('originals/SIM04/deep_trajectory.csv');X=np.empty((21,50,3));R=np.empty((21,50))
assert len(raw)==1050
for row in raw:
    p=int(row['Pass']);i=int(row['Glyph_ID']);X[p,i]=[float(row[k]) for k in ['X','Y','Z']];R[p,i]=float(row['Resonance'])
ids=np.array([10,15,27,30,33,47]);table=[];pairrows=[];pair_endpoints=[]
for p in range(5,21):
    x=X[p,ids];y=x-x.mean(axis=0);cov=y.T@y/6;ev=np.linalg.eigvalsh(cov)[::-1];Rg=np.sqrt(np.trace(cov));d=np.linalg.norm(x[:,None]-x[None,:],axis=2)
    a,lab,ds=graph(X[p]);assert np.array_equal(np.flatnonzero(lab==lab[ids[0]]),ids)
    assert a[np.ix_(ids,ids)].sum()==30
    assert a[ids].sum()==30 and a[:,ids].sum()==30
    table.append(dict(pass_=p,Rg=Rg,diameter=d.max(),lambda1=ev[0],lambda2=ev[1],lambda3=ev[2],fraction1=ev[0]/ev.sum(),fraction2=ev[1]/ev.sum(),fraction3=ev[2]/ev.sum(),raw_min_eigenvalue=ev[-1]))
    for i in range(6):
        for j in range(i+1,6):pairrows.append(dict(pass_=p,glyph_i=int(ids[i]),glyph_j=int(ids[j]),distance=d[i,j],distance_over_Rg=d[i,j]/Rg))
recorded=rows('analysis/SIM04_six_geometry.csv');recpairs=rows('analysis/SIM04_six_normalized_pairs.csv')
assert len(recorded)==16 and len(recpairs)==240
err=max(abs(float(a[k])-float(b[k])) for a,b in zip(table,recorded) for k in a)
perr=max(abs(float(a[k])-float(b[k])) for a,b in zip(pairrows,recpairs) for k in a)
assert err<1e-12 and perr<1e-12
for i in range(15):
    a=pairrows[i];b=pairrows[-15+i];pair_endpoints.append(dict(pair=[a['glyph_i'],a['glyph_j']],pass5=a['distance_over_Rg'],pass20=b['distance_over_Rg'],change=b['distance_over_Rg']-a['distance_over_Rg']))
with np.load(ROOT/'replay/captured/states_and_rng.npz',allow_pickle=False) as f:z={k:f[k] for k in f.files}
# Check the seed/configuration initialization without constructing a simulator.
rng=np.random.RandomState(2038)
x0=rng.uniform(-5,5,(50,3));r0=rng.uniform(0,.3,50);d0=rng.uniform(0,.3,50)*.01
assert np.array_equal(x0,z['X'][0]) and np.array_equal(r0,z['R'][0]) and np.array_equal(d0,z['D'][0])
s=rng.get_state();assert np.array_equal(s[1],z['rng_keys'][0]) and s[2]==z['rng_pos'][0] and s[3]==z['rng_has_gauss'][0] and s[4]==z['rng_cached_gaussian'][0]
# Independently compare the SIM04 original bytes with the earlier submitted ZIP.
prior=Path('/mnt/data/SRG_SIMULATION_STUDY_04_SEED_EXPLORER_REVIEW.zip');prior_match={}
if prior.exists():
    with zipfile.ZipFile(prior) as ar:
        for n in ['deep_trajectory.csv','pass_metrics.csv','srg_seed_explorer.py','SRG_Deep_Analysis.md']:
            candidates=[k for k in ar.namelist() if k.endswith('/'+n) and ('originals/' in k or 'evidence/' in k)]
            assert len(candidates)==1,(n,candidates)
            prior_match[n]=ar.read(candidates[0])==(ROOT/'originals/SIM04'/n).read_bytes();assert prior_match[n]
# Check all final pair/candidate observer identities, retained in audit findings.
f=json.loads((OUT/'findings.json').read_text());parts=f['final_groups']
assert sum(g['N']*(g['N']-1)//2 for g in parts)==238
# H, stage windows, per-pass energy budgets: recompute from delivered intermediate arrays.
with np.load(ROOT/'analysis/intermediate_terms.npz',allow_pickle=False) as ar:st={k:ar[k] for k in ar.files}
windows={}
for name,sl in [('all',slice(0,200)),('early',slice(0,20)),('late',slice(100,200)),('last20',slice(180,200))]:
    windows[name]={k:float(np.sqrt(np.mean(st[k][sl]**2))) for k in ['local_R','local_D','cross_R','cross_D','H_effect_R','H_effect_D','sine_effect_R','local_X','fusion','position_residual']}
# Count each historical metric match without the label column; documents are not changed.
column_stats=rows('analysis/historical_replay_columns.csv')
ex_without=sum(int(r['exact_count']) for r in column_stats if r['column']!='pass');ex_with=sum(int(r['exact_count']) for r in column_stats)
assert ex_without==2785 and ex_with==2985
# CSV exports are convenient review outputs, not modifications to the study.
with (OUT/'final_components.csv').open('w',newline='') as h:
    keys=['label','N','ids','R_mean','R_std','D_mean','D_std','Rg','diameter','candidate_count','internal_echo_pairs']
    w=csv.DictWriter(h,fieldnames=keys);w.writeheader()
    for g in parts:w.writerow({k:';'.join(map(str,g[k])) if k=='ids' else g[k] for k in keys})
with (OUT/'SIM04_geometry_rechecked.csv').open('w',newline='') as h:
    w=csv.DictWriter(h,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
with (OUT/'SIM04_normalized_pair_changes.csv').open('w',newline='') as h:
    w=csv.DictWriter(h,fieldnames=['pair','pass5','pass20','change']);w.writeheader();w.writerows(pair_endpoints)
result=dict(SIM04_geometry_max_error=err,SIM04_normalized_pairs_max_error=perr,SIM04_component_and_30_edges_all16=True,SIM04_endpoint_geometry=[table[0],table[-1]],SIM04_min_fraction_range=[min(x['fraction3'] for x in table),max(x['fraction3'] for x in table)],SIM04_largest_normalized_pair_change=max(pair_endpoints,key=lambda x:abs(x['change'])),SIM04_diameter_rebound_18_to_19=table[14]['diameter']-table[13]['diameter'],SIM04_originals_match_prior_upload=prior_match,initialization_seed2038_arrays_and_rng_exact=True,initial_positions_equal_SIM04=np.array_equal(z['X'][0],X[0]),initial_R_3x_SIM04_max_error=float(np.max(np.abs(z['R'][0]-3*R[0]))),historical_exact_metric_entries=ex_without,historical_exact_with_pass_labels=ex_with,stage_window_rms=windows,no_new_simulator_updates=True)
save('supplemental_checks.json',result)
print(json.dumps(result,default=lambda x:x.item() if isinstance(x,np.generic) else x,indent=2))
