"""Copy only specifically consulted prior mathematical context; no checkers execute."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
items=[('R1_CLIPPING_AND_SPECTRAL_AUDIT/SRG_R1_REPORT.md','R1_REPORT.md'),('R2_AMPLIFICATION_AND_GEOMETRY/GPT_REVIEW_BRIEF.md','R2_REVIEW_BRIEF.md'),('R3_TRANSIENT_H_AND_SYNTHESIS/GPT_REVIEW_BRIEF.md','R3_REVIEW_BRIEF.md'),('R3_TRANSIENT_H_AND_SYNTHESIS/MATHEMATICAL_REVIEW.md','R3_MATHEMATICAL_REVIEW.md'),('OC06_JANUARY_TWO_STEP_ACCESS_01/REPORT.md','JANUARY_OC06_REPORT.md'),('SRG_SIGNED_GRID_REACHABILITY_PAPER_01/CLOSEOUT.md','JANUARY_PAPER_CLOSEOUT.md')]
assert not (ROOT/'PRESERVATION_CONTEXT_BASELINE.json').exists()
rows=[]
for rel,name in items:
    p=ROOT.parent/rel;b=p.read_bytes();rows.append(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    q=ROOT/'context/accepted_math'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(ROOT/'PRESERVATION_CONTEXT_BASELINE.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print('Copied six consulted context documents; no prior checks or simulations executed.')
