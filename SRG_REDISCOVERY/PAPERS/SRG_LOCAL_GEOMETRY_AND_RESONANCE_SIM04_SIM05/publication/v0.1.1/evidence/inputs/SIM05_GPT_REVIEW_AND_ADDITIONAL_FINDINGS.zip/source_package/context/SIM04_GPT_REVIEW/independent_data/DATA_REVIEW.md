# SIM04 independent saved-data review

**Verdict: numerical claims checked here are accepted within the stated historical-record scope. No substantive numerical correction is required.**

This review reads the supplied original CSVs and source as data/text. It does not import any supplied Python program, run a simulation, call a random-number generator, or propagate calculated endpoints. The independent script uses matrix calculations and a small reachability routine, rather than rerunning the package inspection script. Each transition calculation starts anew from the saved incoming state.

## Verification

- Exactly 1,050 ordered `(Pass, Glyph_ID)` rows: passes 0–20, IDs 0–49 within each pass. The schema, completeness, finite values and zero initial velocities match the report.
- All 240 aggregate values in the 20-row metrics file match independent recomputation exactly as parsed doubles.
- All 3,000 saved velocity components equal the corresponding saved position differences exactly.
- All 1,000 conditional next-resonance values match within `4.163336342344337e-17`. The package's sequential expression reports `1.3877787807814457e-17`; the matrix expression and different runtime here change arithmetic order. Both are at roundoff scale and comfortably satisfy the declared `1e-12` bound. This is not a substantive discrepancy.
- No lower or upper RPCO clipping activates in these 1,000 evaluations. All recorded amplitudes are positive.
- Position residuals agree with the package: population standard deviation `0.010015489534635932`, mean `-0.00010426606872480922`, maximum absolute component `0.03680452889275743`. These remain unresolved residuals, not recovered random draws or proof of their probability distribution.
- The neighbor cutoff minimum gap is `8.798022790323934e-5`; no cutoff tie affects the inspected graphs.
- Highest-resonance identities are 3 at passes 0–2, 40 at passes 3–5, and 38 at passes 6–20. Glyph 38's pass-6-to-20 endpoint displacement is `0.9861187493420075`, with saved-step path length `1.0313666220242348`.
- The first echo pair is IDs 5/43 at pass 7: distance `0.2308543251752029`, score `0.8697887482847164`.
- The final top three are 38, 23 and 8; their three pair distances reproduce the report exactly.

The independent environment is Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0. The supplied source and both CSV hashes match their stated identities. This does not re-certify the absent original archive, original software environment or historical RNG state.

## Global observation

Radius of gyration decreases at every saved transition, from `5.386371733197014` to `4.186458315433766`: a 22.2768401% reduction. Resonance population standard deviation also decreases at every saved transition, from `0.028332746849600417` to `0.007223413604847407`: a 74.5050713% reduction (93.5000861% reduction in variance). Coherence rises monotonically; maximum resonance falls monotonically. Mean resonance rises by 5.2698718% overall.

Thus this window supports simultaneous spatial contraction and amplitude equalization. These monotonic observations are not universal theorems for other initial states or longer runs.

## Graph chronology and additional component observations

Weak components: one at passes 0–4; two at passes 5–19; three at pass 20. Strong-component counts are 1 through pass 2, 2 at pass 3, 3 at passes 4–12, 4 at passes 13–14, 5 at passes 15–16, 6 at pass 17, and 7 at passes 18–20.

**The two-component membership at passes 5–19 is unchanged**, rather than repeatedly splitting and recombining with the same count. It is the 44-point remainder plus the six IDs `{10,15,27,30,33,47}`. Those six remain a weak component at pass 20.

| Actual final weak component | Size | Mean resonance | Resonance population std | Spatial diameter |
| --- | ---: | ---: | ---: | ---: |
| Component containing ID 0 | 21 | 0.050540943286000006 | 0.004861158917574455 | 5.599007023660057 |
| Component containing IDs 38,23,8 | 23 | 0.053849580779646924 | 0.004853662601130919 | 7.252586418018764 |
| IDs 10,15,27,30,33,47 | 6 | 0.035700719756164484 | 0.0004033296326504165 | 0.07378524362131371 |

The final top triad belongs to a **23-node weak component and an eight-node strong component**. It is a close selection by resonance ranking, not a separately isolated three-point subsystem.

The six-point component is particularly informative. At its first observed separation, pass 5, its diameter is `2.1700266130477375`, radius of gyration `1.036195894209367`, resonance std `0.007209363695907052`, and mean resonance `0.03589427514563215`. By pass 20 its diameter is `0.07378524362131371`, radius of gyration `0.035947984653217226`, resonance std `0.0004033296326504165`, and mean resonance `0.035700719756164484`. It becomes spatially tight and internally similar while retaining lower resonance than the rest of the field.

It contains exactly the six lowest final resonance values: its range is `[0.03517079398689678, 0.03638046558145359]`, while the minimum among the other 44 points is `0.04435115972879026`. Ranking only the strongest resonance values would overlook this compact group.

Every six-component member selects the other five as its neighbors: 30 internal directed edges, zero external directed edges. This is the complete directed six-node graph. **Six is the minimum possible isolated weak-component size under a five-distinct-neighbor rule**; it is not evidence of a sixfold geometric law. No claim about polyhedral shape follows from this graph.

At pass 20 the actual weak-group partition gives the exact descriptive variance split:

- Weighted within-group variance: `2.07811834012964e-5`.
- Between-group variance: `3.139652070539827e-5`.
- Total variance: `5.217770410669462e-5`.
- Between-group fraction: **60.1722924435%**.

This decomposition is about the final state and its actual final components. It supports the explanation that a globally more uniform field still retains distinguishable group means. It does not show exact internal consensus or persistent long-run separation. The two larger weak components are also spatially broad; “graph component” should not be casually equated with a compact spatial blob.

The pass-20 graph is an endpoint diagnostic: no saved pass-21 update used it. Earlier pass-p graphs are consumed by the p-to-p+1 update. The global resonance-weighted fusion center still couples positions across all these groups, so local disconnection is not independence of the full dynamics.

## Conditional mathematical reading supported by the same data

On these positive, unclipped amplitudes, the resonance step is `R_p = c_p A_(p-1) R_(p-1) + 1e-9 * 1`, where `A = 0.85 I + 0.15 W` and each row of W is the normalized inverse-distance neighbor weighting. A is row-stochastic and c_p is the shared positive product of the memory and sine factors.

Removing the common gain and the uniform epsilon offset converts this to ordinary time-varying convex averaging on the observed sequence of graphs. If `g_0=1`, `b_0=0`, `g_p=c_p g_(p-1)`, `b_p=c_p b_(p-1)+1e-9`, and `U_p=(R_p-b_p)/g_p`, then `U_p=A_(p-1) U_(p-1)` in exact algebra under the stated positive/unclipped conditions. The normalized maximum cannot increase and the normalized minimum cannot decrease. Direct checks confirm both in this record; normalized range shrinks by 74.5393169%.

This is a structural explanation for smoothing, not an independent claim of long-time consensus or an alternative simulated path. Global gains, fusion, clipping and noise retain their actual roles; the graph sequence itself depends on the full position history.

## Output files

- `verify_saved_data.py`: the independent procedure.
- `independent_checks.json`: full checks and summary quantities.
- `state_diagnostics.json`: per-state metrics and exact weak/strong memberships.
- `transition_diagnostics.json`: independent transition comparisons and terms.
- `fixed_final_partition_variance.json`: explicitly retrospective final-partition diagnostic for every stored state. Only its pass-20 row is used for the actual-component decomposition above.

Original files and supplied review outputs were unchanged. No external service, Git operation or new simulated trajectory was involved.
