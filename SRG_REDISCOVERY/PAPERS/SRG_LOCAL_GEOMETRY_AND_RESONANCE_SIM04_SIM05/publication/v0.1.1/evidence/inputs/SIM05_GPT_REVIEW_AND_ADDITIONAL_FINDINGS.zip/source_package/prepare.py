"""Static preparation only. Never imports or executes the historical program."""
from pathlib import Path
import ast, hashlib, json, zipfile, io, difflib, sys
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent.parent
R0=ROOT.parent/'R0_SOURCE_RECOVERY'
SIM04=ROOT.parent/'SRG_SIMULATION_STUDY_04_SEED_EXPLORER'
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
baseline=[]
def copy(p,dest):
    b=p.read_bytes(); baseline.append(dict(path=str(p),bytes=len(b),sha256=sha(b)))
    q=ROOT/dest;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    return b
def main():
    assert not (ROOT/'PREPARATION.json').exists(), 'Preparation is one-shot; preserve existing receipts.'
    order=copy(Path('C:/Users/Notandi/Downloads/SRG_SIMULATION_STUDY_05_INFINITY_CODEX_WORK_ORDER.md'),'context/AUTHORITATIVE_WORK_ORDER.md')
    hz=Path('C:/Users/Notandi/Downloads/SRG_SIM05_CODEX_HANDOFF.zip');hb=hz.read_bytes()
    baseline.append(dict(path=str(hz),bytes=len(hb),sha256=sha(hb)))
    z=zipfile.ZipFile(io.BytesIO(hb)); hm=json.loads(z.read('HANDOFF_MANIFEST.json'))
    for e in hm['files']:
        b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
    dump(ROOT/'context/HANDOFF_MANIFEST.json',hm)
    for n in ['START_HERE.md','context/NEXT_SELECTION_EVIDENCE.json']:
        p=ROOT/'context'/('HANDOFF_START_HERE.md' if n=='START_HERE.md' else 'NEXT_SELECTION_EVIDENCE.json');p.write_bytes(z.read(n))
    embedded=z.read('SRG_SIMULATION_STUDY_05_INFINITY_CODEX_WORK_ORDER.md')
    (ROOT/'context/EMBEDDED_WORK_ORDER.md').write_bytes(embedded)
    (ROOT/'context/WORK_ORDER_DIFF.txt').write_text(''.join(difflib.unified_diff(embedded.decode('utf-8-sig').splitlines(True),order.decode('utf-8-sig').splitlines(True),fromfile='embedded',tofile='authoritative separate')),encoding='utf-8')
    review=zipfile.ZipFile(io.BytesIO(z.read('context/SIM04_GPT_REVIEW_AND_ADDITIONAL_FINDINGS.zip')))
    for n in review.namelist():
        if n.endswith('/') or n.startswith('input/'): continue
        p=ROOT/'context/SIM04_GPT_REVIEW'/n
        assert p.resolve().is_relative_to(ROOT)
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(review.read(n))
    entries=json.loads((R0/'external_and_selected_sources.json').read_text())
    av=json.loads(copy(R0/'march_archive_verification.json','context/march_archive_verification.json'))
    archive=Path(av['original_path']);ab=archive.read_bytes()
    baseline.append(dict(path=str(archive),bytes=len(ab),sha256=sha(ab)))
    assert sha(ab)==av['sha256']
    az=zipfile.ZipFile(io.BytesIO(ab));records=[]
    for n in ['srg_infinity.py','srg_infinity_asymptotic.csv','SRG_Infinity_Seeds.md']:
        b=copy(R0/'selected_sources/MARCH_19023429'/n,'originals/'+n)
        assert b==z.read('originals_R0/'+n)==az.read(n)
        matches=[e for e in entries if e['package_path']=='selected_sources/MARCH_19023429/'+n]
        assert len(matches)==1
        rec=matches[0];op=Path(rec['original_path'])
        ob=op.read_bytes();baseline.append(dict(path=str(op),bytes=len(ob),sha256=sha(ob)))
        assert ob==b and sha(b)==rec['sha256'];records.append(rec)
    dump(ROOT/'context/SELECTED_ORIGIN_RECORDS.json',records)
    for n in ['deep_trajectory.csv','pass_metrics.csv','srg_seed_explorer.py','SRG_Deep_Analysis.md']:
        copy(SIM04/'originals'/n,'originals/SIM04/'+n)
    for n in ['START_HERE.md','CONSTRUCTION.md','VERIFICATION_AND_LIMITS.md','analysis/graph_components.json','analysis/directed_neighbors.csv','analysis/checks.json']:
        copy(SIM04/n,'context/SIM04/'+n)
    for n in ['SRG_R0_REPORT.md','external_and_selected_sources.json']:
        copy(R0/n,'context/R0/'+n)
    for p,d in [(ROOT.parent/'PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1/CROSS_STUDY_MECHANISM_MAP.md','VOLUME_I_MECHANISM_MAP.md'),(ROOT.parent/'PUBLICATION_WORK/V1_PUBLISH/PUBLICATION_RECEIPT.md','VOLUME_I_PUBLICATION_RECEIPT.md'),(ROOT.parent/'SIMULATION_RECONSTRUCTION_RESEARCH/SIMULATION_STUDY_LEDGER.md','CANONICAL_LEDGER_SNAPSHOT.md')]:
        copy(p,'context/'+d)
    src=(ROOT/'originals/srg_infinity.py').read_text(encoding='utf-8')
    lines=src.splitlines(keepends=True)
    core='import numpy as np\nimport pandas as pd\nfrom scipy.spatial.distance import pdist, squareform\n\n'+''.join(lines[42:55])+'\n'+''.join(lines[60:275])
    orig_ast=ast.parse(src);core_ast=ast.parse(core)
    def nodes(tree):
        return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['H','rpco','GlyphFieldInfinity']}
    assert nodes(orig_ast)==nodes(core_ast) and len(nodes(core_ast))==3
    def hmnode(tree):return next(ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='H_MAX' for t in n.targets))
    assert hmnode(orig_ast)==hmnode(core_ast)
    compile(core,'audited_core.py','exec') # syntax only; no execution
    (ROOT/'audited_core.py').write_text(core,encoding='utf-8',newline='\n')
    dump(ROOT/'CORE_IDENTITY.json',dict(original_sha256=sha((ROOT/'originals/srg_infinity.py').read_bytes()),core_sha256=sha((ROOT/'audited_core.py').read_bytes()),original_line_ranges=[[43,55],[61,275]],normalization='CRLF to LF only; three required imports prepended; original bytes retained',slice_exact=True,ast_exact=True,syntax_pass=True,original_module_imported=False))
    dump(ROOT/'PRESERVATION_BASELINE.json',baseline)
    dump(ROOT/'PREPARATION.json',dict(handoff_manifest_pass=True,source_archive_identity_pass=True,separate_order_sha256=sha(order),embedded_order_sha256=sha(embedded),orders_byte_identical=order==embedded,budget_used=0,core_static_gate=True,python=sys.version))
    print(json.dumps(dict(preparation='PASS',protected_files=len(baseline),order_same=order==embedded,source_lines=len(lines),budget_used=0)))
if __name__=='__main__':main()
