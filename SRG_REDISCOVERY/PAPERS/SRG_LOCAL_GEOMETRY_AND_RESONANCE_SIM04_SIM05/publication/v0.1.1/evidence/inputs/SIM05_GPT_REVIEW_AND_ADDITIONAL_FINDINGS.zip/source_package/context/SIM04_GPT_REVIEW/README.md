# SIM04 GPT review package

Start with **SIM04_GPT_SCIENTIFIC_REVIEW.md**. The verdict is scientific acceptance within the historical construction and saved-record scope, with two minor editorial/packaging cleanup items. Hilmir's review and discussion are the next checkpoint.

## Contents

- `SIM04_GPT_SCIENTIFIC_REVIEW.md`: complete review and additional findings.
- `REVIEW_RECEIPT.json`: machine-readable review disposition and limits.
- `additional_figure/`: new two-panel scientific figure (PNG/SVG), its script and exact plotted data.
- `independent_data/`: independent saved-data verifier and numerical results.
- `source_review.md`: source and mathematical review.
- `integrity_review.md` and `integrity_results.json`: package and publication-receipt checks.
- `input/`: complete, unchanged extracted payload of the submitted SIM04 review ZIP. The original nested manifest remains valid within this directory.
- `MANIFEST.json`: new review-bundle file identities, excluding this outer manifest itself.

## Reproducing this review

From this extracted directory, the reviewer procedures are:

```sh
python3 independent_data/verify_saved_data.py
python3 additional_figure/plot_six_component.py
```

They read the original CSV as data and write their own analysis results. They do not import or execute the historical simulator, generate random draws, or advance a simulated trajectory. Requirements are Python, NumPy, SciPy and Matplotlib. The verified numerical environment is recorded in `independent_data/independent_checks.json`. The supplied programs under `input/` remain preserved source evidence; running them is not part of this review workflow.

The plotted six-point diameter is on a logarithmic axis. Lines connect saved observations, with no reconstruction between passes. The group is isolated only in the local neighbor graph; all points remain coupled through global fusion. The final pass-20 graph has no corresponding saved pass-21 update.

Original Windows path references inside the preserved input retain their historical context. No canonical ledger or repository state is amended by this package.
