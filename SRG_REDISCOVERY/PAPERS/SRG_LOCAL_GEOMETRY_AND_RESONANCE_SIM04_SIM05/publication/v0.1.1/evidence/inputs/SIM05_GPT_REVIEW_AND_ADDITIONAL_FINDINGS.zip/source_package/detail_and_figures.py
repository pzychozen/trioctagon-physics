"""Derived tables and static figures from stored states only; no evolution or RNG draws."""
from pathlib import Path
import os,json,itertools
ROOT=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(ROOT/'render_cache')
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
A=ROOT/'analysis';F=ROOT/'figures';F.mkdir(exist_ok=True)
def read(n):return pd.read_csv(A/n,float_precision='round_trip')
def write(n,obj):(A/n).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csv(n,rows):pd.DataFrame(rows).to_csv(A/n,index=False,float_format='%.17g')
z=np.load(ROOT/'replay/captured/states_and_rng.npz');X=z['X'];R=z['R'];D=z['D'];V=z['V']
t=np.arange(201);s=np.load(A/'intermediate_terms.npz');graph=np.load(A/'graph_arrays.npz');labels=graph['weak_labels']
st=read('stage_summary.csv');ge=read('field_geometry.csv');gs=read('graph_summary.csv');sim4=read('SIM04_six_geometry.csv');pairs4=read('SIM04_six_normalized_pairs.csv')
groups=json.loads((A/'selected_groups.json').read_text());out={}
events=[]
for field in ['R','D']:
    for bound in ['lower','upper']:
        for p,i in np.argwhere(s[bound+'_'+field]):events.append(dict(pass_=int(p+1),glyph_id=int(i),field=field,bound=bound,pre_RPCO=float(s['pre_RPCO_'+field][p,i]),post_RPCO=float(s['post_RPCO_'+field][p,i])))
csv('clipping_events.csv',events)
window=[]
for name,lo,hi in [('all',1,200),('early',1,20),('late',101,200),('last20',181,200)]:
    row=dict(window=name,first_pass=lo,last_pass=hi)
    for k in ['local_R','local_D','cross_R','cross_D','H_effect_R','H_effect_D','sine_effect_R','local_X','fusion','position_residual']:
        row[k+'_rms']=float(np.sqrt(np.mean(s[k][lo-1:hi]**2)))
    row['cross_D_over_local_D']=row['cross_D_rms']/row['local_D_rms'];row['cross_R_over_local_R']=row['cross_R_rms']/row['local_R_rms'];window.append(row)
csv('stage_windows.csv',window)
out['cross_coefficient_sign_changes']=(np.where(np.sign(st.cross_coefficient.to_numpy()[1:])!=np.sign(st.cross_coefficient.to_numpy()[:-1]))[0]+2).tolist()
out['D_over_R_final_min_max']=[float((D[-1]/R[-1]).min()),float((D[-1]/R[-1]).max())]
out['D_squared_over_R_squared_final']=float(np.sum(D[-1]**2)/np.sum(R[-1]**2))
out['D_amplitude_ratio_rms']=float(np.sqrt(np.sum(D[-1]**2)/np.sum(R[-1]**2)))
out['final_component_variance']={}
for name,field in [('R',R),('D',D)]:
    within=sum(np.mean(labels[-1]==j)*np.var(field[-1,labels[-1]==j]) for j in np.unique(labels[-1]))
    total=float(np.var(field[-1]));out['final_component_variance'][name]=dict(total=total,within=float(within),between=float(total-within),between_fraction=float((total-within)/total))
leaders=np.argmax(abs(R),axis=1);runs=[];start=0
for p in range(1,202):
    if p==201 or leaders[p]!=leaders[start]:
        i=int(leaders[start]);runs.append(dict(start=start,end=p-1,glyph=i,states=p-start,path_length=float(np.linalg.norm(np.diff(X[start:p,i],axis=0),axis=1).sum()),endpoint_displacement=float(np.linalg.norm(X[p-1,i]-X[start,i]))));start=p
csv('leader_intervals.csv',runs);out['longest_leader_interval']=max(runs,key=lambda r:r['states'])
out['final_step_max_speed']=float(np.linalg.norm(V[-1],axis=1).max())
out['all_cutoff_gaps_positive']=bool((gs.min_neighbor_cutoff_gap>0).all());out['minimum_cutoff_gap']=float(gs.min_neighbor_cutoff_gap.min())
energy=[]
for p in range(200):
    row=dict(pass_=p+1)
    for field,arr,local,cross,posth,pre,post in [('R',R,'local_R','cross_R','post_H_R','pre_RPCO_R','post_RPCO_R'),('D',D,'local_D','cross_D','post_H_D','pre_RPCO_D','post_RPCO_D')]:
        vals=[arr[p],arr[p]+s[local][p],(arr[p]+s[local][p])+s[cross][p],s[posth][p],s[pre][p],s[post][p]]
        for k,value in zip(['incoming','mixed','crossed','post_H','pre_RPCO','post_RPCO'],vals):row[field+'_'+k]=float(np.sum(value**2))
    energy.append(row)
csv('squared_amplitude_stages.csv',energy)
# Validate retained SIM04 graph records against the addendum's exact selected identities.
edges=pd.read_csv(ROOT/'context/SIM04/analysis/directed_neighbors.csv',float_precision='round_trip');six=[10,15,27,30,33,47]
for p in range(5,21):
    q=edges[edges['pass']==p];inside=q.glyph.isin(six);target=q.neighbor.isin(six)
    assert int((inside&target).sum())==30 and int((inside^target).sum())==0
out['SIM04_retained_graph_all16_match']=True
pairchanges=[]
for (i,j),df in pairs4.groupby(['glyph_i','glyph_j']):pairchanges.append(dict(glyph_i=int(i),glyph_j=int(j),pass5=float(df.distance_over_Rg.iloc[0]),pass20=float(df.distance_over_Rg.iloc[-1]),change=float(df.distance_over_Rg.iloc[-1]-df.distance_over_Rg.iloc[0])))
csv('SIM04_pair_shape_changes.csv',pairchanges)
out['SIM04_fraction3_range']=[float(sim4.fraction3.min()),float(sim4.fraction3.max())]
out['SIM04_largest_pair_normalized_change']=max(pairchanges,key=lambda r:abs(r['change']))
write('detail_checks.json',out)
plt.rcParams.update({'font.size':10,'axes.titlesize':11,'figure.facecolor':'#fafafa','axes.facecolor':'#fafafa','savefig.facecolor':'#fafafa','axes.grid':True,'grid.alpha':.2,'font.family':'DejaVu Sans'})
colors=plt.colormaps['turbo'](np.linspace(.04,.96,50));register=[]
def save(fig,name,label,data):
    fig.savefig(F/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(F/(name+'.svg'),bbox_inches='tight');plt.close(fig)
    register.append(dict(id=name,png='figures/'+name+'.png',svg='figures/'+name+'.svg',evidence=label,data=data,inspection='pending'))
def points(ax,x,ids,title,limits=None,annotate=True,gray=False):
    ids=np.asarray(ids);ax.scatter(x[:,0],x[:,1],x[:,2],c=('#c2c7cc' if gray else colors[ids]),s=23,depthshade=False)
    if annotate:
        for i,pt in zip(ids,x):ax.text(*pt,str(i),fontsize=6,color='#253142')
    if limits is None:
        mid=(x.min(0)+x.max(0))/2;rad=max(float(np.ptp(x,axis=0).max())*.58,.001);limits=(mid-rad,mid+rad)
    lo,hi=limits;ax.set_xlim(lo[0],hi[0]);ax.set_ylim(lo[1],hi[1]);ax.set_zlim(lo[2],hi[2]);ax.set_box_aspect((1,1,1));ax.view_init(22,-55)
    ax.set_xlabel('X');ax.set_ylabel('Y');ax.set_zlabel('Z');ax.set_title(title);ax.tick_params(labelsize=7)
fig=plt.figure(figsize=(13,10),layout='constrained');fig.suptitle('SIM05 · REPRODUCED — 50 moving points, fixed IDs and equal spatial scale',fontsize=15)
for j,p in enumerate([0,20,100,200]):
    ax=fig.add_subplot(2,2,j+1,projection='3d');points(ax,X[p],range(50),f'Pass {p} | Rg = {ge.Rg.iloc[p]:.3f} | weak components = {gs.weak.iloc[p]}',(np.full(3,-5.5),np.full(3,5.5)),annotate=p==0)
    if p>=100:
        for k in np.unique(labels[p]):
            ids=np.where(labels[p]==k)[0];c=X[p,ids].mean(0);ax.text(*(c+np.array([.12,0,.12])),f'n={len(ids)}',fontsize=9)
save(fig,'F01_SIM05_whole_field','REPRODUCED',['replay/captured/glyph_states.csv','analysis/field_geometry.csv','analysis/graph_summary.csv'])
fig=plt.figure(figsize=(15,9),layout='constrained');fig.suptitle('SIM05 · REPRODUCED — two fixed final components, centered and divided by their own Rg\nSame coordinate orientation; no rigid alignment; axis limits shared',fontsize=13)
for row,g in enumerate(groups):
    ids=g['ids']
    for j,p in enumerate([20,100,200]):
        y=X[p,ids]-X[p,ids].mean(0);rg=float(np.sqrt(np.mean(np.sum(y*y,axis=1))));y/=rg
        kind='component' if p in g['actual_component_passes'] else 'retrospective subset'
        ax=fig.add_subplot(2,3,row*3+j+1,projection='3d');points(ax,y,ids,f'{len(ids)} points · pass {p} · {kind}\nRg before scaling = {rg:.5f}',(np.full(3,-2.5),np.full(3,2.5)))
save(fig,'F02_SIM05_selected_groups','REPRODUCED',['analysis/selected_groups.json','analysis/selected_group_geometry.csv','replay/captured/glyph_states.csv'])
fig,axs=plt.subplots(2,2,figsize=(13,8),layout='constrained');fig.suptitle('SIM05 · DERIVED from replay — actual stage contributions, not ablations',fontsize=14)
for ax,field,ks in [(axs[0,0],'R',['local_R','cross_R','H_effect_R','sine_effect_R']),(axs[0,1],'D',['local_D','cross_D','H_effect_D'])]:
    for k in ks:ax.semilogy(st.pass_,st[k+'_rms'].where(st[k+'_rms']>0),label=k.replace('_',' '))
    ax.set(title=field+' increment RMS (50 amplitudes)',xlabel='pass',ylabel='amplitude per pass');ax.legend(fontsize=8)
axs[1,0].plot(st.pass_,st.cross_coefficient,color='#8a437d');axs[1,0].axhline(0,color='black',lw=.7);axs[1,0].set(title='Cross coefficient cₚ = .08699 sin(.244p + π/2)',xlabel='pass',ylabel='cₚ (field increment also multiplies .01)')
for k in ['local_X','fusion','position_residual']:axs[1,1].semilogy(st.pass_,st[k+'_rms'],label=k.replace('_',' '))
axs[1,1].set(title='Spatial increment RMS (150 coordinates)',xlabel='pass',ylabel='coordinate increment');axs[1,1].legend(fontsize=9)
save(fig,'F03_SIM05_stages','DERIVED from REPRODUCED states',['analysis/stage_summary.csv','analysis/stage_windows.csv'])
fig,axs=plt.subplots(2,2,figsize=(13,8),layout='constrained');fig.suptitle('SIM05 · REPRODUCED — second real field stays positive, but changes and separates by group',fontsize=13)
im=axs[0,0].imshow(D.T,aspect='auto',origin='lower',extent=[-.5,200.5,-.5,49.5],cmap='viridis',vmin=0,vmax=D.max());axs[0,0].set(xlabel='pass',ylabel='fixed glyph ID',title='D amplitudes, all 10,050 values');fig.colorbar(im,ax=axs[0,0],label='D')
axs[0,1].plot(t,D.min(1),label='minimum');axs[0,1].plot(t,D.mean(1),label='mean');axs[0,1].plot(t,D.max(1),label='maximum');axs[0,1].axhline(0,color='black',lw=.7);axs[0,1].set(xlabel='pass',ylabel='D',title='Small does not mean zero');axs[0,1].legend()
axs[1,0].plot(t,np.sum(D*D,axis=1)/np.sum(R*R,axis=1));axs[1,0].set(title='Squared-sum ratio (not a pointwise amplitude ratio)',xlabel='pass',ylabel='ΣD² / ΣR²')
for j in np.unique(labels[-1]):
    ids=np.where(labels[-1]==j)[0];axs[1,1].scatter(R[-1,ids],D[-1,ids],s=35,label=f'component {j}: n={len(ids)}')
axs[1,1].set(xlabel='R at pass 200',ylabel='D at pass 200',title='Five actual endpoint components');axs[1,1].legend(fontsize=8)
save(fig,'F04_SIM05_second_field','REPRODUCED',['replay/captured/glyph_states.csv','analysis/component_geometry.csv'])
fig,axs=plt.subplots(2,2,figsize=(13,8),layout='constrained');fig.suptitle('SIM05 · REPRODUCED — finite contraction, graph separation and ongoing motion',fontsize=14)
axs[0,0].plot(t,ge.Rg,label='whole-field Rg');axs[0,0].plot(t,ge.diameter,label='diameter');axs[0,0].set(xlabel='pass',ylabel='coordinate units');axs[0,0].legend()
for j in range(1,4):axs[0,1].plot(t,ge['fraction'+str(j)],label=f'λ{j} / trace(C)')
axs[0,1].set(xlabel='pass',ylabel='covariance fraction',ylim=(0,1),title='Unweighted centered 3D spread');axs[0,1].legend()
axs[1,0].step(t,gs.weak,where='post',label='weak');axs[1,0].step(t,gs.strong,where='post',label='strong');axs[1,0].set(xlabel='saved pass (graph drives NEXT pass)',ylabel='component count');axs[1,0].legend()
axs[1,1].plot(t,ge.mean_speed,color='#167985');axs[1,1].set(xlabel='pass',ylabel='mean ‖Xₚ − Xₚ₋₁‖',title='Displacement remains nonzero at pass 200')
save(fig,'F05_SIM05_geometry_and_motion','REPRODUCED',['analysis/field_geometry.csv','analysis/graph_summary.csv'])
h4=pd.read_csv(ROOT/'originals/SIM04/deep_trajectory.csv',float_precision='round_trip');x4=h4[['X','Y','Z']].to_numpy().reshape(21,50,3)
fig=plt.figure(figsize=(16,5),layout='constrained');fig.suptitle('SIM04 · NEW ANALYSIS OF HISTORICAL DATA — six fixed IDs within the full field',fontsize=14)
for j,p in enumerate([0,5,10,20]):
    rest=[i for i in range(50) if i not in six]
    ax=fig.add_subplot(1,4,j+1,projection='3d');points(ax,x4[p,rest],rest,f'Historical saved pass {p}',(np.full(3,-5.5),np.full(3,5.5)),annotate=False,gray=True)
    ax.scatter(*x4[p,six].T,c=colors[six],s=35,depthshade=False)
    if p<=5:
        for i in six:ax.text(*x4[p,i],str(i),fontsize=7)
    else:ax.text(*(x4[p,six].mean(0)+np.array([0,0,.3])),'6 points',fontsize=9)
save(fig,'F06_SIM04_context','NEW ANALYSIS / VISUALIZATION OF SIM04 HISTORICAL DATA',['originals/SIM04/deep_trajectory.csv'])
fig=plt.figure(figsize=(15,10),layout='constrained');fig.suptitle('SIM04 · NEW ANALYSIS OF HISTORICAL DATA — shrinkage and relative shape are different\nFixed IDs 10, 15, 27, 30, 33, 47; no alignment, edges, hull or inferred surface',fontsize=14)
for j,p in enumerate([5,10,20]):
    pts=x4[p,six];y=pts-pts.mean(0);rg=np.sqrt(np.mean(np.sum(y*y,axis=1)));ax=fig.add_subplot(2,3,j+1,projection='3d');points(ax,y/rg,six,f'Pass {p}: centered / Rg\nActual Rg = {rg:.5f}',(np.full(3,-2),np.full(3,2)))
ax=fig.add_subplot(2,3,4);ax.semilogy(sim4.pass_,sim4.diameter,'o-',label='diameter');ax.semilogy(sim4.pass_,sim4.Rg,'s-',label='Rg');ax.set(xlabel='pass',ylabel='coordinate units',title='Scale; diameter rebounds at 18 → 19');ax.legend()
ax=fig.add_subplot(2,3,5)
for j in range(1,4):ax.plot(sim4.pass_,sim4['fraction'+str(j)],'o-',label=f'λ{j} / trace(C)')
ax.set(xlabel='pass',ylabel='fraction',ylim=(0,1),title='All three directions retain positive spread');ax.legend(fontsize=8)
ax=fig.add_subplot(2,3,6)
for (i,j),df in pairs4.groupby(['glyph_i','glyph_j']):ax.plot(df.pass_,df.distance_over_Rg,lw=1,alpha=.7)
ax.set(xlabel='pass',ylabel='fixed pair distance / Rg',title='All 15 identity-preserving pairs\nPair IDs and values supplied in CSV')
save(fig,'F07_SIM04_scale_and_shape','NEW ANALYSIS / VISUALIZATION OF SIM04 HISTORICAL DATA',['analysis/SIM04_six_geometry.csv','analysis/SIM04_six_normalized_pairs.csv','originals/SIM04/deep_trajectory.csv'])
(ROOT/'FIGURE_REGISTER.json').write_text(json.dumps(register,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2));print('Saved seven PNG/SVG figures. No evolution calls.')
