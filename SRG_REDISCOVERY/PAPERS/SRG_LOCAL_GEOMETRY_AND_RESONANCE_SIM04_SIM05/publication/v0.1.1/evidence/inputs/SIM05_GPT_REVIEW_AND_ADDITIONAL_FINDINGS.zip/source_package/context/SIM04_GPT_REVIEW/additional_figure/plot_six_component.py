"""Plot two observations from the saved historical SIM04 CSV.

No original program is imported, no trajectory is simulated, and no random
values are generated. Local graph isolation does not imply independence of
the full model: the global fusion center still couples positions.

Usage:
    python plot_six_component.py --input PATH/TO/deep_trajectory.csv
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os
import tempfile
import numpy as np
os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir())/'sim04_component_mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FuncFormatter, MultipleLocator


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    parser.add_argument('--input', type=Path, default=here.parent/'input/originals/deep_trajectory.csv')
    parser.add_argument('--output-dir', type=Path, default=here)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with args.input.open(newline='', encoding='utf-8-sig') as stream:
        records = list(csv.DictReader(stream))
    by_pass = {}
    for row in records:
        p, ident = int(row['Pass']), int(row['Glyph_ID'])
        by_pass.setdefault(p, {})[ident] = row
    group = [10, 15, 27, 30, 33, 47]
    group_set = set(group)
    diameters = []
    for p in range(5,21):
        assert set(by_pass[p]) == set(range(50))
        x = np.array([[float(by_pass[p][i][col]) for col in ('X','Y','Z')] for i in range(50)])
        distances = np.linalg.norm(x[:,None,:]-x[None,:,:],axis=2)
        neighbors = np.argsort(distances,axis=1)[:,1:6]
        assert all(set(neighbors[i]) == group_set-{i} for i in group)
        assert all(not(set(neighbors[i]) & group_set) for i in range(50) if i not in group_set)
        diameter = float(distances[np.ix_(group,group)].max())
        diameters.append({'Pass':p,'Diameter':diameter,'Isolated_weak_component':True})
    final = sorted([(i,float(by_pass[20][i]['Resonance'])) for i in range(50)],key=lambda item:(item[1],item[0]))
    ranks = [{'Rank':rank,'Glyph_ID':i,'Resonance':value,'In_six_point_component':i in group_set}
             for rank,(i,value) in enumerate(final,1)]
    assert {row['Glyph_ID'] for row in ranks[:6]} == group_set
    for filename,rows in [('six_component_diameters.csv',diameters),('final_resonance_sorted.csv',ranks)]:
        with (args.output_dir/filename).open('w',newline='') as stream:
            writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    metadata = {
      'classification':'New visualization of historical data; no simulation.',
      'source_filename':'deep_trajectory.csv',
      'source_sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),
      'group_ids':group,'k_neighbors':5,'six_is_actual_isolated_weak_component_at_all_plotted_passes':True,
      'coupling_qualification':'Local neighbor isolation only; global fusion still couples this group to the field.',
      'panel_A':{'quantity':'Maximum 3D pair distance among the six IDs','units':'source coordinate units','scale':'logarithmic y axis','rows':diameters},
      'panel_B':{'quantity':'All 50 resonance values at saved pass 20, sorted ascending','units':'source resonance values; no physical units assigned','rows':ranks},
      'line_convention':'Panel A segments join discrete saved observations; they do not recover between-pass motion.',
      'initial_plotted_diameter':diameters[0]['Diameter'],'final_plotted_diameter':diameters[-1]['Diameter'],
      'six_resonance_range':[ranks[0]['Resonance'],ranks[5]['Resonance']],
      'next_lowest_resonance':ranks[6]['Resonance'],
    }
    (args.output_dir/'figure_data.json').write_text(json.dumps(metadata,indent=2)+'\n')
    plt.rcParams.update({
      'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':13,'axes.labelsize':11.5,
      'xtick.labelsize':10.5,'ytick.labelsize':10.5,'axes.spines.top':False,'axes.spines.right':False,
      'axes.edgecolor':'#506070','axes.labelcolor':'#172B3A','text.color':'#172B3A',
      'xtick.color':'#334655','ytick.color':'#334655','svg.fonttype':'none',
    })
    amber = '#C56A09'
    blue = '#315E78'
    fig,axes = plt.subplots(1,2,figsize=(13.6,6.25),gridspec_kw={'width_ratios':[1,1.08]})
    fig.subplots_adjust(left=.075,right=.975,bottom=.22,top=.80,wspace=.24)
    fig.suptitle('SIM04  |  A compact group outside the highest-resonance ranking',
                 x=.075,y=.955,ha='left',fontsize=17,fontweight='bold')
    fig.text(.075,.888,'Same six glyphs: 10, 15, 27, 30, 33, 47.  Each is connected locally to the other five.',
             fontsize=11.5,color='#445B6B')
    ax=axes[0]
    p=np.array([row['Pass'] for row in diameters])
    d=np.array([row['Diameter'] for row in diameters])
    ax.plot(p,d,color=amber,lw=2.1,marker='o',ms=5.1,mec='white',mew=.7,zorder=3)
    ax.set_yscale('log')
    ax.set_xlim(4.5,20.5)
    ax.set_ylim(.05,3.3)
    ax.set_xticks([5,8,11,14,17,20])
    ax.yaxis.set_major_locator(FixedLocator([.05,.1,.2,.5,1,2]))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:g}'))
    ax.minorticks_off()
    ax.grid(axis='y',color='#E3E9ED',lw=.8,zorder=0)
    ax.set_xlabel('Saved pass')
    ax.set_ylabel('Group diameter (coordinate units; log scale)')
    ax.set_title('A   The local group contracts',loc='left',pad=13,fontweight='bold')
    ax.annotate('2.1700',xy=(5,d[0]),xytext=(7.2,2.5),fontsize=11.5,fontweight='bold',color=amber,
                arrowprops={'arrowstyle':'-','color':amber,'lw':1},va='center')
    ax.annotate('0.073785',xy=(20,d[-1]),xytext=(15.7,.062),fontsize=11.5,fontweight='bold',color=amber,
                arrowprops={'arrowstyle':'-','color':amber,'lw':1},va='center')
    ax.text(.03,.045,'16 recorded samples; no extrapolation',transform=ax.transAxes,fontsize=9.6,color='#536674',
            bbox={'facecolor':'white','edgecolor':'none','pad':2})
    ax=axes[1]
    rr=np.array([row['Rank'] for row in ranks])
    yy=np.array([row['Resonance'] for row in ranks])
    in_group=np.array([row['In_six_point_component'] for row in ranks])
    ax.scatter(rr[~in_group],yy[~in_group],s=31,color=blue,edgecolors='white',linewidths=.5,label='Other 44 glyphs',zorder=3)
    ax.scatter(rr[in_group],yy[in_group],s=48,color=amber,edgecolors='white',linewidths=.6,label='Same six-point component',zorder=4)
    ax.set_xlim(-.5,51)
    ax.set_ylim(.032,.064)
    ax.set_xticks([1,10,20,30,40,50])
    ax.yaxis.set_major_locator(MultipleLocator(.005))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value:.3f}'))
    ax.grid(axis='y',color='#E3E9ED',lw=.8,zorder=0)
    ax.set_xlabel('Rank among 50 glyphs at pass 20 (lowest first)')
    ax.set_ylabel('Resonance')
    ax.set_title('B   The same group has the lowest resonance',loc='left',pad=13,fontweight='bold')
    ax.annotate('All six lowest values',xy=(5.5,yy[5]),xytext=(14,.0366),fontsize=11,color=amber,
                arrowprops={'arrowstyle':'-','color':amber,'lw':1},va='center')
    handles,labels=ax.get_legend_handles_labels()
    ax.legend([handles[1],handles[0]],[labels[1],labels[0]],loc='lower right',frameon=False,
              fontsize=10,handletextpad=.45,borderaxespad=.7)
    fig.text(.075,.116,'New visualization of historical data from deep_trajectory.csv. No simulation was run.',fontsize=10.4,color='#445B6B')
    fig.text(.075,.074,'Isolation refers to the five-neighbor graph. The global fusion term still couples this group to the rest of the field.',fontsize=10.4,color='#445B6B')
    base=args.output_dir/'SIM04_six_point_component'
    fig.savefig(base.with_suffix('.png'),dpi=240,facecolor='white')
    fig.savefig(base.with_suffix('.svg'),facecolor='white')
    plt.close(fig)
    print(json.dumps({'png':str(base.with_suffix('.png')),'svg':str(base.with_suffix('.svg')),'diameters':diameters},indent=2))


if __name__=='__main__':
    main()
