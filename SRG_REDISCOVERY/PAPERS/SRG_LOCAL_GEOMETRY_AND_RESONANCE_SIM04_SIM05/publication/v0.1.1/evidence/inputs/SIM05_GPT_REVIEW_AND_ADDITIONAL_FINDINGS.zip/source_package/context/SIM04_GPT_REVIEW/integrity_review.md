# SIM04 integrity and publication-receipt review

**Verdict: package integrity passes; no scientific blocking defect identified in this review lane.** This is a review of package identity and supplied provenance, not of the historical mathematical findings.

## Independently recomputed from the supplied bytes

- ZIP: 1,372,925 bytes; SHA-256 `1a10bb9c2ad94789efc6d16d7a579a5e60346275ed8c44ac4a386e7799879025`.
- Exactly 52 unique ZIP members: 51 listed payload members plus `MANIFEST.json`. No missing, duplicate or unexpected entries. Every extracted payload length and SHA-256 matches its manifest row, and every extracted file matches its ZIP member bytes.
- All four `originals/` copies agree with the lengths and SHA-256 values in `SOURCE_PROVENANCE.json` and the preservation receipt. This independently establishes consistency of the submitted copies with the recorded identities. The original March archive and authoritative Windows originals were not re-opened here; archive-membership verification remains the supplied engineer's recorded check.
- Standalone uploaded `START_HERE(7).md` is byte-identical to the internal `START_HERE.md`: 5,453 bytes, SHA-256 `ae8a98b91c93cb088bd4509bcc2c3b98074e444ba75647499816b0ae2fd389a1`.
- Included R0 report and work order are byte-identical to the copies retained from GPT's previous turn.
- All 35 package-relative links recorded by `PACKAGE_VALIDATION.json` resolve in the supplied ZIP. These checks concern the five top-level review documents; links inside copied historical publication receipts point to their original workspace and are not all included here.
- The 23 baseline preservation entries plus one comparison-context supplement equal the 24 entries in `PRESERVATION_RECEIPT.json`, with identical recorded lengths/hashes. Independent access to the Windows working tree is unavailable; the no-Git-write, no-kernel-change and no-simulation execution-history assertions remain Codex's recorded statements. Static reading of the two data/plot scripts finds no original-script imports, RNG calls, `evolve` calls, `exec` or `eval` calls.

## Newly supplied Volume I receipt

`context/publication_receipt/PUBLICATION_RECEIPT.md` and `.json` have been read in full. They state `PUBLISHED_AND_REMOTE_BYTES_VERIFIED`, completed 22 October 2026 at 23:20:16 UTC, with:

- Commit `63469551eb04c17bfbedb6b8fce057c5890cbba8` and sole parent `170e638ecc0438f911c4ceb8091ffb1b574652fe`.
- Exactly 502 files and 72,789,875 bytes.
- 502/502 staged comparisons, 502/502 committed comparisons and 502/502 fresh commit-pinned HTTPS download comparisons.
- Publication manifest SHA-256 `e71386570f5bc48c93c9b17b7c039c490cc39757c5ea0875601f72e64a7725b8`.
- Accepted PDF SHA-256 `56489c2a4702ca05686cf47bd91faf6cf1981126f48191b8fb5b2b40aea61b9a` and 3,712,962 bytes.
- The normal push automatically triggered CI. Its quoted in-progress status is explicitly a historical observation, not a current status claim.

These identities agree with the handoff and the prior read-only GitHub check. The previously outstanding **receipt-received** checkpoint is now satisfied. However, this SIM04 ZIP includes only the Markdown and JSON summary receipts: `EXACT_PUBLICATION_FILE_LIST.json`, `stage_verification.json`, `commit_verification.json`, `remote_byte_verification.json` and the full publication closeout review bundle are referenced rather than included. It is accurate to say that the newly received Codex receipt records successful 502-file remote verification. It would overstate this review to say GPT independently recomputed all 502 remote hashes here.

Recommended user-facing administrative wording: “The final Volume I receipt is now included. It records 502/502 fresh remote-byte matches at the already confirmed commit, resolving the receipt gap from the handoff. I have checked its identities and consistency here; I have not repeated that full remote download audit.”

## Minor packaging wording issue

`START_HERE.md` says the prior receipt Markdown/JSON **and delivery identity** are copied under `context/publication_receipt/`. `prepare_evidence.py` lines 44–46 indeed copies the previous `DELIVERY_RECEIPT.json`, but `finalize_review.py` line 47 filters by basename and excludes **every** `DELIVERY_RECEIPT.json`, including this nested context receipt. Only the Markdown/JSON summary receipt files are in the ZIP. The prior delivery receipt's identity is nonetheless recorded in both preservation metadata files: 577 bytes and SHA-256 `e78557c2f51d681f073444bf2057aedc56e0e062f1c1fbada346c60c96b737dc`.

This is a small packaging/wording discrepancy with no effect on the source, saved records, figures or mathematics. It does not warrant blocking SIM04 scientific acceptance. At eventual packaging cleanup, either distinguish the copied receipt files from the delivery identity recorded in preservation metadata, or narrow the ZIP's exclusion rule to the **root** delivery receipt so copied historical receipt files remain included. No originals were changed here.

## Outputs

`integrity_results.json` retains exact member-level verification results. No supplied script was executed, no historical program imported, no simulation advanced, and no external operation or repository mutation performed in this review lane.
