import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform

def H(t):
    """REFU memory curve — the heartbeat of the recursion"""
    t = np.asarray(t, dtype=float)
    return (2.0*np.exp(-0.5*t)*np.cos(t) + 1.0*np.exp(-0.3*t)*np.sin(t)
            + 1.5*np.exp(-0.7*t) + 1.0*np.exp(-0.4*t))

def rpco(x, L=9.0, eps=1e-9):
    x = np.asarray(x, dtype=float)
    mag = np.abs(x) + eps
    z = np.clip(np.log(mag), -L, L)
    return np.sign(x) * np.exp(z)

H_MAX = float(np.max(np.abs(H(np.linspace(0, 100, 50000))))) + 1e-12

class GlyphFieldInfinity:
    """
    Extended glyph field with:
    - Phase-orthogonal (90°) dual recursion (matter + dark mirror)
    - GRF tracking per glyph
    - Vesica frequency modulation
    - Long-run asymptotic analysis capability
    """

    def __init__(self, N, R_range=(0, 0.1), spatial_range=(-5, 5), seed=None):
        if seed is not None:
            np.random.seed(seed)
        self.N = N
        self.positions = np.random.uniform(spatial_range[0], spatial_range[1], (N, 3))
        self.resonance = np.random.uniform(R_range[0], R_range[1], N)

        # Phase-orthogonal mirror field (the "dark" recursion)
        self.dark_resonance = np.random.uniform(R_range[0], R_range[1], N) * 0.01
        self.dark_phase_offset = np.pi / 2  # 90° offset

        self.velocities = np.zeros((N, 3))
        self.pass_count = 0

        # Parameters
        self.alpha = 0.05
        self.beta = 0.15
        self.lam_H = 0.05
        self.rpco_L = 9.0
        self.k_neighbors = 5
        self.omega_vesica = 0.244  # vesica piscis frequency from dark_energy.pdf
        self.gamma_srg = 0.08699  # the SRG coupling constant

        # Tracking
        self.metrics_history = []
        self.seed_history = []  # track top seed evolution
        self.grf_history = []   # GRF per glyph over time

    def _adjacency(self):
        dists = squareform(pdist(self.positions))
        adj = np.zeros((self.N, self.N))
        for i in range(self.N):
            neighbors = np.argsort(dists[i])[1:self.k_neighbors+1]
            adj[i, neighbors] = 1
        return adj, dists

    def _graph_laplacian(self, adj):
        lap = np.zeros_like(self.positions)
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) > 0:
                lap[i] = np.mean(self.positions[nbrs] - self.positions[i], axis=0)
        return lap

    def _resonance_coupling(self, adj, dists):
        R_new = self.resonance.copy()
        D_new = self.dark_resonance.copy()
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) == 0:
                continue
            w = 1.0 / (dists[i, nbrs] + 1e-8)
            w /= w.sum()

            # Matter resonance coupling
            R_nbr = np.sum(w * self.resonance[nbrs])
            R_new[i] += self.beta * (R_nbr - self.resonance[i])

            # Dark resonance coupling (90° phase shifted)
            D_nbr = np.sum(w * self.dark_resonance[nbrs])
            D_new[i] += self.beta * 0.5 * (D_nbr - self.dark_resonance[i])

            # Cross-coupling: matter↔dark via vesica frequency
            cross = self.gamma_srg * np.sin(self.omega_vesica * self.pass_count + self.dark_phase_offset)
            R_new[i] += cross * self.dark_resonance[i] * 0.01
            D_new[i] += cross * self.resonance[i] * 0.01

        return R_new, D_new

    def _compute_grf(self):
        """Glyph Retention Factor = 1/(1 + mean(|velocity|))"""
        vel_mag = np.linalg.norm(self.velocities, axis=1)
        return 1.0 / (1.0 + vel_mag)

    def _compute_curvature(self, adj, dists):
        """Local curvature per glyph from neighbor divergence"""
        curvature = np.zeros(self.N)
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) < 2:
                continue
            # Curvature from angle variance between neighbor pairs
            angles = []
            for j in range(len(nbrs)):
                for k in range(j+1, len(nbrs)):
                    v1 = self.positions[nbrs[j]] - self.positions[i]
                    v2 = self.positions[nbrs[k]] - self.positions[i]
                    cos_a = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-10)
                    angles.append(np.arccos(np.clip(cos_a, -1, 1)))
            curvature[i] = np.std(angles) if angles else 0
        return curvature

    def evolve_pass(self):
        self.pass_count += 1
        t = float(self.pass_count)
        old_pos = self.positions.copy()

        adj, dists = self._adjacency()

        # 1. Spatial: graph Laplacian
        lap = self._graph_laplacian(adj)
        self.positions += self.alpha * lap + self.beta * np.tanh(lap)

        # 2. Resonance coupling (matter + dark)
        self.resonance, self.dark_resonance = self._resonance_coupling(adj, dists)

        # 3. Memory modulation (weakens as t → ∞)
        h_t = H(t)
        mem_factor = 1.0 + self.lam_H * h_t / H_MAX
        self.resonance *= mem_factor
        # Dark field modulated by H with 90° phase shift
        h_dark = H(t + self.dark_phase_offset)
        self.dark_resonance *= (1.0 + self.lam_H * h_dark / H_MAX)

        # 4. Fusion pull toward resonance-weighted center
        center = np.average(self.positions, axis=0,
                          weights=np.abs(self.resonance) + 1e-8)
        fusion = (center - self.positions) * 0.03 * self.resonance[:, np.newaxis]
        self.positions += fusion

        # 5. Vesica frequency modulation
        self.resonance *= (1.0 - 0.001 * np.sin(t * self.omega_vesica * 2 * np.pi))

        # 6. RPCO compression on both fields
        self.resonance = rpco(self.resonance, L=self.rpco_L)
        self.dark_resonance = rpco(self.dark_resonance, L=self.rpco_L)

        # 7. Small tunneling noise (decreases with time for asymptotic study)
        noise_scale = 0.01 / (1 + 0.01 * t)  # decaying noise
        self.positions += np.random.normal(0, noise_scale, self.positions.shape)

        # Update velocities
        self.velocities = self.positions - old_pos

        # Record metrics
        self._record_metrics(adj, dists)

    def _record_metrics(self, adj, dists):
        t = self.pass_count
        R = self.resonance
        D = self.dark_resonance
        grf = self._compute_grf()
        curvature = self._compute_curvature(adj, dists)

        # Find proto-SRG-∞ seed candidates (R > 0.66 * max, Curvature > 0.012)
        R_norm = np.abs(R) / (np.max(np.abs(R)) + 1e-10)
        seed_mask = (R_norm > 0.66) & (curvature > 0.012)
        n_infinity_seeds = int(np.sum(seed_mask))

        top_idx = np.argmax(np.abs(R))

        # Spatial metrics
        center = np.mean(self.positions, axis=0)
        Rg = np.sqrt(np.mean(np.sum((self.positions - center)**2, axis=1)))

        # Coherence
        coh = 1.0 - np.std(R) / (np.mean(np.abs(R)) + 1e-8) if np.mean(np.abs(R)) > 1e-12 else 0

        # Echo corridors
        echo_count = 0
        for i in range(self.N):
            for j in range(i+1, self.N):
                R_sim = 1 - abs(R[i] - R[j]) / (np.max(np.abs(R)) + 1e-8)
                s_prox = np.exp(-dists[i,j] / 3.0)
                if R_sim * s_prox > 0.85:
                    echo_count += 1

        # Dark field energy
        dark_energy = float(np.sum(D**2))
        matter_energy = float(np.sum(R**2))
        dark_matter_ratio = dark_energy / (matter_energy + 1e-12)

        # Memory curve value at this pass
        h_val = float(H(t))

        metrics = {
            'pass': t,
            'R_max': float(np.max(np.abs(R))),
            'R_mean': float(np.mean(np.abs(R))),
            'R_std': float(np.std(R)),
            'dark_energy': dark_energy,
            'matter_energy': matter_energy,
            'dark_matter_ratio': dark_matter_ratio,
            'Rg': float(Rg),
            'coherence': float(coh),
            'n_echo_corridors': echo_count,
            'n_infinity_seeds': n_infinity_seeds,
            'top_seed_id': int(top_idx),
            'top_seed_R': float(R[top_idx]),
            'top_seed_grf': float(grf[top_idx]),
            'top_seed_curvature': float(curvature[top_idx]),
            'mean_grf': float(np.mean(grf)),
            'H_value': h_val,
            'mean_curvature': float(np.mean(curvature)),
            'top_seed_x': float(self.positions[top_idx, 0]),
            'top_seed_y': float(self.positions[top_idx, 1]),
            'top_seed_z': float(self.positions[top_idx, 2]),
        }
        self.metrics_history.append(metrics)

    def evolve(self, n_passes):
        for _ in range(n_passes):
            self.evolve_pass()

    def get_metrics_df(self):
        return pd.DataFrame(self.metrics_history)
