"""Two isolated, sequential, source-faithful executions. Never run a smoke step.
--check performs static/dependency gates only; --execute spends the single budget.
Fresh copies retain RUN_BUDGET.json deliberately: review should not rerun trajectories.
"""
from pathlib import Path
import ast, hashlib, json, sys, subprocess, os, platform, csv, datetime
ROOT=Path(__file__).resolve().parent
CONFIG=dict(N=50,R_range=[0,0.3],spatial_range=[-5,5],seed=2038,passes=200)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def gate():
    import numpy, scipy, pandas, matplotlib
    identity=json.loads((ROOT/'CORE_IDENTITY.json').read_text())
    assert sha(ROOT/'audited_core.py')==identity['core_sha256']
    assert sha(ROOT/'originals/srg_infinity.py')==identity['original_sha256']
    lines=(ROOT/'originals/srg_infinity.py').read_text(encoding='utf-8').splitlines(keepends=True)
    expected='import numpy as np\nimport pandas as pd\nfrom scipy.spatial.distance import pdist, squareform\n\n'+''.join(lines[42:55])+'\n'+''.join(lines[60:275])
    assert expected==(ROOT/'audited_core.py').read_text(encoding='utf-8')
    for p in [ROOT/'audited_core.py',Path(__file__)]:compile(p.read_text(encoding='utf-8'),str(p),'exec')
    info=dict(python=sys.version,executable=sys.executable,platform=platform.platform(),numpy=numpy.__version__,scipy=scipy.__version__,pandas=pandas.__version__,matplotlib=matplotlib.__version__,conda_default_env=os.environ.get('CONDA_DEFAULT_ENV'),core_sha256=identity['core_sha256'],config=CONFIG,static_gate=True)
    assert info['conda_default_env']=='torment'
    return info
def worker(label):
    import numpy as np
    from audited_core import GlyphFieldInfinity,H_MAX
    budget=json.loads((ROOT/'RUN_BUDGET.json').read_text())
    assert budget['reservations'][-1]['label']==label and budget['reservations'][-1]['reserved_calls']==200
    out=ROOT/'replay'/label;out.mkdir(parents=True,exist_ok=False)
    call_log=(out/'CALL_LOG.jsonl').open('x',encoding='utf-8')
    f=GlyphFieldInfinity(50,R_range=(0,0.3),spatial_range=(-5,5),seed=2038)
    states={k:[] for k in ['X','R','D','V','pass','rng_keys','rng_pos','rng_has_gauss','rng_cached_gaussian']}
    before=[];after=[]
    def rng():
        r=np.random.get_state();assert r[0]=='MT19937'
        return (r[1].copy(),r[2],r[3],r[4])
    def capture():
        for k,attr in [('X','positions'),('R','resonance'),('D','dark_resonance'),('V','velocities')]:states[k].append(getattr(f,attr).copy())
        states['pass'].append(f.pass_count)
        for k,v in zip(['rng_keys','rng_pos','rng_has_gauss','rng_cached_gaussian'],rng()):states[k].append(v)
    capture()
    for p in range(1,201):
        before.append(rng())
        call_log.write(json.dumps(dict(call=p,status='authorized immediately before call'))+'\n');call_log.flush();os.fsync(call_log.fileno())
        f.evolve_pass() # the only state-advance call site; exactly 200 iterations
        assert f.pass_count==p and len(f.metrics_history)==p
        after.append(rng());capture()
        if p%50==0:print(label,p,flush=True)
    call_log.close()
    a={k:np.asarray(v) for k,v in states.items()}
    for prefix,rs in [('before',before),('after',after)]:
        for j,k in enumerate(['keys','pos','has_gauss','cached_gaussian']):a['rng_'+prefix+'_'+k]=np.asarray([r[j] for r in rs])
    np.savez_compressed(out/'states_and_rng.npz',**a)
    dump(out/'metrics.json',f.metrics_history)
    with (out/'metrics.csv').open('w',newline='',encoding='utf-8') as h:
        w=csv.DictWriter(h,fieldnames=list(f.metrics_history[0]));w.writeheader();w.writerows(f.metrics_history)
    if label=='captured':
        with (out/'glyph_states.csv').open('w',newline='',encoding='utf-8') as h:
            w=csv.writer(h);w.writerow(['pass','glyph_id','X','Y','Z','R','D','VX','VY','VZ'])
            for p in range(201):
                for i in range(50):w.writerow([p,i,*a['X'][p,i],a['R'][p,i],a['D'][p,i],*a['V'][p,i]])
    rr=rng()
    assert all(np.asarray(rr[j]).tobytes()==np.asarray(after[-1][j]).tobytes() for j in range(4)), 'Recording changed RNG'
    dump(out/'EXECUTION.json',dict(label=label,complete_calls=200,state_count=201,glyph_records=10050,metrics_rows=200,H_MAX=H_MAX,config=CONFIG,rng_algorithm='MT19937',rng_records='201 boundaries plus explicit before/after arrays for every call',recording_rng_unchanged=True,core_sha256=sha(ROOT/'audited_core.py'),utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
def compare():
    import numpy as np
    a=np.load(ROOT/'replay/reference/states_and_rng.npz');b=np.load(ROOT/'replay/captured/states_and_rng.npz')
    checks={k:dict(shape=list(a[k].shape),dtype=str(a[k].dtype),bitwise=a[k].dtype==b[k].dtype and a[k].shape==b[k].shape and a[k].tobytes()==b[k].tobytes()) for k in a.files}
    for k in ['keys','pos','has_gauss','cached_gaussian']:
        assert b['rng_'+k][:-1].tobytes()==b['rng_before_'+k].tobytes()
        assert b['rng_'+k][1:].tobytes()==b['rng_after_'+k].tobytes()
    ma=(ROOT/'replay/reference/metrics.json').read_bytes();mb=(ROOT/'replay/captured/metrics.json').read_bytes()
    result=dict(arrays=checks,metric_outputs_serialized_identical=ma==mb,rng_boundary_continuity=True,all_pass=all(v['bitwise'] for v in checks.values()) and ma==mb)
    dump(ROOT/'REFERENCE_EQUIVALENCE.json',result);assert result['all_pass']
    print('BITWISE EQUIVALENCE PASS: all boundaries, metrics, complete RNG; 400 calls total.')
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--worker':worker(sys.argv[2])
    elif len(sys.argv)>1 and sys.argv[1]=='--check':print(json.dumps(gate(),indent=2))
    elif len(sys.argv)>1 and sys.argv[1]=='--execute':
        env=gate();assert not (ROOT/'RUN_BUDGET.json').exists(),'Budget already reserved: no rerun permitted'
        dump(ROOT/'ENVIRONMENT.json',env)
        budget=dict(maximum_calls=400,reservations=[],completed_calls=0)
        for label in ['reference','captured']:
            budget['reservations'].append(dict(label=label,reserved_calls=200))
            assert sum(x['reserved_calls'] for x in budget['reservations'])<=400
            dump(ROOT/'RUN_BUDGET.json',budget)
            subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'--worker',label],cwd=ROOT,check=True)
            budget['completed_calls']+=200;dump(ROOT/'RUN_BUDGET.json',budget)
        compare()
    else:raise SystemExit('Use --check (no trajectory) or the one-shot --execute.')
