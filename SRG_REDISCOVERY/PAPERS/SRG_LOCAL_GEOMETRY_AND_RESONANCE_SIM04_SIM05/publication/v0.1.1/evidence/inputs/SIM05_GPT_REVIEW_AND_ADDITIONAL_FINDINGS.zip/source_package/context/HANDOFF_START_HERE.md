# Next Codex assignment — SIM05 Infinity

**Authorized by Hilmir on 23 October 2026. GPT has selected the next step.**

Read and execute `SRG_SIMULATION_STUDY_05_INFINITY_CODEX_WORK_ORDER.md`. The authoritative Windows research root is:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY`

Create all new study work under `SRG_SIMULATION_STUDY_05_INFINITY` (or a documented sibling revision if that directory already contains unrelated/completed work).

## The assignment

1. Understand `srg_infinity.py` and audit its original 200-row metric record and historical claims.
2. Capture one faithful 50-glyph, seed-2038, 200-pass replay, plus the same-configuration reference execution needed to verify instrumentation. The total cap is **400 update calls**, including debugging. Preserve both real fields, positions, displacement, metrics and complete RNG checkpoints.
3. Complete a small 3D geometry addendum from the already saved SIM04 historical coordinates. Do not rerun SIM04.
4. Give a compact source-family and paper map, then return the complete review ZIP to GPT.

The full order defines the isolation, verification, evidence labels and stopping rules. It authorizes the bounded new replay; the previous SIM04 no-next-study instruction belonged to that completed assignment. Routine implementation decisions are Codex's to finish within the order. Hilmir is resting and need not reconstruct prior context or choose another model.

## Included context

- `context/SIM04_GPT_REVIEW_AND_ADDITIONAL_FINDINGS.zip` contains GPT's completed scientific review, independent checks, measured additional findings and the complete unchanged original SIM04 submission. Start with its `SIM04_GPT_SCIENTIFIC_REVIEW.md` if needed.
- `context/SRG_R0_REPORT.md` is the retained source-family survey. Its old proposed Tower II experiment is historical context, not the current task.
- `originals_R0/` holds unchanged copies of the exact Infinity script, historical CSV and accompanying historical note. Their bytes match the retained R0 manifest. The Windows recovered originals remain authoritative.
- `context/NEXT_SELECTION_EVIDENCE.json` records the selection basis and input identities.
- `HANDOFF_MANIFEST.json` identifies every handoff payload except itself.

The three old moving-center studies remain in Volume I. The March resonance-field models belong in a separate reconstruction paper or Volume II with explicitly separate recurrences. The intended finish line is Infinity, one representative Tower II construction/evidence study with short comparisons for the other March variants, and then manuscript drafting. This order starts only Infinity and its two small companions.

Return `SRG_SIMULATION_STUDY_05_INFINITY_REVIEW.zip` for GPT review. No Git write, publication, production/kernel integration or next engine is part of this assignment.
