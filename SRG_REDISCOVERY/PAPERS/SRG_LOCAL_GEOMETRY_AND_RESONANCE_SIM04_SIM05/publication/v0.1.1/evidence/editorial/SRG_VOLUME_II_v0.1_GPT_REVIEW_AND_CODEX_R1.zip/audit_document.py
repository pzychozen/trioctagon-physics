"""Read-only manuscript/package audit. No scientific script imports or executions."""
from __future__ import annotations
import hashlib, json, re, zipfile, argparse, collections
from pathlib import Path
import fitz

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()
def main() -> None:
    ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('output',type=Path);args=ap.parse_args()
    c=args.candidate.resolve();o=args.output; o.mkdir(parents=True,exist_ok=True)
    report={'scope':'file/document checks only; no numerical science rerun','simulation_updates':0,'scientific_checker_executions':0,'rng_draws':0}
    manifest=json.loads((c/'MANIFEST.json').read_text())
    errors=[]; rows=[]
    for e in manifest['files']:
        p=c/e['path']; b=p.read_bytes(); ok=len(b)==e['bytes'] and sha(b)==e['sha256']
        rows.append({'path':e['path'],'bytes':len(b),'sha256':sha(b),'matches_manifest':ok})
        if not ok:errors.append(e['path'])
    actual={p.relative_to(c).as_posix() for p in c.rglob('*') if p.is_file()}
    expected={e['path'] for e in manifest['files']}|{'MANIFEST.json'}
    report['manifest']={'payload_count':len(rows),'total_files':len(actual),'mismatches':errors,'unexpected':sorted(actual-expected),'missing':sorted(expected-actual),'files':rows}
    archives={'A4':zipfile.ZipFile(c/'evidence/inputs/SRG_SIMULATION_STUDY_04_SEED_EXPLORER_REVIEW.zip'), 'A5':zipfile.ZipFile(c/'evidence/inputs/SIM05_GPT_REVIEW_AND_ADDITIONAL_FINDINGS.zip')}
    report['immutable_input_upload_comparisons']=[]
    for name in ['SRG_SIMULATION_STUDY_04_SEED_EXPLORER_REVIEW.zip','SIM05_GPT_REVIEW_AND_ADDITIONAL_FINDINGS.zip']:
        p=c/'evidence/inputs'/name; q=Path('/mnt/data')/name
        report['immutable_input_upload_comparisons'].append({'name':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'independent_uploaded_copy_present':q.exists(),'identical_to_independent_upload':p.read_bytes()==q.read_bytes() if q.exists() else None})
    report['standalone_upload_comparisons']=[]
    for local,attached in [('manuscript.pdf','manuscript.pdf'),('manuscript.tex','manuscript(2).tex'),('START_HERE.md','START_HERE(9).md'),('evidence/AUTHORITATIVE_WORK_ORDER.md','SRG_SIM04_SIM05_MANUSCRIPT_HANDOFF/SRG_VOLUME_II_SIM04_SIM05_CODEX_MANUSCRIPT_WORK_ORDER.md')]:
        q=Path('/mnt/data')/attached
        report['standalone_upload_comparisons'].append({'candidate':local,'attachment':attached,'matches':(c/local).read_bytes()==q.read_bytes() if q.exists() else None})
    report['archives_crc']={k:z.testzip() for k,z in archives.items()}
    hash_index=collections.defaultdict(list)
    for label,z in archives.items():
        for info in z.infolist():
            if not info.is_dir(): hash_index[sha(z.read(info.filename))].append(label+': '+info.filename)
    copied=[]
    for p in sorted((c/'evidence').rglob('*')):
        if p.is_file() and p.parts[-2]!='inputs' and any(x in p.relative_to(c/'evidence').parts for x in ('originals','reviews','studies','tables')):
            matches=hash_index.get(sha(p.read_bytes()),[])
            copied.append({'path':p.relative_to(c).as_posix(),'identical_archive_members':matches})
    report['evidence_copy_matches']=copied
    reg=json.loads((c/'FIGURE_REGISTER.json').read_text());fs=[]
    for row in reg['selected']:
        label,member=row['archive_locator'].split(': ',1); b=(c/row['path']).read_bytes();ab=archives[label].read(member)
        fs.append({'figure':row['figure_number'],'path':row['path'],'identical_to_accepted_asset':b==ab,'registered_hash_matches':sha(b)==row['sha256']})
    report['figures']=fs
    tex=(c/'manuscript.tex').read_text(); refs=(c/'references.tex').read_text(); both=tex+'\n'+refs
    labels=re.findall(r'\\label\{([^}]+)\}',tex)
    label_uses=re.findall(r'\\(?:ref|eqref|pageref)\{([^}]+)\}',tex)
    bkeys=re.findall(r'\\bibitem(?:\[[^]]*\])?\{([^}]+)\}',refs)
    cite_groups=re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}',tex)
    cites=[v.strip() for g in cite_groups for v in g.split(',')]
    # The figure macro receives the label in its third argument: extract those labels as well.
    figlabels=re.findall(r'\}\{(fig:[^}]+)\}\{\}',tex)
    defined=set(labels)|set(figlabels)
    hrefs=re.findall(r'\\href\{([^}]+)\}',both)
    linkrows=[]
    for s in hrefs:
        t=s.removeprefix('run:')
        if not re.match(r'https?://',t):linkrows.append({'target':t,'exists':(c/t).exists()})
    claims=re.findall(r'^\| (C\d+) /', (c/'CLAIM_EVIDENCE_MATRIX.md').read_text(),re.M)
    report['tex_structure']={'labels':sorted(defined),'duplicate_explicit_labels':[k for k,v in collections.Counter(labels).items() if v>1],'reference_occurrences':len(label_uses),'unresolved_references':sorted(set(label_uses)-defined),'bibliography_entries':len(bkeys),'citation_occurrences':len(cites),'unresolved_citations':sorted(set(cites)-set(bkeys)),'propositions':tex.count('\\begin{proposition}'),'numbered_equation_source_environments':tex.count('\\begin{equation}')+tex.count('\\begin{align}'),'claim_rows':len(claims),'claim_ids':claims,'relative_tex_links':linkrows}
    doc=fitz.open(c/'manuscript.pdf');pages=[]; links=[];fonts={}; bad=[]
    for i,p in enumerate(doc):
        text=p.get_text()
        for link in p.get_links():
            rec={'page':i+1,'kind':link['kind']}
            if 'file' in link:
                target=link['file'];rec.update(target=target,exists=(c/target).exists())
            if 'page' in link:rec['destination_page']=link['page']
            if 'uri' in link:rec['uri']=link['uri']
            links.append(rec)
        # Text boxes are in unrotated page space; verify there, never against rotated rect.
        bounds=p.mediabox
        for block in p.get_text('dict')['blocks']:
            if block.get('type')!=0:continue
            for line in block.get('lines',[]):
                for span in line['spans']:
                    bb=fitz.Rect(span['bbox'])
                    if not bounds.contains(bb):bad.append({'page':i+1,'text':span['text'],'bbox':list(bb),'pagebox':list(bounds)})
        for f in p.get_fonts(full=True):
            xref=f[0]
            if xref not in fonts:
                name,ext,typ,data=doc.extract_font(xref);fonts[xref]={'name':name,'type':typ,'embedded_bytes':len(data)}
        pages.append({'pdf_page':i+1,'rotation':p.rotation,'width':p.rect.width,'height':p.rect.height,'text_length':len(text),'image_count':len(p.get_images()),'replacement_character': '\ufffd' in text,'literal_unresolved_marker':'??' in text})
    report['pdf']={'page_count':len(doc),'sha256':sha((c/'manuscript.pdf').read_bytes()),'tex_sha256':sha((c/'manuscript.tex').read_bytes()),'metadata':doc.metadata,'pages':pages,'links':links,'font_embedding':list(fonts.values()),'text_outside_media_box':bad}
    report['manuscript_digest_matches_receipts']={}
    for f in ['FINAL_BUILD_RECEIPT.json','DOCUMENT_QA.json','PAGE_INSPECTION.json']:
        d=json.loads((c/f).read_text());report['manuscript_digest_matches_receipts'][f]=d.get('pdf_sha256')==report['pdf']['sha256']
    report['windows_filesystem_limit']='Local hashes verify delivered bytes and available earlier uploads; reported Windows worktree preservation and zero executions are not independently witnessed host telemetry.'
    (o/'document_integrity.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    summary={'manifest_count':len(rows),'manifest_errors':len(errors),'unexplained_files':sorted(actual-expected),'copied_evidence_files':len(copied),'unmatched_evidence_copies':[r['path'] for r in copied if not r['identical_archive_members']],'figures_pass':all(r['identical_to_accepted_asset'] and r['registered_hash_matches'] for r in fs),'propositions':report['tex_structure']['propositions'],'claims':len(claims),'bibitems':len(bkeys),'unresolved_refs':report['tex_structure']['unresolved_references'],'relative_links':len(linkrows),'missing_tex_links':[r for r in linkrows if not r['exists']],'pdf_pages':len(doc),'pdf_links':len(links),'missing_pdf_file_links':[r for r in links if 'exists' in r and not r['exists']],'text_outside':bad,'all_fonts_embedded':all(f['embedded_bytes']>0 for f in fonts.values())}
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
