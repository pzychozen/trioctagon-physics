"""Read-only verification of submitted SRG publication files; writes results outside payload."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,difflib,re
R=Path('/mnt/data/srg_pub_final_review/input')
P=R/'payload/SRG_REDISCOVERY/PAPERS/SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1'
O=Path('/mnt/data/srg_pub_final_review/results');O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check_rows(base,rows,key='path'):
 for a in rows:
  p=base/a[key];assert p.is_file() and p.stat().st_size==a['bytes'] and sha(p)==a['sha256'],str(p)
 assert len(rows)==len({a[key] for a in rows})
 return len(rows)
res={}
m=json.loads((R/'REVIEW_PACKAGE_MANIFEST.json').read_text())
res['review_member_hashes']=check_rows(R,m['files'])
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
assert actual=={a['path'] for a in m['files']}|{'REVIEW_PACKAGE_MANIFEST.json'}
res['review_member_count']=len(actual)
m=json.loads((P/'PUBLICATION_FILE_MANIFEST.json').read_text())
res['publication_payload_hashes_except_manifest']=check_rows(P,m['files'])
actualpub={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}
assert actualpub=={a['path'] for a in m['files']}|{'PUBLICATION_FILE_MANIFEST.json'}
stage=json.loads((R/'preparation/EXACT_PUBLICATION_FILE_LIST.json').read_text())
res['staged_file_identities']=check_rows(R/'payload',stage,key='repository_path')
assert {a['repository_path'] for a in stage}=={str(p.relative_to(R/'payload')) for p in P.rglob('*') if p.is_file()}
textstage=(R/'preparation/PROPOSED_STAGING_FILES.txt').read_text().splitlines()
nulstage=(R/'preparation/PROPOSED_STAGING_FILES.nul').read_bytes().decode('utf-8').rstrip('\0').split('\0')
assert textstage==nulstage==[a['repository_path'] for a in stage]
res['staging_lists_exact_and_no_extra_paths']=True
res['payload_bytes']=sum(a['bytes'] for a in stage)
res['review_zip_sha256']=sha(Path('/mnt/data/SRG_VOLUME_I_v0.1.1_PUBLICATION_REVIEW.zip'))
res['publication_manifest_sha256']=sha(P/'PUBLICATION_FILE_MANIFEST.json')
res['publication_pdf_sha256']=sha(P/'MANUSCRIPT/volume_i.pdf')
assert (P/'MANUSCRIPT/volume_i.pdf').read_bytes()==Path('/mnt/data/volume_i(2).pdf').read_bytes()
res['separate_uploaded_pdf_matches_payload']=True
bpath=P/'provenance/accepted_editorial_v0.1.1.zip'
assert bpath.read_bytes()==Path('/mnt/data/SRG_VOLUME_I_EDITORIAL_R1_GPT_REVIEW.zip').read_bytes()
changes=[];diffs=[];same=[]
with ZipFile(bpath) as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.startswith('MANUSCRIPT/'):
   a=z.read(n);p=P/n
   if not p.is_file():changes.append({'path':n,'missing':True});continue
   if a==p.read_bytes():same.append(n)
   else:
    changes.append({'path':n,'old_sha256':hashlib.sha256(a).hexdigest(),'new_sha256':sha(p)})
    if n.endswith(('.tex','.md')):
     diffs.extend(difflib.unified_diff(a.decode('utf-8').splitlines(True),p.read_text().splitlines(True),fromfile='accepted/'+n,tofile='publication/'+n))
 (O/'accepted.pdf').write_bytes(z.read('MANUSCRIPT/volume_i.pdf'))
res['manuscript_changed_files']=changes;res['manuscript_byte_identical_count']=len(same)
(O/'independent_manuscript_diff.diff').write_text(''.join(diffs))
# Compare copied studies to the actual previously supplied archives, not solely their included manifests.
studies=[('SRG_SIMULATION_CONSTRUCTION_01','SRG_SIMULATION_CONSTRUCTION_01_REVIEW.zip'),('SRG_SIMULATION_CONSTRUCTION_02','SRG_SIMULATION_CONSTRUCTION_02_GPT_REVIEW.zip'),('SRG_SIMULATION_REPLAY_01','SRG_SIMULATION_REPLAY_01_REVIEW.zip'),('SRG_SIMULATION_STUDY_03_PLOT1','SRG_SIMULATION_STUDY_03_PLOT1_GPT_REVIEW.zip')]
comparisons=[]
for study,name in studies:
 copied=P/'evidence/SRG_REDISCOVERY'/study
 with ZipFile(Path('/mnt/data')/name) as z:
  mn=next(n for n in z.namelist() if n=='MANIFEST.json' or n.endswith('/MANIFEST.json') and n.count('/')<=1)
  prefix=mn[:-len('MANIFEST.json')]
  manifest=json.loads(z.read(mn));rows=manifest.get('package_files',manifest.get('files'))
  assert (copied/'MANIFEST.json').read_bytes()==z.read(mn)
  for row in rows:
   rel=row['path'];assert (copied/rel).read_bytes()==z.read(prefix+rel),rel
  comparisons.append({'study':study,'payloads_match_original_uploaded_zip':len(rows),'manifest_matches':True})
res['independent_study_archive_comparisons']=comparisons
# Identify stale current status without treating preserved historical receipts as current status.
pattern=re.compile(r'awaiting review|review candidate|draft awaiting|not authorized|not been staged|publication is not',re.I)
hits=[]
for p in (P/'MANUSCRIPT').rglob('*.tex'):
 for i,line in enumerate(p.read_text().splitlines(),1):
  if pattern.search(line):hits.append({'path':str(p.relative_to(P)),'line':i,'text':line})
res['current_manuscript_status_hits']=hits
res['verification_passed']=True
(O/'independent_checks.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
print(json.dumps(res,indent=2,ensure_ascii=False))
