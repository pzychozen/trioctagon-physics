# SRG Simulation Reconstruction Volume I v0.1.1 — publication review

**Reviewer:** GPT  
**Date:** 22 October 2026  
**Disposition:** Scientific acceptance retained; publication integrity checks pass; one required publication-status consistency correction (**PUB-01**) before final approval of the exact publishable payload.  
**Git authority:** No staging, commit, push, release or publication authorized or performed by this review.

## 1. Reviewed identities

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Submitted publication review ZIP | 60,467,308 | `5647a1f99d291ba7f893f6bd08ecd60a546d4748cef836353e982ca0dc0980db` |
| Publication PDF | 3,712,951 | `0ed0b424a4121f0892589bd4837820d1fcfda4c2042006073760e41bfe3aaae8` |
| Publication file manifest | 108,169 | `d7ff67b5b1383f8d8d38b17f6081ab7c5234f66b22ff70b9948eda7b08d9ccab` |
| Exact publication file list | 147,626 | `e755092cf82c848a1265e04baa1525965821f164c14b0b10c92dc9c5c34ba7ac` |
| Proposed staging text list | 78,020 | `f73e41a733ff640827d3cb8cbe9d41ea4114e21f2e5f3dae1d389e9ad1a8c850` |

The separate uploaded PDF matches the PDF in the publication payload byte for byte. The accepted R1 archive embedded in provenance matches the separately supplied accepted R1 archive byte for byte.

## 2. Checks actually performed

The ZIP was safely extracted into a review-only container workspace. Full CRC readback passed. Its 524 manifest-listed members passed byte-length and SHA-256 comparison; the root manifest is the 525th archive member. Duplicate/member-list and exact payload membership checks passed.

The proposed publication tree has **496 files totaling 68,280,372 bytes**. Its manifest covers 495 files and is itself accounted for by the outer review manifest and exact staging file list. The JSON, text and NUL-delimited staging lists identify exactly the same 496 publication files, with no extra repository paths.

After reading its code, I ran the supplied **read-only publication integrity verifier**, not a simulator or scientific-results checker. All its assertions passed: 116 accepted R1 archive payloads; 374 study payloads; 66 indexed evidence items; 102 claim source markers; 17 figures; 35 assets; 16 unchanged displayed equation/align environments; 63 unique labels; 44 resolved reference occurrences; 12 bibliography entries; and 390 local Markdown link occurrences.

I separately verified the outer/package/staging manifests using independent code. I also compared all 374 copied study payloads and their four manifests directly to the four earlier uploaded study archives, not merely to their newly copied manifests. All match.

An independent local-path pass also found all 390 relative Markdown link targets present in the detached payload. This does not certify external URLs or make historical absolute Windows references into live GitHub links. Those references remain explicitly contextualized archival material. General heading fragments were not comprehensively audited; the supplied verifier additionally checks supported line-number fragments.

## 3. Accepted-content and presentation comparison

Direct manuscript comparison found only these four changed files under MANUSCRIPT:

- `volume_i.tex`: cover, PDF metadata and running-header status;
- `sections/06_agenda.tex`: final review-status paragraph;
- `README.md`: publication-copy and build/access guidance;
- `volume_i.pdf`: corresponding rebuilt PDF.

The other **63 manuscript files** match the accepted edition byte for byte. Source comparison confirms unchanged science, figures, original programs and bibliography. The normalized independent diff is included in this review package.

Both 53-page PDFs were rendered independently with Poppler at 110 dpi. Excluding only the first 100 pixel rows containing running headers, **50 page bodies are pixel-identical**. The three differing bodies are physical pages 1, 41 and 45. Extracted body text matches on **51 pages**; only cover/status pages 1 and 45 differ. Page 41 contains unchanged source/text with a table-layout difference.

I visually inspected full-resolution publication pages 1, 41 and 45 and the status passage on page 9. The inspected cover, table, closing paragraph and status passage are readable without observed clipping or overlap. This is a difference-based publication review, not a claim to have manually reread every scientific line or every archival movie in this turn. No manuscript build was run during this review.

## 4. PUB-01 — remaining current-status inconsistency

The cover and section 6.6 correctly state that scientific/editorial review is complete. However, physical page 9 (printed page 3), in section 1.3, still says:

> This manuscript itself is a draft awaiting review.

Exact source: `MANUSCRIPT/sections/01_scope.tex`, lines 104–105, C07.

The current C07 entry in both `CLAIM_EVIDENCE_MATRIX.md` (line 25 in this submission) and `records/claims.json` also says `manuscript remains in review`. C102's current register entry still uses draft-stage review wording/support even though its manuscript paragraph has been updated.

These are administrative status statements, not errors in the equations or observations. They should nevertheless agree before publishing the exact edition. The README's treatment of old appendices and archived review notices as historical provenance does not explicitly make the present-tense C07 statement a historical quotation.

Required resolution:

1. Replace only the current C07 sentence with: **“Scientific and editorial review is complete; publication requires separate authorization.”**
2. Synchronize only C07/C102 status/support wording in the current claim matrix and JSON with the closure receipt and publication work order. Preserve the other 100 claim entries and all IDs.
3. Update the publication verifier's exact allowlist to recognize these narrowly specified administrative changes, without relaxing scientific/evidence checks.
4. Rebuild the separate publication PDF, inspect affected pages, refresh diffs/checksums/manifests and return the resealed identities.

Accepted R1 bytes, original studies, historical review records and the canonical ledger must remain unchanged. Scientific acceptance and editorial E01/E02 closure are not reopened. The attached narrow Codex work order gives the precise scope.

## 5. Git boundary and navigation

A read-only live GitHub request confirmed `pzychozen/trioctagon-physics` main at `170e638ecc0438f911c4ceb8091ffb1b574652fe`, matching the preparation checkpoint at the time of this review. The root README was also read at that commit. No GitHub writes occurred.

This does not verify the present Windows working tree, index or protected-file inventory. Those remain Codex's recorded local checks and must be refreshed before any future staging.

The proposed 496-file staging list contains only the new edition directory. The optional root/SRG README additions remain outside that list and are not authorized by this review. Current archive status is preparation only; no publication success is claimed.

## 6. What remains

One metadata-only consistency correction and its new sealed identities. No new scientific review, simulation, seed search, numerical experiment, historical recovery or kernel change is needed to close PUB-01.

The exact submitted payload is not yet approved for a push. After the narrow correction is reviewed, owner authorization can identify the exact final file set and hashes. Actual publication must then be verified from committed/remote bytes rather than inferred from local preparation.

## Review evidence

This package includes independent manifest/source/link/PDF comparison results, the readback from the supplied read-only verifier, the normalized manuscript diff, the independent hash/source comparison script, and rendered pages showing the relevant status and layout. The script uses the review container paths; it is an audit record, not a Windows execution instruction.

No submitted artifact was edited. All review outputs were written separately. No simulation, scientific checker, manuscript compiler, staging, commit, push or release was executed.
