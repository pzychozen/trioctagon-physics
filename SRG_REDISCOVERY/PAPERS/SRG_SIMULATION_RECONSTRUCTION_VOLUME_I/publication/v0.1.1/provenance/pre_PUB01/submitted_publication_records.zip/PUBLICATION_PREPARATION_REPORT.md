# Volume I publication preparation

Hilmir, the accepted volume is ready as a separate publication candidate. It still explains the same three historical simulations. The source equations, numerical evidence and conclusions are preserved. This preparation packages the supporting evidence so that readers can follow the links without your local research workspace.

Status: **scientifically accepted; editorially closed; publication payload prepared for final authorization. Not staged, committed, pushed, released or published by this task.**

## Prepared result

- Edition v0.1.1, 22 October 2026; author Hilmir Frímann Halldórsson; scientific lead GPT; research engineering and manuscript preparation Codex.
- 53 physical pages, 17 numbered figures, 35 image assets and 102 mapped claims.
- [Publication PDF](MANUSCRIPT/volume_i.pdf): 3,712,951 bytes, SHA-256 `0ed0b424a4121f0892589bd4837820d1fcfda4c2042006073760e41bfe3aaae8`.
- [Landing page](PUBLICATION_README.md), complete LaTeX, all required assets, mathematical mechanism map, claim/evidence and figure registers, build instructions and read-only integrity checker.
- All 374 manifest-listed payloads of the four accepted study packages, four original manifests, all 66 volume-indexed evidence items, accepted R1 archive and GPT editorial closure. Original movies and logs are included. Historical labels and uncertainty are preserved.

## Changes and conventions

The repository already uses SRG_REDISCOVERY/PAPERS/<paper>/publication/<edition> with a README, sources, provenance and checksums. This copy uses the requested SRG_SIMULATION_RECONSTRUCTION_VOLUME_I/publication/v0.1.1 directory. The root and SRG landing READMEs remain unchanged; proposed navigation additions are supplied separately in the preparation review ZIP.

Only two LaTeX files differ from the accepted edition: the main file's cover, PDF metadata and running header, and the final status paragraph in section 6.6. That paragraph now records completed scientific/editorial review while leaving publication and future experiments as separate decisions. The surrounding science, all 16 displayed equation/align environments, numeric statements, captions and bibliography are unchanged. The [exact diff](provenance/PUBLICATION_CHANGES.diff) also covers the manuscript README, evidence-index introduction and 118 hyperlink relocations. The JSON evidence index gains publication paths while retaining accepted paths and hashes. Newly authored publication documents/checker are listed explicitly in the manifest; the changed PDF has its own identity.

The accepted appendices retain their historical workspace and compact-review-package descriptions. The publication README and build guide explain their context and give the current self-contained paths. No canonical ledger update is made; the included ledger is an unchanged snapshot.

## Verification and preservation

[Publication verification](PUBLICATION_VERIFICATION.md) records the build, complete source/manifest checks, link checks, exact accepted comparison and visual review. The accepted R1 PDF and ZIP identities match GPT's closure receipt. All 116 accepted archive payloads and all 374 study payloads were hash-verified before copying. No original simulator, replay harness or scientific checking routine was executed.

The source checkpoint is main at `170e638ecc0438f911c4ceb8091ffb1b574652fe`. The index hash is `ff88a675346bdf5aba858329039f400af037fceea1eaa6334586d681c4dbfb4f`. The preparation baseline hashes 4,056 accepted/protected and tracked files, and inventories size/mtime for 30,881 existing repository files. Full coverage and exclusions are stated in the preservation receipt; this is not a claim to hash all unrelated untracked bytes. Existing Git entries, protected bytes and inventoried metadata must remain unchanged. Only this new publication directory and its separate preparation/build workspace are written.

Compiler binaries, TeX caches, temporary page rasters, unrelated research and earlier study ZIP duplicates are excluded from the staging payload. No payload depends on adding an untracked historical directory later. The exact file list, proposed staging list, source checkpoint, proposed commit message and post-publication procedure accompany the review ZIP. No Git mutation has been performed.

## Approval boundary

The [work order](instructions/PUBLICATION_WORK_ORDER.md) explicitly authorizes publication preparation only and prohibits staging, commits, pushes, releases and publication. The complete package is returned for GPT and Hilmir to review before that separate authorization. No further experiment or manuscript reconstruction is initiated.
