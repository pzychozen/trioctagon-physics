# Publication verification

This is publication-integrity verification, not a new scientific experiment. Saved numerical results were copied and hash-checked, not recomputed.

| Check | Result |
|---|---|
| Accepted baseline | Exact R1 ZIP and PDF match the subsequent GPT closure; 116 archive payloads pass CRC, size and SHA-256 checks. |
| Historical evidence | All 374 payloads in four accepted study manifests pass; all 66 indexed evidence items are included with matching hashes. |
| Scientific comparison | Only main TeX metadata/cover/header and section 6.6 status text differ. All 16 displayed equation/align environments, source programs, figure includes/assets and bibliography are unchanged. |
| Claims and references | All 102 claim IDs resolve to the same source markers and lines; 63 labels are unique; all label references and 12 bibliography entries resolve. |
| Figures | All 17 numbered figure includes and 35 asset hashes match; the compiler's figure list contains 17 entries. |
| PDF/source consistency | Exact distributed TeX/image/program inputs match the isolated build inputs; build succeeded. Final PDF identity appears in the preparation report and build receipt. |
| PDF quality | 53 pages; zero overfull boxes, undefined references, missing glyph warnings, replacement characters or unresolved question-mark pairs. The accepted abstract underfull warning (badness 1077) remains. |
| Accepted PDF comparison | After excluding only the running-header strip, 50 page bodies are pixel-identical. 51 pages retain identical extracted body text. Cover and closing status paragraph change; page 41 has unchanged source/text with a typesetter table-layout difference. |
| Visual inspection | Cover and all page layouts/running headers inspected; final page 41 table and page 45 status text inspected at full size. No clipping, collision or unreadable new status text found. See the final visual-review receipt. |
| Evidence links | All active local Markdown links must resolve inside the exact payload, with case-sensitive path checks suitable for GitHub. Local absolute provenance strings and historical archived references are not advertised as live GitHub paths. |
| Publication seal | Complete exact-member manifest and SHA-256 checksums are verified by the read-only checker. The review ZIP's CRC, member list and byte identities are verified separately; ZIP hash is in the external delivery receipt to avoid self-reference. |
| Preservation | Protected file hashes, complete accepted directories, canonical ledger, Git HEAD/index and pre-existing Git entries remain unchanged. Unrelated inventoried file sizes/mtimes are also compared. |

Machine-readable records: [PDF and input comparison](records/pdf_comparison.json), [visual review](records/visual_review.json), [static content/link checks](records/content_checks.json), [preservation](records/preservation_after.json), [build receipt](records/build_receipt.json) and [manifest](PUBLICATION_FILE_MANIFEST.json). Run [the read-only checker](tools/verify_publication.py) from a complete extracted payload to repeat integrity checks.

The final publication manifest hashes every payload file except itself. SHA256SUMS.txt hashes all payload files except itself and the manifest; the manifest covers SHA256SUMS.txt. The external preparation receipt supplies the manifest and review-ZIP hashes. No checksum is made self-referential.

No remote publication has happened, so live GitHub links to this new edition cannot yet be tested. Their relative targets are all included in the proposed file list. The proposed post-publication procedure requires a fresh clone of the authorized pushed commit, the same checksum/relative-link checks, and GitHub browser checks of the landing page, PDF, source and original media/logs. Existing external dependency URLs are retained provenance, not newly certified network services.

No fresh dependency download or cross-platform build was attempted. The pinned compiler and copied cache were verified and reused in isolation. No claim is made that an alternate compiler/environment produces byte-identical PDF output.
