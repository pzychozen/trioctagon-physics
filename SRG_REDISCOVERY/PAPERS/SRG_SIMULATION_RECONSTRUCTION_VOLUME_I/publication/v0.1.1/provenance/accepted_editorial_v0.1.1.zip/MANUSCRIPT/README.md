# Manuscript source and candidate PDF

The editable source is [volume_i.tex](volume_i.tex), with eight section files, references and seventeen figure includes. [volume_i.pdf](volume_i.pdf) is the corrected candidate compiled from that source: edition 0.1.1, editorial R1, awaiting closure review. GPT accepted the scientific content with minor editorial revisions. The reviewed edition 0.1 remains unchanged in the sibling VOLUME_I_01 directory.

The figures are selected accepted evidence. F03 and F04 use exact declared crops of already-existing replay sheets for readable panel layout; no data plot or trajectory was generated. See the root figure register for hashes and crop rectangles. Small original program copies are included under sources/; they are never imported by the manuscript build.

From Windows Command Prompt, activate the requested environment and change to this volume root. In a fresh extracted Windows copy, obtain the pinned compiler before building. If build/toolchain/tectonic.exe is already present, skip the acquisition command. First-time dependency acquisition requires network access; the compiler and build cache are excluded from the ZIP, and the first build may fetch uncached TeX dependencies.

    call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
    cd /d C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\SIMULATION_RECONSTRUCTION_RESEARCH\VOLUME_I_01_R1
    python -B tools\acquire_typesetter.py
    python -B tools\build_pdf.py

The acquisition script obtains pinned Tectonic 0.17.0 and checks its release asset digest; no system-wide installation is required. The builder expects build/toolchain/tectonic.exe. For this editorial closeout, the verified compiler and cached dependencies were copied from the prior workspace; acquisition was not rerun.

Alternative build route: a compatible XeLaTeX setup with the specified fonts/packages can compile this LaTeX project. This is separate from the supplied Windows commands. Cross-environment byte identity is not promised.

The standard standalone Codex LaTeX compiler does not support this project's additional section/figure files, so the candidate uses a recorded local project build. The build tools do not execute original source or scientific checkers.

Use the root REVIEW_REPORT.md for actual compilation and PDF inspection results, not merely file existence. Large original movies/logs and accepted numerical receipts remain linked to repository-relative locations in FIGURE_AND_MEDIA_REGISTER.md and EXTERNAL_EVIDENCE_INDEX.md.
