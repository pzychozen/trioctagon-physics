# Editorial R1 closure report

**Edition:** 0.1.1, editorial R1. **Scientific lead:** GPT. **Author / research direction:** Hilmir Frímann Halldórsson. **Preparation:** Codex. **Status:** E01–E02 applied; awaiting editorial closure review. **Date:** 22 October 2026.

## Scope and review authority

The user's request identifies the achieved first-volume milestone and confines remaining work to editorial closeout. The supplied GPT review accepts the scientific content with minor editorial revisions. Its E01–E02 identify the corrections; it explicitly does not authorize publication, canonical-ledger changes or another simulation.

The attachment at Downloads/volume_i.pdf is byte-identical to the reviewed candidate: 3,711,816 bytes, SHA-256 4180aaa47a7f95cfd2fd0b857dc98415339387652f1f0d3107af6a7aeaa979c7. The original review ZIP and manifest also match the identities in GPT's review. The supplied review is copied unchanged under instructions/.

No separate Volume I review ZIP, independent-readback results file or review checker was found among the supplied attachments or matching Downloads files. The review document itself supplies the exact corrections and records GPT's independent findings. Those findings remain attributed to GPT; no missing script or result has been invented, and no scientific readback was repeated.

The corrected edition is in the sibling VOLUME_I_01_R1 directory. The whole previous VOLUME_I_01 directory, including its PDF, source, records, ZIP and build files, remains unchanged.

## Correction closure

| Item | Applied change | Verification |
|---|---|---|
| E01, Appendix A | Restored spacing in “800 by 800”, “60 fps”, “20 fps”, “rows / 1,092”, “rows / 440” | Whitespace-stripped source is identical to edition 0.1; physical PDF pages 46–47 visually checked |
| E01, Table B.1 | Restored spacing in “All 2,000”, “relations; 31”, “independent 20”, “All 18” | No values or non-whitespace characters changed in the pre-build section; physical PDF page 49 checked |
| E01, registers | Same prose-level spacing pass in the claim matrix, mechanism map and open-question register | Only whitespace changes; all link targets, hashes and claim IDs preserved; JSON claim wording kept consistent |
| E02, Appendix B.2 and README | Fresh copies run acquisition before build; existing compiler permits skipping acquisition; network and excluded-cache requirements explicit; XeLaTeX kept separate | Instructions inspected against the unchanged acquisition/builder scripts; physical PDF page 50 checked |
| Edition identification | Cover identifies 0.1.1 / editorial R1 and the scientific acceptance verdict, with closure review pending | Physical PDF page 1 checked |

Only four manuscript source/document files changed: volume_i.tex, sections/07_provenance.tex, sections/08_reproducibility.tex and MANUSCRIPT/README.md. The [complete editorial diff](review/EDITORIAL_R1.diff) includes these and the whitespace-only register changes.

Chapters 1–6, the bibliography source, all three historical program copies, all 17 figure includes and all 35 image assets are byte-identical to the reviewed edition. The 102 claim source locations still resolve. There are 63 unique labels with resolved references. Equation bodies, numerical findings and provenance qualifications are unchanged, including the strong but formally UNLINKED S03 movie/log relationship.

Appendix B.4 retains the initial volume's historical preservation account. Its earlier ledger update occurred during edition 0.1 preparation. It is not a new ledger action during R1. Historical receipts are segregated in baseline/; current R1 receipts are in records/ and review/.

## Build and PDF inspection

All Python/build/check work used Windows Command Prompt and conda environment torment. The pinned Tectonic 0.17.0 executable and TeX cache were copied from the verified existing workspace; compiler acquisition was not rerun. The original compiler provenance is retained, with a separate [reuse receipt](records/compiler_reuse.json). Neither build script was modified.

The initially longer editorial folder name exceeded Windows' path limit for one cached TeX filename. The new draft folder was shortened to VOLUME_I_01_R1 before building; the local cache copy then completed. No historical file, equation or tool behavior was changed to handle this path issue.

Commands used from this volume root after activating torment:

    python -B tools\space_register_prose.py
    python -B tools\build_pdf.py
    python -B tools\inspect_pdf.py --render
    python -B tools\check_closeout.py
    python -B tools\package_closeout.py
    python -B tools\verify_delivery.py

The build produces 53 physical pages: cover, five Roman-numbered pages, and printed pages 1–47. The extra build guidance moves the bibliography start from printed page 45 to 46. Contents and generated references are refreshed. The resulting PDF is 3,713,461 bytes with SHA-256 a051db660e8f1632fdd9a185f1a1f82e7db0133c6040e5b4d1656f4d1eba78f9.

All 53 pages were rendered at 110 dpi. Ten changed/new physical pages were visually inspected: **1, 5, 41, 46, 47, 49, 50, 51, 52, 53**. The other 43 page rasters are byte-identical to the previously inspected candidate. The changed page 41 has unchanged scientific source and a typesetting layout difference; its table and text remain clear. No clipping, collisions, missing figures or broken glyphs were found.

The final log has zero overfull boxes and zero undefined-reference messages. The same previously accepted underfull abstract paragraph remains (badness 1077); its raster is unchanged. Text extraction finds no replacement characters or unresolved “??” markers. The [visual receipt](review/visual_review.json) ties the page comparisons and inspection to the final PDF hash.

## Preservation and integrity

The closeout preservation baseline covers **939 existing files**: the original 397-file protected set, the complete previous Volume I directory including build files, the canonical ledger and the two review attachments. All byte lengths and SHA-256 hashes remain unchanged. This is an explicitly scoped set, not a certification of every repository file.

The canonical ledger remains unchanged, SHA-256 adf3eb82bc940139eecb3ea48e3ccb3cf5c7b942a202d18d21dda364de2c2526. Git HEAD remains 170e638ecc0438f911c4ceb8091ffb1b574652fe; the index SHA-256 remains ff88a675346bdf5aba858329039f400af037fceea1eaa6334586d681c4dbfb4f. All 220 pre-existing status entries are unchanged.

See [closeout checks](records/closeout_checks.json), [baseline](records/closeout_before.json), and the manifest for exact coverage. The package includes full corrected source/PDF/figures, active registers, the supplied review, historical baseline receipts, diff and current preservation/build records. The compiler, cache, page rasters, redundant TeX intermediates and external movies/logs are excluded.

The manifest lists payload byte lengths and SHA-256 hashes. ZIP integrity is verified by full CRC readback and comparison of every member against the manifest and live payload. The post-archive receipt remains outside the ZIP to avoid a self-hash cycle. The included delivery verifier performs read-only file/archive checks and executes no scientific source.

## Stop

No new simulation, scientific-checker rerun, numerical readback investigation, equation modification, historical-data correction, canonical-ledger mutation, staging, commit, push or publication occurred. GPT and Hilmir receive this corrected candidate for the narrow E01–E02 closure review. The remaining SRG investigations stay open and unstarted.
