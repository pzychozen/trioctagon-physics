# Volume I — editorial R1 closeout

Hilmir, the scientific reconstruction in Volume I is accepted with minor editorial revisions. This separate candidate makes those two revisions. It does not reopen the three experiments, add findings or begin another simulation.

The [corrected PDF](MANUSCRIPT/volume_i.pdf) is edition **0.1.1, editorial R1**, awaiting GPT/Hilmir closure review. It has 53 pages, 17 numbered figures, 35 figure assets and the same 102 mapped claims. The added build instructions account for the extra page.

- **E01:** corrected joined words/numbers in Appendices A/B and the human-readable registers. No values, formulas, identifiers, hashes, source filenames or historical chart pixels changed.
- **E02:** the PDF and [README](MANUSCRIPT/README.md) now tell a fresh Windows user to acquire the pinned compiler before building, explain when acquisition can be skipped, and state the network/cache requirements. The existing builder and acquisition scripts are unchanged.
- **Edition identification:** the cover now identifies editorial R1 and GPT's scientific acceptance with minor editorial revisions. Closure review and publication remain separate.

Chapters 1–6, mathematical equations, bibliography source, historical program copies, figure includes and all image assets are byte-identical to the reviewed edition. The original candidate, its ZIP, accepted packages and canonical ledger remain untouched.

Read the [closure report](REVIEW_REPORT.md) and the [narrow diff](review/EDITORIAL_R1.diff) to review the changes. The supplied [GPT review](instructions/SRG_VOLUME_I_GPT_SCIENTIFIC_REVIEW.md) is preserved verbatim. The independent readback package/checker mentioned in the message was not among the supplied files or matching Downloads files; its numerical work was not repeated.

The review ZIP includes the full corrected manuscript source, PDF, selected figures, registers, review, diff, hashes and preservation receipts. Full movies/logs remain linked through the [external evidence index](EXTERNAL_EVIDENCE_INDEX.md). The previous edition remains in the sibling VOLUME_I_01 directory; baseline receipts copied here are explicitly historical.

This is the editorial finish of the first volume, not completion of SRG. No ledger update, publication, staging, commit, push or next investigation is part of this closeout.
