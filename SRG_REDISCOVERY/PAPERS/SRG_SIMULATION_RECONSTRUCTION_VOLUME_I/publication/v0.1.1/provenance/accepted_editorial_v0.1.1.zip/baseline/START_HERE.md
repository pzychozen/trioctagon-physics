# SRG Simulation Reconstruction Volume I

Hilmir, this first volume explains three original programs by following what they actually store, calculate and display. Their most revealing common feature is **carried velocity**: a point can continue moving in one direction even after its current interaction points the other way. Their most consequential difference for interpretation is **how they record time and movement**.

The manuscript is a **review candidate**, with GPT as scientific lead. It integrates the three accepted studies; it does not run another simulation, extend the earlier path-inheritance proofs or introduce physical assumptions.

## The three constructions

**Three-point attraction.** The first program places three points in two dimensions, starts their velocities at zero, and updates them in order 0,1,2. Each responds to the other two. After 500 sweeps it draws all three trails as a static picture. Its surviving historical PNG has no recovered seed or ordered log.

A separately authorized seed-0 reproduction supplies a known chronology. Two points approach to about 0.00004424 coordinate units at the end of sweep 169, then separate on the next sweep. A third point moves the other way along much the same visible diagonal. These are observations of the reproduction, not a reconstruction of the lost run behind the original picture. Overlapping trails do not establish simultaneous coincidence or a leader-following route.

**Eight tetrahedral centers.** The second program moves eight centers in three dimensions. Each tetrahedron is a fixed drawing around its center; its corners do not calculate forces. Each center responds to an arithmetic average of the currently stored coordinates. Because the centers take turns, later ones see earlier moves.

Its historical movie survives. It shows changing arrangements, a specific screen relocation between frames 13 and 14, and slower visible movement later. The numerical history does not survive in a certified form. We therefore explain how the source permits wrapping and centroid changes without assigning an invented velocity or travel distance to that relocation.

**Binary response switching.** The third program retains the centroid construction and adds a per-body switch that can reverse the new interaction contribution. Its original logs show a center first slowing after a switch, then moving away two callbacks later. The switch does not erase its previous velocity.

Those logs also contain 1,092 and 440 updates despite only 200 nominal movie labels. Labels repeatedly return to zero while the state continues. This restarts a strong prescribed H value and accompanies bursts in the recorded kinetic quantity. It is not spontaneous creation of a physically conserved energy.

## The distinctions worth keeping

- **Native movement versus a coordinate jump.** The largest checked native increments in the two original eight-body logs are below 0.062 units. A coordinate can nevertheless jump from near 0 to near 10 through wrapping.
- **A real turn versus a detector warning.** Body7 crosses the X boundary three times while retaining one mode, and its VX genuinely changes sign. Separately, the source's unsigned-modulo “teleport” diagnostic would flag thousands of ordinary movements. Its flags and actual seam crossings are different counts.
- **A clock argument versus an update count.** H reads the supplied frame label, not an accumulated elapsed time. Repeated callbacks therefore matter.
- **An original artifact versus a certified original run.** The third movie closely matches selected saved states from logB, but the original export chain remains missing. The manuscript preserves the formal **UNLINKED** qualification.
- **Recorded kinetic accounting versus physical energy.** The code computes half the sum of squared speeds, with a zero potential placeholder. The manuscript derives its drive-and-damping balance without adding a physical potential or gravity law.

## What to read and review

Start with the [candidate PDF](MANUSCRIPT/volume_i.pdf). Each major chapter begins in ordinary language, followed by exact equations, source locators, case studies and limitations. Seventeen numbered figures distinguish historical artifacts, reproduced states and derived inspections.

The [LaTeX source](MANUSCRIPT/volume_i.tex) is editable and builds the actual candidate PDF. The [claim matrix](CLAIM_EVIDENCE_MATRIX.md) maps 102 claims to support. The [figure and media register](FIGURE_AND_MEDIA_REGISTER.md) gives origins, hashes, captions and declared crops. The [mechanism map](CROSS_STUDY_MECHANISM_MAP.md) provides a compact comparison, and [open questions](OPEN_QUESTIONS_AND_NEXT_VOLUMES.md) bounds the next scientific decisions.

The [review report](REVIEW_REPORT.md) records compilation, page inspection, source/figure/link checks and preservation. Large movies and numerical logs remain linked in their accepted packages; the ZIP includes the manuscript's chosen assets rather than duplicating those complete archives.

The canonical ledger now records SIM03's acceptance, as explicitly stated in the matching Volume I work order, while retaining its evidence qualifications. Its old study snapshot remains untouched. Volume I itself is **DRAFT / IN REVIEW**.

Review priorities are whether the equations match the source order, whether each observational claim stays within its records, whether original/reproduced evidence remains clear, and whether the volume is readable without reconstructing the earlier studies. The original time-equation lineage, later simulation families and any gravity/energy comparison remain open work.

This volume does not finish the SRG project. No next simulation or publication is underway. GPT and Hilmir review the manuscript before any further action.
