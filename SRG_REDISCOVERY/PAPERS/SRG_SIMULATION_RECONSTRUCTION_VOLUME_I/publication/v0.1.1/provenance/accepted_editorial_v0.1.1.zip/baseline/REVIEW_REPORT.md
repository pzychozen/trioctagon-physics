# Volume I review report

**Status: DRAFT / IN REVIEW. Scientific lead: GPT. Author / research direction: Hilmir Frímann Halldórsson. Preparation: Codex. Date: 22 October 2026.**

The candidate is a 52-page LaTeX research manuscript with 17 numbered figures, 35 reused/cropped figure assets, 102 mapped major claims, six chapters, two appendices and primary-evidence references. Its purpose is reconstruction of three specific programs and their evidence, not a completed SRG theory. [Start here](START_HERE.md), [candidate PDF](MANUSCRIPT/volume_i.pdf), [editable source](MANUSCRIPT/volume_i.tex).

## Authority and scope

The file named in the latest user message was the earlier Study 03 work order. The matching **SRG_SIMULATION_RECONSTRUCTION_VOLUME_I_CODEX_WORK_ORDER.md** was located in Downloads, read, and used because it specifies the requested Volume I task, directory and deliverables. Both supplied work orders are preserved under [instructions](instructions). The user's latest manuscript request governs this turn; the older study order does not authorize another investigation.

The matching Volume I order explicitly records GPT's acceptance of SIM03 within its evidence/provenance qualifications and authorizes a minimal canonical ledger update. The canonical ledger now records that acceptance and this volume's DRAFT / IN REVIEW status. The old SIM03 package, its IN REVIEW manifest wording, and its old ledger snapshot remain unchanged. The [ledger diff](records/ledger_authorized_change.diff), [before copy](records/SIMULATION_STUDY_LEDGER_before.md) and [after copy](records/SIMULATION_STUDY_LEDGER_after.md) make this distinction reviewable.

All new files are inside this volume directory. No original script, historical equation, scientific kernel, accepted study package, earlier paper or unrelated working material was edited. No simulation, RNG draw, new trajectory, seed search, parameter sweep or accepted scientific-checker rerun was performed. Reading and reconciling saved receipts is not described as repeating their scientific verification.

## Scientific and editorial review

The chapters begin in ordinary language, then transcribe the native operators, exact parameters and sequential state dependencies. The manuscript distinguishes pairwise response from arithmetic-centroid response, carried velocity from the new interaction contribution, static trail recording from callback logging, and model multipliers from prescribed H arguments and encoded movie time.

The [claim matrix](CLAIM_EVIDENCE_MATRIX.md) associates all 102 claim IDs with source lines, accepted analysis locations, physical CSV rows/callbacks or movie frames, evidence class and limitations. A consistency check resolves their current manuscript source lines. The [mechanism map](CROSS_STUDY_MECHANISM_MAP.md) supports the cross-study comparison. Algebraic identities are deductions from the supplied equations, without a new potential, metric, gravitational law or physical calibration.

The preserved numerical cases include the reproduced S01 near-contact at sweep 169, S03 body 5's delayed direction change at callbacks 7–9, clock resets with retained state, small native increments versus large stored-coordinate jumps, and body 7's seam crossings while its mode remains unchanged. Counts of rows, callbacks, repeated keys and zero labels were reconciled against the existing accepted summary. No source recurrence was evaluated by this reconciliation.

The accepted S03 all-row energy/position/GRF checks remain distinct from its sampled full velocity-equation checks. The volume reports 31 primary sampled transitions and 20 independent R0 samples without claiming an exhaustive audit of every velocity transition. The reproduced S01 fidelity receipt certifies all saved position arrays and final velocity, not an unsaved historical execution.

### Qualifications carried forward

- S01's historical PNG remains ORIGINAL / ATTRIBUTED with missing seed and ordered history. It is never relabelled as the seed-0 reproduction.
- S02's attributed movie lacks a certified numerical history. A localized screen relocation is wrap-consistent; its actual crossing axis and native displacement are not supplied.
- S03's movie-to-log-B correspondence is strong at the tested samples but its original-run join remains **UNLINKED**. No likelihood, recovered seed or unique export chain is claimed.
- S03's unsigned-modulo detector would flag 8,151 and 3,129 checkable body events, while actual seam counts are 22 and 7. These are accepted recomputed diagnostics; the original console transcript is missing.
- The historical body-7 charts mix repeated Step labels and callback-index markers. Their original pixels remain intact; generator code and precise selection method remain missing. The accepted derived diagnostic is labelled separately.
- The kinetic diagnostic is half the sum of squared speeds with zero potential placeholder. Its drive/damping balance is not a physical energy-conservation or gravity result.
- Finite near-contact, slowed movement and selected pair screens do not establish asymptotic convergence, a universal orbit or a no-go theorem against approximate collective following. The separate compatibility/initializer studies are not extended here.

These are explicit retained qualifications, not silent corrections to accepted research.

## PDF construction and visual review

The actual source builds the candidate PDF using pinned Tectonic 0.17.0, downloaded from its official release with the asset digest verified. [Compiler provenance](records/typesetter_provenance.json) records the URL and archive/executable hashes. Fonts, cache and temporary paths are task-local; the compiler/cache are excluded from the ZIP. No system-wide installation or conda package modification was made.

Build and inspection used Windows Command Prompt and the requested conda environment:

    call C:\Users\Notandi\miniconda3\condabin\conda.bat activate torment
    cd /d C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\SIMULATION_RECONSTRUCTION_RESEARCH\VOLUME_I_01
    python -B tools\build_pdf.py
    python -B tools\inspect_pdf.py --render
    python -B tools\prepare_claim_matrix.py
    python -B tools\editorial_checks.py

The candidate was rendered with Poppler at 110 dpi. Every page was visually inspected for clipping, equations, tables, figures, captions and navigation. An editorial spacing pass corrected words joined to numbers, followed by a fresh build/render and review of changed pages. Unchanged page rasters were matched by hash to the already inspected pages. The final [visual review receipt](review/visual_review.json) records page-by-page coverage and the PDF hash.

The final typeset log has no overfull boxes or undefined references/citations. One underfull abstract paragraph (badness 1077) remains; its spacing was visually acceptable and has no clipping or collision. Text extraction finds no replacement characters or unresolved “??” markers. Full-width data charts have readable labels; multi-frame figures are qualitative spatial comparisons with frame indices explained in captions and full-resolution assets included.

Figures are selected from accepted packages. F03/F04 use declared exact pixel crops of two existing replay sheets, arranged two by two. Other image assets are byte-identical copies, scaled only by page layout. No scientific plot, trajectory or recorded-state render was regenerated. The [figure register](FIGURE_AND_MEDIA_REGISTER.md) documents every source hash, crop and caption.

## Preservation and packaging

The [editorial receipt](records/editorial_checks.json) records exact check coverage:

- 397 protected files: all four accepted construction/replay/study packages, including their archives; the previously protected originals/aliases/attachments; the canonical charter and the matched Volume I work order. Every protected byte count and SHA-256 matches the before snapshot.
- 374 payload entries independently checked against the four existing accepted manifests: 4 + 28 + 68 + 274. These overlap the protected set; they are not 374 additional originals.
- All three included small program copies match their historical originals byte for byte.
- Git HEAD remains 170e638ecc0438f911c4ceb8091ffb1b574652fe. The index hash and all 220 pre-existing porcelain status entries are unchanged. The research workspace was already untracked at the parent level, so its new nested volume creates no additional top-level status entry.
- Canonical ledger change is separately authorized and recorded; it is not falsely included in the immutable-file claim.

This is scoped preservation coverage, not a hash certification of every unrelated repository file. Existing untracked work was neither erased nor reorganized.

The [external evidence index](EXTERNAL_EVIDENCE_INDEX.md) links and hashes accepted documents, full numerical records, movies and reproducibility receipts. Those large archives remain external to the compact review ZIP. The PDF, source, all 35 figure assets, small original source copies, instructions, review records and editorial/build methods are included. Build toolchain/cache/page rasters and redundant LaTeX intermediates are excluded.

MANIFEST.json hashes the included payload, excluding itself and the ZIP to avoid self-reference. The archive is checked by CRC and full member-byte comparison against the manifest. The external delivery receipt records the final ZIP hash. The included read-only delivery verifier can repeat integrity checks without executing any scientific source.

## Review stop

No staging, commit, push, upload, publication, next simulation or time-equation investigation was performed. GPT and Hilmir now review the equations, evidence boundaries, readability and manuscript conclusions. This volume and its proposed future questions authorize no further experiment.
