"""Create a separate editorial candidate. Never import historical programs."""
from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT.parent/"VOLUME_I_01"; REPO=ROOT.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")
def git(*a):return subprocess.check_output(["git","--no-optional-locks",*a],cwd=REPO,text=True,encoding="utf-8")
assert not (ROOT/"records/closeout_before.json").exists(),"Preserve previous preparation."
for d in ["MANUSCRIPT","tools","records","review","instructions","baseline","build/toolchain"]:
    (ROOT/d).mkdir(parents=True,exist_ok=True)
m=json.loads((OLD/"MANIFEST.json").read_text(encoding="utf-8"))
assert sha(OLD/"MANUSCRIPT/volume_i.pdf")=="4180aaa47a7f95cfd2fd0b857dc98415339387652f1f0d3107af6a7aeaa979c7"
assert sha(OLD/m["archive_name"])=="54b91588bfa86966a96e180a1f8021cfd32441bc01c19551659ac9672cd1c3ff"
assert sha(OLD/"MANIFEST.json")=="5e680bf92881aae386a1911d6d3d40785fc7b50ff6e2585d614c380e5787b030"
attachment=Path("C:/Users/Notandi/Downloads/volume_i.pdf")
assert sha(attachment)==sha(OLD/"MANUSCRIPT/volume_i.pdf")
oldprotected=json.loads((OLD/"records/preservation_before.json").read_text(encoding="utf-8"))
protected={Path(r["path"]) for r in oldprotected["protected_files"]}
protected.update(p for p in OLD.rglob("*") if p.is_file())
ledger=ROOT.parent/"SIMULATION_STUDY_LEDGER.md";protected.add(ledger)
review=Path("C:/Users/Notandi/Downloads/SRG_VOLUME_I_GPT_SCIENTIFIC_REVIEW.md")
protected.update([review,attachment])
index=Path(git("rev-parse","--git-path","index").strip())
if not index.is_absolute():index=REPO/index
status=git("status","--short")
(ROOT/"records/git_status_before.txt").write_text(status,encoding="utf-8")
dump(ROOT/"records/closeout_before.json",{
 "scope":"Existing 397 protected files; complete prior Volume I directory including build files; canonical ledger; two supplied review attachments.",
 "files":[{"path":p.as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(protected)],
 "git_head":git("rev-parse","HEAD").strip(),"git_index_path":str(index),"git_index_sha256":sha(index),
 "status_entries":len(status.splitlines()),"ledger_sha256":sha(ledger),
 "reviewed_zip_sha256":sha(OLD/m["archive_name"]),"reviewed_pdf_sha256":sha(attachment)})
for r in m["package_files"]:
    source=OLD/r["path"]
    assert source.stat().st_size==r["bytes"] and sha(source)==r["sha256"]
    if r["path"].startswith("MANUSCRIPT/") and source.suffix!=".pdf":
        dest=ROOT/r["path"];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
for name in ["CLAIM_EVIDENCE_MATRIX.md","FIGURE_AND_MEDIA_REGISTER.md","CROSS_STUDY_MECHANISM_MAP.md",
             "OPEN_QUESTIONS_AND_NEXT_VOLUMES.md","EXTERNAL_EVIDENCE_INDEX.md"]:
    shutil.copyfile(OLD/name,ROOT/name)
for name in ["claims.json","figures.json","external_evidence.json","typesetter_provenance.json",
             "preservation_before.json","editorial_checks.json","SIMULATION_STUDY_LEDGER_before.md",
             "SIMULATION_STUDY_LEDGER_after.md","ledger_authorized_change.diff"]:
    shutil.copyfile(OLD/"records"/name,ROOT/"baseline"/name)
for name in ["claims.json","figures.json","external_evidence.json","typesetter_provenance.json"]:
    shutil.copyfile(OLD/"records"/name,ROOT/"records"/name)
for name in ["MANIFEST.json","REVIEW_REPORT.md","START_HERE.md"]:
    shutil.copyfile(OLD/name,ROOT/"baseline"/name)
for name in ["build_pdf.py","acquire_typesetter.py","inspect_pdf.py"]:
    shutil.copyfile(OLD/"tools"/name,ROOT/"tools"/name)
shutil.copyfile(review,ROOT/"instructions"/review.name)
shutil.copyfile(OLD/"build/toolchain/tectonic.exe",ROOT/"build/toolchain/tectonic.exe")
# Reuse the verified compiler and already-present TeX bundle. No new download.
for name in ["tectonic-cache","cache"]:
    if (OLD/"build"/name).is_dir():shutil.copytree(OLD/"build"/name,ROOT/"build"/name)
dump(ROOT/"records/compiler_reuse.json",{
 "origin":str(OLD/"build/toolchain/tectonic.exe"),
 "sha256":sha(ROOT/"build/toolchain/tectonic.exe"),
 "acquisition_executed_for_R1":False,"original_acquisition_receipt":"records/typesetter_provenance.json",
 "scope":"Byte-identical compiler and cached dependencies reused locally; excluded from archive"})
print(json.dumps({"protected_files":len(protected),"status_entries":len(status.splitlines()),
 "downloads_pdf_matches_reviewed_candidate":True,"prior_payloads_verified":len(m["package_files"]),
 "root":str(ROOT)},indent=2))
