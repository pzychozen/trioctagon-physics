"""Package the editorial candidate; record already completed visual review."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/"VOLUME_I_01"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")
for p in (OLD/"instructions").glob("*"):
    if p.is_file() and not (ROOT/"instructions"/p.name).exists():shutil.copyfile(p,ROOT/"instructions"/p.name)
checks=json.loads((ROOT/"records/closeout_checks.json").read_text(encoding="utf-8"))
reviewed=[1,5,41,46,47,49,50,51,52,53]
assert checks["pages_requiring_visual_inspection"]==reviewed
assert checks["pdf"]["pdf_sha256"]==sha(ROOT/"MANUSCRIPT/volume_i.pdf")
visual={"pdf_sha256":checks["pdf"]["pdf_sha256"],"pages":53,"dpi":110,
 "reviewer":"Codex, editorial inspection; GPT/Hilmir closure decision pending",
 "method":"Ten changed/new full-page rasters visually inspected; all 43 remaining rasters byte-identical to previously inspected pages.",
 "visually_inspected_pages":reviewed,"unchanged_page_raster_count":43,
 "result":"No clipping, collisions, missing figures, broken glyphs or unresolved markers observed.",
 "page_records":checks["raster_comparison"]}
dump(ROOT/"review/visual_review.json",visual)
links=[]
for p in list(ROOT.glob("*.md"))+[ROOT/"MANUSCRIPT/README.md"]:
    for target in re.findall(r"\]\(([^)]+)\)",p.read_text(encoding="utf-8")):
        target=target.strip("<>").split("#",1)[0]
        if not target or re.match(r"^[a-z]+://",target):continue
        dest=(p.parent/unquote(target)).resolve()
        assert dest.exists(),(p,target)
        links.append({"document":p.relative_to(ROOT).as_posix(),"target":target,"exists":True})
dump(ROOT/"records/link_checks.json",{"scope":"Active root documents and manuscript README; historical baseline documents kept verbatim, not rewritten.","checked":len(links),"broken":0,"links":links})
name="SRG_VOLUME_I_EDITORIAL_R1_GPT_REVIEW.zip"
excluded={"MANIFEST.json",name,"review/delivery_receipt.json"}
paths=[]
for p in sorted(ROOT.rglob("*")):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if rel.parts[0]=="build" or "__pycache__" in rel.parts or rel.as_posix() in excluded:continue
    if rel.parts[0]=="MANUSCRIPT" and p.suffix in [".aux",".toc",".lof",".out",".log"]:continue
    paths.append(p)
files=[{"path":p.relative_to(ROOT).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)} for p in paths]
manifest={"task":"SRG_VOLUME_I_EDITORIAL_R1","edition":"0.1.1","date":"2026-10-22",
 "scientific_lead":"GPT","author_research_direction":"Hilmir Frímann Halldórsson","preparation":"Codex",
 "status":"E01-E02 applied; editorial closure review pending; no publication authorization",
 "scope":"Appendix/register spacing and explicit fresh-build prerequisites; cover edition identification only. No new scientific work.",
 "review_authority":"instructions/SRG_VOLUME_I_GPT_SCIENTIFIC_REVIEW.md",
 "prior_edition":{"directory":"../VOLUME_I_01","pdf_sha256":"4180aaa47a7f95cfd2fd0b857dc98415339387652f1f0d3107af6a7aeaa979c7",
 "zip_sha256":"54b91588bfa86966a96e180a1f8021cfd32441bc01c19551659ac9672cd1c3ff","complete_directory_unchanged":True},
 "pdf":checks["pdf"],"numbered_figures":17,"figure_assets":35,"claims":102,
 "diff":"review/EDITORIAL_R1.diff","checks":"records/closeout_checks.json","visual_review":"review/visual_review.json",
 "scientific_body_and_original_source_assets_unchanged":True,"build_and_acquisition_scripts_unchanged":True,
 "compiler_acquisition_rerun":False,"scientific_checkers_or_readback_rerun":False,
 "preservation":{"files":939,"all_unchanged":True,"canonical_ledger_unchanged":True,
 "git_head":checks["git_head"],"git_index_sha256":checks["git_index_sha256"],"status_entries":220,
 "head_index_status_unchanged":True,"scope":"Prior 397-file set; complete previous Volume I directory; ledger; review attachments."},
 "active_document_links_checked":len(links),"broken_links":0,
 "package_files":files,"payload_files_excluding_manifest":len(files),
 "payload_bytes_excluding_manifest":sum(r["bytes"] for r in files),
 "archive_name":name,"archive_members":len(files)+1,
 "excluded":"build toolchain/cache/page rasters; redundant TeX intermediates; full external media/logs; prior ZIP; post-archive delivery receipt",
 "manifest_self_hash":"Not included; avoid self-reference","archive_self_inclusion":False,
 "delivery_receipt":"review/delivery_receipt.json is outside ZIP and records its final hash",
 "stop":"GPT/Hilmir editorial closure review before any separately authorized publication; no next investigation."}
mf=ROOT/"MANIFEST.json";dump(mf,manifest)
archive=ROOT/name
assert not archive.exists(),"Preserve any existing review archive."
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in paths+[mf]:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(files)+1
    assert set(z.namelist())=={r["path"] for r in files}|{"MANIFEST.json"}
    for r in files:
        b=z.read(r["path"]);assert b==(ROOT/r["path"]).read_bytes()
        assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"]
    assert z.read("MANIFEST.json")==mf.read_bytes()
receipt={"archive":name,"bytes":archive.stat().st_size,"sha256":sha(archive),"members":len(files)+1,
 "crc_passed":True,"all_payload_hashes_passed":True,"manifest_sha256":sha(mf),
 "pdf_sha256":checks["pdf"]["pdf_sha256"],"active_links_checked":len(links),"broken_links":0}
dump(ROOT/"review/delivery_receipt.json",receipt)
print(json.dumps(receipt,indent=2))
