"""Read-only manifest/ZIP verification; no scientific source execution."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];mf=ROOT/"MANIFEST.json"
m=json.loads(mf.read_text(encoding="utf-8"))
for r in m["package_files"]:
    p=(ROOT/r["path"]).resolve();assert p.is_relative_to(ROOT.resolve())
    b=p.read_bytes();assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"],r["path"]
archive=ROOT/m["archive_name"]
if archive.exists():
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))==m["archive_members"]
        assert set(z.namelist())=={r["path"] for r in m["package_files"]}|{"MANIFEST.json"}
        assert z.read("MANIFEST.json")==mf.read_bytes()
        for r in m["package_files"]:
            b=z.read(r["path"]);assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"]
    receipt=ROOT/"review/delivery_receipt.json"
    if receipt.exists():
        d=json.loads(receipt.read_text(encoding="utf-8"))
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==d["sha256"]
        assert hashlib.sha256(mf.read_bytes()).hexdigest()==d["manifest_sha256"]
print(json.dumps({"verified_payloads":len(m["package_files"]),"passed":True,
                  "archive_present_and_verified":archive.exists(),"read_only":True},indent=2))
