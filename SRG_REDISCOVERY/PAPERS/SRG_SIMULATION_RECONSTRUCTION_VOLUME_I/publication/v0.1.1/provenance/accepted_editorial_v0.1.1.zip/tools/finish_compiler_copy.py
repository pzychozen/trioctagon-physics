"""Finish local cached build dependency reuse after shortening the output path."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/"VOLUME_I_01"
for name in ["tectonic-cache","cache"]:
    if (OLD/"build"/name).is_dir():
        shutil.copytree(OLD/"build"/name,ROOT/"build"/name,dirs_exist_ok=True)
p=ROOT/"build/toolchain/tectonic.exe"
d={"origin":str(OLD/"build/toolchain/tectonic.exe"),
   "sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
   "acquisition_executed_for_R1":False,"original_acquisition_receipt":"records/typesetter_provenance.json",
   "scope":"Byte-identical compiler and cached dependencies reused locally; excluded from archive",
   "build_preparation_note":"Output folder shortened to VOLUME_I_01_R1 to stay within Windows cache path limits."}
(ROOT/"records/compiler_reuse.json").write_text(json.dumps(d,indent=2),encoding="utf-8")
print(json.dumps(d,indent=2))
