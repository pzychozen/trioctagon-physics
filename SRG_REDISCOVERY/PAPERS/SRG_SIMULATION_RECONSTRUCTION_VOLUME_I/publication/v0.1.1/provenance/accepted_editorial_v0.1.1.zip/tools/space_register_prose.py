"""E01 spacing only in copied human-readable registers; no identities altered."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/"VOLUME_I_01"
names=["CLAIM_EVIDENCE_MATRIX.md","CROSS_STUDY_MECHANISM_MAP.md",
       "OPEN_QUESTIONS_AND_NEXT_VOLUMES.md","FIGURE_AND_MEDIA_REGISTER.md","EXTERNAL_EVIDENCE_INDEX.md"]
def polish(t):
    t=re.sub(r"\b(lines?|frames?|events?|states?|Window|seed|Declared|independent|Accepted|and|Mode|All|by)(?=\d)",r"\1 ",t)
    t=re.sub(r"\bbody(?=\d+(?!\d)[\s/;,.)])","body ",t)
    t=re.sub(r"(?<=\d)fps\b"," fps",t)
    return t
changes=[]
for name in names:
    before=(OLD/name).read_text(encoding="utf-8")
    after=polish(before)
    assert re.sub(r"\s","",before)==re.sub(r"\s","",after)
    assert re.findall(r"\]\(([^)]+)\)",before)==re.findall(r"\]\(([^)]+)\)",after)
    assert re.findall(r"\b[a-f0-9]{64}\b",before)==re.findall(r"\b[a-f0-9]{64}\b",after)
    (ROOT/name).write_text(after,encoding="utf-8")
    if after!=before:changes.append(name)
claims=json.loads((OLD/"records/claims.json").read_text(encoding="utf-8"))
for r in claims:
    for key in ["claim","support","limitation"]:r[key]=polish(r[key])
(ROOT/"records/claims.json").write_text(json.dumps(claims,indent=2,ensure_ascii=False),encoding="utf-8")
(ROOT/"records/register_spacing.json").write_text(json.dumps({
 "changed_registers":changes,"all_changes_whitespace_only":True,
 "links_hashes_and_claim_IDs_unchanged":True,"claim_source_locations_unchanged":True},indent=2),encoding="utf-8")
print(json.dumps(changes,indent=2))
