"""Editorial diff and preservation checks. No numeric readback or simulation."""
from pathlib import Path
import difflib,hashlib,json,re,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/"VOLUME_I_01";REPO=ROOT.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding="utf-8"))
before=load(ROOT/"records/closeout_before.json")
for r in before["files"]:
    p=Path(r["path"])
    assert p.stat().st_size==r["bytes"] and sha(p)==r["sha256"],p
git=lambda *a:subprocess.check_output(["git","--no-optional-locks",*a],cwd=REPO,text=True,encoding="utf-8")
assert git("rev-parse","HEAD").strip()==before["git_head"]
assert sha(Path(before["git_index_path"]))==before["git_index_sha256"]
status=git("status","--short")
assert status.splitlines()==(ROOT/"records/git_status_before.txt").read_text(encoding="utf-8").splitlines()
assert sha(ROOT.parent/"SIMULATION_STUDY_LEDGER.md")==before["ledger_sha256"]
(ROOT/"records/git_status_after.txt").write_text(status,encoding="utf-8")
allow={"MANUSCRIPT/volume_i.tex","MANUSCRIPT/sections/07_provenance.tex",
       "MANUSCRIPT/sections/08_reproducibility.tex","MANUSCRIPT/README.md"}
changes=[];diff=[]
for p in sorted((ROOT/"MANUSCRIPT").rglob("*")):
    if not p.is_file() or p.suffix not in [".tex",".py",".png",".md"]:continue
    rel=p.relative_to(ROOT).as_posix();original=OLD/rel
    assert original.is_file(),rel
    if sha(p)!=sha(original):
        assert rel in allow,rel
        changes.append(rel)
        diff.extend(difflib.unified_diff(original.read_text(encoding="utf-8").splitlines(True),
                    p.read_text(encoding="utf-8").splitlines(True),fromfile="edition_0.1/"+rel,tofile="editorial_R1/"+rel))
assert set(changes)==allow
for name in ["CLAIM_EVIDENCE_MATRIX.md","CROSS_STUDY_MECHANISM_MAP.md",
             "OPEN_QUESTIONS_AND_NEXT_VOLUMES.md","FIGURE_AND_MEDIA_REGISTER.md","EXTERNAL_EVIDENCE_INDEX.md"]:
    old=(OLD/name).read_text(encoding="utf-8");new=(ROOT/name).read_text(encoding="utf-8")
    assert re.sub(r"\s","",old)==re.sub(r"\s","",new)
    if old!=new:
        diff.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
                    fromfile="edition_0.1/"+name,tofile="editorial_R1/"+name))
(ROOT/"review/EDITORIAL_R1.diff").write_text("".join(diff),encoding="utf-8")
old7=(OLD/"MANUSCRIPT/sections/07_provenance.tex").read_text(encoding="utf-8")
new7=(ROOT/"MANUSCRIPT/sections/07_provenance.tex").read_text(encoding="utf-8")
assert re.sub(r"\s","",old7)==re.sub(r"\s","",new7)
old8=(OLD/"MANUSCRIPT/sections/08_reproducibility.tex").read_text(encoding="utf-8")
new8=(ROOT/"MANUSCRIPT/sections/08_reproducibility.tex").read_text(encoding="utf-8")
before_build=lambda x:x.split("\\section{Manuscript build}")[0]
after_build=lambda x:x.split("\\section{Figures and presentation}")[1]
assert re.sub(r"\s","",before_build(old8))==re.sub(r"\s","",before_build(new8))
assert after_build(old8)==after_build(new8)
for name in ["build_pdf.py","acquire_typesetter.py"]:
    assert sha(ROOT/"tools"/name)==sha(OLD/"tools"/name)
    script=(ROOT/"tools"/name).read_text(encoding="utf-8")
    assert "tectonic.exe" in script
assert "0.17.0" in (ROOT/"tools/acquire_typesetter.py").read_text(encoding="utf-8")
for p in [ROOT/"MANUSCRIPT/README.md",ROOT/"MANUSCRIPT/sections/08_reproducibility.tex"]:
    t=p.read_text(encoding="utf-8")
    assert t.index("python -B tools\\acquire_typesetter.py")<t.index("python -B tools\\build_pdf.py")
    assert "network access" in t and "excluded" in t
claims=load(ROOT/"records/claims.json")
for r in claims:
    for loc in r["manuscript_locations"]:
        line=(ROOT/loc["file"]).read_text(encoding="utf-8").splitlines()[loc["line"]-1]
        assert "\\claim{"+r["id"]+"}" in line
assert len(claims)==102
oldfigs=load(OLD/"records/figures.json");figs=load(ROOT/"records/figures.json")
assert oldfigs==figs
for f in figs:
    for a in f["assets"]:assert sha(ROOT/"MANUSCRIPT/figures"/a["asset"])==a["sha256"]
tex="\n".join(p.read_text(encoding="utf-8") for p in (ROOT/"MANUSCRIPT").rglob("*.tex"))
labels=re.findall(r"\\label\{([^}]+)\}",tex)
assert len(labels)==len(set(labels))==63
assert set(re.findall(r"\\(?:ref|eqref)\{([^}]+)\}",tex))<=set(labels)
log=(ROOT/"MANUSCRIPT/volume_i.log").read_text(encoding="utf-8")
assert "Overfull" not in log and "undefined" not in log.lower()
pdf=load(ROOT/"records/pdf_structure.json")
assert pdf["pdf_sha256"]==sha(ROOT/"MANUSCRIPT/volume_i.pdf")
assert pdf["pages"]==53 and pdf["replacement_characters"]==pdf["visible_question_mark_pairs"]==0
render=[]
for p in sorted((ROOT/"build/pdf_review").glob("page-*.png")):
    n=int(p.stem.split("-")[1])
    previous=OLD/"build/pdf_review"/p.name
    render.append({"pdf_page":n,"sha256":sha(p),
                   "matches_previously_reviewed_page":previous.is_file() and sha(p)==sha(previous)})
assert len(render)==pdf["pages"]
result={"scope":"E01-E02 editorial closeout; no scientific checker or numerical readback rerun",
 "protected_files_checked":len(before["files"]),"all_protected_files_unchanged":True,
 "previous_edition_including_build_unchanged":True,"canonical_ledger_unchanged":True,
 "git_head":before["git_head"],"git_index_sha256":before["git_index_sha256"],
 "git_status_entries":len(status.splitlines()),"git_head_index_status_unchanged":True,
 "changed_manuscript_source_files":changes,"chapters_1_to_6_references_sources_figures_unchanged":True,
 "E01_values_identifiers_formulas_unchanged":True,"E02_build_scripts_byte_identical":True,
 "claim_locations_verified":102,"figure_assets_verified":35,"labels_unique_resolved":63,
 "pdf":pdf,"overfull_boxes":0,"undefined_references":0,
 "underfull_warning":"Same accepted abstract paragraph; badness 1077",
 "raster_comparison":render,
 "pages_requiring_visual_inspection":[r["pdf_page"] for r in render if not r["matches_previously_reviewed_page"]]}
(ROOT/"records/closeout_checks.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
shutil.copyfile(ROOT/"MANUSCRIPT/volume_i.log",ROOT/"review/typeset.log")
shutil.copyfile(ROOT/"build/typeset_console.txt",ROOT/"review/typeset_console.txt")
print(json.dumps({k:v for k,v in result.items() if k!="raster_comparison"},indent=2))
