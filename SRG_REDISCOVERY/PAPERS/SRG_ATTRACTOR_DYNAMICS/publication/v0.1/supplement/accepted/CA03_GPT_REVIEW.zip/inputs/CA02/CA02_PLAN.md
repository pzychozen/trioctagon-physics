# CA02 fixed plan, written before fresh numerical execution

21 October 2026. Authority: the user's CA02 request and received/SRG_CA02_CODEX_WORK_ORDER.md. The attached review accepts CA01 within printed-map/passive-measurement scope. CA01 and all unrelated work are read-only.

## Source gate

Starting main HEAD: 2ecc2ded685fd210bd3cda226eb9731156dc167e. Accepted CA01 archive SHA-256 f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0; review SHA-256 9ce79ca882ab29a2ba07e14caf8b927cbfac8aa08385ab7b59fb47955ed1d317. All 89 CA01 archive payload identities passed; consumed local files match their archive members and attached text copies. Full identities are in evidence/SOURCES_BEFORE.json. No new historical search or PDF review is needed to resolve the accepted equations.

First derive the endpoint formulas in CA02_ENDPOINT_RETENTION_ANALYSIS.md. Then extract only the inspected pure H, P, step and finite-check functions into a local model.py, with AST identity verification. The source runner is read as text, never imported. Use the literal trigonometric P as primary, and the closed form only for independent saved-record checks.

## Fixed 16-run matrix

Let a=1/32, a/2=1/64, rho_*=(3+sqrt(3))/4, z_*=sqrt(sqrt(3)/2)/2 and L_*=sqrt(rho_*^2+z_*^2). Construct each start once using binary64 evaluation of its analytic definition; save the actual three components. Use cos/sin at the declared angle (including their ordinary nonzero floating residual at pi/2). No normalization afterward.

| IDs | Family | Start | alpha |
|---|---|---|---|
| A0p,A0m | A | s_*(0) | +a,-a |
| A1p,A1m | A | s_*(pi/2) | +a,-a |
| A2p,A2m | A | s_*(pi) | +a,-a |
| A3p,A3m | A | s_*(3pi/2) | +a,-a |
| Bhalf,Bthreehalf | B, size only | .5*s_*(0), 1.5*s_*(0) | +a |
| Czero,Cquarter | C, tilt only | L_*(cos beta,0,sin beta), beta=0,pi/4 | +a |
| D0p,D0m | D | s_*(0) | +a/2,-a/2 |
| D1p,D1m | D | s_*(pi/2) | +a/2,-a/2 |

All runs have exactly 800 updates, t_n=.1n, dt=.1, states 0..800. B compares with A0p at fixed initial direction; C compares with A0p at the same norm and azimuth. These are diagnostic parameters, never recovered historical inputs.

Budget: 16 trajectories, 12,800 fresh state-advance calls. No additional fresh isolated steps are planned (ceiling 24 remains unused). No alpha=0 rollout: its endpoint is exact and CA01 supplies the saved illustration. No repetitions, extra starts, parameter changes, high-precision rollout, or extension.

The known bound ||s0||<=9/4 gives ||q0||<=729/1024=.7119140625<.79999. For n>=1, ||q_n||<=81/256=.31640625<.79999. Both use |H|<=9/2 and |alpha|<=1/32. Keep the original clipping expression and record factor=1 rather than deleting it. Smallest declared initial horizontal radius is rho_*/2>.59; the maximal first increment bound .071192<.072 therefore leaves the segment off-axis. Subsequent segments have rho>=.42 by CA01. Verify observed bounds; unexpected clipping or an undefined remap stops that branch without repair.

## Preliminary passive check and resource guards

Before any fresh trajectory, compare local pure evaluator outputs against all 12 inherited isolated records and all 200 inherited transitions. These 212 evaluations start independently from saved inputs; never chain their outputs. AST comparisons verify unchanged numeric expressions and operation order. Fresh and passive counters are separate.

The numerical stage is one child Python process under CMD/torment, supervised with a hard 600-second timeout. Internal deadline checks before every call and output checks supplement the supervisor. One launch only; a failure is retained and never automatically restarted. Reserve a conservative uncompressed raw-array allowance before each run and enforce a 250,000,000-byte new-result limit. Raw records and partial failed runs stay within CA02. Save counters/progress after each trajectory, and partial records on a normal failure; a hard kill may leave only the most recent checkpoint and is reported as incomplete.

Use Python -B; TMP, TEMP and plotting caches point inside CA02. No dependency install, GUI, kernel import or original runner.

## Tolerances and recorded quantities

Primary arithmetic: NumPy binary64. CA01 fixture absolute tolerance: 1e-12. For squared-norm and torque-perpendicularity residuals report both absolute values and values divided by max(1,||s||^2,||u||^2); threshold 1e-12 on that scale. Remap surface and angular-increment/lift consistency tolerances: 1e-12. These are consistency criteria, not mathematical error bounds.

Record per update: n, t, H, alpha, incoming state, raw torque, clipped torque, factor, clipping flag, pre-remap state, successor, exact-form short angular increment evaluated in binary64, and accumulated continuous phase lift. Save all 801 states and distances to C. P preserves pre-remap azimuth. Record the minimum segment horizontal-radius lower bound rho(s)-||e_xy|| and the increment denominator; no branch regularization.

The first-order response is computed from the derived scalar series, not by extra native rollouts. Starts on C and their ray variants have closed forms. For the two tilt responses, sum 40 terms of the scalar unforced meridional correction to the known fixed-circle series, with an explicit geometric residual bound. These scalar coefficient calculations are not new three-component trajectories or fresh alpha=0 experiments. Use binary64 estimates plus the analytical correction remainder; do not claim they are interval-certified floating results.

## Endpoint/error accounting

For state N=800, the remaining exact angular change is bounded by B_N(alpha) in the work order, proved from the summable envelope. Retain its exact expression and report an ordinary binary64 estimate, clearly distinct from roundoff. For comparisons add the two exact-trajectory tails; circular differences use atan2(sin delta,cos delta), while derivatives use the continuous lifts.

Compare central differences D_h=[Phi_h-Phi_-h]/(2h) at h=a,a/2 with the analytic derivative. Prove local C^3 regularity so truncation is bounded by h^2 sup|partial_alpha^3 Phi|/6; the supremum need not be assigned an unproved numerical value. Report actual derivative discrepancies, the exact tail contribution <=B_N(h)/h, observed one-step residuals and lift consistency. A Richardson correction may be shown as an estimate, not a certified error bar or another run. No unproved accumulated binary64 error bound will be inferred from the tail or the largest one-step residual. If quantitative separations remain only finite floating evidence, label them accordingly.

## Output and observer choice

Two native-coordinate figures are planned: angular/derivative response and separate size/tilt comparisons. A third geometry overlay is optional only if it adds information. The principal result needs no reconstruction of the crystal or new SRG-to-Z bridge. Geometry remains the accepted passive reference; no ball, containment, re-centering or per-path scale is introduced. At most three PNGs and one CA02_GPT_REVIEW.zip.

After execution, independently verify saved evidence without new state advancement; preserve consumed-source hashes and outside-task Git status. Package a <=700-word summary, mathematical analysis, source/claim map, endpoint table, raw arrays, scripts, counters, commands, manifest and receipt. No staging, commit, push or publication.
