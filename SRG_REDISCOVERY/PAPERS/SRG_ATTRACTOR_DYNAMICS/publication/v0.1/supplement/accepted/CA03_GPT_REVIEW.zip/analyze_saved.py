"""Independent saved-record, tangent and passive-frame analysis. No model import/step calls."""
from pathlib import Path
import csv, hashlib, json, math, sys
import numpy as np
BASE=Path(__file__).resolve().parent
R=json.loads((BASE/'RUN_RESULTS.json').read_text());assert R['status']=='COMPLETED'
SC=json.loads((BASE/'SCALAR_ANALYSIS.json').read_text())
rho=R['circle']['rho_star'];z=R['circle']['z_star'];a=1/32;eta=1e-4
cases=json.loads((BASE/'received/CA03_EXPERIMENT_SPEC.json').read_text())['cases']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def savej(name,obj):(BASE/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def table(name,rows):
    with (BASE/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def circ(v):return np.arctan2(np.sin(v),np.cos(v))
def forcing(t):return 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
def tail(f):return float(.225*a/.42*(2*np.exp(-.05*f)/(-np.expm1(-.05))+np.exp(-.03*f)/(-np.expm1(-.03))+
    1.5*np.exp(-.07*f)/(-np.expm1(-.07))+np.exp(-.04*f)/(-np.expm1(-.04))))
def G(ph):return z*z/rho*np.cos(ph)+z*np.sin(ph)*np.cos(ph)-rho*np.sin(ph)
def Gprime(ph):return -z*z/rho*np.sin(ph)+z*np.cos(2*ph)-rho*np.cos(ph)
maxima={k:0. for k in ['independent_H','component_torque','clip_factor','clipped_torque','Euler_pre_remap',
    'closed_form_successor','surface','Euler_norm_abs','Euler_norm_scaled','perpendicular_abs','perpendicular_scaled',
    'phase_increment_vs_azimuth','phase_lift_vs_azimuth','phase_lift_vs_fsum','stored_angle_increment',
    'stored_segment_margin','stored_angle_denominator','distance_to_circle','meridional_coordinate']}
minimum=dict(segment_rho_lower=float('inf'),angle_denominator=float('inf'),post_remap_height=float('inf'))
maxq=0.;clips=0;observed=[];D={};count=0;states_count=0
with np.load(BASE/'INPUTS.npz',allow_pickle=False) as data:initials={k:data[k].copy() for k in data.files}
for row in R['branches']:
    path=BASE/row['raw'];assert sha(path)==row['raw_sha256']
    with np.load(path,allow_pickle=False) as data:d={k:data[k].copy() for k in data.files}
    D[row['id']]=d;steps=row['updates'];assert row['status']=='COMPLETED'
    assert d['states'].shape==(steps+1,3) and d['s'].shape==(steps,3)
    assert all(v.dtype!=object and np.isfinite(v).all() for v in d.values())
    assert d['states'][0].tobytes()==initials[row['case']].tobytes()
    assert d['phase_lift'][0].tobytes()==initials[row['case']+'_phase'].tobytes()
    assert np.array_equal(d['states'][:-1],d['s']) and np.array_equal(d['states'][1:],d['dest'])
    j=np.arange(steps);f=800+j if row['arm']=='CONTINUE' else j%800
    assert np.array_equal(d['j'],j) and np.array_equal(d['n'],800+j)
    assert np.array_equal(d['block'],j//800+1) and np.array_equal(d['f'],f)
    assert np.array_equal(d['t'],.1*f) and np.all(d['alpha']==a)
    assert np.array_equal(d['absolute_state_index'],800+np.arange(steps+1))
    assert np.array_equal(d['continuation_state_index'],np.arange(steps+1))
    assert np.array_equal(d['completed_new_blocks'],np.arange(steps+1)//800)
    s=d['s'];u=d['u'];dest=d['dest'];q=d['q'];qh=d['qhat'];x,y,zz=s.T
    h=forcing(d['t']);A=np.column_stack((y*y-x*zz,zz*zz-x*y,x*x-y*zz));q_expected=(a*h)[:,None]*A
    qnorm=np.linalg.norm(q_expected,axis=1);factor=np.minimum(1.,.8/(qnorm+1e-5))
    uh=np.hypot(u[:,0],u[:,1]);ul=np.linalg.norm(u,axis=1);assert np.all(uh>0)
    closed=np.column_stack(((1+u[:,2]/(2*ul))*u[:,0]/uh,(1+u[:,2]/(2*ul))*u[:,1]/uh,uh/(2*ul)))
    ss=np.einsum('ij,ij->i',s,s);uu=np.einsum('ij,ij->i',u,u);qq=np.einsum('ij,ij->i',qh,qh)
    scale=np.maximum(1.,np.maximum(ss,uu));euler=np.abs(uu-ss-.01*qq);dot=np.abs(np.einsum('ij,ij->i',s,qh))
    e=.1*qh;segment=np.hypot(x,y)-np.linalg.norm(e[:,:2],axis=1)
    numerator=x*e[:,1]-y*e[:,0];denominator=x*x+y*y+x*e[:,0]+y*e[:,1]
    increment=np.arctan2(numerator,denominator)
    all_s=d['states'];az=np.arctan2(all_s[:,1],all_s[:,0]);hr=np.hypot(all_s[:,0],all_s[:,1])
    dist=np.hypot(hr-rho,all_s[:,2]-z);theta=np.arctan2(all_s[:,2],hr-1)
    checks=dict(independent_H=float(np.max(np.abs(h-d['H']))),component_torque=float(np.max(np.abs(q_expected-q))),
        clip_factor=float(np.max(np.abs(factor-d['factor']))),clipped_torque=float(np.max(np.abs(factor[:,None]*q-qh))),
        Euler_pre_remap=float(np.max(np.abs(s+.1*qh-u))),closed_form_successor=float(np.max(np.abs(closed-dest))),
        surface=float(np.max(np.abs((np.hypot(dest[:,0],dest[:,1])-1)**2+dest[:,2]**2-.25))),
        Euler_norm_abs=float(euler.max()),Euler_norm_scaled=float(np.max(euler/scale)),
        perpendicular_abs=float(dot.max()),perpendicular_scaled=float(np.max(dot/scale)),
        phase_increment_vs_azimuth=float(np.max(np.abs(circ(np.diff(az)-increment)))),
        phase_lift_vs_azimuth=float(np.max(np.abs(circ(d['phase_lift']-az)))),
        phase_lift_vs_fsum=abs(float(d['phase_lift'][-1])-(float(d['phase_lift'][0])+math.fsum(increment))),
        stored_angle_increment=float(np.max(np.abs(increment-d['angular_increment']))),
        stored_segment_margin=float(np.max(np.abs(segment-d['segment_rho_lower']))),
        stored_angle_denominator=float(np.max(np.abs(denominator-d['angle_denominator']))),
        distance_to_circle=float(np.max(np.abs(dist-d['distance_to_circle']))),
        meridional_coordinate=float(np.max(np.abs(theta-d['meridional_theta']))))
    for key,val in checks.items():maxima[key]=max(maxima[key],val);assert val<1e-12,(row['id'],key,val)
    assert np.all(factor==1) and not d['clipped'].any()
    assert np.all(segment>0) and np.all(denominator>0) and np.all(dest[:,2]>=0)
    minimum['segment_rho_lower']=min(minimum['segment_rho_lower'],float(segment.min()))
    minimum['angle_denominator']=min(minimum['angle_denominator'],float(denominator.min()))
    minimum['post_remap_height']=min(minimum['post_remap_height'],float(dest[:,2].min()))
    maxq=max(maxq,float(qnorm.max()));clips+=int(d['clipped'].sum());count+=steps;states_count+=steps+1
    observed.append(dict(id=row['id'],max_circle_distance=float(dist.max()),final_circle_distance=float(dist[-1]),
        final_lift=float(d['phase_lift'][-1]),phase_displacement=float(d['phase_lift'][-1]-d['phase_lift'][0]),
        min_segment_radius=float(segment.min()),max_raw_torque=float(qnorm.max())))
assert count==43200 and states_count==43222

history=[];boundary=[];responses=[]
hist_cases=['Bhalf','Bthreehalf','Czero','Cquarter']
for arm in ['CONTINUE','RETURN']:
    ref=D['A0p_'+arm]
    for case in cases:
        d=D[case+'_'+arm]
        for added in range(4):
            j=800*added;s=d['states'][j];sr=ref['states'][j]
            delta=float(circ(d['phase_lift'][j]-ref['phase_lift'][j]))
            d0=float(circ(d['phase_lift'][0]-ref['phase_lift'][0]))
            phase=float(d['phase_lift'][j]);lift_delta=float(d['phase_lift'][j]-ref['phase_lift'][j])
            rec=dict(case=case,arm=arm,added_blocks=added,absolute_state_index=800+j,
                phase_lift=phase,phase_mod_2pi=float(phase%(2*np.pi)),
                phase_displacement_from_checkpoint=phase-float(d['phase_lift'][0]),
                phase_difference_from_A0p=delta,lift_difference_from_A0p=lift_delta,
                circular_magnitude=abs(delta),ratio_to_checkpoint=abs(delta/d0) if d0 else None,
                sign_reversal=bool(delta*d0<0),wrap_integer=int(round((lift_delta-delta)/(2*np.pi))),
                meridional_theta=float(d['meridional_theta'][j]),
                meridional_difference=float(d['meridional_theta'][j]-ref['meridional_theta'][j]),
                rho_z_separation=float(np.hypot(np.hypot(s[0],s[1])-np.hypot(sr[0],sr[1]),s[2]-sr[2])),
                Cartesian_separation=float(np.linalg.norm(s-sr)),distance_to_circle=float(d['distance_to_circle'][j]),
                uninterrupted_tail_next_f=(800+j if arm=='CONTINUE' else 800),
                uninterrupted_tail_estimate=tail(800+j if arm=='CONTINUE' else 800),
                tail_convention='No further restarts; counterfactual at RETURN boundaries before final stop')
            boundary.append(rec)
            if case in hist_cases:history.append(rec)
        if arm=='RETURN':
            for block in range(3):
                j=800*block;phi=float(d['phase_lift'][j]);shift=float(d['phase_lift'][j+800]-d['phase_lift'][j])
                responses.append(dict(case=case,block=block+1,input_phase=phi,input_phase_mod=float(phi%(2*np.pi)),
                    output_phase=float(d['phase_lift'][j+800]),block_phase_change=shift,
                    leading_circle_prediction=float(a*SC['K_N_estimate']*G(phi)),
                    discrepancy_from_leading=float(shift-a*SC['K_N_estimate']*G(phi)),
                    leading_phase_gain=float(1+a*SC['K_N_estimate']*Gprime(phi)),
                    incoming_distance_to_circle=float(d['distance_to_circle'][j]),
                    caveat='Leading formula starts on C; actual full state, finite alpha and residual tilt retained'))
table('BOUNDARY_TABLE.csv',boundary);table('HISTORY_COMPARISONS.csv',history);table('BLOCK_RESPONSE_TABLE.csv',responses)

# Analytic derivatives on the saved A0p RETURN branch, no extra model calls.
ref=D['A0p_RETURN'];s0=ref['states'][0];hr=float(np.hypot(s0[0],s0[1]));norm=float(np.linalg.norm(s0))
ph=float(np.arctan2(s0[1],s0[0]));be=float(np.arctan2(s0[2],hr))
J=np.column_stack((s0,norm*np.array([-np.sin(be)*np.cos(ph),-np.sin(be)*np.sin(ph),np.cos(be)]),np.array([-s0[1],s0[0],0.])))
sens=[J.copy()];phase_sens=[];theta_sens=[]
jac_checks=dict(closed_vs_trigonometric=0.,radial_null=0.,torque_homogeneity=0.,phase_chain_rule=0.)
for n in range(801):
    s=ref['states'][n];horiz=np.hypot(s[0],s[1]);w=np.array([s[0]/horiz,s[1]/horiz,0.])
    gp=np.array([-s[1],s[0],0.])/horiz**2
    gt=((horiz-1)*np.array([0.,0.,1.])-s[2]*w)/((horiz-1)**2+s[2]**2)
    phase_sens.append(gp@J);theta_sens.append(gt@J)
    if n==800:break
    x,y,zz=s;u=ref['u'][n];rr=np.hypot(u[0],u[1]);ll=np.linalg.norm(u)
    wh=np.array([u[0]/rr,u[1]/rr,0.]);hh=1+u[2]/(2*ll)
    grad_h=np.array([0.,0.,1.])/(2*ll)-u[2]*u/(2*ll**3)
    Dw=(np.diag([1.,1.,0.])-np.outer(wh,wh))/rr
    DP=np.vstack((hh*Dw[0]+wh[0]*grad_h,hh*Dw[1]+wh[1]*grad_h,wh/(2*ll)-rr*u/(2*ll**3)))
    theta=np.arctan2(rr,u[2]);phi=np.arctan2(u[1],u[0])
    pt=np.array([-.5*np.sin(theta)*np.cos(phi),-.5*np.sin(theta)*np.sin(phi),.5*np.cos(theta)])
    pp=np.array([-(1+.5*np.cos(theta))*np.sin(phi),(1+.5*np.cos(theta))*np.cos(phi),0.])
    dtheta=(u[2]*wh-rr*np.array([0.,0.,1.]))/(ll*ll)
    dphi=np.array([-u[1],u[0],0.])/(rr*rr)
    DP_trig=np.outer(pt,dtheta)+np.outer(pp,dphi)
    DA=np.array([[-zz,2*y,-x],[-y,-x,2*zz],[2*x,-zz,-y]])
    AA=np.array([y*y-x*zz,zz*zz-x*y,x*x-y*zz])
    out=ref['dest'][n];out_grad=np.array([-out[1],out[0],0.])/np.hypot(out[0],out[1])**2
    checks=dict(closed_vs_trigonometric=float(np.max(np.abs(DP-DP_trig))),radial_null=float(np.max(np.abs(DP@u))),
        torque_homogeneity=float(np.max(np.abs(DA@s-2*AA))),phase_chain_rule=float(np.max(np.abs(out_grad@DP-dphi))))
    for key,val in checks.items():jac_checks[key]=max(jac_checks[key],val);assert val<1e-12
    J=DP@(np.eye(3)+.1*a*ref['H'][n]*DA)@J;sens.append(J.copy())
phase_sens=np.asarray(phase_sens);theta_sens=np.asarray(theta_sens)
np.savez_compressed(BASE/'TANGENT.npz',parameter_order=np.array(['SIZE','TILT','PHASE']),
    state_tangent=np.asarray(sens),phase_tangent=phase_sens,meridional_tangent=theta_sens,absolute_state_index=800+np.arange(801))
disturb=[];tangent_comparisons=[]
for col,kind in enumerate(['SIZE','TILT','PHASE']):
    plus=D[kind+'+'];minus=D[kind+'-']
    for sign,suffix in [(1,'+'),(-1,'-')]:
        d=D[kind+suffix]
        for j in [0,1,800]:
            difference=float(circ(d['phase_lift'][j]-ref['phase_lift'][j]));sr=ref['states'][j];s=d['states'][j]
            disturb.append(dict(id=kind+suffix,parameter=kind,eta=sign*eta,absolute_state_index=800+j,local_state_index=j,
                phase_difference=difference,linear_tangent_prediction=float(sign*eta*phase_sens[j,col]),
                difference_minus_tangent=float(difference-sign*eta*phase_sens[j,col]),
                meridional_difference=float(d['meridional_theta'][j]-ref['meridional_theta'][j]),
                rho_z_separation=float(np.hypot(np.hypot(s[0],s[1])-np.hypot(sr[0],sr[1]),s[2]-sr[2])),
                Cartesian_separation=float(np.linalg.norm(s-sr)),distance_to_circle=float(d['distance_to_circle'][j])))
    cd=(plus['phase_lift'][800]-minus['phase_lift'][800])/(2*eta)
    tangent_comparisons.append(dict(parameter=kind,units='fractional scale' if kind=='SIZE' else 'radians',
        tangent_initial=float(phase_sens[0,col]),tangent_after_one=float(phase_sens[1,col]),tangent_after_block=float(phase_sens[800,col]),
        central_difference=float(cd),central_minus_tangent=float(cd-phase_sens[800,col]),
        central_exact_tail_allowance_estimate=tail(800)/eta,
        error_scope='Tail only for a hypothetical uninterrupted endpoint, not for sampled finite block; no accumulated roundoff enclosure'))
table('DISTURBANCE_TABLE.csv',disturb);table('TANGENT_COMPARISON.csv',tangent_comparisons)

# Rotate the whole actual observer about O and measure in co-rotated axes.
with np.load(BASE/'received/reference/CA01_geometry_reference.npz',allow_pickle=False) as f:geo={k:f[k].copy() for k in f.files}
angle=np.pi/3;Q=np.array([[np.cos(angle),-np.sin(angle),0.],[np.sin(angle),np.cos(angle),0.],[0.,0.,1.]])
O=geo['origin'];assert np.max(np.abs(Q.T@Q-np.eye(3)))<1e-12 and abs(np.linalg.det(Q)-1)<1e-12
native=np.asarray([D[r['case']+'_'+r['arm']]['states'][r['absolute_state_index']-800] for r in boundary])
world=O+native;rotworld=O+(world-O)@Q.T;co=(rotworld-O)@Q
frame=dict(observation_count=len(native),proper_rotation_determinant=float(np.linalg.det(Q)),
    orthogonality_residual=float(np.max(np.abs(Q.T@Q-np.eye(3)))),
    recovered_coordinate_residual=float(np.max(np.abs(co-native))),
    phase_residual=float(np.max(np.abs(circ(np.arctan2(co[:,1],co[:,0])-np.arctan2(native[:,1],native[:,0]))))))
dist_native=np.hypot(np.hypot(native[:,0],native[:,1])-rho,native[:,2]-z)
dist_co=np.hypot(np.hypot(co[:,0],co[:,1])-rho,co[:,2]-z)
frame['circle_distance_residual']=float(np.max(np.abs(dist_native-dist_co)))
frame['pair_distance_residual']=0.;frame['phase_difference_residual']=0.
for arm in ['CONTINUE','RETURN']:
    for added in range(4):
        ix=[i for i,r in enumerate(boundary) if r['arm']==arm and r['added_blocks']==added]
        p=world[ix];q=rotworld[ix]
        d1=np.linalg.norm(p[:,None,:]-p[None,:,:],axis=2);d2=np.linalg.norm(q[:,None,:]-q[None,:,:],axis=2)
        frame['pair_distance_residual']=max(frame['pair_distance_residual'],float(np.max(np.abs(d1-d2))))
        az1=np.arctan2(native[ix,1],native[ix,0]);az2=np.arctan2(co[ix,1],co[ix,0])
        frame['phase_difference_residual']=max(frame['phase_difference_residual'],float(np.max(np.abs(circ(circ(az1-az1[0])-circ(az2-az2[0]))))))
observer_raw=dict(native_states=native,world_states=world,rotated_world_states=rotworld,recovered_components=co,Q=Q,origin=O)
for name in ['plus','minus','host_vertices']:
    vertices=geo[name];rot=O+(vertices-O)@Q.T
    d1=np.linalg.norm(world[:,None,:]-vertices[None,:,:],axis=2)
    d2=np.linalg.norm(rotworld[:,None,:]-rot[None,:,:],axis=2)
    frame[name+'_vertex_distance_residual']=float(np.max(np.abs(d1-d2)))
    frame[name+'_nearest_vertex_distance_range']=[float(d1.min(axis=1).min()),float(d1.min(axis=1).max())]
    observer_raw[name]=vertices;observer_raw[name+'_rotated']=rot
    observer_raw[name+'_nearest_vertex_distance']=d1.min(axis=1)
for key in ['faces','host_faces','boundary_edges']:observer_raw[key]=geo[key]
phis=np.linspace(0,2*np.pi,361);circle=O+np.column_stack((rho*np.cos(phis),rho*np.sin(phis),np.full_like(phis,z)))
observer_raw['circle']=circle;observer_raw['circle_rotated']=O+(circle-O)@Q.T
frame['circle_recovered_residual']=float(np.max(np.abs((observer_raw['circle_rotated']-O)@Q-(circle-O))))
for key,val in frame.items():
    if 'residual' in key:assert val<1e-12,(key,val)
frame.update(source_geometry_sha256=sha(BASE/'received/reference/CA01_geometry_reference.npz'),
    source_topology='Saved PLUS and MINUS arrays, 24 triangles per hand, 12 open-boundary edges, 3 host octagons; no caps or reconstruction.',
    role='Rigid-frame consistency and contextual relational distances; no demonstrated extra dynamical invariant or predictive correspondence.',
    hand_limitation='Nearest vertex distance does not distinguish the two face hands sharing the vertex set.',
    transformed_trajectory_calls=0,scale=1,observer_feedback=False)
np.savez_compressed(BASE/'OBSERVER.npz',**observer_raw);savej('OBSERVER_CHECKS.json',frame)
verification=dict(status='PASS',passive_saved_transitions=count,saved_states=states_count,fresh_state_advance_calls=0,
    inherited_preflight=R['passive_preflight'],residual_maxima=maxima,minima=minimum,maximum_raw_torque=maxq,clipped_records=clips,
    analytic_Jacobian_saved_steps=800,Jacobian_residuals=jac_checks,observer_observations=64,
    error_scope='All residual thresholds 1e-12; no certified inherited/accumulated floating error bound.',
    software=dict(python=sys.version,numpy=np.__version__))
savej('VERIFICATION.json',verification)
results=dict(history=history,boundaries=boundary,block_responses=responses,disturbances=disturb,
    tangent_comparisons=tangent_comparisons,branches=observed,
    tail_estimates={str(f):tail(f) for f in [800,1600,2400,3200]},
    tail_scope='Uninterrupted fade only; RETURN boundary tail is counterfactual before the declared final stop.',
    numerical_stage_counts=R['counts'])
savej('COMPARISON_RESULTS.json',results)
print(json.dumps(dict(history_final=[r for r in history if r['added_blocks']==3],
    cardinal_final=[r for r in boundary if r['added_blocks']==3 and r['case'].startswith('A')],
    disturbances_final=[r for r in disturb if r['local_state_index']==800],tangent=tangent_comparisons,
    tail_estimates=results['tail_estimates'],verification=verification,frame=frame),indent=2))
