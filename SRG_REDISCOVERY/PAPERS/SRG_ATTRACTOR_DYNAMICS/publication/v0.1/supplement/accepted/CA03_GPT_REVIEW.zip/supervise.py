"""One launch only, hard 600-second timeout, no retry."""
from pathlib import Path
import ast, datetime, hashlib, json, os, subprocess, sys, time
BASE=Path(__file__).resolve().parent
for name in ['run_stage.py','model.py']:ast.parse((BASE/name).read_text(encoding='utf-8'))
cmd=[sys.executable,'-B',str(BASE/'run_stage.py')]
record=dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,cwd=str(BASE),
    timeout_seconds=600,launch_count=1,automatic_restart=False,
    script_hashes={name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in ['run_stage.py','supervise.py','model.py']})
launch=BASE/'evidence/NUMERICAL_LAUNCH.json'
with launch.open('x') as f:json.dump(record,f,indent=2)
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
for key in ['TMP','TEMP','MPLCONFIGDIR']:
    p=BASE/'cache'/key;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
t=time.monotonic()
with (BASE/'evidence/numerical_stdout.txt').open('wb') as log:
    try:
        child=subprocess.run(cmd,cwd=BASE,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
        record['returncode']=child.returncode;record['status']='COMPLETED' if child.returncode==0 else 'CHILD_FAILED'
    except subprocess.TimeoutExpired:record['status']='TIMEOUT_KILLED_NO_RESTART'
record['elapsed_seconds']=time.monotonic()-t
launch.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print((BASE/'evidence/numerical_stdout.txt').read_text())
