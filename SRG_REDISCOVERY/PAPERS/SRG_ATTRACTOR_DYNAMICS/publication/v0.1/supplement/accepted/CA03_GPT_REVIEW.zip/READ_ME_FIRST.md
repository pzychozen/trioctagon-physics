# CA03 — The trace survives three returning pulses, but shrinks

**The earlier angular traces remain distinct after the drive returns three times. Their separations shrink by about 36.8%, leaving about 63.2% of each checkpoint difference.** When the original clock simply continues, those same differences remain essentially unchanged at the available floating precision.

We started from the exact saved CA02 states at update 800. No prefix was rerun and no state was reconstructed from a rounded endpoint table. RETURN restarts only the forcing clock; both schedules carry the complete state through every block.

The differences below are measured against the same-schedule A0p reference, in radians:

| Earlier difference | At the checkpoint | After three RETURN pulses |
|---|---:|---:|
| Half initial size | −0.001112180 | −0.000702991 |
| 1.5 times initial size | +0.001119389 | +0.000707462 |
| Earlier zero tilt | −0.001611355 | −0.001018540 |
| Earlier pi/4 tilt | +0.007988609 | +0.005046949 |

All four keep their signs. They retain roughly 85.9% after one pulse, 73.7% after two, and 63.2% after three. There are small within-pulse reversals of the contraction, so this is a net block result. The cardinal controls also move by different amounts; the change is not a common rotation that merely disguises the old distinctions.

The six later disturbances give a second result. Applying a small size or tilt change at the A0p checkpoint creates a new angular trace during the returning drive. After one block, size changes of ±0.0001 leave approximately ±0.191 microradians, and tilt changes of ±0.0001 radians leave approximately ±1.076 microradians. A direct ±100-microradian phase change contracts to approximately ±85.922 microradians. These are separate controlled directions at one disturbance size, not a general noise study. Analytic derivatives propagated along the saved reference agree closely with the paired disturbance runs.

**What is proved:** the finite block has a phase-dependent leading response. Its two simple leading zeros continue to genuine fixed points of the full two-coordinate block map for sufficiently small nonzero coupling. For small positive coupling one is locally attracting and the other is a saddle; negative coupling reverses those roles. The argument solves the meridional fixed-point equation rather than pretending every block lies exactly on the old circle.

**What remains unproved:** those local results do not certify the chosen coupling 1/32, its global basins, or the indefinite fate of these eight histories. Three-pulse contraction is not exact erasure. Conversely, indefinite restarting can support local asymptotic coalescence under the small-coupling theorem, so the finite survival observation is not a promise of permanent protection.

The fading-tail bound applies only when the drive is allowed to fade without another restart. After the final RETURN pulse its estimate is 2.14 × 10⁻¹¹ radians per state. This excludes inherited and accumulated floating-point error; the observed finite-coupling separations are numerical evidence, not certified intervals.

The geometric instrument helped separate meridional contraction from angular differences. Rotating the actual reference, data and measuring axes together preserved phase differences and distances to floating precision. The crystal supplied positional context; no additional invariant or predictive correspondence was established. It supplied no confinement, force or state fitting.

Exactly **22 branches and 43,200 fresh updates** completed in one numerical launch. All 36 inherited preflight evaluations matched exactly; independent saved-record checks passed. Clipping and the advancing or returning clock schedules were preserved. Source hashes and repository state are recorded; CA01, CA02 and the kernels remain untouched. No staging, commit, push or publication occurred.

Read CA03_RETURNING_DRIVE_ANALYSIS.md for proofs and numerical qualifications; figures/ contains the three explanatory plots. The CSV/JSON tables, raw/, input identities and VERIFICATION.md support review without rerunning the numerical stage. The complete payload manifest is in CA03_GPT_REVIEW.zip; its receipt is beside the archive.
