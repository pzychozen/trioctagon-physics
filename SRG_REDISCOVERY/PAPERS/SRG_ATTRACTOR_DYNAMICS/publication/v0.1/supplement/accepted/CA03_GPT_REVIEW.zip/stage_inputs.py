"""Bounded scalar algebra and one-time input definitions; no recurrence calls."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import ast, hashlib, json
import numpy as np
BASE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def savej(name,obj):(BASE/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
assert not (BASE/'INPUTS.npz').exists(), 'Inputs already fixed'
def interval(v):return (F(v),F(v))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    p=[x*y for x in a for y in b];return min(p),max(p)
def div(a,b):
    assert not b[0]<=0<=b[1]
    return mul(a,(1/b[1],1/b[0]))
scale=10**50
def sqrt_floor(x):return F(isqrt(x.numerator*scale**2//x.denominator),scale)
def sqrt_i(x):return sqrt_floor(x[0]),sqrt_floor(x[1])+F(1,scale)
sqrt3=sqrt_i(interval(3))
r=div(add(interval(3),sqrt3),interval(4))
b=div(sub(sqrt3,interval(1)),interval(4))
z=sqrt_i(div(sqrt3,interval(8)))
coef=[b,mul(interval(2),add(r,z)),interval(0),mul(interval(2),sub(r,z)),neg(b)]
def poly(v):
    value=coef[0]
    for c in coef[1:]:value=add(mul(value,interval(v)),c)
    return value
def sign(v):
    if v[0]>0:return 1
    if v[1]<0:return -1
    raise ArithmeticError('Scalar interval cannot certify sign; no adaptive search')
def serialize(v):return [str(q) for q in v]
roots=[]
for lo,hi,quadrant in [(F(0),F(1),'I'),(F(-32),F(-1),'III')]:
    slo=sign(poly(lo));assert slo!=sign(poly(hi))
    for _ in range(64):
        mid=(lo+hi)/2;sm=sign(poly(mid))
        if sm==slo:lo=mid
        else:hi=mid
    vi=(lo,hi);v2=mul(vi,vi);c=div(sub(interval(1),v2),add(interval(1),v2))
    slope=sub(mul(z,mul(c,c)),div(r,c))
    ph=float(2*np.arctan(float((lo+hi)/2)))
    if ph<0:ph+=2*np.pi
    roots.append(dict(quadrant=quadrant,v_bracket=serialize(vi),bracket_width=str(hi-lo),
        polynomial_at_lower=serialize(poly(lo)),polynomial_at_upper=serialize(poly(hi)),
        Gprime_interval=serialize(slope),Gprime_sign=sign(slope),
        phase_estimate=ph,Gprime_estimate=float((slope[0]+slope[1])/2)))
def Z(w):return np.expm1(800*w)/np.expm1(w)
KN=float(.1*(2*np.real(Z(-.05+.1j))+np.imag(Z(-.03+.1j))+1.5*Z(-.07)+Z(-.04)))
scalar=dict(N=800,K_N_estimate=KN,roots=roots,
    coefficient_interval_precision='Exact rational square-root brackets on a 10^50 grid; integer square roots.',
    root_bisections_per_root=64,root_count=2,phase_estimates='Ordinary binary64 atan; rigorous root brackets refer to v=tan(phi/2).',
    meridional_multiplier_exact='(sqrt(3)-2)^800; positive, nonzero, less than one; not evaluated as a binary64 zero.')
savej('SCALAR_ANALYSIS.json',scalar)
index=json.loads((BASE/'received/CHECKPOINT_INDEX.json').read_text())
states={};lifts={};origins=[]
for row in index['checkpoints']:
    source=BASE/'inputs/CA02'/row['archive_member']
    assert sha(source.read_bytes())==row['member_sha256']
    with np.load(source,allow_pickle=False) as data:
        sb=data['states'][800].copy();ph=data['phase_lift'][800].copy()
    states[row['case_id']]=sb;lifts[row['case_id']]=float(ph)
    origins.append(dict(id=row['case_id'],kind='checkpoint',member=row['archive_member'],member_sha256=row['member_sha256'],
        state_row_bytes_sha256=sha(sb.tobytes()),phase_row_bytes_sha256=sha(ph.tobytes()),
        actual_state=sb.tolist(),phase_lift=float(ph)))
sb=states['A0p'];rho=np.hypot(sb[0],sb[1]);L=np.linalg.norm(sb);phi=np.arctan2(sb[1],sb[0]);beta=np.arctan2(sb[2],rho);eta=1e-4
spherical_zero=L*np.array([np.cos(beta)*np.cos(phi),np.cos(beta)*np.sin(phi),np.sin(beta)])
phase_zero=np.array([rho*np.cos(phi),rho*np.sin(phi),sb[2]])
for kind in ['SIZE','TILT','PHASE']:
    for sign_,suffix in [(1,'+'),(-1,'-')]:
        if kind=='SIZE':v=(1+sign_*eta)*sb
        elif kind=='TILT':
            bb=beta+sign_*eta
            v=L*np.array([np.cos(bb)*np.cos(phi),np.cos(bb)*np.sin(phi),np.sin(bb)])
        else:
            pp=phi+sign_*eta;v=np.array([rho*np.cos(pp),rho*np.sin(pp),sb[2]])
        name=kind+suffix;ph=lifts['A0p']+(sign_*eta if kind=='PHASE' else 0.)
        states[name]=v;lifts[name]=ph
        angle_residual=float(np.arctan2(np.sin(ph-np.arctan2(v[1],v[0])),np.cos(ph-np.arctan2(v[1],v[0]))))
        assert abs(angle_residual)<1e-12
        origins.append(dict(id=name,kind='one-time disturbance',reference='A0p',parameter=kind,eta=sign_*eta,
            actual_state=v.tolist(),phase_lift=ph,state_row_bytes_sha256=sha(v.tobytes()),
            phase_row_bytes_sha256=sha(np.asarray(ph,dtype=np.float64).tobytes()),angle_lift_residual=angle_residual,
            norm=float(np.linalg.norm(v)),horizontal_radius=float(np.hypot(v[0],v[1]))))
for key,v in states.items():
    assert v.dtype==np.float64 and np.isfinite(v).all() and np.linalg.norm(v)<1.501
    assert np.hypot(v[0],v[1])>.4998
np.savez_compressed(BASE/'INPUTS.npz',**{k:v for k,v in states.items()},
                    **{k+'_phase':np.asarray(v,dtype=np.float64) for k,v in lifts.items()})
savej('INPUT_DEFINITIONS.json',dict(eta=eta,origins=origins,
    A0p_reference_coordinates=dict(rho=float(rho),L=float(L),phi=float(phi),beta=float(beta)),
    construction_rounding=dict(spherical_zero_max_abs=float(np.max(np.abs(spherical_zero-sb))),
                               cylindrical_zero_max_abs=float(np.max(np.abs(phase_zero-sb)))),
    inputs_sha256=sha((BASE/'INPUTS.npz').read_bytes()),
    initial_q_bound_exact_definition='4.5*(1.5*(1+1e-4))^2/32',
    initial_q_bound_estimate=float(4.5*(1.50015)**2/32),
    conservative_binary_gate_bound=float(4.5*(1.501)**2/32)))
model=(BASE/'inputs/CA02/model.py').read_bytes()
assert sha(model)=='8a33ac0d51cb32d5e23688bffd6bfb6a27b90214e3a7c7018b30a2cc795d6408'
(BASE/'model.py').write_bytes(model)
funcs=[n for n in ast.parse(model.decode()).body if isinstance(n,ast.FunctionDef)]
savej('evidence/MODEL_IDENTITY.json',dict(byte_identical=True,sha256=sha(model),
    functions=[dict(name=n.name,ast_sha256=sha(ast.dump(n,include_attributes=False).encode())) for n in funcs],
    original_runner_executed=False,original_prefix_rerun=False))
path=BASE/'CA03_RETURNING_DRIVE_ANALYSIS.md'
analysis=path.read_text(encoding='utf-8')
scalar_text='### Bounded scalar evaluation before the rollout\n\n'
scalar_text+=f'The finite-sum estimate is K_800 = {KN:.15g}. Exact rational interval bisection (64 steps per root) gives the v brackets and slope-sign certificates in SCALAR_ANALYSIS.json. Ordinary phase estimates are {roots[0]["phase_estimate"]:.12f} and {roots[1]["phase_estimate"]:.12f} radians; the corresponding G-prime estimates are {roots[0]["Gprime_estimate"]:.12f} and {roots[1]["Gprime_estimate"]:.12f}. These are leading roots, not numerically located fixed points of T at a=1/32.\n\n'
analysis=analysis.replace('## 4. Finite contraction',scalar_text+'## 4. Finite contraction')
path.write_text(analysis,encoding='utf-8')
(BASE/'evidence/PRE_RUN_ANALYSIS.md').write_bytes(path.read_bytes())
savej('evidence/PRE_RUN_SEAL.json',{name:sha((BASE/name).read_bytes()) for name in
    ['CA03_PLAN.md','CA03_RETURNING_DRIVE_ANALYSIS.md','model.py','INPUTS.npz','INPUT_DEFINITIONS.json','SCALAR_ANALYSIS.json']})
print(json.dumps(dict(K_N=KN,root_phase_estimates=[r['phase_estimate'] for r in roots],
    root_slope_estimates=[r['Gprime_estimate'] for r in roots],input_count=len(states),
    max_initial_norm=max(float(np.linalg.norm(s)) for s in states.values()),fresh_updates=0),indent=2))
