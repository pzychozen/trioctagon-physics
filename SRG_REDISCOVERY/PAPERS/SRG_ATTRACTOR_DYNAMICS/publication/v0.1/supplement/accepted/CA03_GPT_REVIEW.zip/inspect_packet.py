"""Read the CA03 packet and instructions without executing included code."""
from pathlib import Path
import hashlib, json, zipfile, sys
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[2]
for folder in [*reversed(REPO.parents),REPO,BASE.parent.parent,BASE.parent,BASE]:
    p=folder/'AGENTS.md'
    if p.exists():print('\nINSTRUCTIONS',p,'\n',p.read_text(encoding='utf-8'))
p=Path(r'C:\Users\Notandi\Downloads\SRG_CA03_CODEX_START_PACKET.zip')
print('PACKET SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
with zipfile.ZipFile(p) as z:
    print('MEMBERS',json.dumps(z.namelist(),indent=2))
    for name in z.namelist():
        if name.endswith(('SRG_CA03_CODEX_WORK_ORDER.md','CHECKPOINT_INDEX.json','SOURCE_ANCHORS.md','MANIFEST.json')):
            print('\nFILE',name,'\n',z.read(name).decode('utf-8-sig'))
