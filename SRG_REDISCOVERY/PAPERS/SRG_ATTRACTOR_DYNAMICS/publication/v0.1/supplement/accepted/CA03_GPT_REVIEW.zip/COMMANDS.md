# CA03 commands and safe review

All shell commands used Windows CMD (cmd.exe, login=false), prefixed by call conda activate torment. Python used -B. All task scripts ran with this CA03 directory as their working directory. No dependency installation or original runner import/launch occurred.

The task sequence was:

~~~bat
call conda activate torment && python -B inspect_packet.py
call conda activate torment && python -B prepare.py
call conda activate torment && python -B stage_inputs.py
call conda activate torment && python -B supervise.py
call conda activate torment && python -B analyze_saved.py
call conda activate torment && python -B render_figures.py
call conda activate torment && python -B package_review.py
~~~

Read-only inspection also used rg/dir/type and Git HEAD/status/index queries. The initial rg search found no AGENTS.md under the repository; explicit ancestor instruction checks found none. The plan and initial derivation were written before stage_inputs.py, which performed only bounded scalar/root computations and one-time vector construction, copied the inspected pure evaluator, and preserved the pre-run analysis and seal.

supervise.py launched one numerical child, with a 600-second hard timeout and a launch marker prohibiting repetition. Its exact executable, arguments, script hashes, UTC time and duration are retained in evidence/NUMERICAL_LAUNCH.json. The child made 36 passive inherited-input evaluations and 43,200 fresh calls. No prefix was chained or rerun. Checkpoints were loaded from their original NPZ rows and compared by bytes. Partial block checkpoint saving did not start new trajectories.

analyze_saved.py imported no model and made no new state advances. It independently checked saved component equations, schedules, angular readouts, analytic Jacobians and passive frame changes. render_figures.py also used saved arrays only. Its first invocation failed at parsing because of an extra closing parenthesis; after that typo was corrected it rendered successfully. A subsequent layout-only rerender moved figure-2 annotations. These attempts are documented and do not change numerical counters.

package_review.py performs final read-only consumed-source/Git checks and archive validation. It writes the manifest and final receipt without launching another numerical stage. The receipt lives outside the ZIP to avoid circular self-hashing.

Review the saved evidence rather than rerunning supervise.py, run_stage.py, or inherited runners. The complete 43,200-call authorization has been used. NPZ files load with allow_pickle=False; no pickle deserialization is required. A separate future numerical investigation would need its own scope. No stage, commit, push, release or publication command was issued.
