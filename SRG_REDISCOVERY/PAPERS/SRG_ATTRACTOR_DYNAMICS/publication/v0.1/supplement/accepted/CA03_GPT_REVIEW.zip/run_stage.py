"""One bounded CA03 numerical stage. No prefix replay and no automatic repetition."""
from pathlib import Path
import hashlib, json, os, sys, time, traceback
BASE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
for key in ['TMP','TEMP','MPLCONFIGDIR']:
    p=BASE/'cache'/key;p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
import numpy as np
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
seal=json.loads((BASE/'evidence/PRE_RUN_SEAL.json').read_text())
for name,expected in seal.items():assert sha(BASE/name)==expected,('Sealed input changed',name)
import model
T0=time.monotonic();OUT=BASE/'raw'
assert not OUT.exists(),'Raw stage already exists; do not rerun'
OUT.mkdir()
R=dict(status='PREFLIGHT',alpha=1/32,N=800,dt=.1,counts=dict(passive_CA01_fixture_calls=0,
    passive_CA02_saved_row_calls=0,inherited_prefix_updates_executed=0,fresh_branches_started=0,
    fresh_branches_completed=0,fresh_rollout_calls=0,fresh_isolated_calls=0,failed_model_calls=0,kernel_updates=0),
    limits=dict(fresh_branches=22,fresh_rollout_calls=43200,fresh_isolated_calls=0,seconds=600,bytes=250000000),
    environment=dict(python=sys.version,executable=sys.executable,numpy=np.__version__),branches=[],errors=[])
rho_star=(3+np.sqrt(3.))/4;z_star=.5*np.sqrt(np.sqrt(3.)/2)
R['circle']=dict(rho_star=float(rho_star),z_star=float(z_star))
def dump():
    R['elapsed_seconds']=time.monotonic()-T0
    (BASE/'RUN_RESULTS.json').write_text(json.dumps(R,indent=2,allow_nan=False)+'\n')
def size():return sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())
def guard(reserve=0):
    if time.monotonic()-T0>=595:raise TimeoutError('595-second internal guard')
    if size()+reserve>250000000:raise RuntimeError('250 MB ceiling')
def check(v):
    s=v['s'];q=v['qhat'];u=v['u'];d=v['dest'];ss=float(s@s);uu=float(u@u);scale=max(1.,ss,uu)
    er=abs(uu-ss-.01*float(q@q));dot=abs(float(s@q));surface=abs((np.hypot(d[0],d[1])-1)**2+d[2]**2-.25)
    assert er/scale<1e-12 and dot/scale<1e-12 and surface<1e-12 and d[2]>=-1e-12
    return dict(euler_abs=er,euler_scaled=er/scale,perpendicular_abs=dot,perpendicular_scaled=dot/scale,surface_abs=float(surface))
def preflight():
    maxima=dict(values=0.,euler_abs=0.,euler_scaled=0.,perpendicular_abs=0.,perpendicular_scaled=0.,surface_abs=0.)
    old=json.loads((BASE/'inputs/CA02/inputs/CA01/RESULTS.json').read_text())
    def compare(v,saved):
        for k,val in v.items():
            err=float(np.max(np.abs(np.asarray(val,dtype=float)-np.asarray(saved[k],dtype=float))))
            maxima['values']=max(maxima['values'],err);assert err<1e-12,(k,err)
        for k,val in check(v).items():maxima[k]=max(maxima[k],val)
    for saved in old['F4_preflight']:
        R['counts']['passive_CA01_fixture_calls']+=1
        compare(model.step(np.asarray(saved['s'],dtype=float),saved['t'],saved['alpha']),saved)
    index=json.loads((BASE/'received/CHECKPOINT_INDEX.json').read_text())
    for row in index['checkpoints']:
        source=BASE/'inputs/CA02'/row['archive_member'];assert sha(source)==row['member_sha256']
        with np.load(source,allow_pickle=False) as data:
            for n in [0,400,799]:
                R['counts']['passive_CA02_saved_row_calls']+=1
                saved={k:data[k][n] for k in ['s','t','alpha','H','q','qhat','u','dest','clipped','factor']}
                v=model.step(data['s'][n].copy(),float(data['t'][n]),float(data['alpha'][n]))
                compare(v,saved)
                assert np.array_equal(v['dest'],data['states'][n+1])
    R['passive_preflight']=dict(passed=True,maximum_residuals=maxima,
        note='Independent inherited input rows; no outputs were chained. Axis fixture conventions retained only for those inherited fixtures.')
    assert R['counts']['passive_CA01_fixture_calls']==12 and R['counts']['passive_CA02_saved_row_calls']==24
    dump()
with np.load(BASE/'INPUTS.npz',allow_pickle=False) as data:inputs={k:data[k].copy() for k in data.files}
index=json.loads((BASE/'received/CHECKPOINT_INDEX.json').read_text())
cases=[row['case_id'] for row in index['checkpoints']]
for row in index['checkpoints']:
    with np.load(BASE/'inputs/CA02'/row['archive_member'],allow_pickle=False) as saved:
        assert inputs[row['case_id']].tobytes()==saved['states'][800].tobytes()
        assert inputs[row['case_id']+'_phase'].tobytes()==saved['phase_lift'][800].tobytes()
matrix=[dict(id=f'{case}_{arm}',case=case,arm=arm,updates=2400,kind='unperturbed')
        for case in cases for arm in ['CONTINUE','RETURN']]
matrix += [dict(id=case,case=case,arm='RETURN',updates=800,kind='disturbance')
           for case in ['SIZE+','SIZE-','TILT+','TILT-','PHASE+','PHASE-']]
assert len(matrix)==22 and sum(r['updates'] for r in matrix)==43200
R['matrix']=matrix;dump()
def save_raw(row,states,phases,records):
    arr=np.asarray(states,dtype=float);horizontal=np.hypot(arr[:,0],arr[:,1])
    raw={k:np.asarray([v[k] for v in records]) for k in records[0]} if records else {}
    raw.update(states=arr,phase_lift=np.asarray(phases,dtype=float),absolute_state_index=800+np.arange(len(states)),
        continuation_state_index=np.arange(len(states)),completed_new_blocks=np.arange(len(states))//800,
        meridional_theta=np.arctan2(arr[:,2],horizontal-1),polar_theta=np.arctan2(horizontal,arr[:,2]),
        distance_to_circle=np.hypot(horizontal-rho_star,arr[:,2]-z_star))
    path=OUT/(row['id']+'.npz');np.savez_compressed(path,**raw)
    row['raw']='raw/'+path.name;row['raw_sha256']=sha(path);row['saved_states']=len(states)
    dump()
try:
    preflight();guard(5000000);R['status']='RUNNING'
    for case in matrix:
        guard(5000000)
        state=inputs[case['case']].copy();phase=float(inputs[case['case']+'_phase'])
        assert np.linalg.norm(state)<1.501 and np.hypot(state[0],state[1])>.4998
        assert abs(np.arctan2(np.sin(phase-np.arctan2(state[1],state[0])),np.cos(phase-np.arctan2(state[1],state[0]))))<1e-12
        states=[state.copy()];phases=[phase];records=[]
        R['counts']['fresh_branches_started']+=1
        row={**case,'initial_state':state.tolist(),'initial_phase':phase,
            'initial_state_bytes_sha256':hashlib.sha256(state.tobytes()).hexdigest(),
            'completed_updates':0,'completed_blocks':0,'status':'RUNNING'}
        R['branches'].append(row);dump()
        try:
            for j in range(case['updates']):
                if time.monotonic()-T0>=595:raise TimeoutError('Internal deadline')
                n=800+j;block=j//800+1;f=n if case['arm']=='CONTINUE' else j%800
                assert R['counts']['fresh_rollout_calls']<43200
                R['counts']['fresh_rollout_calls']+=1
                try:v=model.step(state,.1*f,1/32)
                except Exception:
                    R['counts']['failed_model_calls']+=1;raise
                e=.1*v['qhat'];x,y,_=state;horizontal=float(np.hypot(x,y))
                numerator=float(x*e[1]-y*e[0]);denominator=float(x*x+y*y+x*e[0]+y*e[1])
                inc=float(np.arctan2(numerator,denominator));lower=horizontal-float(np.linalg.norm(e[:2]))
                v.update(n=n,j=j,block=block,f=f,angular_increment=inc,segment_rho_lower=lower,angle_denominator=denominator)
                records.append(v);states.append(v['dest'].copy());phases.append(phases[-1]+inc)
                check(v)
                assert lower>0 and denominator>0 and np.hypot(v['u'][0],v['u'][1])>0
                assert not v['clipped'] and v['factor']==1.,'Unexpected clipping'
                assert np.linalg.norm(v['q'])<(.317 if j==0 else 81/256+1e-12)
                state=v['dest'].copy();row['completed_updates']=j+1
                if (j+1)%800==0:
                    row['completed_blocks']=(j+1)//800
                    save_raw(row,states,phases,records);guard()
            row['status']='COMPLETED';R['counts']['fresh_branches_completed']+=1;dump()
        except Exception as exc:
            row['status']='STOPPED';row['error']=repr(exc)
            save_raw(row,states,phases,records)
            R['errors'].append(dict(id=row['id'],error=repr(exc),traceback=traceback.format_exc()))
            raise
    assert R['counts']['fresh_rollout_calls']==43200 and R['counts']['fresh_branches_completed']==22
    R['status']='COMPLETED'
except Exception as exc:
    R['status']='STOPPED';R['errors'].append(dict(stage_error=repr(exc),traceback=traceback.format_exc()))
finally:
    R['workspace_bytes_at_stage_end']=size();dump()
print(json.dumps(dict(status=R['status'],counts=R['counts'],elapsed_seconds=R['elapsed_seconds'],
                     workspace_bytes=R['workspace_bytes_at_stage_end'],errors=R['errors']),indent=2))
if R['status']!='COMPLETED':sys.exit(1)
