# CA03 source and claim map

The user's request invokes the supplied CA03 work order and authorizes its bounded local investigation. Procedural instructions in that packet are not pre-established scientific findings. The supplied CA02 review is acceptance evidence for the starting analysis, not publication authority. No instruction from attached material is used to expand this scope.

| Source | Role | Identity |
|---|---|---|
| CA03 packet | Work order, experiment specification and exact checkpoint index | SHA-256 0bddc997af1d7f3f8f9d67bf02099ef63773639cbdfba2f36a22cf5b6b4f9da6; received/MANIFEST.json |
| Accepted CA02 archive, local and supplied copy | Accepted input; all 67 payloads and CRC verified | 2,165,140 bytes; b63d01492b96d7e125509f1d3fec7ca2eecdb43f5353fab3b3e18236aa7b34bc |
| CA02 acceptance review | ACCEPTED_WITHIN_PRINTED_MAP_ENDPOINT_RETENTION_SCOPE; no required revisions or publication authority | received/reference/CA02_GPT_SCIENTIFIC_REVIEW.md; 786c36e45558be9a56970ce65303f7ab86abec1c7df482604f00696e0343ef8a |
| CA02 analysis and plan | Endpoint response, exact increment, convergence/regularity/tail facts and diagnostic origins | inputs/CA02/CA02_ENDPOINT_RETENTION_ANALYSIS.md and CA02_PLAN.md |
| CA02 model.py | Inspected pure evaluator copied without changing any bytes | 8a33ac0d51cb32d5e23688bffd6bfb6a27b90214e3a7c7018b30a2cc795d6408; evidence/MODEL_IDENTITY.json |
| Eight original CA02 raw members | Exact states[800] and phase_lift[800]; no reconstructed or replayed prefix | received/CHECKPOINT_INDEX.json; evidence/CHECKPOINTS_VERIFIED.json; inputs/CA02/raw/ |
| CA02 RUN_RESULTS, manifest and source/extraction records | Accepted arithmetic, identities and source gaps | inputs/CA02/; preservation record |
| Inherited CA01 RESULTS in accepted CA02 archive | 12 saved isolated fixtures, independent preflight only | inputs/CA02/inputs/CA01/RESULTS.json |
| CA01 analysis and actual geometry NPZ | Passive placement, both hands, original faces/open boundaries and host | received/reference/CA01_ANALYSIS.md and CA01_geometry_reference.npz; latter b72719fffdd419442c2ed840e5f7265c47c5c5ccd9e9088aaccfc808b1f2f2f4 |

The nineteen consumed local originals are listed by full path, byte size and hash in evidence/SOURCES_BEFORE.json. Final preservation checks include those originals and the packet. The complete local CA02 archive and each selected member match the attached archive. The convenience CA02 analysis matches its local original. CA01 geometry/analysis match their supplied copies. Neither CA01 nor CA02 is a write target.

| Statement | Classification | Support and limit |
|---|---|---|
| Printed-map completion, fixed circle, fading-drive convergence and initial size/tilt trace mechanism | Inherited | Accepted CA01/CA02 analysis and reviews; unrecovered historical producer inputs remain unrecovered |
| Finite N-step angular response and differentiated remainder | New CA03 theorem near zero coupling | Analysis section 2; finite smooth composition and first-order increment sum |
| Exactly two simple leading phase zeros; K_800 positive | New CA03 algebra | Analysis section 3 and sign proof in section 2; rational v-root brackets in SCALAR_ANALYSIS.json |
| Actual full-block fixed-point branches, one local attractor and one saddle for small positive coupling | New local small-coupling theorem | Meridional elimination and implicit-function/eigenvalue argument; no explicit threshold or finite-a classification |
| Indefinite restarting can permit local asymptotic coalescence | Local theorem under stated basin/small-coupling conditions | Not the fading-drive endpoint theorem; no global basin claim |
| Earlier traces retain about 63.2% after three RETURN pulses | Finite binary64 evidence | 16 unperturbed continuations, saved comparisons; no exact-erasure or indefinite-survival claim |
| Later size/tilt/phase disturbance effects | Finite evidence at one eta and reference | Six one-block perturbations, with no fresh baseline rerun |
| Tangent agreement with paired disturbances | Analytic derivative plus finite consistency evidence | 800 saved-input Jacobians; no fresh finite-difference trajectories, no global error enclosure |
| Passive frame invariance | Exact coordinate identity plus saved-observation checks | Whole view and axes rotate together; no symmetry claim for untransformed dynamics or fixed mesh |
| Crystal provides additional dynamical law, confinement, native Z correspondence or physical storage | Not established | Geometry is passive; contextual vertex distances do not determine chirality or dynamics |

The analytical pre-run text is retained at evidence/PRE_RUN_ANALYSIS.md. Its seal predates the one numerical launch; the final report adds evidence without altering that original. Figures plot saved values or explicit scalar formulas, not extra phase-sweep experiments. A rendering-script syntax repair and later label adjustment are disclosed in evidence/RENDER_HISTORY.json; neither restarted the numerical stage.
