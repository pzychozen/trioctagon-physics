# CA03 source anchors and packet scope

This packet prepares a new investigation. No CA03 trajectory, scientific checker,
phase-root computation or stability classification was executed while preparing it.
Archive/member integrity checks and reading the stored checkpoint metadata are not new rollouts.

## Inherited sources, unchanged

- `reference/CA02_GPT_REVIEW.zip`: the exact accepted submission; 67 manifested payloads plus its manifest. Read its analysis §§1, 3–5 and 7; plan; `model.py`; recorded results; and the eight raw members listed in `CHECKPOINT_INDEX.json`.
- `reference/CA02_ENDPOINT_RETENTION_ANALYSIS.md` and `reference/CA02_READ_ME_FIRST.md`: unchanged convenience copies of that archive's texts.
- `reference/CA02_GPT_SCIENTIFIC_REVIEW.md`: accepted internal review; limitations and no-publication status remain unchanged.
- `reference/CA01_ANALYSIS.md`: unchanged member of accepted `CA01_GPT_REVIEW.zip` (SHA-256 f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0).
- `reference/CA01_GPT_SCIENTIFIC_REVIEW.md`: unchanged earlier internal review.
- `reference/CA01_geometry_reference.npz`: unchanged bytes of CA01's `evidence/geometry_reference.npz`, renamed here only for clarity. Its geometry and passive placement are explained in the CA01 analysis/review. It supplies no dynamical coupling.

## New proposals

The returning-clock protocol, three added blocks, checkpoint continuation matrix,
six disturbances, finite-block response/stability tasks and passive frame check are
new CA03 experimental choices. They are not already proved results, historical
producer recovery, or changes to the accepted CA01/CA02 conclusions. All times and
coordinates retain their diagnostic, uncalibrated status.

## Local source locations

Authoritative checkout: `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`.
CA01: `SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA01_source_and_measurement_v0.1\`.
CA02: `SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA02_endpoint_retention_v0.1\`.
CA03 output: `SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA03_returning_drive_v0.1\`.

Do not infer a current Git HEAD from prior reports. No repository or remote was
changed during packet preparation. A work-order packet is not a scientific
publication payload and authorizes no Git write.
