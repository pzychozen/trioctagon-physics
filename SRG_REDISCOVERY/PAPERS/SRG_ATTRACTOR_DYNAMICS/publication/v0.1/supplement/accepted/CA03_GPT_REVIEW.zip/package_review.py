"""Preservation, final verification report and one CA03 review ZIP. No state advances."""
from pathlib import Path
from fractions import Fraction
import datetime, hashlib, json, subprocess, zipfile
BASE=Path(__file__).resolve().parent;REPO=BASE.parents[2]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):(BASE/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def read(name):return json.loads((BASE/name).read_text(encoding='utf-8'))
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
archive=BASE/'CA03_GPT_REVIEW.zip'
assert not archive.exists(),'Completed review archive already exists; no silent rebuild'
R=read('RUN_RESULTS.json');V=read('VERIFICATION.json');L=read('evidence/NUMERICAL_LAUNCH.json')
assert R['status']=='COMPLETED' and V['status']=='PASS' and L['status']=='COMPLETED'
assert R['counts']['fresh_rollout_calls']==43200 and R['counts']['fresh_branches_completed']==22
assert R['counts']['fresh_isolated_calls']==0 and R['counts']['inherited_prefix_updates_executed']==0
assert R['counts']['failed_model_calls']==0 and not R['errors'] and L['launch_count']==1
assert V['passive_saved_transitions']==43200 and V['saved_states']==43222
assert V['analytic_Jacobian_saved_steps']==800 and V['fresh_state_advance_calls']==0
assert R['workspace_bytes_at_stage_end']<250000000 and L['elapsed_seconds']<600
seal=read('evidence/PRE_RUN_SEAL.json')
for name,expected in seal.items():
    path=BASE/('evidence/PRE_RUN_ANALYSIS.md' if name=='CA03_RETURNING_DRIVE_ANALYSIS.md' else name)
    assert sha(path.read_bytes())==expected,('Pre-run seal differs',name)
for name,expected in L['script_hashes'].items():assert sha((BASE/name).read_bytes())==expected
for row in R['branches']:assert sha((BASE/row['raw']).read_bytes())==row['raw_sha256']
checked=[]
for row in read('evidence/SOURCES_BEFORE.json'):
    path=Path(row['path']);data=path.read_bytes()
    assert sha(data)==row['sha256'] and len(data)==row['size_bytes'],('Consumed source changed',str(path))
    if row['copy']:assert (BASE/row['copy']).read_bytes()==data
    checked.append({**row,'unchanged':True})
assert len(checked)==19
start=read('evidence/START.json')
packet=Path(r'C:\Users\Notandi\Downloads\SRG_CA03_CODEX_START_PACKET.zip')
assert sha(packet.read_bytes())==start['packet_sha256']
head=git('rev-parse','HEAD').decode().strip();branch=git('branch','--show-current').decode().strip()
status=git('status','--porcelain=v1','--untracked-files=normal')
index=git('diff','--cached','--name-status');tracked=git('diff','--name-status')
(BASE/'evidence/status_after.txt').write_bytes(status)
(BASE/'evidence/index_after.txt').write_bytes(index)
(BASE/'evidence/tracked_worktree_after.txt').write_bytes(tracked)
assert head==start['HEAD'] and branch==start['branch']
assert index==(BASE/'evidence/index_before.txt').read_bytes()
status_same=status==(BASE/'evidence/status_before.txt').read_bytes()
pres=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=checked,source_count=len(checked),
    all_consumed_sources_unchanged=True,packet_unchanged=True,HEAD_before=start['HEAD'],HEAD_after=head,
    branch_before=start['branch'],branch_after=branch,index_bytes_unchanged=True,status_bytes_unchanged=status_same,
    tracked_worktree_name_status=tracked.decode(),scope='Consumed artifacts and normal Git status only; no whole-repository byte census.',
    task_writes='Confined to CA03; CA01/CA02 and unrelated work read-only. No stage/commit/push/publication.')
write('evidence/PRESERVATION.json',pres)
SC=read('SCALAR_ANALYSIS.json')
for root in SC['roots']:
    lo=[Fraction(x) for x in root['polynomial_at_lower']]
    hi=[Fraction(x) for x in root['polynomial_at_upper']]
    assert (lo[1]<0 and hi[0]>0) or (lo[0]>0 and hi[1]<0)
    slope=[Fraction(x) for x in root['Gprime_interval']]
    assert (slope[1]<0 and root['Gprime_sign']==-1) or (slope[0]>0 and root['Gprime_sign']==1)
assert len(SC['roots'])==2 and all(r['root_bisections_per_root']==64 for r in [SC])
words=len((BASE/'READ_ME_FIRST.md').read_text(encoding='utf-8').split())
assert words<=800,words
figs=read('FIGURE_RECORD.json')
assert len(figs['figures'])==3 and len(list((BASE/'figures').glob('*.png')))==3
for row in figs['figures']:assert sha((BASE/row['path']).read_bytes())==row['sha256']
assert not list(BASE.rglob('*.pyc'))
write('evidence/DELIVERY_CHECKS.json',dict(summary_words=words,figures=3,
    visual_review='All three figures inspected; figure 2 annotations repositioned and re-inspected.',
    numerical_launches=1,fresh_calls_after_stage=0,passive_saved_transition_coverage=43200,
    scalar_root_certificates=2,pre_run_analysis_seal_verified=True,
    rendering_history='One parse failure before rendering, followed by a successful render and layout-only rerender; see RENDER_HISTORY.json.',
    unresolved='No certified accumulated floating-error enclosure, explicit small-alpha threshold or global classification at alpha=1/32.'))
obs=read('OBSERVER_CHECKS.json')
lines=['# CA03 verification and preservation','',
    '**PASS within the declared consistency criteria.** Unique numerical coverage and source checks are not counts of theorems.','',
    '## Authorized execution','',
    '| Quantity | Actual |','|---|---:|','| Unperturbed continuation branches | 16 |','| Disturbance branches | 6 |',
    '| Fresh rollout calls | 43,200 |','| Fresh isolated calls | 0 |','| Inherited prefix updates executed | 0 |',
    '| Failed model calls | 0 |','| Kernel updates | 0 |','| Numerical launches | 1 |',
    '| Passive inherited fixture evaluations | 12 |','| Passive CA02 saved-row evaluations | 24 |',
    '| Passive saved-transition coverage after the run | 43,200 |','| Saved states | 43,222 |',
    '| Saved-input analytic Jacobian evaluations | 800 |','| Passive frame boundary observations | 64 |',
    f"| Supervisor wall time | {L['elapsed_seconds']:.3f} seconds / 600 allowed |",
    f"| Workspace bytes at numerical-stage end | {R['workspace_bytes_at_stage_end']:,} / 250,000,000 allowed |",'',
    'All eight incoming checkpoint rows and phase values matched the indexed original NPZ bytes. Each was branched unchanged into the two clock schedules. The six disturbance vectors were constructed once from the exact A0p checkpoint. Original prefixes were not rerun. The 36 preflight outputs matched every inherited primary value exactly, with no chaining of their computed successors.','',
    'The copied model is byte-identical to accepted CA02 model.py. H, P, step and finite retain their bodies and operation order. run_stage.py and supervise.py still match their launch-time hashes. The pre-run plan, source copy, scalar results, input definitions and frozen mathematical analysis pass their seals. The final analysis adds numerical evidence without replacing that snapshot.','',
    '## Independent saved-record checks','',
    'All consistency thresholds were 1e-12. Scale-aware Euler/perpendicularity diagnostics divide by max(1,||s||²,||u||²). The checker uses explicit torque components and the closed-form remap, not the primary evaluator. It never chains a computed successor into another state.','',
    '| Residual | Maximum |','|---|---:|']
for key,val in V['residual_maxima'].items():lines.append(f'| {key} | {val:.9g} |')
lines+=['',f"Every clip factor was one; clipped records: {V['clipped_records']}. Maximum raw torque was {V['maximum_raw_torque']:.12g}, below the strict predeclared clipping bound. The minimum horizontal-segment lower bound was {V['minima']['segment_rho_lower']:.12g}, the minimum angular denominator {V['minima']['angle_denominator']:.12g}. All fresh remaps were finite/off-axis and all post-remap heights were nonnegative.",'',
    'Schedules were checked from j, n, block and f, including reset points at RETURN j=800 and 1600. CONTINUE always supplied f=n. All state/predecessor/successor linkage and inherited start bytes matched. Distances, meridional angles, phase increments and lifts were checked against saved states. The final future conventions were never simulated beyond the authorized horizons.','',
    '## Jacobian, scalar and observer checks','',
    '| Jacobian identity | Maximum residual |','|---|---:|']
for key,val in V['Jacobian_residuals'].items():lines.append(f'| {key} | {val:.9g} |')
lines+=['',
    'The tangent compares analytic derivatives of the same smooth map along 800 saved A0p RETURN steps. It uses no fresh finite-difference input. The paired ±eta central differences use only the six authorized disturbance branches. The largest central-minus-tangent discrepancy is about 1.54e-10 in parameter-derivative units. This is not an accumulated-roundoff enclosure or a certified higher-derivative bound.','',
    'The two roots of the leading angular factor were isolated by 64 exact rational interval bisections each, using square-root coefficient brackets on a 10^50 grid. Stored endpoint polynomial intervals have opposite strict signs and stored slope intervals exclude zero. Phase-angle displays and K_800 are ordinary binary64 estimates. The exact meridional multiplier remains symbolic and nonzero. No exact finite-a block fixed point was numerically solved.','',
    f"The fixed proper rotation was checked on {obs['observation_count']} indexed observations, including all four boundaries. Co-rotated phase-difference residual is {obs['phase_difference_residual']:.9g}; pair-distance residual is {obs['pair_distance_residual']:.9g}; point-to-circle and reference-vertex distance residuals are at most 4.44e-16. Both face hands, original open boundaries and host arrays remain intact. No geometry feedback or transformed trajectory was introduced.",'',
    '## Error interpretation','',
    'B_800(a) is approximately 2.13895878976e-11 rad; B_3200(a) is approximately 1.15050858390e-42 rad. These are estimates of retained exact analytic expressions for uninterrupted fading tails. Earlier RETURN boundaries cannot use B_800 as a bound on an actual forthcoming restarted pulse. Pairwise tails add. None encloses inherited checkpoint or accumulated binary64 error. A tiny tail is not a statement of many-digit state accuracy. Finite contraction is not exact erasure. The small-coupling block theorem does not classify global behavior at a=1/32.','',
    '## Source preservation and review','',
    f'All {len(checked)} consumed local originals retained their bytes, sizes and SHA-256 identities. They include the accepted CA02 archive and selected members, CA01 analysis and actual geometry. The supplied packet hash is also unchanged. Input copies match their originals. No whole-repository census was performed.','',
    f'HEAD before and after: {head}; branch: {branch}. Index bytes unchanged: True. Normal status bytes unchanged: {status_same}. Tracked worktree name/status output is '+('empty.' if not tracked else 'retained for review.'),'',
    'Task writes were confined to CA03. Existing unrelated untracked research was retained. No Git publication action occurred. These preservation statements combine the explicit consumed-source checks, unchanged tracked/index records and the scoped task operations; they are not a byte census of every unrelated file.','',
    f"Environment: {V['software']['python']}; NumPy {V['software']['numpy']}; Matplotlib {figs['matplotlib']}. CMD/torment was used throughout, with Python bytecode disabled and plotting/TMP caches kept inside CA03. No installation occurred.",'',
    'All three figures were visually inspected. One rendering-script parse error was repaired before the first successful render, and figure 2 received a layout-only label adjustment. These did not repeat the numerical stage; the actual attempt history is retained.','',
    'Start review with READ_ME_FIRST.md, then CA03_RETURNING_DRIVE_ANALYSIS.md, EVIDENCE_GUIDE.md and the tables. Inspect saved evidence instead of relaunching the stage. MANIFEST.json covers payload identities; REVIEW_ZIP_RECEIPT.json beside the archive supplies the ZIP hash and verification count without circular self-hashing.','']
(BASE/'VERIFICATION.md').write_text('\n'.join(lines),encoding='utf-8')
excluded={'MANIFEST.json','CA03_GPT_REVIEW.zip','REVIEW_ZIP_RECEIPT.json'}
payload=[]
for path in sorted(BASE.rglob('*')):
    if not path.is_file():continue
    rel=path.relative_to(BASE)
    if rel.parts[0]=='cache' or rel.as_posix() in excluded:continue
    data=path.read_bytes();payload.append(dict(path=rel.as_posix(),size_bytes=len(data),sha256=sha(data)))
assert sum(row['size_bytes'] for row in payload)<250000000
manifest=dict(scope='Completed local CA03 returning-drive research, not publication approval',files=payload,
    payload_count=len(payload),exclusions=['cache/**','manifest self-hash','archive self-hash','external ZIP receipt'],
    numerical_launches=1,fresh_rollout_calls=43200,figures=3)
write('MANIFEST.json',manifest)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
    for row in payload:zf.write(BASE/row['path'],row['path'])
    zf.write(BASE/'MANIFEST.json','MANIFEST.json')
with zipfile.ZipFile(archive) as zf:
    assert zf.testzip() is None
    assert len(zf.namelist())==len(payload)+1 and len(set(zf.namelist()))==len(zf.namelist())
    assert json.loads(zf.read('MANIFEST.json'))==manifest
    for row in payload:
        data=zf.read(row['path']);assert len(data)==row['size_bytes'] and sha(data)==row['sha256']
assert git('rev-parse','HEAD').decode().strip()==head and git('diff','--cached','--name-status')==index
receipt=dict(archive=str(archive),size_bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    manifested_payloads_verified=len(payload),archive_members=len(payload)+1,CRC='PASS',summary_words=words,
    figures=3,fresh_rollout_calls=43200,numerical_launches=1,all_consumed_sources_unchanged=True,
    HEAD=head,index_unchanged=True,status_unchanged=status_same,publication=False)
write('REVIEW_ZIP_RECEIPT.json',receipt)
print(json.dumps(receipt,indent=2))
