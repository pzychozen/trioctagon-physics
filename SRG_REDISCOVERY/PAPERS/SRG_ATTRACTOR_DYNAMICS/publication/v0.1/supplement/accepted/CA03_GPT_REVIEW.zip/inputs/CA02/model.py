"""CA02 pure evaluator: unchanged CA01 function ASTs; no source module execution."""
import numpy as np

def H(t):
    a1, b1 = (2.0, 0.5)
    alpha2, b2 = (1.0, 0.3)
    lambda1, omega1 = (1.5, 0.7)
    lambda2, omega2 = (1.0, 0.4)
    return a1 * np.exp(-b1 * t) * np.cos(t) + alpha2 * np.exp(-b2 * t) * np.sin(t) + lambda1 * np.exp(-omega1 * t) + lambda2 * np.exp(-omega2 * t)

def finite(*arrays):
    if not all((np.isfinite(a).all() for a in arrays)):
        raise FloatingPointError('nonfinite branch stopped')

def P(v):
    x, y, z = v
    theta = np.arctan2(np.sqrt(x * x + y * y), z)
    phi = np.arctan2(y, x)
    return np.array([(1 + 0.5 * np.cos(theta)) * np.cos(phi), (1 + 0.5 * np.cos(theta)) * np.sin(phi), 0.5 * np.sin(theta)])

def step(s, t, alpha):
    H = float(env['H'](t))
    q = alpha * H * np.cross(s, np.roll(s, 1))
    qnorm = float(np.linalg.norm(q))
    factor = min(1.0, 0.8 / (qnorm + 1e-05))
    qhat = q * factor
    u = s + 0.1 * qhat
    dest = P(u)
    finite(s, q, qhat, u, dest)
    return dict(s=s.copy(), t=float(t), alpha=float(alpha), H=H, q=q, qhat=qhat, u=u, dest=dest, clipped=bool(factor < 1.0), factor=factor)

env = {'H': H}
