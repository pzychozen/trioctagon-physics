# CA03 fixed plan — before fresh numerical execution

21 October 2026. Authority: the user's CA03 request and received/SRG_CA03_CODEX_WORK_ORDER.md. The accepted CA01/CA02 inputs remain read-only. All new files and caches stay in this directory. Use CMD, `call conda activate torment`, and Python `-B`; no installs, GUI, original runner, kernel or Git mutation.

## Sources and initial gate

HEAD is 2ecc2ded685fd210bd3cda226eb9731156dc167e, branch main. Status/index snapshots are saved. The supplied CA03 packet has SHA-256 0bddc997af1d7f3f8f9d67bf02099ef63773639cbdfba2f36a22cf5b6b4f9da6. Its manifest passed. The local accepted CA02 archive matches the attached archive, 2,165,140 bytes, SHA-256 b63d01492b96d7e125509f1d3fec7ca2eecdb43f5353fab3b3e18236aa7b34bc; all 67 payloads and CRC passed. The accepted review hash is 786c36e45558be9a56970ce65303f7ab86abec1c7df482604f00696e0343ef8a. Original consumed paths/hashes are in evidence/SOURCES_BEFORE.json.

CHECKPOINT_INDEX.json identifies A0p, A1p, A2p, A3p, Bhalf, Bthreehalf, Czero, Cquarter. Each original NPZ matches its member hash and has float64 states[0..800]. Load states[800] and phase_lift[800] from the verified copies directly; never from JSON displays or rounded endpoint tables. evidence/CHECKPOINTS_VERIFIED.json records exact row-byte hashes. Do not execute the 6400 inherited prefix updates again. Inspect and copy CA02 model.py byte-for-byte; import only that safe local copy.

## Written analysis before running

Complete CA03_RETURNING_DRIVE_ANALYSIS.md through the block expansion, leading roots, meridional elimination/full-block fixed-point argument, finite-versus-infinite protocol distinction, disturbance Jacobian, clipping and tail proofs. Preserve a pre-run copy and SHA-256. Bounded scalar calculations may evaluate K_800 and isolate the two roots of the derived quartic with exact rational interval arithmetic (at most 64 bisections each, 50 decimal digits for coefficient enclosures). No root-finding trajectory or phase sweep. Floating phase/root displays are estimates; rational root brackets provide the rigorous isolation in tan(phi/2).

## Exact fixed matrix and schedules

alpha=1/32; dt=.1; N=800. For each of the eight checkpoints run CONTINUE then RETURN, 2400 updates each. New index j=0..2399; actual n=800+j; new block b=floor(j/800)+1.

- CONTINUE supplies f=800+j and t=.1*f.
- RETURN supplies f=j mod 800 and t=.1*f. The state and lifted phase carry through j=800 and 1600 unchanged; only the forcing index returns to zero.

Then construct six one-time disturbances from the original A0p checkpoint, eta=1e-4, in the work-order order SIZE+, SIZE-, TILT+, TILT-, PHASE+, PHASE-. Use the exact definitions in section 5B with rho=hypot(x,y), L=norm(s), phi=atan2(y,x), beta=atan2(z,rho). SIZE uses (1±eta)s. TILT uses L(cos(beta±eta)cos(phi),cos(beta±eta)sin(phi),sin(beta±eta)). PHASE uses (rho cos(phi±eta),rho sin(phi±eta),z). Construct once, retain actual components, then run f=j=0..799 only. Carry the inherited lift for SIZE/TILT and add ±eta for PHASE. Compare with the already computed first RETURN block of A0p. Record construction-angle residual and the zero-perturbation spherical/cylindrical reconstruction residual as rounding diagnostics, not a changed baseline.

Ceilings: 22 branches, 43,200 attempted fresh model.step calls, zero fresh isolated probes. No numerical restart, prefix replay, new phase/alpha/eta, extra blocks, high-precision duplicate trajectories or alternate integrator.

## Preflight, guards and recording

Before fresh calls verify source/model byte identity; re-evaluate the 12 inherited CA01 fixtures and CA02 saved rows n=0,400,799 for each selected case (24). Each starts independently from saved input; compare all returned intermediate values and successor, never chain results. Count exactly 36 passive preflight evaluations separately.

Exact torus starts have norm<=1.5. The largest defined perturbed norm is <=1.5(1+eta)=1.50015. Thus ||q0||<=4.5*(1.50015)^2/32<.317<.8-1e-5. Subsequent ||q||<=81/256=.31640625. Allow a conservative 1.501 initial-norm gate for binary64 construction, still giving ||q||<.317. The smallest analytical initial horizontal radius is at least .5-1.5eta=.49985; the first displacement is <.0317. Subsequent clipped displacement <=.08 leaves radius>=.42. Verify actual inputs before execution, retaining clipping in every call. Off-axis, finite and clipping margins must pass; no axis regularization or state projection.

One child numerical process, supervised with a 600-second hard timeout; internal 595-second deadline. A launch marker refuses repeats. Enforce a 250,000,000-byte workspace/result ceiling, reserving 5 MB before each branch. Count attempted calls before invocation, including failures. Save all completed block prefixes at each 800-update boundary and each completed branch. On a normal failure save partial data and stop the entire stage; a hard kill may leave only the last block checkpoint and must be reported. No automatic retry.

Save every incoming state, q, qhat, factor/clipping flag, u, successor, alpha, H, t, n/j/b/f, short-segment angular increment, all lifted phases and 2401 or 801 states. Save state index, torus-meridional angle atan2(z,rho-1), polar angle atan2(rho,z), and distance sqrt((rho-rho_*)²+(z-z_*)²) to C. The torus-meridional readout for an off-torus disturbed initial point is only a chart measurement; no assumption of membership or projection follows. Post-remap membership is checked.

Absolute consistency tolerance 1e-12; Euler and perpendicularity checks additionally use scale max(1,||s||²,||u||²). Clock/index/row linkage and copied checkpoint bytes must match exactly. Record observed residuals separately from proof claims and global error bounds.

## Saved-evidence analysis, without new advances

Independently check all 43,200 saved successor relations using explicit component torque and the closed-form P. Compute pairwise phase differences modulo 2pi and continuous-lift differences; report wraps/sign changes and magnitude ratios to the original checkpoint difference, plus torus-meridional, (rho,z), full Cartesian and circle-distance readouts. Use boundary indices j=0,800,1600,2400. Cardinal movement is not pairwise erasure.

For six disturbances compare initial, first-update and full-block effects with A0p RETURN. Propagate the analytic 3D Jacobian along its first 800 saved steps for three parameter directions. This evaluates derivatives at saved inputs, without model.step calls or finite-difference trajectories. Compare ±eta central differences from the six authorized runs with that tangent prediction; report rounding and unknown higher-order constants. Do not infer a certified global enclosure or zero rank from binary64 underflow.

Final uninterrupted-tail convention: CONTINUE next f=3200, RETURN next f=800, disturbed branches next f=800. Retain exact B_f(a) and label scalar evaluations as estimates. At earlier RETURN boundaries B_800 describes only the counterfactual of no further restart. Indefinite restart has no summable forcing tail. Neither tail bound includes inherited or accumulated floating error.

## Passive instrument and figures

Reuse actual saved PLUS/MINUS geometry, faces, open-boundary indices, host vertices/faces and origin O. No rebuilding, fitting, new ball or scale changes. Apply Q=Rz(pi/3) to the entire saved view about O, including data, reference, circle and measuring axes. At all four boundaries for all 16 unperturbed branches (64 indexed observations), verify phase differences in co-rotated axes, pair distances, distance to C and distances to the saved reference vertices. Compare both hands without treating a vertex-set metric as chirality detection. Arrays stay unchanged; no transformed dynamics is executed.

Three figures maximum: history differences across boundaries; derived phase-dependent block response with finite observations; later disturbances with tangent comparison. An overlay is optional only if informative. Explain whether actual reference geometry adds anything predictive, even if no overlay is useful. Preserve complete data regardless of plotting choices.

## Completion

Return <=800-word READ_ME_FIRST.md, full derivation/results, source/claim map, plan, source/checkpoint copies, raw arrays, CSV/JSON evidence, scripts, counters, versions, commands, verification/preservation receipt and complete manifest in CA03_GPT_REVIEW.zip. Verify consumed sources and final HEAD/status/index; preserve unrelated changes. No staging, commit, push or publication.
