# CA03 — Does the retained trace survive a returning drive?

**Date:** 21 October 2026  
**Scientific lead:** GPT · **Analysis and implementation:** Codex · **Author:** Hilmir Frímann Halldórsson  
**Status:** New local investigation. CA01 and CA02 are accepted inputs, not write targets.  
**Authorization:** Read-only source inspection, mathematical analysis, the bounded detached continuations and passive measurements below. No production integration, changes to existing research, Git writes, or publication.

## 1. The scientific question

CA02 showed that an initial size or tilt difference can disappear from those coordinates while its earlier effect remains in the final angle. It did not establish how that trace responds to later activity.

> **When the same drive returns, does the earlier angular difference survive, grow, shrink, or become indistinguishable? What does a small later disturbance do to it?**

Study this question without changing the torque, clipping, Euler increment or active remap. Compare two explicitly different forcing schedules from identical saved states. Then make a separate, small disturbance comparison. These are new diagnostic protocols, not recovered historical Figure 4 inputs.

Hilmir's Tri-Octagon/crystal/central-ball/toroidal construction is an analytical and visual instrument, not an assumed physical object or container. It supplies no force, pressure, confinement, material boundary, or feedback. The historical TGMO remap is different: it is already an active operation in the recurrence. Keep these roles separate.

“Trace” means dependence of the evolving state or its later endpoint on earlier differences. Do not equate it with learning, a full record of the past, calibrated storage capacity, heat, magnetism or light.

This is a focused robustness test of one mechanism. It is not a full noise study, a replacement SRG model, a bifurcation atlas, or a proof of robustness under every numerical method. Lead the return with an ordinary-language answer, not a new publication manuscript.

## 2. Workspace and accepted sources

Authoritative checkout:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

Create a new destination, never reuse a completed output directory:

```text
SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA03_returning_drive_v0.1\
```

Read these accepted inputs first:

- **S1:** CA02 `CA02_ENDPOINT_RETENTION_ANALYSIS.md`, especially §§1, 3–5 and 7: the clock-indexed endpoint, exact angular increment, small-drive response, error distinctions and limitations.
- **S2:** `CA02_GPT_SCIENTIFIC_REVIEW.md`, supplied in this packet. Its acceptance is bounded and is not publication authorization.
- **S3:** CA02 `model.py`, `CA02_PLAN.md`, `RUN_RESULTS.json`, `MANIFEST.json`, `raw/*.npz` and source identities. The pure evaluator is the numerical authority; the original runners are not to be launched.
- **S4:** CA01 analysis/review and the inherited saved fixtures, only as needed for convergence, smooth-domain and remap facts.
- **S5:** CA01's `evidence/geometry_reference.npz` and its documented passive placement, for the read-only observer comparison. The packet includes the saved arrays and analysis; do not rebuild the crystal lane.

Accepted archive identity:

```text
CA02_GPT_REVIEW.zip
SHA-256 b63d01492b96d7e125509f1d3fec7ca2eecdb43f5353fab3b3e18236aa7b34bc
Bytes 2165140
```

The packet includes that unchanged archive, reference reports and `CHECKPOINT_INDEX.json`. Check their identities against the local accepted inputs. If a needed local copy is unavailable, use the verified attached archive under CA03; do not substitute another similarly named experiment. The index identifies exact archive members and checkpoint rows, not a replacement serialization of the state.

Use Windows CMD and the existing `torment` environment. No dependency installation, GUI, original runner import, kernel import, or automated historical-source hunt. Put every new file/cache/temp output under CA03; use `python -B`. Inspect scripts before importing. Copy the inspected pure evaluator unchanged into CA03 and import only that safe copy. Preserve H/P/step/finite function bodies and their arithmetic order. The new driver chooses the forcing-time argument; it does not rewrite those functions.

Record actual local HEAD and scoped status/index before and after. Hash only consumed sources and new outputs; no repeated whole-repository census. Preserve CA01, CA02, SRG Origins, SIM01/SIM02, historical originals, central-crystal/Z/chirality work, both kernels and unrelated working-tree changes. Do not revert concurrent unrelated changes to make a receipt look clean. No pull, checkout, stash, reset, staging, commit, push, release or external upload.

## 3. Preserve the recurrence; declare the new schedule

Keep the CA01/CA02 completion exactly:

\[
C(x,y,z)=(z,x,y),\quad \Delta t=0.1,\quad \alpha=a=1/32,
\]
\[
H(t)=2e^{-0.5t}\cos t+e^{-0.3t}\sin t+1.5e^{-0.7t}+e^{-0.4t},
\]
\[
q=\alpha H(t)(s\times Cs),\quad
\widehat q=q\min\left(1,\frac{0.8}{\|q\|+10^{-5}}\right),\quad
s^+=P(s+0.1\widehat q).
\]

The primary P uses `atan2(sqrt(x*x+y*y),z)` and `atan2(y,x)` followed by the original trigonometric torus parametrization. Its closed form is an independent checker, not a replacement evaluator. Do not replace Euler by an exact rotation, remove clipping, alter the roll, or add a normalization.

CA02 used one continuously advancing forcing clock. A restart there would have changed its question. **Here the restart is intentional, confined to a separately named experimental arm.** Distinguish actual update count, local continuation count, block number and supplied forcing time. No claim of calibrated physical time is made.

Let N=800. Each unperturbed branch starts from CA02's saved `states[800]`, immediately before absolute update n=800. The first 800 updates are inherited, not executed again. Let j=0,...,2399 count new updates, so n=800+j.

| Arm | Forcing index f at new update j | Supplied time | State at a block boundary |
|---|---|---|---|
| CONTINUE | f=800+j | t=0.1f | Keep the complete evolving state |
| RETURN | f=j mod 800 | t=0.1f | Keep the complete evolving state; reset only the forcing index |

RETURN therefore contains three additional copies of the original 800-sample drive, with starts at absolute n=800,1600,2400. A repeated drive profile does **not** mean repeated torque: the torque also depends on the retained state.

At the end of the three new blocks, stop numerical execution. For a *finite-pulse endpoint interpretation*, define the future with no further restarts: RETURN continues f=800,801,... from the last pulse, and CONTINUE continues f=3200,3201,... . No extra rollout is authorized. The existing tail argument may bound these hypothetical uninterrupted tails after its assumptions are checked.

Separately, the same block map may be studied on paper under indefinite periodic restart. That is a different infinite protocol. Do not apply the fading-drive endpoint theorem to it or describe every block boundary as a settled endpoint.

## 4. Mathematics first: define what survival would mean

Write `CA03_PLAN.md` and the initial mathematical analysis before running fresh continuations. No additional routine author approval is needed for the matrix below.

### 4.1 Separate movement of the whole pattern from loss of an earlier difference

For each size/tilt history compare its phase with A0p at the same absolute update and under the same schedule. Preserve continuous phase lifts and also report circular differences via atan2(sin(delta),cos(delta)). A common shift of both phases is not erasure.

Measure the signed difference, its magnitude, and—only where the initial difference is nonzero—the ratio to the inherited checkpoint difference. Keep the four cardinal starts as orientation controls, not as evidence of recovered hidden coordinates. Report any sign reversal or wrap separately. Track meridional separation and full Cartesian distance alongside phase when they matter.

Use precise outcomes: exact identity from an argument; asymptotic coalescence from a theorem; finite contraction/expansion; or unresolved distinction at the available numerical precision. A small or rounded-to-zero difference alone is not exact erasure. A lasting difference in a finite observation window is not a proof of indefinite protection.

### 4.2 A block response, not a falsely autonomous one-step endpoint

Define the full N-step map

\[
T_{\alpha,N}=F_{\alpha,N-1}\circ\cdots\circ F_{\alpha,0},
\]

where F uses the stated local forcing index. Repeated RETURN blocks iterate this map on the complete state. CONTINUE uses different, progressively later blocks.

After remapping, use torus coordinates

\[
s(\theta,\phi)=((1+\tfrac12\cos\theta)\cos\phi,
(1+\tfrac12\cos\theta)\sin\phi,\tfrac12\sin\theta).
\]

The inherited fixed circle has rho_*=(3+sqrt(3))/4, z_*=sqrt(sqrt(3)/2)/2 and its fixed meridional angle theta_*. At alpha=0, T has a contracting meridional direction and neutral azimuth. At nonzero drive **do not** replace every block's output by s_*(phi) or assume a closed phase-only recurrence. Finite residual tilt is retained in both the equations and saved checkpoints.

Use CA02's analysis to derive and verify the finite-block expansion on starts on that circle:

\[
\arg[T_{\alpha,N}(s_*(\phi))]
=\phi+\alpha K_NG(\phi)+O(\alpha^2),\qquad
K_N=0.1\sum_{m=0}^{N-1}H(0.1m),
\]
\[
G(\phi)=\frac{z_*^2}{\rho_*}\cos\phi
+z_*\sin\phi\cos\phi-\rho_*\sin\phi.
\]

Here arg means the lifted **horizontal** phase. The finite-sum expansion is a CA03 derivation target, not an already accepted CA03 result. Justify its domain, smoothness and differentiated remainder; compute K_N from a finite geometric sum. Differentiate with respect to phi only with the corresponding regularity justification.

Investigate whether the phase response expands distinctions in some directions and contracts them in others. A first-order derivative is not automatically an error-certified bound at a=1/32. The complete two-coordinate block map, not just G, controls repeated behavior.

### 4.3 Could returning drive select preferred phases?

Locate and classify the zeros of G analytically where possible; bound numerical root evaluations honestly. Determine the sign of K_N and the leading phase stability for small positive and negative alpha. This is a question, not a requirement to find any predetermined symmetry or constant.

If simple zeros support a continuation argument, investigate whether they yield genuine fixed points of the **full** block map for sufficiently small nonzero alpha. Solve or eliminate the meridional fixed-point equation as part of the argument; do not equate a root of the leading angular term with an exact finite-alpha state. Distinguish a block fixed point from the possibly nonconstant N-step motion within each block.

Such a result could explain a transition from a neutral family under faded forcing to phase selection under recurring forcing. Establish only the local/small-coupling statement actually proved. Do not infer global basin coverage, a particular minimal period, a universal phase-locking law, or classification at a=1/32 from the leading expansion. If a rigorous continuation argument does not close, retain the weaker response result and name the remaining gap; do not patch the model or launch new runs.

A finite number of smooth, locally invertible angular maps can shrink a distinction without deleting it exactly. Conversely an infinite sequence may have a different asymptotic outcome. Address that distinction rather than treating all contraction as information destruction. Complete classification at arbitrary coupling is not required.

### 4.4 Later disturbances and the roles of geometry

Use the six controlled perturbations in §5 to ask whether the three initially different directions now have different consequences. Compare them with the *same RETURN reference*, not with another clock or a reset state.

Where useful, derive the Jacobian of one step or the block response and propagate sensitivities along already saved trajectories. Use analytic derivatives on the verified smooth branch, with any approximation labelled; do not hide extra finite-difference trajectories inside a derivative calculation. One perturbation size tests local response at that scale, not all amplitudes or stochastic noise robustness.

Include the short structural distinction: when torque is zero, an active update s^+=P(s) can still change state, whereas repeatedly displaying P(s) for a state that is not advanced does not create evolution. This is a written comparison of operations, not authorization to replace the accepted recurrence or simulate a new no-remap engine.

## 5. Fixed, bounded numerical matrix

### A. Sixteen unperturbed continuation branches

Use these **eight** CA02 cases, all with alpha=+1/32:

| Cases | Earlier difference retained in the checkpoint |
|---|---|
| A0p, A1p, A2p, A3p | Four original cardinal starting azimuths |
| Bhalf, Bthreehalf | Original size variants; compare with A0p |
| Czero, Cquarter | Original equal-norm tilt variants; compare with A0p |

For each case, branch the same exact saved `states[800]` into CONTINUE and RETURN. Carry `phase_lift[800]` as the starting lift; do not recompute it on a different branch. Do not round, project, reinitialize from the endpoint table, change the scale or make a fitted circle state. Load NPZ with `allow_pickle=False` and retain dtype/component values.

Run each branch for exactly 2400 new updates (three blocks of 800). Save all 2401 states and per-step records. This is **8 × 2 × 2400 = 38,400 fresh updates**. The 6400 prefix updates across these eight original cases are inherited records, not new execution and not duplicated scientific counts.

### B. Six small, one-time disturbances at the reference checkpoint

Use the same A0p checkpoint s_b=(x_b,y_b,z_b). Set rho_b=hypot(x_b,y_b), L_b=||s_b||, phi_b=atan2(y_b,x_b), beta_b=atan2(z_b,rho_b). Fix eta=10^-4; size changes are fractional, angular changes are radians.

| Pair | Perturbed initial state | What stays fixed |
|---|---|---|
| SIZE+ / SIZE- | (1 +/- eta) s_b | Direction |
| TILT+ / TILT- | L_b (cos(beta_b +/- eta) cos(phi_b), cos(beta_b +/- eta) sin(phi_b), sin(beta_b +/- eta)) | Norm and azimuth |
| PHASE+ / PHASE- | (rho_b cos(phi_b +/- eta), rho_b sin(phi_b +/- eta), z_b) | Height and horizontal radius |

Construct each once; no per-step disturbance, no random noise, no normalization. Retain the actual vectors and document construction rounding. Choose the initial lift nearest the inherited lift: for PHASE use the inherited lift +/- eta, and for size/tilt continue the inherited branch, checking against the constructed vector's angle.

Each of these six branches receives only the **first RETURN block**, local f=0,...,799, then stops. Compare with the saved first RETURN block of A0p, not a new baseline rollout. This adds **6 × 800 = 4800 fresh updates**. A hypothetical endpoint after this block assumes the drive continues fading without a further restart.

### Budget and numerical gates

**Total ceiling: 22 continuation/perturbation branches and 43,200 fresh state-advance calls. No additional fresh isolated calls.** An incomplete or analytically redundant branch may reduce this count with an explanation. Do not extend horizons, change alpha/eta, add seeds, sweep phases, repeat the numerical stage, or run high-precision duplicate trajectories.

Verify before execution that every chosen checkpoint and perturbed start is off-axis with adequate margin. Use |H|<=4.5 and the post-remap ||s||<=1.5 bounds. Check the slightly enlarged initial norm for SIZE+ explicitly. Prove a sufficient inactive-clip margin including epsilon; nevertheless preserve and log the full clipping expression. An unexpected clip branch stops the numerical stage rather than being silently removed. Inherited bounds and binary64 checks have different evidential roles.

Preflight uses only saved inputs: the 12 inherited CA01 fixtures and CA02 rows n=0,400,799 for each of the eight selected cases (24 further passive evaluations). Check returned states and intermediate records against their original bytes/values using the inherited scale-aware 1e-12 consistency tolerances. These 36 evaluations do not advance a new trajectory and are counted separately. The existing pure evaluator must match its source identity before use.

One guarded numerical-stage launch; 600-second wall-time limit and 250 MB new-result ceiling. Count attempted calls, including failures, before invocation. Persist progress at block boundaries and completed branches; retain partial records on failure. No automatic restart. Source mismatches, nonfinite values, axis/branch violations, unexpected clipping or resource failures are stop conditions, not reasons to repair an input silently. Independent written analysis can continue within scope.

Record n, j, block number, forcing index f, t, H, alpha, state, torque before/after clipping, factor, pre-remap state, successor, angular increment/lift, meridional coordinate and distance to the inherited circle. Keep input origins and actual checkpoint hashes. The copy of the engine does not know the schedule; the driver records exactly which t it supplies.

## 6. Comparison, uncertainty and review

Compare unperturbed arms at equal absolute updates n=800,1600,2400,3200. For the disturbance test use absolute n=800,...,1600; each branch has the same RETURN schedule as its reference. Distinguish original size/tilt history from a newly injected size/tilt disturbance at the checkpoint.

Primary readouts:

- The four size/tilt phase differences from A0p under each schedule, including signed differences and magnitude ratios to their own checkpoint differences.
- The phase displacement of all four cardinal controls under each schedule, explaining why whole-pattern turning differs from loss of pairwise distinction.
- The six disturbance outcomes relative to the unperturbed RETURN reference; first-step versus full-block consequences where they differ.
- Distance to the inherited circle and normal/meridional differences; closeness to that circle at pulse boundaries is a diagnostic, not an imposed constraint.

Keep every endpoint statement clock-qualified. The CA02 bound B_N(a) controls an uninterrupted fading tail. At a sampled RETURN boundary, B_800 can describe the counterfactual “no further restarts from here”; it does **not** bound the actual remaining change once another pulse starts. At the final stop, the explicitly defined finite-pulse protocols allow that tail argument. CONTINUE uses the current original forcing index. Derive/check these applications rather than attaching the old endpoint error bar to periodic forcing.

The prior checkpoints and new calculations are binary64 states. A tail theorem for an exact trajectory does not bound inherited or accumulated floating-point error. Small one-step residuals, hash agreement or a tangent matrix do not supply a rigorous global enclosure. Retain exact bounds, label ordinary evaluations as estimates, and say when a distinction is only numerical evidence. Identical floating states are not an exact-arithmetic coalescence proof.

Independently re-evaluate saved successor relations and schedules without chaining calculated outputs into new states. Check finite values, the torque perpendicularity and Euler norm identity, remap surface, positive horizontal-segment margin, clipping regime and lift consistency. Analytic Jacobian checks may use symbolic differentiation and saved-input evaluation, but no uncounted model.step calls on fresh perturbations.

## 7. What the geometric instrument adds—or does not add

Provide a short, explicit assessment rather than a decorative overlay. The (theta,phi) return-map view can separate a contracting coordinate from retained angular differences and show how repeated input acts on each. State which conclusions are intrinsic to the recurrence and which are observation choices.

For the actual Tri-Octagon/crystal reference, reuse CA01's saved arrays and placement y=O+s, O=(0,sqrt(3)/6,0), unit scale and fixed axes. Preserve both face hands and open boundaries. No fit inside a ball, new toroidal guide, trajectory-dependent scale/recentering, hidden out-of-window states, native Z samples or geometry feedback.

Perform a passive frame-consistency check on saved observations at the four unperturbed checkpoints. One fixed proper rotation, for example Q=R_z(pi/3), may rotate the *entire view* about O: data, circle, reference and measuring axes together. Phase differences measured in the co-rotated axes and distances must agree. This is not a claim that Q is a symmetry of the fixed mesh or of the untransformed dynamics. If discussing equations in that frame, transform C to QCQ^-1 and P by the corresponding conjugation; no new trajectory in that frame is required.

Explicitly report whether the crystal overlay adds a useful relational readout or only contextual visualization. “No additional invariant or predictive correspondence found” is a legitimate result. Do not invent threefold dynamics from a resemblance, equate theta/phi with native Z clocks, or claim a material core. Do not defer the source/math work while asking Hilmir to choose a literal sphere interpretation.

## 8. Deliverables and acceptance standard

Return one `CA03_GPT_REVIEW.zip` with:

1. `READ_ME_FIRST.md` (aim for <=800 words): what happened to the earlier trace under later activity; what is proved, observed and unresolved; what the geometric view contributed.
2. `CA03_RETURNING_DRIVE_ANALYSIS.md`: definitions, unchanged update, new schedule, full block map, response/stability arguments, disturbance results, and finite-versus-infinite protocol/error distinctions.
3. The predeclared plan, exact checkpoint and input identities, copied pure evaluator, new driver, saved raw records, comparison tables, verification scripts/results, actual counters, software versions and commands.
4. Up to three explanatory figures: earlier-trace separation across pulse boundaries; phase-dependent block response and/or disturbance comparison; a passive geometry view only if it adds information. Label pulse counts, finite samples, different schedules and counterfactual endpoints. Connecting samples do not establish continuous motion or persistent circular orbits.
5. A compact consumed-source preservation receipt and complete payload manifest, plus instructions to review saved evidence without relaunching the numerical stage.

Classify statements as inherited CA01/CA02, new CA03 theorem, small-coupling/leading-order result, finite evidence, or unresolved. Report exactly which robustness directions were tested. Do not require trace survival, erasure or phase selection as a success condition. A clean contraction result is as useful as persistence when its mechanism and limitations are understood.

Do not change accepted files to accommodate a surprising result. No source archaeology beyond the identified inputs, publication manuscript, parameter tuning, kernel wiring, or Git operation is part of this assignment.

**End state:** a locally reviewable answer to whether later driving preserves or changes the earlier trace, while both the historical recurrence and the passive measuring framework retain their proper roles. GPT and Hilmir review before any further work or publication.
