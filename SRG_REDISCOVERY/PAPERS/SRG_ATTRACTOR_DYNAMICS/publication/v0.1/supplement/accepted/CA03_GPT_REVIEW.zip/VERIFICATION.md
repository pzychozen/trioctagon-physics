# CA03 verification and preservation

**PASS within the declared consistency criteria.** Unique numerical coverage and source checks are not counts of theorems.

## Authorized execution

| Quantity | Actual |
|---|---:|
| Unperturbed continuation branches | 16 |
| Disturbance branches | 6 |
| Fresh rollout calls | 43,200 |
| Fresh isolated calls | 0 |
| Inherited prefix updates executed | 0 |
| Failed model calls | 0 |
| Kernel updates | 0 |
| Numerical launches | 1 |
| Passive inherited fixture evaluations | 12 |
| Passive CA02 saved-row evaluations | 24 |
| Passive saved-transition coverage after the run | 43,200 |
| Saved states | 43,222 |
| Saved-input analytic Jacobian evaluations | 800 |
| Passive frame boundary observations | 64 |
| Supervisor wall time | 6.093 seconds / 600 allowed |
| Workspace bytes at numerical-stage end | 8,797,108 / 250,000,000 allowed |

All eight incoming checkpoint rows and phase values matched the indexed original NPZ bytes. Each was branched unchanged into the two clock schedules. The six disturbance vectors were constructed once from the exact A0p checkpoint. Original prefixes were not rerun. The 36 preflight outputs matched every inherited primary value exactly, with no chaining of their computed successors.

The copied model is byte-identical to accepted CA02 model.py. H, P, step and finite retain their bodies and operation order. run_stage.py and supervise.py still match their launch-time hashes. The pre-run plan, source copy, scalar results, input definitions and frozen mathematical analysis pass their seals. The final analysis adds numerical evidence without replacing that snapshot.

## Independent saved-record checks

All consistency thresholds were 1e-12. Scale-aware Euler/perpendicularity diagnostics divide by max(1,||s||²,||u||²). The checker uses explicit torque components and the closed-form remap, not the primary evaluator. It never chains a computed successor into another state.

| Residual | Maximum |
|---|---:|
| independent_H | 0 |
| component_torque | 0 |
| clip_factor | 0 |
| clipped_torque | 0 |
| Euler_pre_remap | 0 |
| closed_form_successor | 6.66133815e-16 |
| surface | 1.66533454e-16 |
| Euler_norm_abs | 7.43346566e-16 |
| Euler_norm_scaled | 4.59982604e-16 |
| perpendicular_abs | 3.62123526e-17 |
| perpendicular_scaled | 2.24023642e-17 |
| phase_increment_vs_azimuth | 3.54750951e-16 |
| phase_lift_vs_azimuth | 1.39659254e-14 |
| phase_lift_vs_fsum | 1.0658141e-14 |
| stored_angle_increment | 0 |
| stored_segment_margin | 0 |
| stored_angle_denominator | 0 |
| distance_to_circle | 0 |
| meridional_coordinate | 0 |

Every clip factor was one; clipped records: 0. Maximum raw torque was 0.211708407752, below the strict predeclared clipping bound. The minimum horizontal-segment lower bound was 1.16426885021, the minimum angular denominator 1.39022125802. All fresh remaps were finite/off-axis and all post-remap heights were nonnegative.

Schedules were checked from j, n, block and f, including reset points at RETURN j=800 and 1600. CONTINUE always supplied f=n. All state/predecessor/successor linkage and inherited start bytes matched. Distances, meridional angles, phase increments and lifts were checked against saved states. The final future conventions were never simulated beyond the authorized horizons.

## Jacobian, scalar and observer checks

| Jacobian identity | Maximum residual |
|---|---:|
| closed_vs_trigonometric | 4.4408921e-16 |
| radial_null | 5.30859159e-16 |
| torque_homogeneity | 4.4408921e-16 |
| phase_chain_rule | 5.55111512e-16 |

The tangent compares analytic derivatives of the same smooth map along 800 saved A0p RETURN steps. It uses no fresh finite-difference input. The paired ±eta central differences use only the six authorized disturbance branches. The largest central-minus-tangent discrepancy is about 1.54e-10 in parameter-derivative units. This is not an accumulated-roundoff enclosure or a certified higher-derivative bound.

The two roots of the leading angular factor were isolated by 64 exact rational interval bisections each, using square-root coefficient brackets on a 10^50 grid. Stored endpoint polynomial intervals have opposite strict signs and stored slope intervals exclude zero. Phase-angle displays and K_800 are ordinary binary64 estimates. The exact meridional multiplier remains symbolic and nonzero. No exact finite-a block fixed point was numerically solved.

The fixed proper rotation was checked on 64 indexed observations, including all four boundaries. Co-rotated phase-difference residual is 3.33066907e-16; pair-distance residual is 4.4408921e-16; point-to-circle and reference-vertex distance residuals are at most 4.44e-16. Both face hands, original open boundaries and host arrays remain intact. No geometry feedback or transformed trajectory was introduced.

## Error interpretation

B_800(a) is approximately 2.13895878976e-11 rad; B_3200(a) is approximately 1.15050858390e-42 rad. These are estimates of retained exact analytic expressions for uninterrupted fading tails. Earlier RETURN boundaries cannot use B_800 as a bound on an actual forthcoming restarted pulse. Pairwise tails add. None encloses inherited checkpoint or accumulated binary64 error. A tiny tail is not a statement of many-digit state accuracy. Finite contraction is not exact erasure. The small-coupling block theorem does not classify global behavior at a=1/32.

## Source preservation and review

All 19 consumed local originals retained their bytes, sizes and SHA-256 identities. They include the accepted CA02 archive and selected members, CA01 analysis and actual geometry. The supplied packet hash is also unchanged. Input copies match their originals. No whole-repository census was performed.

HEAD before and after: 2ecc2ded685fd210bd3cda226eb9731156dc167e; branch: main. Index bytes unchanged: True. Normal status bytes unchanged: True. Tracked worktree name/status output is empty.

Task writes were confined to CA03. Existing unrelated untracked research was retained. No Git publication action occurred. These preservation statements combine the explicit consumed-source checks, unchanged tracked/index records and the scoped task operations; they are not a byte census of every unrelated file.

Environment: 3.11.15 | packaged by Anaconda, Inc. | (main, Mar 11 2026, 17:12:15) [MSC v.1942 64 bit (AMD64)]; NumPy 2.4.4; Matplotlib 3.10.9. CMD/torment was used throughout, with Python bytecode disabled and plotting/TMP caches kept inside CA03. No installation occurred.

All three figures were visually inspected. One rendering-script parse error was repaired before the first successful render, and figure 2 received a layout-only label adjustment. These did not repeat the numerical stage; the actual attempt history is retained.

Start review with READ_ME_FIRST.md, then CA03_RETURNING_DRIVE_ANALYSIS.md, EVIDENCE_GUIDE.md and the tables. Inspect saved evidence instead of relaunching the stage. MANIFEST.json covers payload identities; REVIEW_ZIP_RECEIPT.json beside the archive supplies the ZIP hash and verification count without circular self-hashing.
