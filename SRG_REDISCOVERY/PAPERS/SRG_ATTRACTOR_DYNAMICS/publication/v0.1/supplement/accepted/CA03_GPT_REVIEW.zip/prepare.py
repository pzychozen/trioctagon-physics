"""Verified read-only input access and copies; no model execution."""
from pathlib import Path
import ast, hashlib, json, subprocess, sys, zipfile
import numpy as np
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path(__file__).resolve().parent;REPO=BASE.parents[2]
CA02=BASE.parent/'CA02_endpoint_retention_v0.1';CA01=BASE.parent/'CA01_source_and_measurement_v0.1'
PACKET=Path(r'C:\Users\Notandi\Downloads\SRG_CA03_CODEX_START_PACKET.zip')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(path,b):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==b,f'Existing output differs: {path}'
    else:path.write_bytes(b)
def jsave(name,obj):save(BASE/name,(json.dumps(obj,indent=2)+'\n').encode())
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
with zipfile.ZipFile(PACKET) as zf:
    manifest=json.loads(zf.read('MANIFEST.json'))
    for row in manifest['files']:
        b=zf.read(row['path']);assert len(b)==row['size_bytes'] and sha(b)==row['sha256']
    assert zf.testzip() is None
    for name in zf.namelist():
        dest=(BASE/'received'/name).resolve();assert dest.is_relative_to(BASE/'received');save(dest,zf.read(name))
index=json.loads((BASE/'received/CHECKPOINT_INDEX.json').read_text())
archive=CA02/'CA02_GPT_REVIEW.zip'
assert sha(archive.read_bytes())==index['source_archive_sha256']
assert archive.read_bytes()==(BASE/'received/reference/CA02_GPT_REVIEW.zip').read_bytes()
sources=[dict(path=str(archive),size_bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),copy=None)]
names=['model.py','CA02_PLAN.md','CA02_ENDPOINT_RETENTION_ANALYSIS.md','RUN_RESULTS.json','MANIFEST.json',
       'evidence/SOURCES_BEFORE.json','evidence/MODEL_EXTRACTION.json','inputs/CA01/RESULTS.json']
names += [r['archive_member'] for r in index['checkpoints']]
with zipfile.ZipFile(archive) as zf:
    m=json.loads(zf.read('MANIFEST.json'))
    for row in m['files']:
        b=zf.read(row['path']);assert sha(b)==row['sha256'] and len(b)==row['size_bytes']
    assert zf.testzip() is None
    for name in names:
        b=(CA02/name).read_bytes();assert b==zf.read(name)
        copy='inputs/CA02/'+name;save(BASE/copy,b)
        sources.append(dict(path=str(CA02/name),size_bytes=len(b),sha256=sha(b),copy=copy))
for local,received in [('CA01_ANALYSIS.md','CA01_ANALYSIS.md'),('evidence/geometry_reference.npz','CA01_geometry_reference.npz')]:
    b=(CA01/local).read_bytes();assert b==(BASE/'received/reference'/received).read_bytes()
    sources.append(dict(path=str(CA01/local),size_bytes=len(b),sha256=sha(b),copy='received/reference/'+received))
assert (CA02/'CA02_ENDPOINT_RETENTION_ANALYSIS.md').read_bytes()==(BASE/'received/reference/CA02_ENDPOINT_RETENTION_ANALYSIS.md').read_bytes()
assert sha((BASE/'received/reference/CA02_GPT_SCIENTIFIC_REVIEW.md').read_bytes())=='786c36e45558be9a56970ce65303f7ab86abec1c7df482604f00696e0343ef8a'
jsave('evidence/SOURCES_BEFORE.json',sources)
for name,args in [('status_before.txt',('status','--porcelain=v1','--untracked-files=normal')),
                  ('index_before.txt',('diff','--cached','--name-status'))]:save(BASE/'evidence'/name,git(*args))
jsave('evidence/START.json',dict(HEAD=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),
    python=sys.executable,version=sys.version,packet_sha256=sha(PACKET.read_bytes()),archive_verified_payloads=len(m['files'])))
checks=[]
for row in index['checkpoints']:
    p=BASE/'inputs/CA02'/row['archive_member'];assert p.stat().st_size==row['member_bytes'] and sha(p.read_bytes())==row['member_sha256']
    with np.load(p,allow_pickle=False) as d:
        state=d[row['state_key']];phase=d[row['phase_key']]
        assert list(state.shape)==row['state_shape'] and str(state.dtype)==row['state_dtype']
        sb=state[row['state_index']].copy();ph=float(phase[row['phase_index']]);assert np.isfinite(sb).all()
        checks.append(dict(case_id=row['case_id'],state=sb.tolist(),phase_lift=ph,state_row_bytes_sha256=sha(sb.tobytes()),
            phase_row_bytes_sha256=sha(phase[row['phase_index']:row['phase_index']+1].tobytes()),member_sha256=sha(p.read_bytes()),
            horizontal_radius=float(np.hypot(sb[0],sb[1])),norm=float(np.linalg.norm(sb))))
jsave('evidence/CHECKPOINTS_VERIFIED.json',checks)
model=(BASE/'inputs/CA02/model.py').read_text(encoding='utf-8')
tree=ast.parse(model)
assert [n.name for n in tree.body if isinstance(n,ast.FunctionDef)]==['H','finite','P','step']
print('PURE MODEL (TEXT ONLY)\n'+model)
print('\nEXPERIMENT SPEC\n'+(BASE/'received/CA03_EXPERIMENT_SPEC.json').read_text())
print('\nCA02 ACCEPTANCE REVIEW\n'+(BASE/'received/reference/CA02_GPT_SCIENTIFIC_REVIEW.md').read_text(encoding='utf-8'))
print('\nCHECKPOINT IDENTITIES\n'+json.dumps(checks,indent=2))
with np.load(BASE/'received/reference/CA01_geometry_reference.npz',allow_pickle=False) as d:
    print('\nGEOMETRY ARRAYS')
    for key in d.files:print(key,d[key].shape,str(d[key].dtype),d[key].tolist())
print('\nCA01 PASSIVE DEFINITIONS')
lines=(BASE/'received/reference/CA01_ANALYSIS.md').read_text(encoding='utf-8').splitlines()
for i,line in enumerate(lines):
    if '## 5.' in line:print('\n'.join(lines[i:i+75]))
