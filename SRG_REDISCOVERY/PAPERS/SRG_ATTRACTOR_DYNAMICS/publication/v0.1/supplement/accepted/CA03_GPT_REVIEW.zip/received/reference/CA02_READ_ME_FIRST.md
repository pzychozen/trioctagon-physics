# CA02 — What survives in the final angle?

**Yes: the drive can leave a lasting angular trace of both initial size and initial tilt, even though remapping alone would erase those differences.** The torque acts first. It can turn a size or tilt difference into a change of azimuth; the following remap preserves that azimuth. The two kinds of initial change were studied separately.

With no drive, the answer is exact: positive size is lost at the first remap, tilt differences contract away, and the original azimuth determines the endpoint. Many starts therefore share one endpoint.

With a small drive, we derived the endpoint's first-order response, including justification for differentiating its infinite angular sum. Different response coefficients prove that the specified size and tilt variants have different endpoints for sufficiently small nonzero coupling. This is an endpoint result, not just an observation that their first steps differ.

There are exceptions. Along the `(1,1,1)` direction, the first torque is zero. Positive rescalings become identical after the first remap and have exactly the same future, even with a drive. Also, a zero first angular increment alone does not establish erasure: the zero-tilt diagnostic starts that way and still acquires a final angular shift.

The one authorized numerical stage completed **16 trajectories × 800 updates**, with no extra probes or reruns. At diagnostic coupling +1/32, all starting azimuths below are zero:

| Initial state comparison | Final-angle estimate at update 800, radians |
|---|---:|
| Reference | 0.034913239 |
| Half initial size, same direction | 0.033801059 |
| 1.5 times initial size, same direction | 0.036032628 |
| Zero tilt, same norm | 0.033301884 |
| Tilt pi/4, same norm | 0.042901848 |

The remaining exact-trajectory angular tail is bounded by the expression in the analysis, approximately **2.14 × 10⁻¹¹ radians per trajectory**. That is much smaller than these differences. It does not bound accumulated floating-point error, so the finite-coupling separations remain numerical evidence rather than interval-certified results. Halving the coupling reduced central-difference derivative discrepancies by roughly four, consistent with the derived second-order truncation behavior.

The endpoint has one angular coordinate. Dependence on several initial coordinates does not mean they can all be recovered independently. Near zero drive the endpoint map has rank one and two-dimensional local level sets. Global injectivity or a complete classification at arbitrary coupling remains unresolved.

Clipping and the advancing clock were preserved. Clipping remained inactive, as proved beforehand. All 212 inherited fixture/transition checks matched CA01 exactly. Independent checks of saved successors, torque identities, remap geometry and angular lifts passed. CA01 and consumed source identities were preserved; the preservation receipt records actual Git state. No kernel or unrelated research was edited, and no Git publication action occurred.

These are results about CA01's accepted completion of Figure 4's printed recurrence. The diagnostic parameters are not recovered historical inputs. The circle is a set of possible endpoints, not a persistent orbit or physical container. Our geometric framework supplies no force or confinement; no new geometry overlay was needed.

Read **CA02_ENDPOINT_RETENTION_ANALYSIS.md** for proofs and error distinctions, **VERIFICATION.md** for checks, and the two PNGs in **figures/** for the comparisons. The CSV/JSON tables and **raw/** hold all numerical evidence. **SOURCE_AND_CLAIM_MAP.md**, **CA02_PLAN.md**, **COMMANDS.md**, the input copies and manifest provide provenance. Review the saved evidence without launching another numerical stage; `supervise.py` refuses repetition. The package is ready for local scientific review, not publication approval.
