"""Read saved evidence, summarize full-window readouts and render three static figures."""
from pathlib import Path
import json, os, hashlib
BASE=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(BASE/'cache/MPLCONFIGDIR')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=json.loads((BASE/'COMPARISON_RESULTS.json').read_text());SC=json.loads((BASE/'SCALAR_ANALYSIS.json').read_text())
RUN=json.loads((BASE/'RUN_RESULTS.json').read_text())
D={}
for row in RUN['branches']:
    with np.load(BASE/row['raw'],allow_pickle=False) as f:D[row['id']]={k:f[k].copy() for k in ['states','phase_lift','meridional_theta','distance_to_circle']}
def circ(x):return np.arctan2(np.sin(x),np.cos(x))
hist=['Bhalf','Bthreehalf','Czero','Cquarter']
details=[]
for arm in ['CONTINUE','RETURN']:
    ref=D['A0p_'+arm]
    for case in hist:
        d=D[case+'_'+arm];lift=d['phase_lift']-ref['phase_lift'];diff=circ(lift)
        wraps=np.rint((lift-diff)/(2*np.pi)).astype(int)
        ratio=np.abs(diff/diff[0])
        details.append(dict(case=case,arm=arm,boundary_ratios=[float(ratio[j]) for j in [0,800,1600,2400]],
            sign_reversal_any_saved_state=bool(np.any(diff*diff[0]<0)),
            wrap_integer_changes=int(np.count_nonzero(np.diff(wraps))),
            minimum_magnitude_ratio=float(ratio.min()),maximum_magnitude_ratio=float(ratio.max()),
            max_change_from_checkpoint_difference=float(np.max(np.abs(diff-diff[0]))),
            max_meridional_difference=float(np.max(np.abs(d['meridional_theta']-ref['meridional_theta']))),
            maximum_samplewise_increase_in_magnitude=float(np.max(np.diff(np.abs(diff))))))
extra=dict(history_full_window=details,
    max_CONTINUE_absolute_phase_displacement=float(max(abs(row['phase_displacement']) for row in R['branches'] if row['id'].endswith('_CONTINUE'))),
    max_RETURN_circle_distance=float(max(row['max_circle_distance'] for row in R['branches'] if row['id'].endswith('_RETURN'))),
    max_RETURN_final_circle_distance=float(max(row['final_circle_distance'] for row in R['branches'] if row['id'].endswith('_RETURN'))),
    perturbation_initial_circle_distance={k:float(D[k]['distance_to_circle'][0]) for k in ['SIZE+','SIZE-','TILT+','TILT-','PHASE+','PHASE-']})
(BASE/'READOUT_DETAILS.json').write_text(json.dumps(extra,indent=2)+'\n')
FIG=BASE/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,
    'axes.titleweight':'bold','savefig.facecolor':'white'})
colors={'Bhalf':'#2166ac','Bthreehalf':'#b85c00','Czero':'#168078','Cquarter':'#9046a1'}
labels={'Bhalf':'Earlier half-size','Bthreehalf':'Earlier 1.5× size','Czero':'Earlier zero tilt','Cquarter':'Earlier π/4 tilt'}
n=800+np.arange(2401);ix=np.array([0,800,1600,2400]);ticks=[800,1600,2400,3200]
fig,axs=plt.subplots(2,2,figsize=(13,8.7),layout='constrained')
for ax,group,title in [(axs[0,0],hist[:2],'A. Earlier size traces'),(axs[0,1],hist[2:],'B. Earlier tilt traces')]:
    for case in group:
        for arm,ls in [('CONTINUE','--'),('RETURN','-')]:
            delta=circ(D[case+'_'+arm]['phase_lift']-D['A0p_'+arm]['phase_lift'])
            ax.plot(n,1000*delta,color=colors[case],ls=ls,lw=1.6,label=labels[case] if arm=='RETURN' else None)
            if arm=='RETURN':ax.scatter(n[ix],1000*delta[ix],color=colors[case],s=24,zorder=4)
    ax.axhline(0,color='#888888',lw=.7)
    ax.set(title=title,ylabel='Difference from A0p (milliradians)');ax.legend(fontsize=9)
ax=axs[1,0]
for case in hist:
    delta=circ(D[case+'_RETURN']['phase_lift']-D['A0p_RETURN']['phase_lift'])
    rat=np.abs(delta/delta[0]);ax.plot(n,rat,color=colors[case],lw=1.4)
    ax.scatter(n[ix],rat[ix],s=20,color=colors[case])
ax.axhline(1,ls='--',color='#555555',lw=1.2,label='CONTINUE ≈ 1')
ax.text(.97,.08,'Four RETURN curves nearly overlap.\nFinal retained fraction: 0.6318–0.6321.',transform=ax.transAxes,ha='right',fontsize=10)
ax.set(title='C. Shrinkage relative to each checkpoint trace',ylabel='|Current difference| / |Checkpoint difference|');ax.legend(loc='lower left',fontsize=9)
ax=axs[1,1]
control_colors=['#2166ac','#b85c00','#168078','#9046a1']
for k,color in enumerate(control_colors):
    for arm,ls in [('CONTINUE','--'),('RETURN','-')]:
        d=D[f'A{k}p_{arm}'];shift=d['phase_lift']-d['phase_lift'][0]
        ax.plot(n,shift,color=color,ls=ls,lw=1.5,label=f'A{k}p' if arm=='RETURN' else None)
        if arm=='RETURN':ax.scatter(n[ix],shift[ix],s=20,color=color)
ax.set(title='D. Cardinal controls turn by different amounts',ylabel='Phase displacement since checkpoint (rad)');ax.legend(ncol=2,fontsize=9)
for ax in axs.flat:
    ax.set(xticks=ticks,xlabel='Absolute update n')
    for at in [1600,2400]:ax.axvline(at,color='#bbbbbb',ls=':',lw=.8,zorder=0)
fig.suptitle('CA03 · Returning pulses contract the earlier traces; they remain distinct',fontsize=17,fontweight='bold')
fig.supxlabel('Solid: RETURN (three new pulses). Dashed: CONTINUE (clock keeps advancing). Dots: inherited checkpoint and block ends.\n'
    'Curves connect discrete saved samples. Net contraction over this finite window is not exact erasure or an indefinite-time claim.',fontsize=10)
fig.savefig(FIG/'01_trace_survival.png',dpi=170);plt.close(fig)

rho=RUN['circle']['rho_star'];zz=RUN['circle']['z_star'];K=SC['K_N_estimate'];a=1/32
phi=np.linspace(0,2*np.pi,361)
G=zz**2/rho*np.cos(phi)+zz*np.sin(phi)*np.cos(phi)-rho*np.sin(phi)
Gp=-zz**2/rho*np.sin(phi)+zz*np.cos(2*phi)-rho*np.cos(phi)
fig,axs=plt.subplots(2,1,figsize=(12.6,8.3),layout='constrained')
ax=axs[0]
ax.plot(phi,a*K*G,color='#2166ac',lw=2,label='Leading prediction: a K₈₀₀ G(φ)')
responses=R['block_responses']
ax.scatter([r['input_phase_mod'] for r in responses],[r['block_phase_change'] for r in responses],
    s=34,facecolors='none',edgecolors='#b85c00',linewidths=1.3,label='24 saved RETURN blocks (full states)',zorder=4)
ax.axhline(0,color='#777777',lw=.8)
ax.set(ylabel='Phase change in one block (rad)',title='A. Response depends on the incoming phase')
ax.legend(loc='upper left',fontsize=10)
for root in SC['roots']:
    px=root['phase_estimate'];ax.axvline(px,color='#999999',ls=':',lw=1)
    text='Attracting branch as α → 0+' if root['quadrant']=='I' else 'Saddle branch as α → 0+'
    xytext=(1.9,.13) if root['quadrant']=='I' else (4.1,-.15)
    ax.annotate(text+f'\nleading φ ≈ {px:.6f}',xy=(px,0),xytext=xytext,ha='center',fontsize=9,
                arrowprops=dict(arrowstyle='->',color='#555555'))
ax=axs[1];gain=1+a*K*Gp
ax.plot(phi,gain,color='#2166ac',lw=2)
ax.axhline(1,color='#555555',ls='--',lw=1)
ax.fill_between(phi,gain,1,where=gain<1,color='#2166ac',alpha=.14,label='Leading contraction')
ax.fill_between(phi,gain,1,where=gain>1,color='#b85c00',alpha=.14,label='Leading expansion')
ax.set(ylabel='Leading angular gain 1 + a K₈₀₀ G′(φ)',title='B. A local angular difference can shrink or grow, depending on phase')
ax.legend(fontsize=10)
for ax in axs:
    ax.set(xticks=np.arange(5)*np.pi/2,xticklabels=['0','π/2','π','3π/2','2π'],xlabel='Incoming phase φ (rad)',xlim=(0,2*np.pi))
fig.suptitle('CA03 · Block response and small-coupling phase selection',fontsize=17,fontweight='bold')
fig.supxlabel('Curves are derived scalar formulas, not additional trajectories. a = 1/32; K₈₀₀ ≈ 6.586496869.\n'
    'Leading roots continue to full block fixed points for sufficiently small coupling. Their locations/stability at a are not certified.\n'
    'Finite residual tilt is carried in every observed block; no state is projected onto the fixed circle.',fontsize=10)
fig.savefig(FIG/'02_block_response.png',dpi=170);plt.close(fig)

fig,axs=plt.subplots(1,3,figsize=(13.2,5.8),layout='constrained')
for col,kind in enumerate(['SIZE','TILT','PHASE']):
    ax=axs[col]
    for suffix,color,offset in [('+','#2166ac',-.05),('-','#b85c00',.05)]:
        data=[next(r for r in R['disturbances'] if r['id']==kind+suffix and r['local_state_index']==j) for j in [0,1,800]]
        ax.scatter(np.arange(3)+offset,[r['phase_difference']*1e6 for r in data],s=55,color=color,label=suffix+' disturbance',zorder=3)
        ax.scatter(2+offset,data[-1]['linear_tangent_prediction']*1e6,s=100,marker='D',facecolors='none',edgecolors=color,linewidths=1.3,zorder=2)
        val=data[-1]['phase_difference']*1e6
        ax.annotate(f'{val:+.6g}',(2+offset,val),xytext=(-5,14 if suffix=='+' else -19),textcoords='offset points',ha='center',fontsize=10)
    ax.axhline(0,color='#999999',lw=.8)
    ax.set(xticks=[0,1,2],xticklabels=['Initial','After 1','After 800'],ylabel='Phase difference from reference (µrad)',
        title=kind+(' (±10⁻⁴ fractional size)' if kind=='SIZE' else ' (±10⁻⁴ rad)'))
    ax.margins(x=.18,y=.35)
    if col==0:ax.legend(loc='upper left',fontsize=9)
fig.suptitle('CA03 · New size, tilt and phase disturbances have different angular effects',fontsize=16,fontweight='bold')
fig.supxlabel('One-time disturbances at the exact A0p checkpoint; all receive the same first RETURN block.\n'
    'Filled markers: saved comparisons. Open diamonds: analytic tangent prediction along the saved reference.\n'
    'Three selected sample stages; no continuous motion is implied. Separate vertical scales; all readouts are angular differences.',fontsize=10)
fig.savefig(FIG/'03_later_disturbances.png',dpi=170);plt.close(fig)
record=dict(matplotlib=matplotlib.__version__,figures=[dict(path='figures/'+p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(FIG.glob('*.png'))],
    fresh_rollout_calls=0,geometry_overlay='Omitted: no additional predictive correspondence; actual arrays used in the passive frame test.')
(BASE/'FIGURE_RECORD.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(extra,indent=2))
