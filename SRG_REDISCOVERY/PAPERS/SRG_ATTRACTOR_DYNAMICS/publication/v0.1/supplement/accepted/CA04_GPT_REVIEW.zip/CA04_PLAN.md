# CA04 sealed plan — before any fresh full-block evaluation

The question is existence and local attraction for the complete exact-real 800-update RETURN map at alpha=1/32, dt=1/10, f=0,...,799. Both state coordinates evolve. Only the forcing index restarts. The source is the verified accepted CA03 archive, not a new historical reconstruction.

## Source and environment

Use CMD, call conda activate torment, python -B. No installations, accepted-source changes, kernel calls, original runner imports, Git writes or publication. The installed environment has NumPy, SymPy and mpmath but no flint or gmpy2. The proof will use a task-specific integer directed interval implementation, not ordinary mpmath. Preserve reference_model.py byte-for-byte. Preflight exactly the 12 indexed transitions without chaining outputs.

## Mathematical strategy

Use c=cos(theta), v=tan(phi/2) and chi(c,v) as in the work order. Derive an equivalent radial/tangential expression, which retains both coordinates and writes the angular change as an identity plus a small increment. This reduces interval dependency when the forcing fades without omitting any step. See PRE_RUN_ANALYSIS.md for the algebra, derivative chain, elementary-function error bounds and contraction proof.

On K, |H|<=9/2, norm(s)<=3/2, rho>=1/2 imply norm(q)<=81/256<4/5-1/100000 and rho-norm(u-s)>=1199/2560>0. Check the local chart denominators in every interval step. Off-K optional inputs must pass a separate exact interval clipping and axis test before their actual first Cartesian update.

Locate a two-coordinate candidate using binary64 Newton with simultaneous analytic forward differentiation, seeded at c* and the midpoint of the supplied leading v bracket. At most 12 Newton evaluations, plus at most 12 reserved candidate/reference refinements: total 19,200 point steps. Stop Newton at residual max<=2e-14, or failure/ceiling. No finite-difference trajectories, parameter changes, saddle search or extra pulses.

Candidate estimates do not prove anything. Serialize the chosen floating center as exact dyadic fractions. At 160 binary fractional bits, rigorously evaluate its residual and the signed full derivative over a rectangle. Only then take absolute bounds M. Use radii (10^-6,10^-5) first; permitted fallback radii are (10^-7,10^-6), (10^-5,10^-4), (10^-4,10^-3), with 224-bit refinement if needed. These finite choices change enclosures, not dynamics. Where needed subdivide a rectangle into at most 4 c strips and 16 v strips; cover the exact full rectangle without gaps. Evaluate each independently and take the componentwise hull of the full derivatives. No hidden central trajectory. Each additional traversal is charged.

Required inequalities are e+M r<r and q=max_i (Mr)_i/r_i<1 in exact rational arithmetic. They certify invariance, existence, uniqueness in the rectangle, and convergence for T in the weighted max norm. Export exact e, signed derivative bounds, M, margins, q, chart/Cartesian/phase bounds and a deterministic 800-step recipe.

Only after primary success attempt a larger concentric B with radii (1/1000,1/10). If the full-domain enclosure fails, try (1/1000,2/25), (1/1000,7/100) in that order, with the same allowed subdivisions. A certified B containing X has the same unique root. Entry requires actual block images of all five exact stored Cartesian dyadic starts, never a fit to K. First perform the exact Cartesian F_0, then intrinsic f=1,...,799. If B is unavailable, use up to four complete blocks per input into X; stop each chain on success. Do not begin entry propagation until a certified destination exists. Failure is an unresolved inclusion, not an outside-basin result.

## Arithmetic trust and independent verification

Represent intervals by integer endpoints on a fixed 2^-p grid; Python exact integers implement outward +,-,*,/ and square root through integer square root. Rational constants enter through floor/ceiling. Exp/sin/cos use small-argument Taylor polynomials with explicit remainders, then seven exact identities with outward rounding. Recompute all 800 H values, including late nonzero terms. See the initial analysis for proofs. Derivatives use product/quotient/square-root rules with signed intervals.

The fixed-certificate verifier may share the small reviewed arithmetic kernel but must regenerate all inequalities from the declared center, radii and exact inputs, with no root search or new box choices. Independently check the chart algebra and the analytic derivative rules using symbolic identities; test the arithmetic against exact Fraction inequalities and integer square-root endpoints. Those tests supplement the written arithmetic proof. Serialization uses integer endpoint pairs and exact rational strings, never display decimals as proof inputs.

## Accounting and stop conditions

Persistent ledger across every scientific subprocess and relaunch: point<=19,200, construction set<=76,800, replay set<=76,800, preflight=12. State plus derivative traversal counts once, derivative-step work separately. Charge actual partial traversals and reserve remaining traversal allowance durably before launch so a crash cannot erase usage. Scalar H preparation and algebra checks are separate counts. Fresh unstructured rollouts, inherited prefixes and native kernel updates remain zero.

Candidate plus construction cumulative execution wall<=1800 seconds; fixed replay<=900 seconds. New results excluding unchanged inputs<=250,000,000 bytes. Ledger tracks failures, code hashes, refinements and elapsed time; code repairs require a new recorded seal and use only remaining allowance. Stop affected work on mismatched sources, singular/unproved domains, arithmetic failure or exhausted budget. No proof can rest on ordinary residuals, precision agreement or apparent pulse convergence.

Deliver READ_ME_FIRST<=700 words, analysis, exact certificate or precise obligations, standalone verifier, accounting/preservation, up to two explanatory figures and CA04_GPT_REVIEW.zip. Record one primary disposition from the work order and separate entry dispositions. No global basin, finite-time erasure, exact multiplier zero, minimal-period, branch-connection or physical-geometry claims.
