"""Scalar consequences of saved certificates only; no recurrence evaluations."""
from execution import read,write
from interval_core import I,F,Q,phase
from validated_map import chi
def interval(p):return I.raw(*map(int,p))
def bounds(a):return [float(a.lower()),float(a.upper())]
c=read('CERTIFICATE.json');center=list(map(F,c['center']))
M=[list(map(F,r)) for r in c['primary']['M']];e=list(map(F,c['primary']['e']))
det=(1-M[0][0])*(1-M[1][1])-M[0][1]*M[1][0];assert det>0
d=[((1-M[1][1])*e[0]+M[0][1]*e[1])/det,(M[1][0]*e[0]+(1-M[0][0])*e[1])/det]
assert all(0<=x<F(r) for x,r in zip(d,c['primary']['radii']))
root=[I.box(center[j]-d[j],center[j]+d[j]) for j in range(2)]
phase_root=phase(root[1]);cart=chi(*root)
summary={'center':c['center'],'root_error_bound':list(map(str,d)),'root_chart':[x.dump() for x in root],'root_phase':phase_root.dump(),'root_cartesian':[x.dump() for x in cart],'display_root_error':list(map(float,d)),'display_root_phase':bounds(phase_root),'display_root_cartesian':[bounds(x) for x in cart],'regions':{},'entry':[],'derivation':'At the fixed point, distance<=e+M distance. Since the certified weighted norm of M is <1, its Neumann inverse is nonnegative and distance<=(I-M)^-1 e. This is a scalar consequence, no new traversal.'}
for name in ['primary','larger_region']:
    b=c[name];D=[list(map(F,r)) for r in b['M']]
    summary['regions'][name]={'q':float(F(b['q'])),'radii':list(map(float,map(F,b['radii']))),'M':[[float(t) for t in row] for row in D],'e':list(map(float,map(F,b['e']))),'margins':list(map(float,map(F,b['inward_margins']))),'phase_bounds':bounds(interval(b['phase_enclosure'])),'domain_minima':{k:float(F(v)) for k,v in b['subboxes'][0]['domain_minima'].items()}}
for en in c['entry']:
    x=list(map(interval,en['blocks'][-1]))
    summary['entry'].append({'case':en['case'],'display_final_c':bounds(x[0]),'display_final_v':bounds(x[1]),'display_final_phase':bounds(phase(x[1])),'final_interval_widths':list(map(str,[t.upper()-t.lower() for t in x])),'status':en['status'],'blocks':len(en['blocks'])})
write('CERTIFICATE_SCALAR_CONSEQUENCES.json',summary)
print(__import__('json').dumps({k:v for k,v in summary.items() if k not in ['root_chart','root_phase','root_cartesian','root_error_bound']},indent=2))
print('Ledger',read('EXECUTION_LEDGER.json')['seconds'])
