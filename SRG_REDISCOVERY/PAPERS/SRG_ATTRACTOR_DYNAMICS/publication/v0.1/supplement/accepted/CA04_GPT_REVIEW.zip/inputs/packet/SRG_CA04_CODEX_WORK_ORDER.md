# CA04 — Certify the returning response at the tested coupling

**Date:** 21 October 2026  
**Scientific lead:** GPT · **Analysis/implementation:** Codex · **Author:** Hilmir Frímann Halldórsson  
**Status:** New local research. Accepted CA01–CA03 are inputs, not write targets.  
**Authorization:** Read-only source inspection, mathematical analysis, bounded candidate solving, and rigorous enclosure/certificate computations specified below. No kernel changes, new physical model, manuscript changes, Git writes, or publication.

## 1. The question in ordinary language

CA03 observed shrinking angular differences through three returning pulses at coupling **1/32**. Its theorem establishes a locally attracting repeating response only for **sufficiently small** positive coupling, without proving that 1/32 is in that range.

> **At exactly 1/32, does the complete returning-drive rule have a repeating response that attracts a definite neighborhood? Can we establish this with explicit error bounds rather than extrapolating three pulses?**

Primary goal: certify one locally attracting fixed point of the **full 800-update return map**, together with a nonzero-size attracting neighborhood. A fixed point of this map repeats at pulse boundaries; the state may move during the pulse.

Secondary goal, only after the primary result is secured: determine whether the five saved final RETURN states underlying the earlier size/tilt comparisons can be connected to that attracting neighborhood under a precisely declared future. Scope the answer to those stored checkpoints, not unknown exact historical states.

Do not make more ordinary pulse plots and call that a proof. Do not change the coupling, block length, roll, clipping, Euler step or active remap to obtain a desired answer. Finding a valid certificate is a goal, not a result assumed in advance.

Hilmir's Tri-Octagon/crystal/central-ball/toroidal geometry remains an analytical instrument. It supplies no force, container, imposed orbit, normalization or feedback. No new geometric overlay is needed for this proof task.

## 2. Workspace and accepted inputs

Authoritative checkout:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

Create a new workspace:

```text
SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA04_finite_coupling_certificate_v0.1\
```

Do not reuse a completed output directory. Read:

- **S1:** CA03 `CA03_RETURNING_DRIVE_ANALYSIS.md`, especially §§1–4, 5–6 and 9. These specify the full block, its small-coupling theorem, derivative formulas, domain bounds and unresolved finite-coupling question.
- **S2:** `CA03_GPT_SCIENTIFIC_REVIEW.md`, especially §§3–4 and 8. Its bounded acceptance does not certify 1/32 or authorize publication.
- **S3:** CA03 `model.py`, `SCALAR_ANALYSIS.json`, `CA03_PLAN.md`, `VERIFICATION.json`, `MANIFEST.json`, and the selected saved records indexed in this packet.
- **S4:** CA02 analysis/review and CA01 analysis/review already included in the accepted CA03 archive, only as needed for inherited definitions. Do not relaunch their runners.
- **S5:** `CA04_INPUT_INDEX.json` in this packet. It identifies exact archive members, the five optional checkpoint rows, and passive preflight inputs.

Accepted CA03 archive:

```text
CA03_GPT_REVIEW.zip
Bytes: 8794368
SHA-256: bc18315ce76f64ca8dae5b3fafa4bec77ce0e1eceb06a566a087c01fadb044e4
```

The packet contains this unchanged archive and the accepted GPT review. Verify consumed identities against local inputs or use verified packet copies under CA04. A differently named experiment is not an acceptable substitute.

Use Windows CMD and the existing `torment` environment. Use `python -B`; keep caches, temporary data and logs inside CA04. Inspect modules before importing. The accepted pure `model.py` may be copied unchanged as a reference; do not import historical or accepted runner scripts with execution at module level. No dependency installation or environment mutation is authorized.

Record actual local HEAD and relevant index/status before and after, without treating an older recorded commit as current. Hash consumed originals, not the entire repository. Preserve CA01–CA03, SRG Origins, historical originals, SIM01/SIM02, central-crystal/Z/chirality work, both kernels and unrelated changes. Do not reset or revert concurrent work. No pull, checkout, stash, reset, staging, commit, push, release or external upload.

## 3. Freeze the mathematical problem

Set **a=1/32**, **N=800**, **dt=1/10**. Local forcing indices are f=0,...,799 in every repeated block. Carry the entire state between blocks; reset only this forcing index.

\[
C(x,y,z)=(z,x,y),\quad A(s)=s\times Cs=(y^2-xz,\ z^2-xy,\ x^2-yz),
\]
\[
H(t)=2e^{-t/2}\cos t+e^{-3t/10}\sin t+\frac32e^{-7t/10}+e^{-2t/5},
\]
\[
q_f=aH(f/10)A(s),\quad
\widehat q_f=q_f\min\left(1,\frac{4/5}{\|q_f\|+1/100000}\right),
\]
\[
u=s+\frac1{10}\widehat q_f,\qquad F_f(s)=P(u),\qquad
T=F_{799}\circ\cdots\circ F_0.
\]

For off-axis v, write rho=sqrt(v_x²+v_y²), L=||v||. The exact-real identity is

\[
P(v)=\left(\left(1+\frac{v_z}{2L}\right)\frac{v_x}{\rho},
\left(1+\frac{v_z}{2L}\right)\frac{v_y}{\rho},\frac{\rho}{2L}\right).
\]

**Separate three computational objects.**

1. The theorem target is this **exact-real recurrence** with the printed decimals interpreted as the fractions above, including t=f/10. It is not a theorem about bit-for-bit eventual repetition of a finite-state floating-point program.
2. The unchanged trigonometric binary64 `model.py` is the historical-reference evaluator. Preserve its source and operation order for ordinary consistency comparisons.
3. A new, explicitly labelled validated evaluator may use algebraically equivalent formulas and intrinsic coordinates to enclose the exact-real map. Prove that equivalence on its domain; it does not replace or edit the primary evaluator. Rigorous input/constants/function bounds are required.

The old stored binary64 trajectories remain numerical evidence. Do not retroactively certify their accumulated errors or silently equate their rounded forcing evaluations with exact-real constants.

After an exact remap, states lie on

\[
K=\{(x,y,z):(\rho-1)^2+z^2=1/4,\ z\geq0,\ \rho\geq1/2\}.
\]

Use both intrinsic coordinates. Do not set the meridional coordinate to theta_* at each boundary, replace T by its leading angular response, or solve only G(phi)=0. The small-coupling root near 0.245117619178 radians is a **candidate seed**, not a finite-a solution or bracket.

## 4. Mathematics and proof plan first

Before any fresh full-block evaluation, write `CA04_PLAN.md` and seal the initial analysis. State the exact target, chosen chart, arithmetic/backend assumptions, candidate seed, enclosure strategy, refinement rules, budgets, and criteria for each conclusion. Ordinary file inspection and scalar algebra may precede the seal.

### 4.1 Domain and clipping

Recheck inherited |H(t)|<=9/2, ||s||<=3/2 and rho>=1/2 on K. A useful exact bound to verify is

\[
\|q_f\|\leq\frac1{32}\frac92\left(\frac32\right)^2=\frac{81}{256}
<\frac45-\frac1{100000}.
\]

Thus clipping is identically inactive for the exact map on K, including the epsilon margin. Retain clipping in the reference evaluator. The smooth validated branch may simplify it only after this bound, and any required off-K entrance bound, have been proved.

The corresponding horizontal straight-segment bound on K is

\[
\rho-\|u-s\|\geq\frac12-\frac{81}{2560}=\frac{1199}{2560}>0.
\]

These are suggested CA04 deductions to verify, not newly certified results supplied by this order. Extra interval overestimation must not invalidate the chosen computational chart or be mistaken for a real clipping event. If a bounding box is unnecessarily wide, refine the enclosure within budget rather than changing the model.

### 4.2 Suggested exact chart for validation

The inherited (theta,phi) chart is valid. An optional way to reduce repeated inverse-trigonometric evaluations near the proposed attracting phase is

\[
c=\cos\theta,\qquad v=\tan(\phi/2),
\]
\[
\chi(c,v)=\left(
(1+c/2)\frac{1-v^2}{1+v^2},
(1+c/2)\frac{2v}{1+v^2},
\frac12\sqrt{1-c^2}\right).
\]

For u=chi(c,v)+(a/10)H_f A(chi(c,v)), the candidate equivalent intrinsic step is

\[
c^+=\frac{u_z}{\|u\|},\qquad
v^+=\frac{u_y}{\sqrt{u_x^2+u_y^2}+u_x}.
\]

Derive and check this identity and its derivatives before use. Require -1<c<1, nonzero norms and a strictly positive half-angle denominator throughout every relevant interval tube. The positive square root corresponds to K's upper half. Use a single declared angular chart or a rigorously justified chart transition; a branch jump cannot be hidden by an `atan2` convention.

This is a coordinate change of the **full** two-coordinate update, not a phase-only model. The phase readout is 2 atan(v) on the local chart. Do not import a crystal symmetry as a symmetry of the recurrence.

### 4.3 Locate one candidate; then certify it

Use the quadrant-I leading root from CA03's exact rational half-angle bracket, with c_*=(sqrt(3)-1)/2, as the seed. Solve the two-coordinate equation T(x)-x=0 at **a=1/32 only**. A bounded Newton or equivalent local solve is permitted. Derivatives should be analytic/automatic, not an uncounted collection of perturbed trajectories.

Candidate coordinates, Newton convergence and a small residual are **not certificates**. Record them as estimates until the existence/stability conditions below are verified. No coupling sweep, homotopy scan, saddle search, global root count, basin atlas or proof that this root is connected to the small-a branch is required. Do not claim any of those from a nearby phase value.

### 4.4 Preferred existence-and-attraction certificate

Let X=xhat+[-r_1,r_1]×[-r_2,r_2] be a closed chart rectangle, with explicit positive rational/dyadic radii, contained in a smooth domain of the full T. Enclose T(xhat)-xhat and DT(x) **for every x in X**, including all 800 intermediate steps.

Obtain certified componentwise bounds

\[
|T(\widehat x)-\widehat x|\leq e,\qquad
|DT(x)|\leq M\quad(x\in X),
\]

where M is a nonnegative upper-bound matrix. Verify, with rigorous arithmetic,

\[
\boxed{e+Mr<r}\quad\text{componentwise},\qquad
q=\max_i\frac{(Mr)_i}{r_i}<1.
\]

Give the short proof: the mean-value bound maps X into its interior, and the weighted max norm ||d||_r=max_i |d_i|/r_i makes T a contraction. This supplies existence, uniqueness **in X**, invariance and convergence from X. A certified containing box need not have many digits to be useful.

Report all margins, not just a PASS flag. Translate chart bounds back to phase and Cartesian state with justified interval maps. A bound q is a conservative contraction bound in the stated norm, not the observed 85.9% ratio or a universal memory-loss fraction.

An interval-Newton, Krawczyk, radii-polynomial or equivalent proof is allowed when better conditioned. State and check its hypotheses. **Convergence of a preconditioned root solver is not attraction under T.** If a solver map certifies a root, separately certify stability of the actual DT and a local attraction neighborhood. A claimed attracting box requires its own inclusion proof; eigenvalues at an approximate point alone do not establish basin membership.

A pointwise certified spectral-radius bound can establish local stability when the applicable smoothness hypotheses are proved, but it does not by itself certify a specified finite rectangle as invariant. Keep these outcomes separate.

### 4.5 What the theorem would mean

If the certificate closes, state it for exactly a=1/32 and the indefinitely repeated 800-sample schedule. It would establish a locally attracting periodically driven response, not a static state during every pulse, a circular orbit, minimal period 800, global attraction, exactly two finite-a roots, or exact finite-time erasure.

Use finite-prefix continuity of the within-block maps to explain what convergence at block boundaries implies at each corresponding phase of the repeating drive. If making an ambient three-coordinate attraction statement, justify entry into the intrinsic attracting domain after the actual remapping step; do not assume that an arbitrary off-K point is already on K.

The strong contracting direction can have a tiny nonzero multiplier. Do not infer an exact zero, loss of invertibility, or finite-time coalescence from numerical underflow or a determinant dominated by cancellation. A certified enclosure containing zero may still prove contraction while leaving invertibility unresolved.

## 5. Rigorous computation: what counts as a certificate

Use outward-enclosing interval/ball arithmetic with documented guarantees, or exact rational inequalities with proved elementary-function remainder bounds. Every nonlinear constant and operation in the proof must be enclosed: rational inputs, square roots, exp, sin/cos, any inverse-trig readouts, derivatives and accumulated compositions.

Check the installed environment first. An already installed, documented Arb/python-flint or comparable validated backend is acceptable after checking its version and relevant contracts. This order does not assume any package is installed. Ordinary high-precision `mpmath`, agreement between two precisions, a NumPy residual, or adding an arbitrary epsilon does not constitute a rigorous enclosure. A library named “interval” is not enough without the guarantees needed for the actual operations and conversions used.

If no suitable backend is available, a small reviewed rational/directed arithmetic implementation with analytic remainder bounds is permitted within scope. Do not create a general numerical library. If that cannot be completed within the budget, retain the written analysis and candidate evidence and identify the exact missing certification capability; do not quietly install software or label an ordinary numerical solve certified.

New external sources may justify verification methods only. Keep them separate from the private SRG sources and do not use them to replace any SRG equation. `SOURCE_ANCHORS.md` lists primary methodological references inspected during preparation; the suggested certificate above must also be explained self-containedly.

### Enclosure width and derivative propagation

A naive 800-step Cartesian interval box can become too wide because it discards correlations. Use the intrinsic chart, mean-value/centered forms, rigorous automatic differentiation, controlled subdivisions or another justified enclosure strategy as needed. Increasing precision alone does not remove dependency overestimation.

Propagate the signed derivative matrices before taking componentwise absolute bounds when justified; avoid unnecessarily multiplying only absolute matrices and discarding all cancellation. Every derivative enclosure must cover the relevant entire set of trajectories, not just a sampled central trajectory.

A finite head/tail decomposition is permitted only with a rigorous bound for every omitted update **and its needed derivative effect**. Late H values are small but not zero. The fading infinite-tail bound from CA02 does not replace the missing part of an indefinitely repeated block or establish its derivative stability.

All constants f/10 and printed decimal coefficients enter the exact-real proof as rationals/rigorous enclosures, not binary64 values silently promoted to exact decimal constants. Preserve exact serialized interval endpoints for verification; rounded display strings are not certificate inputs.

## 6. Optional bridge to five saved histories — a separate claim

The primary certificate must not depend on expanding this into a global basin study. Once it succeeds, use only these five accepted CA03 records:

```text
raw/A0p_RETURN.npz
raw/Bhalf_RETURN.npz
raw/Bthreehalf_RETURN.npz
raw/Czero_RETURN.npz
raw/Cquarter_RETURN.npz
```

Take **states[2400]**, the final saved state at absolute n=3200, from each. `CA04_INPUT_INDEX.json` gives member hashes, state-byte hashes, exact float hex/dyadic identities and existing phase lifts. No CA02/CA03 prefix is rerun.

Define the new future explicitly: from each saved state, restart the forcing at f=0 and continue RETURN indefinitely. This is **not** CA03's hypothetical final fading future used for its endpoint tail bounds. All five starts get the same next forcing phase.

For this secondary theorem, interpret each stored Cartesian component as its exact dyadic real value. That is a declared new initial-value problem. It does not certify how far the preceding binary64 calculation lay from an ideal exact-real history.

Stored checkpoints can be microscopically off K. Do not fit them to the circle or torus, round them, or simply reconstruct chi(theta,phi) and call it the same state. Begin with an exact validated Cartesian update, then use the intrinsic chart for the exact post-remap state and the remaining correctly indexed steps. A one-step advance is at forcing phase 1, not a new phase-0 block boundary.

Try either:

- a certified attracting region B, linked to the primary root, whose full-domain inclusion/derivative bounds contain the exact complete-block images of these starts; or
- a finite chain of rigorous block-image enclosures into the already certified region, with **at most four additional complete blocks per saved checkpoint**.

A larger region may be subdivided, but cover it without gaps and count every box propagation. Do not assume a segment between two certified points is certified. Stop a checkpoint chain once inclusion is proved; the contraction theorem supplies the indefinite future, not further simulation.

For each of the five states, report `certified entry`, `not established within this investigation`, or a rigorously demonstrated different outcome. Failure of an interval inclusion is not proof that the state lies outside the basin. Partial inclusion is useful; do not tune the model or extend the horizon to force all five successes.

A certificate from these exact stored starts is not a statement about all eight earlier cardinal/history controls, all possible disturbances, or the original unrecovered Figure 4 run. No forward-error reconstruction of the inherited 3200-update histories is authorized.

## 7. Bounded execution and counters

This is a proof-oriented calculation, not an additional long pulse simulation. Its repeated one-block evaluations are nevertheless real computations and must be counted.

| Activity | Ceiling |
|---|---:|
| Fresh point/candidate full-block equivalents, including Newton trials and rejected trials | 24 × 800 = **19,200** point state-step evaluations |
| Certificate construction and optional entry: validated set-step evaluations, including all refinements/subdivisions | 96 × 800 = **76,800** validated set-step evaluations |
| Independent certificate replay, with no search/refitting | 96 × 800 = **76,800** validated set-step evaluations |
| Passive saved-input preflight of the reference evaluator | **12** indexed saved transitions |
| Fresh unstructured long rollouts, prefix reruns, new parameter cases | **0** |

A partial traversal consumes its actual steps. An additional center traversal used by a mean-value enclosure is an additional traversal; charge it to the appropriate counter. Simultaneous state-and-derivative propagation in one traversal is counted once as a state traversal, with derivative work recorded separately. Extra finite-difference trials count as additional point evaluations; analytic differentiation is preferred. Caches may reuse rigorously established constants or already computed enclosures with identical domains, never unrecorded new computations.

The optional checkpoint entrance blocks use the **same** validation budget, not an extra allowance. High-precision candidate refinements, failed attempts, and reference comparisons on newly chosen starts count too. Scalar preparation of 800 validated H values and small exact matrix/sign checks are counted separately, not called trajectories.

Set cumulative wall-time limits of **1,800 seconds for candidate plus certificate construction**, and **900 seconds for certificate replay**, with a **250 MB new-result ceiling** excluding unchanged input copies. These are ceilings, not quotas. Keep a persistent ledger across subprocesses or manual relaunches. No reset of counters after errors, no hidden retries, no parameter or horizon extension. Implementation repairs may use remaining budget with an explicit attempt history; successful scientific evidence must match the final sealed code.

Before the numerical stage, inspect and verify the 12 indexed saved predecessor/successor cases (stored transition rows j=0,399,799,800,1599,2399 for A0p_RETURN and Cquarter_RETURN; use each row's actual forcing index f=j mod 800). This is a consistency preflight, not a rigor certificate. Do not chain its outputs. Use the accepted 1e-12 scale-aware consistency threshold only for this ordinary comparison, never as an arbitrary interval-proof tolerance.

Stop affected computations on source mismatch, unhandled axis/chart singularity, nonfinite results, unproved arithmetic assumptions or exhausted resources. A certificate inclusion that fails may be refined within the predeclared budget; it is not a reason to alter the recurrence. Continue valid written work and report exactly which proof obligation remains open.

## 8. Certificate and independent checking

Return enough data to verify the claimed theorem without rerunning candidate search or choosing new boxes. At minimum store:

- exact target constants, forcing schedule and real-versus-binary64 scope;
- chosen chart and domain/clip/nonsingularity inequalities;
- validated H_f table or an executable rigorous construction of it;
- rational/dyadic candidate center, box radii, derivative enclosure and residual enclosure;
- inward margins, norm weights and a rigorous q<1 bound, or all ingredients of the alternative proof;
- intermediate set/derivative enclosures or a deterministic bounded recipe to reproduce them;
- for optional checkpoint claims, input dyadics, next-clock convention, all entrance sets and the final inclusion;
- backend/version, precision settings, exact serialization, source hashes, counters and failed/refined attempts.

Provide a separate `verify_certificate.py` which regenerates the rigorous inequalities from these fixed inputs and definitions, rather than trusting Boolean fields from the solver. It must not search for a new root, change domains or invoke the original runners. Independently verify the chart equivalence and analytic derivative formulas; compare the unchanged binary64 evaluator only as a consistency check, not the source of rigorous bounds.

Fresh certificate evaluation is not a replay of a historical trajectory. State that plainly. If only ordinary numerical evidence is available, label the file as a candidate report rather than a mathematical certificate.

## 9. Deliverables and scientific decision

Return one `CA04_GPT_REVIEW.zip` containing:

1. `READ_ME_FIRST.md` (aim <=700 words): whether attraction at 1/32 was certified; what neighborhood was covered; whether the five stored starts were connected to it; what remains unknown.
2. `CA04_FINITE_COUPLING_ANALYSIS.md`: exact model, chart, proofs, explicit bounds and clear separation from inherited small-coupling results.
3. The sealed plan, copied unchanged reference evaluator, candidate/validated code, certificate data, standalone verifier, exact input index, verification results, execution ledger and preservation records.
4. At most two useful figures: a labelled certified chart neighborhood/entry enclosure, and optionally one period's bounded motion. Distinguish certified sets from illustrative midpoint curves; do not imply a fixed physical ball or continuous trajectory between discrete states.
5. Complete payload manifest and concise review instructions. Preserve all earlier accepted artifacts byte-for-byte.

Separate these dispositions:

- `CERTIFIED_LOCAL_ATTRACTION_AT_1_OVER_32`: the exact target map has a certified attracting response and specified neighborhood.
- `CERTIFIED_FIXED_POINT_ONLY`: existence established, but attraction or the requested neighborhood not yet established.
- `NUMERICAL_CANDIDATE_ONLY`: a candidate exists numerically but proof obligations remain.
- `NO_CERTIFICATE_WITHIN_DECLARED_SCOPE`: state what was attempted and the exact obstruction; this is not a nonexistence theorem.

Optional entry status is separate for every checkpoint. A purely analytic proof with explicit inequalities is equally acceptable; no numerical method is mandatory. A contradictory validated result should be reported as such, with its domain—not suppressed to obtain the preferred disposition.

Do not claim a global basin, permanent trace retention, finite-time erasure, heat/magnetism/light, physical storage, SRG-to-Z correspondence, or universal superiority of this formulation. The value of CA04 is to close a specific parameter gap rigorously, or identify precisely what prevents doing so in this bounded investigation.

**End state:** local CA04 research ready for GPT and Hilmir's review. No publication manuscript, staging, commit, push or release. All previous approvals and accepted results retain their original scope.
