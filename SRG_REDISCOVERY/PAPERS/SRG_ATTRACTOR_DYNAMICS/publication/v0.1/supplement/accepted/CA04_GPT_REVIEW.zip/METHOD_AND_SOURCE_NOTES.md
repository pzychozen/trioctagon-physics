# Source and claim boundaries

The private definitions and accepted findings come from the verified CA03 archive and supplied review. The archive SHA-256 is bc18315ce76f64ca8dae5b3fafa4bec77ce0e1eceb06a566a087c01fadb044e4. Its pure model.py is copied byte-for-byte to reference_model.py. CA04_INPUT_INDEX.json supplies the seed bracket and exact checkpoint identities. No external source supplies an SRG equation or a CA04 scientific result.

CA04's new deductions are the exact chart rearrangement, explicit interval implementation, complete finite-parameter contraction certificates, and five conditional entry/convergence statements. The initial derivation is sealed in PRE_RUN_ANALYSIS.md. The final analysis adds numerical evidence without modifying that sealed file. The midpoint Newton result is only a candidate until the separate strict inequalities pass.

No installed Arb/flint or gmpy2 was available. The proof uses Python arbitrary-precision integers, Fraction and integer square root. The official Python 3.11 documentation describes unlimited-precision integers and floor division, and specifies that isqrt returns the floor of the exact square root. These are implementation contracts, not SRG evidence: [numeric types](https://docs.python.org/3.11/library/stdtypes.html#numeric-types-int-float-complex), [integer square root](https://docs.python.org/3.11/library/math.html#math.isqrt). Consulted 21 October 2026; the online 3.11 documentation banner displayed 3.11.17, while the actual environment is 3.11.15.

The Taylor remainder, interval induction and contraction arguments are given self-containedly. The packet's Rump/Arb methodological references were not used as evidence that any particular package was installed or that this certificate passed. No external paper was redistributed by CA04.

The passive geometry helps distinguish the two intrinsic coordinates. No additional crystal overlay was needed for this proof. No physical container, force, symmetry, projection or predictive SRG-to-Z correspondence was introduced.

The full source archive is retained as an unchanged reference. The only imported accepted scientific module was the inspected pure evaluator during the 12 passive preflight comparisons. Accepted runners and kernels were not imported or executed. Optional entry inputs are newly declared exact dyadic initial-value problems, not corrected or reconstructed historical states.
