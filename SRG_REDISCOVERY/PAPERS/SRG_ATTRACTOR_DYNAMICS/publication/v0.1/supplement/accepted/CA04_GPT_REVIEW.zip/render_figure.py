"""Render only saved exact enclosures. No trajectory/model evaluation."""
import os
from pathlib import Path
B=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(B/'render_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from fractions import Fraction as F
import json
c=json.loads((B/'CERTIFICATE.json').read_text());s=json.loads((B/'CERTIFICATE_SCALAR_CONSEQUENCES.json').read_text())
chat,vhat=map(lambda v:float(F(v)),c['center'])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,(ax,bx)=plt.subplots(1,2,figsize=(13.2,6.4),gridspec_kw={'width_ratios':[1.18,1]})
fig.subplots_adjust(left=.08,right=.97,top=.83,bottom=.27,wspace=.30)
fig.suptitle('The complete RETURN map is certified to attract at α = 1/32',x=.08,ha='left',y=.96,fontsize=17,fontweight='bold')
fig.text(.08,.90,'Both intrinsic coordinates evolve • 800 exact-real updates per block • one common forcing phase',fontsize=11,color='#475569')
ax.add_patch(Rectangle((vhat-.1,-1),.2,2,facecolor='#dbeafe',edgecolor='#2563eb',lw=1.6))
ax.axhline(0,color='#a8b6c8',lw=.7)
ax.scatter([vhat],[0],marker='*',s=130,color='#b91c1c',zorder=5)
for j,e in enumerate(s['entry']):
    ax.plot(e['display_final_v'][0],(e['display_final_c'][0]-chat)*1000,'o',ms=5,color='#0f766e')
ax.text(vhat+.016,.70,'Certified region B\nq < 0.925',color='#1e40af',fontsize=12)
ax.annotate('Five entry enclosures',(s['entry'][0]['display_final_v'][0],0),(vhat-.095,-.62),arrowprops={'arrowstyle':'->','color':'#0f766e'},color='#0f766e')
ax.annotate('Primary X / fixed point',(vhat,0),(vhat+.012,-.30),arrowprops={'arrowstyle':'->','color':'#b91c1c'},color='#b91c1c',fontsize=10)
ax.set(xlim=(vhat-.112,vhat+.112),ylim=(-1.15,1.15),xlabel='v = tan(φ / 2)',ylabel='1000 × (c − ĉ)',title='A  Full certified chart rectangle')
ax.text(.02,1.02,'c = cos(θ)',transform=ax.transAxes,fontsize=9,color='#475569')
bx.set_title('B  Complete-block images of the saved starts')
names=['Reference A0p','Earlier size × 1/2','Earlier size × 3/2','Earlier tilt 0','Earlier tilt π/4']
for j,(e,name) in enumerate(zip(s['entry'],names)):
    x=e['display_final_v'][0]
    bx.plot(x,4-j,'o',color='#0f766e',ms=7)
    bx.text(x+.00010,4-j+.18,f'{x:.9f}',fontsize=9,color='#0f766e')
bx.set_yticks(range(5),names[::-1]);bx.set_ylim(-.6,4.6);bx.set_xlim(.0652,.0690)
bx.set_xlabel('v after one validated 800-update block')
bx.grid(axis='x',alpha=.2)
bx.ticklabel_format(axis='x',style='plain',useOffset=False)
fig.text(.08,.16,'All five block images are inside B. Panel B markers locate intervals narrower than 2 × 10⁻⁴⁵ in v.',fontsize=10,color='#334155')
fig.text(.08,.12,'B: |c − ĉ| ≤ 0.001, |v − v̂| ≤ 0.1.   X: |c − ĉ| ≤ 10⁻⁶, |v − v̂| ≤ 10⁻⁵; q < 0.851.',fontsize=10)
fig.text(.08,.078,'The tiny X rectangle is represented by a star at this scale. Exact center, interval endpoints and inclusion margins are in CERTIFICATE.json.',fontsize=9,color='#475569')
fig.text(.08,.038,'The starts are exact stored Cartesian dyadics. Their actual first remap is included. This is a coordinate view, not a physical container.',fontsize=9,color='#475569')
(B/'figures').mkdir(exist_ok=True)
fig.savefig(B/'figures'/'CA04_certified_region_and_entry.png',dpi=180)
fig.savefig(B/'figures'/'CA04_certified_region_and_entry.svg')
plt.close(fig)
print('Rendered one explanatory figure in PNG and SVG; no state updates.')
