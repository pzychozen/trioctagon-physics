# CA04 — A repeating response really attracts at 1/32

**Disposition: CERTIFIED_LOCAL_ATTRACTION_AT_1_OVER_32.**

The complete 800-update RETURN map has a locally attracting repeating response at exactly alpha=1/32. This closes CA03's finite-parameter gap for one explicitly specified neighborhood. Both intrinsic coordinates evolve throughout every update.

The result is a mathematical contraction certificate using outward interval bounds, followed by a fixed-input verification. It does not rely on a small solver residual or additional apparently convergent pulses.

The response repeats at pulse boundaries. Its boundary phase is approximately **0.242070584289 radians**. The theorem concerns the periodically driven sequence; it does not assert a static state throughout a pulse, a circular orbit, or minimal period 800.

The chart is c=cos(theta), v=tan(phi/2). The exact center is

- c-hat = 3296863744182679/9007199254740992;
- v-hat = 4382175857337591/36028797018963968.

The primary rectangle X has radii (0.000001, 0.00001). A larger concentric rectangle B has radii (0.001, 0.1). Each is mapped strictly inside itself by the complete RETURN map. Its conservative contraction bound is below **0.851 in X** and **0.925 in B**, using each rectangle's own weighted maximum norm. These are bounds, not universal phase-retention percentages. The unique fixed point in B is the same one certified in X.

**All five saved starts have certified entry.** A0p_RETURN, Bhalf_RETURN, Bthreehalf_RETURN, Czero_RETURN and Cquarter_RETURN each enter B after one additional complete block. Their actual Cartesian components were taken as exact dyadic new initial values. Their first update was performed in Cartesian coordinates, including clipping checks and the actual remap. The remaining 799 updates used the equivalent intrinsic chart. No state was fitted to the circle or torus, and no inherited prefix was rerun.

Consequently, under this newly specified indefinitely repeated RETURN future, all five starts converge to the same repeating response. Their angular differences tend to zero. This establishes asymptotic loss of those angular distinctions in this protocol; it does not prove exact finite-time erasure. It also does not certify the accumulated error of the older binary64 histories or identify unrecovered historical Figure 4 inputs.

The proof keeps every forcing value, including the small late terms, and includes the derivative of every update. Its task-specific arithmetic uses exact integers, outward dyadic intervals and explicit Taylor remainder bounds. The verifier regenerates the inequalities without searching for a root or changing the boxes. A separately hand-derived Jacobian also passes both contraction tests.

Execution used 3,200 point steps, 6,400 construction/entry set steps, 8,000 fixed-verification set steps, and 12 passive saved-transition checks. No scientific attempt failed and no subdivision or precision refinement was needed. All were below the authorized ceilings.

Read CA04_FINITE_COUPLING_ANALYSIS.md for the derivations, CERTIFICATE.json for exact bounds, REVIEW_INSTRUCTIONS.md for replay, and PRESERVATION_AFTER.json for preservation. The explanatory figure shows the certified coordinate region and the five entry enclosures. Geometry remains a passive analytical reference.

Global attraction, other roots, connection to the small-coupling branch, minimal period, and finite-time injectivity remain unclassified. No dependency was installed. No kernel, accepted research, historical source or unrelated lane was modified. No staging, commit, push or publication was performed.
