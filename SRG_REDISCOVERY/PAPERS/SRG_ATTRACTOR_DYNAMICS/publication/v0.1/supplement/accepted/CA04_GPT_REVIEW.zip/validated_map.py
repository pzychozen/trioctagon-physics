"""Algebraically equivalent full intrinsic update, float or directed intervals."""
import math
from interval_core import I,F
def sqrt(x):return x.sqrt() if hasattr(x,'sqrt') else math.sqrt(x)
class D:
    __slots__=('v','d')
    def __init__(self,v,d=(0,0)):self.v=v;self.d=tuple(d)
    def __add__(self,b):
        if not isinstance(b,D):b=D(b)
        return D(self.v+b.v,[self.d[j]+b.d[j] for j in range(2)])
    __radd__=__add__
    def __neg__(self):return D(-self.v,[-t for t in self.d])
    def __sub__(self,b):return self+-b
    def __rsub__(self,b):return -self+b
    def __mul__(self,b):
        if not isinstance(b,D):b=D(b)
        return D(self.v*b.v,[self.d[j]*b.v+self.v*b.d[j] for j in range(2)])
    __rmul__=__mul__
    def __truediv__(self,b):
        if not isinstance(b,D):b=D(b)
        val=self.v/b.v
        return D(val,[(self.d[j]-val*b.d[j])/b.v for j in range(2)])
    def __rtruediv__(self,b):return D(b)/self
    def __pow__(self,n):
        assert n==2
        return D(self.v**2,[2*self.v*t for t in self.d])
    def sqrt(self):
        val=sqrt(self.v)
        return D(val,[t/(2*val) for t in self.d])
def value(a):return a.v if isinstance(a,D) else a
def require_positive(x,name,stats):
    x=value(x);lo=x.lower() if isinstance(x,I) else x
    assert lo>0,(name,str(lo))
    if stats is not None:stats[name]=min(stats.get(name,lo),lo)
def intrinsic(c,v,k,stats=None):
    cv=value(c)
    if isinstance(cv,I):assert cv.lo>-I(1).hi and cv.hi<I(1).lo
    else:assert -1<cv<1
    r=1+c/2;z=sqrt(1-c**2)/2
    C=(1-v**2)/(1+v**2);S=2*v/(1+v**2)
    R=z**2*S-r*z*C**2
    W=z**2*C-r**2*S+r*z*S*C
    Z=r**2*C**2-r*z*S
    a=r+k*R;b=k*W;d=z+k*Z
    require_positive(a,'radial_u',stats)
    h=sqrt(a**2+b**2);L=sqrt(h**2+d**2)
    require_positive(h,'horizontal_u',stats);require_positive(L,'norm_u',stats)
    require_positive(h+a,'increment_half_angle',stats)
    require_positive(h+a*C-b*S,'original_half_angle',stats)
    w=b/(h+a)
    require_positive(1-v*w,'addition_denominator',stats)
    return d/L,(v+w)/(1-v*w)
def chi(c,v):
    r=1+c/2
    return [r*(1-v**2)/(1+v**2),r*2*v/(1+v**2),sqrt(1-c**2)/2]
def block(x,H,charge,derivative=True,start=0,trace=False):
    state=list(x);zero=I(0) if isinstance(state[0],I) else 0.
    one=I(1) if isinstance(state[0],I) else 1.
    mat=[[one,zero],[zero,one]];stats={};saved=[]
    for f in range(start,800):
        charge.step(derivative)
        if derivative:
            y=intrinsic(D(state[0],(one,zero)),D(state[1],(zero,one)),H[f]/320,stats)
            local=[t.d for t in y]
            mat=[[sum(local[i][k]*mat[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
            state=[t.v for t in y]
        else:state=list(intrinsic(*state,H[f]/320,stats))
        if trace:saved.append([t.dump() for t in state])
    return state,mat,stats,saved
def cartesian_entry(s,H0,charge):
    charge.step(False)
    x,y,z=s;A=[y**2-x*z,z**2-x*y,x**2-y*z]
    q=[H0*t/32 for t in A]
    normq=sqrt(sum(t**2 for t in q))
    assert normq.upper()+F(1,100000)<F(4,5)
    rho=sqrt(x**2+y**2)
    assert rho.lower()-normq.upper()/10>0
    u=[s[j]+q[j]/10 for j in range(3)]
    h=sqrt(u[0]**2+u[1]**2);L=sqrt(h**2+u[2]**2)
    assert h.lo>0 and L.lo>0 and (h+u[0]).lo>0
    state=[u[2]/L,u[1]/(h+u[0])]
    return state,{'qnorm':normq.dump(),'horizontal_segment_lower':str(rho.lower()-normq.upper()/10),'post_first_step':[t.dump() for t in state]}
