# CA04 source anchors and new choices

## Accepted scientific evidence (private project inputs)

The exact SRG definitions and prior findings come from the supplied materials, not web sources.

- `reference/CA03_GPT_REVIEW.zip` / `CA03_RETURNING_DRIVE_ANALYSIS.md` §§1–3: unchanged recurrence, N=800 block, full two-coordinate small-coupling branches and their unproved threshold.
- Same analysis §4 and §9: finite contraction versus indefinite restarting; no certificate at 1/32 and no global basin claim.
- Same analysis §§5–6: smooth derivative formulas, clipping/nonsingularity and schedule-qualified tails.
- Same analysis §8: finite diagnostic results and exact raw-file locations. These remain numerical observations.
- `reference/CA03_GPT_SCIENTIFIC_REVIEW.md` §§3–4 and §8: accepted scope, source semantics, very small nonzero meridional multiplier, remaining finite-parameter gap.
- `CA04_INPUT_INDEX.json`: verified archive members, first-quadrant leading seed, twelve passive preflight rows and five optional stored dyadic initial values.

## New CA04 choices, not already accepted results

The target is one attracting response at exactly 1/32. The proposed chart (c,v), explicit contraction certificate, bounded proof-solver budget and optional five-checkpoint entry test are this new work order. They require Codex's derivation and verification. No CA04 root, stability enclosure, basin or numerical run is supplied in this packet.

The optional future restarts f=0 from each final stored state. This differs from CA03's hypothetical final fading future. The stored floats are treated as exact dyadic *new initial data*, not as certified reconstructions of an earlier exact-real path.

## External methodological references (not SRG source evidence)

These primary references were consulted on 21 October 2026 only for validated-computation methods. They do not establish any CA04 result or availability of software in `torment`. No external paper is redistributed.

**M1 — S. M. Rump, “INTLAB — Interval Laboratory” (1999), introduction and nonlinear-system verification discussion.** The paper distinguishes rigorous arithmetic from a suitable verification algorithm; naive interval substitution may overestimate excessively. This is a methodological warning, not a requirement to install INTLAB.

`https://www.tuhh.de/ti3/paper/rump/Ru99a.pdf`

**M2 — F. Johansson, “Arb: Efficient Arbitrary-Precision Midpoint-Radius Interval Arithmetic,” arXiv:1611.02831 (2016 preprint; later published 2017).** Primary description of arbitrary-precision ball arithmetic and error-bound strategies. Use only a documented implementation already available, or separately justified rigorous bounds.

`https://arxiv.org/abs/1611.02831`

**M3 — Official python-flint `arb` reference, consulted version displayed as 0.9.0.** Documents midpoint/radius balls, rational and exact-binary inputs, rigorous upper/lower bounds, and supported elementary functions. Check the locally installed version instead of assuming it matches. Exact input conversion and enclosing output serialization still matter.

`https://python-flint.readthedocs.io/en/latest/arb.html`

The work order's residual-plus-derivative certificate is explained self-containedly using a weighted contraction argument. Alternative methods must state their own hypotheses; naming an interval-Newton or Krawczyk method is not a substitute for verifying its conditions. Attraction must concern the SRG return map, not merely a solver map.
