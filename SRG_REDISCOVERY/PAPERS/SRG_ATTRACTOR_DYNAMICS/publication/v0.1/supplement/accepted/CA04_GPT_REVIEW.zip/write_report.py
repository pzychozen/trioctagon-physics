"""Assemble reports from saved evidence; no evolution."""
from fractions import Fraction as F
from execution import B,read,write
from interval_core import I,Q,phase
c=read('CERTIFICATE.json');s=read('CERTIFICATE_SCALAR_CONSEQUENCES.json');v=read('VERIFICATION.json');ledger=read('EXECUTION_LEDGER.json')
upperM=[['0.0000000000000003304','0.0000000000001464'],['0.001919','0.850415']]
upperB=[['0.000000000000002691','0.0000000000004244'],['0.005490','0.924524']]
for key,upper,qbound in [('primary',upperM,'0.851'),('larger_region',upperB,'0.925')]:
    for row,up in zip(c[key]['M'],upper):
        assert all(F(a)<=F(b) for a,b in zip(row,up))
    assert F(c[key]['q'])<F(qbound)
assert all(F(x)<F('2e-45') for e in s['entry'] for x in e['final_interval_widths'])
start="""# CA04 — Finite-coupling certificate for the complete RETURN map

**21 October 2026. Disposition: CERTIFIED_LOCAL_ATTRACTION_AT_1_OVER_32.**

The complete exact-real 800-update map at alpha=1/32 has a unique attracting fixed point in each of two explicit nested chart rectangles. All five indexed exact dyadic saved starts have certified entry into the larger rectangle after one block. This proves their convergence to the same periodically driven response under the declared indefinite RETURN future.

The initial proof argument below was sealed before any fresh full-block evaluation. It is reproduced from PRE_RUN_ANALYSIS.md; the results and limitations following it were added after construction and fixed-input replay. The source recurrence, full state and advancing within-block clock remain unchanged.

"""
results="""
## Completed certificate at exactly 1/32

The exact dyadic center is

    c_hat = 3296863744182679 / 9007199254740992
    v_hat = 4382175857337591 / 36028797018963968

Its ordinary values are approximately (0.3660254037843512, 0.1216298133693170). The two-coordinate Newton solve took four complete-block evaluations and stopped with a binary64 residual of 5.55e-17. This was only candidate evidence. The subsequently validated exact-real residual bound is approximately e=(2.90090378513e-18, 1.58224025513e-16); its difference from the ordinary residual illustrates why the latter is not a certificate.

Define X=xhat+[-10^-6,10^-6]×[-10^-5,10^-5]. The following entries are deliberately rounded **upward** bounds on the exact nonnegative derivative-bound matrix in CERTIFICATE.json:

    M_X <= [[3.304e-16, 1.464e-13],
            [0.001919, 0.850415]]

All 800 signed derivative updates were enclosed before taking absolute values. No late update was removed, no matrix entry was declared exactly zero, and the meridional variable was not held fixed. The exact serialized certificate gives:

| Quantity | X result (display values) |
|---|---:|
| First inward margin r_c-e_c-(Mr)_c | 9.99999999995635e-7 |
| Second inward margin r_v-e_v-(Mr)_v | 1.49393583195194e-6 |
| Weighted contraction bound q_X | 0.850606416788984 < 0.851 |

The margins are strictly positive as exact rational inequalities. Thus T(X) is inside the interior of X and T contracts in the norm max(|dc|/10^-6, |dv|/10^-5). Existence and uniqueness concern the actual T; Newton plays no role in these conclusions.

The first declared enclosure succeeded at p=160. No subdivision, alternate radius or precision refinement was used. All interval-domain tests passed. For X, the smallest certified bounds over the complete tube exceed 1.176 for the radial and horizontal pre-remap components, 1.271 for the full norm, 2.318 for the original half-angle denominator, and 0.999997 for the addition denominator. The exact values are in the certificate.

The fixed point is further localized by the exact scalar implication

    |x_star-xhat| <= (I-M_X)^(-1) e.

Indeed, the nonnegative M_X has weighted norm below one, so its Neumann inverse exists and is nonnegative. Applying it to d<=e+M_X d gives the bound. This uses saved certificate inequalities and no new state evaluations. The resulting coordinate-error bounds are less than 2.901e-18 in c and 1.058e-15 in v. The rigorous phase enclosure is contained in

    0.2420705842886754 < phi_star < 0.2420705842886798 radians.

Cartesian coordinates are approximately (1.148520440083195, 0.283583940922842, 0.465302429551067); full exact interval endpoints are in CERTIFICATE_SCALAR_CONSEQUENCES.json. Display rounding can make two endpoints look equal. This does not make the mathematical interval degenerate. The old leading root near 0.245117619178 is only the seed, and no continuation proof linking branches was attempted.

## Larger attracting region and the five entry problems

Only after X passed, the declared larger concentric B with radii (1/1000,1/10) was evaluated. It also passed on its first full-domain attempt, without subdivision:

    M_B <= [[2.691e-15, 4.244e-13],
            [0.005490, 0.924524]]

| Quantity | B result (display values) |
|---|---:|
| First inward margin | 0.000999999999957557 |
| Second inward margin | 0.00754211953063461 |
| Weighted contraction bound q_B | 0.924578804693652 < 0.925 |

B uses max(|dc|/0.001, |dv|/0.1). These norm bounds cannot be read as observed phase-retention fractions or compared as if the norms were the same. Because X is a subset of B, the unique fixed point in B equals the one in X. Every point in B converges to it under T.

The certified B tube has radial/horizontal lower bounds above 1.174, norm above 1.268, original half-angle denominator above 2.206, and addition denominator above 0.999465. Thus there is no chart switch or hidden branch discontinuity.

For each saved state, the serialized exact dyadic components were first verified against the NPZ member and row hashes, float hex and exact ratios. They were then used directly. The actual Cartesian f=0 update checked norm(q)+1/100000<4/5 and a positive horizontal-segment bound. Its post-remap chart state was obtained from u_z/norm(u) and u_y/(rho(u)+u_x). The intrinsic continuation began at f=1 and finished at f=799. There was no initial projection onto K, and no clock restart after the first update.

| Exact stored IVP | Full blocks used | Final v (display only) | Final phase (display only) | Result |
|---|---:|---:|---:|---|
| A0p_RETURN | 1 | 0.065973712572206 | 0.131756488456476 | certified entry into B |
| Bhalf_RETURN | 1 | 0.065671414263580 | 0.131154500024741 | certified entry into B |
| Bthreehalf_RETURN | 1 | 0.066277935162302 | 0.132362284712477 | certified entry into B |
| Czero_RETURN | 1 | 0.065535723538212 | 0.130884281548326 | certified entry into B |
| Cquarter_RETURN | 1 | 0.068144045826960 | 0.136077721177767 | certified entry into B |

Every full two-coordinate endpoint enclosure is contained in B. Their v widths are below 2e-45; no display decimal is substituted for an endpoint. Stop-on-inclusion was obeyed, so no second entry block was run. The first-step and complete-block enclosures, all exact input components and the destination are saved in CERTIFICATE.json.

This is a theorem about the five stored numbers treated as exact new initial values under a new f=0 RETURN future. It does not certify the ideal exact-real versions of the preceding 3,200-update histories. Their later angular differences tend to zero because both full states converge to the same block fixed point and the chart phase is continuous. No exact finite-time identification is inferred.

## Independent verification and arithmetic scope

verify_certificate.py reconstructed every H interval and exactly reproduced the residual and both AD certificates from the fixed inputs. It then propagated a separately hand-derived Jacobian on each of those same full rectangles; those independent bounds also satisfied both strict contraction/inclusion tests. It independently checked all five entry IVPs. No root search, new domain, original runner or reference-evaluator call was part of replay.

The independently hand-derived bounds were approximately q_X=0.850607383690 and q_B=0.943681887849. The second is wider than the AD certificate's 0.924578804694 because the algebraic differential uses different interval groupings. Both enclose the same exact derivative and both prove contraction. The reported q<0.925 for B is the exactly reproduced AD bound.

The arithmetic audit checks exact Fraction endpoint inequalities, integer-square-root enclosure inequalities, primitive differentiation identities, torque decomposition, and the rational half-angle addition identity. The complete written derivative proof is induction through those operations. The separately hand-derived implementation expands the local differential without using the forward AD class, and composes signed interval matrices.

This is a computer-assisted proof based on the stated arithmetic and code assumptions, not a proof-assistant formalization or a theorem obtained by precision agreement. The trusted arithmetic core is limited to exact integers, rational conversion, directed operations and integer square root. The exponential and trigonometric functions are built with the explicit remainder bounds above. METHOD_AND_SOURCE_NOTES.md separates the official Python contracts from private model evidence.

The binary64 preflight covered exactly twelve saved predecessor/successor cases. All compared fields agreed exactly in this environment (maximum difference zero). That check establishes consistency only; the proof uses exact-real rational times, not the saved binary64 t values.

## Execution, preservation and limitations

The numerical plan and initial mathematical analysis were sealed before the first complete-block evaluation. The four scientific sessions were preflight/audit, candidate, construction/entry, and fixed replay. Every session's code hashes and runtime appear in EXECUTION_LEDGER.json. All completed successfully; there were no failed scientific traversals, refinements, hidden retries or finite-difference evaluations.

| Category | Actual steps | Authorized ceiling |
|---|---:|---:|
| Candidate point traversals: 4 blocks | 3,200 | 19,200 |
| Construction center, X, B: 3 blocks | 2,400 | shared below |
| Optional five entry blocks | 4,000 | shared below |
| Total construction/entry | 6,400 | 76,800 |
| Fixed replay including independent hand derivatives | 8,000 | 76,800 |
| Passive saved-transition preflight | 12 | 12 |
| Inherited prefixes / unstructured rollouts / native kernel updates | 0 / 0 / 0 | 0 / 0 / 0 |

Simultaneous derivative work is separately recorded: point 3,200, construction 1,600, replay 3,200 derivative steps. The two scalar H preparations each constructed 800 intervals and are recorded separately. Supplemental readouts, scalar root bounds, figure rendering and packaging advance no states.

The durable ledger reserves each complete traversal before execution and charges actual attempted steps on normal completion or handled failure; an unhandled process crash leaves the reservation charged. Scientific runtime totals, including conservative process-launch timing, are far below the 1,800/900-second limits. The 250 MB new-result ceiling is checked during packaging. EXECUTION_ACCOUNTING.json records non-scientific preparation and rendering activity as well.

Consumed originals are hashed before and after. HEAD, staged diff and tracked diff are recorded; outside-workspace status is compared without resetting unrelated files. Git reports pre-existing overlong untracked paths in another research lane; those warning paths are recorded, not interpreted as complete coverage of those untracked trees. Consumed hashes and tracked/index checks remain independently available.

All equations, clipping, kernels and accepted research are preserved. The geometry is a passive coordinate instrument. The explanatory figure uses only saved enclosures; its markers are visualization readouts and its rectangle is a certified chart domain, not a physical wall.

The certificate settles one local finite-parameter question and the five specified new futures. It does not classify all initial states, other fixed points, a global basin, branch connection as alpha changes, minimal period, an ambient open neighborhood, or finite-time invertibility. A tiny derivative component or an interval containing zero proves no exact erasure. Within-block convergence follows by the finite-prefix continuity argument; no continuous-time path between discrete states is assumed.
"""
# Check the report's outward phase endpoints against the exact interval.
pr=I.raw(*map(int,s['root_phase']))
assert F('0.2420705842886754')<pr.lower() and pr.upper()<F('0.2420705842886798')
pre=(B/'PRE_RUN_ANALYSIS.md').read_text(encoding='utf-8')
pre=pre.replace('# CA04 mathematical analysis sealed before numerical work','# Initial sealed mathematical analysis',1)
(B/'CA04_FINITE_COUPLING_ANALYSIS.md').write_text(start+pre+results,encoding='utf-8')
account={'counts':ledger['counts'],'derivative_steps':ledger['derivative_steps'],'recorded_session_seconds':ledger['seconds'],'conservative_observed_command_wall_seconds':{'preflight':1.8476291,'candidate':1.6189986,'construction':3.68128,'replay':4.9068679},'limits_seconds':{'candidate_plus_construction':1800,'replay':900},'scientific_sessions':4,'failed_scientific_sessions':0,'scalar_forcing_values':ledger['scalar_forcing_values'],'candidate_scalar_H_values':800,'other_activity':[{'activity':'Packet inspection, verified extraction and source reading','state_steps':0},{'activity':'Exact root-localization and displayed bound checks from saved certificate','state_steps':0},{'activity':'Figure render then footer-spacing repair; two successful render calls','state_steps':0},{'activity':'Report assembly, source preservation and ZIP validation','state_steps':0}],'preparation_note':'An initial oversized inspection output was truncated and reread in bounded parts. One tool patch expression failed to parse before filesystem/scientific execution. Neither used state evaluations.','clock_scope':'Scientific execution wall time, not elapsed authoring/inspection time. Recorded whole-command timings conservatively cover startup and scalar/symbolic work outside the session timer.','zero_activities':['dependency installation','inherited prefix rerun','unstructured long rollout','native kernel update','Git mutation','publication']}
write('EXECUTION_ACCOUNTING.json',account)
print('Report written; summary words',len((B/'READ_ME_FIRST.md').read_text().split()))
print('Independent hand q:',{k:float(F(v[k]['independent_hand_q'])) for k in ['primary','larger_region']})
