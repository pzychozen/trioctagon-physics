# CA04 mathematical analysis sealed before numerical work

## Exact dynamics and domain

Let A(s)=(y^2-xz,z^2-xy,x^2-yz), H(t)=2exp(-t/2)cos(t)+exp(-3t/10)sin(t)+(3/2)exp(-7t/10)+exp(-2t/5). The full map is T=F_799 o ... o F_0, each F=P(s+qhat/10), q=(1/32)H(f/10)A(s), qhat=q min(1,(4/5)/(norm(q)+1/100000)). These rational coefficients and times are exact. The accepted binary64 evaluator remains a separate unchanged consistency reference.

For t>=0, |2e^(-t/2)cos(t)+e^(-3t/10)sin(t)|<=2e^(-t/2)+t e^(-3t/10). The derivative of this upper envelope is nonpositive because 1-3t/10<=exp(-t/5). Its value at zero is 2; adding the last two terms gives |H|<=9/2. On K, norm(s)<=3/2, rho>=1/2, norm(A)<=norm(s)^2. Thus norm(q)<=81/256, strictly below 4/5-1/100000. The horizontal straight-segment radius is at least 1/2-81/2560=1199/2560. These proofs justify the smooth inactive-clip branch on K, not an alteration of clipping. Off-K entry requires its own interval check.

## Exact two-coordinate map

Let c in (-1,1), v finite, r=1+c/2, z=sqrt(1-c^2)/2, C=(1-v^2)/(1+v^2), S=2v/(1+v^2). Then chi=(rC,rS,z), C^2+S^2=1, and chi lies on K. Conversely, on this open chart, c=2(rho-1), v=y/(rho+x), z>0.

Put k=H(f/10)/320. Resolve the torque in the horizontal basis (C,S),(-S,C):

R=C A_x+S A_y=z^2 S-rz C^2,
W=C A_y-S A_x=z^2 C-r^2 S+rz SC,
Z=A_z=r^2 C^2-rz S.

Write a=r+kR, b=kW, d=z+kZ, h=sqrt(a^2+b^2), L=sqrt(h^2+d^2). Then u=(aC-bS,aS+bC,d). With a>0, the short angular increment delta has tan(delta/2)=w=b/(h+a). Hence the exact chart update is

c_next=d/L,
v_next=(v+w)/(1-vw).

Require h+a>0, 1-vw>0 and the original horizontal half-angle denominator h+u_x>0. The explicit interval tests also require -1<c<1, h>0, L>0. There is no chart transition or phase wrap in the accepted tube. Since P(u) has radius 1+d/(2L) and height h/(2L)>0, its chi parameters are exactly (d/L,u_y/(h+u_x)); the half-angle addition identity gives the expression above. The simplification preserves the complete update and does not fix c at c*. In particular late k values remain present.

## Derivatives

For any independent coordinates x_j, use d(ab)=b da+a db, d(a/b)=(da-(a/b)db)/b, d sqrt(a)=da/(2sqrt(a)), d(a^2)=2a da. Begin Dc=(1,0), Dv=(0,1). The explicit scalar ingredients have

dr=dc/2, dz=-c dc/(2sqrt(1-c^2)),
dC=-4v dv/(1+v^2)^2, dS=2(1-v^2)dv/(1+v^2)^2.

Differentiate R,W,Z and the subsequent expressions by these rules. This produces the two-by-two local Jacobian J_f throughout the full interval state box. Propagate signed matrices D_{f+1}=J_f D_f, D_0=I, before taking absolute bounds at f=800. Natural state interval images contain every orbit of the starting rectangle; J_f therefore bounds every needed local derivative. Matrix interval induction encloses the full derivative on the entire initial domain, including correlations that are discarded conservatively. Subdivision unions can reduce overestimation and must cover the original rectangle exactly. No approximate central derivative is substituted for a set derivative.

## Directed arithmetic proof

Fix Q=2^p. An interval is [l/Q,h/Q] with arbitrary-size signed integer l<=h. Rational n/d is enclosed by floor(nQ/d),ceil(nQ/d), with d>0. Addition and subtraction are exact at the grid. Multiplication takes the min and max of four endpoint integer products, then divides outward by Q. Division first bounds the reciprocal with floor(Q^2/h),ceil(Q^2/l) when zero is excluded; negative intervals follow the same decreasing reciprocal rule. Squaring uses 0 as the minimum when the interval crosses zero. Square root for l>=0 is [isqrt(lQ),ceil_sqrt(hQ)]/Q. Integer-square comparisons establish both inequalities exactly. These operations enclose their real functions; induction encloses every arithmetic expression. No binary floating arithmetic enters a certified endpoint.

For each exact rational t=f/10, the exponents and trig arguments are divided by 128. Their absolute values are <1. Evaluate the degree-64 Taylor polynomial of exp(y), sin(y), cos(y) with interval arithmetic. The exponential remainder is at most 3/65!, since exp(|y|)<3 for |y|<=1 (the series for e is less than 3). Each sine/cosine remainder is at most 1/65! by Taylor's theorem. Add these symmetric rational error intervals, then use exp(2y)=exp(y)^2, sin(2y)=2sin(y)cos(y), cos(2y)=cos(y)^2-sin(y)^2 seven times. These identities propagate the enclosing errors to the requested arguments. Round every operation outward. This constructs 800 exact-real forcing enclosures, including constants and all late values.

For phase display, if |v|<=1/2, use 2atan(v)=2 sum_{j=0}^{127} (-1)^j v^(2j+1)/(2j+1), with symmetric error at most 2/(257*2^257); the alternating-series bound applies separately at every point in the interval. Cartesian display uses chi with the same outward arithmetic. Display bounds are not substituted back into dynamics.

## Existence and attraction theorem to verify

For an exact dyadic center xhat and positive rational radius vector r, define the closed convex rectangle X=xhat+[-r,r]. Suppose all 800 compositions are smooth on X, |T(xhat)-xhat|<=e, and |DT(x)|<=M for every x in X. For any x in X, integrate the derivative along the segment from xhat to x to get |T(x)-xhat|<=e+Mr. If e+Mr<r componentwise then T maps X into its interior. The same segment argument for any two points gives ||T(x)-T(y)||_r<=q||x-y||_r, where q=max_i (Mr)_i/r_i<1. The closed rectangle in this weighted norm is complete, so the contraction argument gives a unique fixed point in X and convergence of all its iterates. This is a statement about the physical update T, not Newton's iteration.

For a larger certified concentric B containing X, the unique root is the same because the root in X is in B. Its invariance and contraction may have different certified bounds. For each exact stored dyadic Cartesian start, carry out the actual F_0 with a rigorous off-K clipping/axis bound, extract c=u_z/norm(u), v=u_y/(rho(u)+u_x) for P(u), then evaluate f=1,...,799. If that entire endpoint enclosure is inside B (or X), induction supplies the indefinite future without extra pulses. This changes neither initial state nor dynamics. It certifies a newly declared dyadic initial-value problem, not the old floating calculation's accumulated history.

Convergence of T at the boundaries implies convergence at each corresponding within-block phase by continuity of each finite prefix F_{j-1} o ... o F_0. The result is a periodically driven response; its minimal period and within-pulse stationarity are not assumed. The theorem is intrinsic to K and the specifically validated off-K starts, not an unproved ambient neighborhood claim. A derivative interval containing zero does not prove a zero multiplier, invertibility failure or exact finite-time erasure. The geometry is a passive coordinate reference.

## Possible conclusions

Only strict verified inequalities warrant CERTIFIED_LOCAL_ATTRACTION_AT_1_OVER_32. A root existence proof without dynamics stability is CERTIFIED_FIXED_POINT_ONLY. An ordinary solver alone gives NUMERICAL_CANDIDATE_ONLY. Failure to close these obligations within scope is NO_CERTIFICATE_WITHIN_DECLARED_SCOPE, not nonexistence. Entry conclusions are separate for the five indexed initial data.
