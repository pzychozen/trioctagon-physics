"""Task-specific directed dyadic arithmetic. No external numeric backend."""
from fractions import Fraction as F
from math import isqrt,factorial
P=160
Q=1<<P
def ceildiv(a,b): return -((-a)//b)
class I:
    __slots__=('lo','hi')
    def __init__(self,x=0):
        if isinstance(x,I):self.lo,self.hi=x.lo,x.hi
        else:
            assert not isinstance(x,float),'Proof constants cannot enter as floats'
            x=F(x);self.lo=x.numerator*Q//x.denominator;self.hi=ceildiv(x.numerator*Q,x.denominator)
    @classmethod
    def raw(cls,l,h):
        assert isinstance(l,int) and isinstance(h,int) and l<=h
        s=object.__new__(cls);s.lo=l;s.hi=h;return s
    @classmethod
    def box(cls,l,h):
        l,h=F(l),F(h);assert l<=h
        return cls.raw(I(l).lo,I(h).hi)
    def __add__(self,b):
        if not isinstance(b,(I,int,F,str)):return NotImplemented
        b=I(b);return I.raw(self.lo+b.lo,self.hi+b.hi)
    __radd__=__add__
    def __neg__(self):return I.raw(-self.hi,-self.lo)
    def __sub__(self,b):return self+-I(b)
    def __rsub__(self,b):return I(b)+-self
    def __mul__(self,b):
        if not isinstance(b,(I,int,F,str)):return NotImplemented
        b=I(b);p=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi]
        return I.raw(min(p)//Q,ceildiv(max(p),Q))
    __rmul__=__mul__
    def reciprocal(self):
        assert self.lo>0 or self.hi<0,'Division through zero'
        return I.raw(Q*Q//self.hi,ceildiv(Q*Q,self.lo))
    def __truediv__(self,b):return self*I(b).reciprocal()
    def __rtruediv__(self,b):return I(b)*self.reciprocal()
    def __pow__(self,n):
        assert n==2
        l=0 if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi)
        h=max(self.lo*self.lo,self.hi*self.hi)
        return I.raw(l//Q,ceildiv(h,Q))
    def sqrt(self):
        assert self.lo>=0,'Negative square root'
        l=isqrt(self.lo*Q);h=isqrt(self.hi*Q)
        if h*h<self.hi*Q:h+=1
        return I.raw(l,h)
    def lower(self):return F(self.lo,Q)
    def upper(self):return F(self.hi,Q)
    def magnitude(self):return F(max(abs(self.lo),abs(self.hi)),Q)
    def dump(self):return [str(self.lo),str(self.hi)]
    def midfloat(self):return (self.lo+self.hi)/(2*Q)
    def contains(self,b):b=I(b);return self.lo<=b.lo and b.hi<=self.hi
    def hull(self,b):return I.raw(min(self.lo,b.lo),max(self.hi,b.hi))

def exp_interval(x):
    y=I(x)/128
    assert y.magnitude()<=1
    t=I(1);s=t
    for n in range(1,65):t=t*y/n;s=s+t
    err=F(3,factorial(65));s=s+I.box(-err,err)
    assert s.lo>0
    for _ in range(7):s=s**2
    return s
def sincos_interval(x):
    y=I(x)/128
    assert y.magnitude()<=1
    t=I(1);s=I(0);c=I(1)
    for n in range(1,65):
        t=t*y/n
        if n%2:s=s+(t if (n//2)%2==0 else -t)
        else:c=c+(t if (n//2)%2==0 else -t)
    err=F(1,factorial(65));e=I.box(-err,err)
    s,c=s+e,c+e
    for _ in range(7):s,c=2*s*c,c**2-s**2
    return s,c
def forcing():
    out=[]
    for f in range(800):
        t=F(f,10);s,c=sincos_interval(t)
        h=2*exp_interval(-t/2)*c+exp_interval(-3*t/10)*s+F(3,2)*exp_interval(-7*t/10)+exp_interval(-2*t/5)
        out.append(h)
    return out
def phase(v):
    v=I(v);assert v.magnitude()<=F(1,2)
    power=v;s=I(0)
    for j in range(128):
        term=power/(2*j+1);s=s+(term if j%2==0 else -term)
        power=power*v**2
    err=F(1,257*2**257)
    return 2*(s+I.box(-err,err))
