"""Independent hand differential of the equivalent intrinsic graph.

Used only by fixed-certificate replay. Does not use the forward AD class.
"""
from interval_core import I
from validated_map import require_positive
def hand_step(c,v,k,stats):
    assert -I(1).hi<c.lo and c.hi<I(1).lo
    r=1+c/2;z=(1-c**2).sqrt()/2;den=1+v**2
    C=(1-v**2)/den;S=2*v/den
    R=z**2*S-r*z*C**2
    W=z**2*C-r**2*S+r*z*S*C
    Z=r**2*C**2-r*z*S
    a=r+k*R;b=k*W;d=z+k*Z
    h=(a**2+b**2).sqrt();L=(h**2+d**2).sqrt()
    w=b/(h+a);E=1-v*w
    for name,x in [('radial_u',a),('horizontal_u',h),('norm_u',L),('increment_half_angle',h+a),('original_half_angle',h+a*C-b*S),('addition_denominator',E)]:
        require_positive(x,name,stats)
    out=[d/L,(v+w)/E]
    jac=[[],[]]
    for j in range(2):
        dr=I('1/2') if j==0 else I(0)
        dz=-c/(4*z) if j==0 else I(0)
        dC=I(0) if j==0 else -4*v/(den**2)
        dS=I(0) if j==0 else 2*(1-v**2)/(den**2)
        dv=I(j)
        dR=2*z*dz*S+z**2*dS-(dr*z+r*dz)*C**2-2*r*z*C*dC
        dW=2*z*dz*C+z**2*dC-2*r*dr*S-r**2*dS+(dr*z+r*dz)*S*C+r*z*(dS*C+S*dC)
        dZ=2*r*dr*C**2+2*r**2*C*dC-(dr*z+r*dz)*S-r*z*dS
        da=dr+k*dR;db=k*dW;dd=dz+k*dZ
        dh=(a*da+b*db)/h;dL=(a*da+b*db+d*dd)/L
        dw=(db*(h+a)-b*(dh+da))/((h+a)**2)
        jac[0].append((dd*L-d*dL)/(L**2))
        jac[1].append(((dv+dw)*E+(v+w)*(dv*w+v*dw))/(E**2))
    return out,jac
def hand_block(x,H,charge):
    mat=[[I(1),I(0)],[I(0),I(1)]];stats={}
    for f in range(800):
        charge.step(True)
        x,local=hand_step(*x,H[f]/320,stats)
        mat=[[sum(local[i][k]*mat[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
    return x,mat,stats
