"""Deterministic enclosure of declared boxes. No solver or box-selection logic."""
from interval_core import I,F,phase
from validated_map import block,chi
def dumps(a):return [[t.dump() for t in row] for row in a]
def statebounds(x):return [t.dump() for t in x]
def region(center,radii):
    return [I.box(c-r,c+r) for c,r in zip(center,radii)]
def residual(center,H,session,kind):
    x=list(map(I,center))
    with session.reserve(kind,800,'fixed center residual') as count:
        y,_,stats,trace=block(x,H,count,derivative=False,trace=True)
    res=[y[i]-x[i] for i in range(2)]
    return {'enclosure':statebounds(res),'e':[str(t.magnitude()) for t in res],'output':statebounds(y),'domain_minima':{k:str(v) for k,v in stats.items()},'trace':trace}
def prove_box(center,radii,subdivisions,H,e,session,kind,label):
    nc,nv=subdivisions;assert nc>=1 and nv>=1
    total=None;records=[]
    for i in range(nc):
        for j in range(nv):
            ranges=[]
            for c,r,n,k in zip(center,radii,[nc,nv],[i,j]):
                ranges.append((c-r+2*r*k/n,c-r+2*r*(k+1)/n))
            box=[I.box(*p) for p in ranges]
            with session.reserve(kind,800,label+f' subdivision {i},{j}/{nc},{nv}') as count:
                out,der,stats,_=block(box,H,count,derivative=True)
            if total is None:total=der
            else:total=[[total[a][b].hull(der[a][b]) for b in range(2)] for a in range(2)]
            records.append({'subdivision':[i,j],'input':statebounds(box),'output':statebounds(out),'signed_derivative':dumps(der),'domain_minima':{k:str(v) for k,v in stats.items()}})
    M=[[t.magnitude() for t in row] for row in total]
    mr=[sum(M[i][j]*radii[j] for j in range(2)) for i in range(2)]
    margin=[radii[i]-e[i]-mr[i] for i in range(2)]
    q=max(mr[i]/radii[i] for i in range(2))
    box=region(center,radii)
    return {'label':label,'radii':list(map(str,radii)),'subdivisions':list(subdivisions),'signed_derivative':dumps(total),'M':[[str(t) for t in row] for row in M],'Mr':list(map(str,mr)),'e':list(map(str,e)),'inward_margins':list(map(str,margin)),'q':str(q),'passed':all(t>0 for t in margin) and q<1,'subboxes':records,'chart_box':statebounds(box),'phase_enclosure':phase(box[1]).dump(),'cartesian_enclosure':statebounds(chi(*box))}
def inside(x,center,radii):
    return all(c-r<=t.lower() and t.upper()<=c+r for t,c,r in zip(x,center,radii))
