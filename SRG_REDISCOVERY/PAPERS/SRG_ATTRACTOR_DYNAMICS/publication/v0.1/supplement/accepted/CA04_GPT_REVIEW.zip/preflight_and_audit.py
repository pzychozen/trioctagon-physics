"""Saved transitions only; exact scalar arithmetic and symbolic checks."""
import numpy as np
import sympy as sp
from fractions import Fraction as F
from math import isqrt
from execution import B,Session,read,write,digest
from interval_core import I,Q
from validated_map import D
import reference_model as ref

def audits():
    tests=0
    for i in range(-12,13):
        a=I.box(F(i,7),F(i+2,7));b=I.box(F(i+1,11),F(i+3,11))
        for x in [a.lower(),a.upper(),(a.lower()+a.upper())/2]:
            for y in [b.lower(),b.upper(),(b.lower()+b.upper())/2]:
                for out,exact in [(a+b,x+y),(a-b,x-y),(a*b,x*y)]:
                    assert out.lower()<=exact<=out.upper();tests+=1
                if b.lo>0 or b.hi<0:
                    out=a/b;assert out.lower()<=x/y<=out.upper();tests+=1
            out=a**2;assert out.lower()<=x*x<=out.upper();tests+=1
        pos=I.box(F(i*i,13),F(i*i+3,13));rt=pos.sqrt()
        assert rt.lower()**2<=pos.lower() and rt.upper()**2>=pos.upper();tests+=1
    # Primitive AD rules verified independently by symbolic differentiation.
    c,v=sp.symbols('c v',real=True)
    f=c*c+c*v;g=1+v*v
    df=D(f,(sp.diff(f,c),sp.diff(f,v)));dg=D(g,(0,sp.diff(g,v)))
    for val,der in [(df+dg, f+g),(df*dg,f*g),(df/dg,f/g),(df**2,f*f)]:
        for j,x in enumerate([c,v]):assert sp.cancel(val.d[j]-sp.diff(der,x))==0;tests+=1
    h=sp.symbols('h',positive=True)
    assert sp.diff(sp.sqrt(h),h)==1/(2*sp.sqrt(h));tests+=1
    r,z=sp.symbols('r z',real=True)
    C=(1-v*v)/(1+v*v);S=2*v/(1+v*v)
    Ax=r*r*S*S-r*z*C;Ay=z*z-r*r*C*S;Az=r*r*C*C-r*z*S
    for expr in [C*C+S*S-1,C*Ax+S*Ay-(z*z*S-r*z*C*C),C*Ay-S*Ax-(z*z*C-r*r*S+r*z*S*C),sp.diff(C,v)+4*v/(1+v*v)**2,sp.diff(S,v)-2*(1-v*v)/(1+v*v)**2]:
        assert sp.cancel(expr)==0;tests+=1
    # Half-angle addition, with h=a(1+w²)/(1-w²), b=2aw/(1-w²).
    a,w=sp.symbols('a w',real=True)
    b=2*a*w/(1-w*w);h=a*(1+w*w)/(1-w*w)
    assert sp.cancel((a*S+b*C)/(h+a*C-b*S)-(v+w)/(1-v*w))==0;tests+=1
    return {'exact_scalar_checks':tests,'symbolic_chart_and_AD_rules':'PASS','interval_grid_bits':160,'proof_basis':'PRE_RUN_ANALYSIS.md, exact Python integers and math.isqrt','sympy':sp.__version__,'numpy':np.__version__}

if __name__=='__main__':
    with Session('seal, source preflight, arithmetic and symbolic audit') as session:
        idx=read('CA04_INPUT_INDEX.json');out=[]
        with session.reserve('preflight',12,'12 indexed saved predecessor/successor cases') as count:
            for e in idx['passive_preflight_inputs']:
                p=B/'inputs'/'ca03'/e['archive_member'];assert digest(p)==e['member_sha256']
                with np.load(p,allow_pickle=False) as a:
                    j=e['transition_row'];s=a['s'][j];dest=a['dest'][j];t=float(a['t'][j]);alpha=float(a['alpha'][j])
                    import hashlib
                    assert hashlib.sha256(s.tobytes()).hexdigest()==e['s_sha256']
                    assert hashlib.sha256(dest.tobytes()).hexdigest()==e['dest_sha256']
                    assert t.hex()==e['time_float_hex'] and alpha.hex()==e['alpha_float_hex'] and e['forcing_index']==j%800
                    count.step();got=ref.step(s,t,alpha)
                    errors={k:float(np.max(np.abs(np.asarray(got[k])-a[k][j]))) for k in ['dest','q','qhat','u','H','factor']}
                    assert all(v<=1e-12*max(1,float(np.max(np.abs(a[k][j])))) for k,v in errors.items())
                    out.append({'member':e['archive_member'],'row':j,'errors':errors})
        # Read/verify all five exact dyadic input identities, without propagation.
        for e in idx['optional_stored_checkpoint_initial_value_problems']:
            p=B/'inputs'/'ca03'/e['archive_member'];assert digest(p)==e['member_sha256']
            with np.load(p,allow_pickle=False) as a:
                s=a['states'][2400]
                assert hashlib.sha256(s.tobytes()).hexdigest()==e['state_row_c_order_sha256']
                for x,d in zip(s,e['components_xyz']):
                    assert float(x).hex()==d['float_hex'] and F(float(x))==F(d['exact_dyadic'])
        write('PREFLIGHT.json',{'cases':out,'max_error':max(v for e in out for v in e['errors'].values()),'new_chained_steps':0,'optional_identities':5})
        write('ARITHMETIC_AUDIT.json',audits())
        print('PASS: 12 passive transitions; exact dyadic identities; arithmetic and symbolic audit.')
