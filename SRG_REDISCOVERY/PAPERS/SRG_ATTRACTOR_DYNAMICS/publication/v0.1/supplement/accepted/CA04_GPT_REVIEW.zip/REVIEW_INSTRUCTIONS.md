# Review the fixed certificate

Extract CA04_GPT_REVIEW.zip into a separate directory if you want to preserve the delivered ledger and verification files. The bundle contains the required modules and accepted input copies; it does not depend on the original repository paths during verification.

In Windows CMD, activate the existing environment and change to the extracted directory:

~~~bat
call conda activate torment
cd /d C:\path\to\extracted_CA04
python -B verify_certificate.py
~~~

Use ordinary Python, not python -O: the verifier intentionally uses assertions for proof obligations. The tested environment is Python 3.11.15, NumPy 2.4.4 and SymPy 1.14.0. No installation is needed in torment. The enclosure core itself uses the Python standard library; the independent scalar/symbolic audit also uses the already installed packages.

The verifier checks sealed source identities, rebuilds all 800 exact-real forcing intervals, re-evaluates the fixed center residual, and reproduces both declared rectangles' inclusion and derivative bounds. It also propagates a separately hand-derived Jacobian through those same fixed rectangles, then verifies the five declared dyadic entry problems. It performs no candidate search, domain choice, parameter sweep, reference-model calls or inherited-prefix replay.

One verification consumes 8,000 validated set steps: center 800; X and B with AD 1,600; X and B with hand derivatives 1,600; five entry blocks 4,000. It writes VERIFICATION.json and appends to EXECUTION_LEDGER.json. The ledger never resets on re-execution. Future review invocations are additional computations and should be counted in that copy.

Do not run solve_candidate.py, construct_certificate.py, preflight_and_audit.py, or accepted historical runners merely to check the certificate. The existing ledger has already consumed the 12 authorized passive preflight cases; their source and results are supplied.

## Where the evidence lives

| File | Review purpose |
|---|---|
| CA04_PLAN.md; PRE_RUN_ANALYSIS.md; PRE_RUN_SEAL.json | Plan and mathematical argument sealed before full-block evaluation |
| CA04_FINITE_COUPLING_ANALYSIS.md | Full derivation, strict numerical inequalities and scope |
| reference_model.py | Unchanged accepted binary64 evaluator; only preflight used it |
| interval_core.py | 160-bit dyadic intervals, outward rounding, bounded elementary functions |
| validated_map.py | Complete intrinsic recurrence and forward AD |
| independent_derivative.py | Separately hand-derived differential used by replay |
| CERTIFICATE.json | Exact target, center, radii, residual, signed DT, M, margins, q, entry data |
| FORCING_INTERVALS.json | All 800 forcing enclosures; endpoint integers divided by 2^160 |
| CENTER_RESIDUAL.json | Rigorous center residual and all 800 intermediate center enclosures |
| CONSTRUCTION_ATTEMPTS.json | Two successful declared-box attempts, no failures |
| CERTIFICATE_SCALAR_CONSEQUENCES.json | Root enclosure from (I-M)^-1 e; no new trajectories |
| summarize_certificate.py | Recomputes those scalar consequences from saved certificates |
| VERIFICATION.json; ARITHMETIC_AUDIT.json | Fixed replay, independent derivative and scalar checks |
| EXECUTION_LEDGER.json; EXECUTION_ACCOUNTING.json | Cumulative steps, derivative work, times, code hashes |
| PRESERVATION_BEFORE/AFTER.json; evidence/ | Consumed-original identities and Git read-only snapshots |
| inputs/packet/; inputs/ca03/ | Verified work order, accepted archive/review and selected copies |
| figures/CA04_certified_region_and_entry.png | One scientific figure; SVG is the same figure |
| MANIFEST.json | Complete payload sizes and SHA-256 values, excluding itself |

Interval data are pairs of decimal-encoded **integers**, representing endpoints divided by 2^160. Exact scalar bounds and input constants are rational strings. Fields beginning with display are ordinary rounded readouts and are never proof inputs. Equality of rounded displayed endpoints does not mean zero interval width or exact coalescence.

The rigorous implementation is a small transparent computer-assisted proof, not a proof-assistant formalization. Its trust assumptions are the reviewed formulas/code, Python integer semantics and integer square root. Exact source and file seals support reproducibility; they are not mathematical evidence by themselves.
