"""Standalone fixed-input replay. Run python -B verify_certificate.py.

No candidate search, choice of new domains, old prefixes, or reference calls.
Outputs replay JSON and updates the persistent ledger in this extracted bundle.
"""
from fractions import Fraction as F
from interval_core import I,P,forcing
from execution import B,Session,read,write,digest
from certificate_math import residual,prove_box,region,inside,statebounds
from validated_map import cartesian_entry,block
from independent_derivative import hand_block
from preflight_and_audit import audits
def main():
    cert=read('CERTIFICATE.json')
    assert cert['target']=={'alpha':'1/32','dt':'1/10','N':800,'forcing_indices':[0,799],'clip':'4/5','epsilon':'1/100000','semantics':'exact-real'}
    assert cert['bits']==P==160
    for n,h in cert['code_sha256'].items():assert digest(B/n)==h,(n,'construction code changed')
    for n,h in read('PRE_RUN_SEAL.json')['files'].items():assert digest(B/n)==h
    center=list(map(F,cert['center']))
    results={'target':'complete exact-real RETURN at alpha=1/32','audits':audits(),'primary':None,'larger_region':None,'entry':[]}
    with Session('fixed certificate replay with independent hand derivative',mode='replay') as session:
        H=forcing();session.scalar(800)
        assert [h.dump() for h in H]==read('FORCING_INTERVALS.json')['values']
        res=residual(center,H,session,'replay')
        assert {k:v for k,v in res.items() if k!='trace'}==cert['center_residual']
        e=list(map(F,res['e']))
        for key in ['primary','larger_region']:
            saved=cert[key]
            if saved is None:continue
            radii=list(map(F,saved['radii']))
            out=prove_box(center,radii,tuple(saved['subdivisions']),H,e,session,'replay',saved['label'])
            assert out==saved and out['passed'],key
            assert all(F(m)>0 for m in out['inward_margins']) and F(out['q'])<1
            # Repropagate the same fixed box with a separately hand-derived J.
            assert saved['subdivisions']==[1,1],'This fixed certificate has no subdivisions'
            with session.reserve('replay',800,'independent hand derivative '+key) as count:
                _,mat,stats=hand_block(region(center,radii),H,count)
            M=[[t.magnitude() for t in row] for row in mat]
            mr=[sum(M[i][j]*radii[j] for j in range(2)) for i in range(2)]
            margins=[radii[i]-e[i]-mr[i] for i in range(2)]
            q=max(mr[i]/radii[i] for i in range(2))
            assert q<1 and all(t>0 for t in margins)
            results[key]={'exact_reproduction':True,'independent_hand_M':[[str(t) for t in row] for row in M],'independent_hand_q':str(q),'independent_hand_margins':list(map(str,margins))}
        if cert['larger_region']:
            assert all(F(a)<=F(b) for a,b in zip(cert['primary']['radii'],cert['larger_region']['radii']))
        index={e['case']:e for e in read('CA04_INPUT_INDEX.json')['optional_stored_checkpoint_initial_value_problems']}
        for en in cert['entry']:
            inp=index[en['case']]
            assert en['input_dyadics']==[t['exact_dyadic'] for t in inp['components_xyz']]
            assert digest(B/'inputs'/'ca03'/inp['archive_member'])==inp['member_sha256']
            assert len(en['blocks'])<=4 and inp['new_future_next_forcing_index']==0
            with session.reserve('replay',800,'fixed entry '+en['case']+' block 1') as count:
                x,first=cartesian_entry([I(F(t)) for t in en['input_dyadics']],H[0],count)
                x,_,_,_=block(x,H,count,False,start=1)
            assert first==en['first_step'] and statebounds(x)==en['blocks'][0]
            for n in range(1,len(en['blocks'])):
                with session.reserve('replay',800,'fixed entry '+en['case']+' block '+str(n+1)) as count:
                    x,_,_,_=block(x,H,count,False)
                assert statebounds(x)==en['blocks'][n]
            dest=cert['larger_region'] if en['destination']=='B' else cert['primary']
            radii=list(map(F,dest['radii']))
            assert inside(x,center,radii) and en['status']=='certified entry'
            results['entry'].append({'case':en['case'],'certified_entry':True,'blocks':len(en['blocks']),'output':statebounds(x)})
        results['status']='PASS'
        write('VERIFICATION.json',results)
        print('PASS: fixed residual, all 800 forcing bounds, both box certificates, independent hand derivatives, all five exact dyadic entry IVPs.')
        print('Cumulative counts',session.ledger['counts'])
if __name__=='__main__':main()
