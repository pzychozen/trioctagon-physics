from pathlib import Path
import zipfile,json,hashlib,io,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
B=Path(__file__).resolve().parent;R=B.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists(): assert p.read_bytes()==b,p
    else:p.write_bytes(b)
p=Path(r'C:\Users\Notandi\Downloads\SRG_CA04_CODEX_START_PACKET.zip')
record=[dict(path=str(p),sha256=sha(p.read_bytes()),size=p.stat().st_size)]
with zipfile.ZipFile(p) as z:
    manifest=json.loads(z.read('MANIFEST.json'))
    for e in manifest['files']:
        b=z.read(e['path']);assert len(b)==e['size_bytes'] and sha(b)==e['sha256']
    for n in z.namelist():
        assert '..' not in Path(n).parts and not Path(n).is_absolute()
        save(B/'inputs'/'packet'/n,z.read(n))
    idx=json.loads(z.read('CA04_INPUT_INDEX.json'))
    archive=z.read(idx['accepted_archive']['packet_path'])
    assert sha(archive)==idx['accepted_archive']['sha256']
    local=B.parent/'CA03_returning_drive_v0.1'/'CA03_GPT_REVIEW.zip'
    assert local.read_bytes()==archive
    record.append(dict(path=str(local),sha256=sha(archive),size=len(archive)))
    with zipfile.ZipFile(io.BytesIO(archive)) as ca:
        for e in idx['source_members']:
            b=ca.read(e['archive_member']);assert sha(b)==e['sha256'] and len(b)==e['size_bytes']
            save(B/'inputs'/'ca03'/e['archive_member'],b)
        for n in ca.namelist():
            if n.startswith('raw/') and n.endswith('_RETURN.npz'):
                save(B/'inputs'/'ca03'/n,ca.read(n))
        save(B/'reference_model.py',ca.read('model.py'))
    save(B/'CA04_INPUT_INDEX.json',z.read('CA04_INPUT_INDEX.json'))
for p in sorted((B/'inputs'/'ca03').rglob('*')):
    if p.is_file():
        original=B.parent/'CA03_returning_drive_v0.1'/p.relative_to(B/'inputs'/'ca03')
        assert original.read_bytes()==p.read_bytes()
        record.append(dict(path=str(original),sha256=sha(p.read_bytes()),size=p.stat().st_size))
save(B/'PRESERVATION_BEFORE.json',(json.dumps(record,indent=2)+'\n').encode())
for name,args in [('HEAD',['rev-parse','HEAD']),('STATUS',['status','--porcelain=v1','--untracked-files=all']),('INDEX',['diff','--cached','--name-status']),('TRACKED',['diff','--name-status'])]:
    save(B/'evidence'/('BEFORE_'+name+'.txt'),subprocess.check_output(['git',*args],cwd=R))
print('Verified packet and accepted archive; staged source-only copies.',len(record),'original identities')
print('INDEX KEYS',list(idx))
print('MODEL\n', (B/'reference_model.py').read_text())
print('CA03 ANALYSIS\n',(B/'inputs'/'ca03'/'CA03_RETURNING_DRIVE_ANALYSIS.md').read_text(encoding='utf-8')[:25500])
