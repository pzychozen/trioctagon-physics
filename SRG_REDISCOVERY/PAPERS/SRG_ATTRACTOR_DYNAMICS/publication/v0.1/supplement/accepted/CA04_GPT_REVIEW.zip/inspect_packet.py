"""Read the CA04 packet without executing any attached program."""
from pathlib import Path
import hashlib,json,sys,zipfile
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path(__file__).resolve().parent;REPO=BASE.parents[2]
for folder in [*reversed(REPO.parents),REPO,BASE.parent.parent,BASE.parent,BASE]:
    p=folder/'AGENTS.md'
    if p.exists():print('\nINSTRUCTIONS',p,'\n',p.read_text(encoding='utf-8'))
p=Path(r'C:\Users\Notandi\Downloads\SRG_CA04_CODEX_START_PACKET.zip')
print('PACKET SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
with zipfile.ZipFile(p) as z:
    print('MEMBERS',json.dumps(z.namelist(),indent=2))
    for name in z.namelist():
        if name.endswith(('SRG_CA04_CODEX_WORK_ORDER.md','CA04_INPUT_INDEX.json','CA04_EXPERIMENT_SPEC.json','SOURCE_ANCHORS.md','MANIFEST.json')):
            print('\nFILE',name,'\n',z.read(name).decode('utf-8-sig'))
