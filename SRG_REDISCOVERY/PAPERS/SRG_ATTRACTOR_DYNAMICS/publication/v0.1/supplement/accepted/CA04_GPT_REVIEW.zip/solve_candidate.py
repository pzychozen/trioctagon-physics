"""Bounded floating Newton; output is explicitly not a certificate."""
import math
import numpy as np
from fractions import Fraction as F
from execution import B,Session,read,write
from validated_map import block
def main():
    assert (B/'PREFLIGHT.json').exists()
    with Session('two-coordinate floating Newton candidate') as session:
        bracket=read('CA04_INPUT_INDEX.json')['candidate_seed']['half_angle_v_rational_bracket']
        x=np.array([(math.sqrt(3)-1)/2,float(sum(map(F,bracket))/2)])
        H=[2*math.exp(-f/20)*math.cos(f/10)+math.exp(-3*f/100)*math.sin(f/10)+1.5*math.exp(-7*f/100)+math.exp(-f/25) for f in range(800)]
        iterations=[]
        for j in range(12):
            with session.reserve('point',800,'Newton evaluation '+str(j)) as charge:
                y,der,stats,_=block(x,H,charge)
            residual=np.array(y)-x
            iterations.append({'input':x.tolist(),'output':y,'residual':residual.tolist(),'derivative':der})
            if np.max(np.abs(residual))<=2e-14:break
            x=x-np.linalg.solve(np.array(der)-np.eye(2),residual)
            assert np.isfinite(x).all() and -.9<x[0]<.9 and 0<x[1]<.4
        else:raise RuntimeError('Candidate budget exhausted')
        write('CANDIDATE.json',{'status':'NUMERICAL_CANDIDATE_ONLY','iterations':iterations,'center':[str(F(float(t))) for t in x],'display_center':x.tolist(),'display_phase':2*math.atan(x[1]),'residual_max':float(max(abs(residual))),'note':'Binary64 estimates; no proof until separate outward certificate.'})
        print('Candidate',x.tolist(),'phase',2*math.atan(x[1]),'evaluations',len(iterations),'residual',max(abs(residual)))
if __name__=='__main__':main()
