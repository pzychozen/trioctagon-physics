"""Candidate-independent strict proof tests, then separately gated entry."""
from interval_core import I,F,P,forcing
from execution import B,Session,read,write,seals
from certificate_math import residual,prove_box,inside,statebounds
from validated_map import block,cartesian_entry
def main():
    with Session('directed construction and optional entry') as session:
        center=list(map(F,read('CANDIDATE.json')['center']))
        H=forcing();session.scalar(800)
        write('FORCING_INTERVALS.json',{'bits':P,'values':[h.dump() for h in H],'exact_argument':'f/10','recipe':'interval_core.forcing'})
        res=residual(center,H,session,'construction')
        write('CENTER_RESIDUAL.json',res)
        e=list(map(F,res['e']));attempts=[];primary=None
        for radii in [('1/1000000','1/100000'),('1/10000000','1/1000000'),('1/100000','1/10000'),('1/10000','1/1000')]:
            cert=prove_box(center,list(map(F,radii)),(1,1),H,e,session,'construction','primary')
            attempts.append(cert);write('CONSTRUCTION_ATTEMPTS.json',attempts)
            print('Primary radii',radii,'q',float(F(cert['q'])),'pass',cert['passed'],flush=True)
            if cert['passed']:primary=cert;break
        assert primary is not None,'No primary certificate'
        certificate={'status':'CERTIFIED_LOCAL_ATTRACTION_AT_1_OVER_32','target':{'alpha':'1/32','dt':'1/10','N':800,'forcing_indices':[0,799],'clip':'4/5','epsilon':'1/100000','semantics':'exact-real'},'bits':P,'center':list(map(str,center)),'center_residual':{k:v for k,v in res.items() if k!='trace'},'primary':primary,'larger_region':None,'entry':[],'code_sha256':seals()}
        write('CERTIFICATE.json',certificate)
        # Optional broader region, attempted only after strict primary success.
        larger=None
        for radv in ['1/10','2/25','7/100']:
            for grid in [(1,1),(1,4),(2,16)]:
                if session.ledger['counts']['construction']+800*grid[0]*grid[1]+4000>76800:break
                try:
                    b=prove_box(center,[F(1,1000),F(radv)],grid,H,e,session,'construction','optional larger B')
                    attempts.append(b);write('CONSTRUCTION_ATTEMPTS.json',attempts)
                    print('B',radv,grid,'q',float(F(b['q'])),'pass',b['passed'],flush=True)
                    if b['passed']:larger=b;break
                except AssertionError as ex:
                    attempts.append({'label':'optional B domain overestimation','radii':['1/1000',radv],'subdivisions':grid,'error':str(ex)})
                    write('CONSTRUCTION_ATTEMPTS.json',attempts)
                    print('B enclosure failed:',str(ex)[:120],flush=True)
            if larger:break
        certificate['larger_region']=larger;write('CERTIFICATE.json',certificate)
        dest=larger or primary;radii=list(map(F,dest['radii']))
        idx=read('CA04_INPUT_INDEX.json')
        for inp in idx['optional_stored_checkpoint_initial_value_problems']:
            s=[I(F(t['exact_dyadic'])) for t in inp['components_xyz']]
            with session.reserve('construction',800,'entry '+inp['case']+' block 1') as count:
                x,first=cartesian_entry(s,H[0],count)
                x,_,stats,_=block(x,H,count,False,start=1)
            en={'case':inp['case'],'input_dyadics':[t['exact_dyadic'] for t in inp['components_xyz']],'first_step':first,'blocks':[statebounds(x)],'destination':'B' if larger else 'X','status':'not established within this investigation'}
            if inside(x,center,radii):en['status']='certified entry'
            else:
                for n in range(2,5):
                    with session.reserve('construction',800,'entry '+inp['case']+' block '+str(n)) as count:
                        x,_,stats,_=block(x,H,count,False)
                    en['blocks'].append(statebounds(x))
                    if inside(x,center,radii):en['status']='certified entry';break
            certificate['entry'].append(en);write('CERTIFICATE.json',certificate)
            print(inp['case'],en['status'],'blocks',len(en['blocks']),flush=True)
        print('CONSTRUCTION COMPLETE',session.ledger['counts'],flush=True)
if __name__=='__main__':main()
