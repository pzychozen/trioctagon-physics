"""Durable cumulative accounting. A crash leaves reservations charged."""
from pathlib import Path
import json,time,hashlib,sys,platform
B=Path(__file__).resolve().parent
LIMITS={'point':19200,'construction':76800,'replay':76800,'preflight':12}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,data):
    p=B/name;p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8');tmp.replace(p)
def read(name):return json.loads((B/name).read_text(encoding='utf-8'))
def seals():
    return {p.name:digest(p) for p in sorted(B.glob('*.py'))}
def init():
    if not (B/'PRE_RUN_SEAL.json').exists():
        write('PRE_RUN_SEAL.json',{'files':{n:digest(B/n) for n in ['CA04_PLAN.md','PRE_RUN_ANALYSIS.md','reference_model.py','CA04_INPUT_INDEX.json']},'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    for n,h in read('PRE_RUN_SEAL.json')['files'].items():assert digest(B/n)==h
    if not (B/'EXECUTION_LEDGER.json').exists():
        write('EXECUTION_LEDGER.json',{'limits':LIMITS,'counts':{k:0 for k in LIMITS},'derivative_steps':{k:0 for k in LIMITS},'seconds':{'construction':0.,'replay':0.},'sessions':[],'traversals':[],'scalar_forcing_values':{'construction':0,'replay':0},'unstructured_rollouts':0,'inherited_prefix_steps':0,'native_kernel_steps':0})
class Session:
    def __init__(self,label,mode='construction'):
        init();self.mode=mode;self.ledger=read('EXECUTION_LEDGER.json')
        assert not any(t['status']=='RUNNING' for t in self.ledger['sessions']),'Prior crash needs explicit accounting'
        self.start=time.perf_counter()
        self.item={'label':label,'mode':mode,'status':'RUNNING','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'code_sha256':seals(),'python':sys.version,'executable':sys.executable,'platform':platform.platform()}
        self.ledger['sessions'].append(self.item);self.save()
    def save(self):write('EXECUTION_LEDGER.json',self.ledger)
    def checktime(self):
        bound=900 if self.mode=='replay' else 1800
        assert self.ledger['seconds'][self.mode]+time.perf_counter()-self.start<bound,'Wall limit'
    def __enter__(self):return self
    def __exit__(self,typ,exc,tb):
        dt=time.perf_counter()-self.start
        self.item.update(status='FAILED' if typ else 'COMPLETE',seconds=dt,error=str(exc) if exc else None)
        self.ledger['seconds'][self.mode]+=dt;self.save()
    def reserve(self,kind,n,label):return Charge(self,kind,n,label)
    def scalar(self,n):self.ledger['scalar_forcing_values'][self.mode]+=n;self.save();self.checktime()
class Charge:
    def __init__(self,s,kind,n,label):
        s.checktime();self.s=s;self.kind=kind;self.used=0;self.deriv=0;self.n=n
        assert s.ledger['counts'][kind]+n<=LIMITS[kind],'Step budget'
        s.ledger['counts'][kind]+=n
        self.item={'label':label,'kind':kind,'reserved':n,'actual':None,'status':'RESERVED'}
        s.ledger['traversals'].append(self.item);s.save()
    def __enter__(self):return self
    def step(self,derivative=False):
        assert self.used<self.n
        self.used+=1;self.deriv+=int(derivative)
        if self.used%50==0:self.s.checktime()
    def __exit__(self,typ,exc,tb):
        self.s.ledger['counts'][self.kind]-=self.n-self.used
        self.s.ledger['derivative_steps'][self.kind]+=self.deriv
        self.item.update(actual=self.used,derivative_steps=self.deriv,status='FAILED' if typ else 'COMPLETE',error=str(exc) if exc else None)
        self.s.save()
