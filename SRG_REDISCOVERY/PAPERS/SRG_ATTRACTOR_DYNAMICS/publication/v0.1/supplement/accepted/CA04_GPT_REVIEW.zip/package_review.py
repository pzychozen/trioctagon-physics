"""Read-only preservation checks and review packaging; no scientific calls."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
from execution import B,read,write,digest
sys.stdout.reconfigure(encoding='utf-8')
R=B.parents[2]
originals=read('PRESERVATION_BEFORE.json');after=[]
for e in originals:
    p=Path(e['path']);h=digest(p)
    assert h==e['sha256'] and p.stat().st_size==e['size'],p
    after.append({**e,'unchanged':True})
git={}
for name,args in [('HEAD',['rev-parse','HEAD']),('STATUS',['status','--porcelain=v1','--untracked-files=all']),('INDEX',['diff','--cached','--name-status']),('TRACKED',['diff','--name-status'])]:
    got=subprocess.run(['git',*args],cwd=R,capture_output=True,check=True)
    (B/'evidence'/('AFTER_'+name+'.txt')).write_bytes(got.stdout)
    (B/'evidence'/('AFTER_'+name+'_STDERR.txt')).write_bytes(got.stderr)
    old=(B/'evidence'/('BEFORE_'+name+'.txt')).read_bytes()
    if name=='STATUS':
        own=B.relative_to(R).as_posix()+'/'
        def outside(b):return [x for x in b.decode().splitlines() if own not in x]
        git['status_outside_CA04_equal']=outside(old)==outside(got.stdout)
        git['outside_status_lines']=len(outside(got.stdout))
        git['status_warning']=got.stderr.decode()
    else:git[name.lower()+'_unchanged']=old==got.stdout;assert old==got.stdout,name
git['head']=(B/'evidence'/'AFTER_HEAD.txt').read_text().strip()
git['index_empty']=not (B/'evidence'/'AFTER_INDEX.txt').read_bytes()
git['tracked_diff_empty']=not (B/'evidence'/'AFTER_TRACKED.txt').read_bytes()
write('PRESERVATION_AFTER.json',{'originals':after,'git':git,'write_scope':'CA04_finite_coupling_certificate_v0.1 only','no_actions':['dependency installation','kernel update','accepted-research edit','staging','commit','push','publication'],'scope_note':'Consumed-original hashes and tracked/index checks are exact. Git warned about existing overlong untracked paths elsewhere; this is not a claim of complete inventory of those trees.'})
# Verify source seals against the code that actually produced and replayed evidence.
for seal in [read('PRE_RUN_SEAL.json')['files'],read('CERTIFICATE.json')['code_sha256']]:
    for n,h in seal.items():assert digest(B/n)==h,n
for session in read('EXECUTION_LEDGER.json')['sessions']:
    assert session['status']=='COMPLETE'
    # Non-scientific presentation/report scripts may be created after execution.
    for n,h in session['code_sha256'].items():assert digest(B/n)==h,n
write('FINAL_CODE_SEAL.json',{'files':{p.name:digest(p) for p in sorted(B.glob('*.py'))},'proof_inputs':read('PRE_RUN_SEAL.json')['files'],'scientific_source_match':True})
# Packet manifest and accepted archive verification, without executing code.
packet=B/'inputs'/'packet'
for e in json.loads((packet/'MANIFEST.json').read_text())['files']:
    p=packet/e['path'];assert p.stat().st_size==e['size_bytes'] and digest(p)==e['sha256']
with zipfile.ZipFile(packet/'reference'/'CA03_GPT_REVIEW.zip') as z:
    assert z.testzip() is None
    m=json.loads(z.read('MANIFEST.json'))
    # Original manifest schema was already identity-verified; preserve it as supplied.
    assert len(z.namelist())==len(set(z.namelist()))
assert len((B/'READ_ME_FIRST.md').read_text().split())<=700
assert read('VERIFICATION.json')['status']=='PASS'
assert read('EXECUTION_LEDGER.json')['counts']=={'point':3200,'construction':6400,'replay':8000,'preflight':12}
excluded={'MANIFEST.json','CA04_GPT_REVIEW.zip','REVIEW_ZIP_RECEIPT.json'}
files=[p for p in sorted(B.rglob('*')) if p.is_file() and p.name not in excluded and 'render_cache' not in p.relative_to(B).parts and '__pycache__' not in p.relative_to(B).parts and p.suffix!='.tmp']
newbytes=sum(p.stat().st_size for p in files if 'inputs' not in p.relative_to(B).parts)
assert newbytes<250_000_000
write('MANIFEST.json',{'scope':'CA04 completed review; all payloads except this manifest','new_result_bytes_excluding_unchanged_inputs':newbytes,'files':[{'path':p.relative_to(B).as_posix(),'size_bytes':p.stat().st_size,'sha256':digest(p)} for p in files]})
zpath=B/'CA04_GPT_REVIEW.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[B/'MANIFEST.json']:z.write(p,p.relative_to(B).as_posix())
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    names=z.namelist();assert len(names)==len(set(names))
    manifest=json.loads(z.read('MANIFEST.json'))
    assert set(names)=={'MANIFEST.json'}|{e['path'] for e in manifest['files']}
    for e in manifest['files']:
        b=z.read(e['path'])
        assert len(b)==e['size_bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
assert newbytes+zpath.stat().st_size<250_000_000
receipt={'archive':str(zpath),'bytes':zpath.stat().st_size,'sha256':digest(zpath),'manifested_payloads':len(files),'archive_members':len(files)+1,'crc':'PASS','manifest_members_sizes_hashes':'PASS','originals_unchanged':len(after),'git':{k:v for k,v in git.items() if k!='status_warning'},'new_payload_bytes_excluding_unchanged_inputs':newbytes,'new_payload_plus_zip_bytes':newbytes+zpath.stat().st_size}
write('REVIEW_ZIP_RECEIPT.json',receipt)
print(json.dumps(receipt,indent=2))
