from pathlib import Path
import zipfile,json,hashlib,sys,importlib.util,subprocess
sys.stdout.reconfigure(encoding='utf-8')
B=Path(__file__).resolve().parent
p=Path(r'C:\Users\Notandi\Downloads\SRG_CA04_CODEX_START_PACKET.zip')
with zipfile.ZipFile(p) as z:
    m=json.loads(z.read('MANIFEST.json'))
    print('MANIFEST',json.dumps(m)[:3500])
    for n in ['CA04_TASK_SPEC.json','SOURCE_ANCHORS.md']:
        print(n,z.read(n).decode())
    s=z.read('SRG_CA04_CODEX_WORK_ORDER.md').decode()
    print(s[:s.index('## 4.')])
    print('REVIEW',z.read('reference/CA03_GPT_SCIENTIFIC_REVIEW.md').decode())
print('BACKENDS', {n:bool(importlib.util.find_spec(n)) for n in ['flint','gmpy2','mpmath','sympy','numpy']})
