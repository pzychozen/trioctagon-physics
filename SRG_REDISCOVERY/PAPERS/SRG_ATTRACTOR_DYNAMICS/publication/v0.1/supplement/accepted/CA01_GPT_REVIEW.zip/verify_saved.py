"""Independent passive consistency checks; never calls the rollout or field code."""
from pathlib import Path
import ast, hashlib, json, sys
import numpy as np
BASE=Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding='utf-8')
R=json.loads((BASE/'RESULTS.json').read_text())
V={'fresh_field_evaluations':0,'fresh_state_updates':0,'saved_F3_detector_records_checked':0,
   'saved_F4_transition_records_checked':0,'saved_F4_preflight_records_checked':0,'checks':{},'source_locators':{}}
checks=V['checks']
def check(name,condition):
    checks[name]=bool(condition)
    if not condition: raise AssertionError(name)
check('budgets',R['counts']=={'F3_field_detector_evaluations':16,'F4_isolated_steps':12,'F4_trajectories':1,'F4_rollout_updates':200,'native_kernel_updates':0,'SIM01_updates':0})
for row in R['F3']:
    with np.load(BASE/row['raw'],allow_pickle=False) as d:
        X,Y,M,mask,centroid=(d[k] for k in ['X','Y','magnitude','mask','centroid'])
        check(row['id']+'_shape',M.shape==X.shape==Y.shape==mask.shape==(row['n'],row['n']))
        check(row['id']+'_finite_field',np.isfinite(M).all())
        threshold=float(np.percentile(M,5,method='linear'))
        if row['kind']=='related_source_argmin':
            selected=np.flatnonzero(mask)
            check(row['id']+'_argmin',len(selected)==1 and selected[0]==np.argmin(M))
        else:
            check(row['id']+'_saved_mask_definition',np.array_equal(mask,M<threshold))
        check(row['id']+'_selected_count',int(mask.sum())==row['selected_count'])
        if mask.any():
            savedmean=np.array([X[mask].mean(),Y[mask].mean()],dtype=float)
            check(row['id']+'_saved_mean',np.array_equal(savedmean,centroid) and np.array_equal(centroid,row['centroid']))
        else: check(row['id']+'_empty_is_undefined',np.isnan(centroid).all() and row['centroid'] is None)
        V['saved_F3_detector_records_checked']+=1

# Independently evaluate the radial closed form of P on saved inputs only.
def P_closed(u):
    x,y,z=np.asarray(u).T; rho=np.hypot(x,y); L=np.sqrt(x*x+y*y+z*z)
    if np.any(rho==0): raise ValueError('Axis branch checked separately')
    return np.column_stack(((1+.5*z/L)*x/rho,(1+.5*z/L)*y/rho,.5*rho/L))
residuals=[];euler=[];torque=[]
for row in R['F4_preflight']:
    s=np.array(row['s']);u=np.array(row['u']);qh=np.array(row['qhat']);q=np.array(row['q']);dest=np.array(row['dest'])
    x,y,z=s
    q_ind=row['alpha']*row['H']*np.array([y*y-x*z,z*z-x*y,x*x-y*z])
    torque.append(float(np.max(abs(q-q_ind))))
    check('preflight_%s_clip'%row['id'],np.max(abs(qh-q*min(1.,.8/(np.linalg.norm(q)+1e-5))))<1e-12)
    check('preflight_%s_Euler'%row['id'],np.max(abs(u-s-.1*qh))<1e-12)
    euler.append(abs(float(u@u-s@s-.01*qh@qh)))
    if np.hypot(u[0],u[1])>0:
        residuals.append(float(np.max(abs(P_closed(u[None,:])[0]-dest))))
    else:
        expected=np.array([.5 if u[2]<0 else 1.5,0.,0.])
        residuals.append(float(np.max(abs(expected-dest))))
    V['saved_F4_preflight_records_checked']+=1
with np.load(BASE/'raw/F4_remap_only.npz',allow_pickle=False) as d:
    states=d['states'];u=d['u'];dest=d['dest']
    check('state_predecessors',np.array_equal(states[:-1],d['s']))
    check('state_successors',np.array_equal(states[1:],dest))
    check('zero_torque',np.array_equal(d['q'],np.zeros((200,3))) and np.array_equal(d['qhat'],np.zeros((200,3))))
    check('zero_alpha',np.array_equal(d['alpha'],np.zeros(200)))
    check('time_schedule',np.array_equal(d['t'],np.arange(200)*.1))
    check('index_schedule',np.array_equal(d['state_index'],np.arange(201)))
    check('finite_states',np.isfinite(states).all())
    residuals.append(float(np.max(abs(P_closed(u)-dest))))
    euler.append(float(np.max(abs(np.sum(u*u,axis=1)-np.sum(d['s']**2,axis=1)-.01*np.sum(d['qhat']**2,axis=1)))))
    V['saved_F4_transition_records_checked']=len(dest)
    rs=R['F4_control']['rho_star'];zs=R['F4_control']['z_star']
    check('endpoint_on_claimed_circle',abs(np.hypot(*states[-1,:2])-rs)<1e-12 and abs(states[-1,2]-zs)<1e-12)
V['max_closed_form_P_residual']=max(residuals);V['max_Euler_identity_residual']=max(euler);V['max_component_torque_residual']=max(torque)
check('floating_residuals',max(residuals+euler+torque)<1e-12)

reg=json.loads((BASE/'evidence/consumed_sources.json').read_text())
V['source_copy_count']=len(reg)
for orig,row in reg.items():
    b=(BASE/row['copy']).read_bytes();check('source_copy_'+Path(row['copy']).name,len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'])
    if orig.endswith(('geometry.py','verify_host_registration.py','attractor_trajector_over_time.py')):
        tree=ast.parse(b.decode('utf-8-sig'))
        V['source_locators'][orig]={n.name:[n.lineno,n.end_lineno] for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
summary=(BASE/'READ_ME_FIRST.md').read_text(encoding='utf-8')
V['summary_word_count']=len(summary.split());check('summary_length',400<=V['summary_word_count']<=700)
for name in ['01_F3_mask_and_centroid.png','02_F4_remap_only.png','03_passive_native_comparison.png','04_reference_mesh_and_openings.png','05_F3_passive_comparison.png']:
    check('image_'+name,(BASE/'plots'/name).read_bytes().startswith(b'\x89PNG\r\n\x1a\n'))
V['status']='PASS_SAVED_DATA_AND_SOURCE_COPY_CONSISTENCY'
(BASE/'VERIFICATION.json').write_text(json.dumps(V,indent=2)+'\n')
print(json.dumps({k:v for k,v in V.items() if k!='checks'},indent=2))
