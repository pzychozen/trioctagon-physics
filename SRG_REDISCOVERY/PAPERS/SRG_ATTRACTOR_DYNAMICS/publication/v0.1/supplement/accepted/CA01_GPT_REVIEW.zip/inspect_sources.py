from source_access import *
import subprocess, shutil
sys.stdout.reconfigure(encoding='utf-8')
mode=sys.argv[1]
if mode=='pdf':
    pdf=BASE/'received/inputs/SGR_simulations.pdf'
    out=BASE/'evidence/pdf_pages'; out.mkdir(exist_ok=True)
    subprocess.run([shutil.which('pdftoppm'),'-f','5','-l','8','-r','125','-png',str(pdf),str(out/'page')],check=True)
    show('SRG_REDISCOVERY/R0_SOURCE_RECOVERY/pdf_text/P16_SGR_simulations.txt',1,390)
elif mode=='indexes':
    rows=json.loads(consume('SRG_REDISCOVERY/R0_SOURCE_RECOVERY/script_inventory.json'))
    print(json.dumps(rows,indent=2)[:24000])
    show('SRG_REDISCOVERY/SIM01_SURVIVING_RECURSIVE_MOTION/publication/v0.1/SIM01_REPORT.md',1,160)
    show('SRG_REDISCOVERY/SIM01_SURVIVING_RECURSIVE_MOTION/publication/v0.1/ACCESS_AND_EVIDENCE_MAP.md')
    consume('SRG_REDISCOVERY/SIM01_SURVIVING_RECURSIVE_MOTION/publication/v0.1/review/SIM01_GPT_SCIENTIFIC_REVIEW.md')
elif mode=='geometry':
    prefix='papers/CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE/publication/v0.3/'
    show(prefix+'reports/Z_CRYSTAL_REVERSAL_AND_UPPER_LOWER_CORRESPONDENCE_ANALYSIS_v0.1.md',1,200)
    show(prefix+'evidence/GPT_POST_AUDIT_FINALIZATION_CLOSURE_CENTRAL_GEOMETRY_Z_CHIRAL_RESPONSE_v0.3.md')
    for p in ['CRYSTAL_HOST_REGISTRATION_REPORT.md','family_analysis/SIGNED_FAMILY_IDENTITIES.md','family_analysis/ZERO_STATE_ANALYSIS.md','family_analysis/TWISTED_HEX_FAMILY_ANALYSIS.md']:
        show('research/twisted_hex_crystal_registration_v0.1/'+p)
