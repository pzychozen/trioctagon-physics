"""CA01 bounded detached checks. Never imports a historical or kernel module.

Refuses to overwrite an existing run. Read ALGEBRA_AND_CHECK_PLAN.md first.
"""
from pathlib import Path
import ast, hashlib, json, os, sys
import numpy as np
import sympy as sp
from source_access import BASE, REPO, consume

sys.stdout.reconfigure(encoding='utf-8')
OUT=BASE/'raw'
if OUT.exists(): raise SystemExit('raw already exists; refusing an automatic rerun')
OUT.mkdir()
for name in ['TMP','TEMP','MPLCONFIGDIR']:
    dest=BASE/'cache'/name; dest.mkdir(parents=True,exist_ok=True); os.environ[name]=str(dest)
TOL=1e-12
results={'scope':'printed F3 diagnostics; related F3 code; printed F4 algebra and remap-only control',
         'environment':{'python':sys.version,'executable':sys.executable,'numpy':np.__version__,'sympy':sp.__version__},
         'tolerances':{'binary64_absolute':TOL,'binary32_magnitude_absolute':2e-6},
         'counts':{'F3_field_detector_evaluations':0,'F4_isolated_steps':0,'F4_trajectories':0,'F4_rollout_updates':0,'native_kernel_updates':0,'SIM01_updates':0},
         'F3':[],'F4_preflight':[],'exact':{},'errors':[]}
def dump(): (BASE/'RESULTS.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
def finite(*arrays):
    if not all(np.isfinite(a).all() for a in arrays): raise FloatingPointError('nonfinite branch stopped')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

# Extract only three inspected side-effect-free helpers, without module imports/tail.
f3_path='SRG_REDISCOVERY/OLD_MATERIAL/Simulations_Trash/Early_simulations/attractor_trajector_over_time.py'
tree=ast.parse(consume(f3_path).decode('utf-8-sig'))
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['H','tgmo_field','rpco_clip']]
assert len(nodes)==3
detached=ast.Module(body=nodes,type_ignores=[])
(BASE/'evidence/detached_F3_helpers.py.txt').write_text(ast.unparse(detached)+'\n')
env={'np':np}
exec(compile(detached,'<inspected F3 helper extraction>','exec'),env)
results['F3_helper_extraction']={'functions':[n.name for n in nodes],'unchanged_AST':True,'module_tail_executed':False}

# Exact reductions supplement the written proofs; no state updates.
x,y,z,a,h,dt,k=sp.symbols('x y z a h dt k',real=True)
s=sp.Matrix([x,y,z]); cross=s.cross(sp.Matrix([z,x,y])); q=a*h*k*cross
results['exact']['cross_components']=[str(v) for v in cross]
results['exact']['orthogonal']=sp.expand(s.dot(q))==0
results['exact']['Euler_norm_identity']=sp.expand((s+dt*q).dot(s+dt*q)-s.dot(s)-dt**2*q.dot(q))==0
c=(sp.sqrt(3)-1)/2
results['exact']['fixed_angle_polynomial']=sp.simplify(c*c+c-sp.Rational(1,2))==0
results['exact']['fixed_multiplier']=str(sp.simplify(-(sp.Rational(1,4)+c/2)/(sp.Rational(5,4)+c)))
th,hh,rr=sp.symbols('theta H radius',real=True)
results['exact']['F3_magnitude_squared']=sp.trigsimp((-sp.sin(th)*hh/(1+rr**2))**2+(sp.cos(th)*hh/(1+rr**2))**2-hh**2/(1+rr**2)**2)==0
assert all(results['exact'][n] for n in ['orthogonal','Euler_norm_identity','fixed_angle_polynomial','F3_magnitude_squared'])

# Every row below is one fresh grid + detector evaluation, including radial controls.
cases=[
 dict(id='F3_00',kind='related_source_argmin',t=0.,n=100),
 dict(id='F3_01',kind='printed',t=0.,n=100),
 dict(id='F3_02',kind='printed',t=2.5,n=100),
 dict(id='F3_03',kind='printed',t=9.9,n=100),
 dict(id='F3_04',kind='printed',t=0.,n=100,H=0.),
 dict(id='F3_05',kind='printed',t=0.,n=100,H=100.),
 dict(id='F3_06',kind='epsilon_clip_centroid_control',t=0.,n=100,H=100.),
 dict(id='F3_07',kind='printed',t=0.,n=100,H=45.),
 dict(id='F3_08',kind='printed',t=0.,n=100,precision='float32'),
 dict(id='F3_09',kind='printed',t=0.,n=101),
 dict(id='F3_10',kind='printed',t=0.,n=100,paired=True),
 dict(id='F3_11',kind='radial_formula',t=0.,n=100,paired=True),
 dict(id='F3_12',kind='radial_formula',t=0.,n=100,paired=True,H=1.),
 dict(id='F3_13',kind='printed',t=0.,n=100,H=1.),
 dict(id='F3_14',kind='printed',t=0.,n=100,H=-1.),
 dict(id='F3_15',kind='printed',t=0.,n=100,H=1e-12),
]
try:
  for case in cases:
    assert results['counts']['F3_field_detector_evaluations']<16 and case['n']<=201
    dtype=np.dtype(case.get('precision','float64')).type
    n=case['n']; t=case['t']; H=case.get('H',float(env['H'](t)))
    coords=np.linspace(-5,5,n,dtype=dtype)
    if case.get('paired'):
        pos=np.linspace(5/(n-1),5,n//2,dtype=dtype); coords=np.concatenate((-pos[::-1],pos))
    X,Y=np.meshgrid(coords,coords)
    results['counts']['F3_field_detector_evaluations']+=1
    if case['kind']=='related_source_argmin':
        U,V=env['tgmo_field'](X,Y,t); U,V=env['rpco_clip'](U,V)
        M=np.sqrt(U**2+V**2)
    elif case['kind']=='radial_formula':
        U=np.zeros_like(X); V=np.zeros_like(Y)
        M=np.minimum(dtype(abs(H))/(dtype(1)+X**2+Y**2),dtype(1))
    else:
        radius=np.sqrt(X**2+Y**2)
        theta=np.arctan2(Y,X)+dtype(.05)*np.sin(dtype(.1)*dtype(t))
        U=-np.sin(theta)*dtype(H)/(dtype(1)+radius**2)
        V=np.cos(theta)*dtype(H)/(dtype(1)+radius**2)
        Mpre=np.sqrt(U**2+V**2)
        if case['kind']=='epsilon_clip_centroid_control':
            fac=np.minimum(dtype(1),dtype(1)/(Mpre+dtype(1e-5)))
            U,V=U*fac,V*fac
        else:
            fac=np.maximum(dtype(1),Mpre/dtype(1)); U,V=U/fac,V/fac
        M=np.sqrt(U**2+V**2)
    finite(X,Y,U,V,M)
    expected=np.minimum(abs(H)/(1+X.astype(float)**2+Y.astype(float)**2),1.)
    pct=float(np.percentile(M,5,method='linear'))
    if case['kind']=='related_source_argmin':
        mask=np.zeros(M.shape,dtype=bool); mask.flat[np.argmin(M)]=True
    else: mask=M<pct
    count=int(mask.sum())
    centroid=np.array([X[mask].mean(),Y[mask].mean()],dtype=float) if count else np.array([np.nan,np.nan])
    # Ideal mathematical printed flatness is separately identified: floating
    # renormalization may produce unequal near-one values and a nonempty mask.
    ideal_flat=(H==0 or abs(H)>=51.)
    argmin_idx=np.unravel_index(np.argmin(M),M.shape)
    row={**case,'H':H,'H_basis':'declared scalar diagnostic' if 'H' in case else 'related source coefficients; PDF coefficients not independently recovered',
         'dtype':str(M.dtype),'percentile_method':'linear','comparison':'strict <' if case['kind']!='related_source_argmin' else 'flattened first argmin',
         'threshold':pct,'selected_count':count,'centroid':centroid.tolist() if count else None,
         'empty':count==0,'ideal_printed_flat_field':ideal_flat,'ideal_printed_centroid_defined':not ideal_flat,
         'selected_radius_min':float(np.hypot(X[mask],Y[mask]).min()) if count else None,
         'inversion_mask_mismatch':int(np.count_nonzero(mask!=mask[::-1,::-1])),
         'inversion_grid_error':float(np.max(np.abs(coords+coords[::-1]))),
         'argmin_coordinate':[float(X[argmin_idx]),float(Y[argmin_idx])],
         'exact_equal_threshold_count':int(np.count_nonzero(M==pct)),
         'magnitude_min':float(M.min()),'magnitude_max':float(M.max()),
         'printed_radial_magnitude_residual':float(np.max(np.abs(M-expected))),
         'raw':f'raw/{case["id"]}.npz'}
    if case['kind'] not in ['related_source_argmin','epsilon_clip_centroid_control']:
        assert row['printed_radial_magnitude_residual']<(2e-6 if dtype==np.float32 else TOL)
    if case['kind']=='radial_formula': assert row['inversion_mask_mismatch']==0
    np.savez_compressed(OUT/(case['id']+'.npz'),X=X,Y=Y,U=U,V=V,magnitude=M,mask=mask,centroid=centroid,
                        H=np.array(H),t=np.array(t),threshold=np.array(pct))
    results['F3'].append(row); dump()

  def P(v):
    x,y,z=v; theta=np.arctan2(np.sqrt(x*x+y*y),z); phi=np.arctan2(y,x)
    return np.array([(1+.5*np.cos(theta))*np.cos(phi),(1+.5*np.cos(theta))*np.sin(phi),.5*np.sin(theta)])
  def step(s,t,alpha):
    H=float(env['H'](t))
    q=alpha*H*np.cross(s,np.roll(s,1)); qnorm=float(np.linalg.norm(q))
    factor=min(1.,.8/(qnorm+1e-5)); qhat=q*factor
    u=s+.1*qhat; dest=P(u)
    finite(s,q,qhat,u,dest)
    return dict(s=s.copy(),t=float(t),alpha=float(alpha),H=H,q=q,qhat=qhat,u=u,dest=dest,
                clipped=bool(factor<1.),factor=factor)
  def serial(d): return {k:v.tolist() if isinstance(v,np.ndarray) else v for k,v in d.items()}
  cval=float(c); rho_star=1+.5*cval; z_star=.5*np.sqrt(1-cval*cval)
  fixtures=[([1,0,0],0,0),([1,0,.5],0,0),([2,0,0],0,0),([0,0,1],0,0),([0,0,-1],0,0),
            ([0,0,0],0,0),([rho_star,0,z_star],0,0),([1,1,-1],0,0),
            ([1,.2,.3],0,1),([1,.2,.3],9.9,1),([1,1,1],0,1),([1,.2,.3],0,-1)]
  for i,(state,t,alpha) in enumerate(fixtures):
    assert results['counts']['F4_isolated_steps']<32
    results['counts']['F4_isolated_steps']+=1
    v=step(np.array(state,dtype=float),t,alpha)
    residual=float(v['u']@v['u']-v['s']@v['s']-.01*(v['qhat']@v['qhat']))
    dot=float(v['s']@v['qhat']); p=v['dest']; surface=float((np.hypot(p[0],p[1])-1)**2+p[2]**2-.25)
    assert abs(residual)<TOL and abs(dot)<TOL and abs(surface)<TOL and p[2]>=-TOL
    results['F4_preflight'].append({'id':i,**serial(v),'Euler_residual':residual,'dot':dot,'surface_residual':surface})
  assert not np.allclose(results['F4_preflight'][0]['dest'],results['F4_preflight'][1]['dest'],atol=TOL,rtol=0)
  assert np.array_equal(results['F4_preflight'][0]['dest'],results['F4_preflight'][2]['dest'])
  dump()

  # Sole fresh trajectory. Alpha=0 deliberately; no historical baseline is asserted.
  records=[]; state=np.array([1.,0.,0.]); states=[state.copy()]
  results['counts']['F4_trajectories']+=1
  for n in range(200):
    assert results['counts']['F4_rollout_updates']<1000
    v=step(state,n*.1,0.); records.append(v); state=v['dest']; states.append(state.copy())
    results['counts']['F4_rollout_updates']+=1
  arr=np.array(states)
  raw={key:np.array([v[key] for v in records]) for key in records[0]}
  raw['states']=arr; raw['state_index']=np.arange(201); raw['display_time']=np.arange(201)*.1
  np.savez_compressed(OUT/'F4_remap_only.npz',**raw)
  dist=np.hypot(np.hypot(arr[:,0],arr[:,1])-rho_star,arr[:,2]-z_star)
  results['F4_control']={'initial_state':[1,0,0],'alpha':0.,'updates':200,'extension_updates':0,
      'state_storage':'201 rows: initial plus each successor; update n uses forcing time .1n',
      'historical_replay':False,'nearby_starts':0,'rho_star':rho_star,'z_star':z_star,
      'fixed_theta':float(np.arccos(cval)),'meridional_multiplier':float(sp.sqrt(3)-2),
      'final_state':arr[-1].tolist(),'distance_to_circle_at_0_1_2_5_10_20_200':{str(i):float(dist[i]) for i in [0,1,2,5,10,20,200]},
      'max_Euler_residual':float(max(abs(v['u']@v['u']-v['s']@v['s']-.01*v['qhat']@v['qhat']) for v in records)),
      'max_surface_residual_after_remap':float(np.max(np.abs((np.hypot(arr[1:,0],arr[1:,1])-1)**2+arr[1:,2]**2-.25))),
      'raw':'raw/F4_remap_only.npz','raw_sha256':sha(OUT/'F4_remap_only.npz')}
  results['status']='CHECKS_COMPLETED_WITH_SOURCE_GAPS_RETAINED'
  dump()
except Exception as exc:
    results['status']='STOPPED'; results['errors'].append(repr(exc)); dump(); raise
print(json.dumps({'counts':results['counts'],'F3':[{k:r[k] for k in ['id','selected_count','centroid','inversion_mask_mismatch','magnitude_min','magnitude_max']} for r in results['F3']], 'F4':results.get('F4_control'),'status':results['status']},indent=2))
