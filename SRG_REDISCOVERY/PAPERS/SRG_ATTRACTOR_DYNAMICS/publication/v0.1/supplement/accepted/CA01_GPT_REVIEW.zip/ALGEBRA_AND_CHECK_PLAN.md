# CA01 algebra and bounded check specification (before execution)

21 October 2026. Sources have been inspected as text and PDF pages 5-8 rendered and read. No historical program or native kernel has been run.

## Source gate

The PDF is the primary definition, not proof of its captions. Its F3 percentile producer and F4 point producer/data were not recovered in the bounded indexed search. The surviving `attractor_trajector_over_time.py` matches F3's field, grid and dt, but has epsilon clipping and an argmin detector. It cannot produce the PDF's central centroid plot as written. Its H coefficients may be used only as explicitly labeled related-source controls for the printed detector.

F4 alpha, initial state, roll implementation and exact executed clock are missing. No driven baseline or nearby-start rollout will be invented. Algebra below concerns the printed definition, with the conventional positive roll (x,y,z) -> (z,x,y) when its components are needed. The forward-limit result explicitly assumes t_n=0.1n and any fixed finite real alpha; it is conditional on that clock, not a recovery of an execution history.

## F3 written deductions

Before clipping, M=|H|/(1+X^2+Y^2), by sin^2(theta)+cos^2(theta)=1. The printed radial clip gives min(M,1). For H != 0 the minimum is at maximal radius, at the square's corners. Exact inversion-symmetric grid points have equal magnitudes; a strict percentile threshold therefore includes or excludes each symmetric pair together. Every nonempty selected mask has centroid exactly zero. The origin is a maximum-magnitude location before clipping; it is not a selected low-magnitude location. On an even 100 grid it is not a grid point at all.

H=0 and a fully clipped constant field have empty masks under strict '<'; their centroids are undefined. Ties can change counts. Floating evaluation can split exact ties, so a threshold near a tied shell can create finite coordinate displacement of the centroid, not merely a tiny roundoff-sized coordinate error. The old wandered path cannot be inferred without producer/data.

The code's epsilon clip gives m -> m min(1,1/(m+1e-5)). For m>1-1e-5 this is m/(m+1e-5), strictly increasing, not a true plateau. The argmin detector selects one corner for H != 0. Ties use NumPy's first flattened index. At H=0 it returns the first grid point although all points tie. None of these detectors moves a carried point.

## F4 written deductions

Let rho=hypot(x,y), L=||s||, R=1, r=1/2. Away from rho=0,

P(s)=((1+z/(2L))x/rho, (1+z/(2L))y/rho, rho/(2L)).

The formula discards positive radial scale and preserves azimuth. It obeys (rho'-1)^2+z'^2=1/4, z'>0. Its image off-axis is the open upper half of this torus; its closure includes both equatorial circles. Exact axial inputs have undefined azimuth. A declared NumPy atan2(0,0)=0 branch supplies individual boundary points; the origin has no unique directional limit. This is not a nearest-point projection. P(1,0,0)=(1,0,1/2), whereas P(P(1,0,0))=(1+1/(2 sqrt(5)),0,1/sqrt(5)).

For q=alpha H(s cross roll(s,1)) and any scalar clipping factor, s dot qhat=0. Thus ||s+dt qhat||^2=||s||^2+dt^2||qhat||^2, with dt=0.1. The Euler step grows norm unless torque is zero; the continuous torque intuition does not change this discrete identity. Only afterward does P impose its surface.

Parameterize the upper torus by s(theta,phi)=((1+r cos theta)cos phi,(1+r cos theta)sin phi,r sin theta), 0<=theta<=pi. With torque zero,

theta_next=g(theta)=atan2(1+r cos theta,r sin theta), phi_next=phi.

The entire interval maps into [pi/3,pi/2]. On [0,pi/2],

g'(theta)=-r(r+cos theta)/(1+2r cos theta+r^2), |g'|<=1/3.

There is one fixed poloidal angle: c=cos theta_*=(sqrt(3)-1)/2, sin theta_*=sqrt(1-c^2). Therefore the fixed set is the circle C={ (rho_* cos phi,rho_* sin phi,z_*) }, with rho_*=1+c/2, z_*=sqrt(1-c^2)/2. The meridional multiplier is sqrt(3)-2, the azimuthal multiplier is 1 and the erased ray direction has multiplier 0. C attracts under P, but no one member attracts a neighborhood containing other azimuths. A contracting poloidal coordinate gives alternating transient segments, not a nontrivial triangle cycle.

### Conditional forward convergence of the driven printed map

For every finite alpha and fixed t_n=0.1n, |H(t_n)| is bounded by the sum 2 exp(-.5t_n)+exp(-.3t_n)+1.5 exp(-.7t_n)+exp(-.4t_n), a summable sequence. After the first defined step, s_n lies in the closed upper torus K, with .5<=rho_n and ||s_n||<=1.5. Write e_n=.1 qhat_n. Clipping gives ||e_n||<=.08, and the torque bound gives ||e_n||<=.225 |alpha| |H(t_n)|, so sum ||e_n|| is finite.

Throughout the straight segment from s_n to s_n+e_n, horizontal radius is at least .42. Angle changes obey |delta theta|,|delta phi|<=||e_n||/.42 (continuous azimuth lift). Also z_{n+1}=.5 rho(s_n+e_n)/||s_n+e_n|| >= .5*.42/1.58 > .1329 for n>=1. Hence z_n+e_{n,z}>.0529 for n>=2, so theta_n lies in (0,pi/2) from n=3 onward. The perturbed contraction satisfies

|theta_{n+1}-theta_*| <= (1/3)|theta_n-theta_*| + ||e_n||/.42.

This proves theta_n -> theta_*. Summable lifted azimuth increments prove phi_n -> phi_infinity. Thus each admissible trajectory converges to a point of C in ordinary Euclidean distance. This is forward convergence from a fixed clock origin. C is the fixed set of the limiting map, generally not an invariant set of the finite-time driven map. No nonzero-size recurring triangle survives this limit.

The endpoint is not a universally selected single point: restrict initial states to a complete torus latitude circle. Every finite-step map is continuous there, has a continuous azimuth lift satisfying Phi(phi+2pi)=Phi(phi)+2pi, and the angle-increment tail bound is uniform in phi. The uniform limiting endpoint map retains degree one and is onto C. This is a set-attraction statement with a neutral endpoint family, not synchronization of all starts. It does not require fresh nearby-start runs.

For alpha != 0 there is no clock-independent fixed state over the whole prescribed schedule. Such a state would have to lie in C by H -> 0. P maps an off-axis ray to a unique torus point, so P(s+e)=s=P(s) would force s+e to be a positive multiple of s. Orthogonality forces e=0. A real positive-roll cross product vanishes only for s proportional to (1,1,1), or zero; no such point lies on C. The zero-alpha exception is the fixed circle. Clock resets, nondecaying schedules and unreported alternative producers are outside this theorem.

## Fixed execution budgets and interpretation

F3: 16 evaluations maximum, each <=101 by 101. First evaluate the related source's literal 100-grid field/epsilon-clip/argmin at t=0. Subsequent cases are declared PDF-detector diagnostics: related H at t=0,2.5,9.9; H=0; H=100 (flat printed clip); H=45 (partial plateau); float32; odd parity; exactly inversion-paired coordinates; radial-form controls; sign and small-amplitude controls. Each new grid/magnitude/detector pipeline counts once. No 100-frame historical replay and no tracer integration.

F4: 12 isolated preflight steps (8 remap-only probes including P twice at one point, axis/origin conventions and one fixed-circle point; 4 explicit diagnostic torque probes). Diagnostic alpha values are fixtures, not historical parameters. One 200-update remap-only trajectory starts at (1,0,0), alpha=0, t_n=.1n. This is a declared finite off-axis state allowed by the printed map; it is not a recovered F4 start. No nearby trajectories, extension or driven baseline. Save every input, torque, clipped torque, pre-remap point, output, time and clipping flag. Nonfinite values stop the branch.

Use binary64 except the explicit binary32 F3 case. Floating algebra/geometry residual checks use absolute tolerance 1e-12 (binary64); F3 binary32 magnitude comparison uses 2e-6. Exact claims rest on the written algebra, with symbolic reductions for the key identities. Mask equality is not enforced across precision or clipped-field methods.

## Passive view specification

Use a detached extraction of only canonical_points/candidate_faces plus their required exact constants from the inspected geometry source; do not import its build or any native kernel. Check the extracted face list against the retained candidate JSON. Use tau=0 PLUS, with MINUS shown separately as its whole-mesh reflection; no hand is selected for dynamics. The host comes directly from HOST_GEOMETRY.json and is checked against its recorded current source hashes. Preserve all open boundaries.

Place source coordinates at X_display=O+s, O=(0,sqrt(3)/6,0), with scale exactly one, no extra rotation, right-handed Cartesian axes and no calibrated physical units. F3 grid/detector coordinates lift to (X,Y,0); F4 uses its saved triple. This is an illustrative identification of coordinate charts, not an SRG-to-Z map. Do not resize the path or data to fit the central geometry. Show the whole extent, and disclose outside-window points. A close geometry inset is context only. No ball surface or surrounding toroid with invented dimensions is needed; the central marker identifies an inspection origin. Explain that any sketched toroidal guide remains schematic.

Observer controls use saved data only: immutable arrays and file hashes with overlay off/on; one predetermined rigid frame rotation/translation and pairwise distance comparison; cylindrical (rho,phi,z) inversion retaining radius, with axis singularity and atan2 wrapping explicit. The view has no clock dependence, so no shrinking-envelope control is applicable. Rendering and camera changes do not call the evolution function.
