# CA01 input notes and source anchors

Prepared by GPT on 21 October 2026 for the accompanying work order.

## Included historical document and visual references

**S1 — `inputs/SGR_simulations.pdf`.** Exact copy of the author's uploaded PDF, internally titled *SGR: simulation steps*, 1 August 2025. Seventeen physical pages. Section 3 on page 5 defines the grid field and percentile-centroid detector; Figure 3 is on page 6. Section 4 on page 7 defines the 3D update and toroidal map; Figure 4 is on page 8. The packet manifest records the original bytes. The historical document is evidence of its printed definitions and claims, not automatic certification of every caption.

**S2 — `inputs/author_toroidal_measurement_sketch.png`.** Exact copy of the author's drawing. Read it together with his subsequent clarification: the geometry is a measuring/visualization layer, not a physical compression mechanism. The drawing's word “squeased” does not override that clarification. Its central silhouette is not the accepted hex-crystal mesh.

**S3 — `inputs/vajra_visual_reference.png`.** Exact copy of the author's supplied photograph, used to explain the ball-like central arrangement. It is not a geometric specification or historical/physical evidence. No inference about the object's makers or religious origins is part of this task.

## Retrieved project references — navigation, not new verification

**R1 — `Z_CRYSTAL_REVERSAL_AND_UPPER_LOWER_CORRESPONDENCE_ANALYSIS_v0.1.md`.** The retrieved 20 October 2026 report records a read of local HEAD `3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34`. Section 1 distinguishes the refined PLUS zero face complex, its handed family, source time, and the passive native observer. Its source-location table identifies the geometry and report paths reproduced in the work order. Source definitions and the applicable review must be checked in the current authoritative local checkout; this packet does not assert today's HEAD or publication status.

In particular, that report distinguishes the chiral face mesh from its vertex scaffold; distinguishes the actual fan openings from finite shell notch measurement triangles; and says that its native map does not evolve the crystal's pose or family parameter. The report's earlier physical-motion questions do not override the author's latest clarification that the present task uses geometry analytically.

**R2 — `FRESH_CHAT_HANDOFF_SRG_SIM02_REPEATED_DRIVE_20261014(1).md`.** The retrieved 14 October handoff provides SIM01 publication/source navigation and separates the A/B/C many-center motion family from other historical SRG constructions. It records SIM01 publication at `0ecedec5a7d7077740b0d336ba9959dc8f117caf` and gives the paths to its report, reviewer analysis and source programs. Its statements about what had or had not been executed were statements at that handoff date, not a newly checked current SIM02 status. CA01 does not authorize executing its proposed repeated-driving experiment.

**R3 — SIM01 publication landing and disposition.** Retrieved Library copies named `README(7).md` and `PUBLICATION_DISPOSITION.md` describe the preserved motion study, its bounded source/replay acceptance, source-specific operators, retained-state feedback and observer artifacts. Those preparation-stage copies retain older approval wording; R2 records the later publication event. Read the authoritative local edition rather than editing old notices or treating a preparation timestamp as current status.

The full Library reports are not duplicated in this packet. Their relevant exact local anchors are included in the work order so Codex can use the source copies already available to him. No live GitHub verification or Windows filesystem inspection was performed while preparing this packet.

## New leads, not inherited results

The F3 magnitude/mask analysis, the F4 discrete-step norm identity, the tests of the map's image/idempotence, and the passive-view controls in the work order are GPT's proposed analysis tasks. They have not been counted as completed CA01 checks. Codex must verify them against the selected definitions and state their scope.

Do not adopt earlier conversational explanations as source authority. In particular, a centroid near zero does not yet establish a quiet neighborhood at the origin, and a continuous torque-only argument is not a proof that the source's finite step preserves norm. The work order explicitly tests those distinctions.

The packet contains no new simulations, repaired historical code, amended manuscript, physical model, or generated scientific figure. Copying an input here does not modify the historical original or confer publication/license permission beyond the author's requested research use.
