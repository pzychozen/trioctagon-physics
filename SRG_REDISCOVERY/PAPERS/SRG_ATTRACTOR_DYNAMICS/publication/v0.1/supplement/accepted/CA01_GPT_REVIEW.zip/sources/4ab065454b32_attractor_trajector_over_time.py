import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Parameters
grid_size = 100
timesteps = 100
dt = 0.1

# Memory curve H(t)
def H(t):
    a1, b1 = 2.0, 0.5
    alpha2, b2 = 1.0, 0.3
    lambda1, omega1 = 1.5, 0.7
    lambda2, omega2 = 1.0, 0.4
    return a1 * np.exp(-b1 * t) * np.cos(t) + alpha2 * np.exp(-b2 * t) * np.sin(t) + \
           lambda1 * np.exp(-omega1 * t) + lambda2 * np.exp(-omega2 * t)

# Toroidal angular flow field (TGMO)
def tgmo_field(X, Y, t):
    r = np.sqrt(X**2 + Y**2)
    theta = np.arctan2(Y, X) + 0.05 * np.sin(0.1 * t)
    return -np.sin(theta) * H(t) / (1 + r**2), np.cos(theta) * H(t) / (1 + r**2)

# RPCO limiters
def rpco_clip(Vx, Vy, threshold=1.0):
    mag = np.sqrt(Vx**2 + Vy**2)
    factor = np.minimum(1.0, threshold / (mag + 1e-5))
    return Vx * factor, Vy * factor

# Initialize grid
x = np.linspace(-5, 5, grid_size)
y = np.linspace(-5, 5, grid_size)
X, Y = np.meshgrid(x, y)

# Initialize field
U, V = np.zeros_like(X), np.zeros_like(Y)

# Attractor position storage
attractor_path = []

# Simulation
for t_step in range(timesteps):
    t = t_step * dt
    U, V = tgmo_field(X, Y, t)
    U, V = rpco_clip(U, V)

    # Numerically locate center of field convergence (attractor estimate)
    magnitude = np.sqrt(U**2 + V**2)
    attractor_index = np.unravel_index(np.argmin(magnitude), magnitude.shape)
    attractor_position = (X[attractor_index], Y[attractor_index])
    attractor_path.append(attractor_position)

# Save attractor path
with open("attractor_path_log.txt", "w") as f:
    for pos in attractor_path:
        f.write(f"{pos[0]:.4f}, {pos[1]:.4f}\n")

# Plot attractor trajectory
attractor_path = np.array(attractor_path)
plt.figure(figsize=(6, 6))
plt.plot(attractor_path[:, 0], attractor_path[:, 1], marker='o', markersize=3)
plt.title("Attractor Trajectory Over Time")
plt.xlabel("X Position")
plt.ylabel("Y Position")
plt.grid(True)
plt.axis("equal")
plt.show()
