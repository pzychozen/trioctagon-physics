"""Copy packet evidence and record bounded read-only provenance."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, zipfile

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[2]
PACKET = Path(r'C:\Users\Notandi\Downloads\SRG_CA01_CODEX_START_PACKET.zip')
sys.stdout.reconfigure(encoding='utf-8')
def sha(data): return hashlib.sha256(data).hexdigest()
def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data: raise RuntimeError(f'Preserving existing file: {path}')
    else: path.write_bytes(data)
def git(*args): return subprocess.check_output(['git', '-C', str(REPO), *args])
with zipfile.ZipFile(PACKET) as z:
    manifest = json.loads(z.read('PACKET_MANIFEST.json'))
    for row in manifest['files']:
        data = z.read(row['path'])
        assert len(data) == row['size'] and sha(data) == row['sha256']
    for name in z.namelist():
        dest = (BASE / 'received' / name).resolve()
        assert dest.is_relative_to(BASE / 'received')
        save(dest, z.read(name))
save(BASE/'evidence'/'starting_status.txt', git('status', '--porcelain=v1', '--untracked-files=normal'))
save(BASE/'evidence'/'starting_index.txt', git('diff', '--cached', '--name-status'))
meta = {'head':git('rev-parse','HEAD').decode().strip(), 'branch':git('branch','--show-current').decode().strip(),
        'python':sys.executable, 'version':sys.version, 'packet_sha256':sha(PACKET.read_bytes()),
        'modules':{n:importlib.util.find_spec(n) is not None for n in ['numpy','scipy','sympy','matplotlib','fitz','pypdf','pdfplumber','PIL']}}
save(BASE/'evidence'/'starting_environment.json', (json.dumps(meta,indent=2)+'\n').encode())
print(json.dumps(meta,indent=2))
if meta['modules']['fitz']:
    import fitz
    doc=fitz.open(BASE/'received'/'inputs'/'SGR_simulations.pdf')
    print('PDF pages:', len(doc))
    for i in range(len(doc)):
        save(BASE/'evidence'/'pdf_text'/f'page_{i+1:02}.txt', doc[i].get_text().encode('utf-8'))
    for i in range(4,8):
        save(BASE/'evidence'/'pdf_pages'/f'page_{i+1:02}.png', doc[i].get_pixmap(matrix=fitz.Matrix(1.6,1.6)).tobytes('png'))
        print(f'\n--- PAGE {i+1} ---\n'+doc[i].get_text())
