"""Bounded indexed search; no historical program is executed."""
from source_access import *
import zipfile, re
sys.stdout.reconfigure(encoding='utf-8')
keys=['attractor_path_log','attractor_positions.csv','np.roll','np.cross','percentile']
out={'scope':'R0 script/data/archive indexes; OLD_MATERIAL Python files; Python and target-named members of Simulations.zip','indexed_hits':{},'loose_code_hits':[],'loose_named_data':[],'archive_code_hits':[],'archive_named_data':[]}
for name in ['script_inventory.json','data_inventory.json','supplied_archive_listing.json','pdf_inventory.json']:
    raw=consume('SRG_REDISCOVERY/R0_SOURCE_RECOVERY/'+name).decode('utf-8')
    data=json.loads(raw)
    if isinstance(data,list):
        hits=[v for v in data if any(k in json.dumps(v).lower() for k in ['attractor','triangle','sgr_simulations'])]
    else:
        hits={'structure':list(data),'matching_lines':[v for v in raw.splitlines() if any(k in v.lower() for k in ['attractor','triangle','sgr_simulations'])]}
    out['indexed_hits'][name]=hits
old=REPO/'SRG_REDISCOVERY/OLD_MATERIAL'
files=list(old.rglob('*.py')); out['loose_python_count']=len(files)
for p in files:
    txt=p.read_text(encoding='utf-8-sig',errors='replace')
    found=[{'line':i,'text':l} for i,l in enumerate(txt.splitlines(),1) if any(k in l for k in keys)]
    if found:
        out['loose_code_hits'].append({'path':str(p.relative_to(REPO)),'hits':found,'sha256':hashlib.sha256(consume(p)).hexdigest()})
for p in old.rglob('*'):
    if p.is_file() and p.name.lower() in ['attractor_positions.csv','attractor_path_log.txt']:
        out['loose_named_data'].append({'path':str(p),'sha256':hashlib.sha256(consume(p)).hexdigest()})
zp=old/'Simulations.zip'
with zipfile.ZipFile(zp) as z:
    py=[i for i in z.infolist() if i.filename.lower().endswith('.py')]
    out['archive_python_count']=len(py)
    out['archive_container']={'path':str(zp),'size':zp.stat().st_size,'identity_scope':'individual consumed members, not whole archive hash'}
    for info in py:
        b=z.read(info); txt=b.decode('utf-8-sig',errors='replace')
        found=[{'line':i,'text':l} for i,l in enumerate(txt.splitlines(),1) if any(k in l for k in keys)]
        if found:
            out['archive_code_hits'].append({'member':info.filename,'size':info.file_size,'sha256':hashlib.sha256(b).hexdigest(),'hits':found})
    for i in z.infolist():
        if Path(i.filename).name.lower() in ['attractor_positions.csv','attractor_path_log.txt']:
            b=z.read(i); out['archive_named_data'].append({'member':i.filename,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(BASE/'evidence/lineage_search.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
for p in ['research/twisted_hex_crystal_registration_v0.1/verify_host_registration.py','research/twisted_hex_crystal_registration_v0.1/HOST_GEOMETRY.json','research/twisted_hex_crystal_registration_v0.1/CANONICAL_CRYSTAL_CANDIDATE.json','kernel_physics/geometry.py','kernel_physics/z_manifold.py','kernel_physics/readouts.py','papers/PAPER_C/publication/v1.0.1/PAPER_C_EXACT_TRIOCTAGON_GEOMETRY_PUBLICATION_v1.0.1.md']:
    consume(p)
