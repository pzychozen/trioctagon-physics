# Reading the evidence

Start with READ_ME_FIRST.md, then CA01_ANALYSIS.md and SOURCE_AND_CLAIM_MAP.md. These files and five PNGs are the review surface. The packet PDF and its four rendered method/figure pages are historical evidence, not newly generated claims. The sketch and photograph are unchanged reference attachments, unused as geometry specifications.

## Machine-readable records

- RESULTS.json: actual budgets, runtime versions, predeclared tolerances, all F3 case settings/statistics, 12 full F4 preflight records, exact supporting reductions and the remap-only control summary.
- OBSERVER_CHECKS.json: fixed placement, saved-array immutability, all raw file hashes, geometry identity and distance/coordinate checks; zero fresh dynamics.
- VERIFICATION.json: independent saved-data checks, symbolic/source locators and residual maxima. Its 16 saved-mask and 212 saved-transition/preflight checks are passive work, not extra field evaluations or rollout updates.
- PRESERVATION.json: scoped before/after source and Git checks. This is not a whole-repository byte census.
- evidence/consumed_sources.json: each substantive consumed original's absolute path, SHA-256, size and bundled snapshot path. `sources/` contains those exact snapshots.
- evidence/lineage_search.json: bounded indexes, searches, missing file results and matching ZIP-member identities. The archive container was not copied into this package.
- MANIFEST.json: review payload paths, sizes and SHA-256 values; excludes itself and the ZIP/transport receipt.

## Raw arrays (always load with allow_pickle=False)

F3_00.npz through F3_15.npz contain X, Y, U, V, magnitude, mask, centroid, H, t and threshold. Consult the corresponding RESULTS.json case first. `t` is the declared diagnostic clock argument, not a recovered historical sample time. The radial-form controls F3_11/F3_12 have **unused zero U,V placeholders**; their operative object is the algebraic radial magnitude, not a reconstructed vector field. F3_00's mask marks its single argmin. All other masks store the strict percentile selection. F3_04's empty mask has NaN centroid in NPZ and null in JSON, explicitly meaning undefined. F3_05's nonempty floating mask is retained despite its exact printed field being flat; do not interpret that artifact as a defined exact centroid. No other nonfinite raw scientific values are accepted.

F4_remap_only.npz stores:

| Array | Index meaning |
|---|---|
| states | 201x3, initial at row 0 and successor of update n at row n+1 |
| state_index/display_time | 0..200 and .1*(0..200); diagnostic state labels |
| s, t, alpha, H | 200 incoming states, forcing times .1n, alpha=0 and evaluated printed H |
| q, qhat, u, dest | 200 raw torques, clipped torques, pre-remap points and successors |
| clipped/factor | Per-update Boolean and actual clip factor |

The final stored zero distance is finite-precision agreement, not a proof of finite-time mathematical arrival. No source-matched driven trajectory is present.

evidence/geometry_reference.npz contains the source-defined PLUS/MINUS zero coordinates, actual triangle indices, open boundary edges, exact-source host rendered in binary64 and O. It is an observation reference, not an added kernel model. Its planar cuts/openings are not caps or physical interfaces.

## Rechecking without new dynamics

From this folder in Windows CMD:

```bat
call conda activate torment
python -B verify_saved.py
```

This reads bundled copies and arrays; it does not need a historical program import or an installed project package. It rewrites VERIFICATION.json with the checker result, so retain the delivered ZIP as the immutable reference. `passive_views.py` can regenerate the same images from saved data and pinned geometry snapshots without evolving state. It prefers available authoritative originals and verifies recorded identities; when originals are absent it resolves the unique bundled source snapshot.

`run_checks.py` records the original bounded experiment. It refuses to run if raw/ already exists. Do not remove that guard or launch more trajectories under this completed execution allowance. The work order's 16-field ceiling has been used. No new scientific run is needed to review the package.

The scripts assume only the already present torment NumPy, SymPy and Matplotlib. No dependency was installed. PDF rendering used the existing bundled Poppler executable, from CMD. No PDF-authoring workflow, online service, GUI viewer, native update or external publication was used.
