"""Saved-data-only observer checks and scientific figures; zero dynamics calls."""
from pathlib import Path
import ast, collections, hashlib, json, os, sys
import numpy as np
import sympy as sp
from source_access import BASE, REPO, consume
for name in ['MPLCONFIGDIR','TMP','TEMP']:
    p=BASE/'cache'/name;p.mkdir(parents=True,exist_ok=True);os.environ[name]=str(p)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#f7f8fa','axes.facecolor':'white'})
PLOTS=BASE/'plots';PLOTS.mkdir(exist_ok=True)
R=json.loads((BASE/'RESULTS.json').read_text())
hash_before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'raw').glob('*.npz')}

# AST-select geometry definitions only. No import of the original module/runner.
src=consume('research/twisted_hex_crystal_registration_v0.1/verify_host_registration.py').decode()
tree=ast.parse(src)
constants={'S','D','R0','O','T','J','HALF','NORMALS'}
nodes=[n for n in tree.body if (isinstance(n,ast.FunctionDef) and n.name in ['canonical_points','candidate_faces']) or
       (isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in constants)]
env={'sp':sp}; exec(compile(ast.Module(body=nodes,type_ignores=[]),'<detached geometry definitions>','exec'),env)
O=np.array([0,np.sqrt(3)/6,0]); faces=np.array(env['candidate_faces'](),dtype=int)
plus=np.array(env['canonical_points'](sp.Integer(0),1),dtype=float).reshape(18,3)+O
minus=np.array(env['canonical_points'](sp.Integer(0),-1),dtype=float).reshape(18,3)+O
host=json.loads(consume('research/twisted_hex_crystal_registration_v0.1/HOST_GEOMETRY.json'))
cand=json.loads(consume('research/twisted_hex_crystal_registration_v0.1/CANONICAL_CRYSTAL_CANDIDATE.json'))
assert faces.tolist()==cand['variants'][0]['faces']
for row in host['sources']:
    assert hashlib.sha256(consume(row['path'])).hexdigest()==row['sha256']
hostv=np.array([[float(sp.sympify(x)) for x in v] for v in host['welded_vertices']]); hostf=host['welded_faces']
edgecounts=collections.Counter(tuple(sorted((int(f[i]),int(f[(i+1)%3])))) for f in faces for i in range(3))
boundary=[e for e,count in edgecounts.items() if count==1]
assert len(plus)==18 and len(faces)==24 and len(edgecounts)==42 and len(boundary)==12
assert np.max(abs(plus[12:15]-np.array(host['upper_targets_numeric'])))<1e-12
np.savez_compressed(BASE/'evidence/geometry_reference.npz',plus=plus,minus=minus,faces=faces,host_vertices=hostv,host_faces=np.array(hostf),origin=O,boundary_edges=np.array(boundary))

with np.load(BASE/'raw/F4_remap_only.npz',allow_pickle=False) as data:
    states=data['states'];time=data['display_time']
states.setflags(write=False)
def observe(s,overlay=True):
    return O+s, {'overlay':overlay,'scale':1.,'rotation':'identity','time_dependence':False}
display,settings=observe(states)
display_off,_=observe(states,False)
assert np.array_equal(display,display_off)
angle=np.pi/6
Q=np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
rotated=states@Q.T+np.array([.2,-.3,.4])
dist=lambda a:np.linalg.norm(a[:,None,:]-a[None,:,:],axis=2)
rotation_residual=float(np.max(np.abs(dist(rotated)-dist(states))))
translation_residual=float(np.max(np.abs(dist(display)-dist(states))))
rho=np.hypot(states[:,0],states[:,1]);phi=np.arctan2(states[:,1],states[:,0]);zz=states[:,2]
angular_reconstruction=np.column_stack((rho*np.cos(phi),rho*np.sin(phi),zz))
angular_residual=float(np.max(np.abs(angular_reconstruction-states)))
assert max(rotation_residual,translation_residual,angular_residual)<1e-12
window=np.all(np.abs(states[:,:2])<=.3,axis=1)&(np.abs(states[:,2])<=.5)
observer={'fresh_updates':0,'saved_F4_states':len(states),'raw_hashes_before':hash_before,'overlay_on_off_array_equal':True,
          'state_array_readonly':not states.flags.writeable,'translation_distance_residual':translation_residual,
          'rigid_frame_distance_residual':rotation_residual,'cylindrical_reconstruction_residual':angular_residual,
          'cylindrical_definition':'rho=hypot(x,y), phi=atan2(y,x) in [-pi,pi], z retained; phi undefined on axis; continuous lift needed across branch',
          'placement':'X_display=(0,sqrt(3)/6,0)+s; fixed scale 1; right-handed axes; no units calibration or Z mapping',
          'central_display_window':'abs(x)<=.3, abs(y)<=.3, abs(z)<=.5 in centered host coordinates, not a containment test',
          'outside_window_count':int((~window).sum()),'geometry':{'tau':0,'faces':24,'vertices':18,'edges':42,'open_boundary_edges':12,'host_source_hashes_match':True,'both_hands_rendered':True,'not_kernel_adoption':True}}

def finish(fig,name,caption):
    fig.text(.035,.025,caption,ha='left',va='bottom',fontsize=10,color='#324050')
    fig.savefig(PLOTS/name,dpi=160,bbox_inches='tight');plt.close(fig)

# Figure 1: identical saved objects, no new field/mask evaluations.
with np.load(BASE/'raw/F3_01.npz',allow_pickle=False) as d:
    X,Y,M,mask,centroid=(d[k] for k in ['X','Y','magnitude','mask','centroid'])
fig,axs=plt.subplots(1,3,figsize=(15.6,5.4),gridspec_kw={'width_ratios':[1,1,1.12]})
fig.suptitle('Figure 3 diagnostic: a central average of distant outer points',fontsize=17,x=.035,ha='left')
im=axs[0].pcolormesh(X,Y,M,cmap='viridis',shading='nearest',norm=LogNorm(vmin=M.min(),vmax=1.))
fig.colorbar(im,ax=axs[0],fraction=.046,pad=.03,label='Clipped field magnitude')
axs[0].set_title('Printed field, related-source H(0)=4.5')
axs[1].scatter(X[mask],Y[mask],s=7,color='#137e90',label=f'{mask.sum()} selected grid points')
axs[1].scatter(*centroid,s=160,marker='X',c='#d44b39',edgecolor='white',label='Their centroid')
axs[1].annotate('The marker is outside the selected region',xy=centroid,xytext=(-4.7,2.8),arrowprops={'arrowstyle':'->'},fontsize=9)
axs[1].legend(loc='lower center',fontsize=8);axs[1].set_title('Strict lowest-5% mask + centroid')
for ax in axs[:2]:
    ax.set(xlim=(-5.3,5.3),ylim=(-5.3,5.3),xlabel='Native X',ylabel='Native Y');ax.set_aspect('equal')
sub=[R['F3'][i] for i in [1,2,3,8,9,10,11]]
colors=['#da563b','#2375ad','#7d58a6','#4c927c','#b58626','#bf577c','#333333']
for row,color in zip(sub,colors):
    cx,cy=row['centroid'];axs[2].scatter(cx,cy,c=color,s=45,label=row['id'])
    if row['id'] not in ['F3_10','F3_11']:axs[2].annotate(row['id'],(cx,cy),xytext=(4,5),textcoords='offset points',fontsize=8)
axs[2].axhline(0,color='#bfc6ce',lw=.7);axs[2].axvline(0,color='#bfc6ce',lw=.7)
axs[2].set(xlim=(-.042,.027),ylim=(-.025,.03),xlabel='Centroid X (zoomed)',ylabel='Centroid Y (zoomed)',title='Diagnostic settings move the detector')
axs[2].text(.03,.06,'F3_10/11: paired grid / radial formula\nBoth give zero within summation roundoff.\nPoints are separate controls, not a time path.',transform=axs[2].transAxes,fontsize=9)
fig.subplots_adjust(left=.05,right=.98,top=.82,bottom=.23,wspace=.38)
finish(fig,'01_F3_mask_and_centroid.png','Saved diagnostic controls, not a recovered Figure 3 replay. Exact symmetric masks average to zero; floating ties can shift that average.\nThe surviving old argmin code instead selects a single corner (-5,-5) in its t=0 check. No tracer particles were introduced.')

# Figure 2: the sole fresh rollout, plus exact limiting set and explicit time direction.
rs=R['F4_control']['rho_star'];zs=R['F4_control']['z_star'];theta=np.linspace(0,2*np.pi,240)
circle=np.column_stack((rs*np.cos(theta),rs*np.sin(theta),np.full_like(theta,zs)))
fig=plt.figure(figsize=(15,9));gs=fig.add_gridspec(2,2,left=.07,right=.96,top=.88,bottom=.16,hspace=.44,wspace=.3)
fig.suptitle('Figure 4 printed map: remapping alone settles toward a fixed circle',x=.04,ha='left',fontsize=17)
ax=fig.add_subplot(gs[0,0],projection='3d')
ax.plot(*circle.T,ls='--',c='#b1b5bd',lw=1.4,label='Limiting fixed circle (not an orbit)')
ax.plot(*states[:12].T,'o-',c='#cf503f',ms=3,label='Remap-only states')
ax.scatter(*states[0],c='#167f91',s=55,marker='s');ax.scatter(*states[-1],c='#d69817',s=65,marker='*')
ax.set(xlabel='x',ylabel='y',zlabel='z',title='Native coordinates: all 200 updates');ax.set_box_aspect((2.5,2.5,1.2));ax.set_zlim(-.05,1.15);ax.legend(fontsize=8,loc='upper left')
ax=fig.add_subplot(gs[0,1]);ax.plot(states[:12,0],states[:12,2],'o-',c='#cf503f',ms=4)
for i,off in [(0,(5,5)),(1,(5,8)),(2,(5,-20)),(3,(-65,0))]:
    ax.annotate(f'n={i}',(states[i,0],states[i,2]),xytext=off,textcoords='offset points')
    if i<3: ax.annotate('',xy=states[i+1,[0,2]],xytext=states[i,[0,2]],arrowprops={'arrowstyle':'->','color':'#303845','lw':1.2})
ax.scatter(rs,zs,c='#d69817',s=100,marker='*');ax.set(xlabel='x = horizontal radius on this control',ylabel='z',title='Initial zigzag is a transient; azimuth stays zero',xlim=(.98,1.26),ylim=(-.03,.56));ax.grid(alpha=.18)
ax=fig.add_subplot(gs[1,0]);d=np.hypot(rho-rs,zz-zs);pos=d>0
ax.semilogy(np.flatnonzero(pos),d[pos],'.-',color='#167f91');ax.set(xlim=(0,30),xlabel='Update count n',ylabel='Euclidean distance to fixed circle',title='Contraction, then binary64 rounding');ax.grid(alpha=.2)
ax.text(.43,.58,'n=20: 2.29e-12\nn=200: stored distance is 0\nA rounded zero is not the proof.',transform=ax.transAxes,fontsize=10)
ax=fig.add_subplot(gs[1,1]);ax.plot(np.arange(201),rho,label='horizontal radius',color='#167f91');ax.plot(np.arange(201),zz,label='height',color='#cf503f');ax.axhline(rs,c='#167f91',ls=':',lw=1);ax.axhline(zs,c='#cf503f',ls=':',lw=1)
ax.set(xlabel='Update count n; assigned time t=0.1n',ylabel='Native coordinate',title='Original 200-step horizon, no extension',xlim=(0,200));ax.legend();ax.grid(alpha=.18)
finish(fig,'02_F4_remap_only.png','Declared control: alpha=0, s0=(1,0,0), 200 updates. This is not a historical replay; the original alpha and initial state are missing.\nThe exact proof gives a neutral azimuth and a contracting poloidal angle. For the printed decaying drive at t=0.1n, trajectories also converge to this circle.')

def draw_mesh(ax,vertices,host_on=True,details=True):
    if host_on:
        for f in hostf:
            pp=hostv[list(f)+[f[0]]];ax.plot(*pp.T,c='#aab4c0',lw=.9,alpha=.8)
    ax.add_collection3d(Poly3DCollection(vertices[faces[:12]],facecolors='#78a8bd',edgecolors='#3d6a80',linewidths=.55,alpha=.2))
    ax.add_collection3d(Poly3DCollection(vertices[faces[12:18]],facecolors='#dcad4e',edgecolors='#9a762a',linewidths=.65,alpha=.45))
    ax.add_collection3d(Poly3DCollection(vertices[faces[18:]],facecolors='#b29acb',edgecolors='#695783',linewidths=.65,alpha=.4))
    for e in boundary: ax.plot(*vertices[list(e)].T,c='#087f7a',lw=2 if details else 1)
    ax.scatter(*O,c='#152f42',marker='+',s=55)

# Figure 3: fixed placement of the SAME saved points, without fitting them to a ball.
fig=plt.figure(figsize=(15,6.6));fig.suptitle('Passive comparison: translating the display does not create attraction',x=.04,ha='left',fontsize=17)
ax1=fig.add_subplot(121,projection='3d');ax2=fig.add_subplot(122,projection='3d')
for ax,pts,center in [(ax1,states,np.zeros(3)),(ax2,display,O)]:
    ax.plot(*pts.T,'o-',c='#cf503f',ms=3,lw=1.4)
    ax.scatter(*pts[0],c='#167f91',marker='s',s=50,label='n=0')
    ax.scatter(*pts[-1],c='#d69817',marker='*',s=85,label='n=200')
    ax.set(xlim=(-.55,1.4),ylim=(center[1]-.55,center[1]+.8),zlim=(-.6,.65),xlabel='x',ylabel='y',zlabel='z')
    ax.view_init(elev=22,azim=-64);ax.set_box_aspect((1.95,1.35,1.25));ax.legend(loc='upper left',fontsize=9)
ax1.set_title('Native F4 remap-only control',pad=13)
draw_mesh(ax2,plus,details=False);ax2.set_title('Same saved states + registered PLUS zero mesh',pad=13)
fig.subplots_adjust(left=.03,right=.97,bottom=.19,top=.83,wspace=.08)
finish(fig,'03_passive_native_comparison.png','Map: X_display = (0, sqrt(3)/6, 0) + s. Fixed scale 1, aligned right-handed axes; units have no physical calibration.\nAll 201 states lie outside the declared central display window. They remain visible. No geometry, camera, clipping window or Z readout feeds the update.')

# Figure 4: actual reference faces and OPEN boundaries, both hands.
fig=plt.figure(figsize=(14,7.3));fig.suptitle('The recovered reference geometry: preserve the faces and openings',x=.04,ha='left',fontsize=17)
for j,(verts,label) in enumerate([(plus,'PLUS zero face complex'),(minus,'MINUS zero face complex')],1):
    ax=fig.add_subplot(1,2,j,projection='3d');draw_mesh(ax,verts)
    ax.set(xlim=(-.54,.54),ylim=(-.02,.91),zlim=(-.56,.56),xlabel='Host x',ylabel='Host y',zlabel='Host z',title=label)
    ax.set_box_aspect((1.08,.93,1.12));ax.view_init(elev=14,azim=-63)
    ax.text(-.46,.08,.49,'upper open boundary',fontsize=8,color='#087f7a')
    ax.text(-.46,.08,-.5,'lower open boundary',fontsize=8,color='#087f7a')
fig.subplots_adjust(left=.01,right=.97,bottom=.19,top=.83,wspace=.03)
finish(fig,'04_reference_mesh_and_openings.png','Existing width-one host and refined crystal family at tau=0: 18 crystal vertices, 24 triangles, two open six-edge boundary loops.\nThe hands share a vertex scaffold but have distinct face surfaces. Green edges bound openings; no caps, ball surface or invented toroidal dimensions are added.')

# F3 comparison at the same fixed placement; full field support stays visible.
fig,axs=plt.subplots(1,2,figsize=(12.8,6));fig.suptitle('Figure 3 passive view: the same outer mask around a different chart origin',x=.04,ha='left',fontsize=16)
for ax,shift,title in [(axs[0],np.zeros(2),'Native grid'),(axs[1],O[:2],'Registered analytical view, fixed scale 1')]:
    ax.scatter(X[mask]+shift[0],Y[mask]+shift[1],s=5,c='#137e90')
    ax.scatter(*(centroid+shift),marker='X',s=100,c='#d44b39',zorder=5)
    ax.set(xlabel='x',ylabel='y',title=title,xlim=(-5.3,5.3),ylim=(-5.3+shift[1],5.3+shift[1]));ax.set_aspect('equal')
for f in hostf:
    pp=hostv[list(f)+[f[0]]];axs[1].plot(pp[:,0],pp[:,1],c='#6a7280',lw=.8)
for f in faces:
    pp=plus[list(f)+[f[0]]];axs[1].plot(pp[:,0],pp[:,1],c='#ad7d23',lw=.5,alpha=.5)
fig.subplots_adjust(left=.07,right=.97,top=.83,bottom=.2,wspace=.25)
finish(fig,'05_F3_passive_comparison.png','F3_01 saved mask and centroid in both panels; the right panel only translates them by O=(0,sqrt(3)/6). Height is zero.\nThe central geometry is small at unit scale. Its proximity to the average does not move the selected grid points there or supply a physical correspondence.')

hash_after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'raw').glob('*.npz')}
assert hash_after==hash_before
observer['raw_hashes_after_match']=True
(BASE/'OBSERVER_CHECKS.json').write_text(json.dumps(observer,indent=2)+'\n')
print(json.dumps({k:v for k,v in observer.items() if k!='raw_hashes_before'},indent=2))
