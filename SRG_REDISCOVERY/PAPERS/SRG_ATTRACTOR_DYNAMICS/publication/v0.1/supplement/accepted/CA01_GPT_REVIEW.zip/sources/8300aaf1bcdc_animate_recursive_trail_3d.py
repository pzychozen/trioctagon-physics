import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
import matplotlib.animation as animation
import numpy as np

# === Load ProtoSRG Recursive Embedding ===
df = pd.read_csv("ProtoSRG_1_Recursive_Embedding.csv")

# Normalize fields
df['Recursive_Weight_Norm'] = (
    df['Recursive_Weight'] - df['Recursive_Weight'].min()
) / (df['Recursive_Weight'].max() - df['Recursive_Weight'].min())

df['Curvature_Norm'] = (
    df['Curvature'] - df['Curvature'].min()
) / (df['Curvature'].max() - df['Curvature'].min())

# Curvature spikes (threshold = 90th percentile)
curv_threshold = df['Curvature_Norm'].quantile(0.9)
spike_indices = df[df['Curvature_Norm'] > curv_threshold].index

# Teleportation Events
teleport_indices = df[df['Teleport_Flag'] == 1].index

# === Initialize Plot ===
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')
ax.set_title("Animated 3D Recursive Trail of ProtoSRG_1")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")

xmin, xmax = df['X'].min(), df['X'].max()
ymin, ymax = df['Y'].min(), df['Y'].max()
zmin, zmax = df['Z'].min(), df['Z'].max()
ax.set_xlim(xmin, xmax)
ax.set_ylim(ymin, ymax)
ax.set_zlim(zmin, zmax)

trail, = ax.plot([], [], [], lw=2, color='red', label='Recursive Trail')
scatter = ax.scatter([], [], [], c=[], cmap='plasma', s=30)
curv_dots = ax.scatter([], [], [], c='cyan', s=50, label='Curvature Spike')
teleport_dots = ax.scatter([], [], [], c='white', s=50, label='Teleportation')

symbolic_labels = []

max_frames = len(df)

def init():
    trail.set_data([], [])
    trail.set_3d_properties([])
    scatter._offsets3d = ([], [], [])
    scatter.set_array(np.array([]))
    curv_dots._offsets3d = ([], [], [])
    teleport_dots._offsets3d = ([], [], [])
    for txt in symbolic_labels:
        txt.remove()
    symbolic_labels.clear()
    return trail, scatter, curv_dots, teleport_dots

def update(frame):
    x = df['X'].values[:frame]
    y = df['Y'].values[:frame]
    z = df['Z'].values[:frame]
    c = df['Recursive_Weight_Norm'].values[:frame]

    trail.set_data(x, y)
    trail.set_3d_properties(z)
    scatter._offsets3d = (x, y, z)
    scatter.set_array(c)

    # Curvature spikes up to current frame
    spikes = spike_indices[spike_indices < frame]
    curv_x = df.loc[spikes, 'X']
    curv_y = df.loc[spikes, 'Y']
    curv_z = df.loc[spikes, 'Z']
    curv_dots._offsets3d = (curv_x, curv_y, curv_z)

    # Teleportation dots
    tele_x = df.loc[teleport_indices[teleport_indices < frame], 'X']
    tele_y = df.loc[teleport_indices[teleport_indices < frame], 'Y']
    tele_z = df.loc[teleport_indices[teleport_indices < frame], 'Z']
    teleport_dots._offsets3d = (tele_x, tele_y, tele_z)

    # Symbolic ID every ~30 steps
    for txt in symbolic_labels:
        txt.remove()
    symbolic_labels.clear()
    if frame % 30 == 0 and frame < len(df):
        label = df.iloc[frame]['Symbolic_ID']
        sym_txt = ax.text(
            df.iloc[frame]['X'],
            df.iloc[frame]['Y'],
            df.iloc[frame]['Z'],
            label,
            fontsize=8,
            color='yellow'
        )
        symbolic_labels.append(sym_txt)

    return trail, scatter, curv_dots, teleport_dots

ani = animation.FuncAnimation(
    fig,
    update,
    frames=max_frames,
    init_func=init,
    interval=50,
    blit=False
)

ani.save("ProtoSRG1_Recursive_Trail_FULL.mp4", writer="ffmpeg", dpi=200)
plt.show()
