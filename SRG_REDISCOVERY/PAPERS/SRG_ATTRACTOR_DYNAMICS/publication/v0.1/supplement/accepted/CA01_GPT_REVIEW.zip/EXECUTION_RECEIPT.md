# CA01 execution and preservation receipt

21 October 2026. Local review complete; no publication action.

- Authoritative repository: `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`. Starting and ending branch `main`, HEAD `2ecc2ded685fd210bd3cda226eb9731156dc167e`.
- Every new task file is under `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA01_source_and_measurement_v0.1`. Existing accepted research, kernels, historical originals, central-crystal/Z/chirality and SRG Origins were not edited.
- All 27 substantive consumed original files and their bundled snapshots match the hashes recorded when consumed. Packet input hashes passed. Outside-task Git status listing unchanged: **True**. Tracked worktree diff is empty; staged/index diff remained empty. Existing untracked research was retained.
- This preservation statement is scoped to those sources and the status listing. It is not a bytewise claim about every untracked file elsewhere, a whole-archive preservation audit, or a remote-Git verification.
- CMD with `call conda activate torment` used Python 3.11.15, NumPy 2.4.4, SymPy 1.14.0. No dependencies installed; no environment substitution. Existing bundled Poppler rendered pages 5-8. `COMMANDS.txt` records commands and harmless pre-execution operational failures.

## Actual scientific execution

| Category | Actual count | Authorized ceiling |
|---|---:|---:|
| F3 fresh field/detector evaluations | 16, grids 100x100 or 101x101 | 16, <=201x201 |
| F4 isolated diagnostic steps | 12 | 32 |
| F4 trajectories | 1 remap-only control | 8 |
| F4 trajectory updates | 200; no extension | <=1,000 per trajectory |
| Driven baseline / nearby comparisons | 0 / 0, missing historical inputs | No invented baseline |
| Native kernel / SIM01 updates | 0 / 0 | 0 / 0 |
| Saved-data verification | 16 F3 detector records, 12 preflight records, 200 F4 transitions | Separate passive work |

One numerical run executed `run_checks.py`. No retry or extra trajectory was run. All executed branches completed with finite states; the intentionally empty F3 mask retains an undefined centroid. Printed fully clipped degeneracy and floating-mask artifacts are disclosed in the report. No scientific branch was repaired to force a result.

The original F3 percentile producer and F4 producer/parameters/data remain unrecovered. A faithful F4 driven baseline and exact reconstruction of the old figures are therefore blocked, while the permitted algebra, source distinction, remap-only control and passive views are complete.

## Verification and review artifacts

The independent checker returned `PASS_SAVED_DATA_AND_SOURCE_COPY_CONSISTENCY`. Maximum independently evaluated saved-map residual is 2.22e-16; maximum Euler residual is 1.69e-16, against predeclared 1e-12. Overlay off/on preserved raw hashes; a rigid frame change preserved distances within 1.95e-16. Exact theorems rely on the written arguments and supporting symbolic reductions, not those residual thresholds.

All five final PNGs were visually inspected for legibility, axes, native scale, opening visibility and captions. The 602-word summary is readable without a PDF. Figures are scientific controls and passive comparisons, explicitly not recovered old trajectories. No GUI viewer or native application integration was run.

`CA01_GPT_REVIEW.zip` contains the reports, checks, raw records, five PNGs, received source packet files, scoped source snapshots and a payload manifest. Cache directories and duplicate transport artifacts are excluded. `REVIEW_ZIP_RECEIPT.json` outside the ZIP records its final hash, size, CRC and payload verification. The manifest does not contain its own hash or a self-referential archive hash.

No staging, commit, push, publication, manuscript update, external upload or additional authorization request occurred.
