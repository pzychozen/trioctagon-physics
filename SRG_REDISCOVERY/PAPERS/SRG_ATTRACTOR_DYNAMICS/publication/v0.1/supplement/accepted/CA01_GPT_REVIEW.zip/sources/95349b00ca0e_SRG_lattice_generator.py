import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from sklearn.metrics.pairwise import cosine_similarity

# === Load Data ===
df = pd.read_csv("symbolic_glyphs_resonance_pass.csv")

# === Use index if 'Glyph_ID' is missing ===
if 'Glyph_ID' not in df.columns:
    df['Glyph_ID'] = df.index

# === Feature Vector Construction ===
features = ['X', 'Y', 'Z', 'Resonance_Signal', 'GRF', 'Curvature']
glyph_vectors = df[features].values
glyph_ids = df['Glyph_ID'].values

# === Cosine Similarity Matrix ===
similarity_matrix = cosine_similarity(glyph_vectors)

# === Build Graph with Similarity ≥ Threshold ===
SIMILARITY_THRESHOLD = 0.95
G = nx.Graph()

# Add nodes
for idx, gid in enumerate(glyph_ids):
    G.add_node(gid, pos=(df.at[idx, 'X'], df.at[idx, 'Y']),
               resonance=df.at[idx, 'Resonance_Signal'])

# Add edges
for i in range(len(glyph_ids)):
    for j in range(i + 1, len(glyph_ids)):
        if similarity_matrix[i, j] >= SIMILARITY_THRESHOLD:
            G.add_edge(glyph_ids[i], glyph_ids[j], weight=similarity_matrix[i, j])

# === Centrality to find SRG-∞ Seeds ===
centrality = nx.degree_centrality(G)
threshold = np.percentile(list(centrality.values()), 99)
srg_seeds = [n for n, c in centrality.items() if c >= threshold]

# === 2D Layout for Plot ===
positions = {gid: (df.at[idx, 'X'], df.at[idx, 'Y']) for idx, gid in enumerate(glyph_ids)}

# === Plot ===
plt.figure(figsize=(14, 12))
nx.draw_networkx_edges(G, positions, edge_color='gray', width=0.3, alpha=0.3)
nx.draw_networkx_nodes(G, positions, node_size=25, node_color='skyblue')
nx.draw_networkx_nodes(G, positions, nodelist=srg_seeds, node_size=80, node_color='red')

# Labels for SRG seeds
labels = {gid: f"Glyph_{gid}" for gid in srg_seeds}
nx.draw_networkx_labels(G, positions, labels=labels, font_size=6, font_color='white')

plt.title("SRG Resonance Lattice (Similarity ≥ 0.95)", fontsize=14)
plt.legend(["SRG-∞ Seeds"], loc='upper right')
plt.axis('off')
plt.tight_layout()
plt.savefig("srg_lattice.png", dpi=300)
plt.show()
