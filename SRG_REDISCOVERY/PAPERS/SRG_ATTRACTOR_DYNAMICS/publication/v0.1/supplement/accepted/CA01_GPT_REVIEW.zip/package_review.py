"""Scoped preservation, payload manifest and one local review ZIP. No Git mutations."""
from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile
BASE=Path(__file__).resolve().parent;REPO=BASE.parents[2]
def digest(b): return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def write_json(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
zip_path=BASE/'CA01_GPT_REVIEW.zip'
if zip_path.exists():raise SystemExit('Review ZIP already exists; refusing overwrite')
start=json.loads((BASE/'evidence/starting_environment.json').read_text())
reg=json.loads((BASE/'evidence/consumed_sources.json').read_text())
source_checks=[]
for orig,row in reg.items():
    b=Path(orig).read_bytes();c=(BASE/row['copy']).read_bytes()
    source_checks.append({'path':orig,'sha256_before':row['sha256'],'sha256_after':digest(b),'copy_matches':c==b,'unchanged':digest(b)==row['sha256']})
status=git('status','--porcelain=v1','--untracked-files=normal')
index=git('diff','--cached','--name-status');tracked=git('diff','--name-status')
(BASE/'evidence/ending_status.txt').write_bytes(status)
(BASE/'evidence/ending_index.txt').write_bytes(index)
head=git('rev-parse','HEAD').decode().strip();branch=git('branch','--show-current').decode().strip()
scope='SRG_REDISCOVERY/CENTRAL_ATTRACTOR_ANALYSIS/'
def outside(b):return [v for v in b.decode().splitlines() if scope not in v.replace('\\','/')]
before=(BASE/'evidence/starting_status.txt').read_bytes()
pres={'scope':'27 substantive consumed original files and their copies; Git HEAD/branch/index and outside-task status listing. No whole-tree byte census.',
      'source_checks':source_checks,'all_consumed_originals_unchanged':all(v['unchanged'] and v['copy_matches'] for v in source_checks),
      'head_before':start['head'],'head_after':head,'branch_before':start['branch'],'branch_after':branch,
      'head_branch_unchanged':head==start['head'] and branch==start['branch'],
      'index_listing_unchanged':index==(BASE/'evidence/starting_index.txt').read_bytes(),
      'tracked_worktree_diff_empty':tracked==b'','outside_task_status_listing_unchanged':outside(before)==outside(status),
      'starting_untracked_listing_lines':len(before.decode().splitlines()),'ending_untracked_listing_lines':len(status.decode().splitlines()),
      'new_output_root':str(BASE),'git_mutations_executed':False,'network_or_publication_executed':False}
assert pres['all_consumed_originals_unchanged'] and pres['head_branch_unchanged'] and pres['index_listing_unchanged'] and pres['tracked_worktree_diff_empty']
write_json(BASE/'PRESERVATION.json',pres)
V=json.loads((BASE/'VERIFICATION.json').read_text());R=json.loads((BASE/'RESULTS.json').read_text())
receipt=f'''# CA01 execution and preservation receipt

21 October 2026. Local review complete; no publication action.

- Authoritative repository: `{REPO}`. Starting and ending branch `main`, HEAD `{head}`.
- Every new task file is under `{BASE}`. Existing accepted research, kernels, historical originals, central-crystal/Z/chirality and SRG Origins were not edited.
- All {len(source_checks)} substantive consumed original files and their bundled snapshots match the hashes recorded when consumed. Packet input hashes passed. Outside-task Git status listing unchanged: **{pres['outside_task_status_listing_unchanged']}**. Tracked worktree diff is empty; staged/index diff remained empty. Existing untracked research was retained.
- This preservation statement is scoped to those sources and the status listing. It is not a bytewise claim about every untracked file elsewhere, a whole-archive preservation audit, or a remote-Git verification.
- CMD with `call conda activate torment` used Python 3.11.15, NumPy {R['environment']['numpy']}, SymPy {R['environment']['sympy']}. No dependencies installed; no environment substitution. Existing bundled Poppler rendered pages 5-8. `COMMANDS.txt` records commands and harmless pre-execution operational failures.

## Actual scientific execution

| Category | Actual count | Authorized ceiling |
|---|---:|---:|
| F3 fresh field/detector evaluations | 16, grids 100x100 or 101x101 | 16, <=201x201 |
| F4 isolated diagnostic steps | 12 | 32 |
| F4 trajectories | 1 remap-only control | 8 |
| F4 trajectory updates | 200; no extension | <=1,000 per trajectory |
| Driven baseline / nearby comparisons | 0 / 0, missing historical inputs | No invented baseline |
| Native kernel / SIM01 updates | 0 / 0 | 0 / 0 |
| Saved-data verification | 16 F3 detector records, 12 preflight records, 200 F4 transitions | Separate passive work |

One numerical run executed `run_checks.py`. No retry or extra trajectory was run. All executed branches completed with finite states; the intentionally empty F3 mask retains an undefined centroid. Printed fully clipped degeneracy and floating-mask artifacts are disclosed in the report. No scientific branch was repaired to force a result.

The original F3 percentile producer and F4 producer/parameters/data remain unrecovered. A faithful F4 driven baseline and exact reconstruction of the old figures are therefore blocked, while the permitted algebra, source distinction, remap-only control and passive views are complete.

## Verification and review artifacts

The independent checker returned `{V['status']}`. Maximum independently evaluated saved-map residual is {V['max_closed_form_P_residual']:.3g}; maximum Euler residual is {V['max_Euler_identity_residual']:.3g}, against predeclared 1e-12. Overlay off/on preserved raw hashes; a rigid frame change preserved distances within 1.95e-16. Exact theorems rely on the written arguments and supporting symbolic reductions, not those residual thresholds.

All five final PNGs were visually inspected for legibility, axes, native scale, opening visibility and captions. The 602-word summary is readable without a PDF. Figures are scientific controls and passive comparisons, explicitly not recovered old trajectories. No GUI viewer or native application integration was run.

`CA01_GPT_REVIEW.zip` contains the reports, checks, raw records, five PNGs, received source packet files, scoped source snapshots and a payload manifest. Cache directories and duplicate transport artifacts are excluded. `REVIEW_ZIP_RECEIPT.json` outside the ZIP records its final hash, size, CRC and payload verification. The manifest does not contain its own hash or a self-referential archive hash.

No staging, commit, push, publication, manuscript update, external upload or additional authorization request occurred.
'''
(BASE/'EXECUTION_RECEIPT.md').write_text(receipt,encoding='utf-8')
exclude={'MANIFEST.json','CA01_GPT_REVIEW.zip','REVIEW_ZIP_RECEIPT.json'}
payload=[p for p in BASE.rglob('*') if p.is_file() and p.name not in exclude and 'cache' not in p.relative_to(BASE).parts and '__pycache__' not in p.parts]
rows=[{'path':p.relative_to(BASE).as_posix(),'size':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted(payload)]
manifest={'package':'CA01_source_and_measurement_v0.1','date':'2026-10-21','excludes_itself':True,'files':rows,'consumed_source_registry':'evidence/consumed_sources.json'}
write_json(BASE/'MANIFEST.json',manifest)
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in payload+[BASE/'MANIFEST.json']:z.write(p,p.relative_to(BASE).as_posix())
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={r['path'] for r in rows}|{'MANIFEST.json'}
    for row in rows:
        b=z.read(row['path']);assert len(b)==row['size'] and digest(b)==row['sha256']
receipt={'archive':zip_path.name,'size':zip_path.stat().st_size,'sha256':digest(zip_path.read_bytes()),'payloads':len(rows),'members':len(rows)+1,'CRC':'PASS','manifest_hashes':'ALL_PASS','self_hash_inside_archive':False,'verification_status':V['status']}
write_json(BASE/'REVIEW_ZIP_RECEIPT.json',receipt)
print(json.dumps({'preservation':{k:v for k,v in pres.items() if k!='source_checks'},'archive':receipt},indent=2))
