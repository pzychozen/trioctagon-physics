"""Read-only inspection of the supplied start packet; does not execute packet code."""
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
print('Python:', sys.executable)
with zipfile.ZipFile(r'C:\Users\Notandi\Downloads\SRG_CA01_CODEX_START_PACKET.zip') as packet:
    for name in packet.namelist():
        if name.lower().endswith(('.md', '.txt', '.json')):
            print('\n---', name, '---\n')
            print(packet.read(name).decode('utf-8-sig'))
