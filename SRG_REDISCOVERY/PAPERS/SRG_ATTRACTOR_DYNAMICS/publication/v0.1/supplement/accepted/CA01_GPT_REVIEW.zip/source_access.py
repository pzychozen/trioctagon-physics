from pathlib import Path
import hashlib, json, sys
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[2]
def consume(path):
    path=Path(path)
    requested=path.as_posix()
    if not path.is_absolute(): path=REPO/path
    reg=BASE/'evidence'/'consumed_sources.json'
    rows=json.loads(reg.read_text()) if reg.exists() else {}
    if not path.exists():
        matches=[row for key,row in rows.items() if key.replace('\\','/').endswith('/'+requested)]
        if len(matches)!=1: raise FileNotFoundError(f'No unique pinned source for {requested}')
        row=matches[0]; data=(BASE/row['copy']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==row['sha256']
        return data
    data=path.read_bytes()
    digest=hashlib.sha256(data).hexdigest()
    key=str(path)
    if key in rows: assert rows[key]['sha256']==digest, f'Source changed: {path}'
    else:
        dest=BASE/'sources'/(digest[:12]+'_'+path.stem[:65]+path.suffix)
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
        rows[key]={'sha256':digest,'size':len(data),'copy':dest.relative_to(BASE).as_posix()}
        reg.write_text(json.dumps(rows,indent=2)+'\n')
    return data
def show(path, start=1, end=None):
    print('\n### '+str(path))
    lines=consume(path).decode('utf-8-sig',errors='replace').splitlines()
    for i,line in enumerate(lines,1):
        if i>=start and (end is None or i<=end): print(f'{i}: {line}')
if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    for arg in sys.argv[1:]:
        if '::' in arg:
            path, span=arg.split('::'); start,end=span.split(':'); show(path,int(start),int(end))
        else: show(arg)
