# SRG-CA01 — Central Attractor Analysis
## Source dynamics first; geometry as a measurement layer

**Date:** 21 October 2026  
**Scientific lead and reviewer:** GPT  
**Source review, verification and implementation:** Codex  
**Author:** Hilmir Frímann Halldórsson  
**Authorization:** Local research and the bounded checks below. Begin with read-only source inspection. No production integration, manuscript revision, staging, commit, push or publication.

## 1. The question and the author's clarified intent

> What do the historical SRG equations actually generate, which of their reported “attractors” genuinely attract, and does our existing Tri-Octagon measurement geometry help us understand that behavior?

Hilmir's drawing and Vajra/Dorje photograph communicate an arrangement for examining the dynamics. They do **not** assert that a physical toroid, hexagonal crystal, central ball, pressure mechanism or material enclosure exists. The geometry is an analytical framework: a way of displaying and measuring relationships. “At the center” names a proposed viewing/measurement location, not an established physical location or a prescribed dynamical endpoint.

Preserve the following interpretation throughout:

- The ball-like middle is a proposed place to **display and inspect** SRG behavior. Do not make the ball a particle, a new state variable, an attracting set, or a spherical boundary condition.
- The surrounding toroidal guide is closely arranged around the central analytical construction, not squeezing it. Keep the existing upper/lower triangular openings unobscured in explanatory views; do not reinterpret openings as physical ducts or exits.
- The sketch conveys this arrangement but does not accurately reproduce the accepted central crystal mesh. Use the actual source-defined mesh when an exact geometric comparison is needed. Do not rebuild it from the sketch or the photograph.
- The Vajra image is a visual analogy, not an archaeological, religious or physical premise.
- Do not ask Hilmir again whether a literal ball confines motion on its surface or in its volume. That framing has been explicitly corrected.

The research order is:

**Historical definitions → actual mathematical behavior → explicit measurement/visualization map → assessment of what, if anything, a physical interpretation would require.**

A positive result, a narrower interpretation, and a demonstrable limitation are all useful. Do not design the analysis to force a central attractor, nor to dismiss the proposed measuring framework in advance. A visualization can be useful even when it establishes no physical correspondence.

## 2. Workspace, protection and execution boundaries

Authoritative checkout:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

All new files, copies, temporary outputs and reports for this task belong under:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA01_source_and_measurement_v0.1\
```

This is a **new destination proposed by this order**, not a claim that the directory already exists. Check for an existing CA01 output before writing; preserve prior contents rather than overwriting them.

Use Windows CMD and the existing `torment` environment. Do not install dependencies, use PowerShell, change environments, run a GUI viewer, or import historical programs with top-level animation/file-writing effects. Read original programs as text. New checks may use a detached, side-effect-free transcription or an already accepted detached core only after its semantics have been checked.

Record the actual starting HEAD, branch and relevant working-tree/index status. Historical checkpoint IDs in the source notes are navigation anchors, not today's HEAD. No pull, checkout, reset, stash, cleanup or Git mutation is authorized. Do not interfere with an independently authorized SRG Origins publication or concurrent work. Attribute unrelated status changes to their actual scope; never revert them to make a receipt look clean.

Read-only protection applies to:

- `kernel_physics`, the scientific UI and any production or Historical TORMENT kernel;
- `SRG_REDISCOVERY\OLD_MATERIAL`, accepted research editions, original data and source archives;
- SRG Origins v0.1/v0.1.1 and their publication/review records;
- central-crystal/Z/chirality sources, reports and manuscript;
- SIM01 and any SIM02 work, plus all other unrelated material.

Do not run additional native Tri-Octagon kernel updates. This order studies historical SRG behavior and passive representations; it does not couple SRG into that kernel. Existing geometry and Z definitions may be inspected as references without executing their runner.

Preservation checks should be bounded to the sources actually consumed and existing working-tree changes. Do not repeat a whole-repository archaeological census or turn the first report into a large governance exercise.

## 3. Source inspection and lineage — required before numerical work

### 3.1 Primary target

The supplied `SGR_simulations.pdf`, internally titled **SGR: simulation steps**, dated 1 August 2025, is the primary historical document. Preserve its SGR/SRG spelling and operator terminology in source descriptions rather than silently standardizing its history.

```text
Size:    3,511,783 bytes
SHA-256: 2d803a28c0a9f4396149cf8700c2a772b5016574517061fb8761c3c50de1c547
Pages:   17
```

First inspect:

| Target | Definition | Figure | What the source calls it |
|---|---|---|---|
| F3 | Section 3, physical page 5 | Figure 3, page 6 | Toroidal attractor dynamics; lowest-magnitude-region centroid |
| F4 | Section 4, physical page 7 | Figure 4, page 8 | Recursive 3D triangle attractor; torque, clipping and toroidal remapping |

Read the figure images, not only extracted text. Sections 1–2 and 5–8 supply context and lineage comparisons only when needed. Do not expand this into a fresh review of the entire historical SRG programme.

Search existing source indexes and accepted recovery reports before looking through `OLD_MATERIAL`. Locate the actual producer programs and data for F3/F4 if they survive. Match using equations, parameter values, array shape, clock schedule, update order and saved records—not a similar filename or picture.

The PDF reuses filenames such as `attractor_positions.csv` across different experiments. A matching basename does not establish which figure a file produced. Distinguish missing data from data that may have been overwritten.

For each target record: printed equation; code equation; actual retained state; external clock/inputs; observation/plotting operation; parameter sources; initial conditions; source/data paths and hashes; and any unresolved differences. Keep the printed-paper and recovered-code versions separate when they differ. Neither is silently repaired to make them agree.

The F3 parameter coefficients and F4 initial state/alpha are not fully specified on the cited method pages. Recover them from the proper source when possible; do not borrow defaults from another section merely because the operator names match. Exact algebra can proceed with explicit parameters even when a faithful numerical replay cannot.

### 3.2 Reuse existing recovery, without substituting another engine

Read the relevant parts of:

```text
SRG_REDISCOVERY\SIM01_SURVIVING_RECURSIVE_MOTION\publication\v0.1\SIM01_REPORT.md
SRG_REDISCOVERY\SIM01_SURVIVING_RECURSIVE_MOTION\publication\v0.1\review\SIM01_GPT_SCIENTIFIC_REVIEW.md
SRG_REDISCOVERY\SIM01_SURVIVING_RECURSIVE_MOTION\publication\v0.1\ACCESS_AND_EVIDENCE_MAP.md
```

The preserved SIM01 family has these historical navigation anchors:

```text
A: OLD_MATERIAL\Simulations_Trash\Simulations_part_2\recursive_attractor.py
B: OLD_MATERIAL\Simulations_Trash\Simulations_part_2\3Dtriangles.py
C: OLD_MATERIAL\Simulations_Trash\Simulations_part_1\plot_1.py
```

Selection of C in SIM01 does **not** establish that C produced Figure 3 or Figure 4. Determine any relationship from source evidence. No fresh A/B/C rollout or repeated-driving experiment is authorized here. Reuse accepted findings only within their original scope and label them inherited, not newly verified.

In particular, do not merge a prescribed field sampled on a grid, a 3D point remapped to a torus surface, and a many-center process with periodic coordinate wrapping. Similar operator names do not make them one recurrence.

### 3.3 Locate the accepted measurement geometry

Read the actual local definitions and their latest applicable review. Known navigation anchors include:

```text
research\twisted_hex_crystal_registration_v0.1\CRYSTAL_HOST_REGISTRATION_REPORT.md
research\twisted_hex_crystal_registration_v0.1\verify_host_registration.py
research\twisted_hex_crystal_registration_v0.1\family_analysis\SIGNED_FAMILY_IDENTITIES.md
research\twisted_hex_crystal_registration_v0.1\family_analysis\ZERO_STATE_ANALYSIS.md
research\twisted_hex_crystal_registration_v0.1\family_analysis\TWISTED_HEX_FAMILY_ANALYSIS.md
papers\PAPER_C\publication\v1.0.1\PAPER_C_EXACT_TRIOCTAGON_GEOMETRY_PUBLICATION_v1.0.1.md
kernel_physics\geometry.py
kernel_physics\z_manifold.py
kernel_physics\readouts.py
```

Also locate, without modifying, the prior reports:

```text
Z_AND_CENTRAL_TWISTED_HEX_CRYSTAL_GEOMETRIC_RELATIONSHIP_INVESTIGATION_v0.1.md
FULL_Z_AND_CENTRAL_PASSAGE_GEOMETRY_ANALYSIS_v0.1.md
Z_CRYSTAL_REVERSAL_AND_UPPER_LOWER_CORRESPONDENCE_ANALYSIS_v0.1.md
```

Earlier source notes locate the first two under `C:\Users\Notandi\.codex\reports`. Locate the third through the current local report/manuscript index; do not invent a full path. The recovered 20 October reversal report records HEAD `3b4aa9cb64b7c218ca82962dbf3caea39d9f7d34`; this is a historical source-read checkpoint only.

That report distinguishes the refined PLUS zero **face complex** from the historical intersecting construction and from a vertex-only scaffold. Preserve actual faces, both hands where relevant, open boundaries and registration. Its family parameter tau is not elapsed time. Its placement `X = O + Z_total` belongs to the specified Z observation, not automatically to an unrelated SRG state.

Do not rerun or re-prove the completed central-geometry programme. Resolve which source-defined construction is being used, then use it only as a passive reference for this task. A missing source blocks an exact mesh overlay, not the historical SRG analysis.

## 4. F3: determine what the reported central point measures

The following is a **new diagnostic derivation to verify**, not a previously accepted F3 finding.

From the printed field, using rho for the source's planar radius to avoid notation collisions,

```math
\rho^2=X^2+Y^2,\quad
\theta=\operatorname{atan2}(Y,X)+0.05\sin(0.1t),
```

```math
U=-\frac{H(t)\sin\theta}{1+\rho^2},\qquad
V=\frac{H(t)\cos\theta}{1+\rho^2}.
```

Check symbolically that before clipping:

```math
M=\sqrt{U^2+V^2}=\frac{|H(t)|}{1+\rho^2},
```

and for the printed radial clip at threshold 1, the magnitude becomes `min(M,1)`.

Use this to investigate:

1. **State versus observation.** Does this experiment evolve a state from its previous value, or recompute a prescribed field and then measure a statistic? A sequence of detector coordinates is not automatically a trajectory generated by a point-motion law.
2. **Where the selected points actually lie.** For nonzero H, test the location of the smallest magnitudes. On a centered square grid, widely separated outer points can have a centroid at the origin. The centroid need not lie in the selected mask. Show the mask and centroid together before interpreting the central marker.
3. **Symmetry and numerical details.** Determine exact symmetry predictions and the effects of finite precision, percentile ties/interpolation, the strict `<` comparison, clipping plateaus, grid parity and any origin special case. Handle an empty mask explicitly, including H=0 or a completely flat clipped field; do not silently replace an undefined centroid by zero.
4. **The plotted wandering.** Explain which parts of Figure 3 can be recovered from the exact definition and which require the producing code/data. A finite-precision or threshold explanation is a hypothesis until checked. Do not claim to have reproduced the old path merely by drawing a similar cloud.

Do not integrate new tracer particles and call that a replay of Figure 3. Such a flow interpretation would be a separate adopted experiment. Do not assume the old reported center is either a high-intensity core or a low-intensity neighborhood without inspecting the actual selected region.

## 5. F4: separate turning, clipping, stepping and remapping

Transcribe the actual order faithfully. The printed candidate is:

```math
q_n=\alpha H(t_n)\,[s_n\times\operatorname{roll}(s_n,1)],
\quad
\widehat q_n=q_n\min\left(1,\frac{0.8}{\|q_n\|+10^{-5}}\right),
```

```math
u_n=s_n+0.1\widehat q_n,\qquad s_{n+1}=P(u_n),
```

with the source's four-term H(t), major radius R=1 and minor radius r=0.5. Verify the source's roll convention, time argument, initial-state storage and clipping order.

### 5.1 Continuous intuition versus the actual discrete step

Verify `s_n dot qhat_n = 0`. For the unprojected discrete step, check the exact identity:

```math
\|s_n+\Delta t\widehat q_n\|^2
=\|s_n\|^2+\Delta t^2\|\widehat q_n\|^2.
```

Thus a continuous torque-only norm argument must **not** be used to claim that this Euler step preserves the radius. Assess the remapping afterward as a distinct operation. Explain this distinction without portraying it as a correction to the author's current geometric intention.

### 5.2 Inspect the map that the source calls a projection

The printed angles are:

```math
\theta=\operatorname{atan2}(\sqrt{x^2+y^2},z),\qquad
\phi=\operatorname{atan2}(y,x),
```

followed by:

```math
P(x,y,z)=((R+r\cos\theta)\cos\phi,
          (R+r\cos\theta)\sin\phi,
          r\sin\theta).
```

Do **not** silently replace these angles with a conventional nearest-torus projection. Determine the map's actual image, singular cases, branch conventions and whether `P(P(s)) = P(s)`. In particular test whether the nonnegative first argument of the printed theta restricts the image to one side. A name such as “projection” does not settle those questions.

Compute what the map does when torque is zero and what happens as the prescribed H tends to zero. Separate geometry enforced by this remapping from behavior generated by the cross-product update. A bounded surface imposed by an update is not by itself evidence for the specific triangular attracting orbit described in the caption.

**Two meanings of geometry must stay distinct:** the historical P operation is part of the original numerical dynamics and must be retained in a faithful analysis; the new Tri-Octagon/crystal/toroidal viewing framework is a passive measuring layer and must not feed back into those dynamics. The author's clarification is not permission to delete a historical update operator.

### 5.3 Classify the actual long-term behavior

Determine, where the available definitions permit, fixed states or sets, possible recurring orbits, invariant regions, local stability and attraction. The drive is explicitly time-dependent; distinguish a transient, the full driven process, and a limiting map. State the applicable notion of attraction and its time convention rather than imposing an autonomous limit-cycle test blindly.

For any claim of attraction, identify the full state, admissible initial states, clock schedule, candidate set and distance being measured. Distinguish a single attracting point from convergence toward a family of points or an attracting set with neutral directions.

Figure 4's connected line segments must not be assumed to close, repeat, or attract nearby starts. Inspect the original samples and the plotting connections, mark time direction and the initial transient, and compare late behavior. A finite plot supports only the finite observations actually tested. Exact proofs, when available, should be reported separately.

## 6. Bounded verification — not an open-ended simulation campaign

Proceed from source inspection to written algebra. Reuse saved data before generating new trajectories. Mathematical analysis can continue with missing execution parameters; numerical work must not fill them in silently.

Permitted new numerical work, **only after the relevant map and parameters are explicit**:

- **F3:** At most 16 field/mask evaluations, each no larger than 201 by 201. Include the recovered source grid first. Label selected H values, degenerate cases and grid/precision comparisons as diagnostic controls, not recovered historical runs.
- **F4:** At most 32 isolated one-step preflight evaluations and 8 trajectories of at most 1,000 updates each: one source-matched baseline, up to six nearby-start comparisons, and one zero-torque/remap-only control. The original paper's 200-step horizon and any extension must be separately marked. Record the selected perturbation sizes and why the states are admissible before running. No automatic extra starts, parameter sweeps, random seeds or repeated-drive schedules.
- **Passive work:** Inspection of existing arrays and detached algebra/observer checks is allowed. Count it separately from fresh state updates. Do not rerun SIM01 or the physics-kernel test suite to pad verification counts.

These are ceilings, not work quotas. Prefer an exact argument over unnecessary runs. Missing initial conditions or alpha prevent a source-faithful baseline; report that gap and continue the parameterized analysis. A fully specified remap-only control can still be investigated on its own declared terms. Do not invent a baseline or interpret an arbitrary parameter choice as a historical reproduction.

For any new harness, preserve update order, constants and branches; keep historical and diagnostic variants distinct. Disable accidental writes/import side effects outside the new workspace. Save raw states and timestamps, pre/post-remap quantities when relevant, clipping status and any errors. Load NumPy arrays without pickle. Record actual precision, commands and comparison tolerances; do not retrofit them to obtain a preferred outcome.

Stop a numerical branch for non-finite values, missing semantics, source mismatch or exhausted budget. Preserve and explain the failed case; do not repair the dynamics in place. Ask for additional authorization only for a genuine expansion, not for routine completion of the work above.

## 7. Use the geometry to observe, not manufacture, a result

After the native analysis, design the smallest useful passive view. Write its map explicitly:

```math
s_{n+1}=F(s_n,t_n),\qquad y_n=\mathcal O(s_n,t_n;\text{declared view settings}).
```

For F3, substitute the actual field/detector objects rather than pretending a state recurrence has been established. In all cases, there is **no feedback arrow from the new view to F**.

### Required comparison

Show the same saved quantities in:

1. their native coordinates, with source scale and time clearly identified;
2. a central analytical view using the recovered geometric reference, when a well-defined map can be specified.

Specify origin, axes, handedness, units or lack of calibration, translation, fixed scale, angle conventions and any discarded information. A source position vector, a three-component channel quantity and a plotted Z vector are not interchangeable merely because all have three entries.

Start with a fixed, transparent placement rather than per-frame recentering or normalization. Any convenient placement in the middle is a display choice, not a deduction that the native dynamics occur at that geometric center. Do not resize every orbit to fit a ball, project it to a sphere, or tune a scale/rotation until a desired symmetry appears. Preserve native distances and the stated conversion for displayed distances.

If no canonical SRG-to-geometry map has been recovered, say so. A clearly labeled illustrative placement may still be useful, but cannot establish a native geometric correspondence. Leave the proposed surrounding toroidal guide schematic when its exact dimensions have not been specified. Do not create a “derived” radius or physical coupling to complete the picture.

### Observer controls

- Turning the geometry overlay off must leave every saved SRG state unchanged.
- Changing camera or a fixed coordinate frame must not change the underlying dynamical classification. Explain which displayed distances scale and which tested relations are invariant.
- Keep radial magnitude when using angular coordinates; document singularities and wrapping. A periodic coordinate jump or a normalization-induced cluster is not automatically physical motion or attraction.
- Distinguish simulation time, forcing time, observer clock and frame number. A clock-dependent shrinking display can look convergent even for a frozen state; test that possibility when a chosen observer has such dependence.
- Do not apply the existing Z observer to unrelated SRG variables without a stated domain map. No SRG-to-Z bridge, observer feedback, crystal evolution or new native kernel step is authorized.
- Keep upper/lower triangular openings recognizable; do not close faces or use a physical collision/containment rule to make a plot look correct. Points outside a displayed central window must be disclosed, not removed as “invalid.”

The desired outcome is an explanation of what the geometry reveals: for example an existing symmetry, a clear separation of radial and angular behavior, or a useful comparison of observer and state. “It provides a readable visualization but no additional invariant” is a valid finding. Do not substitute decorative resemblance for a measured relationship.

## 8. Answer the physical question without guessing a substance

Hilmir asked whether the SRG attractor is thermodynamics, magnetism or light. Answer from the supplied definitions, not from the shapes or operator names.

For each proposed interpretation state what variables, units, governing relations and empirical correspondence are actually supplied. A prescribed H(t) called a memory curve is not automatically accumulated memory; identify where earlier state is genuinely retained. Similarly, a cross product, a decay factor, a clipping threshold, an energy-like diagnostic or a toroidal picture must not alone select a physical interpretation.

Use a concise distinction:

**Established mathematical behavior / possible analogy / missing physical identification.**

Do not declare that a physical connection is impossible because it has not been supplied. Do not import a magnetic field, pressure, temperature, entropy law, electromagnetic wave model or new force to supply the missing identification. An optional comparison with an outside physical law must cite a primary source and remain explicitly separate from the recovered model. No broad physics literature survey is needed in this first pass.

## 9. Deliverables and the first review checkpoint

Produce one compact local review package, not a publication manuscript or a new software product:

1. **`READ_ME_FIRST.md`** — roughly 400–700 words in ordinary language. Answer: What is moving or being measured? Does it genuinely attract? What creates the apparent central/triangular pattern? What does our geometric view add? Do the equations identify heat, magnetism or light? What remains unresolved? Say plainly what, if anything, the author needs to clarify; do not hand routine source recovery back to him.
2. **`CA01_ANALYSIS.md`** — source-led mathematical analysis, with exact equations, proofs/conditions, finite results and limitations. Separate historical claims, new deductions, numerical evidence, display choices and missing specifications.
3. **`SOURCE_AND_CLAIM_MAP.md`** — F3/F4 provenance, exact locators, code/paper differences, geometry source identity, and which prior accepted findings were reused. Include a brief table saying whether any mismatch is in an old caption, a producer, a detector, or the new interpretation—not a vague statement that “the theory is wrong.”
4. **Checks, raw results and a few readable PNGs** — detached scripts and a machine-readable results file; raw data for any fresh tests; F3 magnitude/mask/centroid view, F4 time-resolved/native view, and a passive geometry comparison when justified. Give every figure a plain caption distinguishing observed motion from imposed/view geometry. A static offline viewer is optional; no UI integration.
5. **One review ZIP and a short preservation/execution receipt** — include a manifest of review payloads and consumed-source identities, commands, actual fresh versus inherited counts, and the scoped before/after status. Keep generated logs and duplicate build products out unless needed to reproduce a finding. Do not include a self-referential archive hash in its own manifest.

Keep the first summary readable without opening a PDF. A PDF is not required for this checkpoint. Do not write another long paper before explaining the result.

### Completion criteria

The report distinguishes F3's detector from F4's evolving state; source-native remapping from the new passive measuring geometry; numerical boundedness from proved attraction; and mathematical behavior from a physical label. It provides an explicit, honest geometry-view map or a precise account of why that map is still only illustrative. Missing historical producers remain visible rather than being replaced by a different SRG engine.

No particular attractor shape, physical interpretation or geometric success is required for completion. Do not pause after the source inventory merely to request another routine approval: complete the permitted analysis and return the bounded findings. Stop only a genuinely blocked branch and explain the blocker while completing independent parts.

**End state: local research ready for GPT and Hilmir's review. No changes to accepted models, existing manuscripts or publications. No stage, commit, push, release or external upload.**
