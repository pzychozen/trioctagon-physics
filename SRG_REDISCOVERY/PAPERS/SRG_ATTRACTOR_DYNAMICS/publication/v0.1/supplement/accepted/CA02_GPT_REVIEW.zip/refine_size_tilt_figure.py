"""Layout-only revision of figure 2 from saved arrays; no state advances or new diagnostics."""
from pathlib import Path
import json, os
BASE=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(BASE/'cache/MPLCONFIGDIR')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=json.loads((BASE/'ENDPOINT_RESULTS.json').read_text())
E={r['id']:r for r in R['endpoints']}
keys_all=['Bhalf','A0p','Bthreehalf','Czero','Cquarter']
arrays={}
for key in keys_all:
    with np.load(BASE/'raw'/f'{key}.npz',allow_pickle=False) as f:arrays[key]=f['phase_lift'].copy()
def circ(v):return np.arctan2(np.sin(v),np.cos(v))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.titleweight':'bold','savefig.facecolor':'white'})
gray='#777777';orange='#b85c00';green='#168078'
fig,axs=plt.subplots(2,2,figsize=(12.6,8.4),layout='constrained')
groups=[(['Bhalf','A0p','Bthreehalf'],['½ × size','Reference','1½ × size'],'Size changes, direction fixed'),
        (['Czero','A0p','Cquarter'],['Tilt 0','Reference tilt','Tilt π/4'],'Tilt changes, norm and azimuth fixed')]
colors=[orange,gray,green]
for col,(keys,labels,title) in enumerate(groups):
    ax=axs[0,col]
    for i,(key,color) in enumerate(zip(keys,colors)):
        difference=float(circ(E[key]['phase_800_lift']-E['A0p']['phase_800_lift']))
        linear=(E[key]['analytic_D_at_zero']-E['A0p']['analytic_D_at_zero'])/32
        ax.scatter(i,difference,s=70,color=color,zorder=3)
        ax.scatter(i,linear,s=85,marker='s',facecolors='none',edgecolors=color,linewidths=1.4,zorder=2)
        ax.annotate(f'{difference:+.6f}',(i,max(difference,linear)),xytext=(0,12),
                    textcoords='offset points',ha='center',fontsize=9)
    ax.axhline(0,color=gray,lw=1,ls=':')
    ax.set(xticks=range(3),xticklabels=labels,ylabel='Angular difference from reference (rad)',title=title)
    ax.margins(x=.2,y=.3)
    ax=axs[1,col]
    ref=arrays['A0p']
    for key,color,label in zip(keys,colors,labels):
        if key=='A0p':continue
        diff=circ(arrays[key]-ref)
        ax.plot(np.arange(801),diff,color=color,lw=1.7,label=label)
    ax.axhline(0,color=gray,lw=1,ls=':')
    ax.set(xlabel='Update index n',ylabel='Angular difference from reference (rad)',title='Angular trace accumulated during the drive')
    ax.legend(fontsize=9)
fig.suptitle('CA02 · Size and tilt leave separate angular traces',fontsize=17,fontweight='bold')
fig.supxlabel('All α = +1/32. Filled circles: state 800; open squares: first-order prediction.\n'
              'Lines connect discrete saved samples. Reference is s*(0); all endpoints approach the same circle.\n'
              f"Two-trajectory exact-tail allowance ≈ {2*R['exact_tail_estimate_a']:.2e} rad; accumulated floating error is not enclosed.",fontsize=10)
fig.savefig(BASE/'figures/02_size_and_tilt.png',dpi=170);plt.close(fig)
print('Figure 2 labels separated from prediction markers; saved trajectories unchanged.')
