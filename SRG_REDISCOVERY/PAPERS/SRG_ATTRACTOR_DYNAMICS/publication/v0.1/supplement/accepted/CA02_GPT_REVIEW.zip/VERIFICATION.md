# CA02 verification and preservation

**PASS within the declared consistency criteria.** Proofs and finite checks are distinct; this is not a count of mathematical theorems.

## Execution and limits

| Quantity | Actual |
|---|---:|
| Fresh trajectories | 16 |
| Updates per trajectory | 800 |
| Fresh state-advance calls | 12,800 |
| Additional isolated fresh calls | 0 |
| Failed fresh calls | 0 |
| Inherited fixture evaluations | 12 |
| Inherited saved-transition evaluations | 200 |
| Passive post-run saved-record checks | 12,800 |
| Native kernel updates | 0 |
| Numerical child launches | 1 |
| Supervisor wall time | 2.0 seconds / 600 allowed |
| Workspace bytes at numerical-stage end | 2,230,981 / 250,000,000 allowed |

The preliminary 212 evaluations used independent saved inputs and matched every recorded primary value exactly (maximum discrepancy zero). The 200 computed outputs were never fed into later inputs. The post-run checks used saved records and independent component/closed-form expressions; they were not new trajectories. No extra alpha=0, axis probe, alternative clock or high-precision trajectory was run.

## Arithmetic and measurement checks

All thresholds below were 1e-12. Scale-aware residuals divide by max(1, ||s||², ||u||²).

| Diagnostic | Maximum residual |
|---|---:|
| component_torque | 0 |
| independent_H | 0 |
| qhat | 0 |
| pre_remap | 0 |
| closed_form_P | 4.4408921e-16 |
| successor_storage | 0 |
| euler_abs | 7.4654772e-16 |
| euler_scaled | 4.6196534e-16 |
| perpendicular_abs | 5.5511151e-17 |
| perpendicular_scaled | 2.1887119e-17 |
| surface_abs | 1.6653345e-16 |
| angle_increment_vs_saved_azimuth | 2.4492936e-16 |
| lift_vs_saved_azimuth | 1.130139e-14 |
| lift_vs_fsum_increments | 6.2172489e-15 |
| distance_storage | 0 |

Every clip factor was one; clipped records: 0. Maximum raw torque was 0.480743177153, below the analytic initial cap 729/1024 and clipping threshold .8-1e-5. Maximum torque after the first update was 0.258281870376, below 81/256. Minimum short-segment horizontal-radius lower bound was 0.589426836431; minimum angular denominator was 0.348735076385. Remaps were finite and off-axis and all post-remap heights were nonnegative.

The forcing time is exactly the saved binary64 evaluation of .1*n; alpha, successor linkage, input definitions and n=0..800 storage were checked. Raw arrays are non-pickle NPZ and are protected by SHA-256 values in RUN_RESULTS.json and MANIFEST.json. Four extracted function ASTs match the accepted definitions; no original module was imported.

The exact-tail formula is retained in the analysis. Its ordinary estimates are 2.1389587898e-11 rad at a and 1.0694793949e-11 at a/2. It bounds exact future angular increments only. Neither that formula nor the residual table bounds accumulated binary64 errors. Coefficient rounding and finite-h truncation are also separate. The C³ argument establishes the central-difference remainder form with an unquantified third-derivative supremum.

## Preservation and review

All 10 consumed original artifacts, including CA01's accepted archive, retained their bytes and SHA-256 identities. Input copies still match. The supplied CA02 packet also retained its hash. No whole-repository census was performed.

HEAD before and after: `2ecc2ded685fd210bd3cda226eb9731156dc167e`; branch: `main`. Index bytes unchanged: True. Normal status bytes unchanged: True. Tracked worktree name/status output is empty.

Task writes were confined to CA02. Existing untracked research was preserved. Source protection is supported by the explicit consumed-source hashes and repository receipts; it is not presented as a byte-level census of every unrelated file.

Environment: 3.11.15 | packaged by Anaconda, Inc. | (main, Mar 11 2026, 17:12:15) [MSC v.1942 64 bit (AMD64)]; NumPy 2.4.4; Matplotlib 3.10.9. All Python execution used CMD and the torment environment, with bytecode disabled. No installations occurred.

The two figures were visually inspected. Figure 2 had a layout-only label adjustment from saved data. The plan and primary evaluator remain unchanged. The plan’s scalar 40-term wording is made explicit as n=0 plus correction n=1..39; the exact remainder starts at n=40. This has no effect on the fresh-call budget.

Start with READ_ME_FIRST.md, then the analysis, endpoint/derivative tables and raw records. The source map distinguishes inherited claims, new derivations, finite evidence and unresolved questions. Review the saved evidence without rerunning the numerical launcher. The final ZIP receipt is outside the archive to avoid circular self-hashing.
