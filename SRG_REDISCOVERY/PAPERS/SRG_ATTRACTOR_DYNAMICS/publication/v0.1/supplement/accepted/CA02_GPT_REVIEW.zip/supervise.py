"""Exactly one numerical child launch; 600-second timeout; never automatically restart."""
from pathlib import Path
import datetime, json, os, subprocess, sys, time
BASE=Path(__file__).resolve().parent
launch=BASE/'evidence/NUMERICAL_LAUNCH.json'
command=[sys.executable,'-B',str(BASE/'run_diagnostics.py')]
record=dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,
            cwd=str(BASE),timeout_seconds=600,launch_count=1,automatic_restart=False)
with launch.open('x') as f:json.dump(record,f,indent=2)
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
for key in ('TMP','TEMP','MPLCONFIGDIR'):
    folder=BASE/'cache'/key;folder.mkdir(parents=True,exist_ok=True);env[key]=str(folder)
t=time.monotonic()
with (BASE/'evidence/numerical_stdout.txt').open('wb') as log:
    try:
        child=subprocess.run(command,cwd=BASE,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
        record['returncode']=child.returncode
        record['supervisor_status']='COMPLETED' if child.returncode==0 else 'CHILD_FAILED'
    except subprocess.TimeoutExpired:
        record['supervisor_status']='TIMEOUT_KILLED_NO_RESTART'
record['elapsed_seconds']=time.monotonic()-t
launch.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((BASE/'evidence/numerical_stdout.txt').read_text())
