"""Finish read-only preservation checks and package the completed local CA02 evidence."""
from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[2]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):
    (BASE/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
archive=BASE/'CA02_GPT_REVIEW.zip'
assert not archive.exists(), 'Final archive already exists; do not silently rebuild'
R=json.loads((BASE/'RUN_RESULTS.json').read_text())
V=json.loads((BASE/'VERIFICATION.json').read_text())
start=json.loads((BASE/'evidence/START.json').read_text())
assert R['status']=='COMPLETED' and V['status']=='PASS'
assert R['counts']['fresh_rollout_calls']==12800 and R['counts']['fresh_isolated_calls']==0
assert R['counts']['fresh_trajectories_completed']==16 and not R['errors']
checked=[]
for old in json.loads((BASE/'evidence/SOURCES_BEFORE.json').read_text()):
    path=Path(old['path']);content=path.read_bytes()
    unchanged=sha(content)==old['sha256'] and len(content)==old['size']
    assert unchanged, f'Consumed source changed: {path}'
    if old['copy']: assert (BASE/old['copy']).read_bytes()==content
    checked.append({**old,'unchanged':unchanged})
for name in ['status','index']:
    value=git('status','--porcelain=v1','--untracked-files=normal') if name=='status' else git('diff','--cached','--name-status')
    (BASE/f'evidence/{name}_after.txt').write_bytes(value)
head=git('rev-parse','HEAD').decode().strip()
branch=git('branch','--show-current').decode().strip()
tracked=git('diff','--name-status')
(BASE/'evidence/tracked_worktree_after.txt').write_bytes(tracked)
before_status=(BASE/'evidence/status_before.txt').read_bytes()
after_status=(BASE/'evidence/status_after.txt').read_bytes()
before_index=(BASE/'evidence/index_before.txt').read_bytes()
after_index=(BASE/'evidence/index_after.txt').read_bytes()
assert head==start['HEAD'] and branch==start['branch']
assert before_index==after_index
extract=json.loads((BASE/'evidence/MODEL_EXTRACTION.json').read_text())
for name in ['CA02_PLAN.md','run_diagnostics.py','supervise.py']:
    assert sha((BASE/name).read_bytes())==extract['before_fresh_execution'][name]
assert sha((BASE/'model.py').read_bytes())==extract['model_sha256']
for row in R['runs']:
    assert sha((BASE/row['raw']).read_bytes())==row['raw_sha256']
packet=Path(r'C:\Users\Notandi\Downloads\SRG_CA02_CODEX_START_PACKET.zip')
assert sha(packet.read_bytes())==start['packet_sha256']
preservation=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),consumed_sources=checked,
    all_consumed_sources_unchanged=True,packet_unchanged=True,HEAD_before=start['HEAD'],HEAD_after=head,
    branch_before=start['branch'],branch_after=branch,index_bytes_unchanged=before_index==after_index,
    status_bytes_unchanged=before_status==after_status,tracked_worktree_name_status=tracked.decode(),
    status_scope='Normal Git porcelain listing, not a whole-repository file census. Pre-existing untracked work retained.',
    writes='Task file writes confined to CA02; no stage/commit/push/publication action.',
    unchanged_plan_and_primary_evaluator=True)
write('evidence/PRESERVATION.json',preservation)
summary=(BASE/'READ_ME_FIRST.md').read_text(encoding='utf-8')
word_count=len(summary.split())
assert word_count<=700,word_count
assert len(list((BASE/'figures').glob('*.png')))==2
assert not list(BASE.rglob('*.pyc'))
qa=dict(summary_words=word_count,figures=2,visual_inspection='Both PNGs inspected; figure 2 label placement refined without a trajectory rerun.',
    figure_01='Legible axes, +/- coupling markers, first-order estimates, finite-h discrepancies and tail caveat.',
    figure_02='Separate size and equal-norm tilt panels; endpoint differences and all 801 saved phase differences.',
    passive_checks_after_rollout=12800,fresh_calls_after_stage=0,extra_isolated_calls=0,
    scalar_coefficient_convention='M=40: initial n=0 contribution and correction n=1..39; bound begins at n=40.',
    unresolved='No certified accumulated floating enclosure or global endpoint injectivity classification.')
write('evidence/DELIVERY_CHECKS.json',qa)
maxima=V['residual_maxima']
lines=['# CA02 verification and preservation','',
       '**PASS within the declared consistency criteria.** Proofs and finite checks are distinct; this is not a count of mathematical theorems.','',
       '## Execution and limits','',
       '| Quantity | Actual |','|---|---:|',
       '| Fresh trajectories | 16 |','| Updates per trajectory | 800 |','| Fresh state-advance calls | 12,800 |',
       '| Additional isolated fresh calls | 0 |','| Failed fresh calls | 0 |',
       '| Inherited fixture evaluations | 12 |','| Inherited saved-transition evaluations | 200 |',
       '| Passive post-run saved-record checks | 12,800 |','| Native kernel updates | 0 |',
       '| Numerical child launches | 1 |','| Supervisor wall time | 2.0 seconds / 600 allowed |',
       f"| Workspace bytes at numerical-stage end | {R['workspace_bytes_at_stage_end']:,} / 250,000,000 allowed |",'',
       'The preliminary 212 evaluations used independent saved inputs and matched every recorded primary value exactly (maximum discrepancy zero). The 200 computed outputs were never fed into later inputs. The post-run checks used saved records and independent component/closed-form expressions; they were not new trajectories. No extra alpha=0, axis probe, alternative clock or high-precision trajectory was run.','',
       '## Arithmetic and measurement checks','',
       'All thresholds below were 1e-12. Scale-aware residuals divide by max(1, ||s||², ||u||²).','',
       '| Diagnostic | Maximum residual |','|---|---:|']
for name,value in maxima.items():lines.append(f'| {name} | {value:.8g} |')
lines+=['',f"Every clip factor was one; clipped records: {V['clipped_records']}. Maximum raw torque was {V['max_raw_torque']:.12g}, below the analytic initial cap 729/1024 and clipping threshold .8-1e-5. Maximum torque after the first update was {V['max_post_initial_raw_torque']:.12g}, below 81/256. Minimum short-segment horizontal-radius lower bound was {V['minima']['segment_rho_lower']:.12g}; minimum angular denominator was {V['minima']['angle_denominator']:.12g}. Remaps were finite and off-axis and all post-remap heights were nonnegative.",'',
       'The forcing time is exactly the saved binary64 evaluation of .1*n; alpha, successor linkage, input definitions and n=0..800 storage were checked. Raw arrays are non-pickle NPZ and are protected by SHA-256 values in RUN_RESULTS.json and MANIFEST.json. Four extracted function ASTs match the accepted definitions; no original module was imported.','',
       'The exact-tail formula is retained in the analysis. Its ordinary estimates are 2.1389587898e-11 rad at a and 1.0694793949e-11 at a/2. It bounds exact future angular increments only. Neither that formula nor the residual table bounds accumulated binary64 errors. Coefficient rounding and finite-h truncation are also separate. The C³ argument establishes the central-difference remainder form with an unquantified third-derivative supremum.','',
       '## Preservation and review','',
       f"All {len(checked)} consumed original artifacts, including CA01's accepted archive, retained their bytes and SHA-256 identities. Input copies still match. The supplied CA02 packet also retained its hash. No whole-repository census was performed.",'',
       f'HEAD before and after: `{head}`; branch: `{branch}`. Index bytes unchanged: {before_index==after_index}. Normal status bytes unchanged: {before_status==after_status}. Tracked worktree name/status output is '+('empty.' if not tracked else 'saved for review.'),'',
       'Task writes were confined to CA02. Existing untracked research was preserved. Source protection is supported by the explicit consumed-source hashes and repository receipts; it is not presented as a byte-level census of every unrelated file.','',
       f"Environment: {V['software']['python']}; NumPy {V['software']['numpy']}; Matplotlib {V['software']['matplotlib']}. All Python execution used CMD and the torment environment, with bytecode disabled. No installations occurred.",'',
       'The two figures were visually inspected. Figure 2 had a layout-only label adjustment from saved data. The plan and primary evaluator remain unchanged. The plan’s scalar 40-term wording is made explicit as n=0 plus correction n=1..39; the exact remainder starts at n=40. This has no effect on the fresh-call budget.','',
       'Start with READ_ME_FIRST.md, then the analysis, endpoint/derivative tables and raw records. The source map distinguishes inherited claims, new derivations, finite evidence and unresolved questions. Review the saved evidence without rerunning the numerical launcher. The final ZIP receipt is outside the archive to avoid circular self-hashing.','']
(BASE/'VERIFICATION.md').write_text('\n'.join(lines),encoding='utf-8')
excluded={'MANIFEST.json','CA02_GPT_REVIEW.zip','REVIEW_ZIP_RECEIPT.json'}
payload=[]
for path in sorted(BASE.rglob('*')):
    if not path.is_file():continue
    rel=path.relative_to(BASE)
    if rel.parts[0]=='cache' or str(rel).replace('\\','/') in excluded:continue
    data=path.read_bytes()
    payload.append(dict(path=rel.as_posix(),size_bytes=len(data),sha256=sha(data)))
assert sum(row['size_bytes'] for row in payload)<250_000_000
manifest=dict(scope='Completed CA02 local research review; no publication approval',
    files=payload,exclusions=['cache/**','manifest self-hash','review ZIP self-hash','external ZIP receipt'],
    payload_count=len(payload),fresh_rollout_calls=12800,figures=2)
write('MANIFEST.json',manifest)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
    for row in payload:zf.write(BASE/row['path'],row['path'])
    zf.write(BASE/'MANIFEST.json','MANIFEST.json')
with zipfile.ZipFile(archive) as zf:
    assert zf.testzip() is None
    assert len(zf.namelist())==len(payload)+1
    assert json.loads(zf.read('MANIFEST.json'))==manifest
    for row in payload:
        data=zf.read(row['path'])
        assert len(data)==row['size_bytes'] and sha(data)==row['sha256']
assert git('rev-parse','HEAD').decode().strip()==head
assert git('diff','--cached','--name-status')==after_index
receipt=dict(archive=str(archive),size_bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    manifest_payloads_verified=len(payload),archive_members=len(payload)+1,CRC='PASS',
    summary_words=word_count,figures=2,HEAD=head,all_consumed_sources_unchanged=True,
    numerical_stage_complete=True,publication=False)
write('REVIEW_ZIP_RECEIPT.json',receipt)
print(json.dumps(receipt,indent=2))
