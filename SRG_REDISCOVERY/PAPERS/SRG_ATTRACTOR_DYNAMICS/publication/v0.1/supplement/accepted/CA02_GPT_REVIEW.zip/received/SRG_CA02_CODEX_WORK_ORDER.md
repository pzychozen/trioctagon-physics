# CA02 — Initial-state retention in the limiting position

**Date:** 21 October 2026  
**Scientific lead:** GPT · **Analysis and implementation:** Codex · **Author:** Hilmir Frímann Halldórsson  
**Status:** New local research work order; CA01 is the accepted input, not a write target.  
**Authorization:** Source inspection, written mathematical analysis, and the bounded detached diagnostics below. No kernel changes, manuscript changes, Git writes, or publication.

## 1. The question, in ordinary language

CA01 showed that Figure 4's printed equations settle to a point on a particular circle. Different starts can finish at different points. The next question is:

> **What about the starting state determines where it finishes—and what is genuinely forgotten?**

Do not investigate whether a physical ball, crystal or torus holds a particle. Hilmir's geometric construction is an analytical and visual reference. “At the center” describes the intended inspection view, not a physical container or a boundary condition. The historical toroidal remap is different: it is already an active operation in the printed equations, and must remain in the update.

Here, “retention” or “memory” means a demonstrable dependence of the final position on earlier state. It does not by itself mean learning, information capacity, thermodynamics, a material memory device, or a calibrated physical quantity.

The immediate deliverable is a readable explanation with supporting mathematics and a small, declared comparison—not another publication manuscript, an animation project, or a new SRG engine.

## 2. Workspace, sources and preservation

Authoritative checkout:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

Accepted CA01 source directory:

```text
SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA01_source_and_measurement_v0.1\
```

Create the separate output directory:

```text
SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA02_endpoint_retention_v0.1\
```

Use Windows CMD and the existing `torment` environment. Put new code, caches, numerical results, figures and review files only in CA02. Disable bytecode writes or redirect them there. Read source modules as text; do not import scripts with execution at module level. No dependency installation, GUI launch, kernel import, or original runner invocation.

Read these sources first, using local originals and the attached reference copies as cross-checks:

- **[S1]** `CA01_ANALYSIS.md`, especially §§3–5: complete update, convergence theorem and passive observer.
- **[S2]** `CA01_GPT_SCIENTIFIC_REVIEW.md`, especially §§4–5 and §8. The packet includes the accepted review; it may not already be in the local CA01 directory.
- **[S3]** CA01's `run_checks.py` as text, `RESULTS.json`, and `raw/F4_remap_only.npz`: arithmetic and saved fixtures, not scripts to rerun.
- **[S4]** CA01's `SOURCE_AND_CLAIM_MAP.md`, `evidence/consumed_sources.json`, and `MANIFEST.json`: identities and source gaps.
- **[S5]** `received/inputs/SGR_simulations.pdf`, physical p.7 and Figure 4 on p.8, only as needed to resolve a source detail. Preserve the distinction between its wording and the accepted conditional analysis.
- **[S6]** `evidence/geometry_reference.npz` and the relevant passive-view definitions, only for the optional geometric comparison.

The original CA01 review ZIP has SHA-256:

```text
f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0
```

The accepted GPT review has SHA-256:

```text
9ce79ca882ab29a2ba07e14caf8b927cbfac8aa08385ab7b59fb47955ed1d317
```

Check identities of consumed inputs before use. Record actual local HEAD and relevant index/status at start and finish; do not assume an old checkpoint is current. Do not perform a whole-repository census. Preserve CA01, all historical sources, SRG Origins, SIM01/SIM02, the central-crystal/Z/chirality work, both kernels, and unrelated changes. Concurrent unrelated changes must not be reverted to produce a clean receipt.

No pull, checkout, reset, stash, stage, commit, push, release or external upload is authorized. Prior approval to publish SRG Origins is not authorization for this lane. No extra historical-source search is needed: missing Figure 4 producer inputs remain a documented limitation.

## 3. Accepted starting point: do not merge it with new results

Use the printed-map completion accepted in CA01:

\[
C(x,y,z)=(z,x,y),\qquad t_n=0.1n,
\]
\[
H(t)=2e^{-0.5t}\cos t+e^{-0.3t}\sin t+1.5e^{-0.7t}+e^{-0.4t},
\]
\[
q_n=\alpha H(t_n)(s_n\times Cs_n),\qquad
\widehat q_n=q_n\min\left(1,\frac{0.8}{\|q_n\|+10^{-5}}\right),
\]
\[
u_n=s_n+0.1\widehat q_n,\qquad s_{n+1}=P(u_n).
\]

For an off-axis input, with \(\rho=\sqrt{x^2+y^2}>0\), \(L=\|s\|\),

\[
P(s)=\left(\left(1+\frac z{2L}\right)\frac x\rho,
\left(1+\frac z{2L}\right)\frac y\rho,\frac\rho{2L}\right).
\]

The historical implementation form uses `atan2(rho,z)` and `atan2(y,x)` followed by the torus parametrization. Preserve that operation order in the detached primary evaluator; use the closed form as an independent check, not a silent replacement. The roll convention is the declared CA01 reading, not recovered producer code. Do not substitute continuous-time integration or an orthogonal rotation for the Euler step.

CA01 established:

1. Positive scale is erased by **P alone**, azimuth is preserved by P, and repeated P contracts the other angular coordinate.
2. The fixed circle of P is
   \[
   \mathcal C=\{s_*(\phi):\phi\in S^1\},\quad
   s_*(\phi)=(\rho_*\cos\phi,\rho_*\sin\phi,z_*),
   \]
   \[
   \rho_*=(3+\sqrt3)/4,\qquad z_*=\tfrac12\sqrt{\sqrt3/2}.
   \]
3. For the accepted off-axis/admissible domain, fixed finite alpha, exact arithmetic and the advancing clock above, the driven recurrence converges to some point on C. C need not be invariant at each driven finite-time step.
4. On an initial torus latitude, the limiting angular map is continuous of degree one and onto. This does **not** establish injectivity, monotonicity, or a one-to-one memory of every start.
5. CA01 executed only one 200-step alpha=0 trajectory. Its driven convergence theorem is not a previously run nonzero-alpha experiment.

C is a family of possible endpoints, not a persistent circular orbit. None of these claims identifies heat, magnetism or light. Do not reopen Figure 3 or infer a new SRG-to-Z correspondence.

## 4. Mathematical analysis — main priority

### 4.1 Define exactly what “survives” means

Define the limiting endpoint and its angular label, with the starting forcing clock held fixed:

\[
E_\alpha(s_0)=\lim_{n\to\infty}s_n
=s_*(\Phi_\alpha(s_0)\bmod 2\pi).
\]

State the domain and angle-lift convention. Separate:

- immediate erasure by one operation;
- contraction over repeated steps;
- an initial difference that changes the eventual angular endpoint;
- two different starts with the same endpoint.

An endpoint on a one-dimensional circle cannot be described as an independently recoverable record of all three continuous initial coordinates without justification. Dependence on several initial coordinates is not the same as recovering them separately. Describe local sensitivity/rank and level sets where supportable; do not invent an entropy or capacity score.

For a start at update k, use a time-indexed endpoint map. Check the appropriate relation between that map and the next update. Do not write an autonomous invariance identity by accidentally resetting H to its initial value after each step.

### 4.2 Solve the remap-only retention question exactly

For alpha=0, derive the endpoint map on the smooth off-axis domain and describe which starts share an endpoint. Show precisely what happens to positive radial scale, inclination and azimuth. Separate finite-time loss of radial scale from asymptotic loss of the remaining contracting coordinate. Use the inherited trajectory as an illustration; a new alpha=0 rollout is unnecessary.

This is the control against which the driven result is compared. It is not a model of a literal sphere shrinking onto a ring.

### 4.3 Can the drive transfer an otherwise-erased difference into azimuth?

For nonzero alpha, establish whether the initial positive scale or inclination can influence the endpoint by changing the pre-remap torque. Do not infer that the **full update** erases scale merely because P does. Conversely, do not assume every initial difference survives.

A useful route is to derive the exact angular increment for \(e_n=0.1\widehat q_n\):

\[
\Delta\phi_n=\operatorname{atan2}
\left(x_ne_{n,y}-y_ne_{n,x},
\rho_n^2+x_ne_{n,x}+y_ne_{n,y}\right),
\]

with the continuous short-segment lift justified on the nonsingular region. Verify the expression and its branch conditions before use. Then write the endpoint phase as the initial lift plus the convergent sum of increments. This expression is a CA02 derivation target, not an additional accepted CA01 theorem.

Identify nontrivial examples of retention or erasure, as the equations support. Examine exceptional directions where an initial scale change has no effect. A first-step difference alone is not proof of different limiting endpoints; support the endpoint claim using analysis or a declared numerical comparison with error qualifications.

### 4.4 First-order endpoint response near zero drive

Investigate the derivative of the lifted endpoint phase with respect to alpha at alpha=0. Derive the angular contribution of the cross product on the unforced trajectory. Establish the conditions needed to interchange a derivative and an infinite limit/sum; do not silently assume them.

Begin with starts on C, where the unforced state is constant. This should simplify the candidate response to an angular factor times a discrete sum of the prescribed H values. Evaluate that sum by its convergent geometric/trigonometric series when justified. Then examine positive-ray variants and the two equal-norm tilt variants in §5.

The concrete goal is a statement of the form: which initial changes are erased, which can leave a lasting angular trace, and by what mechanism. Derive local monotonicity/invertibility only to the extent supported. Degree one alone is not a monotonicity proof. A global classification for arbitrary alpha, bifurcation atlas, or full description of all level sets is not required.

The cross product with a fixed coordinate roll need not have the continuous axial symmetry of P. Check any claimed symmetry of the **complete** update rather than inferring it from the circular endpoint set or the crystal's threefold appearance.

## 5. Bounded numerical comparisons

First write `CA02_PLAN.md` with exact cases, source identities, tolerances, tail accounting and counters. Then execute the following diagnostics without another routine author-approval round. New parameters are declared diagnostic choices, not recovered historical values.

### Fixed choices

- Binary64 primary arithmetic; `dt=0.1`; update n uses `t=0.1*n`; no clock resets.
- Small coupling \(a=1/32\); half-coupling \(a/2=1/64\).
- Exactly 800 updates per selected fresh trajectory; save states 0 through 800.
- Define
  \[
  L_*=\sqrt{\rho_*^2+z_*^2},\qquad
  s_{\rm tilt}(\beta)=L_*(\cos\beta,0,\sin\beta).
  \]
- Keep the printed clipping code in every run. Verify analytically that the cases below remain on its inactive branch: the conservative initial bound \(\|s_0\|\le9/4\), \(|H|\le9/2\), \(|\alpha|\le1/32\) gives \(\|q_0\|\le729/1024<0.8-10^{-5}\); after remapping, \(\|s_n\|\le3/2\). Check these bounds, including the epsilon, rather than removing the clip. This deliberate small-drive regime isolates retention before any saturation complication.

### Predeclared run matrix

| Family | Initial state | Coupling | Fresh trajectories | Purpose |
|---|---|---|---:|---|
| A | \(s_*(\phi)\), \(\phi=0,\pi/2,\pi,3\pi/2\) | \(+a,-a\) at each start | 8 | Angular dependence and signed response |
| B | \(\lambda s_*(0)\), \(\lambda=1/2,3/2\) | \(+a\) | 2 | Initial scale with direction held fixed; compare with A at phi=0 |
| C | \(s_{\rm tilt}(\beta)\), \(\beta=0,\pi/4\) | \(+a\) | 2 | Tilt only: same norm and azimuth as A at phi=0 |
| D | \(s_*(\phi)\), \(\phi=0,\pi/2\) | \(+a/2,-a/2\) at each start | 4 | Check the derived alpha=0 derivative at two step sizes |

Family B changes starting norm while holding direction fixed. Family C changes starting tilt while holding norm and azimuth fixed. These are one-time definitions of test inputs, not state normalization during evolution or a spherical display constraint. This separation avoids attributing a simultaneous norm change to tilt alone.

**Ceiling: 16 fresh trajectories × 800 updates = 12,800 rollout updates.** Use fewer only when analysis makes a case redundant and explain the omission. No extra starts, alphas, stochastic variants, repeat runs, adaptive extensions, clock variants, or high-precision rollouts. This is a small fixed comparison, not an optimization or sweep.

Up to **24 additional isolated fresh one-step diagnostics** are authorized if needed. Failed calls count. Re-evaluation of the 12 inherited fixtures and 200 inherited saved transitions is passive verification and must be counted separately; never feed those computed outputs into new trajectories. Maximum fresh state-advance calls, including isolated probes, is therefore **12,824**.

Run the numerical stage in one process with explicit counters, a 10-minute wall-time limit and a 250 MB new-result ceiling. Do not automatically restart. These caps are guardrails, not work quotas. Symbolic analysis and small evaluations of scalar bounds are not rollout calls, but do not launch unbounded symbolic searches.

### Endpoint and error accounting

Do not call the last sample the exact limit. Use the CA01 angular tail argument to derive a bound after state N. A candidate bound to verify for N>=1 is

\[
B_N(\alpha)=\frac{0.225|\alpha|}{0.42}
\left[
\frac{2e^{-0.05N}}{1-e^{-0.05}}
+\frac{e^{-0.03N}}{1-e^{-0.03}}
+\frac{1.5e^{-0.07N}}{1-e^{-0.07}}
+\frac{e^{-0.04N}}{1-e^{-0.04}}
\right].
\]

This bounds the remaining lifted angular change of an **exact** trajectory, not accumulated floating-point error. Report those issues separately. Use a conservatively evaluated bound or retain its exact expression; label ordinary numerical estimates as such. The 800-step horizon is intended to make this mathematical tail small for the chosen couplings. An unresolved numerical distinction is a reportable outcome, not permission to extend runs.

Compare endpoints modulo 2pi using circular differences. Also preserve the continuous lifts for derivatives. Compare the two central-difference estimates with the derived derivative, using a justified truncation/numerical-error assessment rather than demanding an arbitrary error ratio. A decreasing difference is numerical support, not by itself proof of differentiability.

Record state, update index, forcing time, H, alpha, raw and clipped torque, clipping factor, pre-remap state, angular increment/lift, and distance to C. Store the actual initial vectors and their analytic definitions. Use non-pickle numerical formats. Never relabel display-time or update count as a calibrated physical time.

## 6. Detached implementation and checking

Do not import or run CA01's `run_checks.py`: it has execution at module level and includes out-of-scope F3 work. Inspect its helper definitions and make a small local pure evaluator preserving the accepted arithmetic and operation order. Document adaptations of names or dependency plumbing. Check it against CA01's saved fixtures and saved successor states before any new rollout.

Use inherited tolerances where applicable (CA01 used 1e-12 for its isolated floating identities), with scale-aware diagnostics. Check source equality, the torque's perpendicularity, the discrete Euler norm identity, remap surface membership, nonnegative post-remap height, azimuth-lift consistency and the predicted clipping regime. Keep proof claims distinct from numerical residuals.

Stop an affected numerical branch on nonfinite values, an undefined remap, an unexpected clipping branch, source/semantic mismatch, or a resource limit. Preserve the failure. Do not regularize the axis, alter the clock, change alpha, remove clipping, or rerun silently to obtain a desired pattern. A scientifically interesting discrepancy is not a reason to rewrite the input equations. Continue any independent written analysis that remains valid and report a real blocker plainly.

## 7. Passive geometry: useful view, not a mechanism

The main measurements are native initial-state changes and limiting angular position. Use the existing geometric reference only when it helps explain those measurements.

Reuse CA01's saved reference arrays; do not re-audit or rebuild the central-crystal lane. The retained illustrative display convention is

\[
y=O+s,\qquad O=(0,\sqrt3/6,0),
\]

with unit scale and fixed axes. Keep both face hands and the open boundaries distinct. No per-trajectory recentering, shrinking, fitting into a ball, new toroidal guide dimensions, or hidden out-of-window samples. The reference origin is not a dynamical sink.

An optional fixed rigid-frame comparison acts on the data, circle, axes and reference together. It changes their description, not the recurrence. Rotating an initial state relative to the unchanged coordinate roll is a different dynamical experiment and is not interchangeable with a passive frame change. No native Z samples, crystal motion or feedback are authorized.

At most three explanatory figures are needed: initial versus final phase with derivative/finite-error information; the scale/inclination comparisons; and, only if informative, an unchanged-scale geometric overlay. Each figure must distinguish possible endpoints from an orbit and discrete connecting segments from continuous motion. Do not add a diagram implying physical confinement.

## 8. Return package and decision standard

Return one compact `CA02_GPT_REVIEW.zip` with:

- `READ_ME_FIRST.md`, preferably no more than 700 words. Lead with the answer about what survives and what disappears; explain any unresolved point without handing the mathematics back to Hilmir.
- `CA02_ENDPOINT_RETENTION_ANALYSIS.md`: definitions, proofs, assumptions, initial-state comparisons, the linear-response analysis, and limitations.
- The fixed plan/run matrix, detached source, source/claim map, verification results, endpoint table, raw numerical evidence, and up to three legible figures.
- A small consumed-source preservation record, actual execution counters, software versions, commands, manifest, and review instructions. Do not inflate a check count into a theorem count.

The first page must answer: **Does the drive leave an angular trace of initial differences that P alone would erase? Which cases show this, and what is proved versus only observed?**

Mark findings as inherited CA01 results, newly derived results, finite diagnostic evidence, or unresolved questions. Do not describe the new runs as a historical replay or a result about every SRG implementation. Missing old alpha and initial-state records remain missing. Do not identify retained angle with heat, magnetism, light, learned memory, or physical storage.

A useful outcome may be a positive retention mechanism, exact erasure for a class of starts, an exceptional zero response, or a precise limitation. No particular answer is required. A finite error bar or unresolved global classification does not invalidate a narrower exact result.

**End state:** local CA02 research ready for GPT and Hilmir's review. CA01 and all existing models remain unchanged. No staging, commit, push or publication.

---

## Source and proposal boundary

[S1] CA01_ANALYSIS.md §§3–5 and [S2] CA01_GPT_SCIENTIFIC_REVIEW.md §4 support the inherited update, circle, convergence and degree-one statements. [S3] supports the saved numerical baseline and evaluator semantics. [S4]–[S6] support source limits and the passive reference. Exact packet identities are listed in `SOURCE_ANCHORS.md`.

The endpoint-retention questions, linear-response task, coupling choices, 16-case run matrix, new budget and requested comparisons are **new CA02 instructions**. They are not claimed as already completed or established by CA01. No outside physical model is used to complete the supplied definitions.
