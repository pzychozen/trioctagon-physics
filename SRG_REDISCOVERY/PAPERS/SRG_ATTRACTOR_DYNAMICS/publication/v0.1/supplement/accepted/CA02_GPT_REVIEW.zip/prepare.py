"""Read/copy the authorized input evidence; do not import CA01 programs."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
BASE=Path(__file__).resolve().parent;REPO=BASE.parents[2]
CA01=BASE.parent/'CA01_source_and_measurement_v0.1'
PACKET=Path(r'C:\Users\Notandi\Downloads\SRG_CA02_CODEX_START_PACKET.zip')
sys.stdout.reconfigure(encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():assert p.read_bytes()==b, f'Existing content protected: {p}'
    else:p.write_bytes(b)
def git(*a):return subprocess.check_output(['git','-C',str(REPO),*a])
with zipfile.ZipFile(PACKET) as z:
    m=json.loads(z.read('MANIFEST.json'))
    for r in m['files']:
        b=z.read(r['path']);assert len(b)==r['size_bytes'] and sha(b)==r['sha256']
    for name in z.namelist():
        p=(BASE/'received'/name).resolve();assert p.is_relative_to(BASE/'received');save(p,z.read(name))
arc=CA01/'CA01_GPT_REVIEW.zip'
assert sha(arc.read_bytes())=='f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0'
consumed=['CA01_ANALYSIS.md','READ_ME_FIRST.md','run_checks.py','RESULTS.json','raw/F4_remap_only.npz','SOURCE_AND_CLAIM_MAP.md','evidence/consumed_sources.json','MANIFEST.json']
rows=[]
with zipfile.ZipFile(arc) as z:
    assert z.testzip() is None
    m=json.loads(z.read('MANIFEST.json'))
    for r in m['files']:
        b=z.read(r['path']);assert sha(b)==r['sha256'] and len(b)==r['size']
    for name in consumed:
        b=(CA01/name).read_bytes();assert b==z.read(name)
        save(BASE/'inputs/CA01'/name,b)
        rows.append({'path':str(CA01/name),'copy':'inputs/CA01/'+name,'sha256':sha(b),'size':len(b)})
rows.append({'path':str(arc),'sha256':sha(arc.read_bytes()),'size':arc.stat().st_size,'copy':None})
for parent,copy in [('CA01_ANALYSIS.md','CA01_ANALYSIS.md'),('READ_ME_FIRST.md','CA01_READ_ME_FIRST.md')]:
    assert (CA01/parent).read_bytes()==(BASE/'received/reference'/copy).read_bytes()
review=BASE/'received/reference/CA01_GPT_SCIENTIFIC_REVIEW.md'
assert sha(review.read_bytes())=='9ce79ca882ab29a2ba07e14caf8b927cbfac8aa08385ab7b59fb47955ed1d317'
save(BASE/'evidence/SOURCES_BEFORE.json',(json.dumps(rows,indent=2)+'\n').encode())
save(BASE/'evidence/status_before.txt',git('status','--porcelain=v1','--untracked-files=normal'))
save(BASE/'evidence/index_before.txt',git('diff','--cached','--name-status'))
state={'HEAD':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'python':sys.executable,'version':sys.version,'packet_sha256':sha(PACKET.read_bytes()),'accepted_archive_verified_payloads':len(m['files'])}
save(BASE/'evidence/START.json',(json.dumps(state,indent=2)+'\n').encode())
print(json.dumps(state,indent=2))
lines=(BASE/'received/SRG_CA02_CODEX_WORK_ORDER.md').read_text(encoding='utf-8').splitlines()
for i,line in enumerate(lines,1):
    if i>=175:print(f'{i}: {line}')
print('\nCA01 numerical source (read as text):')
lines=(CA01/'run_checks.py').read_text(encoding='utf-8').splitlines()
for i,line in enumerate(lines,1):
    if i>=140:print(f'{i}: {line}')
