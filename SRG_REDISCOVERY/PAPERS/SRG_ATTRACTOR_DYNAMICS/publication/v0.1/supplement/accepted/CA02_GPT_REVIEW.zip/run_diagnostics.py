"""Single authorized CA02 numerical stage. Refuses repetition. See CA02_PLAN.md."""
from pathlib import Path
import hashlib, json, os, sys, time, traceback
BASE = Path(__file__).resolve().parent
for key in ('TMP', 'TEMP', 'MPLCONFIGDIR'):
    folder = BASE / 'cache' / key
    folder.mkdir(parents=True, exist_ok=True)
    os.environ[key] = str(folder)
sys.dont_write_bytecode = True
import numpy as np
import model

T0 = time.monotonic()
MAX_BYTES = 250_000_000
OUT = BASE / 'raw'
assert not OUT.exists(), 'Existing numerical stage protected: no automatic rerun'
OUT.mkdir()
RESULT = dict(status='PREFLIGHT', counts=dict(inherited_fixture_evaluations=0,
    inherited_saved_transition_evaluations=0, fresh_trajectories_started=0,
    fresh_trajectories_completed=0, fresh_rollout_calls=0, fresh_isolated_calls=0,
    failed_fresh_calls=0, kernel_updates=0), runs=[], errors=[],
    environment=dict(python=sys.version, executable=sys.executable, numpy=np.__version__),
    limits=dict(seconds=600, new_result_bytes=MAX_BYTES, fresh_rollout_calls=12800,
                fresh_isolated_calls=24, fresh_trajectories=16),
    tolerances=dict(consistency_absolute_and_scaled=1e-12),
    historical_replay=False, dt=0.1, forcing_clock='t_n=0.1*n, starts at n=0 once per trajectory')
def dump():
    RESULT['elapsed_seconds'] = time.monotonic() - T0
    (BASE / 'RUN_RESULTS.json').write_text(json.dumps(RESULT, indent=2, allow_nan=False) + '\n')
def size(): return sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())
def guard(reserve=0):
    if time.monotonic() - T0 >= 595: raise TimeoutError('Internal 595-second guard')
    if size() + reserve > MAX_BYTES: raise RuntimeError('250 MB result ceiling')
def residuals(v):
    s,q,u,d = v['s'],v['qhat'],v['u'],v['dest']
    ss,uu,qq = float(s@s),float(u@u),float(q@q)
    scale = max(1., ss, uu)
    return dict(euler_abs=abs(uu-ss-.01*qq), euler_scaled=abs(uu-ss-.01*qq)/scale,
                perpendicular_abs=abs(float(s@q)), perpendicular_scaled=abs(float(s@q))/scale,
                surface_abs=abs((float(np.hypot(d[0],d[1]))-1.)**2+d[2]**2-.25))
def check(v):
    r = residuals(v)
    assert r['euler_scaled'] < 1e-12 and r['perpendicular_scaled'] < 1e-12
    assert r['surface_abs'] < 1e-12 and v['dest'][2] >= -1e-12
    return r
def inherited():
    saved = json.loads((BASE / 'inputs/CA01/RESULTS.json').read_text())
    maxima = dict(source_values=0., euler_abs=0., euler_scaled=0., perpendicular_abs=0.,
                  perpendicular_scaled=0., surface_abs=0.)
    for fixture in saved['F4_preflight']:
        RESULT['counts']['inherited_fixture_evaluations'] += 1
        v = model.step(np.array(fixture['s'],dtype=float),fixture['t'],fixture['alpha'])
        for key,val in v.items():
            delta = float(np.max(np.abs(np.asarray(val,dtype=float)-np.asarray(fixture[key],dtype=float))))
            maxima['source_values'] = max(maxima['source_values'],delta)
            assert delta < 1e-12, (fixture['id'],key,delta)
        for key,val in check(v).items(): maxima[key]=max(maxima[key],val)
    with np.load(BASE / 'inputs/CA01/raw/F4_remap_only.npz',allow_pickle=False) as saved:
        for n in range(200):
            RESULT['counts']['inherited_saved_transition_evaluations'] += 1
            # Each input is the saved source row, never a computed predecessor.
            v=model.step(saved['s'][n].copy(),float(saved['t'][n]),float(saved['alpha'][n]))
            for key,val in v.items():
                delta=float(np.max(np.abs(np.asarray(val,dtype=float)-np.asarray(saved[key][n],dtype=float))))
                maxima['source_values']=max(maxima['source_values'],delta)
                assert delta < 1e-12,(n,key,delta)
            assert np.max(np.abs(v['dest']-saved['states'][n+1])) < 1e-12
            for key,val in check(v).items(): maxima[key]=max(maxima[key],val)
    RESULT['inherited_passive_verification']=dict(passed=True,maxima=maxima,
        axis_fixtures='Historical atan2 conventions retained for inherited fixtures only; fresh remaps must be off-axis.')
    dump()

rho=(3+np.sqrt(3.))/4
z=.5*np.sqrt(np.sqrt(3.)/2)
L=float(np.sqrt(rho*rho+z*z))
a=1/32
def star(phi):return np.array([rho*np.cos(phi),rho*np.sin(phi),z],dtype=float)
cases=[]
for j,phi in enumerate([0.,np.pi/2,np.pi,3*np.pi/2]):
    for sign,suffix in [(1,'p'),(-1,'m')]:
        cases.append(dict(id=f'A{j}{suffix}',family='A',state=star(phi),phi0=float(phi),alpha=sign*a,
                          definition=f's_*(phi), phi={j}*pi/2'))
for lam,name in [(.5,'Bhalf'),(1.5,'Bthreehalf')]:
    cases.append(dict(id=name,family='B',state=lam*star(0.),phi0=0.,alpha=a,lambda_=lam,
                      definition=f'{lam} * s_*(0), same direction, size only'))
for beta,name in [(0.,'Czero'),(np.pi/4,'Cquarter')]:
    cases.append(dict(id=name,family='C',state=L*np.array([np.cos(beta),0.,np.sin(beta)]),
                      phi0=0.,alpha=a,beta=float(beta),definition=f'L_*(cos beta,0,sin beta), beta={beta!r}; fixed norm and azimuth'))
for j,phi in enumerate([0.,np.pi/2]):
    for sign,suffix in [(1,'p'),(-1,'m')]:
        cases.append(dict(id=f'D{j}{suffix}',family='D',state=star(phi),phi0=float(phi),alpha=sign*a/2,
                          definition=f's_*(phi), phi={j}*pi/2; half coupling'))
assert len(cases)==16
RESULT['constants']=dict(rho_star=float(rho),z_star=float(z),L_star=L,a=a)
RESULT['declared_cases']=[{**{k:v for k,v in c.items() if k!='state'},'state':c['state'].tolist()} for c in cases]
dump()
try:
    expected=json.loads((BASE/'evidence/MODEL_EXTRACTION.json').read_text())['model_sha256']
    assert hashlib.sha256((BASE/'model.py').read_bytes()).hexdigest()==expected
    assert not any(c['state'].dtype!=np.float64 for c in cases)
    inherited()
    RESULT['status']='RUNNING'
    for case in cases:
        guard(2_000_000)
        RESULT['counts']['fresh_trajectories_started']+=1
        state=case['state'].copy(); states=[state.copy()]; phase=[case['phi0']]; records=[]
        row={k:v for k,v in case.items() if k!='state'}
        row.update(initial_state=state.tolist(),status='RUNNING',completed_updates=0)
        RESULT['runs'].append(row); dump()
        try:
            for n in range(800):
                if time.monotonic()-T0>=595:raise TimeoutError('Internal deadline')
                assert RESULT['counts']['fresh_rollout_calls']<12800
                RESULT['counts']['fresh_rollout_calls']+=1 # Count calls before invocation, including failures.
                try: v=model.step(state,.1*n,case['alpha'])
                except Exception:
                    RESULT['counts']['failed_fresh_calls']+=1
                    raise
                e=.1*v['qhat']; x,y,_=state
                horizontal=float(np.hypot(x,y))
                lower=horizontal-float(np.linalg.norm(e[:2]))
                numerator=float(x*e[1]-y*e[0]); denominator=float(horizontal**2+x*e[0]+y*e[1])
                inc=float(np.arctan2(numerator,denominator))
                v.update(n=n,angular_increment=inc,segment_rho_lower=lower,angle_denominator=denominator)
                records.append(v)
                assert np.isfinite(list(residuals(v).values())).all()
                check(v)
                assert float(np.hypot(v['u'][0],v['u'][1]))>0, 'Undefined fresh remap'
                assert lower>0 and denominator>0, 'Short-segment branch condition failed'
                assert not v['clipped'] and v['factor']==1., 'Unexpected clipping'
                bound=729/1024 if n==0 else 81/256
                assert np.linalg.norm(v['q'])<=bound+1e-12
                state=v['dest'].copy();states.append(state.copy());phase.append(phase[-1]+inc)
                row['completed_updates']=n+1
            row['status']='COMPLETED'
            RESULT['counts']['fresh_trajectories_completed']+=1
        except Exception as exc:
            row['status']='STOPPED';row['error']=repr(exc)
            RESULT['errors'].append(dict(id=case['id'],error=repr(exc),traceback=traceback.format_exc()))
        finally:
            arr=np.asarray(states,dtype=float)
            raw={k:np.asarray([v[k] for v in records]) for k in records[0]} if records else {}
            raw.update(states=arr,state_index=np.arange(len(states)),state_forcing_time=.1*np.arange(len(states)),
                       phase_lift=np.asarray(phase),distance_to_circle=np.hypot(np.hypot(arr[:,0],arr[:,1])-rho,arr[:,2]-z))
            path=OUT/(case['id']+'.npz');np.savez_compressed(path,**raw)
            row.update(raw=str(path.relative_to(BASE)).replace('\\','/'),raw_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            dump()
        if row['status']!='COMPLETED':
            # Resource or semantic failure stops the stage, with no retry or repair.
            raise RuntimeError(f"Branch {case['id']} stopped; saved partial evidence")
        guard()
    assert RESULT['counts']['fresh_rollout_calls']==12800
    RESULT['status']='COMPLETED'
except Exception as exc:
    RESULT['status']='STOPPED'
    RESULT['errors'].append(dict(stage_error=repr(exc),traceback=traceback.format_exc()))
finally:
    RESULT['workspace_bytes_at_stage_end']=size()
    dump()
print(json.dumps({'status':RESULT['status'],'counts':RESULT['counts'],'elapsed_seconds':RESULT['elapsed_seconds'],
                  'workspace_bytes':RESULT['workspace_bytes_at_stage_end'],'errors':RESULT['errors']},indent=2))
if RESULT['status']!='COMPLETED':sys.exit(1)
