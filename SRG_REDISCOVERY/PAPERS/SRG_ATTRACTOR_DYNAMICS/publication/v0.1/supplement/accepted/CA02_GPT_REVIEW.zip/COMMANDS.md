# CA02 execution and review commands

All terminal commands used Windows `cmd.exe` with `login=false` and began with `call conda activate torment`. Python was run with `-B`. The interpreter was C:\Users\Notandi\miniconda3\envs\torment\python.exe. No packages were installed. Working directory for the task scripts was this CA02 directory.

The execution sequence was:

```bat
call conda activate torment && python -B inspect_packet.py
call conda activate torment && python -B prepare.py
```

Read-only inspection also used `rg`/`dir`/`type`, Git status/index/HEAD queries, and local text reads. The written plan and mathematical derivation preceded the following steps:

```bat
call conda activate torment && python -B extract_model.py
call conda activate torment && python -B supervise.py
call conda activate torment && python -B build_evidence.py
call conda activate torment && python -B refine_size_tilt_figure.py
```

`extract_model.py` extracted four inspected function ASTs without executing either original module. `supervise.py` made exactly one child-process launch of `run_diagnostics.py`, with a 600-second timeout and no restart. Its exact executable, arguments, UTC start, runtime and status are in evidence/NUMERICAL_LAUNCH.json; stdout is retained. `build_evidence.py` only reads saved arrays, evaluates scalar formulas, checks records and plots; it makes no fresh state-advance calls. `refine_size_tilt_figure.py` moved two labels above prediction markers using saved data only; it did not repeat the diagnostics.

The completion step records final source preservation and repository state, verifies the review archive and creates a receipt:

```bat
call conda activate torment && python -B package_review.py
```

Do not repeat the numerical stage as part of this work order. The launch marker and raw-directory guards deliberately refuse a rerun. A new numerical investigation would need separate scope. To review this result, inspect the Markdown, JSON, CSV and PNG files, and load NPZ files with `allow_pickle=False`. MANIFEST.json gives payload identities, and REVIEW_ZIP_RECEIPT.json beside the ZIP gives the final archive identity; the receipt is intentionally outside the ZIP to avoid circular self-hashing.

No kernel, original runner, source module tail, GUI or native Z implementation was invoked. No staging, commit, push, publication or external upload command was issued. Cache/TMP paths remained inside CA02.
