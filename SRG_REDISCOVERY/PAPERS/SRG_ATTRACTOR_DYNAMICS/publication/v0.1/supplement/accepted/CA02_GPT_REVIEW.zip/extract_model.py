"""Detach inspected definitions as text/AST; never execute CA01 modules."""
from pathlib import Path
import ast, hashlib, json, zipfile

BASE = Path(__file__).resolve().parent
CA01 = BASE.parent / 'CA01_source_and_measurement_v0.1'
def digest(b): return hashlib.sha256(b).hexdigest()
source = CA01 / 'evidence/detached_F3_helpers.py.txt'
content = source.read_bytes()
with zipfile.ZipFile(CA01 / 'CA01_GPT_REVIEW.zip') as archive:
    assert content == archive.read('evidence/detached_F3_helpers.py.txt')
copy = BASE / 'inputs/CA01/evidence/detached_F3_helpers.py.txt'
copy.write_bytes(content)
registry = BASE / 'evidence/SOURCES_BEFORE.json'
rows = json.loads(registry.read_text())
assert not any(r['path'] == str(source) for r in rows), 'Extraction already recorded'
rows.append(dict(path=str(source), copy=str(copy.relative_to(BASE)).replace('\\', '/'),
                 size=len(content), sha256=digest(content)))
registry.write_text(json.dumps(rows, indent=2) + '\n')
f4 = ast.parse((BASE / 'inputs/CA01/run_checks.py').read_text(encoding='utf-8-sig'))
f3 = ast.parse(content.decode('utf-8-sig'))
definitions = []
for name, tree in [('H', f3), ('finite', f4), ('P', f4), ('step', f4)]:
    found = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name]
    assert len(found) == 1
    definitions.append(found[0])
text = '"""CA02 pure evaluator: unchanged CA01 function ASTs; no source module execution."""\nimport numpy as np\n\n'
text += '\n\n'.join(ast.unparse(node) for node in definitions) + "\n\nenv = {'H': H}\n"
target = BASE / 'model.py'
assert not target.exists()
target.write_text(text, encoding='utf-8')
new = ast.parse(text)
new_defs = {n.name:n for n in new.body if isinstance(n, ast.FunctionDef)}
checks = []
for old in definitions:
    old_dump = ast.dump(old, include_attributes=False)
    assert old_dump == ast.dump(new_defs[old.name], include_attributes=False)
    checks.append(dict(name=old.name, unchanged_AST=True, ast_sha256=digest(old_dump.encode()),
                       source='detached_F3_helpers.py.txt' if old.name == 'H' else 'run_checks.py'))
report = dict(functions=checks, model_sha256=digest(target.read_bytes()),
              adaptation='Only NumPy import, top-level function placement and env={H:H}; function ASTs unchanged.',
              original_modules_imported=False, original_top_level_executed=False)
for name in ['run_diagnostics.py', 'supervise.py']:
    ast.parse((BASE / name).read_text(encoding='utf-8'))
report['before_fresh_execution'] = {name:digest((BASE/name).read_bytes()) for name in
    ['CA02_PLAN.md', 'CA02_ENDPOINT_RETENTION_ANALYSIS.md', 'run_diagnostics.py', 'supervise.py']}
(BASE / 'evidence/MODEL_EXTRACTION.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
