# CA02 source anchors

21 October 2026. This packet prepares the next investigation; it does not report CA02 results.

## Local authority

The author's Windows checkout is authoritative:
`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`.

The accepted input directory is:
`SRG_REDISCOVERY\CENTRAL_ATTRACTOR_ANALYSIS\CA01_source_and_measurement_v0.1\`.

Keep it unchanged. New outputs belong only in the CA02 directory named in the work order.

## What is inherited

CA01's accepted scope is `ACCEPTED_WITHIN_PRINTED_MAP_AND_PASSIVE_MEASUREMENT_SCOPE`.
Its conditional convergence theorem, complete update, saved evidence and source gaps
are inherited; the work order does not reopen their approval or claim a historical replay.

The reference files here are byte copies, not revised editions. `CA01_READ_ME_FIRST.md`
is the parent's `READ_ME_FIRST.md` under a distinguishing filename. These documents retain
their original relative links, which resolve in the complete local CA01 package, not necessarily
in this compact start packet.

The full historical PDF, raw arrays, numerical scripts, images and source snapshots are
already present in CA01. They are not duplicated here. Inspect executable sources as text;
do not import or run CA01's rollout script.

## Identity anchors

The parent archive's SHA-256 was checked while preparing this packet. No new CA01
scientific checker or CA02 rollout was executed during preparation. The identities below
allow Codex to check the exact local inputs; this is not a claim of current Windows access.

- `CA01_GPT_REVIEW.zip`: 7,630,962 bytes; SHA-256 `f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0`.
- `CA01_GPT_SCIENTIFIC_REVIEW.md`: 14,873 bytes; SHA-256 `9ce79ca882ab29a2ba07e14caf8b927cbfac8aa08385ab7b59fb47955ed1d317`.

| CA01 archive member | Bytes | SHA-256 |
|---|---:|---|
| `CA01_ANALYSIS.md` | 22742 | `64e359e7c2d51726a6fd51ee20f05b3ec7ad1ded7c0218d9653089b42c6991e5` |
| `READ_ME_FIRST.md` | 4189 | `4bd7a2c293655ea0e814182a7920a79d72e3c97e742cbcb383276035b14f8824` |
| `run_checks.py` | 11286 | `230c09f68d32dc03732eb03073aee94497fd88cabc9e0f5c4bd76b0e2edfab3f` |
| `RESULTS.json` | 25608 | `37c34e581033e4072af186c8ebb01cf2ec3a4049e5a8547496d706e4e2276a90` |
| `SOURCE_AND_CLAIM_MAP.md` | 11040 | `4819dc0c27a1a4b47e5de5fdd2ab0bd2344db0c52a3cc6e077b1016092cc29bb` |
| `evidence/consumed_sources.json` | 8893 | `f9cad8f8a8dd1476d44039e407c4885c020a056defdbe4950e479250970d3c48` |
| `raw/F4_remap_only.npz` | 6884 | `207a10f5b4462bfa93be1f7aa7ce6b82d6ae38766f730361c26ce9dd79ed4d6a` |
| `evidence/geometry_reference.npz` | 1931 | `b72719fffdd419442c2ed840e5f7265c47c5c5ccd9e9088aaccfc808b1f2f2f4` |
| `received/inputs/SGR_simulations.pdf` | 3511783 | `2d803a28c0a9f4396149cf8700c2a772b5016574517061fb8761c3c50de1c547` |

## New proposal boundary

The CA02 endpoint-retention question, derivative task, small-coupling choices,
initial-state families, execution budget and desired comparisons are new instructions.
They are not inherited numerical findings, missing historical settings, or a physical
interpretation. A derived result or discrepancy must be reported on its own evidence.

No publication authority is transferred from any earlier project task.
