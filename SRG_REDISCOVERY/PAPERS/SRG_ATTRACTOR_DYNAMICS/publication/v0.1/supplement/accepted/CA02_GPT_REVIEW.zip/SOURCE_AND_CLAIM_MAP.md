# CA02 source and claim map

Authority is the user's CA02 request, which explicitly invokes the supplied work order. The packet's work order supplies the authorized research procedure and bounds; its review is evidence of acceptance of CA01. Scientific claims below are separated from those procedural instructions. No permission to publish is inferred from either source.

| Source | Use and boundary | Identity record |
|---|---|---|
| User-supplied CA02 packet | Work order, fixed cases and limits; not pre-established CA02 findings | received/MANIFEST.json; packet SHA-256 in evidence/START.json |
| Accepted CA01 review | ACCEPTED_WITHIN_PRINTED_MAP_AND_PASSIVE_MEASUREMENT_SCOPE; no permission to modify CA01 | received/reference/CA01_GPT_SCIENTIFIC_REVIEW.md; SHA-256 9ce79ca882ab29a2ba07e14caf8b927cbfac8aa08385ab7b59fb47955ed1d317 |
| CA01 review ZIP | Accepted baseline; all 89 manifested payloads and CRC checked before use | SHA-256 f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0 |
| CA01_ANALYSIS.md, sections 3–5 | Complete printed-map interpretation, remap, circle, driven convergence, degree one, passive observer | inputs/CA01/CA01_ANALYSIS.md; matching attached reference |
| CA01 run_checks.py | Inspected as text only; extracted P, step and finite definitions | inputs/CA01/run_checks.py; evidence/MODEL_EXTRACTION.json |
| CA01 detached_F3_helpers.py.txt | Only its H definition extracted; no F3 calculations executed or reopened | inputs/CA01/evidence/detached_F3_helpers.py.txt; extracted AST hash |
| CA01 RESULTS.json and raw/F4_remap_only.npz | 12 isolated fixtures and 200 saved transitions, re-evaluated independently without chaining | inputs/CA01/; RUN_RESULTS.json passive counters |
| CA01 source/claim map, consumed sources, manifest | Preserved provenance, roll reading and unrecovered historical inputs | inputs/CA01/SOURCE_AND_CLAIM_MAP.md, evidence/consumed_sources.json, MANIFEST.json |

Full original paths, sizes and SHA-256 values of the ten consumed original artifacts are in evidence/SOURCES_BEFORE.json; evidence/PRESERVATION.json checks them at completion. The packet's CA01 analysis and introductory text were cross-checked with the local accepted archive; its acceptance review was verified against the separately supplied review hash. The PDF and geometry arrays were not needed anew: CA01 already resolves the accepted equations, and no optional overlay was made. No extra historical-source search occurred.

| Claim | Classification | Support |
|---|---|---|
| Complete recurrence, convergence to C, degree-one initial-latitude map | Inherited CA01 | Accepted analysis and review; no injectivity inferred from degree one |
| Zero-drive endpoint and its half-plane fibers; rank one | New endpoint interpretation of inherited P algebra | CA02 analysis section 2 |
| Exact short-segment angular increment and summable endpoint lift | Newly derived | Section 3, nonsingular segment proof and CA01 forcing bounds |
| Positive scale need not be erased by the complete update | Newly derived | Homogeneity of torque, scale formula and endpoint derivative in sections 3–4 |
| Size and equal-norm tilt can leave different angular endpoints | Newly derived for sufficiently small nonzero coupling | Strict differences in response coefficients, sections 4.2–4.3 |
| Positive rescalings of c(1,1,1) have identical futures | Exact new erasure example | Zero first torque, P scale invariance, common successor and clock |
| Endpoint response D and exact discrete forcing sum | Newly derived | Section 4; smoothness/series justification; scalar coefficient evidence |
| Local rank-one level surfaces and small-coupling monotonicity on C | Local theorem, no numerical threshold | Section 4; smoothness and nonvanishing phase gradient |
| Absence of continuous axial symmetry of full update | Newly derived | Nonconstant G(phi), section 4.1; passive rotations also transform coordinate operators |
| Different phases at alpha=1/32 and central-difference agreement | Finite binary64 evidence | Saved raw arrays and comparison tables; no certified roundoff enclosure |
| Tail after state 800 | Exact analytic bound with ordinary numerical estimate | Section 5; distinct from roundoff and finite-h truncation |
| No geometry-induced attraction/confinement | Scope/implementation fact | model.py has only accepted operations; native coordinate figures; no reference feedback |
| Historical Figure 4 replay, physical memory/heat/magnetism/light, global injectivity | Not established | Missing historical alpha/start/producer retained; beyond this work order |

The new alpha values, starts, 800-update horizon and error measurements are declared diagnostics. No number from them is relabeled as a historical input or calibrated physical quantity.
