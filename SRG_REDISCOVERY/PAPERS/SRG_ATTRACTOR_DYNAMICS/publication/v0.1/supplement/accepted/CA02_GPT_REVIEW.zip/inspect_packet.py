"""Read the task packet as data; execute no attached code."""
import sys, zipfile
sys.stdout.reconfigure(encoding='utf-8')
with zipfile.ZipFile(r'C:\Users\Notandi\Downloads\SRG_CA02_CODEX_START_PACKET.zip') as z:
    for name in ['MANIFEST.json','SOURCE_ANCHORS.md','SRG_CA02_CODEX_WORK_ORDER.md','reference/CA01_GPT_SCIENTIFIC_REVIEW.md']:
        print('\n### '+name+'\n'+z.read(name).decode('utf-8-sig'))
