"""Passive calculations on saved records, scalar response series, tables and figures.

Does not import model, call step/P, or produce any new dynamical trajectory.
"""
from pathlib import Path
import csv, hashlib, json, os, sys
BASE=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(BASE/'cache/MPLCONFIGDIR')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=json.loads((BASE/'RUN_RESULTS.json').read_text())
assert R['status']=='COMPLETED'
rho=R['constants']['rho_star'];z=R['constants']['z_star'];L=R['constants']['L_star'];a=1/32
b=(np.sqrt(3.)-1)/4
S=float(2*np.real(1/(1-np.exp(-.05+.1j)))+np.imag(1/(1-np.exp(-.03+.1j)))+
        1.5/(1-np.exp(-.07))+1/(1-np.exp(-.04)))
def Hscalar(t):return 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
def G(phi):return b*np.cos(phi)+z*np.sin(phi)*np.cos(phi)-rho*np.sin(phi)
def circ(v):return np.arctan2(np.sin(v),np.cos(v))
def tail(N,alpha):
    return float(.225*abs(alpha)/.42*(2*np.exp(-.05*N)/(-np.expm1(-.05))+
        np.exp(-.03*N)/(-np.expm1(-.03))+1.5*np.exp(-.07*N)/(-np.expm1(-.07))+
        np.exp(-.04*N)/(-np.expm1(-.04))))
M=40
coefficient_tail=float(.1*4.5*(5*np.pi/16)*3.**(-(M-1))/(1-1/3))
tilts={}
for beta,label in [(0.,'Czero'),(np.pi/4,'Cquarter')]:
    w0=L*np.sin(beta)**2/np.cos(beta)
    theta=np.pi/2-beta
    correction=0.; terms=[]
    for n in range(1,M):
        w=.25*np.sin(theta)**2/(1+.5*np.cos(theta))
        term=Hscalar(.1*n)*(w-b)
        correction+=term
        terms.append(dict(n=n,theta=float(theta),w=float(w),weighted_correction=float(term)))
        theta=float(np.arctan2(1+.5*np.cos(theta),.5*np.sin(theta)))
    D=float(.1*(S*b+4.5*(w0-b)+correction))
    tilts[label]=dict(beta=float(beta),W0=float(w0),D=D,D_minus_circle=D-.1*S*b,
                      meridional_terms=terms,correction_tail_bound_estimate=coefficient_tail)

maxima={key:0. for key in ['component_torque','independent_H','qhat','pre_remap','closed_form_P',
    'successor_storage','euler_abs','euler_scaled','perpendicular_abs','perpendicular_scaled','surface_abs',
    'angle_increment_vs_saved_azimuth','lift_vs_saved_azimuth','lift_vs_fsum_increments','distance_storage']}
minima=dict(segment_rho_lower=float('inf'),angle_denominator=float('inf'),post_remap_height=float('inf'))
max_q=0.; max_q0=0.;max_q_later=0.;clip_count=0;passive_records=0
endpoints=[]; arrays={}
import math
for row in R['runs']:
    p=BASE/row['raw'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['raw_sha256']
    with np.load(p,allow_pickle=False) as f: d={k:f[k].copy() for k in f.files}
    arrays[row['id']]=d
    assert d['states'].shape==(801,3) and d['n'].shape==(800,)
    assert all(np.isfinite(v).all() for v in d.values())
    assert all(v.dtype!=object for v in d.values())
    assert np.array_equal(d['n'],np.arange(800))
    assert np.array_equal(d['t'],.1*np.arange(800))
    assert np.array_equal(d['state_index'],np.arange(801))
    assert np.array_equal(d['state_forcing_time'],.1*np.arange(801))
    assert np.all(d['alpha']==row['alpha'])
    assert np.array_equal(d['s'],d['states'][:-1])
    assert np.array_equal(d['dest'],d['states'][1:])
    assert np.array_equal(d['states'][0],row['initial_state'])
    s=d['s'];u=d['u'];dest=d['dest'];qh=d['qhat'];q=d['q']
    x,y,zz=s.T
    # Independent component formula, no cyclic-roll call and no primary evaluator.
    component=np.column_stack((y*y-x*zz,zz*zz-x*y,x*x-y*zz))
    h=Hscalar(d['t']);expected_q=(d['alpha']*h)[:,None]*component
    qnorm=np.linalg.norm(q,axis=1)
    factor=np.minimum(1.,.8/(qnorm+1e-5))
    uh=np.hypot(u[:,0],u[:,1]);ul=np.linalg.norm(u,axis=1)
    assert np.all(uh>0) and np.all(ul>0)
    closed=np.column_stack(((1+u[:,2]/(2*ul))*u[:,0]/uh,
                            (1+u[:,2]/(2*ul))*u[:,1]/uh,uh/(2*ul)))
    ss=np.einsum('ij,ij->i',s,s);uu=np.einsum('ij,ij->i',u,u);qq=np.einsum('ij,ij->i',qh,qh)
    scale=np.maximum(1.,np.maximum(ss,uu))
    er=np.abs(uu-ss-.01*qq);dot=np.abs(np.einsum('ij,ij->i',s,qh))
    az=np.arctan2(d['states'][:,1],d['states'][:,0])
    dist=np.hypot(np.hypot(d['states'][:,0],d['states'][:,1])-rho,d['states'][:,2]-z)
    residual=dict(component_torque=float(np.max(np.abs(expected_q-q))),
        independent_H=float(np.max(np.abs(h-d['H']))),qhat=float(np.max(np.abs(q*factor[:,None]-qh))),
        pre_remap=float(np.max(np.abs(s+.1*qh-u))),closed_form_P=float(np.max(np.abs(closed-dest))),
        successor_storage=float(np.max(np.abs(dest-d['states'][1:]))),euler_abs=float(np.max(er)),
        euler_scaled=float(np.max(er/scale)),perpendicular_abs=float(np.max(dot)),
        perpendicular_scaled=float(np.max(dot/scale)),
        surface_abs=float(np.max(np.abs((np.hypot(dest[:,0],dest[:,1])-1)**2+dest[:,2]**2-.25))),
        angle_increment_vs_saved_azimuth=float(np.max(np.abs(circ(np.diff(az)-d['angular_increment'])))),
        lift_vs_saved_azimuth=float(np.max(np.abs(circ(d['phase_lift']-az)))),
        lift_vs_fsum_increments=abs(float(d['phase_lift'][-1])-(row['phi0']+math.fsum(d['angular_increment']))),
        distance_storage=float(np.max(np.abs(dist-d['distance_to_circle']))))
    for key,val in residual.items():
        maxima[key]=max(maxima[key],val)
        assert val<1e-12,(row['id'],key,val)
    assert np.all(factor==1.) and np.array_equal(factor,d['factor'])
    assert not d['clipped'].any()
    e=.1*qh
    segment=np.hypot(s[:,0],s[:,1])-np.linalg.norm(e[:,:2],axis=1)
    denominator=s[:,0]**2+s[:,1]**2+s[:,0]*e[:,0]+s[:,1]*e[:,1]
    assert np.all(segment>0) and np.all(denominator>0)
    assert np.max(np.abs(segment-d['segment_rho_lower']))<1e-12
    assert np.max(np.abs(denominator-d['angle_denominator']))<1e-12
    minima['segment_rho_lower']=min(minima['segment_rho_lower'],float(segment.min()))
    minima['angle_denominator']=min(minima['angle_denominator'],float(denominator.min()))
    minima['post_remap_height']=min(minima['post_remap_height'],float(dest[:,2].min()))
    max_q=max(max_q,float(qnorm.max()));max_q0=max(max_q0,float(qnorm[0]));max_q_later=max(max_q_later,float(qnorm[1:].max()))
    clip_count+=int(d['clipped'].sum());passive_records+=800
    D=float(.1*S*G(row['phi0']))
    if row['family']=='B':D+=.45*(row['lambda_']-1)*b
    if row['family']=='C':D=tilts[row['id']]['D']
    final=float(d['phase_lift'][-1]);shift=final-row['phi0']
    endpoints.append(dict(id=row['id'],family=row['family'],alpha=row['alpha'],phi0=row['phi0'],
        initial_x=row['initial_state'][0],initial_y=row['initial_state'][1],initial_z=row['initial_state'][2],
        initial_norm=float(np.linalg.norm(d['states'][0])),phase_800_lift=final,
        phase_800_mod_2pi=float(final%(2*np.pi)),shift_800=shift,
        analytic_D_at_zero=D,alpha_D=row['alpha']*D,shift_minus_linear=shift-row['alpha']*D,
        distance_to_circle_800=float(dist[-1]),exact_tail_bound_estimate=tail(800,row['alpha']),
        max_abs_increment=float(np.max(np.abs(d['angular_increment']))),
        first_increment=float(d['angular_increment'][0])))
E={r['id']:r for r in endpoints}
derivatives=[]
for j in [0,1]:
    Da=(E[f'A{j}p']['phase_800_lift']-E[f'A{j}m']['phase_800_lift'])/(2*a)
    Dh=(E[f'D{j}p']['phase_800_lift']-E[f'D{j}m']['phase_800_lift'])/a
    exact=E[f'A{j}p']['analytic_D_at_zero']
    derivatives.append(dict(phi0=j*np.pi/2,analytic_D=exact,central_a=Da,central_half_a=Dh,
        error_a=Da-exact,error_half_a=Dh-exact,observed_absolute_error_ratio=abs((Da-exact)/(Dh-exact)),
        change_on_halving=Dh-Da,richardson_estimate=(4*Dh-Da)/3,
        richardson_error=(4*Dh-Da)/3-exact,exact_tail_contribution_estimate=tail(800,a)/a))
comparisons=[]
for key in ['Bhalf','Bthreehalf','Czero','Cquarter']:
    comparisons.append(dict(id=key,reference='A0p',family=E[key]['family'],
        circular_difference=float(circ(E[key]['phase_800_lift']-E['A0p']['phase_800_lift'])),
        derivative_difference=E[key]['analytic_D_at_zero']-E['A0p']['analytic_D_at_zero'],
        first_order_difference=a*(E[key]['analytic_D_at_zero']-E['A0p']['analytic_D_at_zero']),
        sum_of_exact_tails_estimate=2*tail(800,a)))
V=dict(status='PASS',saved_record_checks=passive_records,fresh_advance_calls_in_this_script=0,
       inherited_fixture_and_transition_rechecks=R['inherited_passive_verification'],
       residual_maxima=maxima,minima=minima,max_raw_torque=max_q,max_initial_raw_torque=max_q0,
       max_post_initial_raw_torque=max_q_later,clipped_records=clip_count,
       bound_method='Analytic expressions retained in analysis; listed scalar values use ordinary binary64.',
       floating_error_limit='Residuals are consistency diagnostics, not a certified accumulated roundoff enclosure.',
       software=dict(python=sys.version,numpy=np.__version__,matplotlib=matplotlib.__version__))
(BASE/'VERIFICATION.json').write_text(json.dumps(V,indent=2,allow_nan=False)+'\n')
report=dict(S=S,b=float(b),rho_star=rho,z_star=z,L_star=L,tail_N=800,
    exact_tail_estimate_a=tail(800,a),exact_tail_estimate_half_a=tail(800,a/2),
    scalar_tilt_response=tilts,endpoints=endpoints,derivative_comparisons=derivatives,initial_state_comparisons=comparisons)
(BASE/'ENDPOINT_RESULTS.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
for name,rows in [('ENDPOINT_TABLE.csv',endpoints),('DERIVATIVE_TABLE.csv',derivatives),('INITIAL_STATE_COMPARISONS.csv',comparisons)]:
    with (BASE/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

# Scientific plots use saved data and derived scalar formulas only.
FIG=BASE/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.titleweight':'bold','savefig.facecolor':'white'})
blue='#2166ac';orange='#b85c00';green='#168078';gray='#777777'
fig=plt.figure(figsize=(12.6,7.8),layout='constrained')
gs=fig.add_gridspec(2,2,height_ratios=[1.3,1])
ax=fig.add_subplot(gs[0,:])
xs=np.arange(4)*np.pi/2
for suffix,color,label,offset in [('p',blue,'+a',-.035),('m',orange,'−a',.035)]:
    ys=np.array([E[f'A{j}{suffix}']['phase_800_lift'] for j in range(4)])
    ax.scatter(xs+offset,ys,s=62,color=color,label=f'800-update phase, α={label}',zorder=4)
    pred=xs+np.array([E[f'A{j}{suffix}']['alpha_D'] for j in range(4)])
    ax.scatter(xs+offset,pred,s=80,facecolors='none',edgecolors=color,marker='s',linewidths=1.3,
               label=f'First order, α={label}')
ax.plot([-.1,5],[ -.1,5],ls=':',color=gray,label='Zero-drive endpoint: final = initial')
ax.set(xticks=xs,xticklabels=['0','π/2','π','3π/2'],xlabel='Initial phase φ₀ (rad)',ylabel='Endpoint phase estimate, lifted (rad)',
       title='A. Starting angle remains consequential; the drive does not act as a uniform rotation')
ax.legend(loc='upper left',fontsize=9,ncol=2)
ax.text(.99,.02,'Markers are separate starts, not an orbit.\nSmall horizontal offsets only separate ±α markers.',
        transform=ax.transAxes,ha='right',va='bottom',fontsize=9,color='#444444')
for j in [0,1]:
    ax=fig.add_subplot(gs[1,j]);d=derivatives[j]
    ax.plot([0,1],[d['error_a'],d['error_half_a']],'-o',color=blue)
    ax.axhline(0,color=gray,lw=1,ls=':')
    ax.set(xticks=[0,1],xticklabels=['h = 1/32','h = 1/64'],ylabel='Central difference − exact derivative',
           title=f"B{j+1}. φ₀ = {'0' if j==0 else 'π/2'}; D = {d['analytic_D']:.7f}")
    ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0))
    for xval,k in [(0,'error_a'),(1,'error_half_a')]:
        ax.annotate(f"{d[k]:+.3g}",(xval,d[k]),xytext=(0,9),textcoords='offset points',ha='center',fontsize=9)
    ax.margins(x=.2,y=.3)
fig.suptitle('CA02 · Angular endpoint response of the printed recurrence',fontsize=17,fontweight='bold')
fig.supxlabel(f'800 updates; a = 1/32. Exact-trajectory tail ≤ B₈₀₀(a) ≈ {tail(800,a):.2e} rad.\n'
              'Tail excludes floating error; derivative discrepancies include finite h. No calibrated physical time.',fontsize=10)
fig.savefig(FIG/'01_phase_and_derivative.png',dpi=170);plt.close(fig)

fig,axs=plt.subplots(2,2,figsize=(12.6,8.4),layout='constrained')
groups=[(['Bhalf','A0p','Bthreehalf'],['½ × size','Reference','1½ × size'],'Size changes, direction fixed'),
        (['Czero','A0p','Cquarter'],['Tilt 0','Reference tilt','Tilt π/4'],'Tilt changes, norm and azimuth fixed')]
colors=[orange,gray,green]
for col,(keys,labels,title) in enumerate(groups):
    ax=axs[0,col]
    for i,(key,color) in enumerate(zip(keys,colors)):
        difference=float(circ(E[key]['phase_800_lift']-E['A0p']['phase_800_lift']))
        linear=a*(E[key]['analytic_D_at_zero']-E['A0p']['analytic_D_at_zero'])
        ax.scatter(i,difference,s=70,color=color,zorder=3)
        ax.scatter(i,linear,s=85,marker='s',facecolors='none',edgecolors=color,linewidths=1.4,zorder=2)
        ax.annotate(f'{difference:+.6f}',(i,difference),xytext=(0,11),textcoords='offset points',ha='center',fontsize=9)
    ax.axhline(0,color=gray,lw=1,ls=':')
    ax.set(xticks=range(3),xticklabels=labels,ylabel='Angular difference from reference (rad)',title=title)
    ax.margins(x=.2,y=.3)
    ax=axs[1,col]
    ref=arrays['A0p']['phase_lift']
    for key,color,label in zip(keys,colors,labels):
        if key=='A0p':continue
        diff=circ(arrays[key]['phase_lift']-ref)
        ax.plot(np.arange(801),diff,color=color,lw=1.7,label=label)
    ax.axhline(0,color=gray,lw=1,ls=':')
    ax.set(xlabel='Update index n',ylabel='Angular difference from reference (rad)',title='Angular trace accumulated during the drive')
    ax.legend(fontsize=9)
fig.suptitle('CA02 · Size and tilt leave separate angular traces',fontsize=17,fontweight='bold')
fig.supxlabel('All α = +1/32. Filled circles: state 800; open squares: first-order prediction.\n'
              'Lines connect discrete saved samples. Reference is s*(0); all endpoints approach the same circle.\n'
              f'Two-trajectory exact-tail allowance ≈ {2*tail(800,a):.2e} rad; accumulated floating error is not enclosed.',fontsize=10)
fig.savefig(FIG/'02_size_and_tilt.png',dpi=170);plt.close(fig)
print(json.dumps(dict(S=S,tail_a=tail(800,a),endpoints=endpoints,derivatives=derivatives,comparisons=comparisons,
                     verification=V),indent=2))
