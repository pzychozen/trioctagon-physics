"""Independent CA03 review of saved records only.

This script never imports submitted code, calls a submitted runner, or feeds a
computed state into a subsequent state update. Tangents use saved inputs.
The mathematical proofs still require written review; these consistency checks
are not a proof assistant or a global floating-point error enclosure.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, math, platform, sys, zipfile
from fractions import Fraction as Q
from pathlib import Path, PurePosixPath
import numpy as np
import mpmath as mp
import sympy as sp


def digest(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-dir', type=Path, required=True)
    ap.add_argument('--archive', type=Path, required=True)
    ap.add_argument('--ca02-archive', type=Path)
    ap.add_argument('--ca01-archive', type=Path)
    ap.add_argument('--packet', type=Path)
    ap.add_argument('--output-dir', type=Path, required=True)
    a = ap.parse_args(); root = a.input_dir.resolve(); out = a.output_dir.resolve()
    if out == root or root in out.parents:
        raise ValueError('Review outputs must be outside the submission directory.')
    out.mkdir(parents=True, exist_ok=True)
    checks = []; maxima = {}; notes = []
    def ok(name, v):
        checks.append({'name': name, 'pass': bool(v)})
        if not v: raise AssertionError(name)
    def near(name, x, y, tol=1e-12, category=None):
        x=np.asarray(x); y=np.asarray(y)
        ok(name+' shape', x.shape == y.shape)
        err=float(np.max(np.abs(x-y))) if x.size else 0.
        ok(name, np.isfinite(err) and err <= tol)
        if category: maxima[category]=max(maxima.get(category,0.), err)
        return err
    def js(name): return json.loads((root/name).read_text(encoding='utf-8'))
    def load(name):
        with np.load(root/name, allow_pickle=False) as z:
            return {k:z[k].copy() for k in z.files}
    def rows(name):
        with (root/name).open(newline='',encoding='utf-8') as f:
            return list(csv.DictReader(f))
    circ=lambda v: np.arctan2(np.sin(v),np.cos(v))
    nrm=lambda v: np.linalg.norm(v,axis=-1)
    H=lambda t: 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
    rs=(3+np.sqrt(3.))/4; zs=.5*np.sqrt(np.sqrt(3.)/2)
    a0=1/32; eta=1e-4; cases=['A0p','A1p','A2p','A3p','Bhalf','Bthreehalf','Czero','Cquarter']
    histories=cases[4:]; arms=['CONTINUE','RETURN']
    sourcebytes={p.relative_to(root).as_posix():digest(p.read_bytes()) for p in root.rglob('*') if p.is_file()}

    with zipfile.ZipFile(a.archive) as z:
        names=z.namelist()
        ok('archive CRC',z.testzip() is None)
        ok('unique archive members',len(names)==len(set(names)))
        ok('safe archive members',all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names))
        ok('no symlink members',all((i.external_attr>>16)&0o170000!=0o120000 for i in z.infolist()))
        manifest=json.loads(z.read('MANIFEST.json'))['files']
        ok('complete manifest',set(names)=={'MANIFEST.json'}|{r['path'] for r in manifest})
        for r in manifest:
            b=z.read(r['path']); ok('manifest '+r['path'],len(b)==r['size_bytes'] and digest(b)==r['sha256'])
            ok('extracted '+r['path'],(root/r['path']).read_bytes()==b)
    b2=(root/'received/reference/CA02_GPT_REVIEW.zip').read_bytes()
    ok('accepted CA02 archive hash',digest(b2)=='b63d01492b96d7e125509f1d3fec7ca2eecdb43f5353fab3b3e18236aa7b34bc')
    if a.ca02_archive: ok('CA02 separate original',b2==a.ca02_archive.read_bytes())
    inherited_files=0
    with zipfile.ZipFile(io.BytesIO(b2)) as z:
        ok('CA02 archive CRC',z.testzip() is None)
        for p in sorted((root/'inputs/CA02').rglob('*')):
            if p.is_file():
                ok('CA02 unchanged '+str(p.relative_to(root)),p.read_bytes()==z.read(p.relative_to(root/'inputs/CA02').as_posix())); inherited_files+=1
        ok('primary evaluator unchanged', (root/'model.py').read_bytes()==z.read('model.py'))
    if a.ca01_archive:
        with zipfile.ZipFile(a.ca01_archive) as z:
            for dest,src in [('received/reference/CA01_ANALYSIS.md','CA01_ANALYSIS.md'),('received/reference/CA01_geometry_reference.npz','evidence/geometry_reference.npz')]:
                ok('CA01 unchanged '+dest,(root/dest).read_bytes()==z.read(src))
    if a.packet:
        with zipfile.ZipFile(a.packet) as z:
            for n in z.namelist():
                if not n.endswith('/'): ok('received packet '+n,(root/'received'/n).read_bytes()==z.read(n))
    before=js('evidence/SOURCES_BEFORE.json'); pres=js('evidence/PRESERVATION.json')
    for b,p in zip(before,pres['sources']):
        ok('source before-after '+b['path'], {k:p[k] for k in b}==b and p['unchanged'])
        bb=(root/b['copy']).read_bytes() if b['copy'] else b2
        ok('consumed copy '+b['path'],len(bb)==b['size_bytes'] and digest(bb)==b['sha256'])
    ok('preservation count',len(before)==len(pres['sources']))
    for kind in ['status','index']:
        ok(kind+' records unchanged',(root/f'evidence/{kind}_before.txt').read_bytes()==(root/f'evidence/{kind}_after.txt').read_bytes())
    ok('index empty',(root/'evidence/index_after.txt').stat().st_size==0)
    for name,h in js('evidence/PRE_RUN_SEAL.json').items():
        sealed_path = 'evidence/PRE_RUN_ANALYSIS.md' if name=='CA03_RETURNING_DRIVE_ANALYSIS.md' else name
        ok('pre-run sealed '+name,digest((root/sealed_path).read_bytes())==h)
    pretext=(root/'evidence/PRE_RUN_ANALYSIS.md').read_text(encoding='utf-8')
    finaltext=(root/'CA03_RETURNING_DRIVE_ANALYSIS.md').read_text(encoding='utf-8')
    ok('pre-run mathematical sections unchanged',pretext.split('## 1.')[1].split('## 8.')[0]==finaltext.split('## 1.')[1].split('## 8.')[0])

    # All calculations below evaluate already saved inputs, never rollouts.
    def saved_eval(s,t,alpha):
        s=np.asarray(s,dtype=float).reshape(-1,3); t=np.asarray(t,dtype=float).reshape(-1); alpha=np.asarray(alpha,dtype=float).reshape(-1)
        x,y,z=s.T
        torque=np.column_stack((y*y-x*z,z*z-x*y,x*x-y*z))
        hv=H(t); q=(alpha*hv)[:,None]*torque
        factor=np.minimum(1.,.8/(nrm(q)+1e-5)); qh=q*factor[:,None]; u=s+.1*qh
        ux,uy,uz=u.T; rr=np.hypot(ux,uy); ll=nrm(u)
        theta=np.arctan2(np.sqrt(ux*ux+uy*uy),uz); phi=np.arctan2(uy,ux)
        trig=np.column_stack(((1+.5*np.cos(theta))*np.cos(phi),(1+.5*np.cos(theta))*np.sin(phi),.5*np.sin(theta)))
        dest=trig.copy(); off=rr>0
        dest[off]=np.column_stack(((1+uz[off]/(2*ll[off]))*ux[off]/rr[off],(1+uz[off]/(2*ll[off]))*uy[off]/rr[off],rr[off]/(2*ll[off])))
        return dict(s=s,t=t,alpha=alpha,H=hv,q=q,qhat=qh,u=u,dest=dest,factor=factor,clipped=factor<1)
    def compare_eval(tag,d):
        v=saved_eval(d['s'],d['t'],d['alpha'])
        for k in v:
            old=np.asarray(d[k]); new=v[k].reshape(old.shape)
            if old.dtype==bool: ok(tag+' '+k,np.array_equal(new,old))
            else: near(tag+' '+k,new,old,category='saved_'+k)
    fixtures=js('inputs/CA02/inputs/CA01/RESULTS.json')['F4_preflight']
    for i,d in enumerate(fixtures): compare_eval('CA01 fixture '+str(i),d)
    inputs=load('INPUTS.npz'); checkpoints={}
    for case in cases:
        old=load('inputs/CA02/raw/'+case+'.npz'); checkpoints[case]=old
        ok('checkpoint row bytes '+case,inputs[case].tobytes()==old['states'][800].tobytes())
        ok('checkpoint phase bytes '+case,inputs[case+'_phase'].tobytes()==old['phase_lift'][800].tobytes())
        for j in [0,400,799]: compare_eval(f'CA02 {case} saved {j}',{k:old[k][j] for k in ['s','t','alpha','H','q','qhat','u','dest','factor','clipped']})
    sb=inputs['A0p']; ph=float(np.arctan2(sb[1],sb[0])); rr=float(np.hypot(sb[0],sb[1])); ll=float(nrm(sb)); beta=float(np.arctan2(sb[2],rr))
    for sg,suf in [(1,'+'),(-1,'-')]:
        starts={'SIZE':(1+sg*eta)*sb,
                'TILT':ll*np.array([np.cos(beta+sg*eta)*np.cos(ph),np.cos(beta+sg*eta)*np.sin(ph),np.sin(beta+sg*eta)]),
                'PHASE':np.array([rr*np.cos(ph+sg*eta),rr*np.sin(ph+sg*eta),sb[2]])}
        for k,s in starts.items():
            near('disturbance '+k+suf,inputs[k+suf],s,tol=2e-15,category='initial_construction')
            near('disturbance lift '+k+suf,inputs[k+suf+'_phase'],inputs['A0p_phase']+(sg*eta if k=='PHASE' else 0),tol=0)
    run=js('RUN_RESULTS.json'); matrix=run['matrix']; data={}; minsegment=float('inf'); maxq=0.; total=0
    ok('fixed numerical matrix',len(matrix)==22 and sum(c['updates'] for c in matrix)==43200)
    expected={c+'_'+arm for c in cases for arm in arms}|{k+s for k in ['SIZE','TILT','PHASE'] for s in ['+','-']}
    ok('expected branch identifiers',{r['id'] for r in matrix}==expected)
    for r in matrix:
        ident=r['id']; d=load('raw/'+ident+'.npz'); data[ident]=d; n=r['updates']; total+=n
        ok(ident+' length',d['states'].shape==(n+1,3) and n==(2400 if ident in {c+'_'+arm for c in cases for arm in arms} else 800))
        ok(ident+' finite',all(np.isfinite(v).all() for v in d.values()))
        j=np.arange(n); f=j+800 if r['arm']=='CONTINUE' else j%800
        for k,v in {'j':j,'n':j+800,'block':j//800+1,'f':f,'t':.1*f,'alpha':np.full(n,a0),
                    'absolute_state_index':800+np.arange(n+1),'continuation_state_index':np.arange(n+1),'completed_new_blocks':np.arange(n+1)//800}.items():
            ok(ident+' exact '+k,np.array_equal(d[k],v))
        ok(ident+' incoming linkage',np.array_equal(d['s'],d['states'][:-1]))
        ok(ident+' outgoing linkage',np.array_equal(d['dest'],d['states'][1:]))
        ok(ident+' initial row bytes',d['states'][0].tobytes()==inputs[r['case']].tobytes())
        ok(ident+' initial phase bytes',d['phase_lift'][0].tobytes()==inputs[r['case']+'_phase'].tobytes())
        compare_eval(ident,d)
        ss=np.sum(d['s']**2,axis=1); uu=np.sum(d['u']**2,axis=1); scale=np.maximum(1.,np.maximum(ss,uu))
        near(ident+' Euler residual',(uu-ss-.01*np.sum(d['qhat']**2,axis=1))/scale,np.zeros(n),category='Euler_scaled')
        near(ident+' perpendicular',np.sum(d['s']*d['qhat'],axis=1)/scale,np.zeros(n),category='perpendicular_scaled')
        allrho=np.hypot(d['states'][:,0],d['states'][:,1]); dr=np.hypot(d['dest'][:,0],d['dest'][:,1])
        near(ident+' torus',(dr-1)**2+d['dest'][:,2]**2,np.full(n,.25),category='torus')
        ok(ident+' upper half',np.min(d['dest'][:,2])>=-1e-14)
        ok(ident+' clip inactive',np.all(d['factor']==1) and not d['clipped'].any())
        maxq=max(maxq,float(nrm(d['q']).max()))
        e=.1*d['qhat']; s=d['s']; den=np.sum(s[:,:2]**2,axis=1)+np.sum(s[:,:2]*e[:,:2],axis=1)
        inc=np.arctan2(s[:,0]*e[:,1]-s[:,1]*e[:,0],den)
        lower=nrm(s[:,:2])-nrm(e[:,:2]); minsegment=min(minsegment,float(lower.min()))
        near(ident+' increments',inc,d['angular_increment'],category='increments')
        near(ident+' denominator',den,d['angle_denominator'],category='denominator')
        near(ident+' lower bound',lower,d['segment_rho_lower'],category='segment_bound')
        ok(ident+' nonsingular',np.min(lower)>0 and np.min(den)>0)
        near(ident+' lift linkage',d['phase_lift'][:-1]+inc,d['phase_lift'][1:],category='phase_linkage')
        near(ident+' azimuth',circ(d['phase_lift']-np.arctan2(d['states'][:,1],d['states'][:,0])),np.zeros(n+1),category='phase_azimuth')
        near(ident+' theta',np.arctan2(d['states'][:,2],allrho-1),d['meridional_theta'],category='theta')
        near(ident+' polar',np.arctan2(allrho,d['states'][:,2]),d['polar_theta'],category='polar')
        near(ident+' circle distance',np.hypot(allrho-rs,d['states'][:,2]-zs),d['distance_to_circle'],category='circle_distance')
    ok('all saved updates',total==43200)
    counts=run['counts']; ok('declared counts',counts['fresh_rollout_calls']==total and counts['fresh_branches_completed']==22 and counts['inherited_prefix_updates_executed']==0 and counts['fresh_isolated_calls']==0 and counts['failed_model_calls']==0)

    # Recompute the measured results directly from the saved branches.
    history_summary=[]
    for case in histories:
        for arm in arms:
            d=data[case+'_'+arm]; ref=data['A0p_'+arm]; diff=circ(d['phase_lift']-ref['phase_lift']); ratio=np.abs(diff)/abs(diff[0])
            history_summary.append(dict(case=case,arm=arm,initial=float(diff[0]),boundary_differences=diff[::800].tolist(),retained_fractions=ratio[::800].tolist(),
                max_change=float(np.max(np.abs(diff-diff[0]))),sign_reversal=bool(np.any(np.sign(diff)!=np.sign(diff[0]))),
                maximum_stepwise_increase=float(np.max(np.diff(np.abs(diff)))),final_cartesian=float(nrm(d['states'][-1]-ref['states'][-1]))))
    for fname in ['BOUNDARY_TABLE.csv','HISTORY_COMPARISONS.csv']:
        for row in rows(fname):
            d=data[row['case']+'_'+row['arm']]; ref=data['A0p_'+row['arm']]; j=int(row['absolute_state_index'])-800
            delta=float(circ(d['phase_lift'][j]-ref['phase_lift'][j])); delta0=float(circ(d['phase_lift'][0]-ref['phase_lift'][0]))
            expected_vals={'phase_lift':float(d['phase_lift'][j]),'phase_mod_2pi':float(d['phase_lift'][j]%(2*np.pi)),
                'phase_displacement_from_checkpoint':float(d['phase_lift'][j]-d['phase_lift'][0]),'phase_difference_from_A0p':delta,
                'lift_difference_from_A0p':float(d['phase_lift'][j]-ref['phase_lift'][j]),'circular_magnitude':abs(delta),
                'meridional_theta':float(d['meridional_theta'][j]),'meridional_difference':float(d['meridional_theta'][j]-ref['meridional_theta'][j]),
                'Cartesian_separation':float(nrm(d['states'][j]-ref['states'][j])),'distance_to_circle':float(d['distance_to_circle'][j])}
            if delta0: expected_vals['ratio_to_checkpoint']=abs(delta)/abs(delta0)
            for k,v in expected_vals.items():near(fname+' '+row['case']+row['arm']+str(j)+' '+k,np.array(v),np.array(float(row[k])),category='table_residual')

    # Independent trigonometric Jacobian and tangent recurrence on saved inputs.
    ref=data['A0p_RETURN']; tangent=load('TANGENT.npz')
    J=np.column_stack((sb,ll*np.array([-np.sin(beta)*np.cos(ph),-np.sin(beta)*np.sin(ph),np.cos(beta)]),np.array([-sb[1],sb[0],0.])))
    sens=[]; angles=[]; mer=[]
    for j in range(801):
        s=ref['states'][j]; x,y,z=s; rh=float(np.hypot(x,y)); w=np.array([x/rh,y/rh,0.])
        gp=np.array([-y,x,0.])/rh**2
        gt=((rh-1)*np.array([0.,0.,1.])-z*w)/((rh-1)**2+z*z)
        sens.append(J.copy()); angles.append(gp@J); mer.append(gt@J)
        if j==800: break
        u=ref['u'][j]; ur=float(np.hypot(u[0],u[1])); ul=float(nrm(u)); ut=np.arctan2(ur,u[2]); up=np.arctan2(u[1],u[0])
        wu=np.array([u[0]/ur,u[1]/ur,0.])
        gradt=(u[2]*wu-ur*np.array([0.,0.,1.]))/(ul*ul)
        gradp=np.array([-u[1],u[0],0.])/(ur*ur)
        output_t=np.array([-.5*np.sin(ut)*np.cos(up),-.5*np.sin(ut)*np.sin(up),.5*np.cos(ut)])
        output_p=np.array([-(1+.5*np.cos(ut))*np.sin(up),(1+.5*np.cos(ut))*np.cos(up),0.])
        DP=np.outer(output_t,gradt)+np.outer(output_p,gradp)
        DA=np.array([[-z,2*y,-x],[-y,-x,2*z],[2*x,-z,-y]])
        near(f'Jacobian radial-null {j}',DP@u,np.zeros(3),category='DP_radial_null')
        DF=DP@(np.eye(3)+.1*a0*ref['H'][j]*DA)
        near(f'saved tangent recurrence {j}',DF@tangent['state_tangent'][j],tangent['state_tangent'][j+1],category='tangent_local')
        J=DF@J
    sens=np.array(sens); angles=np.array(angles); mer=np.array(mer)
    near('full tangent',sens,tangent['state_tangent'],category='tangent_cumulative')
    near('phase tangent',angles,tangent['phase_tangent'],category='phase_tangent')
    near('meridional tangent',mer,tangent['meridional_tangent'],category='meridional_tangent')
    disturbances=[]
    for r in rows('DISTURBANCE_TABLE.csv'):
        d=data[r['id']]; j=int(r['local_state_index']); col=['SIZE','TILT','PHASE'].index(r['parameter']); sign=1 if r['id'].endswith('+') else -1
        diff=float(circ(d['phase_lift'][j]-ref['phase_lift'][j])); pred=sign*eta*angles[j,col]
        near('disturbance table '+r['id']+str(j),np.array([diff,pred]),np.array([float(r['phase_difference']),float(r['linear_tangent_prediction'])]),category='disturbance_table')
        if j==800: disturbances.append(dict(id=r['id'],final_angle_difference=diff,linear_prediction=float(pred)))
    for col,k in enumerate(['SIZE','TILT','PHASE']):
        cd=float((data[k+'+']['phase_lift'][800]-data[k+'-']['phase_lift'][800])/(2*eta))
        row=next(r for r in rows('TANGENT_COMPARISON.csv') if r['parameter']==k)
        near(k+' central difference',np.array(cd),np.array(float(row['central_difference'])))
        near(k+' derivative table',np.array(angles[800,col]),np.array(float(row['tangent_after_block'])))

    # Scalar, exact-rational and symbolic checks. No full-state advances.
    mp.mp.dps=90
    hsum=sum(2*mp.exp(-mp.mpf(n)/20)*mp.cos(mp.mpf(n)/10)+mp.exp(-mp.mpf(3)*n/100)*mp.sin(mp.mpf(n)/10)+mp.mpf('1.5')*mp.exp(-mp.mpf(7)*n/100)+mp.exp(-mp.mpf(n)/25) for n in range(800))
    zn=lambda w:(1-w**800)/(1-w)
    kgeom=(2*mp.re(zn(mp.exp(-mp.mpf('.05')+mp.mpf('.1')*1j)))+mp.im(zn(mp.exp(-mp.mpf('.03')+mp.mpf('.1')*1j)))+mp.mpf('1.5')*zn(mp.exp(-mp.mpf('.07')))+zn(mp.exp(-mp.mpf('.04'))))/10
    ok('finite forcing sum identity',abs(hsum/10-kgeom)<mp.mpf('1e-80'))
    scalar=js('SCALAR_ANALYSIS.json'); near('K800',np.array(float(kgeom)),np.array(scalar['K_N_estimate']),tol=1e-13)
    def I(x): return (Q(x),Q(x))
    def add(a,b):return (a[0]+b[0],a[1]+b[1])
    def neg(a):return (-a[1],-a[0])
    def sub(a,b):return add(a,neg(b))
    def mul(a,b):
        vals=[x*y for x in a for y in b]; return (min(vals),max(vals))
    def div(a,b):
        if b[0]<=0<=b[1]:raise ZeroDivisionError('interval crosses zero')
        return mul(a,(1/b[1],1/b[0]))
    def sq(a):
        lo=Q(0) if a[0]<=0<=a[1] else min(a[0]*a[0],a[1]*a[1]); return (lo,max(a[0]*a[0],a[1]*a[1]))
    def sqrtI(a):
        S=10**60
        def lb(v):return Q(math.isqrt(v.numerator*S*S//v.denominator),S)
        return (lb(a[0]),lb(a[1])+Q(1,S))
    root3=sqrtI(I(3)); ri=div(add(I(3),root3),I(4)); zi=div(sqrtI(div(root3,I(2))),I(2)); bi=div(sub(root3,I(1)),I(4))
    def pol(v):
        vi=I(v)
        return sub(add(add(mul(bi,I(v**4)),mul(mul(I(2),add(ri,zi)),I(v**3))),mul(mul(I(2),sub(ri,zi)),vi)),bi)
    root_checks=[]
    for i,row in enumerate(scalar['roots']):
        lo,hi=map(Q,row['v_bracket']); pl,pu=pol(lo),pol(hi)
        signok=(pl[1]<0<pu[0]) if i==0 else (pu[1]<0<pl[0]); ok('rational leading-root bracket '+str(i),lo<hi and signok)
        ci=div(sub(I(1),sq((lo,hi))),add(I(1),sq((lo,hi))))
        slope=sub(mul(zi,sq(ci)),div(ri,ci)); ok('rational slope sign '+str(i),(slope[1]<0 if i==0 else slope[0]>0))
        v=(mp.mpf(lo.numerator)/lo.denominator+mp.mpf(hi.numerator)/hi.denominator)/2
        phase=(2*mp.atan(v))%(2*mp.pi); rmp=(3+mp.sqrt(3))/4; zmp=mp.sqrt(mp.sqrt(3)/2)/2; bmp=(mp.sqrt(3)-1)/4
        gp=-bmp*mp.sin(phase)+zmp*mp.cos(2*phase)-rmp*mp.cos(phase)
        near('leading phase '+str(i),np.array(float(phase)),np.array(row['phase_estimate']),tol=2e-14)
        near('leading slope '+str(i),np.array(float(gp)),np.array(row['Gprime_estimate']),tol=2e-14)
        root_checks.append(dict(v_bracket=[str(lo),str(hi)],polynomial_signs_verified=True,root_slope_interval=[str(slope[0]),str(slope[1])],phase_estimate=mp.nstr(phase,40),slope_estimate=mp.nstr(gp,40)))
    v,b,r,z=sp.symbols('v b r z',real=True)
    sn=2*v/(1+v*v); cs=(1-v*v)/(1+v*v); G=b*cs+z*sn*cs-r*sn
    poly=b*v**4+2*(r+z)*v**3+2*(r-z)*v-b
    ok('symbolic half-angle quartic',sp.cancel(G*(1+v*v)**2+poly)==0)
    p=sp.symbols('p',real=True); Gp=b*sp.cos(p)+z*sp.sin(p)*sp.cos(p)-r*sp.sin(p)
    identity=sp.diff(Gp,p)-(z*sp.cos(p)**2-r/sp.cos(p))+sp.sin(p)*Gp/sp.cos(p)
    ok('symbolic slope at root',sp.trigsimp(identity)==0)
    mu=(mp.sqrt(3)-2)**800
    ok('nonzero meridional block multiplier',0<mu<1)
    def tail(f):
        return mp.mpf('.225')/32/mp.mpf('.42')*(2*mp.exp(-mp.mpf('.05')*f)/(1-mp.exp(-mp.mpf('.05')))+mp.exp(-mp.mpf('.03')*f)/(1-mp.exp(-mp.mpf('.03')))+mp.mpf('1.5')*mp.exp(-mp.mpf('.07')*f)/(1-mp.exp(-mp.mpf('.07')))+mp.exp(-mp.mpf('.04')*f)/(1-mp.exp(-mp.mpf('.04'))))
    tails={str(f):mp.nstr(tail(f),45) for f in [800,1600,2400,3200]}
    reported=js('COMPARISON_RESULTS.json')['tail_estimates']
    for f,xx in tails.items():ok('tail '+f,abs(mp.mpf(reported[f])-mp.mpf(xx))/mp.mpf(xx)<mp.mpf('1e-13'))
    for row in rows('BLOCK_RESPONSE_TABLE.csv'):
        phi=float(row['input_phase']); gf=(zs*zs/rs)*np.cos(phi)+zs*np.sin(phi)*np.cos(phi)-rs*np.sin(phi)
        dgf=-(zs*zs/rs)*np.sin(phi)+zs*np.cos(2*phi)-rs*np.cos(phi)
        pred=a0*float(kgeom)*gf; gain=1+a0*float(kgeom)*dgf
        near('block table '+row['case']+row['block'],np.array([pred,gain]),np.array([float(row['leading_circle_prediction']),float(row['leading_phase_gain'])]),category='block_table')

    # Passive observation checks: no state transforms fed back into dynamics.
    ob=load('OBSERVER.npz'); geo=load('received/reference/CA01_geometry_reference.npz'); br=rows('BOUNDARY_TABLE.csv')
    native=np.array([data[row['case']+'_'+row['arm']]['states'][int(row['absolute_state_index'])-800] for row in br]); O=geo['origin']; rot=ob['Q']
    near('observer source samples',native,ob['native_states'],tol=0)
    near('proper rotation',rot.T@rot,np.eye(3)); near('determinant',np.array(np.linalg.det(rot)),np.array(1.))
    world=O+native; rotated=O+(world-O)@rot.T; recovered=(rotated-O)@rot
    for k,val in [('world_states',world),('rotated_world_states',rotated),('recovered_components',recovered)]:near('observer '+k,ob[k],val,category='observer_records')
    near('frame recovered components',recovered,native,category='frame_coordinates')
    pa=np.arctan2(native[:,1],native[:,0]); pb=np.arctan2(recovered[:,1],recovered[:,0])
    near('frame phase',circ(pb-pa),np.zeros(64),category='frame_phase')
    near('frame pair distances',nrm(world[:,None,:]-world[None,:,:]),nrm(rotated[:,None,:]-rotated[None,:,:]),category='frame_distances')
    for key in ['plus','minus','host_vertices']:
        ok('geometry retained '+key,np.array_equal(ob[key],geo[key]))
        qv=O+(geo[key]-O)@rot.T; near('rotated geometry '+key,qv,ob[key+'_rotated'])
        d1=nrm(world[:,None,:]-geo[key][None,:,:]); d2=nrm(rotated[:,None,:]-qv[None,:,:])
        near('geometry distances '+key,d1,d2,category='frame_geometry_distances')
        near('nearest '+key,d1.min(axis=1),ob[key+'_nearest_vertex_distance'])
    for k in ['faces','host_faces','boundary_edges']:ok('topology retained '+k,np.array_equal(geo[k],ob[k]))
    near('rotated circle',O+(ob['circle']-O)@rot.T,ob['circle_rotated'])
    near('passive circle distances',np.hypot(np.hypot(native[:,0],native[:,1])-rs,native[:,2]-zs),np.hypot(np.hypot(recovered[:,0],recovered[:,1])-rs,recovered[:,2]-zs),category='frame_circle_distance')
    finalbytes={p.relative_to(root).as_posix():digest(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
    ok('submission not changed by review',sourcebytes==finalbytes)
    results=dict(status='PASS',archive=dict(bytes=a.archive.stat().st_size,sha256=digest(a.archive.read_bytes()),manifested_payloads=len(manifest)),
        coverage=dict(consumed_original_records=len(before),CA02_retained_files=inherited_files,checkpoint_rows=8,branches=len(matrix),
            saved_CA03_transitions=total,saved_CA03_states=total+len(matrix),inherited_fixtures=len(fixtures),inherited_saved_transition_rows=24,
            saved_tangent_steps=800,observer_samples=64,new_trajectories=0,new_rollout_updates=0,native_kernel_updates=0),
        environment=dict(python=sys.version,numpy=np.__version__,sympy=sp.__version__,mpmath=mp.__version__,platform=platform.platform()),
        residual_maxima=maxima,minimum_segment_lower_bound=minsegment,maximum_raw_torque=maxq,
        history_comparisons=history_summary,disturbance_outcomes=disturbances,phase_derivatives_after_one_block=angles[-1].tolist(),
        scalar=dict(K800=mp.nstr(kgeom,50),leading_roots=root_checks,meridional_multiplier=mp.nstr(mu,40),uninterrupted_tails=tails),
        checks=checks,check_count=len(checks),checks_are_not_theorems=True,
        limitations=['No independent access to Windows filesystem or remote; preservation claims are record checks.',
            'Saved-successor and derivative consistency do not enclose accumulated roundoff.',
            'Small-coupling proof has no explicit threshold certifying alpha=1/32.',
            'No source runner imported or launched; no indefinite schedule or extra trajectory executed.'])
    dest=out/'CA03_INDEPENDENT_RESULTS.json'; dest.write_text(json.dumps(results,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({k:results[k] for k in ['status','archive','coverage','residual_maxima','minimum_segment_lower_bound','maximum_raw_torque','phase_derivatives_after_one_block','check_count']},indent=2))

if __name__=='__main__':
    main()
