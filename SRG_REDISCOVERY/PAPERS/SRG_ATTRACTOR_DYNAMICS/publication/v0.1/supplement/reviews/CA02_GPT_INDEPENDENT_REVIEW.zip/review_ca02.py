"""Independent CA02 saved-evidence review. Never launches or continues trajectories.

Reads source code only as AST/text. Checks all saved inputs independently using
component torque and a closed-form remap. mpmath evaluates scalar response/bound
formulas only, not additional three-component trajectories.
"""
from __future__ import annotations
import argparse, ast, csv, hashlib, json, math, platform, stat, sys, zipfile
from pathlib import Path, PurePosixPath
import numpy as np
import sympy as sp
import mpmath as mp


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--ca01-archive', type=Path, required=True)
    parser.add_argument('--attachments-dir', type=Path)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    root = args.input_dir.resolve()
    out = args.output_dir.resolve()
    if out == root or root in out.parents:
        raise ValueError('Reviewer output must be outside the submitted input tree.')
    out.mkdir(parents=True, exist_ok=True)
    log: list[dict] = []
    def check(name, passed, detail=None):
        row = {'name': name, 'passed': bool(passed)}
        if detail is not None: row['detail'] = detail
        log.append(row)
        if not passed: raise AssertionError(name + ': ' + str(detail))
    def jread(rel): return json.loads((root / rel).read_text(encoding='utf-8-sig'))
    def maxabs(v): return float(np.max(np.abs(v))) if np.size(v) else 0.0
    def close(name, a, b, tol=1e-12):
        value=maxabs(np.asarray(a)-np.asarray(b))
        check(name,value<=tol,{'max_absolute_error':value,'tolerance':tol})
        return value
    initial_hashes={str(p.relative_to(root)):digest(p.read_bytes())
                    for p in root.rglob('*') if p.is_file()}
    arcbytes=args.archive.read_bytes()
    with zipfile.ZipFile(args.archive) as z:
        names=z.namelist()
        check('Archive names unique',len(names)==len(set(names)))
        for info in z.infolist():
            rel=PurePosixPath(info.filename)
            check('Safe archive member '+info.filename,
                  not rel.is_absolute() and '..' not in rel.parts and '\\' not in info.filename
                  and not stat.S_ISLNK(info.external_attr>>16))
        check('Archive CRC',z.testzip() is None)
        manifest=json.loads(z.read('MANIFEST.json'))
        entries=manifest['files']
        check('Manifest unique',len(entries)==len({r['path'] for r in entries}))
        check('Manifest complete',set(names)=={r['path'] for r in entries}|{'MANIFEST.json'})
        for r in entries:
            data=z.read(r['path'])
            check('Payload '+r['path'], len(data)==r['size_bytes'] and digest(data)==r['sha256']
                  and data==(root/r['path']).read_bytes())
    inherited=[]
    with zipfile.ZipFile(args.ca01_archive) as z:
        ca01hash=digest(args.ca01_archive.read_bytes())
        check('Accepted CA01 archive identity',ca01hash=='f44ecb11036f72971048c7d6c268233f43b36c06bb1a1204dc1896c6bcd2d8a0')
        for p in sorted((root/'inputs/CA01').rglob('*')):
            if p.is_file():
                rel=p.relative_to(root/'inputs/CA01').as_posix()
                check('Byte-preserved CA01 '+rel,p.read_bytes()==z.read(rel))
                inherited.append(rel)
    received=jread('received/MANIFEST.json')
    received_entries=received.get('files',[])
    # The start-packet manifest has the same conventional path/hash fields.
    for row in received_entries:
        p=root/'received'/row['path']
        check('Received packet '+row['path'],digest(p.read_bytes())==row['sha256'])
    if args.attachments_dir:
        comparisons={'CA02_ENDPOINT_RETENTION_ANALYSIS.md':'CA02_ENDPOINT_RETENTION_ANALYSIS.md',
                     'READ_ME_FIRST(1).md':'READ_ME_FIRST.md',
                     'SRG_CA02_CODEX_WORK_ORDER.md':'received/SRG_CA02_CODEX_WORK_ORDER.md',
                     'CA01_GPT_SCIENTIFIC_REVIEW.md':'received/reference/CA01_GPT_SCIENTIFIC_REVIEW.md'}
        for a,b in comparisons.items():
            check('Separate attachment '+a,(args.attachments_dir/a).read_bytes()==(root/b).read_bytes())
    before=jread('evidence/SOURCES_BEFORE.json'); preservation=jread('evidence/PRESERVATION.json')
    after={r['path']:r for r in preservation['consumed_sources']}
    for row in before:
        later=after[row['path']]
        check('Preservation record '+row['path'],row['sha256']==later['sha256'] and later['unchanged'])
        if row['copy']:
            data=(root/row['copy']).read_bytes()
        else:
            data=args.ca01_archive.read_bytes()
        check('Consumed-source identity '+row['path'],digest(data)==row['sha256'] and len(data)==row['size'])
    check('Before/after Git status records identical',(root/'evidence/status_before.txt').read_bytes()==(root/'evidence/status_after.txt').read_bytes())
    check('Supplied index records empty',all((root/f'evidence/index_{s}.txt').read_bytes()==b'' for s in ['before','after']))
    check('Recorded HEAD unchanged',preservation['HEAD_before']==preservation['HEAD_after'])
    def functions(path):
        return {node.name:node for node in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig')))
                if isinstance(node,ast.FunctionDef)}
    dest=functions(root/'model.py'); orig=functions(root/'inputs/CA01/run_checks.py')
    hs=functions(root/'inputs/CA01/evidence/detached_F3_helpers.py.txt')
    for name in ['H','finite','P','step']:
        a=hs[name] if name=='H' else orig[name]
        check('Identical function AST '+name,ast.dump(a)==ast.dump(dest[name]))
    extraction=jread('evidence/MODEL_EXTRACTION.json')
    check('Model recorded hash',digest((root/'model.py').read_bytes())==extraction['model_sha256'])
    for f,h in extraction['before_fresh_execution'].items():
        if f!='CA02_ENDPOINT_RETENTION_ANALYSIS.md':
            check('Unchanged execution input '+f,digest((root/f).read_bytes())==h)

    rho=(3+np.sqrt(3.))/4
    zstar=.5*np.sqrt(np.sqrt(3.)/2)
    Lstar=np.hypot(rho,zstar)
    def circle(phi): return np.array([rho*np.cos(phi),rho*np.sin(phi),zstar])
    def forcing(t):
        return 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
    def evaluate_saved(s,t,alpha,closed=True):
        # Entire arrays of independent saved inputs: no computed successor is reused.
        x,y,z=s.T
        A=np.column_stack((y*y-x*z,z*z-x*y,x*x-y*z))
        h=forcing(t)
        q=(alpha*h)[:,None]*A
        factor=np.minimum(1.,.8/(np.linalg.norm(q,axis=1)+1e-5))
        qhat=q*factor[:,None]; u=s+.1*qhat
        ux,uy,uz=u.T
        rr=np.hypot(ux,uy); ll=np.linalg.norm(u,axis=1)
        if closed:
            dest=np.column_stack(((1+.5*uz/ll)*ux/rr,(1+.5*uz/ll)*uy/rr,.5*rr/ll))
        else:
            # Inherited axis/origin fixtures use the declared atan2 convention.
            th=np.arctan2(np.sqrt(ux*ux+uy*uy),uz); ph=np.arctan2(uy,ux)
            dest=np.column_stack(((1+.5*np.cos(th))*np.cos(ph),(1+.5*np.cos(th))*np.sin(ph),.5*np.sin(th)))
        return dict(H=h,q=q,factor=factor,qhat=qhat,u=u,dest=dest,clipped=factor<1.)

    # 12 saved fixtures plus 200 independently supplied predecessors, not new runs.
    inherited_results=jread('inputs/CA01/RESULTS.json')
    fixture_max=0.
    for i,row in enumerate(inherited_results['F4_preflight']):
        ev=evaluate_saved(np.array(row['s'])[None,:],np.array([row['t']]),np.array([row['alpha']]),closed=False)
        for key, val in ev.items():
            fixture_max=max(fixture_max,close(f'Inherited fixture {i} {key}',val[0].astype(float) if isinstance(val[0],np.ndarray) else float(val[0]),row[key]))
    with np.load(root/'inputs/CA01/raw/F4_remap_only.npz',allow_pickle=False) as data:
        ev=evaluate_saved(data['s'],data['t'],data['alpha'])
        for key, val in ev.items():
            fixture_max=max(fixture_max,close('Inherited 200 transitions '+key,np.asarray(val,dtype=float),np.asarray(data[key],dtype=float)))
        close('Inherited successor storage',data['states'][1:],data['dest'],tol=0.)

    expected=[]
    for j,phi in enumerate([0.,np.pi/2,np.pi,3*np.pi/2]):
        for sign,suffix in [(1,'p'),(-1,'m')]: expected.append((f'A{j}{suffix}',circle(phi),sign/32,phi))
    for lam,name in [(.5,'Bhalf'),(1.5,'Bthreehalf')]: expected.append((name,lam*circle(0.),1/32,0.))
    for beta,name in [(0.,'Czero'),(np.pi/4,'Cquarter')]: expected.append((name,Lstar*np.array([np.cos(beta),0.,np.sin(beta)]),1/32,0.))
    for j,phi in enumerate([0.,np.pi/2]):
        for sign,suffix in [(1,'p'),(-1,'m')]: expected.append((f'D{j}{suffix}',circle(phi),sign/64,phi))
    runs=jread('RUN_RESULTS.json'); observed={r['id']:r for r in runs['runs']}
    check('Exactly the 16 authorized cases',set(observed)=={r[0] for r in expected}=={p.stem for p in (root/'raw').glob('*.npz')})
    counts=runs['counts']
    check('Recorded execution limits',runs['status']=='COMPLETED' and counts['fresh_rollout_calls']==12800
          and counts['fresh_trajectories_completed']==16 and counts['fresh_isolated_calls']==0
          and counts['failed_fresh_calls']==0 and counts['kernel_updates']==0)
    check('Recorded resource limits',runs['elapsed_seconds']<600 and runs['workspace_bytes_at_stage_end']<250000000)
    maxes={}; perrun={}; phase_ends={}
    minseg=float('inf'); maxq=0.; clipped_total=0
    def track(key,value): maxes[key]=max(maxes.get(key,0.),float(value))
    for name,start,alpha,phi0 in expected:
        with np.load(root/'raw'/f'{name}.npz',allow_pickle=False) as a:
            for key in a.files: check(name+' finite '+key,np.isfinite(a[key]).all())
            check(name+' saved shapes',a['states'].shape==(801,3) and a['s'].shape==(800,3))
            close(name+' declared start',a['states'][0],start)
            close(name+' recorded initial state',a['states'][0],observed[name]['initial_state'],tol=0.)
            close(name+' indices',a['n'],np.arange(800),tol=0.)
            close(name+' state indices',a['state_index'],np.arange(801),tol=0.)
            close(name+' clock',a['t'],.1*np.arange(800),tol=0.)
            close(name+' state clock',a['state_forcing_time'],.1*np.arange(801),tol=0.)
            close(name+' constant alpha',a['alpha'],np.full(800,alpha),tol=0.)
            close(name+' incoming storage',a['s'],a['states'][:-1],tol=0.)
            close(name+' successor storage',a['dest'],a['states'][1:],tol=0.)
            ev=evaluate_saved(a['s'],a['t'],a['alpha'])
            for key,val in ev.items(): track(key,close(name+' independent '+key,np.asarray(val,dtype=float),np.asarray(a[key],dtype=float)))
            e=.1*ev['qhat'];s=a['s'];u=ev['u'];d=a['dest'];x,y,z=s.T
            ss=np.sum(s*s,axis=1);uu=np.sum(u*u,axis=1);qq=np.sum(ev['qhat']**2,axis=1)
            scale=np.maximum(1,np.maximum(ss,uu))
            euler=np.abs(uu-ss-.01*qq)/scale
            perpendicular=np.abs(np.sum(s*ev['qhat'],axis=1))/scale
            surface=np.abs((np.hypot(d[:,0],d[:,1])-1)**2+d[:,2]**2-.25)
            for key,arr in [('euler_scaled',euler),('perpendicular_scaled',perpendicular),('surface',surface)]:
                value=maxabs(arr);check(name+' '+key,value<1e-12,value);track(key,value)
            check(name+' upper torus',np.min(d[:,2])>=0.)
            radius=np.hypot(x,y);lower=radius-np.linalg.norm(e[:,:2],axis=1)
            denom=x*x+y*y+x*e[:,0]+y*e[:,1]
            inc=np.arctan2(x*e[:,1]-y*e[:,0],denom)
            track('angular_increment',close(name+' angular increment',inc,a['angular_increment']))
            close(name+' segment bound',lower,a['segment_rho_lower'])
            close(name+' angular denominator',denom,a['angle_denominator'])
            check(name+' nonzero horizontal segments',np.min(lower)>0)
            minseg=min(minseg,float(np.min(lower)))
            qnorm=np.linalg.norm(ev['q'],axis=1);maxq=max(maxq,float(np.max(qnorm)))
            check(name+' analytic clip limits',qnorm[0]<=729/1024 and np.max(qnorm[1:])<=81/256)
            check(name+' clip inactive',np.all(a['factor']==1.) and not np.any(a['clipped']))
            clipped_total+=int(np.sum(a['clipped']))
            # Compensated sum of SAVED increments; no state advancement.
            summed=phi0+math.fsum(a['angular_increment'].tolist())
            lift=a['phase_lift'];delta=lift-np.arctan2(a['states'][:,1],a['states'][:,0])
            lifted_res=maxabs(np.arctan2(np.sin(delta),np.cos(delta)))
            check(name+' azimuth lift',lifted_res<1e-12,lifted_res);track('lift_vs_azimuth',lifted_res)
            track('lift_vs_compensated_sum',close(name+' compensated final lift',summed,lift[-1]))
            close(name+' stored lift updates',lift[1:]-lift[:-1],a['angular_increment'])
            dist=np.hypot(np.hypot(a['states'][:,0],a['states'][:,1])-rho,a['states'][:,2]-zstar)
            close(name+' distance to fixed circle',dist,a['distance_to_circle'])
            phase_ends[name]=float(lift[-1])
            perrun[name]={'phase_800':float(lift[-1]),'circle_distance_800':float(dist[-1]),
                          'first_increment':float(inc[0]),'maximum_increment':float(np.max(np.abs(inc))),
                          'minimum_segment_radius':float(np.min(lower)),'maximum_torque':float(np.max(qnorm))}
            check(name+' raw record hash',digest((root/'raw'/f'{name}.npz').read_bytes())==observed[name]['raw_sha256'])

    # Bounded, high-precision scalar calculations; these do not evolve a 3D state.
    mp.mp.dps=80
    R=(3+mp.sqrt(3))/4;Z=mp.sqrt(mp.sqrt(3)/2)/2;L=mp.sqrt(R*R+Z*Z)
    S=2*mp.re(1/(1-mp.exp(-mp.mpf('.05')+mp.mpf('.1')*1j)))+mp.im(1/(1-mp.exp(-mp.mpf('.03')+mp.mpf('.1')*1j)))+mp.mpf('1.5')/(1-mp.exp(-mp.mpf('.07')))+1/(1-mp.exp(-mp.mpf('.04')))
    b=(mp.sqrt(3)-1)/4
    def mpH(n):
        t=mp.mpf(n)/10
        return 2*mp.exp(-t/2)*mp.cos(t)+mp.exp(-3*t/10)*mp.sin(t)+mp.mpf('1.5')*mp.exp(-7*t/10)+mp.exp(-2*t/5)
    def coeff_fixed(j): return S/10*[b,-R,-b,R][j]
    def coeff_tilt(beta):
        W0=L*mp.sin(beta)**2/mp.cos(beta); theta=mp.pi/2-beta; corr=mp.mpf(0)
        for n in range(1,40):
            w=mp.sin(theta)**2/(4*(1+mp.cos(theta)/2))
            corr+=mpH(n)*(w-b)
            theta=mp.atan2(1+mp.cos(theta)/2,mp.sin(theta)/2)
        return (S*b+mp.mpf('4.5')*(W0-b)+corr)/10
    deriv={}
    for j in range(4):
        for suf in ['p','m']: deriv[f'A{j}{suf}']=float(coeff_fixed(j))
    for j in range(2):
        for suf in ['p','m']: deriv[f'D{j}{suf}']=float(coeff_fixed(j))
    deriv['Bhalf']=float(coeff_fixed(0)-mp.mpf('.225')*b)
    deriv['Bthreehalf']=float(coeff_fixed(0)+mp.mpf('.225')*b)
    deriv['Czero']=float(coeff_tilt(mp.mpf(0)))
    deriv['Cquarter']=float(coeff_tilt(mp.pi/4))
    def tail(alpha,N=800):
        envelope=sum(weight*mp.exp(-rate*N)/(1-mp.exp(-rate)) for weight,rate in
                     [(2,mp.mpf('.05')),(1,mp.mpf('.03')),(mp.mpf('1.5'),mp.mpf('.07')),(1,mp.mpf('.04'))])
        return mp.mpf('.225')*abs(mp.mpf(alpha))/mp.mpf('.42')*envelope
    tilt_remainder=mp.mpf('.45')*5*mp.pi/16*mp.power(3,-39)/(1-mp.mpf(1)/3)
    table=list(csv.DictReader((root/'ENDPOINT_TABLE.csv').open(newline='')))
    check('Endpoint table identifiers',{r['id'] for r in table}==set(perrun) and len(table)==16)
    for row in table:
        name=row['id'];alpha=float(row['alpha']);ph=float(row['phi0']);phase=phase_ends[name]
        close(name+' table phase',phase,float(row['phase_800_lift']),tol=0.)
        close(name+' analytic coefficient',deriv[name],float(row['analytic_D_at_zero']))
        close(name+' first-order prediction',alpha*deriv[name],float(row['alpha_D']))
        close(name+' residual prediction',phase-ph-alpha*deriv[name],float(row['shift_minus_linear']))
        close(name+' table circle distance',perrun[name]['circle_distance_800'],float(row['distance_to_circle_800']))
        approx=float(tail(alpha))
        check(name+' tail expression evaluation',math.isclose(approx,float(row['exact_tail_bound_estimate']),rel_tol=1e-13))
    dtable=list(csv.DictReader((root/'DERIVATIVE_TABLE.csv').open(newline='')))
    cd=[]
    for j,row in enumerate(dtable):
        Dh=(phase_ends[f'A{j}p']-phase_ends[f'A{j}m'])/(2/32)
        Dhalf=(phase_ends[f'D{j}p']-phase_ends[f'D{j}m'])/(2/64)
        Da=float(coeff_fixed(j))
        close(f'Derivative row {j} h',Dh,float(row['central_a']))
        close(f'Derivative row {j} h/2',Dhalf,float(row['central_half_a']))
        close(f'Derivative row {j} coefficient',Da,float(row['analytic_D']))
        close(f'Derivative row {j} error h',Dh-Da,float(row['error_a']))
        close(f'Derivative row {j} error h/2',Dhalf-Da,float(row['error_half_a']))
        ratio=abs((Dh-Da)/(Dhalf-Da));close(f'Derivative row {j} ratio',ratio,float(row['observed_absolute_error_ratio']),tol=1e-8)
        cd.append({'phi_index':j,'analytic_D_80_digit_eval':str(coeff_fixed(j)),
                   'central_h':Dh,'central_half_h':Dhalf,'error_ratio':ratio})
    comparison=list(csv.DictReader((root/'INITIAL_STATE_COMPARISONS.csv').open(newline='')))
    for row in comparison:
        name=row['id'];delta=phase_ends[name]-phase_ends['A0p'];circ=math.atan2(math.sin(delta),math.cos(delta))
        close(name+' comparison delta',circ,float(row['circular_difference']))
        close(name+' comparison first order',(deriv[name]-deriv['A0p'])/32,float(row['first_order_difference']))

    # Algebraic checks supplement the separately written proof review.
    x,y,z,l=sp.symbols('x y z l', real=True)
    vec=sp.Matrix([x,y,z]);C=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    A=vec.cross(C*vec);W=(x*A[1]-y*A[0])/(x*x+y*y)
    check('Symbolic component torque',A==sp.Matrix([y*y-x*z,z*z-x*y,x*x-y*z]))
    check('Symbolic torque perpendicularity',sp.expand(vec.dot(A))==0)
    check('Symbolic angular factor',sp.simplify(W-(x*z*(z+y)/(x*x+y*y)-y))==0)
    check('Symbolic diagonal-ray zero torque',A.subs({x:l,y:l,z:l})==sp.zeros(3,1))
    check('Symbolic W degree-one homogeneity',sp.simplify(W.subs({x:l*x,y:l*y,z:l*z},simultaneous=True)-l*W)==0)
    sqrt3=sp.sqrt(3);Rs=(3+sqrt3)/4;Zs=sp.sqrt(sqrt3/2)/2
    check('Symbolic b coefficient',sp.simplify(Zs**2/Rs-(sqrt3-1)/4)==0)
    # Explicit inequalities used in the two tilt proofs, evaluated as scalar cross-checks.
    lead_zero=mp.mpf('.45')*(mp.mpf('.25')-2*b)
    tail_zero=mp.mpf('.45')*mp.mpf(5)/8*mp.mpf('.108')/(1-mp.mpf(1)/3)
    lead_quarter=mp.mpf('.45')*(mp.mpf('.89')-mp.mpf('.184'))
    tail_quarter=mp.mpf('.45')*mp.mpf(5)/8*(mp.pi/6)/(1-mp.mpf(1)/3)
    check('Zero-tilt strict upper bound negative',lead_zero+tail_zero<0)
    check('Quarter-tilt strict lower bound positive',lead_quarter-tail_quarter>0)
    check('Inputs unchanged during review',initial_hashes=={str(p.relative_to(root)):digest(p.read_bytes()) for p in root.rglob('*') if p.is_file()})
    result={'status':'PASS','archive':{'name':args.archive.name,'bytes':len(arcbytes),'sha256':digest(arcbytes)},
            'scope':'Passive saved-evidence, algebraic-identity and scalar-formula verification; written proof review separate.',
            'coverage':{'manifested_payloads':len(entries),'archive_members':len(entries)+1,'consumed_original_records':len(before),
                        'ca01_byte_identical_members':len(inherited),'unchanged_function_ASTs':4,
                        'inherited_fixtures':12,'inherited_saved_transitions':200,'saved_CA02_transitions':12800,
                        'saved_CA02_states':16*801,'new_trajectories':0,'new_rollout_updates':0,'native_kernel_updates':0,
                        'scalar_tilt_coefficients':2,'scalar_correction_terms_per_tilt':39},
            'max_residuals':maxes,'inherited_max_residual':fixture_max,'minimum_segment_radius':minseg,
            'maximum_raw_torque':maxq,'clipped_saved_records':clipped_total,'per_run':perrun,
            'scalar_checks':{'S_80_digit_eval':str(S),'B800_one_over_32_80_digit_eval':str(tail(mp.mpf(1)/32)),
                             'tilt_derivative_remainder_M40_80_digit_eval':str(tilt_remainder),
                             'tilt_zero_upper_bound':str(lead_zero+tail_zero),'tilt_quarter_lower_bound':str(lead_quarter-tail_quarter),
                             'response_coefficients':deriv,'central_differences':cd},
            'environment':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'sympy':sp.__version__,'mpmath':mp.__version__},
            'limitations':['No direct Windows-filesystem or remote-Git inspection.','No accumulated floating-point-error enclosure.',
                           '80-digit scalar calculations are numerical cross-checks, not directed-rounding intervals.',
                           'Boolean checks include integrity/consistency checks, not a theorem count.'],
            'checks_count':len(log),'checks':log}
    target=out/'CA02_INDEPENDENT_RESULTS.json'; target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['status','archive','coverage','max_residuals','checks_count']},indent=2))
    print('Saved',target)

if __name__=='__main__': main()
