# Reproducing the CA04 review

The submitted CA04 archive remains the authoritative reviewed input. This package contains the reviewer's supplementary checker and recorded results; it does not contain a modified scientific model.

Extract `CA04_GPT_REVIEW.zip` into an `input` directory and make a separate fresh copy named `fixed_replay`. Do not run the verifier in the preserved `input` directory. The verifier writes its ledger and verification output in its own directory.

Run the submitted verifier **once** in `fixed_replay`:

```bat
call conda activate torment
cd /d C:\path\to\fixed_replay
python -B verify_certificate.py
```

This regenerates the fixed certificate without choosing roots, boxes or new inputs. It uses 8,000 validated set steps; the copied ledger adds them to the earlier study's counts. Do not reset or overwrite the ledger on subsequent invocations.

Then run the reviewer checker, with the accepted CA03 archive and the unchanged CA04 start packet available:

```bat
python -B C:\path\to\review_ca04.py --input-dir C:\path\to\input --archive C:\path\to\CA04_GPT_REVIEW.zip --ca03-archive C:\path\to\CA03_GPT_REVIEW.zip --packet C:\path\to\SRG_CA04_CODEX_START_PACKET.zip --replay-dir C:\path\to\fixed_replay --output-dir C:\path\to\new_reviewer_output
```

Use ordinary Python, not `python -O`: proof and consistency obligations use assertions. Existing NumPy and SymPy are used; no installation or environment changes are required by these instructions.

The reviewer's independent forcing calculation uses Fraction endpoints quantized outward on a 224-bit dyadic grid, degree-96 Taylor polynomials on x/256, explicit remainder bounds and eight doubling identities. It is separate code from the submission's 160-bit interval implementation. It verifies containment, not merely similar floating values. The root-phase check is also separately bounded.

All main reviewer checks are non-trajectory computations. The twelve one-step saved-state evaluations do not chain computed outputs. The submitted verifier's fresh interval propagation is explicitly counted separately. A complete log of what was done in this review, including a corrected reviewer-only heading-comparison assumption, is in `CA04_REVIEW_ACTIVITY.json`.

The first checker invocation stopped before scalar/trajectory work because its literal text test included a renamed report heading. The corrected checker verifies the unchanged mathematical body. This was not a source or scientific correction to CA04.

Trust assumptions and limits are described in the scientific review. Do not read a PASS, hash match or high-precision decimal as a substitute for the accompanying mathematical and arithmetic audit.
