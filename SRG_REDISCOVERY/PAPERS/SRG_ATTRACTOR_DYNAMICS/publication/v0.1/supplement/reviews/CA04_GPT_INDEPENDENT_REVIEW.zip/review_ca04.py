"""Independent CA04 artifact, exact-inequality and scalar-arithmetic review.

Does not perform candidate search or advance a state trajectory. The separately
run submitted fixed verifier is checked through its saved replay evidence.
An independently written 224-bit rational-endpoint engine constructs alternative
rigorous enclosures of all 800 prescribed forcing values. Neither mpmath nor
binary64 values are used as proof bounds.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, io, json, platform, stat, sys, zipfile
from fractions import Fraction as F
from math import isqrt, factorial
from pathlib import Path, PurePosixPath
import numpy as np
import sympy as sp

Q = 1 << 160
checks = 0

def test(ok, message):
    global checks
    checks += 1
    if not ok: raise AssertionError(message)

def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def ratint(a): return tuple(F(int(x), Q) for x in a)
def mag(a): return max(abs(a[0]), abs(a[1]))
def within(inner, outer): return outer[0] <= inner[0] <= inner[1] <= outer[1]

class RI:
    """Independent outward intervals with Fraction endpoints; grid 2**-224."""
    grid = 1 << 224
    __slots__ = ('l', 'h')
    def __init__(self, l=0, h=None):
        l=F(l); h=l if h is None else F(h)
        if l>h: raise ValueError('reversed endpoints')
        self.l=F((l.numerator*self.grid)//l.denominator,self.grid)
        self.h=F(-((-h.numerator*self.grid)//h.denominator),self.grid)
    @staticmethod
    def obj(x): return x if isinstance(x, RI) else RI(x)
    def __add__(self,o):
        o=self.obj(o); return RI(self.l+o.l,self.h+o.h)
    __radd__=__add__
    def __neg__(self): return RI(-self.h,-self.l)
    def __sub__(self,o): return self+-self.obj(o)
    def __rsub__(self,o): return self.obj(o)+-self
    def __mul__(self,o):
        o=self.obj(o); a=[x*y for x in (self.l,self.h) for y in (o.l,o.h)]
        return RI(min(a),max(a))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=self.obj(o)
        if o.l<=0<=o.h: raise ZeroDivisionError
        return self*RI(1/o.h,1/o.l)
    def square(self):
        a=[self.l*self.l,self.h*self.h]
        return RI(0 if self.l<=0<=self.h else min(a),max(a))
    def sqrt(self):
        if self.l<0: raise ValueError('sqrt negative')
        # Endpoints are dyadic grid multiples, so sqrt scaling is integral.
        low_n=int(self.l*self.grid)*self.grid
        high_n=int(self.h*self.grid)*self.grid
        l=isqrt(low_n);h=isqrt(high_n)
        if h*h<high_n:h+=1
        return RI(F(l,self.grid),F(h,self.grid))

def alt_exp(x):
    # Distinct reduction (256), polynomial (96) and grid (224 bits).
    y=RI(x)/256
    test(max(abs(y.l),abs(y.h))<1,'independent exp reduction')
    term=RI(1); val=RI(1)
    for n in range(1,97):
        term=term*y/n;val=val+term
    error=F(3,factorial(97));val=val+RI(-error,error)
    test(val.l>0,'independent exp positivity')
    for _ in range(8):val=val.square()
    return val

def alt_sc(x):
    y=RI(x)/256
    test(max(abs(y.l),abs(y.h))<1,'independent trig reduction')
    p=RI(1);s=RI(0);c=RI(1)
    for n in range(1,97):
        p=p*y/n
        if n%2:s=s+((-1)**((n-1)//2))*p
        else:c=c+((-1)**(n//2))*p
    err=F(1,factorial(97));s=s+RI(-err,err);c=c+RI(-err,err)
    for _ in range(8):s,c=2*s*c,c.square()-s.square()
    return s,c

def alt_phase(v):
    # Endpoint monotonicity plus an independently evaluated 96-term series.
    def point(x):
        test(abs(x)<F(1,2),'independent atan branch')
        p=RI(x);out=RI(0);x2=RI(x).square()
        for j in range(96):out=out+((-1)**j)*p/(2*j+1);p=p*x2
        err=abs(x)**193/193
        return 2*(out+RI(-err,err))
    l=point(v[0]);h=point(v[1]);return l.l,h.h

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir',type=Path,required=True)
    ap.add_argument('--archive',type=Path,required=True)
    ap.add_argument('--ca03-archive',type=Path,required=True)
    ap.add_argument('--packet',type=Path,required=True)
    ap.add_argument('--replay-dir',type=Path,required=True)
    ap.add_argument('--output-dir',type=Path,required=True)
    a=ap.parse_args();b=a.input_dir;o=a.output_dir;o.mkdir(parents=True,exist_ok=True)
    out={'environment':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'sympy':sp.__version__},'activity':{'new_point_trajectories':0,'new_candidate_searches':0,'new_native_updates':0,'independent_saved_transition_checks':12,'independent_scalar_forcing_values':800},'status':'IN_PROGRESS'}
    with zipfile.ZipFile(a.archive) as z:
        names=z.namelist();test(z.testzip() is None,'archive CRC');test(len(names)==len(set(names)),'unique names')
        for member in z.infolist():
            p=PurePosixPath(member.filename)
            test(not p.is_absolute() and '..' not in p.parts and '\\' not in member.filename and ':' not in member.filename,'member safety')
            test(not stat.S_ISLNK(member.external_attr>>16),'symlink safety')
        m=json.loads(z.read('MANIFEST.json'))
        test(set(names)=={'MANIFEST.json'}|{x['path'] for x in m['files']},'manifest coverage')
        for x in m['files']:
            data=z.read(x['path']);test(len(data)==x['size_bytes'] and sha(data)==x['sha256'],'manifest '+x['path'])
            test((b/x['path']).read_bytes()==data,'extraction '+x['path'])
    out['archive']={'bytes':a.archive.stat().st_size,'sha256':sha(a.archive.read_bytes()),'payloads':len(m['files']),'members':len(names)}
    with zipfile.ZipFile(a.ca03_archive) as old, zipfile.ZipFile(a.packet) as packet:
        test(a.ca03_archive.read_bytes()==(b/'inputs/packet/reference/CA03_GPT_REVIEW.zip').read_bytes(),'accepted CA03 archive')
        test(sha(a.ca03_archive.read_bytes())=='bc18315ce76f64ca8dae5b3fafa4bec77ce0e1eceb06a566a087c01fadb044e4','accepted CA03 hash')
        for p in (b/'inputs/ca03').rglob('*'):
            if p.is_file():test(p.read_bytes()==old.read(p.relative_to(b/'inputs/ca03').as_posix()),'CA03 member '+p.name)
        for p in (b/'inputs/packet').rglob('*'):
            if p.is_file():test(p.read_bytes()==packet.read(p.relative_to(b/'inputs/packet').as_posix()),'packet member '+p.name)
        test((b/'reference_model.py').read_bytes()==old.read('model.py'),'unchanged primary model')
        before=load(b/'PRESERVATION_BEFORE.json');after=load(b/'PRESERVATION_AFTER.json')
        test(len(before)==len(after['originals']),'preservation count')
        for x,y in zip(before,after['originals']):
            test(x=={k:y[k] for k in x} and y['unchanged'],'preservation pair')
            if x['path'].endswith('SRG_CA04_CODEX_START_PACKET.zip'):data=a.packet.read_bytes()
            elif x['path'].endswith('CA03_GPT_REVIEW.zip'):data=a.ca03_archive.read_bytes()
            else:
                path=x['path'].split('CA03_returning_drive_v0.1\\',1)[1].replace('\\','/')
                data=old.read(path)
            test(len(data)==x['size'] and sha(data)==x['sha256'],'consumed original '+x['path'])
    out['consumed_originals']=len(before)
    for n in ['HEAD','INDEX','TRACKED']:
        test((b/f'evidence/BEFORE_{n}.txt').read_bytes()==(b/f'evidence/AFTER_{n}.txt').read_bytes(),'Git record '+n)
    own='SRG_REDISCOVERY/CENTRAL_ATTRACTOR_ANALYSIS/CA04_finite_coupling_certificate_v0.1/'
    filt=lambda p:[line for line in p.read_text().splitlines() if own not in line]
    test(filt(b/'evidence/BEFORE_STATUS.txt')==filt(b/'evidence/AFTER_STATUS.txt'),'outside status')
    out['outside_status_records']=len(filt(b/'evidence/AFTER_STATUS.txt'))
    out['preservation_limitation']='Supplied records only, not direct Windows access. Existing Git overlong-path warnings prevent a complete untracked-tree inventory.'
    cert=load(b/'CERTIFICATE.json');index=load(b/'CA04_INPUT_INDEX.json')
    test(cert['target']=={'alpha':'1/32','dt':'1/10','N':800,'forcing_indices':[0,799],'clip':'4/5','epsilon':'1/100000','semantics':'exact-real'},'frozen target')
    for seal in [load(b/'PRE_RUN_SEAL.json')['files'],load(b/'FINAL_CODE_SEAL.json')['files'],cert['code_sha256']]:
        for n,h in seal.items():test(sha((b/n).read_bytes())==h,'source seal '+n)
    for sess in load(b/'EXECUTION_LEDGER.json')['sessions']:
        test(sess['status']=='COMPLETE','session complete')
        for n,h in sess['code_sha256'].items():test(sha((b/n).read_bytes())==h,'session seal '+n)
    test((b/'PRE_RUN_ANALYSIS.md').read_text().split('\n',1)[1].strip() in (b/'CA04_FINITE_COUPLING_ANALYSIS.md').read_text(),'sealed mathematical body retained; heading renamed')
    # Independent primitive checks against exact rational endpoint extrema.
    spec=importlib.util.spec_from_file_location('reviewed_interval_core',b/'interval_core.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    I=core.I
    tests_before=checks
    boxes=[(F(i,7),F(i+2,7)) for i in range(-7,8)]+[(F(0),F(0)),(F(-1,2**170),F(1,2**170)),(F(1,2**170),F(1,2**169))]
    for l,h in boxes:
        aa=I.box(l,h);al,ah=aa.lower(),aa.upper();test(al<=l<=h<=ah,'directed conversion')
        for blo,bhi in boxes:
            bb=I.box(blo,bhi);bl,bh=bb.lower(),bb.upper()
            for val,lo,hi in [(aa+bb,al+bl,ah+bh),(aa-bb,al-bh,ah-bl)]:test(val.lower()<=lo<=hi<=val.upper(),'signed exact primitive')
            products=[x*y for x in (al,ah) for y in (bl,bh)]
            mul=aa*bb;test(mul.lower()<=min(products)<=max(products)<=mul.upper(),'exact multiply extrema')
            if not bl<=0<=bh:
                vals=[x/y for x in (al,ah) for y in (bl,bh)];div=aa/bb
                test(div.lower()<=min(vals)<=max(vals)<=div.upper(),'signed exact division')
        sq=aa**2;lo=0 if al<=0<=ah else min(al*al,ah*ah);hi=max(al*al,ah*ah)
        test(sq.lower()<=lo<=hi<=sq.upper(),'square interval')
        pos=I.box(0,max(abs(l),abs(h))+F(1,13));rt=pos.sqrt()
        test(rt.lower()>=0 and rt.lower()**2<=pos.lower() and rt.upper()**2>=pos.upper(),'integer sqrt enclosure')
    out['primitive_endpoint_checks']=checks-tests_before
    # Independently regenerate exact enclosure of prescribed scalar forcing.
    table=load(b/'FORCING_INTERVALS.json')['values'];alt=[]
    test(len(table)==800,'800 forcing values')
    for n in range(800):
        t=F(n,10);s,c=alt_sc(t)
        h=2*alt_exp(-t/2)*c+alt_exp(-3*t/10)*s+F(3,2)*alt_exp(-7*t/10)+alt_exp(-2*t/5)
        given=ratint(table[n]);test(within((h.l,h.h),given),'independent H enclosure '+str(n))
        alt.append([str(h.l),str(h.h)])
    (o/'INDEPENDENT_FORCING_224.json').write_text(json.dumps({'method':'224-bit Fraction-endpoint directed intervals, degree-96 Taylor at x/256, remainder plus eight doubling identities','values':alt},indent=2))
    out['forcing_independence']='All 800 independent rigorous enclosures are contained in the submitted 160-bit forcing intervals.'
    # Review all exact certificate inequalities independently using Fractions.
    center=list(map(F,cert['center']));res=[ratint(x) for x in cert['center_residual']['enclosure']]
    e=[mag(x) for x in res];test(e==list(map(F,cert['center_residual']['e'])),'center e')
    details={}
    for key,bound in [('primary',F(851,1000)),('larger_region',F(925,1000))]:
        p=cert[key];r=list(map(F,p['radii']));D=[[ratint(x) for x in row] for row in p['signed_derivative']];M=[[mag(x) for x in row] for row in D]
        test(M==[list(map(F,row)) for row in p['M']],'independent absolute matrix '+key)
        mr=[sum(M[i][j]*r[j] for j in range(2)) for i in range(2)]
        margin=[r[i]-e[i]-mr[i] for i in range(2)];q=max(mr[i]/r[i] for i in range(2))
        test(mr==list(map(F,p['Mr'])) and margin==list(map(F,p['inward_margins'])) and q==F(p['q']),'rational matrix inequalities '+key)
        test(all(x>0 for x in margin) and q<bound,'strict inward and contraction '+key)
        test(p['subdivisions']==[1,1] and len(p['subboxes'])==1,'no coverage gap '+key)
        for j in range(2):test(within((center[j]-r[j],center[j]+r[j]),ratint(p['subboxes'][0]['input'][j])),'full input coverage')
        for v in p['subboxes'][0]['domain_minima'].values():test(F(v)>0,'domain positive')
        details[key]={'q_exact':str(q),'q_display':float(q),'margins_exact':list(map(str,margin)),'radii':list(map(str,r)),'M_exact':[[str(v) for v in row] for row in M]}
    test(all(F(x)<=F(y) for x,y in zip(cert['primary']['radii'],cert['larger_region']['radii'])),'X subset B')
    test(F(81,256)<F(4,5)-F(1,100000),'inactive clip K')
    test(F(1,2)-F(81,2560)==F(1199,2560)>0,'K nonsingular')
    out['regions']=details
    # Independent root residual-to-coordinate bound and phase localization.
    M=[list(map(F,row)) for row in cert['primary']['M']]
    det=(1-M[0][0])*(1-M[1][1])-M[0][1]*M[1][0]
    test(det>0 and 1-M[0][0]>0 and 1-M[1][1]>0,'positive inverse of I-M')
    d=[((1-M[1][1])*e[0]+M[0][1]*e[1])/det, ((1-M[0][0])*e[1]+M[1][0]*e[0])/det]
    scal=load(b/'CERTIFICATE_SCALAR_CONSEQUENCES.json')
    test(d==list(map(F,scal['root_error_bound'])),'root error from inverse')
    for j in range(2):test(within((center[j]-d[j],center[j]+d[j]),ratint(scal['root_chart'][j])),'root coordinate enclosure')
    phase=alt_phase((center[1]-d[1],center[1]+d[1]))
    test(within(phase,ratint(scal['root_phase'])),'independent rigorous root phase')
    test(F('0.2420705842886754')<phase[0] and phase[1]<F('0.2420705842886798'),'printed root phase bounds')
    out['root_phase_independent_rational']=list(map(str,phase))
    out['root_phase_display']=[float(x) for x in phase]
    # Exact checkpoint identities and set inclusions.
    entries={x['case']:x for x in cert['entry']};test(len(entries)==5,'five entries')
    for x in index['optional_stored_checkpoint_initial_value_problems']:
        p=b/'inputs/ca03'/x['archive_member'];test(sha(p.read_bytes())==x['member_sha256'],'entry member')
        with np.load(p,allow_pickle=False) as ar:
            state=ar[x['state_array']][x['state_row']]
            test(sha(state.tobytes())==x['state_row_c_order_sha256'],'entry row')
            for val,desc in zip(state,x['components_xyz']):test(float(val).hex()==desc['float_hex'] and F(float(val))==F(desc['exact_dyadic']),'exact input dyadic')
            test(float(ar[x['phase_array']][x['phase_row']]).hex()==x['phase_float_hex'],'inherited phase lift')
        en=entries[x['case']];test(en['input_dyadics']==[z['exact_dyadic'] for z in x['components_xyz']],'certificate input identity')
        test(x['new_future_next_forcing_index']==0 and len(en['blocks'])==1 and en['destination']=='B','entry future')
        rad=list(map(F,cert['larger_region']['radii']))
        for j in range(2):test(within(ratint(en['blocks'][0][j]),(center[j]-rad[j],center[j]+rad[j])),'entry in B')
        test(ratint(en['blocks'][0][1])[1]-ratint(en['blocks'][0][1])[0]<F(2,10**45),'display entry width')
        test(ratint(en['first_step']['qnorm'])[1]+F(1,100000)<F(4,5),'off-K clip')
        test(F(en['first_step']['horizontal_segment_lower'])>0,'off-K axis')
    out['entry_count']=len(entries)
    # Independently grouped one-step checks, saved predecessors only.
    max_res=0.
    for x in index['passive_preflight_inputs']:
        with np.load(b/'inputs/ca03'/x['archive_member'],allow_pickle=False) as ar:
            j=x['transition_row'];s=ar['s'][j];dest=ar['dest'][j];t=float(ar['t'][j]);alpha=float(ar['alpha'][j])
            test(sha(s.tobytes())==x['s_sha256'] and sha(dest.tobytes())==x['dest_sha256'],'preflight saved bytes')
            test(t.hex()==x['time_float_hex'] and alpha.hex()==x['alpha_float_hex'] and x['forcing_index']==j%800,'preflight clock')
            X,Y,Z=s;A=np.array([Y*Y-X*Z,Z*Z-X*Y,X*X-Y*Z])
            H=2*np.exp(-t/2)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
            q=alpha*H*A;u=s+.1*q*min(1,.8/(np.linalg.norm(q)+1.e-5))
            rho=np.hypot(u[0],u[1]);L=np.linalg.norm(u)
            v=np.array([(1+u[2]/(2*L))*u[0]/rho,(1+u[2]/(2*L))*u[1]/rho,rho/(2*L)])
            rr=float(np.max(np.abs(v-dest)));max_res=max(rr,max_res)
            test(rr<=1.e-12,'independent saved successor')
    out['saved_successor_max_residual']=max_res
    # Independent algebraic verification of torque decomposition and derivatives.
    v,r,z=sp.symbols('v r z',real=True)
    C=(1-v*v)/(1+v*v);S=2*v/(1+v*v)
    x,y=r*C,r*S;A=sp.Matrix([y*y-x*z,z*z-x*y,x*x-y*z])
    formulas=[C*A[0]+S*A[1]-(z*z*S-r*z*C*C),C*A[1]-S*A[0]-(z*z*C-r*r*S+r*z*S*C),A[2]-(r*r*C*C-r*z*S),C*C+S*S-1]
    for f in formulas:test(sp.cancel(f)==0,'independent torque algebra')
    a0,w=sp.symbols('a w',real=True);hh=a0*(1+w*w)/(1-w*w);bb=2*a0*w/(1-w*w)
    test(sp.cancel((a0*S+bb*C)/(hh+a0*C-bb*S)-(v+w)/(1-v*w))==0,'exact chart addition')
    E=1-v*w;vn=(v+w)/E
    test(sp.cancel(sp.diff(vn,v)-(1+w*w)/E**2)==0,'angle derivative v')
    test(sp.cancel(sp.diff(vn,w)-(1+v*v)/E**2)==0,'angle derivative w')
    out['symbolic_checks']='torque radial/tangential/vertical, circle identity, half-angle equivalence, angular partials PASS'
    # Cross-check fresh fixed replay evidence with originally submitted evidence.
    fresh=load(a.replay_dir/'VERIFICATION.json');old=load(b/'VERIFICATION.json')
    for key in ['primary','larger_region','entry','status']:test(fresh[key]==old[key],'fixed replay reproduced '+key)
    baseledger=load(b/'EXECUTION_LEDGER.json');newledger=load(a.replay_dir/'EXECUTION_LEDGER.json')
    delta={k:newledger['counts'][k]-baseledger['counts'][k] for k in baseledger['counts']}
    test(delta=={'point':0,'construction':0,'replay':8000,'preflight':0},'review replay count')
    test(newledger['derivative_steps']['replay']-baseledger['derivative_steps']['replay']==3200,'review derivative count')
    test(len(newledger['sessions'])==len(baseledger['sessions'])+1 and newledger['sessions'][-1]['status']=='COMPLETE','one reviewer replay completed')
    out['activity']['submitted_fixed_replay_set_steps']=8000
    out['activity']['included_interval_derivative_steps']=3200
    out['activity']['submitted_fixed_replay_forcing_values']=800
    out['shared_core_disclosure']='Submitted verifier, AD and hand derivative share the reviewed interval core. Independent reviewer forcing engine and rational certificate checks do not. This is not proof-assistant certification.'
    test(all(sha((b/x['path']).read_bytes())==x['sha256'] for x in m['files']),'input bytes unchanged after review')
    out['checks']=checks;out['status']='PASS'
    (o/'CA04_INDEPENDENT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['status','checks','archive','consumed_originals','outside_status_records','saved_successor_max_residual','root_phase_display','activity']},indent=2))

if __name__=='__main__':main()
