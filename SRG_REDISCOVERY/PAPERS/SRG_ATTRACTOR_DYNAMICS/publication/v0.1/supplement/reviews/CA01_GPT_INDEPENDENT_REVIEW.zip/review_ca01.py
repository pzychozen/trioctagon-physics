"""Independent CA01 review: read saved records, not fresh evolution.
No historical module imports, no renderer/observer script execution, no rollout.
"""
from pathlib import Path
from collections import Counter
import argparse, hashlib, json, math, platform, zipfile
import numpy as np
import sympy as sp

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-dir',type=Path,default=Path('/mnt/data/ca01_review/input'),help='Directory containing extracted CA01 review payload.')
parser.add_argument('--archive',type=Path,default=Path('/mnt/data/CA01_GPT_REVIEW.zip'),help='Original delivered CA01 review ZIP.')
parser.add_argument('--attachments-dir',type=Path,default=None,help='Optional directory containing separate conversation inputs for byte comparisons.')
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent)
args=parser.parse_args()
B=args.input_dir.resolve()
OUT=args.output_dir.resolve()
if not (B/'MANIFEST.json').is_file() or not args.archive.is_file():
    parser.error('Provide an existing --input-dir and --archive.')
OUT.mkdir(parents=True,exist_ok=True)
checks={}
def ck(name, ok):
    checks[name]=bool(ok)
    if not ok: raise AssertionError(name)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readj(name):return json.loads((B/name).read_text(encoding='utf-8-sig'))
report={'review':'CA01 independent saved-evidence and mathematical review',
    'environment':{'python':platform.python_version(),'numpy':np.__version__,'sympy':sp.__version__},
    'new_rollout_updates':0, 'new_grid_field_evaluations':0,
    'historical_modules_executed':0,'native_kernel_updates':0}
zip_path=args.archive
report['input_zip']={'size':zip_path.stat().st_size,'sha256':sha(zip_path)}
with zipfile.ZipFile(zip_path) as z:
    ck('zip_crc',z.testzip() is None)
    names=z.namelist()
    ck('zip_no_duplicate_members',len(names)==len(set(names)))
manifest=readj('MANIFEST.json')['files']
ck('complete_manifest',set(names)=={r['path'] for r in manifest}|{'MANIFEST.json'})
for r in manifest:
    p=B/r['path']; ck('payload:'+r['path'],p.stat().st_size==r['size'] and sha(p)==r['sha256'])
report['manifested_payloads']=len(manifest)
reg=readj('evidence/consumed_sources.json')
for orig,r in reg.items():
    p=B/r['copy'];ck('source:'+r['copy'],p.stat().st_size==r['size'] and sha(p)==r['sha256'])
report['consumed_source_snapshots']=len(reg)
if args.attachments_dir is not None:
    ad=args.attachments_dir
    ck('standalone_readme_matches',(B/'READ_ME_FIRST.md').read_bytes()==(ad/'READ_ME_FIRST.md').read_bytes())
    for dest,original in [('received/inputs/SGR_simulations.pdf','SGR_simulations.pdf'),('received/SRG_CA01_CODEX_WORK_ORDER.md','SRG_CA01_CODEX_WORK_ORDER.md')]:
        ck('supplied_input:'+dest,(B/dest).read_bytes()==(ad/original).read_bytes())
else:
    report['separate_attachment_comparison']='Not requested; provide --attachments-dir to include it.'
pres=readj('PRESERVATION.json')
ck('all_preservation_records_consistent',len(pres['source_checks'])==len(reg) and all(r['sha256_before']==r['sha256_after'] and r['unchanged'] and r['copy_matches'] for r in pres['source_checks']))
for r in pres['source_checks']:
    ck('preservation_registry:'+r['path'],reg[r['path']]['sha256']==r['sha256_before'])
ck('status_records_byte_identical',(B/'evidence/starting_status.txt').read_bytes()==(B/'evidence/ending_status.txt').read_bytes())
ck('index_records_empty',(B/'evidence/starting_index.txt').read_bytes()==(B/'evidence/ending_index.txt').read_bytes()==b'')
report['preservation_scope']='Supplied records and snapshot bytes only; no direct Windows-filesystem or remote inspection.'
R=readj('RESULTS.json')
f3=[]
for row in R['F3']:
    with np.load(B/row['raw'],allow_pickle=False) as d:
        X,Y,M,mask,centroid=[d[k] for k in ['X','Y','magnitude','mask','centroid']]
        ck(row['id']+':shape',M.shape==X.shape==Y.shape==mask.shape==(row['n'],row['n']))
        ck(row['id']+':finite',all(np.isfinite(d[k]).all() for k in ['X','Y','U','V','magnitude','H','t','threshold']))
        threshold=float(np.percentile(M,5,method='linear'))
        ck(row['id']+':threshold',threshold==row['threshold']==float(d['threshold']))
        expectedmask=np.zeros(M.shape,dtype=bool)
        if row['kind']=='related_source_argmin':expectedmask.flat[np.argmin(M)]=True
        else:expectedmask=M<threshold
        ck(row['id']+':mask',np.array_equal(mask,expectedmask))
        ck(row['id']+':count',int(mask.sum())==row['selected_count'])
        if mask.any():
            mean=np.array([X[mask].mean(),Y[mask].mean()],dtype=float)
            ck(row['id']+':mean',np.array_equal(mean,centroid) and np.array_equal(mean,row['centroid']))
        else:
            ck(row['id']+':undefined',row['centroid'] is None and np.isnan(centroid).all())
        if row['kind']!='radial_formula':
            ck(row['id']+':stored_vector_magnitude',np.array_equal(M,np.sqrt(d['U']**2+d['V']**2)))
        else: ck(row['id']+':documented_unused_vectors',not d['U'].any() and not d['V'].any())
        mag0=abs(float(d['H']))/(1+X.astype(float)**2+Y.astype(float)**2)
        expected=(mag0*np.minimum(1,1/(mag0+1e-5)) if row['kind'] in ('related_source_argmin','epsilon_clip_centroid_control') else np.minimum(mag0,1))
        residual=float(np.max(abs(expected-M)))
        ck(row['id']+':algebraic_magnitude',residual<(2e-6 if M.dtype==np.float32 else 1e-12))
        mismatch=int(np.count_nonzero(mask!=mask[::-1,::-1]))
        ck(row['id']+':pair_mismatch',mismatch==row['inversion_mask_mismatch'])
        f3.append({'id':row['id'],'count':int(mask.sum()),'centroid':row['centroid'],'pair_mismatch':mismatch,'magnitude_residual':residual})
report['F3']={'saved_detector_records_checked':len(f3),'cases':f3}

def H(t):return 2*np.exp(-.5*t)*np.cos(t)+np.exp(-.3*t)*np.sin(t)+1.5*np.exp(-.7*t)+np.exp(-.4*t)
def P_closed(v):
    v=np.asarray(v,dtype=float)
    rho=np.hypot(v[...,0],v[...,1]); L=np.linalg.norm(v,axis=-1)
    ck('off_axis_saved_remap_inputs',bool(np.all(rho>0)))
    return np.stack(((1+.5*v[...,2]/L)*v[...,0]/rho,(1+.5*v[...,2]/L)*v[...,1]/rho,.5*rho/L),axis=-1)
residuals={'P':[],'Euler':[],'torque':[],'orthogonality':[]}
for row in R['F4_preflight']:
    s,u,q,qhat,dest=[np.array(row[k]) for k in ['s','u','q','qhat','dest']]
    x,y,z=s
    qi=row['alpha']*H(row['t'])*np.array([y*y-x*z,z*z-x*y,x*x-y*z])
    ck(f"preflight{row['id']}:H",abs(row['H']-H(row['t']))<1e-12)
    residuals['torque'].append(float(np.max(abs(qi-q))))
    ck(f"preflight{row['id']}:clip",np.max(abs(qhat-q*min(1,.8/(np.linalg.norm(q)+1e-5))))<1e-12)
    ck(f"preflight{row['id']}:increment",np.max(abs(u-s-.1*qhat))<1e-12)
    residuals['Euler'].append(abs(float(u@u-s@s-.01*(qhat@qhat))))
    residuals['orthogonality'].append(abs(float(s@qhat)))
    expected=P_closed(u) if np.hypot(u[0],u[1])>0 else np.array([.5 if u[2]<0 else 1.5,0,0])
    residuals['P'].append(float(np.max(abs(expected-dest))))
with np.load(B/'raw/F4_remap_only.npz',allow_pickle=False) as d:
    states=d['states'].copy()
    ck('F4_states_shape',states.shape==(201,3))
    ck('F4_predecessors',np.array_equal(states[:-1],d['s']))
    ck('F4_successors',np.array_equal(states[1:],d['dest']))
    ck('F4_increment_zero',not d['q'].any() and not d['qhat'].any() and not d['alpha'].any() and np.array_equal(d['u'],d['s']))
    ck('F4_clock',np.array_equal(d['t'],np.arange(200)*.1))
    ck('F4_indices',np.array_equal(d['state_index'],np.arange(201)))
    ck('F4_H_values',np.max(abs(d['H']-H(d['t'])))<1e-12)
    residuals['P'].append(float(np.max(abs(P_closed(d['u'])-d['dest']))))
    ck('F4_finite',all(np.isfinite(d[k]).all() for k in d.files))
rs=(3+math.sqrt(3))/4;zs=.5*math.sqrt(math.sqrt(3)/2)
rho=np.hypot(states[:,0],states[:,1]); distances=np.hypot(rho-rs,states[:,2]-zs)
for i,v in R['F4_control']['distance_to_circle_at_0_1_2_5_10_20_200'].items():
    ck('distance:'+i,abs(distances[int(i)]-v)<1e-14)
ck('F4_surface_after_first',np.max(abs((rho[1:]-1)**2+states[1:,2]**2-.25))<1e-12)
ck('F4_upper_half',np.all(states[1:,2]>=0))
ck('F4_residuals',max(max(a) for a in residuals.values())<1e-12)
report['F4']={'saved_preflight_records_checked':len(R['F4_preflight']),'saved_transitions_checked':200,'max_residuals':{k:max(v) for k,v in residuals.items()},'fixed_circle':{'rho':rs,'z':zs},'selected_distances':{str(i):float(distances[i]) for i in [0,1,2,5,10,20,200]}}

# Symbolic supporting identities, not numerical rollouts.
x,y,z,A,h,dt,k,c=sp.symbols('x y z A h dt k c', real=True)
s=sp.Matrix([x,y,z]); cyc=sp.Matrix([z,x,y]); q=A*h*k*s.cross(cyc)
ck('symbolic_orthogonality',sp.expand(s.dot(q))==0)
ck('symbolic_Euler',sp.expand((s+dt*q).dot(s+dt*q)-s.dot(s)-dt**2*q.dot(q))==0)
cs=(sp.sqrt(3)-1)/2
ck('symbolic_fixed_angle',sp.simplify(cs**2+cs-sp.Rational(1,2))==0)
ck('symbolic_fixed_height',sp.simplify(1-cs**2-sp.sqrt(3)/2)==0)
ck('symbolic_multiplier',sp.simplify(-(sp.Rational(1,4)+cs/2)/(sp.Rational(5,4)+cs)-(sp.sqrt(3)-2))==0)
ck('symbolic_contraction_bound',sp.simplify(sp.Rational(1,3)-(sp.Rational(1,4)+c/2)/(sp.Rational(5,4)+c)-2*(1-c)/(3*(4*c+5)))==0)
th=sp.symbols('theta',real=True)
X=1+sp.cos(th)/2;Z=sp.sin(th)/2
ck('symbolic_g_derivative',sp.trigsimp((Z*sp.diff(X,th)-X*sp.diff(Z,th))/(X**2+Z**2)+(sp.Rational(1,4)+sp.cos(th)/2)/(sp.Rational(5,4)+sp.cos(th)))==0)
ck('symbolic_cross_components',s.cross(cyc)==sp.Matrix([y*y-x*z,z*z-x*y,x*x-y*z]))
ck('symbolic_cone_clearance',sp.Rational(1,2)*sp.Rational(42,100)/sp.Rational(158,100)>sp.Rational(8,100))
report['proof_review']={'remap_contraction':'Verified by written derivation and symbolic supporting identities.', 'driven_forward_convergence':'Verified from bounded clipping, eventual contraction, summable forcing and lifted azimuth increments.', 'limiting_endpoint_surjectivity':'Verified from uniform convergence of degree-one azimuth lifts on each initial latitude circle.', 'no_nonzero_triangle_cycle':'Follows under the stated unreset advancing clock, fixed finite alpha and admissible first remap.', 'proof_assistant_used':False}

# Geometry reference reconstructed from copied definitions without importing source code.
with np.load(B/'evidence/geometry_reference.npz',allow_pickle=False) as d:
    G={k:d[k].copy() for k in d.files}
O=np.array([0,math.sqrt(3)/6,0]); a=(1-math.sqrt(2)/2)/2; hh=(math.sqrt(2)-1)/2
angles=-math.pi/2+np.arange(6)*math.pi/3
ring=np.column_stack((a*np.cos(angles),a*np.sin(angles)))
verts=np.vstack((np.column_stack((ring,np.full(6,hh))),np.column_stack((ring,np.full(6,-hh))),np.column_stack((math.sqrt(3)/6*np.cos(angles[::2]),math.sqrt(3)/6*np.sin(angles[::2]),np.full(3,.5))),np.column_stack((math.sqrt(3)/6*np.cos(angles[::2]),math.sqrt(3)/6*np.sin(angles[::2]),np.full(3,-.5)))))
faces=[]
for i in range(6):faces.extend([[i,(i+1)%6,6+(i+2)%6],[i,6+(i+2)%6,6+(i+1)%6]])
for off,ap in ((0,12),(6,15)):
    for j in range(3):faces.extend([[off+(2*j-1)%6,off+2*j,ap+j],[off+2*j,off+(2*j+1)%6,ap+j]])
ck('geometry_PLUS',np.max(abs(G['plus']-(verts+O)))<1e-12)
ck('geometry_MINUS',np.max(abs(G['minus']-(verts*np.array([-1,1,1])+O)))<1e-12)
ck('geometry_faces',np.array_equal(G['faces'],faces))
edges=Counter(tuple(sorted((f[j],f[(j+1)%3]))) for f in faces for j in range(3))
bound={e for e,n in edges.items() if n==1}
ck('geometry_incidence',len(edges)==42 and len(bound)==12 and max(edges.values())==2)
ck('geometry_open_boundaries',bound=={tuple(sorted(e)) for e in G['boundary_edges']})
adj={}
for i,j in bound:adj.setdefault(i,set()).add(j);adj.setdefault(j,set()).add(i)
components=[]; unseen=set(adj)
while unseen:
    todo=[next(iter(unseen))];comp=set()
    while todo:
        u=todo.pop()
        if u not in comp:comp.add(u);todo.extend(adj[u]-comp)
    unseen-=comp;components.append(len(comp))
ck('two_six_edge_boundary_cycles',sorted(components)==[6,6] and all(len(v)==2 for v in adj.values()))
cand=json.loads(next((B/'sources').glob('*CANONICAL_CRYSTAL_CANDIDATE.json')).read_text())
ck('faces_match_prior_candidate',faces==cand['variants'][0]['faces'])
host=json.loads(next((B/'sources').glob('*HOST_GEOMETRY.json')).read_text())
ck('host_vertices',np.max(abs(G['host_vertices']-np.array([[float(sp.sympify(v)) for v in row] for row in host['welded_vertices']])))<1e-12)
ck('host_faces',np.array_equal(G['host_faces'],host['welded_faces']))
for r in host['sources']:
    candidates=[rr for path,rr in reg.items() if path.replace('\\','/').endswith(r['path'].replace('\\','/'))]
    ck('host_hash:'+r['path'],len(candidates)==1 and candidates[0]['sha256']==r['sha256'])
# Passive frame checks on unchanged saved arrays.
pair=lambda arr:np.linalg.norm(arr[:,None,:]-arr[None,:,:],axis=-1)
angle=math.pi/6;Q=np.array([[math.cos(angle),-math.sin(angle),0],[math.sin(angle),math.cos(angle),0],[0,0,1]])
trans_res=float(np.max(abs(pair(states+O)-pair(states))))
rot_res=float(np.max(abs(pair(states@Q.T+[.2,-.3,.4])-pair(states))))
ck('passive_rigid_distances',max(trans_res,rot_res)<1e-12)
inside=(np.abs(states[:,:2])<=.3).all(axis=1)&(np.abs(states[:,2])<=.5)
ck('reported_outside_window',int((~inside).sum())==201)
report['geometry']={'vertices':18,'faces':24,'edges':42,'open_boundary_components':components,'passive_translation_residual':trans_res,'passive_rigid_residual':rot_res,'outside_display_window':201,'not_a_containment_test':True}
ck('input_preserved_during_review',all((B/r['path']).stat().st_size==r['size'] and sha(B/r['path'])==r['sha256'] for r in manifest))
report['checks']=checks
report['total_boolean_checks']=len(checks)
report['status']='PASS_INDEPENDENT_SAVED_EVIDENCE_AND_MATHEMATICAL_REVIEW'
(OUT/'CA01_INDEPENDENT_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','F3')},indent=2))
