# Codex work order — Volume III editorial R1 only

**Date:** 25 October 2026  
**Assignment:** `SRG_VOLUME_III_SIM06_SIM07_EDITORIAL_R1`  
**Author / research director:** Hilmir Frímann Halldórsson  
**Scientific lead / reviewer:** GPT  
**Preparation:** Codex  
**Output:** Candidate v0.1.1 for GPT/Hilmir review. Not final acceptance or publication approval.

## FIRST OPERATION: Windows CMD only

Use **Windows Command Prompt from the first shell command**, including reads of this order, attachments and archive metadata. Do not use PowerShell to bootstrap the task or discover the CMD requirement. The previous initial-read deviation is disclosed; do not repeat it or rewrite its record. Use the existing `torment` environment for authorized Python document operations.

## 1. Decision and scope

GPT has reviewed the 33-page candidate. Its scientific core, principal mathematical explanations, numerical findings, 11 figures, original/reproduced distinctions and comparison scope are accepted. Two local corrections remain before final manuscript acceptance:

- **E01:** correctly specify Universe whole-field versus Tower II per-band GRF averaging.
- **E02:** correct the cited SIM07 Universe construction GPT review date to 25 October 2026.

This order authorizes only those corrections, the corresponding claim-matrix edit, narrow version/status housekeeping, a document rebuild, page inspection and packaging. No new investigation is needed. Field merger stays deferred. Do not ask Hilmir to choose text or re-supply previously supplied sources.

## 2. Authoritative inputs and workspace

Repository:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`

Accepted baseline candidate:

`SRG_REDISCOVERY\PAPERS\SRG_BAND_AND_LOCAL_FUSION_SIM06_SIM07\draft\v0.1\`

Delivered v0.1 ZIP: `SRG_VOLUME_III_SIM06_SIM07_v0.1_CANDIDATE_REVIEW.zip`, 64,511,968 bytes, SHA-256 `3d23ed7375b069913f7ac562c855d181ccd5f36c90147f1c090545e3540a95cd`.

Create a separate new directory:

`SRG_REDISCOVERY\PAPERS\SRG_BAND_AND_LOCAL_FUSION_SIM06_SIM07\draft\v0.1.1\`

If it already contains work, inspect and choose a clearly identified new non-overwriting R1 directory. Never overwrite v0.1 or an accepted edition. Baseline the current v0.1 workspace and actual accepted inputs used; do not invent a new whole-repository survey. Check candidate identity against the delivered ZIP and GPT review receipt before editing.

This packet includes the full GPT review, source excerpts, exact proposed patch, document audit and target hashes. The candidate and its complete accepted archives already exist in the original delivery; they are not duplicated here. A missing candidate input is a stop/report issue, not permission to regenerate scientific evidence.

## 3. E01: observer scope

Physical PDF page 28, Section 10.1, Equation (32), `closing_sections.tex` currently gives an all-N mean after “Both sources' GRF observer is”.

Preserve the per-point expression `1/(1+||V_i||)`, but make the reporting set explicit:

`GRF_bar_G = (1/|G|) sum_{i in G} 1/(1+||V_i||)`, for nonempty G.

Universe uses all N point IDs. Tower II uses one nonempty band G_b at a time. Its global metrics dictionary does not contain a whole-field GRF. Source anchors: T:222–237 and 244–250; U:243–255. Retain the mean-of-reciprocals qualification, and keep the existing `eq:grf` label and single equation environment. Do not replace historical band outputs with global averages or compute new statistics.

Update claim C34 with those distinct sets. `PROPOSED_E01_E02.patch` gives reviewed wording and precise changes. It changes no recurrence, actual value, figure or scientific argument. Equivalent prose is unnecessary; use the supplied wording unless a document-build issue requires a strictly presentational adjustment, which must be recorded.

## 4. E02: cited date

In `references.bib`, entry `s7creview` only, change its note from `24 October.` to `25 October.` This corrects reference [11] in the current PDF.

The cited Markdown and JSON acceptance both say 2026-10-25. The earlier construction package's creation date is not the date of the later GPT acceptance. Do not edit archived receipts, other reference dates, source-header dates or original notes. No global replacement.

## 5. What must stay unchanged

- Every original program, historical file, accepted report, scientific result table, input archive and the 11 figure images.
- Tower II and Universe recurrence equations, stage order, guards, indexing and sign conventions.
- Spatial variance, ordered-read and pooled-variance explanations, including the scoped clipping discussion.
- All quantitative result passages and retained verification numbers.
- All source blocks except the single GRF observer block in `closing_sections.tex`, the one bibliography note, C34, and explicitly allowed status housekeeping.
- `universe_sections.tex` in its entirety.
- Prior v0.1 material and all sealed study packages; published Volumes I/II; kernel, memory/UI, canonical ledger and unrelated work.

No refactoring, equation renumbering by adding environments, stylistic rewrite, new proof, new physics interpretation, source cleanup or figure regeneration. Existing text may reflow after the longer observer paragraph; that is not permission to change content.

## 6. Permitted housekeeping

In `manuscript.tex`, change only the PDF subject, running header and cover status/date to identify candidate v0.1.1 / editorial R1, using the actual revision date. Keep title, author/contributor attributions and provisional/not-publication-approved status. Do not mark the new manuscript accepted before GPT review.

Update the new edition's START_HERE, correction disposition, editorial/document notes, build/QA records, exact source diff, evidence index only where needed to point to this review, preservation receipt and manifest. If layout reflow changes figure page numbers, update only those navigation fields in the new figure register; image bytes and underlying metadata remain unchanged. Keep original imported handoff/status records as historical evidence.

Do not rerun old package-preparation helpers blindly: read them first; use only clearly bounded document operations. Keep builds and renders inside the new revision workspace. Do not install/alter scientific dependencies for this task.

## 7. Zero-run boundary

**New simulation updates: ZERO. Initializations: ZERO. RNG draws/restorations: ZERO. Scientific checker reruns: ZERO.** No imports of historical simulators, replay drivers, numerical validators, graph/clustering/geometry calculations, FFTs, new figures, parameter changes, merger work or new archive search. Previous replay budgets are closed.

Allowed: reading, text/byte comparison, hashes, unchanged copies, document compilation/rendering, citation/link/layout checks and delivery packaging. No Git commands, staging, commits, push, tags, releases, publication preparation or integration.

The R1 build may compile TeX/BibTeX as document work. It must not execute retained scientific scripts or regenerate their data. Do not rebuild a scientific source because a historical path is inconvenient.

## 8. Verification before delivery

1. Check E01 against both source observer implementations and E02 against the dated S7C review/receipt, by reading only.
2. Compare all actual edited files with v0.1. Provide the complete source diff, including C34 and status changes. Explain any document-only change beyond the proposed patch.
3. Confirm byte identity of all three accepted archives, all copied evidence and 11 figure files. Confirm all other mathematical blocks unchanged; Equation (32) alone is intentionally corrected. `universe_sections.tex` must be byte-identical.
4. Compile and visually inspect every actual final PDF page, including rotated figures and reflow around Section 10 and the bibliography. Do not force a page count if content naturally reflows. No clipping, dropped references, missing glyphs or equation collisions.
5. Verify labels, bibliography keys, current authored links, file/figure registers and exact ZIP payload against a scoped manifest. Do not flatten accepted archive paths.
6. Recheck the actual preservation baseline, state its limits accurately and disclose any deviation. Byte checks alone are not proof of non-execution.

## 9. Deliverables and stop

Return a new `SRG_VOLUME_III_SIM06_SIM07_v0.1.1_EDITORIAL_R1_REVIEW.zip`, a separately accessible PDF and external `REVIEW_ZIP_IDENTITY.json`. Include:

- PDF and editable source/bibliography, unchanged figures/evidence and complete accepted archives;
- `CORRECTION_DISPOSITION.md`, exact source diff from v0.1, and any separate document-only diff;
- updated START_HERE, evidence/claim records, page QA, document/build records and used-input preservation receipt;
- the GPT review/authority packet retained unchanged in a clearly labeled editorial-evidence subdirectory;
- a manifest excluding itself and an external ZIP receipt, avoiding circular hashes.

Keep font files, compiler caches, temporary renders and unrelated work out of the delivery. Existing inherited compiler records may be kept as provenance; never present old ones as the new build result.

**STOP after returning the corrected candidate for GPT/Hilmir review.** No next engine, field-merger investigation, manuscript expansion or publication action follows automatically.
