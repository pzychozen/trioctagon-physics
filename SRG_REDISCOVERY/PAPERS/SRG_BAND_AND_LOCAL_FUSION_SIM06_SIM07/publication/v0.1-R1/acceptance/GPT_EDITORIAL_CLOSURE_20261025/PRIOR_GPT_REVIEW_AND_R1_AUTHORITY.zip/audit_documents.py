"""Document and archive checks only. Does not import or run scientific sources."""
from pathlib import Path
import hashlib, json, re, zipfile, io
from urllib.parse import unquote, urlsplit
import fitz
ROOT=Path('/mnt/data/SRG_VOLUME_III_GPT_REVIEW_v0.1')
S=ROOT/'candidate'; O=ROOT/'audit'; O.mkdir(exist_ok=True)
def h(b): return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes(); return dict(bytes=len(b),sha256=h(b))
def readj(p): return json.loads(p.read_text(encoding='utf-8'))
res={'scope':'Document audit only; no simulation, RNG, scientific checker, clustering or geometry calculation.', 'candidate_archive':ident(Path('/mnt/data/SRG_VOLUME_III_SIM06_SIM07_v0.1_CANDIDATE_REVIEW.zip'))}
zp=Path('/mnt/data/SRG_VOLUME_III_SIM06_SIM07_v0.1_CANDIDATE_REVIEW.zip')
with zipfile.ZipFile(zp) as z:
 names=z.namelist(); man=readj(S/'MANIFEST.json'); rows=man['files']; errors=[]
 for r in rows:
  b=z.read(r['path'])
  if len(b)!=r['bytes'] or h(b)!=r['sha256']: errors.append(r['path'])
  if (S/r['path']).read_bytes()!=b: errors.append('extracted:'+r['path'])
 res['manifest']={'zip_members':len(names),'payloads':len(rows),'crc_pass':z.testzip() is None,'duplicates':len(names)-len(set(names)),'missing':sorted(set(r['path'] for r in rows)-set(names)),'extra':sorted(set(names)-set(r['path'] for r in rows)-{'MANIFEST.json'}),'errors':errors,'uncompressed_payload_bytes':sum(r['bytes'] for r in rows)}
parents={}; parent_equality=[]
for p in (S/'handoff/inputs').glob('*.zip'):
 orig=Path('/mnt/data')/p.name
 parent_equality.append({'path':p.name,**ident(p),'earlier_attachment_present':orig.exists(),'earlier_bytes_match':orig.exists() and p.read_bytes()==orig.read_bytes()})
 parents[p.name]=zipfile.ZipFile(p)
res['immutable_archives']=parent_equality
copies=readj(S/'EVIDENCE_COPY_MANIFEST.json')['copies']; copy_results=[]
for r in copies:
 b=(S/r['path']).read_bytes(); pb=parents[Path(r['parent_archive']).name].read(r['member'])
 copy_results.append({'path':r['path'],'parent':r['parent_archive'],'member':r['member'],'same_bytes':b==pb,'manifest_identity_match':h(b)==r['sha256'] and len(b)==r['bytes']})
res['evidence_copies']={'count':len(copies),'errors':[r for r in copy_results if not(r['same_bytes'] and r['manifest_identity_match'])]}
(O/'EVIDENCE_BYTE_COMPARISONS.json').write_text(json.dumps(copy_results,indent=2))
handoff=zipfile.ZipFile('/mnt/data/SRG_SIM06_SIM07_MANUSCRIPT_CODEX_HANDOFF_20261025.zip')
handoff_rows=[]
for p in (S/'handoff').rglob('*'):
 if p.is_file():
  n=p.relative_to(S/'handoff').as_posix()
  handoff_rows.append({'path':n,'same_bytes':p.read_bytes()==handoff.read(n)})
res['handoff']={'count':len(handoff_rows),'errors':[r for r in handoff_rows if not r['same_bytes']],'archive_identity':ident(Path('/mnt/data/SRG_SIM06_SIM07_MANUSCRIPT_CODEX_HANDOFF_20261025.zip'))}
figs=readj(S/'FIGURE_REGISTER.json')['figures']; fig_rows=[]
for r in figs:
 b=(S/r['file']).read_bytes(); pb=parents[Path(r['parent_archive']).name].read(r['member'])
 fig_rows.append({'figure':r['figure'],'path':r['file'],'physical_pdf_page':r['physical_pdf_page'],'same_bytes':b==pb,'identity_match':len(b)==r['bytes'] and h(b)==r['sha256']})
res['figures']={'count':len(fig_rows),'results':fig_rows}
texts={n:(S/n).read_text() for n in ['manuscript.tex','universe_sections.tex','closing_sections.tex']}; full='\n'.join(texts.values())
labels=re.findall(r'^\\newlabel\{([^}]+)\}', (S/'qa/manuscript.aux').read_text(), re.M)
# The compiled label table resolves labels supplied as figure-macro arguments; do not count the macro parameter #3.
refs=re.findall(r'\\(?:eqref|ref|pageref|autoref)\{([^}]+)\}',full)
cites=[c.strip() for s in re.findall(r'\\cite\w*\{([^}]+)\}',full) for c in s.split(',')]
bib=(S/'references.bib').read_text(); keys=re.findall(r'@\w+\{([^,\s]+)',bib)
res['tex']={'source_lines':{n:len(v.splitlines()) for n,v in texts.items()},'labels':len(labels),'reference_occurrences':len(refs),'unresolved':sorted(set(refs)-set(labels)),'duplicate_labels':sorted({x for x in labels if labels.count(x)>1}),'citations':len(cites),'used_bibliography_keys':len(set(cites)),'bibliography_entries':len(keys),'unresolved_bib':sorted(set(cites)-set(keys)),'equation_align_environments':len(re.findall(r'\\begin\{(?:equation\*?|align\*?)\}',full))}
# Relative links in newly authored root markdown; inherited reports keep original package contexts.
link_results=[]
for p in S.glob('*.md'):
 for m in re.finditer(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  uri=m.group(1).strip().strip('<>'); parts=urlsplit(uri)
  if parts.scheme or uri.startswith('#'): continue
  target=unquote(parts.path)
  q=(p.parent/target).resolve()
  link_results.append({'document':p.name,'target':uri,'exists':q.exists()})
res['authored_markdown_links']={'count':len(link_results),'missing':[r for r in link_results if not r['exists']]}
(O/'ROOT_LINK_CHECKS.json').write_text(json.dumps(link_results,indent=2))
d=fitz.open(S/'manuscript.pdf'); alltext='\n'.join(p.get_text() for p in d); dests=d.resolve_names(); link_rows=[]
for i,p in enumerate(d):
 for l in p.get_links():
  r={'physical_page':i+1,'kind':l['kind']}
  if l['kind']==fitz.LINK_GOTO:
   r['target_page']=l.get('page');r['valid']=0<=l.get('page',-1)<len(d)
  elif l['kind']==fitz.LINK_NAMED:
   target=l.get('nameddest') or l.get('name'); r['target']=target; r['valid']=target in dests
  elif l['kind']==fitz.LINK_URI:
   u=l.get('uri','');r['uri']=u;r['valid']=True
   if u.startswith('file:'): r['valid']=(S/unquote(urlsplit(u).path)).exists()
  elif l['kind'] in (fitz.LINK_LAUNCH,fitz.LINK_GOTOR):
   r['target']=l.get('file');r['valid']=(S/unquote(l.get('file',''))).exists()
  else:r['detail']=str(l);r['valid']=True
  link_rows.append(r)
fonts={f[0]:f for p in d for f in p.get_fonts(full=True)}
fontrows=[]
for xref,f in fonts.items():
 try: info=d.extract_font(xref); fontrows.append({'name':info[0],'type':info[2],'embedded':bool(info[3]),'xref':xref})
 except Exception as e:fontrows.append({'xref':xref,'error':str(e)})
res['pdf']={**ident(S/'manuscript.pdf'),'pages':len(d),'metadata':d.metadata,'rotated_pages':[i+1 for i,p in enumerate(d) if p.rotation],'named_destinations':len(dests),'link_annotations':len(link_rows),'bad_links':[r for r in link_rows if not r['valid']],'replacement_chars':alltext.count('\ufffd'),'unresolved_question_pairs':alltext.count('??'),'fonts':fontrows}
(O/'PDF_LINK_CHECKS.json').write_text(json.dumps(link_rows,indent=2))
(O/'PDF_PAGE_TEXT.txt').write_text('\n'.join(f'\n--- PHYSICAL PAGE {i+1} / PRINTED {i if i else "cover"} ---\n'+p.get_text() for i,p in enumerate(d)))
log=(S/'qa/manuscript.log').read_text(errors='replace')
res['compiler']={'critical_lines':[l for l in log.splitlines() if re.search(r'(undefined|Missing character|LaTeX Error|^!)',l,re.I)],'spacing_lines':[l for l in log.splitlines() if 'Overfull' in l or 'Underfull' in l]}
res['identity']={n:ident(S/n) for n in ['manuscript.pdf','manuscript.tex','universe_sections.tex','closing_sections.tex','references.bib']}
res['start_here_separate_matches']= (S/'START_HERE.md').read_bytes()==Path('/mnt/data/START_HERE(20261025-153113).md').read_bytes()
res['current_claim_rows']=len(re.findall(r'^\| C\d+', (S/'CLAIM_EVIDENCE_MATRIX.md').read_text(),re.M))
(O/'DOCUMENT_AUDIT.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in res.items() if k not in ['figures','pdf','identity']},indent=2,ensure_ascii=False)); print('PDF',res['pdf']);print('figures',res['figures']);print('identity',res['identity'])
