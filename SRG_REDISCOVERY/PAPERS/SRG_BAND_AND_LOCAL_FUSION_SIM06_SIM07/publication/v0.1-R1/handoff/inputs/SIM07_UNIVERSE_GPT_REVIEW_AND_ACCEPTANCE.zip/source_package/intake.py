"""Static ZIP/source intake only. No historical module execution or RNG use."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
HANDOFF=Path(r'C:\Users\Notandi\Downloads\SRG_SIM07_UNIVERSE_CONSTRUCTION_HANDOFF_20261024.zip')
def identity(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with zipfile.ZipFile(HANDOFF) as z:
    for name in ['HANDOFF_MANIFEST.json','INPUT_PROVENANCE.json','TARGET_SOURCE_INDEX.json','CURRENT_CHECKPOINT.md']:
        print('\nFILE',name);print(z.read(name).decode('utf-8-sig'))
    records=[]
    for name in z.namelist():
        if name.endswith('/') or name.startswith('inputs/'):continue
        p=ROOT/'handoff'/name
        assert p.resolve().is_relative_to(ROOT) and not p.exists(),p
        p.parent.mkdir(parents=True,exist_ok=True);raw=z.read(name);p.write_bytes(raw)
        records.append({'container':str(HANDOFF),'member':name,'copy':p.relative_to(ROOT).as_posix(),**identity(raw)})
    (ROOT/'HANDOFF_INTAKE.json').write_text(json.dumps({'archive':str(HANDOFF),**identity(HANDOFF.read_bytes()),'members':records},indent=2)+'\n')
    print('\nFILE context/SIM06_GPT_SCIENTIFIC_REVIEW.md');print(z.read('context/SIM06_GPT_SCIENTIFIC_REVIEW.md').decode('utf-8-sig'))
