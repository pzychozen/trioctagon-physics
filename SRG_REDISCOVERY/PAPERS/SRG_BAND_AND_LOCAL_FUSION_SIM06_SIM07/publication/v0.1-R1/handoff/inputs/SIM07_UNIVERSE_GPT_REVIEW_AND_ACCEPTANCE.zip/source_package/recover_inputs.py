"""Verify and copy only named SIM07 sources and directly relevant retained context."""
from pathlib import Path
import hashlib,json,zipfile,io
ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\TORMENT\TRIOCTAGON_new\trioctagon-physics')
R0=REPO/'SRG_REDISCOVERY/R0_SOURCE_RECOVERY'
def ident(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
intake=json.loads((ROOT/'HANDOFF_INTAKE.json').read_text())
archive=Path(intake['archive']);rows=[{'original':str(archive),'copy':None,**ident(archive.read_bytes())}]
with zipfile.ZipFile(archive) as z:
    man=json.loads(z.read('HANDOFF_MANIFEST.json'))
    for row in man['files']:
        assert ident(z.read(row['path']))=={k:row[k] for k in ['bytes','sha256']},row['path']
    with zipfile.ZipFile(io.BytesIO(z.read('inputs/SIM06_TOWER_II_GPT_REVIEW_AND_ACCEPTANCE.zip'))) as z6:
        member='source_package/CONSTRUCTION.md';raw=z6.read(member)
        p=ROOT/'context/SIM06_CONSTRUCTION.md';p.parent.mkdir(exist_ok=True);assert not p.exists();p.write_bytes(raw)
        intake['members'].append({'container':str(archive),'nested_archive':'inputs/SIM06_TOWER_II_GPT_REVIEW_AND_ACCEPTANCE.zip','member':member,'copy':'context/SIM06_CONSTRUCTION.md',**ident(raw)})
index=json.loads((ROOT/'handoff/TARGET_SOURCE_INDEX.json').read_text())
for row in index['entries']:
    p=Path(row['preferred_recovered_windows_path']);raw=p.read_bytes()
    assert ident(raw)=={'bytes':row['expected_bytes'],'sha256':row['expected_sha256']},p
    dst=ROOT/'original'/p.name;dst.parent.mkdir(exist_ok=True);assert not dst.exists();dst.write_bytes(raw)
    rows.append({'original':str(p),'copy':dst.relative_to(ROOT).as_posix(),**ident(raw)})
    print('MATCH',p.name,len(raw))
for name in ['csv_evidence_summary.json','saved_data_checks.json']:
    p=R0/name
    print('NAMED INDEX',str(p),'exists',p.is_file())
    if p.is_file():
        raw=p.read_bytes();dst=ROOT/'context'/name;assert not dst.exists();dst.write_bytes(raw)
        rows.append({'original':str(p),'copy':dst.relative_to(ROOT).as_posix(),**ident(raw)})
(ROOT/'INPUT_BASELINE.json').write_text(json.dumps({'files':rows,'archive_members':intake['members']},indent=2)+'\n')
(ROOT/'INTAKE_VERIFICATION.json').write_text(json.dumps({'handoff_manifest_entries_verified':len(man['files']),
    'selected_originals_verified':7,'expected_source_identity_matched':True,
    'former_source_locator_exists':Path(index['entries'][0]['historical_archive_locator_from_R0']).exists(),
    'new_state_updates':0,'rng_draws':0,'historical_imports':0},indent=2)+'\n')
print('SOURCE LINES',len((ROOT/'original/srg_condensate_breaking.py').read_text(encoding='utf-8').splitlines()))
