"""Document, static-source, preservation and ZIP checks only. No historical execution."""
from pathlib import Path
import ast,hashlib,io,json,platform,re,struct,zipfile
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
ZIPNAME='SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01_REVIEW.zip'
stamp=datetime.now(timezone.utc).isoformat()
def ident(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def fileid(p):return ident(p.read_bytes())
def write(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
baseline=json.loads((ROOT/'INPUT_BASELINE.json').read_text())
external=[];members=[]
for row in baseline['files']:
    expected={k:row[k] for k in ['bytes','sha256']}
    assert fileid(Path(row['original']))==expected,row['original']
    if row['copy']:assert fileid(ROOT/row['copy'])==expected,row['copy']
    external.append({**row,'original_unchanged':True,'copy_identical':True if row['copy'] else None})
for row in baseline['archive_members']:
    with zipfile.ZipFile(row['container']) as z:
        if row.get('nested_archive'):
            with zipfile.ZipFile(io.BytesIO(z.read(row['nested_archive']))) as nested:raw=nested.read(row['member'])
        else:raw=z.read(row['member'])
    expected={k:row[k] for k in ['bytes','sha256']}
    assert ident(raw)==fileid(ROOT/row['copy'])==expected,row['copy']
    members.append({**row,'container_member_unchanged':True,'copy_identical':True})
assert len(external)==10 and len(members)==12
write('PRESERVATION_RECEIPT.json',{'recorded_utc':stamp,'scope':'Actual used inputs only; no repository-wide audit',
    'external_file_count':len(external),'copied_archive_member_count':len(members),
    'all_preserved':True,'external_files':external,'archive_members':members,
    'execution_attestation':'See ACTION_RECORD.md; hashes alone do not establish non-execution.',
    'new_state_updates':0,'rng_draws':0,'historical_imports':0,'scientific_checker_reruns':0,'git_writes':0})

source=(ROOT/'original/srg_condensate_breaking.py').read_text(encoding='utf-8')
assert len(source.splitlines())==778
tree=ast.parse(source)
definitions=[]
for node in ast.walk(tree):
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
        definitions.append({'name':node.name,'first_line':node.lineno,'last_line':node.end_lineno})
write('SOURCE_MAP.json',{'method':'Static AST parse only; no compile/eval/import of historical code',
    'source':'original/srg_condensate_breaking.py','identity':fileid(ROOT/'original/srg_condensate_breaking.py'),
    'line_count':778,'definitions':sorted(definitions,key=lambda x:x['first_line'])})
script_checks=[]
for p in sorted(ROOT.glob('*.py')):
    t=ast.parse(p.read_text(encoding='utf-8'),filename=p.name)
    prohibited=[]
    for n in ast.walk(t):
        if isinstance(n,ast.Call):
            f=n.func.attr if isinstance(n.func,ast.Attribute) else n.func.id if isinstance(n.func,ast.Name) else ''
            if f in {'evolve_pass','evolve','GlyphFieldUniverse','normal','uniform','shuffle','choice','seed','set_state','eval','exec','run_module','run_path'}:prohibited.append(f)
        if isinstance(n,(ast.Import,ast.ImportFrom)):
            modules=[a.name for a in n.names] if isinstance(n,ast.Import) else [n.module or '']
            assert not any('srg_condensate' in m or 'golden_core' in m for m in modules),(p.name,modules)
    assert not prohibited,(p.name,prohibited)
    script_checks.append(p.name)

visual=[]
for name,expected,notes in [
 ('F01_original_universe_chronology.png',[1560,1320],'All six panels visually inspected at original size: readable legends and axes; fixed pass range; six input populations distinguished from spatial and amplitude observers; L is an imposed schedule, not geometric data.'),
 ('F02_horizon_settings.png',[1560,672],'Both panels visually inspected at original size: trial markers separated; None categorical and branch change marked; no sweep-time curve; valid inter-center distance plotted rather than flattened intra spread.')]:
    p=ROOT/'figures'/name;raw=p.read_bytes();size=list(struct.unpack('>II',raw[16:24]));assert size==expected
    visual.append({'file':'figures/'+name,**ident(raw),'pixels':size,'method':'Codex view_image detail=original on final saved PNG','status':'inspected','notes':notes})
write('VISUAL_INSPECTION.json',{'recorded_utc':stamp,'figures':visual,'new_coordinate_renderings':0})

docs=['START_HERE.md','CONSTRUCTION.md','ORIGINAL_EVIDENCE.md','MOTION_AND_GEOMETRY.md','MODEL_RELATIONSHIPS.md','RECORD_SELECTION_AND_VERIFICATION.md','REPLAY_DECISION_NOTE.md','CONTEXT_INDEX.md','ACTION_RECORD.md']
links=[];table_checks=[]
for name in docs:
    p=ROOT/name;assert p.is_file() and p.stat().st_size>500
    text=p.read_text(encoding='utf-8');assert '\ufffd' not in text,name
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if target.startswith(('http://','https://','#')):continue
        target=target.split('#')[0]
        assert (ROOT/target).is_file() or target in {'MANIFEST.json','DOCUMENT_QA.json'},(name,target)
        links.append({'document':name,'target':target})
    expected=None
    for lineno,line in enumerate(text.splitlines(),1):
        if line.startswith('|'):
            count=len(re.findall(r'(?<!\\)\|',line))
            if expected is None:expected=count
            assert count==expected,(name,lineno,count,expected)
        else:expected=None
    table_checks.append(name)
write('DOCUMENT_QA.json',{'recorded_utc':stamp,'required_six_reports_present':True,'new_documents':docs,
    'package_relative_links':links,'table_column_checks':table_checks,'new_scripts_static_checks':script_checks,
    'script_check_limit':'Named forbidden update/RNG calls and historical imports checked statically in new utilities only; not proof about all possible dynamic behavior. Operational attestation is separate.',
    'source_AST_parse_only':True,'source_read_coverage':'Complete original lines 1–778, including all drivers; companion narrative lines 1–170',
    'figures_visually_inspected':2,'originals_verified':7,'external_files_preserved':10,'archive_copies_preserved':12,
    'runtime':{'python':platform.python_version(),'matplotlib':json.loads((ROOT/'FIGURE_REGISTER.json').read_text())['matplotlib_version']},
    'no_simulation_or_spectral_verification':True})

excluded={ZIPNAME,'MANIFEST.json','REVIEW_ZIP_IDENTITY.json'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).as_posix() not in excluded and 'render_cache' not in p.relative_to(ROOT).parts and '__pycache__' not in p.relative_to(ROOT).parts)
payload=[{'path':p.relative_to(ROOT).as_posix(),**fileid(p)} for p in files]
write('MANIFEST.json',{'assignment':'SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01','created_utc':stamp,
    'exclusions':['MANIFEST.json (self)',ZIPNAME,'REVIEW_ZIP_IDENTITY.json (external-only)','render_cache/','__pycache__/'],
    'files':payload,'payload_count':len(payload),'payload_bytes':sum(p['bytes'] for p in payload)})
files.append(ROOT/'MANIFEST.json')
with zipfile.ZipFile(ROOT/ZIPNAME,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(ROOT/ZIPNAME) as z:
    assert z.testzip() is None
    expected={p.relative_to(ROOT).as_posix():fileid(p) for p in files}
    assert set(z.namelist())==set(expected) and len(z.namelist())==len(expected)
    for n,idn in expected.items():assert ident(z.read(n))==idn,n
write('REVIEW_ZIP_IDENTITY.json',{'file':ZIPNAME,**fileid(ROOT/ZIPNAME),'created_utc':stamp,'entries':len(files),
    'every_zip_entry_matches_manifest_or_manifest_file':True,'crc_passed':True,
    'manifest_identity':fileid(ROOT/'MANIFEST.json'),'external_only_not_in_zip':True})
print(json.dumps({'external_inputs_preserved':len(external),'archive_copies_preserved':len(members),
    'zip':ZIPNAME,**fileid(ROOT/ZIPNAME),'entries':len(files),'new_state_updates':0,'rng_draws':0},indent=2))
