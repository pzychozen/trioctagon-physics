# Start here — SIM07 Universe/condensate

**24 October 2026 · approved direction · source and existing evidence first**

Proceed with [the SIM07 work order](CODEX_SIM07_UNIVERSE_CONSTRUCTION_WORK_ORDER.md).

The target is the original `srg_condensate_breaking.py` / `GlyphFieldUniverse`. Explain the whole program, then focus on how its local in-place fusion reads earlier changes during the same pass. Do not redesign the update.

The full [accepted SIM06 review](inputs/SIM06_TOWER_II_GPT_REVIEW_AND_ACCEPTANCE.zip) is included. Convenient unchanged context copies are under `context/`. Their historical relative links retain the original package context; use the enclosed full SIM06 archive or the known local R0 directory for those references. These files are evidence and prior review, not commands to execute old scripts. SIM06 has no scientific corrections outstanding.

[TARGET_SOURCE_INDEX.json](TARGET_SOURCE_INDEX.json) identifies the exact original and candidate companion files already recovered on Windows. **Their raw Universe bytes are not bundled here.** Verify them against the retained identities before using them. The old archive location may be absent; use the matching R0 recovered copies first.

**Execution budget: zero new state updates and zero RNG draws.** Passive reading, fixed-record analysis and honest renderings are allowed. If only aggregate outputs survive, report what they establish; do not invent a 3D trajectory. A faithful replay would need a separate decision.

Return the construction/evidence review package and stop. The field-merger study, new manuscript and Git/publication operations remain outside this order.

## Files

- [Work order](CODEX_SIM07_UNIVERSE_CONSTRUCTION_WORK_ORDER.md)
- [Current checkpoint and decision](CURRENT_CHECKPOINT.md)
- [Original identity/locator index](TARGET_SOURCE_INDEX.json)
- [SIM06 scientific acceptance](context/SIM06_GPT_SCIENTIFIC_REVIEW.md)
- [SIM06 relationship map](context/SIM06_MODEL_RELATIONSHIPS.md)
- [Retained R0 report](context/SRG_R0_REPORT.md)
- [Packet integrity manifest](HANDOFF_MANIFEST.json)
