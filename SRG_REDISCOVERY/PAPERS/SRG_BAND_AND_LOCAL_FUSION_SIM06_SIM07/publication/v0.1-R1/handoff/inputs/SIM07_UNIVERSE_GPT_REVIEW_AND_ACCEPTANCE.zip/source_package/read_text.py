"""Text only; optional one-based inclusive line interval."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);lines=p.read_text(encoding='utf-8-sig').splitlines()
a=int(sys.argv[2]) if len(sys.argv)>2 else 1
b=int(sys.argv[3]) if len(sys.argv)>3 else len(lines)
print(str(p))
for i in range(a,min(b,len(lines))+1):print(f'{i}: {lines[i-1]}')
