"""Independent read-only SIM07 archive/source/aggregate audit.
No historical module import, constructor, state transition, RNG call, FFT,
clustering of invented coordinates, or submitted checker execution.
"""
from __future__ import annotations
import ast, csv, hashlib, io, json, math, re, sys, zipfile
from pathlib import Path
from collections import Counter
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'source_package'
DATA = ROOT.parent
OUT = ROOT / 'independent'

def identity(b: bytes) -> dict:
    return {'bytes':len(b), 'sha256':hashlib.sha256(b).hexdigest()}
def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(p,x):
    Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def table(p):
    with Path(p).open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f); rows=list(reader); return reader.fieldnames,rows
def near(a,b):
    return math.isclose(float(a),float(b),rel_tol=2e-14,abs_tol=2e-15)
checks=[]
def check(name, value, detail=None):
    checks.append({'check':name,'passed':bool(value),'detail':detail})
    if not value: print('CHECK FAILED:',name,detail)

zpath=DATA/'SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01_REVIEW.zip'
zi=load(DATA/'REVIEW_ZIP_IDENTITY.json')
check('Outer ZIP identity', identity(zpath.read_bytes())=={k:zi[k] for k in ['bytes','sha256']})
manifest=load(SRC/'MANIFEST.json')
with zipfile.ZipFile(zpath) as z:
    names=[n for n in z.namelist() if not n.endswith('/')]
    check('ZIP CRC',z.testzip() is None)
    check('52 unique file members',len(names)==len(set(names))==zi['entries']==52)
    check('Exact manifest membership', set(names)=={e['path'] for e in manifest['files']}|{'MANIFEST.json'})
    rows=[]
    for e in manifest['files']:
        actual=identity(z.read(e['path']))
        rows.append({'path':e['path'],**actual,'matches':actual=={k:e[k] for k in actual}})
        check('Extracted copy '+e['path'],(SRC/e['path']).read_bytes()==z.read(e['path']))
    check('51/51 payload hashes',len(rows)==51 and all(e['matches'] for e in rows))
    check('Payload byte total',sum(e['bytes'] for e in rows)==manifest['payload_bytes'])
    check('Manifest external identity',identity(z.read('MANIFEST.json'))==zi['manifest_identity'])
check('Standalone START_HERE', (DATA/'START_HERE(20261025-043757).md').read_bytes()==(SRC/'START_HERE.md').read_bytes())
dump(OUT/'PAYLOAD_IDENTITIES.json',rows)

# Compare copies with prescribed target identities and prior actually delivered ZIP.
target=load(SRC/'handoff/TARGET_SOURCE_INDEX.json')
for e in target['entries']:
    check('Target original '+e['filename'],identity((SRC/'original'/e['filename']).read_bytes())=={'bytes':e['expected_bytes'],'sha256':e['expected_sha256']})
baseline=load(SRC/'INPUT_BASELINE.json'); pres=load(SRC/'PRESERVATION_RECEIPT.json')
check('Baseline counts',len(baseline['files'])==10 and len(baseline['archive_members'])==12)
for e in baseline['files']:
    p=SRC/e['copy'] if e['copy'] else DATA/'SRG_SIM07_UNIVERSE_CONSTRUCTION_HANDOFF_20261024.zip'
    check('Available baseline snapshot '+str(e['copy'] or 'handoff ZIP'),identity(p.read_bytes())=={k:e[k] for k in ['bytes','sha256']})
check('Preservation receipt identities correspond to baseline',
      len(pres['external_files'])==len(baseline['files']) and
      all(all(v.get(k)==val for k,val in u.items()) for u,v in zip(baseline['files'],pres['external_files'])) and
      len(pres['archive_members'])==len(baseline['archive_members']) and
      all(all(v.get(k)==val for k,val in u.items()) for u,v in zip(baseline['archive_members'],pres['archive_members'])))
with zipfile.ZipFile(DATA/'SRG_SIM07_UNIVERSE_CONSTRUCTION_HANDOFF_20261024.zip') as h:
    handoff_names=h.namelist()
    for e in baseline['archive_members']:
        if e['member'] in handoff_names:
            b=h.read(e['member'])
        else:
            # Last copied document comes from the nested prior accepted SIM06 ZIP.
            hits=[]
            for zn in handoff_names:
                if zn.endswith('.zip'):
                    with zipfile.ZipFile(io.BytesIO(h.read(zn))) as nested:
                        if e['member'] in nested.namelist(): hits.append(nested.read(e['member']))
            if not hits:
                with zipfile.ZipFile(DATA/'SIM06_TOWER_II_GPT_REVIEW_AND_ACCEPTANCE.zip') as nested:
                    if e['member'] in nested.namelist(): hits.append(nested.read(e['member']))
            if len(hits)!=1: raise RuntimeError((e,'nested original ambiguous/missing',len(hits)))
            b=hits[0]
        check('Prior archive member '+e['member'], b==(SRC/e['copy']).read_bytes() and identity(b)=={k:e[k] for k in ['bytes','sha256']})

# Read source as text/AST only.
source=(SRC/'original/srg_condensate_breaking.py').read_text(encoding='utf-8')
node=ast.parse(source)
check('Complete 778-line source',len(source.splitlines())==778)
cls=next(n for n in node.body if isinstance(n,ast.ClassDef) and n.name=='GlyphFieldUniverse')
fns={n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)}
drivers={n.name:n for n in node.body if isinstance(n,ast.FunctionDef) and n.name.startswith('experiment_')}
locators={n.name:{'start':n.lineno,'end':n.end_lineno} for n in list(fns.values())+list(drivers.values())}
record=fns['_record']
used_names={n.id for n in ast.walk(record) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load)}
check('Observer ignores supplied adjacency and distances','adj' not in used_names and 'dists' not in used_names)
check('One gamma assignment, no read',len([n for n in ast.walk(node) if isinstance(n,ast.Attribute) and n.attr=='gamma_srg'])==1)
evolve=fns['evolve_pass']; statements=evolve.body
hbranch=next(n for n in statements if isinstance(n,ast.If) and ast.unparse(n.test)=='self.horizon is not None')
loop=hbranch.body[0]
check('Finite branch ordered index loop',isinstance(loop,ast.For) and ast.unparse(loop.iter)=='range(self.N)' and ast.unparse(loop.target)=='i')
inner=loop.body[1]
check('Local center reads live selected positions','self.positions[nbrs]' in ast.unparse(inner.body[0]) and 'np.abs(self.resonance[nbrs]) + 1e-08' in ast.unparse(inner.body[0]))
check('Fusion writes only row i',isinstance(inner.body[1],ast.AugAssign) and ast.unparse(inner.body[1].target)=='self.positions[i]')
check('Global center computed once outside loop',len(hbranch.orelse)==2 and isinstance(hbranch.orelse[0],ast.Assign) and isinstance(hbranch.orelse[1],ast.AugAssign))
check('One incoming adjacency call',sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='_adjacency_with_horizon' for n in ast.walk(evolve))==1)
output_mapping=[]
for name,fn in drivers.items():
    for n in ast.walk(fn):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='to_csv':
            constants=[s.value for s in ast.walk(n.args[0]) if isinstance(s,ast.Constant) and isinstance(s.value,str)]
            output_mapping.append({'driver':name,**locators[name],'output':''.join(constants).lstrip('/'),'write_line':n.lineno})
check('Five original CSV writes',len(output_mapping)==5 and {x['output'] for x in output_mapping}=={p.name for p in (SRC/'original').glob('*.csv')})
# Preserve exact source excerpts with line numbering, not a modified simulator.
excerpts=[]
for a,b in [(60,103),(105,153),(155,266),(278,355),(388,474),(514,575),(594,654),(675,757)]:
    excerpts.append(f'\n## Original source lines {a}–{b}\n\n```text\n'+'\n'.join(f'{i}: {source.splitlines()[i-1]}' for i in range(a,b+1))+'\n```\n')
(OUT/'SOURCE_READBACK.md').write_text('# SIM07 original-source readback\n'+''.join(excerpts),encoding='utf-8')
dump(OUT/'SOURCE_MAP.json',{'complete_source_lines':len(source.splitlines()),'methods':locators,'driver_outputs':output_mapping,'executed':False})

# Independently derive all reported inspection values from original fixed rows.
inspection=load(SRC/'derived/TABLE_INSPECTION.json')
raw={}; schemas={}; numeric_count=0
for p in sorted((SRC/'original').glob('*.csv')):
    columns,rs=table(p); raw[p.name]=rs
    missing=Counter(); ranges={}
    for col in columns:
        vals=[]; numeric=True
        for r in rs:
            if r[col]=='': missing[col]+=1; continue
            try: v=float(r[col])
            except ValueError: numeric=False; break
            check('Finite cell '+p.name+':'+col,math.isfinite(v))
            vals.append(v); numeric_count+=1
        if numeric and vals: ranges[col]={'min':min(vals),'max':max(vals)}
    schema={'rows':len(rs),'columns':columns,'missing_cells':sum(missing.values()),'missing_by_column':{c:[i+1 for i,r in enumerate(rs) if r[c]==''] for c in columns if missing[c]},'numeric_ranges':ranges}
    schemas[p.name]=schema
    old=inspection['schemas'][p.name]
    check('Schema/row/missing/ranges '+p.name,all(schema[k]==old.get(k) for k in schema), {'ignored_explanatory_metadata':[k for k in old if k not in schema]})
    if p.name in inspection['supporting_tables']:
        check('All original supporting cells '+p.name,rs==inspection['supporting_tables'][p.name])
full=raw['full_universe.csv']
check('Exactly passes 1..200',[int(r['pass']) for r in full]==list(range(1,201)))
check('First and last original rows',full[0]==inspection['full_first_row'] and full[-1]==inspection['full_last_row'])
for selected in inspection['selected_rows']:
    ix=selected['source_data_row']-1
    expected={k:v for k,v in selected.items() if k not in ['source_data_row','R_std_over_mean_derived']}
    check('Selected row '+str(ix+1),full[ix]==expected and float(full[ix]['R_std'])/float(full[ix]['R_mean'])==selected['R_std_over_mean_derived'])
changes={}
for col in ['n_spatial_clusters','n_resonance_clusters','top_seed_id']:
    changes[col]=[{'pass':int(b['pass']),'from':a[col],'to':b[col]} for a,b in zip(full,full[1:]) if a[col]!=b[col]]
    check('Recorded label changes '+col,changes[col]==inspection['recorded_label_changes'][col])
hr=raw['causal_horizons.csv']; horizon=[]
for h in ['3.0','5.0','8.0','12.0','20.0','999.0']:
    rs=[r for r in hr if float(r['horizon'])==float(h)]
    vals=[float(r['mean_inter_dist']) for r in rs]
    obs=next(x for x in inspection['horizon_summary'] if float(x['horizon_raw'])==float(h))
    check('Horizon description '+h, len(rs)==3 and obs['trials']==[int(r['trial']) for r in rs] and
          obs['spatial_cluster_counts']==[int(r['n_spatial_clusters']) for r in rs] and
          near(obs['mean_inter_dist_mean'],math.fsum(vals)/3) and obs['mean_inter_dist_min']==min(vals) and obs['mean_inter_dist_max']==max(vals))
    horizon.append({'horizon':h,'mean_inter_dist_mean':math.fsum(vals)/3,'values':vals,'spatial_counts':[int(r['n_spatial_clusters']) for r in rs]})
# Check plotted supporting CSVs without regenerating the figures.
selcols,selrows=table(SRC/'derived/full_universe_selected_rows.csv')
for r,expected in zip(selrows,inspection['selected_rows']):
    check('Selected CSV '+r['pass'], all(str(expected[k])==r[k] for k in r if k!='R_std_over_mean_derived') and near(r['R_std_over_mean_derived'],expected['R_std_over_mean_derived']))
check('Selected CSV length',len(selrows)==10)
plotcols,plotrows=table(SRC/'derived/horizon_plot_data.csv')
# This convenience CSV contains six per-setting summaries. The figure itself
# reads the original eighteen trial rows directly, as verified by source reading.
for row,expected in zip(plotrows,inspection['horizon_summary']):
    good=all(json.loads(row[k])==expected[k] for k in ['trials','spatial_cluster_counts'])
    good=good and row['horizon_raw']==expected['horizon_raw'] and row['configuration_label']==expected['configuration_label']
    good=good and all(near(row[k],expected[k]) for k in ['mean_inter_dist_mean','mean_inter_dist_min','mean_inter_dist_max'])
    check('Horizon six-row summary CSV '+row['horizon_raw'],good)
check('Horizon summary CSV rows',len(plotrows)==6)

# Three useful definitions are tested descriptively, not as reconstructed dynamics.
num=lambda r,k:float(r[k])
count10=[int(r['pass']) for r in full if r['n_spatial_clusters']=='10']
check('185 successive observations of ten spatial groups',count10==list(range(16,201)))
ratios=[num(r,'R_std')/num(r,'R_mean') for r in full]
min_ix=min(range(len(ratios)),key=lambda i:ratios[i])
pert=raw['condensate_perturbation.csv']
pertsummary=[{'delta':num(r,'delta'),'last_to_first_recorded_deviation':num(r,'final_deviation')/num(r,'initial_deviation'),'response_type':r['response_type'],'decay_time':r['decay_time'],'peak_count':int(r['n_oscillations'])} for r in pert]
equal_breath=all(raw['breathing_condensate.csv'][0][k]==raw['breathing_condensate.csv'][1][k] for k in raw['breathing_condensate.csv'][0] if k!='type')
check('Both breathing summary numeric strings equal',equal_breath==inspection['all_breathing_numeric_strings_identical'])
equalities=[]
for trial in range(3):
    rs=[{k:v for k,v in r.items() if k!='horizon'} for r in hr if int(r['trial'])==trial and float(r['horizon']) in {5,8,12,20}]
    equalities.append(len(rs)==4 and all(r==rs[0] for r in rs))
check('Horizon 5/8/12/20 summaries match by trial',equalities==inspection['finite_horizons_5_8_12_20_identical_except_h_per_trial'])
check('mean_grf below 1 at every saved pass',all(0<num(r,'mean_grf')<1 for r in full))
check('Positive and unequal amplitude extrema every saved pass',all(0<num(r,'R_min')<num(r,'R_max') for r in full))

# New-doc links are distinct from inherited historical context links.
link_rows=[]; missing=[]
for p in sorted(SRC.glob('*.md')):
    for m in re.finditer(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        uri=m.group(1).split('#')[0]
        if not uri or '://' in uri or re.match(r'^[A-Za-z]:',uri): continue
        q=(p.parent/unquote(uri)).resolve(); good=q.exists()
        item={'document':p.name,'target':uri,'exists':good};link_rows.append(item)
        if not good: missing.append(item)
check('Current-root document links resolve',not missing,missing)
# Input/figure identity only. No rendering of new data needed.
from PIL import Image
vis=load(SRC/'VISUAL_INSPECTION.json')
for e in vis['figures']:
    p=SRC/e['file']; img=Image.open(p)
    check('Figure identity and dimensions '+e['file'],identity(p.read_bytes())=={k:e[k] for k in ['bytes','sha256']} and list(img.size)==e['pixels'])

findings={
 'evidence_class':'New passive reading/summary of original saved CSVs; source deductions are separate. No trajectory generated.',
 'table_shapes':{k:[v['rows'],len(v['columns'])] for k,v in schemas.items()},
 'total_data_rows':sum(len(v) for v in raw.values()),
 'total_cells':sum(len(raw[k])*len(v['columns']) for k,v in schemas.items()),
 'finite_numeric_cells':numeric_count,
 'missing_cells':sum(v['missing_cells'] for v in schemas.values()),
 'main_first':full[0],'main_last':full[-1],
 'stable_count_window':{'from_pass':16,'to_pass':200,'rows':len(count10),'count':10,'membership_known':False},
 'main_pass20':full[19],
 'pass20_extreme_ratio':num(full[19],'R_max')/num(full[19],'R_min'),
 'pass20_relative_range':(num(full[19],'R_max')-num(full[19],'R_min'))/num(full[19],'R_max'),
 'last_relative_std':ratios[-1], 'min_relative_std':{'pass':min_ix+1,'value':ratios[min_ix]},
 'relative_std_rebounds_after_early_minimum':ratios[-1]>ratios[min_ix],
 'main_endpoint_extreme_ratio':num(full[-1],'R_max')/num(full[-1],'R_min'),
 'label_changes':changes,'horizon_summary':horizon,
 'horizon_summary_equality':equalities,
 'perturbation':pertsummary,
 'breathing_summary_equality':equal_breath,
 'source_driver_outputs':output_mapping,
 'execution':{'state_updates':0,'rng_draws':0,'historical_imports':0,'submitted_inspector_executions':0,'spectral_checks':0,'reconstructed_coordinates':0}
}
dump(OUT/'FINDINGS.json',findings)
dump(OUT/'SCHEMAS_AND_RANGES.json',schemas)
dump(OUT/'LINKS.json',link_rows)
report={'date':'2026-10-25','method':__doc__,'submitted_archive':identity(zpath.read_bytes()),
        'check_count':len(checks),'passed':sum(c['passed'] for c in checks),'failures':[c for c in checks if not c['passed']],
        'checks':checks,'limits':'No live Windows filesystem access. Copied bytes checked against delivered manifests/prior supplied ZIPs. CSV summaries are not newly recomputed observers from missing X/R. No actual run/order sensitivity measured.'}
dump(OUT/'VERIFICATION.json',report)
print(json.dumps({k:v for k,v in findings.items() if k not in ['label_changes','main_first','main_last','main_pass20','source_driver_outputs']},indent=2))
print('CHECKS',len(checks),'FAILURES',len(report['failures']))
