"""Static plots of original aggregate rows only; no simulation or RNG calls."""
from pathlib import Path
import os,csv,json
ROOT=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(ROOT/'render_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
def read(name):
    with (ROOT/'original'/name).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
u=read('full_universe.csv');h=read('causal_horizons.csv')
def v(rows,c):return [float(r[c]) for r in rows]
p=v(u,'pass')
plt.rcParams.update({'font.size':11,'axes.titlesize':12,'figure.facecolor':'white','savefig.facecolor':'white'})
fig,axs=plt.subplots(3,2,figsize=(13,11))
ax=axs[0,0]
for c,label,color in [('R_max','Maximum |R|','#b13a2b'),('R_mean','Mean |R|','#1571ad'),('R_min','Minimum |R|','#268157')]:ax.plot(p,v(u,c),label=label,color=color)
ax.set_title('Amplitude extrema stay distinct');ax.set_ylabel('Resonance (uncalibrated)');ax.legend(fontsize=9)
ax=axs[0,1]
for c,color in zip(['band_0.1508','band_0.2440','band_0.3948','band_0.6388'],['#1571ad','#b13a2b','#268157','#8754ab']):ax.plot(p,v(u,c),label=c.replace('band_','Assigned f = '),color=color,lw=1)
ax.set_title('Means by fixed assigned frequency');ax.set_ylabel('Mean |R| in each label class');ax.legend(fontsize=8,ncol=2)
ax=axs[1,0]
ax.step(p,v(u,'n_spatial_clusters'),where='post',label='Spatial: average linkage at 2.0',color='#1571ad')
ax.step(p,v(u,'n_resonance_clusters'),where='post',label='Amplitude: gaps > 5% of maximum',color='#b13a2b')
ax.axhline(6,color='#555',ls=':',lw=1,label='Six seeded populations (source)')
ax.annotate('Spatial count = 10\nfrom pass 16 onward',xy=(40,10),xytext=(80,25),arrowprops={'arrowstyle':'->','color':'#555'},fontsize=10)
ax.set_ylim(0,52);ax.set_title('Different grouping rules give different counts');ax.set_ylabel('Recorded observer count');ax.legend(fontsize=8,loc='upper right')
ax=axs[1,1];ax.plot(p,v(u,'mean_grf'),color='#1571ad');ax.axhline(1,color='#555',ls=':',lw=1)
ax.set_ylim(.82,1.005);ax.set_title('Recorded reciprocal-displacement observer');ax.set_ylabel('Mean 1 / (1 + ||V||)')
ax.text(.40,.20,'Below 1 at every recorded pass;\nthis is not mean speed.',transform=ax.transAxes,fontsize=10)
ax=axs[2,0];ax.plot(p,v(u,'L_effective'),color='#8754ab',lw=.8);ax.axhline(9,color='#777',ls=':',lw=1)
ax.set_title('Recorded L follows an imposed decaying schedule');ax.set_ylabel('Log-amplitude clipping limit')
ax=axs[2,1];ratio=[float(r['R_std'])/float(r['R_mean']) for r in u];ax.plot(p,ratio,color='#268157')
ax.set_title('Amplitude spread persists (new passive ratio)');ax.set_ylabel('Recorded std(R) / recorded mean |R|');ax.set_ylim(0,.51)
for ax in axs.flat:ax.set_xlim(1,200);ax.set_xlabel('Completed pass');ax.grid(alpha=.2)
fig.suptitle('Universe: the original 200-row aggregate chronology',fontsize=17,y=.99)
fig.text(.5,.955,'N=120 · horizon=6 · multi-frequency and prescribed breathing enabled · driver seed 1618',ha='center')
fig.text(.5,.008,'ORIGINAL AGGREGATES, newly plotted. No coordinates, new updates or generated states. Rows 1–200; no state-0 row.',ha='center',fontsize=10)
fig.tight_layout(rect=[.015,.035,.985,.94],h_pad=2,w_pad=2)
fig.savefig(OUT/'F01_original_universe_chronology.png',dpi=120);plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(13,5.6))
settings=[3,5,8,12,20,999];colors=['#1571ad','#b13a2b','#268157']
for trial in range(3):
    rows=[next(r for r in h if float(r['horizon'])==a and int(r['trial'])==trial) for a in settings]
    x=[i+(trial-1)*.1 for i in range(6)]
    for ax,col in zip(axs,['n_spatial_clusters','mean_inter_dist']):ax.scatter(x,v(rows,col),label=f'Trial {trial} (seed {42+trial})',color=colors[trial],s=45)
for ax in axs:
    ax.set_xticks(range(6),['3','5','8','12','20','None']);ax.axvline(4.5,color='#777',ls='--');ax.axvspan(4.5,5.5,color='#ddd',alpha=.3)
    ax.set_xlim(-.5,5.5);ax.set_xlabel('Horizon setting (categorical; None is stored as 999)');ax.grid(axis='y',alpha=.2)
axs[0].set_ylim(3.5,5.6);axs[0].set_yticks([4,5]);axs[0].set_ylabel('Recorded spatial-clustering count');axs[0].set_title('Endpoint observer after 100 updates');axs[0].legend(fontsize=9,loc='lower left')
axs[1].set_ylim(0,16);axs[1].set_ylabel('Mean pair distance of four seeded-population centers');axs[1].set_title('Actual centroid-separation statistic, not all coordinates')
fig.suptitle('Horizon comparison also switches the fusion branch',fontsize=17,y=.99)
fig.text(.5,.92,'Finite settings: ordered local fusion. None: one global center. These rows are configurations and trials, not time steps.',ha='center',fontsize=10)
fig.text(.5,.015,'ORIGINAL causal_horizons.csv, all 18 rows. Points are horizontally offset only to distinguish trials; no connecting time curve.',ha='center',fontsize=10)
fig.tight_layout(rect=[.015,.055,.985,.88],w_pad=3)
fig.savefig(OUT/'F02_horizon_settings.png',dpi=120);plt.close(fig)
(ROOT/'FIGURE_REGISTER.json').write_text(json.dumps({'evidence':'New visualizations of unchanged ORIGINAL aggregate tables; no coordinate rendering or simulation',
    'figures':[
        {'file':'figures/F01_original_universe_chronology.png','input':'original/full_universe.csv','data_rows':[1,200],'physical_lines':[2,201],
         'transforms':'Direct column plots; only std(R)/mean|R| is newly divided. Six-population reference comes from source lines 677–689. No smoothing, fitting, interpolation of missing states or FFT. Connecting line segments guide reading between supplied samples.',
         'axes':'Six panels: completed pass 1–200 on x; each y explicitly labeled. Radius/3D geometry not available.','size_pixels':[1560,1320]},
        {'file':'figures/F02_horizon_settings.png','input':'original/causal_horizons.csv','data_rows':[1,18],'physical_lines':[2,19],
         'transforms':'None/999 shown as categorical sixth setting; +/-0.1 categorical display offsets distinguish trials. No statistical confidence interval or time curve.',
         'axes':'Categorical horizon; recorded count and seeded-population mean inter-center distance. Position units are uncalibrated.','size_pixels':[1560,672]}],
    'matplotlib_version':matplotlib.__version__,'new_state_updates':0,'rng_draws':0},indent=2)+'\n')
print('Rendered two aggregate-only figures. No original code execution or RNG use.')
