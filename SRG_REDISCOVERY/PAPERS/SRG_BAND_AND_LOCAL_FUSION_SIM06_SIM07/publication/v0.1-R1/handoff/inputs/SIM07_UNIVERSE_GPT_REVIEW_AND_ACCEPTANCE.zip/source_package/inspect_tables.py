"""Passive original-CSV inspection. No arrays constructed for a simulator,
no state transitions, historical imports, random draws or spectral calculations.
"""
from pathlib import Path
import csv,json,math
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'derived';OUT.mkdir(exist_ok=True)
names=['full_universe.csv','causal_horizons.csv','condensate_perturbation.csv','multi_frequency.csv','breathing_condensate.csv']
tables={};summaries={}
for name in names:
    with (ROOT/'original'/name).open(newline='',encoding='utf-8-sig') as f:
        rd=csv.DictReader(f);rows=list(rd);columns=rd.fieldnames
    tables[name]=rows
    missing={c:[i+1 for i,r in enumerate(rows) if not r[c].strip()] for c in columns}
    ranges={}
    for c in columns:
        vals=[]
        try:
            vals=[float(r[c]) for r in rows if r[c].strip()]
            if vals:ranges[c]={'min':min(vals),'max':max(vals)}
        except ValueError:pass
    summaries[name]={'rows':len(rows),'columns':columns,'missing_cells':sum(len(v) for v in missing.values()),
        'missing_by_column':{k:v for k,v in missing.items() if v},'numeric_ranges':ranges,
        'data_row_numbering':'1-based excluding header; physical CSV line=data row+1'}
full=tables['full_universe.csv'];passes=[int(r['pass']) for r in full]
assert passes==list(range(1,201))
chron=[]
for p in [1,2,5,10,20,50,100,150,190,200]:
    row=full[p-1];chron.append({'source_data_row':p,**row,'R_std_over_mean_derived':float(row['R_std'])/float(row['R_mean'])})
events={}
for c in ['n_spatial_clusters','n_resonance_clusters','top_seed_id']:
    events[c]=[{'pass':passes[i],'from':full[i-1][c],'to':full[i][c]} for i in range(1,len(full)) if full[i][c]!=full[i-1][c]]
small={k:v for k,v in tables.items() if k!='full_universe.csv'}
breath=small['breathing_condensate.csv']
same_breath=all(breath[0][k]==breath[1][k] for k in breath[0] if k!='type')
horizon=[]
for h in ['3.0','5.0','8.0','12.0','20.0','999.0']:
    sub=[r for r in tables['causal_horizons.csv'] if r['horizon']==h]
    assert len(sub)==3
    horizon.append({'horizon_raw':h,'configuration_label':'None (global fusion)' if h=='999.0' else h+' (local fusion)',
        'trials':[int(r['trial']) for r in sub],
        'spatial_cluster_counts':[int(r['n_spatial_clusters']) for r in sub],
        'mean_inter_dist_mean':sum(float(r['mean_inter_dist']) for r in sub)/3,
        'mean_inter_dist_min':min(float(r['mean_inter_dist']) for r in sub),
        'mean_inter_dist_max':max(float(r['mean_inter_dist']) for r in sub)})
finite_equal=[]
for trial in range(3):
    sub=[r for r in tables['causal_horizons.csv'] if int(r['trial'])==trial and float(r['horizon']) in [5,8,12,20]]
    finite_equal.append(all(all(r[k]==sub[0][k] for k in r if k!='horizon') for r in sub))
result={'evidence':'NEW PASSIVE summaries of ORIGINAL aggregate CSV bytes',
    'new_state_updates':0,'rng_draws':0,'schemas':summaries,'selected_rows':chron,
    'recorded_label_changes':events,'supporting_tables':small,'horizon_summary':horizon,
    'all_breathing_numeric_strings_identical':same_breath,
    'finite_horizons_5_8_12_20_identical_except_h_per_trial':finite_equal,
    'full_last_row':full[-1], 'full_first_row':full[0]}
(OUT/'TABLE_INSPECTION.json').write_text(json.dumps(result,indent=2)+'\n')
for name,rows in [('full_universe_selected_rows.csv',chron),('horizon_plot_data.csv',horizon)]:
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Only directly relevant retained index entries; no new corpus inventory.
retained={}
for name in ['csv_evidence_summary.json','saved_data_checks.json']:
    obj=json.loads((ROOT/'context'/name).read_text(encoding='utf-8'))
    found=[]
    def walk(x,path=''):
        if isinstance(x,dict):
            if any(isinstance(v,str) and any(n in v for n in names) for v in x.values()):
                found.append({'json_path':path,'entry':x});return
            for k,v in x.items():
                if any(t in k.lower() for t in ['horizon','universe','perturbation','breathing','multi_frequency']):found.append({'json_path':path+'/'+k,'entry':v})
                else:walk(v,path+'/'+k)
        elif isinstance(x,list):
            for i,v in enumerate(x):walk(v,path+'/'+str(i))
    walk(obj);retained[name]=found
(OUT/'RETAINED_INDEX_EXCERPTS.json').write_text(json.dumps(retained,indent=2)+'\n')
inventory=json.loads((ROOT/'handoff/context/R0_external_and_selected_sources.json').read_text())
known=[r for r in inventory if 'MARCH_19023429' in r.get('package_path','') and any(t in r.get('package_path','').lower() for t in ['universe','condensate','horizon'])]
(OUT/'BOUNDED_RECOVERY.json').write_text(json.dumps({'known_inventory_entries':known,
    'consulted_indexes':['context/csv_evidence_summary.json','context/saved_data_checks.json','handoff/context/R0_external_and_selected_sources.json'],
    'result':'Named records and these indexes identify original aggregate tables; no explicit Universe coordinate/RNG/movie locator found. No broader search or replacement trajectory performed.'},indent=2)+'\n')
print(json.dumps({'schemas':summaries,'selected_rows':chron,'changes':events,'horizon_summary':horizon,
    'breathing_equal':same_breath,'finite_horizon_rows_equal_per_trial':finite_equal},indent=2))
