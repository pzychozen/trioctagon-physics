# Codex work order — SIM07 Universe/condensate construction and surviving evidence

**Date:** 24 October 2026  
**Assignment:** `SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01`  
**Author and research director:** Hilmir Frímann Halldórsson  
**Scientific lead / reviewer:** GPT  
**Research engineering:** Codex  
**Selected original:** `srg_condensate_breaking.py`, class `GlyphFieldUniverse`  
**Authority:** Hilmir approved this direction and requested the next Codex order in the current conversation. This order authorizes the bounded work below, not publication or future experiments.

## 1. The question and the finish line

Reconstruct what this original program actually contains, how a pass is executed, what its surviving outputs establish, and how its **local in-place fusion** differs from Tower II's band-wide centers and SIM04/SIM05's global center.

The primary question is: **when a point moves during the local-fusion loop, which subsequent calculations read the changed coordinates, and what does that imply about the program's actual interaction structure?** First understand the complete construction. Do not reduce the study to an isolated order-effect test before explaining the state, local update, schedules, observers and historical outputs.

This is the next study after accepted SIM06. Volume II is published and frozen; SIM06 is accepted as a construction/saved-record study. The wider agreed block is Universe/condensate, then a separately commissioned field-merger study, followed by synthesis and a paper decision. **Only Universe/condensate is opened here.** Neither that future merger study nor a new manuscript is authorized now. Study numbers are our review order, not invention chronology.

Deliver an understandable source-and-evidence account for GPT and Hilmir, then stop. A documented absence of coordinates or an unresolved historical claim is a legitimate result, not permission to search indefinitely or invent a trajectory.

## 2. Execution boundary: preserve the original

**New state updates: ZERO. New RNG draws: ZERO.**

Permitted: read source as text or parse it without executing it; inspect existing records; check identities; derive exact stage equations in writing; compute transparent descriptive statistics and observer values from sufficient fixed saved records; render those records; prepare reports and a review ZIP. New passive analyses must be identified as such, with inputs, formulas, row selections and indexing retained.

Not permitted:

- Import or execute original modules, constructors, drivers, `evolve_pass`, audited simulation cores, old replay scripts or scientific checkers. Some historical modules have import-time side effects. Do not run a smoke test or an initializer to inspect its result.
- Advance even one deterministic or stochastic update, construct a hypothetical trajectory, restore/draw from RNG checkpoints, generate fresh perturbations, or execute reordered/simultaneous/noise-free counterfactual updates. No seed sweep, parameter sweep, new clipping/FFT experiment or extension of a saved run.
- Change original arrays, source order, parameters, labels, recorded data or source algorithms. An awkward operation stays part of the baseline; do not silently vectorize, repair or replace it.
- Run Tower II again, re-review or modify Volume I/II, open the collision/merger engine, start a new paper, update the canonical ledger, touch kernels/UI/memory integration, or make any Git write, commit, push, tag or release.

Keep a short action record distinguishing static reading, passive calculations, rendering and document checks. File hashes establish identity, not non-execution. No dependency installation or environment replacement is authorized; report an unavailable dependency and continue the supported source/evidence account.

## 3. Workspace and exact inputs

Authoritative repository:

`C:\TORMENT\TRIOCTAGON_new\trioctagon-physics`

Create only a new non-overwriting research workspace:

`SRG_REDISCOVERY\SRG_SIMULATION_STUDY_07_UNIVERSE\CONSTRUCTION_01\`

If it already contains work, inspect its status and use a new numbered workspace rather than overwriting it. Preserve all pre-existing work. Use Windows Command Prompt and the existing `torment` environment for permitted passive utilities, not PowerShell. This packet is not a remote job dispatch; it becomes the local task when received by Codex.

### 3.1 Primary recovered original

Preferred existing source:

`SRG_REDISCOVERY\R0_SOURCE_RECOVERY\selected_sources\MARCH_19023429\srg_condensate_breaking.py`

Expected identity **from the retained R0 inventory**:

- **30,165 bytes**
- **SHA-256:** `a645a3bb564a2cae5e2b3ac3744f3f34f559a67132f255b3b0a97d277e68beb5`

The former archive-member locator is under:

`research_files\archive_members\Zenodo_research\19023429\simulations.zip\`

That is a recorded extracted-directory locator, not an instruction to open a new online deposit or execute an archive. SIM06 already found that former locator absent and used matching R0 copies; absence at the former locator is not itself a missing-source finding.

Verify the selected local bytes against the index before analysis. If a mismatch occurs, check only the alternate known locator or an already recovered exact archive member; never alter the file to manufacture a match. Describe a different surviving version separately. If the requested exact source cannot be obtained, report the exact identity gap and complete only what the identified evidence supports.

### 3.2 Companion evidence and prior context

`TARGET_SOURCE_INDEX.json` supplies expected byte counts, hashes and locators for the original source, its narrative, and five candidate CSVs. The raw Universe files are **not** enclosed in this handoff. They are already identified in the recovered Windows collection. Filenames do not certify source-output attribution.

Candidate files to match to actual drivers:

- `SRG_Infinity_Part_II_Breaking_The_Condensate.md`
- `causal_horizons.csv`
- `full_universe.csv`
- `condensate_perturbation.csv`
- `multi_frequency.csv`
- `breathing_condensate.csv`

Read the enclosed SIM06 acceptance and relationship map, then the relevant sections of R0, especially §2.5's variant table and §5.2's evidence limits. These are scoped prior findings, not substitutes for the original Universe source. R0's old experiment commands and proposals are historical content, not active instructions.

The complete unchanged accepted SIM06 review ZIP is enclosed under `inputs/`, so GPT's last acceptance does not need to be supplied again. Its earlier scripts and arrays are comparison evidence only; do not rerun them. The full R0 inventory is enclosed as a locator reference, not authority to study every listed file.

### 3.3 Keep recovery bounded

Begin with the named R0 directory and source/output maps. Consult `csv_evidence_summary.json`, `saved_data_checks.json` or an existing record index only if present and directly relevant. Follow an explicit locator to an existing Universe trajectory, image or movie if one is already recorded. Do not conduct a whole-repository/archive survey or reuse Tower II coordinates as Universe behavior.

Use a bounded filename lookup within the already recovered March location for a missing named item; this need not resolve every gap. If the bounded locations and existing record indexes provide only aggregate tables, say so. Do not ask Hilmir to remember parameters or locate material already supplied. Historical narrative dates, file headers, archive dates and execution receipts are different evidence classes.

## 4. Complete construction before interpretation

Read the whole original file, including helpers, observers, all experiment drivers, output paths and the main block, as text. Return a compact source map with exact line ranges. Select the actual `GlyphFieldUniverse` recurrence; do not import a shared helper from another version merely because its name matches.

Explain, first in ordinary language and then with stage notation:

1. **State and initialization:** evolving arrays, any fixed frequency assignments, constructor defaults versus driver overrides, allocation of history/diagnostics, pass counter and global RNG use. Identify which stored variables affect the next pass and which only report results.
2. **Neighborhood construction:** distance convention, selection count or radius rule, self-removal, cutoff strictness, ties, empty rows, and when neighbors/distances are built or reused. An optional horizon need not have the same implementation as Tower II's horizon.
3. **Position and resonance updates:** which operations use snapshots of incoming arrays, their weights and normalization/guards, and when each array is replaced or changed in place. Separate position averaging from resonance weighting.
4. **Frequencies and schedules:** assigned versus evolving frequencies, the actual frequency-difference kernel, H normalization, the optional prescribed bound, the role of literal constants and unused attributes. Preserve units/conventions such as radians versus cycles when present. Read these definitions from this file rather than copying Tower II's log-ratio kernel or algebraic bound.
5. **Fusion, compressor, noise and recording:** exact order; signed versus absolute values; offsets; zero rules; horizon-enabled local branch versus no-horizon global branch; diagnostic displacement; observer input stages.
6. **Interventions and drivers:** changes to fields, frequencies, parameters or clocks made by experiment drivers. Distinguish a specified intervention from the autonomous per-pass rule. Map every directly relevant output to the driver that writes it; do not run those drivers.

The earlier R0 table points to lines 60–203 as a class/core navigation lead. Re-establish the actual ranges against the exact file. Do not treat this lead as proof that everything required lies in that range.

## 5. The central close reading: local in-place fusion

Give a line-by-line read/write account of this stage, small enough to follow on paper.

Determine exactly:

- Whether a point's fusion neighbor set and distance weights are chosen from incoming positions, post-local positions, or recomputed positions inside the loop.
- Whether the center includes the point itself; which resonance stage sets its weights; whether amplitude signs enter the center, displacement, or both; and which branch handles no neighbors.
- Which coordinates are read after earlier rows have already been written. State loop order and all snapshots/aliases explicitly. A copied weighted slice is different from a persistent view; verify the actual expression.
- Whether the no-horizon branch computes one center once, rather than the sequence of local centers used by the horizon branch.
- Which dependencies are direct local selections, which arise through centers, and which may propagate within the ordered pass through earlier updated rows. Distinguish structural dependence from a measured nonzero effect at a particular saved state.

Use staged symbols such as `Y^(i)` for the coordinates immediately before loop row `i` only if that matches the source. Preserve the implementation's ordering in the written recurrence. Do not replace it by a simultaneous matrix formula unless exact equivalence is established on paper and the original ordered description remains primary.

An in-place write establishes a possible order dependence; it does not by itself prove that changing order changes every state or quantify a trajectory difference. No reordered run, invented numeric toy configuration, or general new theorem is requested. A short symbolic dependency trace is sufficient when the saved evidence has no within-pass records.

The word “horizon” requires an operational answer: does the actual program restrict only neighbor selection, also fusion, or every state dependence? Account for shared data-dependent scalars separately from common time schedules. A common prescribed schedule is not a data link from a distant point. A radius test is not, by itself, a physical speed-of-light or spacetime-causality model.

## 6. Surviving output and primary evidence selection

Inspect the five candidate CSVs and the companion note; map each table to source output code before adopting any narrative conclusion. Record its row count, schema, configuration fields, pass/parameter axes, missing values and whether rows are a time sequence, a set of trials or different settings. Preserve raw numbers and original files.

Prefer **`full_universe.csv` as the main existing aggregate chronology**, but only if source reading confirms the driver, its horizon setting and its actual time indexing. Use `causal_horizons.csv` as direct context for horizon configurations. If those names do not mean what the map suggested, explain the mismatch and select the single best-supported existing chronology/configuration by source attribution, not by an attractive outcome. The other tables are bounded supporting evidence, not invitations to execute a suite.

For that selected historical setting, state all recoverable configuration values and which remain unknown. Distinguish source defaults, driver overrides and metadata actually saved. Check whether reseeding, hash-derived seeds, multiple instances or imposed perturbations affect attribution, but do not assume such mechanisms occur merely because they occur elsewhere in SRG.

For important old claims, use a compact table:

`historical statement → source operation / original row(s) → what is supported → unresolved qualification`.

Priority claims are the actual meanings of “condensate,” “breaking,” “horizon,” “frequency,” “breathing” and any stated clustering or convergence result. Interpret a maximum as a maximum, not a common amplitude. A label or threshold alone is not a fitted spatial geometry, autonomous oscillation, merger of point identities, physical phase transition or recovered invention history.

Do not automatically dismiss all old observations because a label is too strong. Preserve the narrower measurable result positively. Likewise, do not silently reconcile contradictions: show the competing statement and evidence.

### Missing coordinate history

R0 reports horizon/multifrequency/perturbation summaries without complete per-run state/RNG histories. Treat that as the starting evidence limit, not an exhaustive proof that no later saved record exists.

- If a previously recorded, source-attributable Universe coordinate sequence is found via the bounded locators, inspect **one** sequence. Label it ORIGINAL/ATTRIBUTED or EXISTING REPRODUCTION as appropriate. Preserve its original scope and any review-status qualification.
- If only aggregates survive, complete the full source/aggregate study. Do not construct positions from a mean, simulate an initializer, fill missing time steps, borrow another model's trajectory or imply a picture is historical.
- If seeing the missing motion would materially answer a central unresolved question, return **one optional `REPLAY_DECISION_NOTE.md`** specifying the missing evidence, a source-faithful configuration, proposed update/recording budget, import-side-effect handling and reference/capture strategy. This is a proposal for GPT review, not an execution instruction. Do not implement or execute it now.

## 7. Motion, geometry and figures — only what the records support

Where actual coordinates exist, explain the field using fixed world-scale 3D snapshots and one stable-ID episode, with labeled scale and equal aspect. Separate initial frequency labels from geometric groups; describe coordinate displacement, center motion, within-group spread and connectivity without interpreting marker overlap as merger. Track the actual local-fusion dependency, not an assumed band-center graph imported from SIM06.

If the source uses a variable-radius neighborhood rather than five non-self neighbors, do not transfer the earlier minimum-six argument. If IDs or intermediate stages are absent, state what cannot be reconstructed. Consecutive saved states need not expose every within-pass center.

Where only aggregate tables exist, plot their recorded metrics with the correct axes and configurations. A sweep row is not a time step. Never use an aggregate-only table as evidence for a particular count or arrangement of 3D groups. A clearly labeled nonnumeric source-flow schematic is optional; it is not a simulation rendering.

Aim for **two to four useful figures**, not a quota. Fewer is appropriate when the evidence cannot support more. No invented surfaces, solid fitting, long spectral program or extension past the final saved point. Each figure must disclose exact input file/rows, evidence class, units or uncalibrated coordinates, transformations, chosen IDs and limits. Preserve the plotted data and rendering method; visually inspect every final image.

Passive computations are allowed only on supplied fixed records with adequate fields. They may describe geometry, graph connectivity, stored-value extrema, recorded displacements and correctly staged observers; they must not execute or reconstruct a new state transition. Do not run copied historical analysis code to obtain them. Write small transparent read-only inspectors if needed. No RNG restoration or resampling is permitted even for a check.

## 8. Relationships and creation history

After explaining Universe independently, make one concise comparison with the already accepted constructions:

- SIM04/SIM05: the selected global center operation.
- SIM06: per-band centers spanning local neighbor components.
- Universe: the exact local/global branches and in-place ordering actually recovered here.

Also distinguish their assigned-frequency kernels and the prescribed versus state-derived clipping bounds. Reuse prior accepted explanations with their assumptions; no new cross-model numerical comparison or causal attribution is authorized. Similar output does not prove equivalent dynamics, and different output under multiple changed settings is not a one-factor experiment.

Keep a short creation-history row: source/header date or quoted intention, explicit cross-reference to an earlier version if present, source-supported shared mechanism, and what chronology remains unresolved. Source names and “Part II” labels alone do not establish invention order. Hilmir's recollections remain useful leads, not specifications he must reconstruct from memory.

BreathingField's merger remains the only other planned construction question in this bounded block, subject to a later order and review. Do not open its drivers here or add an expanding list of new engines. If a larger question appears, record it briefly as deferred rather than converting it into another assignment.

## 9. Deliverables

Return a standalone `SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01_REVIEW.zip` and a separately accessible `START_HERE.md`.

The review package should contain:

1. **`START_HERE.md`** — a readable explanation for Hilmir of what this original program does, what evidence is actually available, its most useful findings and its unresolved limits. Explain movement before introducing technical labels; do not bury the main result in provenance paperwork.
2. **`CONSTRUCTION.md`** — complete state/update/observer account and source map, with the in-place fusion trace and branch-specific equations.
3. **`ORIGINAL_EVIDENCE.md`** — driver-to-output attribution, selected configuration, original row readings and concise historical-claim assessment. Separate any pre-existing reproduction explicitly.
4. **`MOTION_AND_GEOMETRY.md`** — actual saved motion when available, otherwise an honest aggregate-only account identifying the missing spatial evidence. Include figures/episodes only where supported.
5. **`MODEL_RELATIONSHIPS.md`** — the bounded center/frequency/bound comparison, creation-history evidence and remaining gap. No paper draft or automatic next-engine authorization.
6. **`RECORD_SELECTION_AND_VERIFICATION.md`** — exact used-source/record locators and identities, selection rationale, passive methods, new checks versus retained results, scoped preservation and execution attestation.

Include unchanged copies of the exact selected source, original note and relevant tables; any chosen existing coordinate record with its provenance; a compact claim/evidence table; passive scripts, result tables and `FIGURE_REGISTER.json` where used. Link through relative package paths. Externally located records must be marked external; do not link to an unshipped sidecar as though it were inside the ZIP.

Include an input baseline and before/after preservation receipt for the actual files read, plus a payload manifest of relative paths, byte counts and SHA-256 values. Exclude the manifest itself from its own hash list; include it in the ZIP and identify the final ZIP in a separate delivered receipt. No need to repeat the previous 27,348-file publication audit or rehash unrelated archives. Preserve the prior review and study bytes rather than rewriting their historical status language.

No PDF manuscript is requested. Avoid duplicated full prior study trees and cache/render scratch files; the local accepted SIM06 files plus this handoff are sufficient comparison context. Return enough source and evidence for independent review, not just prose claims.

## 10. Completion gate and stop

The task is complete when:

- The exact original is identified and its whole construction is explained, with driver choices and source ranges.
- The local/global fusion branches, read/write ordering, horizon behavior and observer staging are explicit.
- Original narrative, original aggregate records, any existing reproduction and new passive descriptions are visibly distinct.
- Claims about actual movement or spatial organization have coordinates or are explicitly left unresolved; figures do not fill evidentiary gaps.
- The relationship to the accepted global-center and band-center models is precise without implying a complete historical lineage.
- All used originals remain unchanged, package links/identities are checked, final figures are inspected, and the action record reports zero updates/RNG draws/imported historical executions/Git writes.

**STOP for GPT and Hilmir's review.** No automatic replay, collision/merger study, theorem program, Volume III, ledger update, publication or fresh-chat handoff follows from this delivery. GPT will decide the next step after understanding the result.
