# SIM07 Universe replay — Codex handoff

**25 October 2026 | New bounded work order, not an executed replay**

Read [CODEX_SIM07_UNIVERSE_REPLAY_01_WORK_ORDER.md](CODEX_SIM07_UNIVERSE_REPLAY_01_WORK_ORDER.md), then the [frozen run specification](RUN_SPECIFICATION.json).

The source-and-aggregate SIM07 study is accepted; it needs no correction. This assignment captures the missing point-level motion of the same original `experiment_full_universe` setting: **seed 1618, 120 points in six supplied populations, horizon 6, assigned frequencies and prescribed breathing enabled, 200 passes**.

## Exactly two executions

One unchanged-core reference and one instrumented capture, each 200 passes: **400 attempted updates maximum and two prescribed initializations maximum**, with no smoke updates, retries, alternate configurations or extension. Preserve all original random consumption, including constructor values later replaced. Reference/capture states, original metrics and RNG checkpoints must agree bit for bit; compare historical metrics separately using the predeclared criteria.

The capture records the actual sequential local-center reads, positions, amplitudes, random samples and observer groups. New 3D views come from these reproduced records, not invented historical geometry. Six supplied populations, frequency labels, local graph groups and observer-defined groups remain distinct. No result is required to form six groups or validate a physical narrative.

## Inputs already enclosed

- [Complete accepted SIM07 review and construction package](inputs/SIM07_UNIVERSE_GPT_REVIEW_AND_ACCEPTANCE.zip), unchanged. It contains the original submitted study and every original source/evidence file. The final GPT acceptance does not need to be forwarded separately.
- [Original source](originals/srg_condensate_breaking.py) and [historical comparison CSV](originals/full_universe.csv), exact convenience copies.
- [Accepted GPT review](context/SIM07_GPT_SCIENTIFIC_REVIEW.md), [prior replay proposal](context/REPLAY_DECISION_NOTE.md), [construction](context/CONSTRUCTION.md), and [evidence account](context/ORIGINAL_EVIDENCE.md). See [context link guidance](context/README.md) for inherited document links.
- [Input provenance](INPUT_MANIFEST.json) and [packet manifest](HANDOFF_MANIFEST.json).

Use the existing Windows checkout and `torment` environment. Write only to the new SIM07 `REPLAY_01` workspace. Do not modify the accepted construction, original algorithms, kernels, publications or ledger. No field-merger work, new manuscript or Git/publication action is authorized.

Return the readable review package and external ZIP identity receipt, then stop for GPT and Hilmir. **No Codex execution, source initialization, RNG draw or state update was launched while preparing this handoff.**
