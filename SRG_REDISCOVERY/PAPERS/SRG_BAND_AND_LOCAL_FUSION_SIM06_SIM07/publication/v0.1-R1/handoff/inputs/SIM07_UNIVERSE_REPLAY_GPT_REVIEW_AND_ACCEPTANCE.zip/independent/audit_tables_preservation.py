"""Passive tabular, figure-input, preservation and link audit. No simulator or RNG calls."""
from pathlib import Path
import csv,json,hashlib,zipfile,re,collections
import numpy as np
from scipy.spatial.distance import pdist
from scipy.sparse.csgraph import connected_components
from PIL import Image
S=Path(__file__).resolve().parents[1]/'source_package';O=Path(__file__).resolve().parent
errors=[];counts=collections.Counter();mx={}
def ck(k,ok,d=None):
 counts[k]+=1
 if not ok:errors.append([k,d])
def cl(k,a,b,d=None):
 a,b=np.asarray(a),np.asarray(b);v=float(np.max(np.abs(a-b))) if a.size else 0;mx[k]=max(v,mx.get(k,0));ck(k,np.allclose(a,b,atol=5e-13,rtol=5e-12),d)
def j(p):return json.loads(p.read_text())
def nz(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def rows(p):
 with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def sha(b):return hashlib.sha256(b).hexdigest()
B=[nz(S/f'runs/B_CAPTURE/boundaries/boundary_{p:03}.npz') for p in range(201)];T=[nz(S/f'runs/B_CAPTURE/stages/pass_{p:03}.npz') for p in range(1,201)]
X=np.stack([b['X'] for b in B]);V=np.stack([b['V'] for b in B]);R=np.stack([b['R'] for b in B]);F=B[0]['frequencies'];N=120
steps=np.linalg.norm(V,axis=2);paths=np.cumsum(steps,axis=0)
for run in ['A_REFERENCE','B_CAPTURE']:
 rs=rows(S/f'runs/{run}/point_states.csv');ck('point_csv_length',len(rs)==24120,run)
 for n,r in enumerate(rs):
  p,i=divmod(n,120);ck('point_csv_keys',int(r['boundary'])==p and int(r['id'])==i and int(r['population'])==i//20,[run,n])
  vals=[float(r[k]) for k in ['frequency','x','y','z','R_signed','vx','vy','vz']];expected=np.r_[F[i],X[p,i],R[p,i],V[p,i]]
  ck('point_csv_values_exact',np.array_equal(vals,expected),[run,n])
for r in rows(S/'analysis/geometry.csv'):
 p=int(r['boundary']);c=X[p].mean(axis=0);rg=np.sqrt(np.mean(np.sum((X[p]-c)**2,axis=1)))
 expected={'center_x':c[0],'center_y':c[1],'center_z':c[2],'radius_of_gyration':rg,'diameter':pdist(X[p]).max(),'center_displacement_from_0':np.linalg.norm(c-X[0].mean(axis=0)),'mean_step':steps[p].mean(),'max_step':steps[p].max(),'mean_cumulative_path':paths[p].mean(),'min_signed_R':R[p].min(),'max_signed_R':R[p].max()}
 for k,v in expected.items():cl('whole_geometry_'+k,v,float(r[k]),p)
for r in rows(S/'analysis/population_geometry.csv'):
 p,k=int(r['boundary']),int(r['population']);ids=np.arange(20*k,20*(k+1));xx=X[p,ids];c=xx.mean(axis=0)
 expected={'center_x':c[0],'center_y':c[1],'center_z':c[2],'radius_of_gyration':np.sqrt(np.mean(np.sum((xx-c)**2,axis=1))),'diameter':pdist(xx).max(),'center_displacement_from_0':np.linalg.norm(c-X[0,ids].mean(axis=0)),'flattened_std_original_definition':np.std(xx),'mean_step':steps[p,ids].mean(),'mean_cumulative_path':paths[p,ids].mean(),'mean_abs_R':np.mean(np.abs(R[p,ids]))}
 for key,v in expected.items():cl('population_geometry_'+key,v,float(r[key]),[p,k])
for r in rows(S/'analysis/stage_movement.csv'):
 p=int(r['pass']);t=T[p-1]
 for key,v in {'mean_local_length':np.linalg.norm(t['Y']-X[p-1],axis=1).mean(),'mean_fusion_length':np.linalg.norm(t['Z']-t['Y'],axis=1).mean(),'mean_noise_length':np.linalg.norm(t['noise'],axis=1).mean(),'mean_net_length':steps[p].mean()}.items():cl('stage_'+key,v,float(r[key]),p)
# Figure-source values and same-boundary labeling.
for r in rows(S/'figures/data/F01_snapshots.csv'):
 p,i=int(r['boundary']),int(r['id']);cl('figure1_coordinates',[float(r[k]) for k in ['x','y','z']],X[p,i],[p,i]);ck('figure1_pop',int(r['population'])==i//20)
canonical={}
for p in [1,16,50,199]:
 adj=T[p]['adjacency'];labs={}
 for mode in ['weak','strong']:
  _,a=connected_components(adj,directed=True,connection=mode);labs[mode]=np.array([np.flatnonzero(a==a[i]).min() for i in range(120)])
 a=T[p-1]['observer_membership'];labs['observer']=np.array([np.flatnonzero(a==a[i]).min() for i in range(120)]);canonical[p]=labs
for file in ['analysis/same_boundary_memberships.csv','figures/data/F02_memberships.csv']:
 for r in rows(S/file):
  p,i=int(r['boundary']),int(r['id']);ck('same_boundary_labels',int(r['graph_supplies_pass'])==p+1 and all(int(r[m+'_min_id'])==int(canonical[p][m][i]) for m in ['weak','strong','observer']),[file,p,i])
for r in rows(S/'figures/data/F04_episode_paths.csv'):
 p,i=int(r['boundary']),int(r['id']);origin=np.array([float(r[k]) for k in ['origin_x','origin_y','origin_z']]);cl('figure4_paths',[float(r[k]) for k in ['centered_x','centered_y','centered_z']],X[p,i]-origin,[p,i])
for r in rows(S/'figures/data/F04_ordered_contributions.csv'):
 p,i,k=int(r['pass']),int(r['row_id']),int(r['neighbor_id']);t=T[p-1];ids=t['fusion_ids'][i];slot=int(np.flatnonzero(ids==k)[0]);w=t['fusion_weights'][i];a=w[slot]/w.sum();inc=t['fusion_reads'][i,slot]-t['Y'][k]
 cl('figure4_contributions',[float(r[s]) for s in ['weighted_dx','weighted_dy','weighted_dz']],a*inc,[p,i,k])
for r in rows(S/'figures/data/F05_historical_float_errors.csv'):
 h,y=float(r['historical']),float(r['replay']);d=abs(y-h);cl('figure5_absolute',float(r['absolute_error']),d);cl('figure5_ratio',float(r['error_divided_by_frozen_tolerance']),d/(1e-12+1e-10*abs(h)))
# Before/after identity table agrees; matching prior snapshots are distinct from live audit.
base=j(S/'INPUT_BASELINE.json')['protected_files'];receipt=j(S/'PRESERVATION_RECEIPT.json');after={x['path']:x for x in receipt['protected_files']}
ck('preservation_count',len(base)==len(after)==receipt['protected_file_count'])
for x in base:
 y=after.get(x['path'],{});ck('preservation_before_after',all(x.get(k)==y.get(k) for k in ['path','bytes','sha256']) and y.get('unchanged'),x['path'])
available={}
for name in ['SRG_SIM07_UNIVERSE_REPLAY_HANDOFF_20261025.zip','SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01_REVIEW.zip','REVIEW_ZIP_IDENTITY.json']:
 p=Path('/mnt/data')/name;b=p.read_bytes();available[(len(b),sha(b))]=name
with zipfile.ZipFile('/mnt/data/SRG_SIMULATION_STUDY_07_UNIVERSE_CONSTRUCTION_01_REVIEW.zip') as z:
 for name in z.namelist():
  b=z.read(name);available[(len(b),sha(b))]='prior construction/'+name
matched=[];unavailable=[]
for x in base:
 key=(x['bytes'],x['sha256']);(matched if key in available else unavailable).append(x['path'])
# Source extraction text includes unchanged intervals and unchanged H_MAX / PHI assignments.
source=(S/'handoff/originals/srg_condensate_breaking.py').read_text().splitlines(keepends=True);ref=(S/'methods/reference_core.py').read_text()
for lo,hi in [[42,54],[60,266],[663,758]]:ck('exact_source_interval',''.join(source[lo-1:hi]) in ref,[lo,hi])
config=json.loads(str(B[0]['configuration_json']));ck('frozen_configuration',config=={'N':120,'horizon':6.,'multi_freq':True,'breathing':True,'base_L':9.,'alpha':.05,'beta':.15,'lam_H':.05,'k_neighbors':5,'gamma_srg':.08699})
# New root documents only; inherited archive-relative provenance is not rewritten.
links=[]
for p in S.glob('*.md'):
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in target or target.startswith('#'):continue
  target=target.split('#')[0]
  if not target:continue
  q=p.parent/target;links.append([p.name,target,q.exists()]);ck('root_link',q.exists(),[p.name,target])
visual=[]
for p in sorted((S/'figures').glob('*.png')):
 im=Image.open(p);visual.append({'path':str(p.relative_to(S)),'width':im.width,'height':im.height,'sha256':sha(p.read_bytes()),'review':'Opened and visually inspected at full available render; no blocking clipping or misleading interpolation found. Existing image not regenerated.'})
result={'status':'PASS' if not errors else 'FAIL','errors':errors,'checks':dict(counts),'maximum_errors':mx,'preservation':{'baselined_files':len(base),'available_prior_snapshot_matches':len(matched),'unavailable_live_only':unavailable,'qualification':'No live Windows path accessed. Snapshot agreement and before/after receipt consistency are not independent proof of live preservation or non-execution.'},'figure_review':visual,'root_links_checked':len(links),'operational_note':'ACTION_RECORD.md discloses initial filesystem/ZIP reads using PowerShell, contrary to the requested CMD workflow. Scientific executions used CMD/torment. Non-scientific process deviation; no scientific correction/rerun required. Future work orders should follow CMD throughout.'}
(O/'TABLES_PRESERVATION_VISUAL.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'errors':errors[:15],'preservation':result['preservation'],'root_links_checked':len(links),'figures':len(visual),'checks':dict(counts)},indent=2))
