"""One authorized execution; NEVER retry. Invoked only through launch_run.py."""
from pathlib import Path
import hashlib, json, os, sys, traceback
import numpy as np
from recorder import Recorder, ledger, dump, config

ROOT=Path(__file__).resolve().parents[1]
run=sys.argv[1]
assert run in ['A_REFERENCE','B_CAPTURE']
preflight=json.loads((ROOT/'PREFLIGHT.json').read_text())
assert preflight['status']=='READY_ZERO_INITIALIZATIONS_ZERO_UPDATES'
for e in preflight['frozen_methods']:
    assert hashlib.sha256((ROOT/e['path']).read_bytes()).hexdigest()==e['sha256'],e['path']
events=[json.loads(l) for l in (ROOT/'CALL_BUDGET.jsonl').read_text().splitlines()] if (ROOT/'CALL_BUDGET.jsonl').exists() else []
assert not any(e['run']==run and e['event']=='initialization_entry' for e in events),'No retries'
assert sum(e['event']=='initialization_entry' for e in events)<2
if run=='B_CAPTURE': assert any(e['run']=='A_REFERENCE' and e['event']=='run_completed' for e in events)
out=ROOT/'runs'/run
out.mkdir(parents=True,exist_ok=False)
rec=Recorder(run,out,run=='B_CAPTURE')
core=ROOT/'methods'/('capture_core.py' if rec.deep else 'reference_core.py')
namespace={'__name__':'isolated_original_extraction','OUTPUT_DIR':str(out),'REC':rec}
# This evaluates only original operator definitions, sampled H_MAX and class/driver
# definitions. No constructor or RNG call occurs until the counted driver call below.
exec(compile(core.read_text(encoding='utf-8'),str(core),'exec'),namespace)
cls=namespace['GlyphFieldUniverse']; evolve_original=cls.evolve; step_original=cls.evolve_pass
attempted=0; completed=0

def evolve_observed(field,n_passes):
    assert n_passes==200 and field.pass_count==0
    assert len(field.metrics_history)==0
    assert config(field)=={'N':120,'horizon':6.0,'multi_freq':True,'breathing':True,'base_L':9.0,'alpha':0.05,'beta':0.15,'lam_H':0.05,'k_neighbors':5,'gamma_srg':0.08699}
    rec.boundary(field)
    dump(out/'configuration.json',config(field))
    ledger('initialization_completed',run,boundary=0)
    return evolve_original(field,n_passes)

def step_observed(field):
    global attempted,completed
    assert attempted<200 and field.pass_count==completed
    attempted+=1
    ledger('step_entry',run,attempt=attempted,pass_before=field.pass_count,pass_expected=field.pass_count+1)
    rec.begin_pass(field)
    try:
        result=step_original(field)
        rec.end_pass(field)
        completed+=1
        ledger('step_completed',run,attempt=attempted,pass_after=field.pass_count)
        return result
    except BaseException:
        rec.partial(); ledger('step_failed',run,attempt=attempted,error=traceback.format_exc()); raise

cls.evolve=evolve_observed; cls.evolve_pass=step_observed
rec.install_random_observers()
try:
    ledger('initialization_entry',run,driver_seed=1618,command=sys.argv,python=sys.executable)
    field,df=namespace['experiment_full_universe']()
    assert attempted==completed==200
    ledger('run_completed',run,initializations=1,attempted=attempted,completed=completed,pass_after=field.pass_count)
    dump(out/'RUN_RECEIPT.json',{'run':run,'status':'COMPLETE','initializations':1,'attempted_updates':attempted,'completed_updates':completed,'boundary_records':201,'original_metric_rows':len(df),'random_calls_including_seed':len(rec.calls),'H_MAX':namespace['H_MAX'],'PHI':namespace['PHI'],'core_sha256':hashlib.sha256(core.read_bytes()).hexdigest()})
except BaseException:
    ledger('run_failed',run,attempted=attempted,completed=completed,error=traceback.format_exc())
    dump(out/'RUN_RECEIPT.json',{'run':run,'status':'FAILED_NO_RETRY','attempted_updates':attempted,'completed_updates':completed,'error':traceback.format_exc()})
    raise
finally:
    rec.uninstall_observers()
