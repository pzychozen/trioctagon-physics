"""Process receipt for exactly one prescribed execution. No automatic retry."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
run=sys.argv[1]; assert run in ['A_REFERENCE','B_CAPTURE']
receipt=ROOT/f'PROCESS_{run}.json'
assert not receipt.exists(),'Already attempted; do not retry'
cmd=[sys.executable,'-B',str(ROOT/'methods/run_once.py'),run]
data={'run':run,'command':cmd,'cwd':str(ROOT),'start_utc':datetime.now(timezone.utc).isoformat(),'parent_pid':os.getpid(),'status':'LAUNCHING','shell_context':'Windows Command Prompt; conda activate torment'}
receipt.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
with (ROOT/f'{run}_STDOUT.txt').open('w',encoding='utf-8',newline='\n') as stdout, (ROOT/f'{run}_STDERR.txt').open('w',encoding='utf-8',newline='\n') as stderr:
    process=subprocess.Popen(cmd,cwd=ROOT,stdout=stdout,stderr=stderr)
    data['pid']=process.pid
    receipt.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    code=process.wait()
data.update(status='COMPLETE' if code==0 else 'FAILED_NO_RETRY',exit_code=code,end_utc=datetime.now(timezone.utc).isoformat())
receipt.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2)); sys.exit(code)
