# Context copies and their original link roots

These documents and the acceptance receipt are unchanged copies from the accepted SIM07 review archive. Their earlier execution prohibitions and proposal-only wording describe that earlier checkpoint. The new dated work order authorizes only its explicitly bounded replay.

Links *inside these inherited documents* retain their original relative paths. To follow those links, extract `../inputs/SIM07_UNIVERSE_GPT_REVIEW_AND_ACCEPTANCE.zip` into a separate read-only input folder and open the document at its original member path listed in `../INPUT_MANIFEST.json`. The complete archive, including `source_package/`, supplies the original document structure. No archived script is a request to execute it.

The new work order and starting guide have their own direct relative links checked against this handoff.
