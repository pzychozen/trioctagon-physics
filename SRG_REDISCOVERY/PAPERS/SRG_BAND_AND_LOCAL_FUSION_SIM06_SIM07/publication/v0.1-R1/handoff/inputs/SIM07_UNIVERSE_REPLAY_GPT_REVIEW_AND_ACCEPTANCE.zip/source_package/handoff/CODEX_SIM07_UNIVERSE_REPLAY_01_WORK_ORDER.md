# Codex work order — SIM07 Universe: one faithful replay and inspectable motion

**Date:** 25 October 2026  
**Assignment:** `SRG_SIM07_UNIVERSE_REPLAY_01`  
**Author / research director:** Hilmir Frímann Halldórsson  
**Scientific lead and reviewer:** GPT  
**Research engineering:** Codex  
**Authority:** Hilmir's request, “please proceed with next work order for codex,” following GPT's recommendation of one reference execution and one matching capture of the selected Universe setting. This order authorizes that bounded replay, not another construction or a general experiment program.

## 1. Purpose and inherited checkpoint

SIM07 `CONSTRUCTION_01` is **accepted within historical-source and original-aggregate scope**, with no required scientific corrections. Do not reopen or revise it. Its complete acceptance package is supplied under [inputs](inputs/SIM07_UNIVERSE_GPT_REVIEW_AND_ACCEPTANCE.zip); the readable [GPT review](context/SIM07_GPT_SCIENTIFIC_REVIEW.md) and [original replay proposal](context/REPLAY_DECISION_NOTE.md) are also included unchanged.

The remaining central gap is the absence of a complete coordinate/RNG history for the original `experiment_full_universe` output. Reproduce exactly that one setting and record enough information to explain the motion, the changing groups and the original ordered fusion. These are **new reproduced coordinates**, not recovered historical coordinates.

The principal question is: **what do the unchanged original update rules actually make these points do, and how do earlier positional writes enter later local-center calculations within a pass?** Understanding the original program comes before searching for a preferred shape or interpretation.

This order supersedes the previous zero-run boundary **only for the two executions specified here, in a new workspace**. Earlier receipts retain their original dates, limits and “proposal only” wording. Their archived instructions do not override this later order, and their presence is not authority to run other archived code.

## 2. Workspace and protected material

Authoritative checkout:

```text
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics
```

Create outputs under:

```text
SRG_REDISCOVERY\SRG_SIMULATION_STUDY_07_UNIVERSE\REPLAY_01\
```

Use Windows Command Prompt and the existing `torment` environment. Do not install, upgrade or downgrade dependencies to chase a historical numerical match. Record the actual environment; report a missing required dependency before initialization.

If `REPLAY_01` already exists, inspect its receipts first. Do not overwrite previous results, restart an execution, or create a differently named directory to reset the budget. An unused workspace can be completed after its contents are identified; evidence of an earlier scientific attempt requires reporting its consumed budget before proceeding.

Keep the original source, `CONSTRUCTION_01`, SIM06 and its review, earlier R0–R3 records, both published volumes, canonical ledger, kernels, UI and unrelated files unchanged. Scope a before/after hash baseline to the accepted construction directory and the actual external inputs used. Do not repeat a whole-repository audit merely for this study.

No Git writes, publication, paper drafting, ledger edits, kernel integration, field-merger execution, Tower study or new archive survey. All new code, records, logs and visualizations belong inside the new workspace.

## 3. Exact inputs and source isolation

| Input | Bytes | SHA-256 |
|---|---:|---|
| Original `srg_condensate_breaking.py` | 30,165 | `a645a3bb564a2cae5e2b3ac3744f3f34f559a67132f255b3b0a97d277e68beb5` |
| Original `full_universe.csv` | 45,093 | `f58acaf40d5bf2eae0110499c5291cea6227a70b2260386db2823821d79c1c50` |
| Accepted SIM07 GPT package | 1,199,866 | `f9fc96200aba6056a8a3df82341159deff9f9031ee40eec62e21ae5b0b21635c` |

Convenience copies of the first two files are in [originals](originals/). They are byte-identical to the accepted package. The full package includes all seven original source/evidence files, all construction reports, the unchanged original submission, and the independent review. Verify these identities before executing anything.

Preferred recovered originals are under:

```text
SRG_REDISCOVERY\R0_SOURCE_RECOVERY\selected_sources\MARCH_19023429\
```

The accepted construction also retains copies under:

```text
SRG_REDISCOVERY\SRG_SIMULATION_STUDY_07_UNIVERSE\CONSTRUCTION_01\original\
```

Use matching local copies or the supplied bytes. A mismatch is a stop condition, not permission to select a nearby version. Local availability does not require a new recovery search.

Read the exact source and the supplied [construction account](context/CONSTRUCTION.md). Build a minimal isolated core from these original intervals:

- Lines **42–54**: `H`, signed `rpco`, the actual sampled `H_MAX` expression, and `PHI`.
- Lines **60–266**: complete `GlyphFieldUniverse`, including its original observer.
- Lines **663–758**: only `experiment_full_universe`.

Supply only the necessary imports and a workspace-local `OUTPUT_DIR`. Do not import or run the complete original module, its main block (765–778), the four other experiment drivers, or old review/build helpers. Preserve the original source as an untouched evidence file. The isolated core is a declared extraction, not a replacement original.

Retain the exact numerical expressions, NumPy legacy global-RNG interface, method calls, sort behavior and loop order. In particular, do not replace the sampled `H_MAX` with a hand-entered value, simplify the log/exp compressor, substitute a different neighbor library, reorder reductions, vectorize local fusion, or modernize the RNG. Redirecting `OUTPUT_DIR` is an output-only adaptation; record it explicitly. Preserve the selected driver's endpoint report and CSV export.

Before initialization, record extraction intervals, hashes and an AST/text comparison. The reference numerical definitions must match the original. Capture instrumentation may add copies and observation hooks only; removing those documented hooks must recover the original numerical statements and their order. A hook must never write into a live array, change aliasing, evaluate an update a second time, or consume random values.

## 4. Frozen configuration and initialization order

This is the selected `experiment_full_universe` setting, **not** another experiment with a familiar seed:

| Setting | Required value |
|---|---|
| Driver seed | **1618** |
| Points | **120** |
| Supplied spatial populations | Six ordered blocks of 20 stable IDs |
| Population centers, in source order | `(8,0,0)`, `(-8,0,0)`, `(0,8,0)`, `(0,-8,0)`, `(0,0,8)`, `(0,0,-8)` |
| Population coordinate draws | Six `np.random.normal(c, 1.5, (20,3))` calls, then `vstack` |
| Constructor | `GlyphFieldUniverse(120, horizon=6.0, multi_freq=True, breathing=True, seed=None)` |
| Constructor defaults | `R_range=(0,.3)`, `spatial_range=(-5,5)` |
| Replaced arrays | Positions become the six-population array; resonance is newly drawn with `np.random.uniform(0,.3,120)` |
| Evolution | Original `field.evolve(200)` |
| Other settings | Unchanged source defaults, including `.05`, `.15`, `.05`, five neighbors, base `L=9` and stored-but-unused `.08699` |

Each of the two runs performs the following sequence once:

1. Execute the original `np.random.seed(1618)`.
2. Make all six Gaussian population draws in their supplied order and stack them.
3. Call the original constructor with `seed=None`: it still consumes its uniform position draw, uniform resonance draw and frequency-choice draw, in that order.
4. Preserve the fixed frequency array chosen from `[.244, .244*PHI, .244*PHI**2, .244/PHI]`.
5. Replace positions as the driver does, then consume the replacement resonance draw.
6. Save boundary **0 after those replacements**, with zero displacement and pass counter zero. The original aggregate history is still empty at this point.
7. Perform the 200 source updates.

**Do not skip the overwritten constructor arrays. Do not reseed in the constructor or before replacement resonance.** Those choices alter the later random stream. Population IDs are a diagnostic mapping `id // 20`, not an extra interaction label. Frequency labels are independently assigned and must not be forced into equal counts.

[RUN_SPECIFICATION.json](RUN_SPECIFICATION.json) records this configuration and the predeclared comparison policy. It is metadata, not executable simulation code.

## 5. Strict execution budget and sequence

| Execution | Initialization | Maximum attempted `evolve_pass` calls |
|---|---:|---:|
| A — reference | One prescribed driver initialization | 200 |
| B — instrumented capture | One independently repeated prescribed driver initialization | 200 |
| **Entire assignment** | **Two initializations maximum** | **400 calls maximum** |

Both executions have the same configuration and source mathematics. They establish recording fidelity, **not two independent experimental trials**. Successful completion uses 400 updates, not 400 passes in one trajectory. No state beyond pass 200 is authorized.

Finish source inspection, extraction checks, recorder schemas, path checks and syntax/static checks **before either initialization**. No smoke updates, practice initializations, toy trajectory tests, discarded warm-ups, random fixtures, alternate seed, parameter sweep, reordered loop, simultaneous-fusion control, no-horizon control, breathing-off control or extension. Merely naming a call a test does not exempt it from the budget.

Use separate reference/capture output directories and isolated processes with the same recorded environment. Maintain one external, durable budget ledger: initialization attempts and step entry are written before execution, and completion is recorded afterward. Failed/partial calls count as attempted calls. Record timestamps, pass labels, process IDs, commands, exit status and any errors. No automatic retry or resume of scientific execution; preserve partial outputs and return a blocker if a run fails. Do not spend a third run on recovery or repeat completed passes after discovering a recording defect.

Reference recording can wrap the unchanged step solely to copy boundary state before/after the single call. Capture recording additionally observes its internal stages. Counters and recorders may not alter the simulation state. Pure file/record-analysis fixes after execution can use the already saved files, without reconstructing or re-advancing a trajectory.

## 6. Required capture: make this run inspectable the first time

Binary arrays with explicit dtype/shape are authoritative; CSV/JSON are readable companions. Never retain a view that later mutates. Store copies at the stage where the source actually uses a value.

### 6.1 Initialization and complete boundaries

For both reference and capture, retain:

- Every boundary `p=0,...,200`: X, R, V, pass, fixed frequencies and configuration. This is **201 boundaries and 24,120 point-state rows per complete run**; the point IDs are always 0–119.
- Full legacy RNG checkpoints after seeding, at the initialization stages, at boundary 0, and around each pass. Preserve the generator name, state words, position, cached-Gaussian flag and cached value without lossy serialization. A pre-seed checkpoint may be retained as provenance but need not agree across isolated processes; comparisons begin after the deterministic seed.
- The driver's Gaussian population array, discarded constructor X/R arrays, chosen frequency array and replacement R, or exact lossless checkpoint copies documenting those stages. Do not regenerate them afterward to obtain missing evidence.
- All original aggregate rows in original key/column order, original endpoint printed summaries and the exported CSV under a run-local path.

The capture must also retain actual random-return arrays from the prescribed initialization and pass calls. Observe each original call once and return its unchanged output; never draw a second value for logging. `get_state`/copy operations are allowed; independent post-run RNG replays or restorative random-draw tests are not part of this order.

### 6.2 Every capture pass: the actual update stages

Record the following for each completed pass, with incoming/outgoing indexing explicit:

1. Incoming X/R and the original incoming distances, adjacency, selected IDs and empty-row flags. Neighbor selection is from boundary `p-1`; the radius is strict `<6`, capped at five, self excluded. The later `np.where` traversal is ascending ID order.
2. The computed local `lap` and post-local positions Y. This first movement is simultaneous; it must not start reading earlier changed rows.
3. Post-frequency-coupling amplitudes B, the H factor, and post-H/pre-fusion amplitudes Q. Retain normalization-guard flags/weights where observed without recomputing or altering the update. The two normalization stages and the strict `>1e-10` guard remain unchanged.
4. For **each fusion row in ascending ID order**: selected neighbor IDs, their coordinate values as actually read, their fixed Q weights, the local center actually evaluated, the target point before/after its write, and whether the row was skipped. Use a validity mask for empty rows rather than a fake zero-valued center. There are 24,000 row visits over a complete capture, not 24,000 additional pass calls.
5. The full post-fusion positions, selected L, pre/post-compression amplitudes and lower/upper clipping flags. Define clipping flags from the actual log magnitude and limits; distinguish a zero input from a nonzero value raised to the lower floor.
6. The actual 120×3 noise array returned by the original call, its scale, RNG checkpoints immediately before/after that call, and completed X/R/V.
7. The actual original observer row. Capture the average-linkage cluster membership when it is already computed inside `_record`; observing it must not feed back into the next step.

The finite-horizon fusion center excludes self, has amplitude-magnitude weights plus `1e-8`, and has **no inverse-distance weight**. It reads post-local/currently overwritten coordinates, retains incoming selections, and uses Q unchanged across the loop. Compression follows the loop. Do not substitute final compressed R or rebuild neighbors during fusion.

Logging all stages is practical at this bounded size and avoids needing another run merely to explain an interesting episode. Saving an actual intermediate is authorized; creating an alternate intermediate through a changed update is not.

## 7. Verification policy fixed before execution

### 7.1 Capture fidelity: strict gate

For reference versus capture in the same environment require **bit-for-bit identity**, not a tolerance, for every saved boundary's X/R/V, frequencies, pass/configuration and deterministic post-seed RNG checkpoints. Compare dtype, shape and raw numerical bytes, including signed zeros. Compare original metric keys, integer values and floating bit patterns at every row; report CSV byte identity separately from numeric identity.

Reference/capture equality establishes noninterference of the recorder and repeatability of this one implementation. It is not independent validation of the mathematical model. Source/AST identity, stage records and independent passive readback supply separate evidence.

Verify 201 contiguous boundaries, 200 metric rows, 120 unique point IDs per boundary, array shapes, finiteness, fixed frequencies and the exact displacement identity `V[p] = X[p]-X[p-1]`. Verify noise/stage bookkeeping from captured values; do not draw the noise again. Reconstructing observations from stored arrays is permitted. No `evolve_pass` call, propagated successor or alternate-order stage is permitted in a checker.

If state/RNG/metric equality fails, preserve the first discrepancy and all usable records. **Do not accept the capture as source-faithful or run again.** Return the failure for GPT review. No environment change, tolerance relaxation or seed adjustment can repair that strict gate within this order.

### 7.2 Original CSV attribution: separate historical comparison

Compare only with `originals/full_universe.csv`, rows 1–200. Do not compare state 0 with a nonexistent historical initial row. Expected columns, in order:

```text
pass,R_max,R_min,R_mean,R_std,n_resonance_clusters,n_spatial_clusters,
entropy,mean_grf,top_seed_id,L_effective,
band_0.1508,band_0.2440,band_0.3948,band_0.6388
```

- Exact schema, pass labels and integer-valued fields: `pass`, `n_resonance_clusters`, `n_spatial_clusters`, `top_seed_id` — **800 integer cells**, including 200 pass labels.
- Eleven continuous columns — **2,200 floating cells** — use the predeclared criterion:

```text
abs(replay - historical) <= 1e-12 + 1e-10 * abs(historical)
```

- Report exact parsed equality and near equality separately, per column, with maximum absolute/relative discrepancies and the worst pass. For a historical zero, report the absolute discrepancy and define the relative statistic explicitly rather than silently dividing by zero.
- Denominators: **3,000 total cells; 2,800 non-pass metrics = 600 integer metrics + 2,200 floating metrics**. Do not call the pass column a scientific metric. Any missing/nonfinite value or schema mismatch must be reported.

These are comparison criteria, not a claimed tolerance of the unknown historical environment. Keep the original CSV bytes and exact exported replay CSV. Text serialization differences are separate from numerical differences. An argmax/count mismatch is still a mismatch even when other floats are close; report near ties without changing the criterion.

If this historical comparison fails while reference/capture fidelity passes, preserve and describe the valid source-faithful replay with an explicit historical mismatch. Do not silently identify it with the old trajectory or spend another run seeking agreement. The selected finite replay can still be reviewed on its own evidence.

**Even complete aggregate agreement does not recover the original coordinates, original environment or original RNG provenance.** Label all newly captured trajectories `REPRODUCED` throughout.

## 8. Bounded motion and mechanism analysis

Analyze the captured arrays only after the fidelity gate. Aim for an ordinary-language explanation supported by a few inspectable episodes, not a new theoretical program.

### A. Distinguish the different groupings

Keep four structures separate:

1. Six **supplied population blocks**, fixed IDs `0–19`, `20–39`, ..., `100–119`.
2. Fixed **assigned frequency labels** and their actual, potentially unequal counts.
3. The source's directed **horizon/nearest-five interaction graph**, including weak and strong components, empty rows and membership changes.
4. The observer's **average-linkage groups at distance 2.0**, evaluated on completed positions.

At selected boundaries compare these memberships directly, rather than equating counts. Canonicalize partitions by their member sets before comparing times; a changed arbitrary cluster label is not a membership change. Check whether the historical table's stable ten-group count, if reproduced, conceals changing membership or movement. Ten groups, six populations and four frequencies are different definitions; none is a success target.

Tag a graph built at boundary p as supplying pass p+1; the pass-200 graph has no executed successor. The capture has 200 incoming graphs and 201 position boundaries. An optional boundary-200 graph is a passive description, never a hidden pass 201. Initial-state offline observer values must not be inserted into the historical 200-row table.

### B. Explain the actual ordered reads, without a counterfactual

Select up to three representative pass windows from the captured chronology and identify stable IDs. Show which earlier neighbor writes a later row actually reads, using the recorded coordinates, Q weights and centers. Record the magnitude of those earlier positional changes and their weighted contribution to the center being read.

If useful, the exact-arithmetic accounting is `sum_j a_ij * (Z_read[j] - Y[j])`, where `a_ij=(abs(Q_j)+1e-8)/sum_{k in N_i}(abs(Q_k)+1e-8)`. This describes the center contribution of already realized writes relative to that pass's post-local coordinates; it does **not** evaluate an alternate movement law or a reordered trajectory. Show finite-arithmetic residuals separately when applying this accounting.

A dependency or changed read is not a measured causal effect of swapping row order. Do not assert how much a simultaneous/reversed system would differ: neither is run here. If all relevant increments happen to vanish in a selected episode, report that rather than manufacturing an order effect.

Check direct cross-population selections and their persistence. A finite-horizon branch has no additional global/band-center bridge for fixed selections, but supplied populations need not equal disconnected components. Common schedules and RNG bookkeeping are not an extra geometry-dependent force. Do not import Tower II's combined-connectivity result into this different program.

### C. Describe spatial motion and amplitude behavior

From saved coordinates measure whole-field and selected-group radius of gyration, diameter, arithmetic-center movement, within-group spread, step lengths and cumulative paths of a few stable IDs. Use true centered geometry. Keep the original flattened `np.std(pos_k)` print statistic as an original observer with its known limitation; label any proper geometric measurement as a new analysis of reproduced data, not a correction to the historical output.

Use 3D views to explain separation, regrouping and continuing motion, not to fit named solids. Near or overlapping markers do not merge point identities. Persisting membership does not imply a fixed geometry or convergence.

Relate amplitude levels and frequency labels to the actual recorded local exchanges. Retain signed R as well as magnitude summaries; do not infer positivity only from a positive minimum magnitude. Report actual clipping activation along this replay. Activity/inactivity here is not an ablation result or a retroactive explanation of the different historical static/breathing driver.

The stage analysis and original endpoint printout must not promote the source labels `SEPARATE`, `MERGED`, “independent,” “condensate,” or “living” into physical results. Explain their operational definitions when relevant.

## 9. Visual deliverables

Provide **four to six readable static figures**, each with plotted-data files and a figure register:

- Whole-field 3D snapshots with fixed world scale and equal axis aspect, showing the six supplied populations and retaining stable identities.
- Group-membership comparison between supplied populations, assigned frequencies, interaction components and the original spatial observer.
- Close views/paths for the selected episodes, including an ordered local-center read/write example from actual captured operands.
- Geometry/movement and historical-metric comparison sufficient to orient the reader.

Use labels, distinct marker styles or documented colors consistently. Clearly distinguish world units from centered/rescaled close views. Prefer fixed orientation; disclose any alignment or scaling. No fabricated surfaces, interpolation presented as sampled dynamics, or automatic shape classification. Include the pass window, IDs and data class in every caption.

A short animation is optional only if it helps explain already captured motion. Render it from saved frames; no callbacks may advance the engine. Static frames and numeric records remain the review evidence. There is no requirement to produce a new movie, PDF or paper to complete this assignment.

## 10. Review package

Return `SRG_SIMULATION_STUDY_07_UNIVERSE_REPLAY_01_REVIEW.zip` with a separately accessible `START_HERE.md` and external `REVIEW_ZIP_IDENTITY.json`.

Required narrative documents:

1. `START_HERE.md`: plain-language account for Hilmir, actual findings, historical comparison outcome, and stop status.
2. `REPLAY_FIDELITY_AND_PROVENANCE.md`: exact source extraction, initialization, environment, run budget, reference/capture equality and historical attribution limits.
3. `MOTION_AND_GROUPS.md`: inspectable trajectory, four grouping definitions and a few stable-ID episodes.
4. `ORDERED_FUSION_TRACE.md`: actual read/write examples and source-supported interpretation; no reordered control claimed.
5. `VERIFICATION_AND_LIMITS.md`: machine-readable check pointers, first discrepancies if any, protected inputs and remaining limits.

Include the frozen run specification, immutable original source and CSV, acceptance/context index, extracted reference core, documented capture instrumentation/diff, all execution/call-budget receipts, complete reference/capture states and RNG checkpoints, stage/actual-noise records, original observer outputs, passive analyses and their source, figures and plotted values. Keep methods and records separate. Provide a record schema explaining pass indexing, units, shapes, dtypes, skip masks and categorical identities.

Include scoped input/preservation manifests and a payload manifest with all files accounted for. The final ZIP's own identity must be supplied **outside the ZIP** to avoid circular hashing; the included guide must explain that external status rather than link misleadingly to a missing internal file. Do not include temporary renders, interpreter caches or irrelevant archive families.

## 11. Completion and stop

Successful completion requires the original hashes to match, strict reference/capture fidelity, a complete 201-boundary/200-update capture, a separately stated original-CSV comparison, readable movement/ordered-read evidence, a fully accounted execution budget, and unchanged protected inputs. A documented historical mismatch is a research outcome, not authority to modify the model.

A source mismatch, unsafe output path, exhausted/uncertain budget, nonfinite state, failed capture fidelity or failed execution yields a bounded blocker report with preserved partial records. Do not launch another attempt. Hashes establish byte preservation, not absence of execution; keep action attestations and receipts separate.

**STOP after returning this one Universe replay for GPT and Hilmir review.** Do not move to `srg_breathing_collision.py`, draft a new volume, change a ledger or publish anything. The agreed outer direction remains: understand this original Universe construction, then consider the separately ordered field-merger construction, then synthesis/paper decision. This work order authorizes only the missing-motion step for SIM07.

## Source basis

- Original program: [exact source](originals/srg_condensate_breaking.py), especially 42–54, 60–266 and 663–758.
- Original comparison data: [full_universe.csv](originals/full_universe.csv).
- Accepted review: [SIM07 GPT scientific review](context/SIM07_GPT_SCIENTIFIC_REVIEW.md), especially §§4–5 and §10.
- Original proposal: [REPLAY_DECISION_NOTE.md](context/REPLAY_DECISION_NOTE.md), retained as proposal-era evidence; this order provides the subsequent bounded authority.
- Full unmodified source/evidence/review corpus: [accepted input archive](inputs/SIM07_UNIVERSE_GPT_REVIEW_AND_ACCEPTANCE.zip).

This handoff specifies work for Codex. No simulation, initialization, RNG draw/restoration or Codex execution was performed to prepare it.
