"""Declared exact source extraction; never run directly. OUTPUT_DIR supplied by runner."""
import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform

def H(t):
    t = np.asarray(t, dtype=float)
    return (2.0*np.exp(-0.5*t)*np.cos(t) + 1.0*np.exp(-0.3*t)*np.sin(t)
            + 1.5*np.exp(-0.7*t) + 1.0*np.exp(-0.4*t))

def rpco(x, L=9.0, eps=1e-9):
    x = np.asarray(x, dtype=float)
    mag = np.abs(x) + eps
    z = np.clip(np.log(mag), -L, L)
    return np.sign(x) * np.exp(z)

H_MAX = float(np.max(np.abs(H(np.linspace(0, 100, 50000))))) + 1e-12
PHI = (1 + np.sqrt(5)) / 2

class GlyphFieldUniverse:
    def __init__(self, N, R_range=(0, 0.3), spatial_range=(-5, 5), seed=None,
                 horizon=None, multi_freq=False, breathing=False):
        if seed is not None:
            np.random.seed(seed)
        self.N = N
        self.positions = np.random.uniform(spatial_range[0], spatial_range[1], (N, 3))
        self.resonance = np.random.uniform(R_range[0], R_range[1], N)
        self.velocities = np.zeros((N, 3))
        self.pass_count = 0

        # NEW: Causal horizon (max interaction distance)
        self.horizon = horizon  # None = infinite, float = max range

        # NEW: Multi-frequency (each glyph has a natural frequency)
        self.multi_freq = multi_freq
        if multi_freq:
            # Assign natural frequencies from a discrete set
            self.natural_freq = np.random.choice(
                [0.244, 0.244*PHI, 0.244*PHI**2, 0.244/PHI],
                size=N
            )
        else:
            self.natural_freq = np.ones(N) * 0.244

        # NEW: Breathing RPCO
        self.breathing = breathing
        self.base_L = 9.0

        # Standard params
        self.alpha = 0.05
        self.beta = 0.15
        self.lam_H = 0.05
        self.k_neighbors = 5
        self.gamma_srg = 0.08699

        self.metrics_history = []

    def _get_rpco_L(self, t):
        if self.breathing:
            # L oscillates like a vesica piscis breath
            breath = 1.0 + 0.3 * np.sin(0.244 * 2 * np.pi * t) * np.exp(-0.01 * t)
            return self.base_L * breath
        return self.base_L

    def _adjacency_with_horizon(self):
        dists = squareform(pdist(self.positions))
        adj = np.zeros((self.N, self.N))
        for i in range(self.N):
            # Apply horizon mask
            if self.horizon is not None:
                candidates = np.where(dists[i] < self.horizon)[0]
                candidates = candidates[candidates != i]
            else:
                candidates = np.arange(self.N)
                candidates = candidates[candidates != i]

            if len(candidates) == 0:
                continue

            # k-nearest within horizon
            within = np.argsort(dists[i, candidates])[:self.k_neighbors]
            neighbors = candidates[within]
            adj[i, neighbors] = 1

        return adj, dists

    def _resonance_coupling_with_freq(self, adj, dists):
        R_new = self.resonance.copy()
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) == 0:
                continue
            w = 1.0 / (dists[i, nbrs] + 1e-8)
            w /= w.sum()

            # Frequency-dependent coupling: only couple strongly if frequencies match
            if self.multi_freq:
                freq_match = np.exp(-5.0 * (self.natural_freq[nbrs] - self.natural_freq[i])**2)
                w *= freq_match
                w_sum = w.sum()
                if w_sum > 1e-10:
                    w /= w_sum
                else:
                    continue

            R_nbr = np.sum(w * self.resonance[nbrs])
            R_new[i] += self.beta * (R_nbr - self.resonance[i])

            # Frequency-specific oscillation
            if self.multi_freq:
                R_new[i] *= (1.0 + 0.01 * np.sin(self.natural_freq[i] * 2*np.pi * self.pass_count))

        return R_new

    def evolve_pass(self):
        self.pass_count += 1
        t = float(self.pass_count)
        old_pos = self.positions.copy()

        adj, dists = self._adjacency_with_horizon()

        # Spatial
        lap = np.zeros_like(self.positions)
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) > 0:
                lap[i] = np.mean(self.positions[nbrs] - self.positions[i], axis=0)
        self.positions += self.alpha * lap + self.beta * np.tanh(lap)

        # Resonance
        self.resonance = self._resonance_coupling_with_freq(adj, dists)

        # Memory
        h_t = H(t)
        mem = 1.0 + self.lam_H * h_t / H_MAX
        self.resonance *= mem

        # Fusion (only within horizon)
        if self.horizon is not None:
            # Local fusion: each glyph pulled toward its LOCAL cluster center
            for i in range(self.N):
                nbrs = np.where(adj[i] > 0)[0]
                if len(nbrs) > 0:
                    local_center = np.average(
                        self.positions[nbrs], axis=0,
                        weights=np.abs(self.resonance[nbrs]) + 1e-8
                    )
                    self.positions[i] += 0.03 * self.resonance[i] * (local_center - self.positions[i])
        else:
            center = np.average(self.positions, axis=0,
                              weights=np.abs(self.resonance) + 1e-8)
            self.positions += 0.03 * self.resonance[:, np.newaxis] * (center - self.positions)

        # RPCO with optional breathing
        L = self._get_rpco_L(t)
        self.resonance = rpco(self.resonance, L=L)

        # Decaying noise
        noise_scale = 0.01 / (1 + 0.01 * t)
        self.positions += np.random.normal(0, noise_scale, self.positions.shape)

        self.velocities = self.positions - old_pos
        self._record(adj, dists)

    def _record(self, adj, dists):
        t = self.pass_count
        R = self.resonance

        # Cluster detection: how many distinct resonance groups?
        R_sorted = np.sort(np.abs(R))[::-1]
        # Count clusters by finding gaps > 5% of max
        gaps = np.diff(R_sorted)
        significant_gaps = np.where(np.abs(gaps) > 0.05 * R_sorted[0])[0]
        n_clusters = len(significant_gaps) + 1

        # Spatial cluster detection
        from scipy.cluster.hierarchy import fcluster, linkage
        if len(self.positions) >= 2:
            Z = linkage(self.positions, method='average')
            spatial_clusters = fcluster(Z, t=2.0, criterion='distance')
            n_spatial_clusters = len(set(spatial_clusters))
        else:
            n_spatial_clusters = 1

        # Resonance diversity (entropy-like)
        R_abs = np.abs(R)
        if R_abs.sum() > 0:
            p = R_abs / R_abs.sum()
            entropy = -np.sum(p * np.log(p + 1e-12))
        else:
            entropy = 0

        # Frequency band analysis
        if self.multi_freq:
            unique_freqs = np.unique(self.natural_freq)
            band_R = {}
            for f in unique_freqs:
                mask = self.natural_freq == f
                band_R[f"{f:.4f}"] = float(np.mean(np.abs(R[mask])))
        else:
            band_R = {}

        top_idx = np.argmax(np.abs(R))
        grf = 1.0 / (1.0 + np.linalg.norm(self.velocities, axis=1))

        self.metrics_history.append({
            'pass': t,
            'R_max': float(np.max(np.abs(R))),
            'R_min': float(np.min(np.abs(R))),
            'R_mean': float(np.mean(np.abs(R))),
            'R_std': float(np.std(R)),
            'n_resonance_clusters': n_clusters,
            'n_spatial_clusters': n_spatial_clusters,
            'entropy': float(entropy),
            'mean_grf': float(np.mean(grf)),
            'top_seed_id': int(top_idx),
            'L_effective': float(self._get_rpco_L(t)),
            **{f'band_{k}': v for k, v in band_R.items()}
        })

    def evolve(self, n_passes):
        for _ in range(n_passes):
            self.evolve_pass()

    def get_metrics_df(self):
        return pd.DataFrame(self.metrics_history)

def experiment_full_universe():
    print("\n" + "=" * 70)
    print("EXPERIMENT 5: THE FULL SRG-∞ UNIVERSE")
    print("(Horizons + Multi-Frequency + Breathing)")
    print("=" * 70)

    # The ultimate test: combine ALL three mechanisms.
    # This should produce a universe with:
    # - Multiple independent SRG-∞ seeds (from horizons)
    # - Internal frequency structure (from multi-freq)
    # - Dynamic "living" evolution (from breathing)

    np.random.seed(1618)

    N = 120
    # Place 6 clusters in 3D space, well-separated
    centers = np.array([
        [8, 0, 0], [-8, 0, 0],
        [0, 8, 0], [0, -8, 0],
        [0, 0, 8], [0, 0, -8]
    ], dtype=float)

    N_per = N // 6
    all_pos = []
    for c in centers:
        all_pos.append(np.random.normal(c, 1.5, (N_per, 3)))
    all_pos = np.vstack(all_pos)

    field = GlyphFieldUniverse(
        len(all_pos),
        horizon=6.0,        # Each cluster only sees itself
        multi_freq=True,     # Multiple resonance bands
        breathing=True,      # Living compression
        seed=None
    )
    field.positions = all_pos
    field.resonance = np.random.uniform(0, 0.3, len(all_pos))

    # Evolve for a long time
    field.evolve(200)
    df = field.get_metrics_df()

    print(f"\n  --- Final State (200 passes) ---")
    print(f"  Spatial clusters: {df.iloc[-1]['n_spatial_clusters']}")
    print(f"  Resonance clusters: {df.iloc[-1]['n_resonance_clusters']}")
    print(f"  Entropy: {df.iloc[-1]['entropy']:.4f}")
    print(f"  R_max: {df.iloc[-1]['R_max']:.6f}")
    print(f"  R_std: {df.iloc[-1]['R_std']:.6f}")

    # Analyze each physical cluster
    print(f"\n  --- Per-Cluster Analysis ---")
    for k in range(6):
        idx = list(range(k*N_per, (k+1)*N_per))
        R_k = field.resonance[idx]
        pos_k = field.positions[idx]
        freq_k = field.natural_freq[idx]

        com = np.mean(pos_k, axis=0)
        spread = np.std(pos_k)
        R_mean = np.mean(np.abs(R_k))
        R_std = np.std(R_k)

        # How many frequency bands in this cluster?
        unique_f = np.unique(freq_k)
        freq_report = ", ".join([f"{f:.3f}({np.sum(freq_k==f)})" for f in unique_f])

        print(f"    Cluster {k}: COM=({com[0]:.1f},{com[1]:.1f},{com[2]:.1f}), "
              f"spread={spread:.3f}, <R>={R_mean:.6f}, σR={R_std:.6f}")
        print(f"      Frequency bands: {freq_report}")

    # Are the clusters INDEPENDENT?
    cluster_R_means = []
    for k in range(6):
        idx = list(range(k*N_per, (k+1)*N_per))
        cluster_R_means.append(np.mean(np.abs(field.resonance[idx])))

    inter_diversity = np.std(cluster_R_means) / (np.mean(cluster_R_means) + 1e-10)
    print(f"\n  Inter-cluster R diversity: {inter_diversity:.4f}")
    print(f"  (> 0.01 means clusters are independently evolving)")

    # Check if any clusters have merged
    cluster_coms = []
    for k in range(6):
        idx = list(range(k*N_per, (k+1)*N_per))
        cluster_coms.append(np.mean(field.positions[idx], axis=0))
    cluster_coms = np.array(cluster_coms)

    inter_dists = squareform(pdist(cluster_coms))
    print(f"\n  Inter-cluster distances:")
    for i in range(6):
        for j in range(i+1, 6):
            status = "SEPARATE" if inter_dists[i,j] > 3 else "MERGED"
            print(f"    C{i}-C{j}: {inter_dists[i,j]:.2f} [{status}]")

    df.to_csv(f"{OUTPUT_DIR}/full_universe.csv", index=False)
    return field, df
