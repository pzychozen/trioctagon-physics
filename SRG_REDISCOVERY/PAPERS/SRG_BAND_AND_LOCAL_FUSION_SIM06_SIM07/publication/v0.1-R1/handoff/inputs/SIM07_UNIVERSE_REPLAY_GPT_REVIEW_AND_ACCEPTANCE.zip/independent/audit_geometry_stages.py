"""Independent saved-state geometry and conditional-operand audit; ZERO trajectory advancement.
No import of original or supplied executable methods, constructor, RNG call, or RNG restore.
Every equation check uses a stored incoming state or stored actual operands; no computed
successor is used in another row/pass. Observer clustering is rerun on fixed saved X only.
"""
from pathlib import Path
import collections,json,csv,math
import numpy as np
from scipy.spatial.distance import pdist
from scipy.sparse.csgraph import connected_components
from scipy.cluster.hierarchy import linkage,fcluster
S=Path(__file__).resolve().parents[1]/'source_package';O=Path(__file__).resolve().parent
errors=[];counts=collections.Counter();maxima={}
def ck(k,ok,detail=None):
 counts[k]+=1
 if not bool(ok):errors.append([k,detail])
def eq(k,a,b,detail=None):
 a,b=np.asarray(a),np.asarray(b);ck(k,a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes(),detail)
def cl(k,a,b,detail=None):
 a,b=np.asarray(a),np.asarray(b);d=float(np.max(np.abs(a-b))) if a.size else 0.;maxima[k]=max(maxima.get(k,0.),d)
 ck(k,a.shape==b.shape and np.all(np.isfinite(a)) and np.all(np.isfinite(b)) and np.allclose(a,b,atol=5e-13,rtol=5e-12),detail)
def nz(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def j(p):return json.loads(p.read_text())
def rng(k,a,pa,b,pb):
 for key in ['name','words','position','has_gauss','cached_gaussian']:eq(k,a[pa+key],b[pb+key])
def part(labels):return sorted([np.flatnonzero(labels==k).tolist() for k in np.unique(labels)],key=lambda g:g[0])
def geom(x):
 c=x.mean(axis=0);return c,float(np.sqrt(np.mean(np.sum((x-c)**2,axis=1)))),float(pdist(x).max())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def table(n,rows):
 with (O/n).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
bound=[nz(S/f'runs/B_CAPTURE/boundaries/boundary_{p:03}.npz') for p in range(201)]
X=np.stack([b['X'] for b in bound]);R=np.stack([b['R'] for b in bound]);V=np.stack([b['V'] for b in bound]);freq=bound[0]['frequencies'];pop=np.arange(120)//20
metrics=nz(S/'runs/B_CAPTURE/metrics.npz');Hmax=float(j(S/'runs/B_CAPTURE/RUN_RECEIPT.json')['H_MAX'])
graphs=[];parts=[];observers=[];cross=[];gcounts=[];readcounts=[];episodes=[];clip=collections.Counter();minmargin=math.inf;minQ=math.inf;minGuard=math.inf
for p in range(1,201):
 t=nz(S/f'runs/B_CAPTURE/stages/pass_{p:03}.npz');a=bound[p-1];b=bound[p];noise=nz(S/f'runs/B_CAPTURE/random/call_{p+10:03}_normal.npz')
 for k in ['X','R']:eq('incoming_state',t['incoming_'+k],a[k],[p,k])
 for k in ['X','R','V']:eq('completed_state',t['completed_'+k],b[k],[p,k])
 rng('pass_rng_before',t,'pass_before_',a,'rng_');rng('pass_rng_after',t,'pass_after_',b,'rng_');rng('noise_before',t,'noise_before_',noise,'before_');rng('noise_after',t,'noise_after_',noise,'after_');rng('incoming_rng_to_noise',t,'noise_before_',a,'rng_');rng('noise_to_completed_rng',t,'noise_after_',b,'rng_');eq('actual_noise_return',t['noise'],noise['value'],p)
 dx=a['X'][:,None,:]-a['X'][None,:,:];dist=np.sqrt(np.sum(dx*dx,axis=2));cl('distances',dist,t['distances'],p)
 adj=np.zeros((120,120),dtype=float)
 for i in range(120):
  cand=np.flatnonzero((dist[i]<6)&(np.arange(120)!=i));ids=cand[np.argsort(dist[i,cand])[:5]];adj[i,ids]=1
 eq('adjacency',adj,t['adjacency'],p);graphs.append(adj.astype(bool));nw,lw=connected_components(adj,directed=True,connection='weak');ns,ls=connected_components(adj,directed=True,connection='strong');parts.append(part(lw));gcounts.append({'pass':p,'incoming_boundary':p-1,'weak':int(nw),'strong':int(ns)})
 ii,jj=np.where(adj>0);cross.extend({'pass':p,'row':int(i),'neighbor':int(k),'distance':float(dist[i,k])} for i,k in zip(ii,jj) if pop[i]!=pop[k])
 eq('fusion_visit_order',t['fusion_visit_order'],np.arange(120,dtype=np.int64),p)
 n_early=n_late=0;contrib=[]
 for i in range(120):
  ids=np.flatnonzero(adj[i]);n=len(ids);ck('neighbor_count',int(t['neighbor_count'][i])==n and bool(t['empty_rows'][i])==(n==0),[p,i]);eq('fusion_ids',t['fusion_ids'][i,:n],ids,[p,i]);ck('fusion_valid',bool(t['fusion_valid'][i])==(n>0),[p,i])
  if not n:continue
  lap=np.mean(a['X'][ids]-a['X'][i],axis=0);cl('local_lap',lap,t['lap'][i],[p,i]);cl('local_X',a['X'][i]+.05*t['lap'][i]+.15*np.tanh(t['lap'][i]),t['Y'][i],[p,i])
  w=1/(dist[i,ids]+1e-8);w/=w.sum();factor=np.exp(-5*(freq[ids]-freq[i])**2);wp=w*factor;ww=wp/wp.sum();minGuard=min(minGuard,float(wp.sum()))
  for key,val in [('coupling_distance_weights',w),('coupling_frequency_factors',factor),('coupling_weighted_pre_guard',wp),('coupling_final_weights',ww)]:cl(key,val,t[key][i,:n],[p,i])
  cl('guard_sum',wp.sum(),t['coupling_weight_sum'][i],[p,i]);ck('guard',bool(t['coupling_guard_visited'][i]) and bool(t['coupling_guard_passed'][i])==(wp.sum()>1e-10) and bool(t['coupling_active'][i]),[p,i])
  rn=np.sum(ww*a['R'][ids]);cl('neighbor_R',rn,t['coupling_R_neighbor'][i],[p,i]);value=(a['R'][i]+.15*(rn-a['R'][i]))*(1+.01*np.sin(freq[i]*2*np.pi*p));cl('coupled_R',value,t['B'][i],[p,i]);eq('coupling_row_capture',t['B'][i],t['coupling_row_result'][i],[p,i])
  # GATHER actual recorded writes; do NOT evolve a working coordinate copy.
  reads=np.array([t['fusion_after'][k] if k<i else t['Y'][k] for k in ids]);eq('earlier_write_later_read',reads,t['fusion_reads'][i,:n],[p,i]);eq('own_row_still_Y',t['fusion_before'][i],t['Y'][i],[p,i]);eq('neighbor_Q',t['fusion_Q_neighbors'][i,:n],t['Q'][ids],[p,i]);eq('fusion_weights',t['fusion_weights'][i,:n],np.abs(t['Q'][ids])+1e-8,[p,i])
  fw=t['fusion_weights'][i,:n];actual=t['fusion_reads'][i,:n];center=np.sum(actual*fw[:,None],axis=0)/fw.sum();cl('fusion_center',center,t['fusion_center'][i],[p,i]);after=t['fusion_before'][i]+.03*t['Q'][i]*(t['fusion_center'][i]-t['fusion_before'][i]);cl('fusion_row_write',after,t['fusion_after'][i],[p,i])
  dr=actual-t['Y'][ids];d=np.sum(dr*(fw/fw.sum())[:,None],axis=0);n_early+=int(np.sum(ids<i));n_late+=int(np.sum(ids>i));contrib.append(float(np.linalg.norm(d)))
  if (p,i) in [(1,112),(16,6),(200,8)]:episodes.append({'pass':p,'row':i,'ids':ids.tolist(),'earlier_ids':ids[ids<i].tolist(),'actual_read_change_norms':np.linalg.norm(dr,axis=1).tolist(),'center':t['fusion_center'][i].tolist(),'center_contribution_from_realized_earlier_writes':d.tolist(),'actual_target_displacement':(t['fusion_after'][i]-t['fusion_before'][i]).tolist()})
 h=2*np.exp(-.5*p)*np.cos(float(p))+np.exp(-.3*p)*np.sin(float(p))+1.5*np.exp(-.7*p)+np.exp(-.4*p);cl('H',h,t['H'],p);cl('H_factor',1+.05*float(t['H'])/Hmax,t['H_factor'],p);cl('Q',t['B']*t['H_factor'],t['Q'],p);minQ=min(minQ,float(t['Q'].min()))
 eq('postfusion_Z',t['Z'],t['fusion_after'],p);eq('compression_input',t['pre_compression_R'],t['Q'],p);L=9*(1+.3*np.sin(.244*2*np.pi*p)*np.exp(-.01*p));cl('L',L,t['L'],p)
 log=np.log(np.abs(t['Q'])+1e-9);lo=log<-t['L'];hi=log>t['L'];minmargin=min(minmargin,float(np.min(log+t['L'])),float(np.min(t['L']-log)));eq('lower_flags',lo,t['clipping_lower'],p);eq('upper_flags',hi,t['clipping_upper'],p);clip['lower']+=int(lo.sum());clip['upper']+=int(hi.sum())
 cl('compressed_R',np.sign(t['Q'])*np.exp(np.clip(log,-float(t['L']),float(t['L']))),b['R'],p);cl('completed_X_from_recorded_noise',t['Z']+t['noise'],b['X'],p);cl('noise_scale',.01/(1+.01*p),t['noise_scale'],p)
 tree=linkage(b['X'],method='average');labels=fcluster(tree,t=2,criterion='distance');cl('observer_linkage',tree,t['observer_linkage'],p);ck('observer_partition',part(labels)==part(t['observer_membership']),p);observers.append(part(labels))
 ra=np.abs(b['R']);rs=np.sort(ra)[::-1];prob=ra/ra.sum();md={'pass':p,'R_max':ra.max(),'R_min':ra.min(),'R_mean':ra.mean(),'R_std':np.std(b['R']),'n_resonance_clusters':np.sum(np.abs(np.diff(rs))>.05*rs[0])+1,'n_spatial_clusters':len(np.unique(labels)),'entropy':-np.sum(prob*np.log(prob+1e-12)),'mean_grf':np.mean(1/(1+np.linalg.norm(b['V'],axis=1))),'top_seed_id':int(np.argmax(ra)),'L_effective':L,**{f'band_{f:.4f}':np.mean(ra[freq==f]) for f in np.unique(freq)}}
 for k,val in md.items():cl('observer_'+k,val,metrics[k][p-1],[p,k])
 readcounts.append({'pass':p,'earlier_reads':n_early,'later_reads':n_late,'nonzero_earlier_center_contributions':sum(v>0 for v in contrib),'max_contribution_norm':max(contrib)})
 if p%50==0:print('Saved records checked through pass',p,flush=True)
steps=np.linalg.norm(np.diff(X,axis=0),axis=2);paths=steps.sum(axis=0);changes=[p for p in range(2,201) if observers[p-1]!=observers[p-2]]
facts={'record_counts':{'boundaries':201,'point_states':24120,'displacement_components':72000,'fusion_row_visits':24000,'neighbor_edge_visits':sum(int(a.sum()) for a in graphs)},'observer':{'partition_last_changed_at':max(changes),'stable_observations':201-max(changes),'sizes':[len(g) for g in observers[-1]],'final_members':observers[-1],'mixed_populations':any(len(set(pop[g]))>1 for g in observers[-1])},'graphs':{'weak_range':[min(g['weak'] for g in gcounts),max(g['weak'] for g in gcounts)],'strong_range':[min(g['strong'] for g in gcounts),max(g['strong'] for g in gcounts)],'final_incoming':gcounts[-1],'changed_binary_entries':sum(int(np.count_nonzero(a!=b)) for a,b in zip(graphs,graphs[1:])),'last_changed_entries':int(np.count_nonzero(graphs[-1]!=graphs[-2]))},'cross_population':{'visits':len(cross),'pairs':[{'row':i,'neighbor':k,'passes':[e['pass'] for e in cross if e['row']==i and e['neighbor']==k]} for i,k in sorted(set((e['row'],e['neighbor']) for e in cross))]},'movement':{'final_mean_step':float(steps[-1].mean()),'final_max_step':float(steps[-1].max()),'final_min_step':float(steps[-1].min()),'positive_final_steps':int(np.sum(steps[-1]>0)),'mean_path':float(paths.mean()),'longest_path_id':int(paths.argmax()),'longest_path':float(paths.max()),'late_mean_step_151_200':float(steps[150:].mean())},'clipping':{'lower':clip['lower'],'upper':clip['upper'],'smallest_log_margin':minmargin,'minimum_Q':minQ,'minimum_guard_sum':minGuard,'saved_R_min':float(R.min()),'saved_R_max':float(R.max())},'ordered_examples':episodes,'ordered_reads':{'earlier':sum(r['earlier_reads'] for r in readcounts),'later':sum(r['later_reads'] for r in readcounts),'nonzero_center_contributions':sum(r['nonzero_earlier_center_contributions'] for r in readcounts)}}
facts['geometry']={}
for p in [0,16,50,199,200]:
 c,rg,di=geom(X[p]);facts['geometry'][str(p)]={'center':c.tolist(),'Rg':rg,'diameter':di}
facts['populations_final']=[]
for k in range(6):
 ids=np.flatnonzero(pop==k);c,rg,di=geom(X[200,ids]);flat=float(np.std(X[200,ids]));rhs=rg**2/3+float(np.mean((c-c.mean())**2));cl('flattened_std_identity',flat**2,rhs,k)
 facts['populations_final'].append({'population':k,'Rg':rg,'diameter':di,'flattened_std':flat,'observer_sizes':sorted(len(g) for g in observers[-1] if pop[g[0]]==k)})
same=[]
for b in [16,50,199]:
 obs=observers[b-1];weak=parts[b];omap={i:k for k,g in enumerate(obs) for i in g};same.append({'boundary':b,'observer_count':len(obs),'weak_count':len(weak),'weak_spanning_observer_groups':[g for g in weak if len({omap[i] for i in g})>1],'observer_to_weak':[{'ids':g,'weak_components_touched':[w for w in weak if set(w)&set(g)]} for g in obs]})
facts['same_boundary_partitions']=same;depart=[]
for i,k in sorted(set((e['row'],e['neighbor']) for e in cross)):
 last=max(e['pass'] for e in cross if e['row']==i and e['neighbor']==k);t=nz(S/f'runs/B_CAPTURE/stages/pass_{last+1:03}.npz');d=t['distances'][i,k];ids=np.flatnonzero(t['adjacency'][i]);depart.append({'row':i,'neighbor':k,'last_selected_pass':last,'next_pass':last+1,'distance_on_departure':float(d),'inside_horizon':bool(d<6),'selected_ids':ids.tolist(),'farthest_selected_distance':float(t['distances'][i,ids].max())})
facts['cross_selection_departure']=depart
ms=j(S/'analysis/MOTION_SUMMARY.json');ck('submitted_edge_changes',facts['graphs']['changed_binary_entries']==ms['graph_directed_edges_changed_total']);ck('submitted_cross_visits',len(cross)==ms['cross_population_selection_visits'])
for q in ms['geometry_selected']:
 p=q['boundary'];c,rg,di=geom(X[p]);cl('submitted_Rg',rg,q['radius_of_gyration'],p);cl('submitted_diameter',di,q['diameter'],p)
save('FINDINGS.json',facts);table('GRAPH_COUNTS.csv',gcounts);table('ORDERED_READ_COUNTS.csv',readcounts)
result={'status':'PASS' if not errors else 'FAIL','errors':errors,'checks':dict(counts),'max_absolute_errors':maxima,'scope':{'state_updates':0,'constructors':0,'RNG_draws':0,'RNG_restores':0,'original_or_submitted_verifier_imports':0,'fresh_fixed_record_observer_and_graph_measurements':True,'note':'Conditional expressions use saved independent inputs and actual operands. No computed successor is propagated. All 200 observer clusterings were recomputed on fixed saved coordinates.'}}
save('GEOMETRY_STAGE_VERIFICATION.json',result)
print(json.dumps({'status':result['status'],'errors':errors[:20],'check_calls':sum(counts.values()),'max_errors':maxima,'movement':facts['movement'],'graphs':facts['graphs'],'departures':depart,'ordered_reads':facts['ordered_reads']},indent=2))
