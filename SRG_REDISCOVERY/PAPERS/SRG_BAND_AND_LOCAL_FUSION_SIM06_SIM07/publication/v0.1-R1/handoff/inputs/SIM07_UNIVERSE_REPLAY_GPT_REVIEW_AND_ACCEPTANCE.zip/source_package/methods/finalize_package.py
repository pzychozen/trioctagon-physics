"""Final passive preservation, link/data readback and exact ZIP packaging; no engine."""
from pathlib import Path
from datetime import datetime, timezone
import ast, csv, hashlib, json, re, zipfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
ZIPNAME='SRG_SIMULATION_STUDY_07_UNIVERSE_REPLAY_01_REVIEW.zip'
assert not (ROOT/ZIPNAME).exists(),'Do not replace an already issued package'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p): return {'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(n,x): (ROOT/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def load(p):
    with np.load(p,allow_pickle=False) as f: return {k:f[k] for k in f.files}
baseline=json.loads((ROOT/'INPUT_BASELINE.json').read_text())
preserved=[]
for e in baseline['protected_files']:
    p=Path(e['path']); assert p.exists() and p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],e['path']
    preserved.append({**e,'unchanged':True})
construction=ROOT.parent/'CONSTRUCTION_01'
expected={str(Path(e['path'])) for e in baseline['protected_files'] if Path(e['path']).is_relative_to(construction)}
actual={str(p) for p in construction.rglob('*') if p.is_file()}
assert expected==actual,'Accepted construction fileset changed'
handoff=json.loads((ROOT/'handoff/HANDOFF_MANIFEST.json').read_text())
for e in handoff['files']:
    p=ROOT/'handoff'/e['path']; assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],e['path']
pref=json.loads((ROOT/'PREFLIGHT.json').read_text())
for e in pref['frozen_methods']:
    assert (ROOT/e['path']).stat().st_size==e['bytes'] and sha(ROOT/e['path'])==e['sha256'],e['path']
save('PRESERVATION_RECEIPT.json',{'checked_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','protected_files':preserved,'protected_file_count':len(preserved),'accepted_construction_fileset_unchanged':True,'handoff_payloads_unchanged':len(handoff['files']),'pre_execution_frozen_methods_and_inputs_unchanged':len(pref['frozen_methods']),'scope':'Entire pre-existing CONSTRUCTION_01 and actual external handoff ZIP; supplied handoff payloads and pre-execution method files separately verified','hashes_are_not_nonexecution_proof':True})
fid=json.loads((ROOT/'analysis/FIDELITY_VERIFICATION.json').read_text()); hc=json.loads((ROOT/'analysis/HISTORICAL_COMPARISON.json').read_text()); sup=json.loads((ROOT/'analysis/SUPPLEMENTAL_READBACK.json').read_text())
assert fid['status']=='PASS' and hc['status']=='PASS' and sup['status']=='PASS'
assert sup['observer_columns_checked']==12 and sup['observer_cells_checked']==2400
events=[json.loads(l) for l in (ROOT/'CALL_BUDGET.jsonl').read_text().splitlines()]
assert sum(e['event']=='initialization_entry' for e in events)==2
assert sum(e['event']=='step_entry' for e in events)==400
assert sum(e['event']=='step_completed' for e in events)==400
assert not any(e['event'] in ['run_failed','step_failed'] for e in events)
random_counts={}
for run in ['A_REFERENCE','B_CAPTURE']:
    calls=json.loads((ROOT/'runs'/run/'random/CALLS.json').read_text()); random_counts[run]={'seed_calls':sum(c['kind']=='seed' for c in calls),'value_returning_calls':sum(c['has_value'] for c in calls)}
    assert random_counts[run]=={'seed_calls':1,'value_returning_calls':210}
    process=json.loads((ROOT/f'PROCESS_{run}.json').read_text()); assert process['exit_code']==0
    assert (ROOT/f'{run}_STDERR.txt').stat().st_size==0
    # Complete readable state companion, checked from saved arrays without advancing.
    with (ROOT/'runs'/run/'point_states.csv').open(newline='',encoding='utf-8') as f:
        rr=csv.DictReader(f); count=0; previous_b=None; state=None
        for row in rr:
            b=int(row['boundary']); i=int(row['id'])
            assert count==b*120+i and int(row['population'])==i//20
            if b!=previous_b: state=load(ROOT/'runs'/run/'boundaries'/f'boundary_{b:03}.npz'); previous_b=b
            recovered=np.array([float(row[k]) for k in ['frequency','x','y','z','R_signed','vx','vy','vz']],dtype=np.float64)
            original=np.array([state['frequencies'][i],*state['X'][i],state['R'][i],*state['V'][i]],dtype=np.float64)
            assert recovered.tobytes()==original.tobytes()
            count+=1
        assert count==24120
save('EXECUTION_BUDGET_SUMMARY.json',{'initializations':2,'attempted_updates':400,'completed_updates':400,'failed_updates':0,'retries':0,'runs':fid['budget'],'random_interface_counts':random_counts,'additional_engine_calls_from_analysis':0,'additional_rng_draws_or_restorations_from_analysis':0,'note':'Interface-call counts are not underlying generator-word counts; two matched recordings are one setting, not independent trials.'})
execution_files=[info(p) for p in sorted((ROOT/'runs').rglob('*')) if p.is_file()]
save('EXECUTION_RECORD_MANIFEST.json',{'files':execution_files,'includes':'Complete boundary/stage/random records, original metrics and exports, configurations, receipts and passive readable state companions'})
schema={}
for name,rel in [('boundary','runs/B_CAPTURE/boundaries/boundary_000.npz'),('stage','runs/B_CAPTURE/stages/pass_001.npz'),('rng_initialization','runs/B_CAPTURE/random/call_001_normal.npz'),('metrics','runs/B_CAPTURE/metrics.npz')]:
    schema[name]={'example_file':rel,'arrays':{k:{'shape':list(v.shape),'dtype':v.dtype.str,'bytes':v.nbytes} for k,v in load(ROOT/rel).items()}}
save('ARRAY_SCHEMA_OBSERVED.json',schema)
required=['START_HERE.md','REPLAY_FIDELITY_AND_PROVENANCE.md','MOTION_AND_GROUPS.md','ORDERED_FUSION_TRACE.md','VERIFICATION_AND_LIMITS.md','RECORD_SCHEMA.md','CONTEXT_INDEX.md','ACTION_RECORD.md','HISTORICAL_COMPARISON_TABLE.md']
links=[]
for filename in required:
    s=(ROOT/filename).read_text(encoding='utf-8')
    for m in re.finditer(r'!?\[[^\]]*\]\(([^)]+)\)',s):
        target=m.group(1).split('#')[0]
        if not target or '://' in target: continue
        path=(ROOT/target).resolve()
        assert path.is_relative_to(ROOT) and (path.exists() or target=='MANIFEST.json'),(filename,target)
        links.append({'document':filename,'target':target})
syntax=[]
for p in sorted((ROOT/'methods').glob('*.py')):
    compile(p.read_text(encoding='utf-8'),str(p),'exec'); syntax.append(p.relative_to(ROOT).as_posix())
visual=json.loads((ROOT/'VISUAL_INSPECTION.json').read_text())
assert len(visual['figures'])==6
for e in visual['figures']: assert sha(ROOT/e['path'])==e['sha256']
figs=json.loads((ROOT/'FIGURE_REGISTER.json').read_text())
for e in figs:
    for rel in e['plotted_data']: assert (ROOT/rel).exists(),rel
save('DOCUMENT_AND_PACKAGE_QA.json',{'status':'PASS','new_document_links_checked':len(links),'links':links,'syntax_files':syntax,'complete_state_companion_rows_verified':48240,'state_companion_float_bits_match_binary':True,'figure_payloads_match_visual_receipt':6,'required_documents':required,'inherited_context_links':'Unchanged and explicitly indexed to enclosed archive; not rewritten','first_discrepancy':None})
excluded={ZIPNAME,'REVIEW_ZIP_IDENTITY.json','MANIFEST.json'}
excluded_files=[]; payload=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file(): continue
    rel=p.relative_to(ROOT).as_posix()
    if rel in excluded: continue
    if 'render_cache' in p.relative_to(ROOT).parts or '__pycache__' in p.relative_to(ROOT).parts or p.suffix=='.pyc':
        excluded_files.append({'path':rel,'reason':'Non-evidence renderer/interpreter cache, excluded from review ZIP'}); continue
    payload.append(info(p))
manifest={'assignment':'SRG_SIM07_UNIVERSE_REPLAY_01','date':'2026-10-25','scope':'Every review payload except this manifest and external ZIP identity; archive itself excluded','files':payload,'payload_count':len(payload),'payload_bytes':sum(e['bytes'] for e in payload),'excluded_local_files':excluded_files}
save('MANIFEST.json',manifest)
for e in links: assert (ROOT/e['target']).exists(),e
with zipfile.ZipFile(ROOT/ZIPNAME,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for e in payload: z.write(ROOT/e['path'],e['path'])
    z.write(ROOT/'MANIFEST.json','MANIFEST.json')
with zipfile.ZipFile(ROOT/ZIPNAME) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(payload)+1
    assert set(z.namelist())=={e['path'] for e in payload}|{'MANIFEST.json'}
    for e in payload:
        b=z.read(e['path']); assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],e['path']
    assert z.read('MANIFEST.json')==(ROOT/'MANIFEST.json').read_bytes()
identity={'zip_name':ZIPNAME,'bytes':(ROOT/ZIPNAME).stat().st_size,'sha256':sha(ROOT/ZIPNAME),'manifest_sha256':sha(ROOT/'MANIFEST.json'),'payload_files':len(payload),'zip_members':len(payload)+1,'fresh_zip_crc_and_all_member_identities':'PASS','state_fidelity':'PASS','historical_frozen_comparison':'PASS','preservation':'PASS','scientific_budget':{'initializations':2,'updates':400},'external_sidecar_not_inside_zip':True,'completed_utc':datetime.now(timezone.utc).isoformat(),'stop':'Returned for GPT and Hilmir review; no successor task or publication'}
save('REVIEW_ZIP_IDENTITY.json',identity)
print(json.dumps(identity,indent=2))
