"""Passive SIM07 intake; no scientific module imports or state execution."""
from pathlib import Path
import hashlib, json, zipfile, sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
ATTACHMENT = Path(r'C:\Users\Notandi\Downloads\SRG_SIM07_UNIVERSE_REPLAY_HANDOFF_20261025.zip')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p): return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
def save(n, obj):
    p=ROOT/n; p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists(): raise RuntimeError('Refusing overwrite: '+str(p))
    p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')

if (ROOT/'INPUT_BASELINE.json').exists(): raise RuntimeError('Already intaken; inspect receipts')
construction=ROOT.parent/'CONSTRUCTION_01'
baseline=[info(ATTACHMENT)]+[info(p) for p in sorted(construction.rglob('*')) if p.is_file()]
with zipfile.ZipFile(ATTACHMENT) as z:
    entries=[]
    for e in z.infolist():
        if e.is_dir(): continue
        dst=ROOT/'handoff'/e.filename
        if not dst.resolve().is_relative_to((ROOT/'handoff').resolve()): raise RuntimeError('Unsafe path')
        dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists(): raise RuntimeError('Exists')
        dst.write_bytes(z.read(e)); entries.append(info(dst))
save('INPUT_BASELINE.json',{'protected_files':baseline,'scope':'Entire accepted CONSTRUCTION_01 plus actual handoff ZIP; no repository-wide audit'})
save('INTAKE_RECEIPT.json',{'attachment':info(ATTACHMENT),'entries':entries})
for n in ['RUN_SPECIFICATION.json','HANDOFF_MANIFEST.json','INPUT_MANIFEST.json','context/GPT_ACCEPTANCE_RECEIPT.json','context/SIM07_GPT_SCIENTIFIC_REVIEW.md','context/CONSTRUCTION.md','context/README.md']:
    print('\nFILE: '+n+'\n'+(ROOT/'handoff'/n).read_text(encoding='utf-8-sig'))
print('SOURCE:')
for i,line in enumerate((ROOT/'handoff/originals/srg_condensate_breaking.py').read_text(encoding='utf-8-sig').splitlines(),1): print(f'{i:4}: {line}')
