"""Independent passive SIM07 archive/source/record audit. No source execution or RNG calls."""
from pathlib import Path
import ast,collections,csv,hashlib,json,zipfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'source_package';O=ROOT/'independent'
checks=collections.Counter();errors=[]
def ck(k,ok,detail=None):
 checks[k]+=1
 if not ok:errors.append([k,detail])
def eq(k,a,b,detail=None):
 a,b=np.asarray(a),np.asarray(b);ck(k,a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes(),detail)
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def nz(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def rng(k,a,pa,b,pb):
 for key in ['name','words','position','has_gauss','cached_gaussian']:eq(k,a[pa+key],b[pb+key],key)
def rows(p):
 with Path(p).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
p=Path('/mnt/data/SRG_SIMULATION_STUDY_07_UNIVERSE_REPLAY_01_REVIEW.zip');z=zipfile.ZipFile(p);m=j(S/'MANIFEST.json');side=j('/mnt/data/REVIEW_ZIP_IDENTITY(1).json')
ck('zip_identity',p.stat().st_size==side['bytes'] and sha(p.read_bytes())==side['sha256'])
ck('crc',z.testzip() is None);ck('unique_paths',len(z.namelist())==len(set(z.namelist())))
ck('manifest_identity',sha((S/'MANIFEST.json').read_bytes())==side['manifest_sha256'])
ck('membership',set(z.namelist())=={a['path'] for a in m['files']}|{'MANIFEST.json'})
for f in m['files']:
 b=(S/f['path']).read_bytes();ck('payload_hash_size',len(b)==f['bytes'] and sha(b)==f['sha256'],f['path'])
sp=j(S/'handoff/RUN_SPECIFICATION.json')
for key in ['source','historical_comparison']:
 a=sp[key];b=(S/'handoff'/a['file']).read_bytes();ck('original_identity',len(b)==a['bytes'] and sha(b)==a['sha256'],key)
prev=Path('/mnt/data/SIM07_UNIVERSE_GPT_REVIEW_AND_ACCEPTANCE.zip')
ck('accepted_input_unchanged',prev.read_bytes()==(S/'handoff/inputs'/prev.name).read_bytes())
with zipfile.ZipFile('/mnt/data/SRG_SIM07_UNIVERSE_REPLAY_HANDOFF_20261025.zip') as hz:
 for name in hz.namelist():
  if name.endswith('/'):continue
  q=S/'handoff'/name;ck('handoff_copy',q.exists() and q.read_bytes()==hz.read(name),name)
source=(S/'handoff/originals/srg_condensate_breaking.py').read_text();ref=(S/'methods/reference_core.py').read_text();cap=(S/'methods/capture_core.py').read_text()
stripped='\n'.join(l for l in cap.splitlines() if not l.lstrip().startswith('REC.'))+'\n'
ck('capture_strip_text',stripped==ref)
for name in ['H','rpco','GlyphFieldUniverse','experiment_full_universe']:
 a=next(n for n in ast.parse(source).body if getattr(n,'name',None)==name);b=next(n for n in ast.parse(ref).body if getattr(n,'name',None)==name)
 ck('original_definition_AST',ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),name)
for f in j(S/'PREFLIGHT.json')['frozen_methods']:ck('preflight_method_hash',sha((S/f['path']).read_bytes())==f['sha256'],f['path'])
# Verify immutable execution-record manifest, separately from whole-package manifest.
for f in j(S/'EXECUTION_RECORD_MANIFEST.json')['files']:
 b=(S/f['path']).read_bytes();ck('execution_record_hash',len(b)==f['bytes'] and sha(b)==f['sha256'],f['path'])
ledger=[json.loads(l) for l in (S/'CALL_BUDGET.jsonl').read_text().splitlines()];budget={}
for run in ['A_REFERENCE','B_CAPTURE']:
 es=[e for e in ledger if e['run']==run];ct=collections.Counter(e['event'] for e in es);budget[run]=dict(ct)
 for key,num in {'initialization_entry':1,'initialization_completed':1,'step_entry':200,'step_completed':200,'run_completed':1,'random_call_entry':211,'random_call_completed':211}.items():ck('budget_events',ct[key]==num,[run,key])
 ck('no_failed_events',not any('fail' in key for key in ct),run)
 ck('completed_pass_order',[e['pass_after'] for e in es if e['event']=='step_completed']==list(range(1,201)),run)
bound=[]
for p in range(201):
 a=nz(S/f'runs/A_REFERENCE/boundaries/boundary_{p:03}.npz');b=nz(S/f'runs/B_CAPTURE/boundaries/boundary_{p:03}.npz')
 ck('boundary_keys',list(a)==list(b),p)
 for k in a:eq('boundary_raw_bytes',a[k],b[k],[p,k])
 for k in ['X','R','V','frequencies']:ck('boundary_finite',bool(np.isfinite(b[k]).all()),[p,k])
 eq('stable_ids',b['ids'],np.arange(120,dtype=np.int64),p);ck('pass_label',int(b['pass'])==p,p)
 if p:
  eq('displacements',b['V'],b['X']-bound[-1]['X'],p);eq('fixed_frequencies',b['frequencies'],bound[0]['frequencies'],p);eq('fixed_configuration',b['configuration_json'],bound[0]['configuration_json'],p)
 else:ck('initial_zero_V',bool(np.all(b['V']==0)))
 bound.append(b)
a=nz(S/'runs/A_REFERENCE/metrics.npz');b=nz(S/'runs/B_CAPTURE/metrics.npz')
for k in a:eq('metric_raw_bytes',a[k],b[k],k)
for name in ['full_universe.csv','metrics.json']:ck('metric_export_bytes',(S/'runs/A_REFERENCE'/name).read_bytes()==(S/'runs/B_CAPTURE'/name).read_bytes(),name)
calls=j(S/'runs/B_CAPTURE/random/CALLS.json');ck('random_call_metadata',calls==j(S/'runs/A_REFERENCE/random/CALLS.json') and len(calls)==211)
random=[]
for i,c in enumerate(calls):
 name=f'call_{i:03}_{c["kind"]}.npz';a=nz(S/'runs/A_REFERENCE/random'/name);b=nz(S/'runs/B_CAPTURE/random'/name)
 ck('random_keys',list(a)==list(b),i)
 for k in a:
  if i==0 and k.startswith('before_'):continue
  eq('random_record_raw_bytes',a[k],b[k],[i,k])
 if i:rng('consecutive_rng_checkpoints',random[-1],'after_',b,'before_')
 random.append(b)
ck('init_call_order',[c['kind'] for c in calls[:11]]==['seed']+['normal']*6+['uniform']*2+['choice','uniform'])
eq('initial_X_from_draws',bound[0]['X'],np.vstack([random[i]['value'] for i in range(1,7)]));eq('initial_R_from_draw',bound[0]['R'],random[10]['value']);eq('initial_freq_from_draw',bound[0]['frequencies'],random[9]['value']);rng('initial_rng_checkpoint',random[10],'after_',bound[0],'rng_')
for p,c in enumerate(calls[11:],1):ck('noise_call_metadata',c['kind']=='normal' and c['pass']==p and c['args']==[0,.01/(1+.01*p),[120,3]],p)
h=rows(S/'handoff/originals/full_universe.csv');r=rows(S/'runs/B_CAPTURE/full_universe.csv');hc=sp['historical_comparison'];ck('historical_schema',len(h)==len(r)==200 and list(h[0])==list(r[0])==hc['columns'])
columns={};exact=0
for k in hc['columns']:
 x=np.array([float(v[k]) for v in h]);y=np.array([float(v[k]) for v in r]);d=np.abs(y-x);ii=k in hc['integer_columns'];good=d==0 if ii else d<=1e-12+1e-10*np.abs(x)
 ck('historical_column',bool(np.all(good)),k);ne=int(np.sum(d==0));exact+=ne
 columns[k]={'integer':ii,'cells':200,'exact':ne,'max_absolute_error':float(d.max()),'worst_pass':int(np.argmax(d)+1)}
result={'status':'PASS' if not errors else 'FAIL','errors':errors,'checks':dict(checks),'input_zip':{'bytes':p if False else side['bytes'],'sha256':side['sha256'],'files':len(z.namelist()),'payloads':len(m['files'])},'budget_ledger':budget,'historical':{'total_cells':3000,'nonpass_cells':2800,'integer_including_pass':800,'continuous':2200,'exact_total':exact,'exact_continuous':exact-800,'columns':columns},'scope':'Passive archive, source AST, recorded-byte and checkpoint comparisons. No new simulation, constructor, random draw or RNG restoration. No live Windows inspection.'}
(O/'RECORD_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'errors':errors[:20],'check_calls':sum(checks.values()),'historical_exact':exact},indent=2))
