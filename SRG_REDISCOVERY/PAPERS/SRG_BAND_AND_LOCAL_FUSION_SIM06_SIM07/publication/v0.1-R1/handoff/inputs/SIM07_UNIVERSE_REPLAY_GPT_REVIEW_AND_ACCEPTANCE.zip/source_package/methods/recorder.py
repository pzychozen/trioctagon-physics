"""Copy-only recorder. No state advancement, RNG generation, or restoration here."""
from pathlib import Path
from datetime import datetime, timezone
import json, os
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
def utc(): return datetime.now(timezone.utc).isoformat()
def json_safe(x):
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,dict): return {k:json_safe(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [json_safe(v) for v in x]
    return x
def dump(path,x):
    Path(path).write_text(json.dumps(json_safe(x),indent=2,allow_nan=False)+'\n',encoding='utf-8')
def ledger(event,run,**kwargs):
    record={'time_utc':utc(),'pid':os.getpid(),'run':run,'event':event,**kwargs}
    with (ROOT/'CALL_BUDGET.jsonl').open('a',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(record,allow_nan=False)+'\n'); f.flush(); os.fsync(f.fileno())
def rng_record(state,prefix='rng_'):
    name,words,pos,has_gauss,cached=state
    return {prefix+'name':np.asarray(name),prefix+'words':words.copy(),prefix+'position':np.asarray(pos,dtype=np.int64),prefix+'has_gauss':np.asarray(has_gauss,dtype=np.int64),prefix+'cached_gaussian':np.asarray(cached,dtype=np.float64)}
def config(field):
    names=['N','horizon','multi_freq','breathing','base_L','alpha','beta','lam_H','k_neighbors','gamma_srg']
    return {k:json_safe(getattr(field,k)) for k in names}

class Recorder:
    def __init__(self,run,out,deep):
        self.run=run; self.out=Path(out); self.deep=deep; self.p=0; self.calls=[]; self.stage=None
        for d in ['boundaries','random','stages']: (self.out/d).mkdir()
        self.random_originals={}; self.average_original=None; self.active_fusion=None

    def install_random_observers(self):
        # Each original random call is invoked exactly once, its actual result is
        # copied and the exact same result object returned. No RNG state restoration.
        for name in ['seed','normal','uniform','choice']:
            original=getattr(np.random,name); self.random_originals[name]=original
            def observed(*args,_name=name,_original=original,**kwargs):
                idx=len(self.calls); before=np.random.get_state()
                ledger('random_call_entry',self.run,call=idx,kind=_name,pass_label=self.p)
                value=_original(*args,**kwargs)
                after=np.random.get_state()
                record={**rng_record(before,'before_'),**rng_record(after,'after_')}
                if value is not None: record['value']=np.asarray(value).copy()
                np.savez_compressed(self.out/'random'/f'call_{idx:03}_{_name}.npz',**record)
                self.calls.append({'call':idx,'kind':_name,'pass':self.p,'args':json_safe(args),'kwargs':json_safe(kwargs),'has_value':value is not None})
                dump(self.out/'random/CALLS.json',self.calls)
                if self.p>0 and _name=='normal' and self.deep:
                    self.stage['noise']=np.asarray(value).copy()
                    self.stage.update(rng_record(before,'noise_before_'))
                    self.stage.update(rng_record(after,'noise_after_'))
                ledger('random_call_completed',self.run,call=idx,kind=_name,pass_label=self.p)
                return value
            setattr(np.random,name,observed)
        if self.deep:
            self.average_original=np.average
            def average(a,*args,**kwargs):
                # Actual arguments passed by the original expression, copied before evaluation.
                row=self.active_fusion
                if row is not None and self.stage is not None:
                    self.stage['fusion_reads'][row,:len(a)]=np.asarray(a).copy()
                    self.stage['fusion_weights'][row,:len(a)]=np.asarray(kwargs['weights']).copy()
                return self.average_original(a,*args,**kwargs)
            np.average=average

    def uninstall_observers(self):
        for name,fn in self.random_originals.items(): setattr(np.random,name,fn)
        if self.average_original is not None: np.average=self.average_original

    def boundary(self,field):
        p=field.pass_count
        arrays={'pass':np.asarray(p,dtype=np.int64),'ids':np.arange(field.N,dtype=np.int64),'X':field.positions.copy(),'R':field.resonance.copy(),'V':field.velocities.copy(),'frequencies':field.natural_freq.copy(),'configuration_json':np.asarray(json.dumps(config(field),sort_keys=True)),**rng_record(np.random.get_state())}
        if not all(np.isfinite(arrays[k]).all() for k in ['X','R','V','frequencies']): raise RuntimeError('Nonfinite boundary state')
        np.savez_compressed(self.out/'boundaries'/f'boundary_{p:03}.npz',**arrays)

    def begin_pass(self,field):
        self.p=field.pass_count+1
        if not self.deep: return
        n=field.N; k=field.k_neighbors
        self.stage={'incoming_X':field.positions.copy(),'incoming_R':field.resonance.copy(),'pass':np.asarray(self.p,dtype=np.int64),**rng_record(np.random.get_state(),'pass_before_'),
          'coupling_distance_weights':np.zeros((n,k)), 'coupling_frequency_factors':np.zeros((n,k)), 'coupling_weighted_pre_guard':np.zeros((n,k)), 'coupling_final_weights':np.zeros((n,k)), 'coupling_weight_sum':np.zeros(n), 'coupling_guard_visited':np.zeros(n,dtype=bool), 'coupling_guard_passed':np.zeros(n,dtype=bool), 'coupling_active':np.zeros(n,dtype=bool), 'coupling_R_neighbor':np.zeros(n), 'coupling_row_result':field.resonance.copy(),
          'fusion_ids':np.full((n,k),-1,dtype=np.int64),'fusion_valid':np.zeros(n,dtype=bool),'fusion_reads':np.zeros((n,k,3)),'fusion_weights':np.zeros((n,k)),'fusion_center':np.zeros((n,3)),'fusion_before':np.zeros((n,3)),'fusion_after':np.zeros((n,3)),'fusion_Q_neighbors':np.zeros((n,k)),'fusion_visit_order':np.full(n,-1,dtype=np.int64)}
        self.visits=0

    def graph(self,adj,dists):
        self.stage['adjacency']=adj.copy(); self.stage['distances']=dists.copy()
        self.stage['neighbor_count']=np.sum(adj>0,axis=1).astype(np.int64)
        self.stage['empty_rows']=self.stage['neighbor_count']==0

    def local(self,lap,positions): self.stage.update(lap=lap.copy(),Y=positions.copy())
    def coupling_distance(self,i,nbrs,w): self.stage['coupling_distance_weights'][i,:len(nbrs)]=w.copy()
    def coupling_guard(self,i,match,w,total):
        k=len(w); self.stage['coupling_frequency_factors'][i,:k]=match.copy(); self.stage['coupling_weighted_pre_guard'][i,:k]=w.copy(); self.stage['coupling_weight_sum'][i]=total; self.stage['coupling_guard_visited'][i]=True; self.stage['coupling_guard_passed'][i]=bool(total>1e-10)
    def coupling_final(self,i,w): self.stage['coupling_final_weights'][i,:len(w)]=w.copy()
    def coupling_result(self,i,Rnbr,result): self.stage['coupling_active'][i]=True; self.stage['coupling_R_neighbor'][i]=Rnbr; self.stage['coupling_row_result'][i]=result
    def post_coupling(self,R): self.stage['B']=R.copy()
    def post_H(self,h,mem,R): self.stage.update(H=np.asarray(h).copy(),H_factor=np.asarray(mem).copy(),Q=R.copy())
    def fusion_before(self,i,nbrs,positions,R):
        self.active_fusion=i; self.stage['fusion_visit_order'][self.visits]=i; self.visits+=1
        self.stage['fusion_ids'][i,:len(nbrs)]=nbrs.copy(); self.stage['fusion_valid'][i]=len(nbrs)>0
        self.stage['fusion_before'][i]=positions[i].copy()
        self.stage['fusion_Q_neighbors'][i,:len(nbrs)]=R[nbrs].copy()
    def fusion_center(self,i,center): self.stage['fusion_center'][i]=center.copy()
    def fusion_after(self,i,position):
        self.stage['fusion_after'][i]=position.copy(); self.active_fusion=None
    def compression_before(self,positions,R,L):
        self.stage.update(Z=positions.copy(),pre_compression_R=R.copy(),L=np.asarray(L).copy())
        # Passive flags, never used by source: same actual input and limits.
        mag=np.abs(R)+1e-9; logmag=np.log(mag)
        self.stage.update(compression_magnitude=mag.copy(),compression_log_magnitude=logmag.copy(),clipping_lower=logmag < -L,clipping_upper=logmag > L,compression_zero_input=R==0)
    def compression_after(self,R): self.stage['post_compression_R']=R.copy()
    def noise_scale(self,scale): self.stage['noise_scale']=np.asarray(scale).copy()
    def observer_groups(self,groups,linkage): self.stage['observer_membership']=groups.copy(); self.stage['observer_linkage']=linkage.copy()
    def end_pass(self,field):
        self.boundary(field)
        metrics=field.metrics_history
        dump(self.out/'metrics.json',metrics)
        # Original key order and native values also kept in per-column binary arrays.
        np.savez_compressed(self.out/'metrics.npz',**{k:np.asarray([r[k] for r in metrics]) for k in metrics[0]})
        if self.deep:
            self.stage.update(completed_X=field.positions.copy(),completed_R=field.resonance.copy(),completed_V=field.velocities.copy(),**rng_record(np.random.get_state(),'pass_after_'))
            self.stage['observer_metric_json']=np.asarray(json.dumps(json_safe(metrics[-1]),allow_nan=False))
            np.savez_compressed(self.out/'stages'/f'pass_{self.p:03}.npz',**self.stage)
        self.stage=None
    def partial(self):
        if self.deep and self.stage is not None: np.savez_compressed(self.out/'stages'/f'PARTIAL_pass_{self.p:03}.npz',**self.stage)
