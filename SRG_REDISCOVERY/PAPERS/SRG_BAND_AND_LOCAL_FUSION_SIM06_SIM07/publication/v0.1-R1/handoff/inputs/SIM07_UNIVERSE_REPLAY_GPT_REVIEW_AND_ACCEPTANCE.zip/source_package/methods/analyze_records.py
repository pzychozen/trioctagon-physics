"""Passive finite geometry, graph partitions and actual-read accounting. No engine/RNG."""
from pathlib import Path
import csv, hashlib, json
import numpy as np
from scipy.spatial.distance import pdist
from scipy.sparse.csgraph import connected_components

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'analysis'; OUT.mkdir(exist_ok=True)
B=ROOT/'runs/B_CAPTURE'
assert json.loads((OUT/'FIDELITY_VERIFICATION.json').read_text())['status']=='PASS'
def load(p):
    with np.load(p,allow_pickle=False) as f: return {k:f[k] for k in f.files}
def js(x):
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,dict): return {k:js(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [js(v) for v in x]
    return x
def save(n,x): (OUT/n).write_text(json.dumps(js(x),indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csvout(n,rows):
    with (OUT/n).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def partition(labels): return sorted([np.flatnonzero(labels==v).tolist() for v in np.unique(labels)],key=lambda g:g[0])
def canonical(labels):
    a=np.empty(len(labels),dtype=np.int64)
    for g in partition(labels): a[g]=g[0]
    return a
def geo(x):
    center=x.mean(axis=0); centered=x-center
    return center,float(np.sqrt(np.mean(np.sum(centered**2,axis=1)))),float(np.max(pdist(x))) if len(x)>1 else 0.0

boundaries=[load(B/'boundaries'/f'boundary_{p:03}.npz') for p in range(201)]
X=np.stack([d['X'] for d in boundaries]); R=np.stack([d['R'] for d in boundaries]); V=np.stack([d['V'] for d in boundaries]); frequencies=boundaries[0]['frequencies']; population=np.arange(120)//20
freq_values,freq_ids=np.unique(frequencies,return_inverse=True)
steps=np.linalg.norm(V,axis=2); paths=np.cumsum(steps,axis=0)
geometry=[]; population_geometry=[]
for p in range(201):
    c,rg,diam=geo(X[p]); geometry.append({'boundary':p,'center_x':c[0],'center_y':c[1],'center_z':c[2],'radius_of_gyration':rg,'diameter':diam,'center_displacement_from_0':float(np.linalg.norm(c-X[0].mean(axis=0))),'mean_step':float(steps[p].mean()),'max_step':float(steps[p].max()),'mean_cumulative_path':float(paths[p].mean()),'min_signed_R':float(R[p].min()),'max_signed_R':float(R[p].max())})
    for k in range(6):
        ids=np.flatnonzero(population==k); c,rg,diam=geo(X[p,ids]); initial=X[0,ids].mean(axis=0)
        population_geometry.append({'boundary':p,'population':k,'center_x':c[0],'center_y':c[1],'center_z':c[2],'radius_of_gyration':rg,'diameter':diam,'center_displacement_from_0':float(np.linalg.norm(c-initial)),'flattened_std_original_definition':float(np.std(X[p,ids])),'mean_step':float(steps[p,ids].mean()),'mean_cumulative_path':float(paths[p,ids].mean()),'mean_abs_R':float(np.abs(R[p,ids]).mean())})
csvout('geometry.csv',geometry); csvout('population_geometry.csv',population_geometry)
graphrows=[]; memberrows=[]; partitions={}; actuals=[]; amplitude=[]; edge_counts=np.zeros((120,120),dtype=np.int64); edge_passes={}; clipping={'lower':0,'upper':0,'zero_inputs':0,'nonzero_lower':0}
previous_adj=None; previous_observer=None; previous_weak=None; previous_strong=None
observer_change_passes=[]; graph_partition_change_passes=[]; canonical_observers=[]
episodes=[]; selected_passes=[1,16,200]
for p in range(1,201):
    d=load(B/'stages'/f'pass_{p:03}.npz'); adj=d['adjacency']>0
    nw,weak=connected_components(adj,directed=True,connection='weak'); ns,strong=connected_components(adj,directed=True,connection='strong')
    wcan=canonical(weak); scan=canonical(strong); ocan=canonical(d['observer_membership']); canonical_observers.append(ocan)
    cross=adj & (population[:,None]!=population[None,:]); edges=np.argwhere(cross)
    edge_counts+=cross
    for i,j in edges: edge_passes.setdefault(f'{i}->{j}',[]).append(p)
    obschange=previous_observer is not None and not np.array_equal(ocan,previous_observer)
    graphchange=previous_weak is not None and (not np.array_equal(wcan,previous_weak) or not np.array_equal(scan,previous_strong))
    if obschange: observer_change_passes.append(p)
    if graphchange: graph_partition_change_passes.append(p)
    graphrows.append({'pass_supplied':p,'incoming_boundary':p-1,'edges':int(adj.sum()),'weak_components':int(nw),'strong_components':int(ns),'empty_rows':int(d['empty_rows'].sum()),'cross_population_edges':int(cross.sum()),'changed_directed_edges_from_previous':int(np.count_nonzero(adj!=previous_adj)) if previous_adj is not None else 0,'observer_boundary':p,'observer_groups':len(set(ocan)),'observer_partition_changed':int(obschange),'weak_partition_changed':int(previous_weak is not None and not np.array_equal(wcan,previous_weak)),'strong_partition_changed':int(previous_strong is not None and not np.array_equal(scan,previous_strong))})
    for i in range(120): memberrows.append({'pass_supplied':p,'graph_boundary':p-1,'observer_boundary':p,'id':i,'population':int(population[i]),'frequency_index':int(freq_ids[i]),'frequency':float(frequencies[i]),'weak_component_min_id':int(wcan[i]),'strong_component_min_id':int(scan[i]),'observer_group_min_id':int(ocan[i])})
    if p in [1,2,8,16,20,50,100,200]:
        partitions[str(p)]={'graph_boundary':p-1,'weak_components':partition(weak),'strong_components':partition(strong),'observer_boundary':p,'observer_groups':partition(d['observer_membership'])}
    clipping['lower']+=int(d['clipping_lower'].sum()); clipping['upper']+=int(d['clipping_upper'].sum()); clipping['zero_inputs']+=int(d['compression_zero_input'].sum()); clipping['nonzero_lower']+=int((d['clipping_lower'] & ~d['compression_zero_input']).sum())
    changes=[]; contributions=[]
    for i in range(120):
        count=int(d['neighbor_count'][i]); ids=d['fusion_ids'][i,:count]
        if not count: continue
        w=d['fusion_weights'][i,:count]; a=w/w.sum(); increments=d['fusion_reads'][i,:count]-d['Y'][ids]; contribution=(a[:,None]*increments).sum(axis=0)
        before_center=(a[:,None]*d['Y'][ids]).sum(axis=0) # passive decomposition term, never used as an update
        residual=d['fusion_center'][i]-(before_center+contribution)
        norm=float(np.linalg.norm(contribution)); contributions.append((norm,i))
        actuals.append({'pass':p,'row_id':i,'neighbors':count,'earlier_selected_ids':int((ids<i).sum()),'read_increment_max_norm':float(np.max(np.linalg.norm(increments,axis=1))),'weighted_realized_read_contribution_norm':norm,'fusion_row_displacement_norm':float(np.linalg.norm(d['fusion_after'][i]-d['fusion_before'][i])),'center_accounting_max_abs_residual':float(np.max(np.abs(residual)))})
    if p in selected_passes:
        norm,i=max(contributions); count=int(d['neighbor_count'][i]); ids=d['fusion_ids'][i,:count]; weights=d['fusion_weights'][i,:count]; a=weights/weights.sum(); increments=d['fusion_reads'][i,:count]-d['Y'][ids]
        per=[]
        for slot,j in enumerate(ids):
            per.append({'neighbor_id':int(j),'earlier_write':bool(j<i),'Q':d['Q'][j],'weight_operand':weights[slot],'normalized_weight':a[slot],'post_local_Y':d['Y'][j],'actual_read':d['fusion_reads'][i,slot],'realized_increment':increments[slot],'increment_norm':np.linalg.norm(increments[slot]),'weighted_contribution':a[slot]*increments[slot]})
        centerY=(a[:,None]*d['Y'][ids]).sum(axis=0); contrib=(a[:,None]*increments).sum(axis=0)
        episodes.append({'pass':p,'window_boundaries':[max(0,p-5),min(200,p+5)],'row_id':i,'selection':'Maximum norm of realized earlier-write contribution among rows of this predetermined pass; descriptive record selection, no parameter search','Q_i':d['Q'][i],'target_before':d['fusion_before'][i],'actual_center':d['fusion_center'][i],'target_after':d['fusion_after'][i],'fusion_displacement':d['fusion_after'][i]-d['fusion_before'][i],'center_Y_decomposition_term':centerY,'realized_center_contribution':contrib,'contribution_norm':norm,'finite_arithmetic_residual':d['fusion_center'][i]-(centerY+contrib),'neighbors':per})
    for fidx,f in enumerate(freq_values):
        ids=np.flatnonzero(frequencies==f)
        amplitude.append({'pass':p,'frequency_index':fidx,'frequency':float(f),'count':len(ids),'mean_incoming_R':float(d['incoming_R'][ids].mean()),'mean_B':float(d['B'][ids].mean()),'mean_Q':float(d['Q'][ids].mean()),'mean_completed_R':float(d['completed_R'][ids].mean()),'mean_neighbor_exchange_diagnostic':float((d['coupling_R_neighbor'][ids]-d['incoming_R'][ids]).mean()),'mean_absolute_B_change':float(np.abs(d['B'][ids]-d['incoming_R'][ids]).mean()),'mean_abs_B_to_Q_change':float(np.abs(d['Q'][ids]-d['B'][ids]).mean()),'lower_clips':int(d['clipping_lower'][ids].sum()),'upper_clips':int(d['clipping_upper'][ids].sum())})
    previous_adj=adj; previous_observer=ocan; previous_weak=wcan; previous_strong=scan
csvout('graph_chronology.csv',graphrows); csvout('memberships.csv',memberrows); csvout('ordered_read_accounting.csv',actuals); csvout('amplitude_by_frequency.csv',amplitude)
save('SELECTED_PARTITIONS.json',partitions); save('ORDERED_EPISODES.json',episodes)
save('CROSS_POPULATION_SELECTIONS.json',{'direction':'row i selects j; an information-read edge, not a physical directed force','edges':edge_passes,'unique_edges':int(np.count_nonzero(edge_counts)),'total_selection_visits':int(edge_counts.sum()),'max_duration':max(edge_counts.flatten()).item()})
selected_ids=sorted({0,20,34,39,40,60,80,97,100}|{int(e['row_id']) for e in episodes}|{int(n['neighbor_id']) for e in episodes for n in e['neighbors']})
trackrows=[]
for p in range(201):
    for i in selected_ids:
        trackrows.append({'boundary':p,'id':i,'population':int(population[i]),'frequency':float(frequencies[i]),'x':X[p,i,0],'y':X[p,i,1],'z':X[p,i,2],'R_signed':R[p,i],'step_length':steps[p,i],'cumulative_path':paths[p,i],'net_displacement_from_0':float(np.linalg.norm(X[p,i]-X[0,i]))})
csvout('selected_point_tracks.csv',trackrows)
late=np.stack(canonical_observers[15:]); late_changes=[p for p in observer_change_passes if p>16]
spatial200=partitions['200']['observer_groups']
observer_geometry=[]
# Fixed membership of the endpoint observer groups, traced backward for description.
for p in range(201):
    for g in spatial200:
        c,rg,diam=geo(X[p,g]); observer_geometry.append({'boundary':p,'endpoint_group_min_id':g[0],'members':len(g),'radius_of_gyration':rg,'diameter':diam,'center_x':c[0],'center_y':c[1],'center_z':c[2],'mean_step':float(steps[p,g].mean())})
csvout('endpoint_group_geometry.csv',observer_geometry)
summary={'data_class':'REPRODUCED, two matched recordings of one setting; not independent trials','shape':list(X.shape),'frequency_catalogue_sorted':freq_values,'frequency_counts':[int(np.sum(frequencies==f)) for f in freq_values],'population_frequency_counts':[[int(np.sum((population==k)&(frequencies==f))) for f in freq_values] for k in range(6)],'geometry_selected':[geometry[p] for p in [0,1,16,20,50,100,200]],'population_geometry_initial':[r for r in population_geometry if r['boundary']==0],'population_geometry_final':[r for r in population_geometry if r['boundary']==200],'graph_selected':[graphrows[p-1] for p in [1,2,8,16,20,50,100,200]],'graph_weak_component_range':[min(g['weak_components'] for g in graphrows),max(g['weak_components'] for g in graphrows)],'graph_strong_component_range':[min(g['strong_components'] for g in graphrows),max(g['strong_components'] for g in graphrows)],'cross_population_selection_visits':int(edge_counts.sum()),'cross_population_unique_edges':int(np.count_nonzero(edge_counts)),'cross_population_passes':[g['pass_supplied'] for g in graphrows if g['cross_population_edges']],'empty_row_visits':sum(g['empty_rows'] for g in graphrows),'observer_partition_change_passes':observer_change_passes,'observer_partition_changes_after_16':late_changes,'graph_partition_change_passes':graph_partition_change_passes,'graph_directed_edges_changed_total':sum(g['changed_directed_edges_from_previous'] for g in graphrows),'clipping':clipping,'signed_R_all_boundaries_range':[float(R.min()),float(R.max())],'all_sampled_R_positive':bool(np.all(R>0)),'late_steps':{'pass_200_mean':float(steps[200].mean()),'pass_200_max':float(steps[200].max()),'passes_151_200_mean':float(steps[151:].mean()),'moving_ids_at_200':int(np.count_nonzero(steps[200]>0))},'path_totals':{'mean':float(paths[-1].mean()),'min':float(paths[-1].min()),'max':float(paths[-1].max()),'longest_id':int(paths[-1].argmax())},'episode_summary':[{'pass':e['pass'],'id':e['row_id'],'contribution_norm':e['contribution_norm'],'center_residual_max':float(np.max(np.abs(e['finite_arithmetic_residual'])))} for e in episodes],'selection_policy':'Snapshots 0,16,50,200; ordered-read passes 1,16,200 with maximum realized-read contribution per pass. All selections from saved data only.'}
save('MOTION_SUMMARY.json',summary)
print(json.dumps(js(summary),indent=2))
