"""Final passive gate; no original numerical definition is executed here."""
from pathlib import Path
import ast, hashlib, json, shutil
ROOT=Path(__file__).resolve().parents[1]
expected=Path(r'C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\SRG_SIMULATION_STUDY_07_UNIVERSE\REPLAY_01')
assert ROOT==expected.resolve()
assert not (ROOT/'CALL_BUDGET.jsonl').exists()
assert not (ROOT/'runs').exists()
assert not list(ROOT.glob('PROCESS_*.json'))
assert not (ROOT/'PREFLIGHT.json').exists()
assert shutil.disk_usage(ROOT).free>2_000_000_000
for f in (ROOT/'methods').glob('*.py'): compile(f.read_text(encoding='utf-8'),str(f),'exec')
ref=(ROOT/'methods/reference_core.py').read_text(encoding='utf-8')
cap=(ROOT/'methods/capture_core.py').read_text(encoding='utf-8')
assert ''.join(l for l in cap.splitlines(keepends=True) if not l.lstrip().startswith('REC.'))==ref
recorder=ast.parse((ROOT/'methods/recorder.py').read_text(encoding='utf-8'))
methods={n.name for n in ast.walk(recorder) if isinstance(n,ast.FunctionDef)}
hooks={n.func.attr for n in ast.walk(ast.parse(cap)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='REC'}
assert hooks<=methods
for e in json.loads((ROOT/'INPUT_BASELINE.json').read_text())['protected_files']:
    p=Path(e['path']); assert p.stat().st_size==e['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
frozen=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((ROOT/'methods').glob('*.py'))]
for p in [ROOT/'handoff/RUN_SPECIFICATION.json',ROOT/'handoff/originals/srg_condensate_breaking.py',ROOT/'handoff/originals/full_universe.csv']:
    frozen.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
receipt={'status':'READY_ZERO_INITIALIZATIONS_ZERO_UPDATES','date_utc':'2026-10-25','source_identity':'PASS','extraction_strip_check':'PASS','syntax_checks':'PASS','hook_targets_exist':sorted(hooks),'output_path_scope':'PASS','unused_workspace_budget':'PASS; new workspace created for this assignment, no receipts or run directories before gate','free_bytes':shutil.disk_usage(ROOT).free,'frozen_methods':frozen,'reviewed_numerical_changes':0,'recording_design':'Copy-only boundaries and random-return observation in both runs; capture hooks and actual np.average operands; source calls occur once; durable ledger before initializations and step entries','limits':{'initializations':2,'attempted_updates_total':400,'per_run':200,'retry':False}}
(ROOT/'PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':receipt['status'],'syntax_files':len(list((ROOT/'methods').glob('*.py'))),'hook_targets':len(hooks),'protected_files':len(json.loads((ROOT/'INPUT_BASELINE.json').read_text())['protected_files'])},indent=2))
