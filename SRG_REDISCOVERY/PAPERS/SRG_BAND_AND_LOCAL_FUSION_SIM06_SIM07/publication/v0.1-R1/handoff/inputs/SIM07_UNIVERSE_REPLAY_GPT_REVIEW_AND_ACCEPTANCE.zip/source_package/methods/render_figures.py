"""Static scientific plots of saved arrays only; no engine, RNG, or callbacks."""
from pathlib import Path
import csv, json, os
ROOT=Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR']=str(ROOT/'render_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import to_rgb
from matplotlib.ticker import MaxNLocator
import numpy as np
F=ROOT/'figures'; F.mkdir(exist_ok=True); DATA=F/'data'; DATA.mkdir(exist_ok=True)
B=ROOT/'runs/B_CAPTURE'; A=ROOT/'analysis'
assert json.loads((A/'FIDELITY_VERIFICATION.json').read_text())['status']=='PASS'
def load(p):
    with np.load(p,allow_pickle=False) as z: return {k:z[k] for k in z.files}
def rows(p):
    with p.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
def csvout(n,r):
    with (DATA/n).open('w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=list(r[0])); w.writeheader(); w.writerows(r)
def col(r,k): return np.array([float(x[k]) for x in r])
colors=['#0072B2','#D55E00','#009E73','#CC79A7','#E69F00','#7C52A1']; markers=['o','s','^','D','v','P']
plt.rcParams.update({'font.size':10,'axes.titlesize':11,'axes.labelsize':10,'figure.facecolor':'white','axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
registry=[]
def finish(fig,name,caption,inputs,data,transforms):
    fig.savefig(F/name,dpi=150); plt.close(fig)
    registry.append({'file':'figures/'+name,'data_class':'REPRODUCED (historical aggregate overlays explicitly marked)','caption':caption,'inputs':inputs,'plotted_data':data,'transformations':transforms,'physical_units':'Unspecified source world/amplitude units; time in integer passes'})
states=[load(B/'boundaries'/f'boundary_{p:03}.npz') for p in range(201)]
X=np.stack([s['X'] for s in states]); freq=states[0]['frequencies']; pop=np.arange(120)//20
lim=float(np.ceil(np.max(np.abs(X)))); ids_label=[0,20,40,60,80,100,97]

# F01 fixed world scale, equal 3D aspect, no alignment or camera changes.
fig=plt.figure(figsize=(12,12)); snapshots=[0,16,50,200]; plotted=[]
for k,p in enumerate(snapshots,1):
    ax=fig.add_subplot(2,2,k,projection='3d')
    for g in range(6):
        ids=np.flatnonzero(pop==g); q=X[p,ids]
        ax.scatter(*q.T,c=colors[g],marker=markers[g],s=18,alpha=.85,depthshade=False)
    for i in ids_label: ax.text(*X[p,i],str(i),fontsize=8,color='#222222')
    ax.set(xlim=(-lim,lim),ylim=(-lim,lim),zlim=(-lim,lim),xlabel='x',ylabel='y',zlabel='z',title=f'Boundary {p} | 120 stable IDs')
    ax.set_box_aspect((1,1,1)); ax.view_init(22,-55)
    for i in range(120): plotted.append({'boundary':p,'id':i,'population':int(pop[i]),'frequency':float(freq[i]),'x':X[p,i,0],'y':X[p,i,1],'z':X[p,i,2]})
handles=[Line2D([0],[0],color=colors[g],marker=markers[g],linestyle='',label=f'P{g}: IDs {20*g}–{20*g+19}') for g in range(6)]
fig.suptitle('REPRODUCED | clouds contract while their large-scale separation remains',fontsize=15,y=.98)
fig.legend(handles=handles,ncol=3,loc='lower center',bbox_to_anchor=(.5,.025),frameon=False)
fig.text(.5,.009,f'Same camera and ±{lim:g} world-unit axes in every panel. Labels mark selected IDs; overlapping markers retain distinct identities.',ha='center',fontsize=9)
fig.subplots_adjust(top=.93,bottom=.12,hspace=.18,wspace=.04)
csvout('F01_snapshots.csv',plotted)
finish(fig,'F01_world_snapshots.png','Boundaries 0,16,50,200; all IDs 0–119. Fixed world scale and orientation. No fitted solids or surfaces.','runs/B_CAPTURE/boundaries/boundary_{000,016,050,200}.npz',['figures/data/F01_snapshots.csv'],{'camera_elevation':22,'camera_azimuth':-55,'all_axis_limits':[-lim,lim],'coordinate_alignment':'none','colors_and_markers':'six supplied population blocks'})

# F02 same-boundary partitions; colors identify member sets within each row only.
member=rows(A/'same_boundary_memberships.csv'); fig,axs=plt.subplots(2,1,figsize=(13,6.5)); plotted=[]
keys=['population','frequency_index','weak_min_id','strong_min_id','observer_min_id']; labels=['Supplied population','Assigned frequency','Weak graph component','Strong graph component','Spatial observer']
for ax,b in zip(axs,[16,199]):
    rr=[r for r in member if int(r['boundary'])==b]; plotted+=rr
    rgb=np.zeros((5,120,3))
    for k,key in enumerate(keys):
        values=np.array([int(r[key]) for r in rr]); unq=np.unique(values)
        for v in unq:
            color=colors[v] if key=='population' else plt.get_cmap('turbo')((v*.61803398875)%1)
            rgb[k,values==v]=to_rgb(color)
    ax.imshow(rgb,aspect='auto',interpolation='nearest',extent=(-.5,119.5,4.5,-.5))
    ax.set_yticks(range(5),labels); ax.set_xticks([0,19,39,59,79,99,119]); ax.set_xlabel('Stable point ID'); ax.set_title(f'Boundary {b}: graph supplies pass {b+1}; observer measures boundary {b}')
    for edge in [19.5,39.5,59.5,79.5,99.5]: ax.axvline(edge,color='white',lw=1)
fig.suptitle('REPRODUCED | four different definitions of a group',fontsize=15,y=.98)
fig.text(.5,.014,'Colors are categorical within each row; shared colors across different row types do not imply a shared grouping. Exact member sets are in the CSV.',ha='center',fontsize=9)
fig.subplots_adjust(left=.17,right=.98,top=.90,bottom=.11,hspace=.62)
csvout('F02_memberships.csv',plotted)
finish(fig,'F02_group_memberships.png','IDs 0–119 at boundaries 16 and 199. Weak/strong partitions use the same boundary as the spatial observer; no boundary-200 graph was invented.',['analysis/same_boundary_memberships.csv'],['figures/data/F02_memberships.csv'],{'partition_canonicalization':'member set represented by its smallest ID; fixed frequency indexed in ascending numerical order','color':'categorical and row-local; no metric encoded'})

# F03 finite geometry, movement and separately defined counts.
geom=rows(A/'geometry.csv'); pg=rows(A/'population_geometry.csv'); graphs=rows(A/'graph_chronology.csv'); stage=rows(A/'stage_movement.csv')
fig,axs=plt.subplots(2,2,figsize=(13,8))
for g in range(6):
    rr=[r for r in pg if int(r['population'])==g]
    axs[0,0].plot(col(rr,'boundary'),col(rr,'radius_of_gyration'),color=colors[g],label=f'P{g}')
    axs[0,1].plot(col(rr,'boundary'),col(rr,'center_displacement_from_0'),color=colors[g],label=f'P{g}')
axs[0,0].set(title='True centered spread of supplied populations',ylabel='Radius of gyration [world units]',xlabel='Boundary'); axs[0,0].legend(ncol=3,fontsize=9)
axs[0,1].set(title='Their arithmetic centers also move',ylabel='Displacement from boundary 0 [world units]',xlabel='Boundary')
for key,label,c in [('mean_local_length','Local stage','#0072B2'),('mean_fusion_length','Fusion stage','#D55E00'),('mean_noise_length','Actual noise','#009E73'),('mean_net_length','Net completed step','#222222')]: axs[1,0].semilogy(col(stage,'pass'),col(stage,key),label=label,color=c)
axs[1,0].set(title='Observed lengths of actual stage increments',xlabel='Pass',ylabel='Mean per-point length [world units]'); axs[1,0].legend(fontsize=8)
axs[1,1].plot(col(graphs,'incoming_boundary'),col(graphs,'weak_components'),label='Weak graph components',color='#0072B2')
axs[1,1].plot(col(graphs,'incoming_boundary'),col(graphs,'strong_components'),label='Strong graph components',color='#E69F00')
axs[1,1].plot(col(graphs,'observer_boundary'),col(graphs,'observer_groups'),label='Spatial observer groups',color='#CC79A7')
axs[1,1].axhline(6,color='grey',ls=':',label='Six supplied populations'); axs[1,1].set(title='Group counts use different rules',xlabel='Boundary (graph 0–199; observer 1–200)',ylabel='Count'); axs[1,1].legend(fontsize=8)
for ax in axs.flat: ax.grid(alpha=.2)
fig.suptitle('REPRODUCED | contraction does not mean zero movement',fontsize=15)
fig.text(.5,.012,'All IDs, passes 1–200. Stage lengths are magnitudes of recorded increments; their scalar means do not add to the net step.',ha='center',fontsize=9)
fig.subplots_adjust(left=.07,right=.98,top=.91,bottom=.09,hspace=.38,wspace=.22)
finish(fig,'F03_geometry_and_movement.png','All IDs 0–119, boundaries 0–200 and executed passes 1–200. True vector-centered geometry; no flattened-standard-deviation substitution.',['analysis/geometry.csv','analysis/population_geometry.csv','analysis/stage_movement.csv','analysis/graph_chronology.csv'],['analysis/population_geometry.csv','analysis/stage_movement.csv','analysis/graph_chronology.csv'],{'radius':'sqrt(mean(sum((X-mean(X,axis=0))**2,axis=1)))','stage_lengths':'norm of differences of actual saved stages; logarithmic vertical axis in lower-left panel only','graph_alignment':'incoming boundary p-1, observer boundary p'})

# F04 three actual-read examples, close trajectories and signed contribution accounting.
episodes=json.loads((A/'ORDERED_EPISODES.json').read_text()); fig=plt.figure(figsize=(15,9)); trackdata=[]; contribdata=[]
for k,e in enumerate(episodes):
    p=e['pass']; i=e['row_id']; start,end=e['window_boundaries']; ids=[i]+[n['neighbor_id'] for n in e['neighbors']]; origin=np.array(e['target_before'])
    ax=fig.add_subplot(2,3,k+1,projection='3d'); allq=[]
    for slot,j in enumerate(ids):
        q=X[start:end+1,j]-origin; allq.append(q); color='#111111' if slot==0 else plt.get_cmap('tab10')((slot-1)%10)
        ax.plot(*q.T,c=color,lw=1.7 if slot==0 else 1,marker='.',markersize=3,label=str(j)); ax.scatter(*q[0],c=[color],s=22,marker='o'); ax.scatter(*q[-1],c=[color],s=26,marker='^')
        for b in range(start,end+1): trackdata.append({'episode_pass':p,'target_id':i,'boundary':b,'id':j,'origin_x':origin[0],'origin_y':origin[1],'origin_z':origin[2],'centered_x':X[b,j,0]-origin[0],'centered_y':X[b,j,1]-origin[1],'centered_z':X[b,j,2]-origin[2]})
    q=np.vstack(allq); center=(q.max(axis=0)+q.min(axis=0))/2; half=max(np.ptp(q,axis=0).max()/2*1.15,.003)
    ax.set(xlim=(center[0]-half,center[0]+half),ylim=(center[1]-half,center[1]+half),zlim=(center[2]-half,center[2]+half),xlabel='x − origin',ylabel='y − origin',zlabel='z − origin',title=f'Pass {p}, row {i} | boundaries {start}–{end}')
    ax.set_box_aspect((1,1,1)); ax.view_init(22,-55)
    ax.xaxis.set_major_locator(MaxNLocator(3)); ax.yaxis.set_major_locator(MaxNLocator(3)); ax.zaxis.set_major_locator(MaxNLocator(3))
    ax.legend(loc='upper left',ncol=3,fontsize=7,title='Point IDs',title_fontsize=8,frameon=True)
    bar=fig.add_subplot(2,3,k+4); xx=np.arange(5); cc=['#0072B2','#D55E00','#009E73']
    for dim,label in enumerate(['x','y','z']): bar.bar(xx+(dim-1)*.24,[n['weighted_contribution'][dim] for n in e['neighbors']],width=.24,color=cc[dim],label=label)
    bar.set_xticks(xx,[str(n['neighbor_id'])+(' *' if n['earlier_write'] else '') for n in e['neighbors']]); bar.set(xlabel='Selected neighbor ID (* already written)',ylabel='Weighted realized read increment [world units]',title=f'Center contribution norm = {e["contribution_norm"]:.3g}'); bar.axhline(0,color='grey',lw=.6); bar.grid(axis='y',alpha=.2); bar.ticklabel_format(axis='y',style='sci',scilimits=(-2,2)); bar.legend(fontsize=8)
    for n in e['neighbors']: contribdata.append({'pass':p,'row_id':i,'neighbor_id':n['neighbor_id'],'earlier_write':int(n['earlier_write']),'normalized_weight':n['normalized_weight'],'increment_norm':n['increment_norm'],'weighted_dx':n['weighted_contribution'][0],'weighted_dy':n['weighted_contribution'][1],'weighted_dz':n['weighted_contribution'][2]})
fig.suptitle('REPRODUCED | later rows read earlier writes within the same pass',fontsize=15,y=.98)
fig.text(.5,.017,'Top: sampled paths, circle=start, triangle=end; one fixed translation per panel, equal axes, differing close-view ranges. Bottom: actual-read accounting, not a reordered control.',ha='center',fontsize=9)
fig.subplots_adjust(left=.06,right=.98,top=.92,bottom=.10,wspace=.30,hspace=.25)
csvout('F04_episode_paths.csv',trackdata); csvout('F04_ordered_contributions.csv',contribdata)
finish(fig,'F04_actual_ordered_reads.png','Actual read episodes: pass 1 row 112, pass 16 row 6, pass 200 row 8; selected neighbor IDs labeled. Paths use saved boundaries only.',['analysis/ORDERED_EPISODES.json','runs/B_CAPTURE/boundaries/'],['figures/data/F04_episode_paths.csv','figures/data/F04_ordered_contributions.csv','analysis/ORDERED_EPISODES.json'],{'paths':'subtract fixed target post-local coordinate at the selected pass; no rotation, interpolation or time-dependent recentering','contribution':'a_ij*(actual_read_j-Y_j), summed descriptively; no alternate successor','selection':'maximum realized contribution at fixed passes 1,16,200'})

# F05 historical tolerance, signed amplitude and actual schedules.
hc=json.loads((A/'HISTORICAL_COMPARISON.json').read_text()); metric=json.loads((B/'metrics.json').read_text()); fig,axs=plt.subplots(2,2,figsize=(13,8)); errors=[]; ratios=[]
for k,c in hc['columns'].items():
    if k in ['pass','n_resonance_clusters','n_spatial_clusters','top_seed_id']: continue
    ratio=np.array([r['absolute_error']/(1e-12+1e-10*abs(r['historical'])) for r in c['cells']])
    for cell,ra in zip(c['cells'],ratio): errors.append({'pass':cell['pass'],'column':k,'historical':cell['historical'],'replay':cell['replay'],'absolute_error':cell['absolute_error'],'error_divided_by_frozen_tolerance':float(ra)})
    ratios.append(ratio)
axs[0,0].plot(range(1,201),np.max(ratios,axis=0),lw=1.2,color='#0072B2',label='Maximum over 11 continuous columns')
axs[0,0].set(title='Maximum historical discrepancy / allowed tolerance',xlabel='Pass',ylabel='Ratio (acceptance threshold = 1)'); axs[0,0].ticklabel_format(axis='y',style='sci',scilimits=(-2,2)); axs[0,0].text(.03,.97,'Maximum over 11 continuous columns\nAll 2,200 floating cells pass; 800 integer cells exact',transform=axs[0,0].transAxes,ha='left',va='top',fontsize=9)
for key,label in [('R_min','minimum'),('R_mean','mean'),('R_max','maximum')]: axs[0,1].plot(range(1,201),[r[key] for r in metric],label=label)
axs[0,1].set(title='Actual signed amplitudes stay positive',xlabel='Pass',ylabel='R (source amplitude units)'); axs[0,1].legend(fontsize=9)
for key in [k for k in metric[0] if k.startswith('band_')]: axs[1,0].plot(range(1,201),[r[key] for r in metric],label=key.replace('band_','f='))
axs[1,0].set(title='Assigned frequency labels have distinct means',xlabel='Pass',ylabel='Mean |R| by fixed label'); axs[1,0].legend(ncol=2,fontsize=8)
axs[1,1].plot(col(stage,'pass'),col(stage,'L'),color='#7C52A1',label='Prescribed L'); axs[1,1].set(title='Moving bound; no recorded clipping activation',xlabel='Pass',ylabel='Log-magnitude bound L'); axs[1,1].legend(fontsize=9)
for ax in axs.flat: ax.grid(alpha=.2)
fig.suptitle('REPRODUCED | historical aggregates pass the frozen comparison',fontsize=15)
fig.text(.5,.012,'Passes 1–200, all IDs. Amplitude extrema equal signed extrema here because the recorded signed R is positive. Agreement does not recover historical coordinates.',ha='center',fontsize=9)
fig.subplots_adjust(left=.07,right=.98,top=.91,bottom=.09,wspace=.24,hspace=.40)
csvout('F05_historical_float_errors.csv',errors)
finish(fig,'F05_metrics_and_amplitudes.png','All 200 completed passes. Original historical cells compared separately with reproduced aggregates under the frozen tolerance.',['analysis/HISTORICAL_COMPARISON.json','runs/B_CAPTURE/metrics.json','analysis/stage_movement.csv'],['figures/data/F05_historical_float_errors.csv','runs/B_CAPTURE/metrics.json','analysis/stage_movement.csv'],{'error_ratio':'abs(replay-historical)/(1e-12+1e-10*abs(historical))','amplitudes':'unmodified original observer output; signed positivity independently checked in full saved R','clipping':'activation flags from captured inputs, not an ablation'})

# F06 actual transient cross-population contact; projection disclosed.
cross=rows(A/'cross_population_distance_history.csv'); tracks=rows(A/'cross_population_tracks.csv'); fig,axs=plt.subplots(1,3,figsize=(15,5)); end=30
for i,c in [(34,colors[1]),(39,'#7A3411'),(97,colors[4])]:
    q=X[:end+1,i]; axs[0].plot(q[:,0],q[:,2],marker='.',markersize=4,label=f'ID {i}, P{i//20}',c=c); axs[0].scatter(q[0,0],q[0,2],s=45,marker='o',c=c); axs[0].scatter(q[-1,0],q[-1,2],s=50,marker='^',c=c)
    for b in [0,8,16,30]:
        if i==97: axs[0].annotate(str(b),(q[b,0],q[b,2]),xytext=(4,4),textcoords='offset points',fontsize=8)
axs[0].set(title='Boundaries 0–30: actual sampled x–z paths',xlabel='x [world units]',ylabel='z [world units]'); axs[0].axis('equal'); axs[0].legend(fontsize=8)
for i,j,c in [(39,97,'#D55E00'),(97,34,'#0072B2'),(97,39,'#009E73')]:
    rr=[r for r in cross if int(r['selector_id'])==i and int(r['selected_id'])==j and int(r['incoming_boundary'])<=30]
    # 39->97 and 97->39 have the same Euclidean distance; selection markers differ.
    axs[1].plot(col(rr,'incoming_boundary'),col(rr,'incoming_distance'),c=c,ls='--' if i==39 else '-',label=f'{i} selects {j}')
    sel=[r for r in rr if int(r['selected'])]; axs[1].scatter(col(sel,'incoming_boundary'),col(sel,'incoming_distance'),c=c,s=35,marker='s' if i==39 else 'o')
axs[1].axhline(6,ls=':',c='grey',label='Strict radius limit 6'); axs[1].set(title='Markers = actual selected directed edges',xlabel='Incoming boundary (supplies next pass)',ylabel='Incoming pair distance [world units]'); axs[1].legend(fontsize=8)
rr=[r for r in tracks if int(r['id'])==97]; axs[2].plot(col(rr,'boundary'),col(rr,'step'),c=colors[4]); axs[2].set(title='ID 97 keeps moving after contact ends',xlabel='Completed boundary',ylabel='Completed step length [world units]')
for ax in axs: ax.grid(alpha=.2)
fig.suptitle('REPRODUCED | an early connection between supplied populations P1 and P4',fontsize=15,y=.99)
fig.text(.5,.015,'IDs 34,39,97; paths 0–30 and step history 0–200. x–z projection omits y; straight joins only connect recorded samples. No coordinate wrapping or identity merger.',ha='center',fontsize=9)
fig.subplots_adjust(left=.055,right=.98,top=.85,bottom=.15,wspace=.30)
finish(fig,'F06_transient_cross_population_contact.png','Actual selection pairs 39→97 (passes 1–3), 97→34 (1–6), 97→39 (1–8). Line direction is a read relationship, not a physical force vector.',['analysis/cross_population_distance_history.csv','analysis/cross_population_tracks.csv'],['analysis/cross_population_distance_history.csv','analysis/cross_population_tracks.csv'],{'projection':'x-z unaligned, equal aspect; y omitted','distance':'captured incoming Euclidean distances; nearest-five cap also applies','step':'norm of actual V; no regenerated trajectory'})
(ROOT/'FIGURE_REGISTER.json').write_text(json.dumps(registry,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'figures':len(registry),'files':[r['file'] for r in registry]},indent=2))
