"""Passive readable companions, comparison/source indexes and visual-inspection receipt."""
from pathlib import Path
import ast, csv, hashlib, json, struct
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x): (ROOT/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
hc=json.loads((ROOT/'analysis/HISTORICAL_COLUMN_SUMMARY.json').read_text())
lines=['# Historical aggregate comparison by column','', 'All data rows are passes 1–200. Exact equality is parsed equality; every listed column passes its frozen criterion in all 200 cells. Maxima are first occurrences on a tie. The pass column is an index, not a scientific metric.','', '| Column | Exact / 200 | Max absolute error | Worst absolute pass | Max relative error | Worst relative pass |','|---|---:|---:|---:|---:|---:|']
for k,d in hc.items(): lines.append(f"| {k} | {d['exact_cells']} | {d['max_absolute_error']:.9g} | {d['worst_absolute_pass']} | {d['max_relative_error_excluding_nonzero_over_zero']:.9g} | {d['worst_relative_pass']} |")
lines+=['','Integer criterion: exact equality for pass, n_resonance_clusters, n_spatial_clusters and top_seed_id. Continuous criterion: `abs(replay-historical) <= 1e-12 + 1e-10*abs(historical)`. Relative error uses historical magnitude as denominator; zero/zero is 0, nonzero/zero is null with absolute error retained.','', 'Totals: **800 exact integer cells** (200 pass labels + 600 metrics), **2,200 accepted floating cells** (1,512 exact + 688 near-only). **3,000 cells total; 2,800 non-pass metrics.** No missing/nonfinite cells or schema/pass mismatches.','', 'Reference/capture exports are byte-identical to each other. The historical export is not byte-identical to the replay. Full cell-level values: [HISTORICAL_COMPARISON.json](analysis/HISTORICAL_COMPARISON.json). Criteria were supplied before either initialization in [RUN_SPECIFICATION.json](handoff/RUN_SPECIFICATION.json).','']
(ROOT/'HISTORICAL_COMPARISON_TABLE.md').write_text('\n'.join(lines),encoding='utf-8')
for run in ['A_REFERENCE','B_CAPTURE']:
    out=ROOT/'runs'/run/'point_states.csv'
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['boundary','id','population','frequency','x','y','z','R_signed','vx','vy','vz'])
        for b in range(201):
            with np.load(ROOT/'runs'/run/'boundaries'/f'boundary_{b:03}.npz',allow_pickle=False) as d:
                for i in range(120): w.writerow([b,i,i//20,float(d['frequencies'][i]),*d['X'][i].tolist(),float(d['R'][i]),*d['V'][i].tolist()])
source=ROOT/'handoff/originals/srg_condensate_breaking.py'; tree=ast.parse(source.read_text(encoding='utf-8'))
mapping=[]
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
        item={'name':node.name,'first_line':node.lineno,'last_line':node.end_lineno}
        if isinstance(node,ast.ClassDef): item['methods']=[{'name':n.name,'first_line':n.lineno,'last_line':n.end_lineno} for n in node.body if isinstance(n,ast.FunctionDef)]
        mapping.append(item)
save('SOURCE_LOCATIONS.json',{'source_path':source.relative_to(ROOT).as_posix(),'source_sha256':sha(source),'original_lines':778,'definitions':mapping,'executed_driver_only':'experiment_full_universe','executed_intervals':[[42,54],[60,266],[663,758]]})
visual=[]
notes={
'F01_world_snapshots.png':'Fixed ±13 world axes and equal aspect in all panels; increased row spacing removes 3D-axis/title crowding. Some projected markers overlap, disclosed; numerical IDs remain distinct.',
'F02_group_memberships.png':'Readable stable-ID membership strips, correctly aligned same-boundary graph and observer; categorical row-local colors and exact CSV member values disclosed.',
'F03_geometry_and_movement.png':'Population colors consistent with F01; labels, legends and logarithmic stage-length axis readable; graph/observer boundary offsets explicit.',
'F04_actual_ordered_reads.png':'Legends replace overlapping close-view IDs; reduced tick density resolves late-panel crowding. Fixed translations, different panel scales and actual-read decomposition disclosed.',
'F05_metrics_and_amplitudes.png':'Maximum discrepancy ratio across eleven columns clearly labeled; all ratios far below 1; amplitudes and scheduled L readable.',
'F06_transient_cross_population_contact.png':'x-z projection and omitted y explicit; directed selection markers, distance limit and ID97 step history readable; all plotted samples retained.'}
for name,note in notes.items():
    p=ROOT/'figures'/name; b=p.read_bytes(); width,height=struct.unpack('>II',b[16:24]); visual.append({'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'width':width,'height':height,'review':'Opened with view_image at original detail; final revisions to F01/F04/F05 reopened; F02/F03/F06 unchanged rendering instructions and visually inspected','status':'PASS','note':note})
save('VISUAL_INSPECTION.json',{'date':'2026-10-25','figures':visual,'static_only':True,'new_frames_or_updates_during_rendering':0})
print(json.dumps({'comparison_table':'written','complete_point_state_CSVs':2,'point_rows_per_run':24120,'source_definitions_indexed':len(mapping),'figures_inspected':6},indent=2))
