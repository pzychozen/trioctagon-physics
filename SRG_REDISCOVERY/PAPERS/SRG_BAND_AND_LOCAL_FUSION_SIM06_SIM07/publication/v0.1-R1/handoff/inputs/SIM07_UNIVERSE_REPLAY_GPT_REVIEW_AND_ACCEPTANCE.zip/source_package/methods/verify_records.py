"""Passive independent readback only. Never imports the engine or uses an RNG."""
from pathlib import Path
import csv, hashlib, json, struct
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'analysis'; OUT.mkdir(exist_ok=True)
def save(n,x): (OUT/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def load(p):
    with np.load(p,allow_pickle=False) as f: return {k:f[k] for k in f.files}
def same(a,b): return a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()
errors=[]; counts={}
def check(ok,kind,detail):
    counts[kind]=counts.get(kind,0)+1
    if not ok: errors.append({'kind':kind,'detail':detail})
A=ROOT/'runs/A_REFERENCE'; B=ROOT/'runs/B_CAPTURE'
spec=json.loads((ROOT/'handoff/RUN_SPECIFICATION.json').read_text())
for run in [A,B]:
    receipt=json.loads((run/'RUN_RECEIPT.json').read_text()); check(receipt['status']=='COMPLETE','execution',run.name)
    check(len(list((run/'boundaries').glob('*.npz')))==201,'boundary_count',run.name)
    previous=None
    for p in range(201):
        d=load(run/'boundaries'/f'boundary_{p:03}.npz')
        check(d['pass'].item()==p,'pass_label',f'{run.name}/{p}')
        check(same(d['ids'],np.arange(120,dtype=np.int64)),'stable_ids',f'{run.name}/{p}')
        for key,shape in [('X',(120,3)),('R',(120,)),('V',(120,3)),('frequencies',(120,))]:
            check(d[key].shape==shape and d[key].dtype==np.dtype('float64') and np.isfinite(d[key]).all(),'state_schema_finite',f'{run.name}/{p}/{key}')
        if previous is None:
            check(same(d['V'],np.zeros((120,3))),'boundary_zero_displacement',run.name)
            f0=d['frequencies'].copy(); conf=d['configuration_json'].copy()
        else:
            check(same(d['V'],d['X']-previous['X']),'exact_displacement',f'{run.name}/{p}')
        check(same(d['frequencies'],f0) and same(d['configuration_json'],conf),'fixed_configuration',f'{run.name}/{p}')
        previous=d
for p in range(201):
    a=load(A/'boundaries'/f'boundary_{p:03}.npz'); b=load(B/'boundaries'/f'boundary_{p:03}.npz')
    check(list(a)==list(b),'strict_boundary_schema',p)
    for k in a: check(same(a[k],b[k]),'strict_boundary_bytes',f'{p}/{k}')
for rel in ['metrics.npz']:
    a=load(A/rel); b=load(B/rel); check(list(a)==list(b),'metric_keys_order',rel)
    for k in a: check(same(a[k],b[k]),'strict_metric_bytes',k)
a_json=json.loads((A/'metrics.json').read_text()); b_json=json.loads((B/'metrics.json').read_text())
check(len(a_json)==len(b_json)==200,'metric_count',200)
for p,(a,b) in enumerate(zip(a_json,b_json),1):
    check(list(a)==list(b)==spec['historical_comparison']['columns'],'row_metric_order',p)
    for k in a:
        exact=(type(a[k])==type(b[k]) and (struct.pack('!d',a[k])==struct.pack('!d',b[k]) if isinstance(a[k],float) else a[k]==b[k]))
        check(exact,'strict_row_metric',f'{p}/{k}')
calls_a=json.loads((A/'random/CALLS.json').read_text()); calls_b=json.loads((B/'random/CALLS.json').read_text())
check(calls_a==calls_b,'random_calls_metadata','all')
expected=['seed']+['normal']*6+['uniform','uniform','choice','uniform']+['normal']*200
check([c['kind'] for c in calls_a]==expected,'random_call_order','211 calls including seed')
for c in calls_a:
    p=f"random/call_{c['call']:03}_{c['kind']}.npz"; a=load(A/p); b=load(B/p)
    check(list(a)==list(b),'random_schema',p)
    for k in a:
        if c['call']==0 and k.startswith('before_'): continue # arbitrary process pre-seed state
        check(same(a[k],b[k]),'strict_random_bytes',p+'/'+k)
for run in [A,B]:
    d=load(run/'boundaries/boundary_000.npz')
    gaussians=[load(run/'random'/f'call_{i:03}_normal.npz')['value'] for i in range(1,7)]
    check(same(np.vstack(gaussians),d['X']),'initialization_mapping',run.name+'/X')
    check(same(load(run/'random/call_009_choice.npz')['value'],d['frequencies']),'initialization_mapping',run.name+'/frequencies')
    check(same(load(run/'random/call_010_uniform.npz')['value'],d['R']),'initialization_mapping',run.name+'/R')
    for p in range(1,201):
        before=load(run/'boundaries'/f'boundary_{p-1:03}.npz'); after=load(run/'boundaries'/f'boundary_{p:03}.npz'); noise=load(run/'random'/f'call_{p+10:03}_normal.npz')
        for suf in ['name','words','position','has_gauss','cached_gaussian']:
            check(same(before['rng_'+suf],noise['before_'+suf]) and same(after['rng_'+suf],noise['after_'+suf]),'pass_rng_bookkeeping',f'{run.name}/{p}/{suf}')
check(len(list((B/'stages').glob('pass_*.npz')))==200,'stage_count',200)
stage_residuals={'ordered_center_accounting_max_abs':0.0}
for p in range(1,201):
    d=load(B/'stages'/f'pass_{p:03}.npz'); incoming=load(B/'boundaries'/f'boundary_{p-1:03}.npz'); completed=load(B/'boundaries'/f'boundary_{p:03}.npz')
    check(same(d['incoming_X'],incoming['X']) and same(d['incoming_R'],incoming['R']),'incoming_state',p)
    for target,key in [('X','completed_X'),('R','completed_R'),('V','completed_V')]: check(same(d[key],completed[target]),'completed_state',f'{p}/{key}')
    check(same(d['fusion_visit_order'],np.arange(120,dtype=np.int64)),'ascending_visits',p)
    adj=d['adjacency']>0
    check(not np.diag(adj).any() and np.max(np.sum(adj,axis=1))<=5 and np.all(d['distances'][adj]<6),'graph_rules',p)
    check(np.array_equal(np.sum(adj,axis=1),d['neighbor_count']) and np.array_equal(d['empty_rows'],d['neighbor_count']==0),'neighbor_counts',p)
    check(same(d['pre_compression_R'],d['Q']) and same(d['B'],d['coupling_row_result']),'amplitude_stage_identity',p)
    check(same(d['Z'],d['fusion_after']) and same(d['fusion_before'],d['Y']),'fusion_stage_identity',p)
    # Noise addition is an identity check from two recorded operands, not a
    # reconstructed trajectory or propagated successor.
    check(same(d['Z']+d['noise'],d['completed_X']),'actual_noise_identity',p)
    check(same(d['noise'],load(B/'random'/f'call_{p+10:03}_normal.npz')['value']),'actual_noise_return',p)
    check(same(d['post_compression_R'],d['completed_R']),'compression_state',p)
    check(same(d['Q'],d['pre_compression_R']),'Q_fixed_through_fusion',p)
    check(len(set(d['observer_membership'].tolist()))==b_json[p-1]['n_spatial_clusters'],'observer_count',p)
    check(json.loads(d['observer_metric_json'].item())==b_json[p-1],'observer_row',p)
    check(np.array_equal(d['clipping_lower'],d['compression_log_magnitude'] < -d['L']) and np.array_equal(d['clipping_upper'],d['compression_log_magnitude'] > d['L']),'clipping_flags',p)
    for i in range(120):
        ids=np.flatnonzero(adj[i]); k=len(ids)
        check(np.array_equal(ids,d['fusion_ids'][i,:k]) and np.all(d['fusion_ids'][i,k:]==-1),'fusion_ids',f'{p}/{i}')
        check(bool(d['fusion_valid'][i])==(k>0),'fusion_valid_mask',f'{p}/{i}')
        if not k: continue
        check(same(d['fusion_Q_neighbors'][i,:k],d['Q'][ids]),'fusion_Q_reads',f'{p}/{i}')
        check(same(d['fusion_weights'][i,:k],np.abs(d['Q'][ids])+1e-8),'fusion_actual_weights',f'{p}/{i}')
        for t,j in enumerate(ids):
            expected_read=d['fusion_after'][j] if j<i else d['Y'][j]
            check(same(d['fusion_reads'][i,t],expected_read),'actual_ordered_read',f'{p}/{i}/{j}')
        # Accounting against stored Y, not an alternative center used for an update.
        w=d['fusion_weights'][i,:k]; a=w/w.sum()
        contribution=np.sum(a[:,None]*(d['fusion_reads'][i,:k]-d['Y'][ids]),axis=0)
        center_identity=np.sum(a[:,None]*d['Y'][ids],axis=0)+contribution
        residual=float(np.max(np.abs(d['fusion_center'][i]-center_identity)))
        stage_residuals['ordered_center_accounting_max_abs']=max(stage_residuals['ordered_center_accounting_max_abs'],residual)
    for key,array in d.items():
        if array.dtype.kind in 'fc': check(np.isfinite(array).all(),'stage_finite',f'{p}/{key}')
events=[json.loads(l) for l in (ROOT/'CALL_BUDGET.jsonl').read_text().splitlines()]
budget={r:{k:sum(e['run']==r and e['event']==k for e in events) for k in ['initialization_entry','initialization_completed','step_entry','step_completed','step_failed','run_completed','run_failed']} for r in ['A_REFERENCE','B_CAPTURE']}
for r,v in budget.items(): check(v=={'initialization_entry':1,'initialization_completed':1,'step_entry':200,'step_completed':200,'step_failed':0,'run_completed':1,'run_failed':0},'budget',r)
fidelity={'status':'PASS' if not errors else 'FAIL_NO_RERUN','errors':errors,'first_discrepancy':errors[0] if errors else None,'check_counts':counts,'budget':budget,'stage_accounting_residuals':stage_residuals,'reference_capture_csv_bytes_identical':(A/'full_universe.csv').read_bytes()==(B/'full_universe.csv').read_bytes(),'policy':'Raw dtype/shape/bytes for state, full deterministic RNG and metric arrays; no tolerance','pre_seed_rng_excluded':True,'scientific_updates_in_this_checker':0}
save('FIDELITY_VERIFICATION.json',fidelity)

# Historical comparison is a separate gate; use Python CSV float parsing rather
# than a dataframe parser that may round a last bit differently.
with (ROOT/'handoff/originals/full_universe.csv').open(newline='',encoding='utf-8') as f: hreader=csv.DictReader(f); hist=list(hreader); hkeys=hreader.fieldnames
with (A/'full_universe.csv').open(newline='',encoding='utf-8') as f: rreader=csv.DictReader(f); replay=list(rreader); rkeys=rreader.fieldnames
policy=spec['historical_comparison']; hc={'schema_exact':hkeys==rkeys==policy['columns'],'rows_historical':len(hist),'rows_replay':len(replay),'columns':{},'byte_identical':(ROOT/'handoff/originals/full_universe.csv').read_bytes()==(A/'full_universe.csv').read_bytes(),'float_policy':policy['float_formula'],'relative_zero_policy':'Relative error defined as 0 for 0 versus 0, otherwise null at historical zero; absolute discrepancy is always reported. Maximum relative statistic excludes nonzero/zero cases.','integer_cells':800,'floating_cells':2200,'total_cells':3000,'non_pass_metrics':2800}
for k in policy['columns']:
    vals=[]
    for p,(h,r) in enumerate(zip(hist,replay),1):
        x=float(h[k]); y=float(r[k]); delta=abs(y-x); rel=delta/abs(x) if x!=0 else (0.0 if delta==0 else None)
        exact=y==x; near=exact if k in policy['integer_columns'] else delta<=1e-12+1e-10*abs(x)
        vals.append({'pass':p,'historical':x,'replay':y,'absolute_error':delta,'relative_error':rel,'exact':exact,'within_frozen_criterion':near,'finite':bool(np.isfinite(x) and np.isfinite(y))})
    worst=max(vals,key=lambda v:v['absolute_error']); relmax=max((v for v in vals if v['relative_error'] is not None),key=lambda v:v['relative_error'])
    hc['columns'][k]={'exact_cells':sum(v['exact'] for v in vals),'criterion_pass_cells':sum(v['within_frozen_criterion'] and v['finite'] for v in vals),'finite_cells':sum(v['finite'] for v in vals),'max_absolute_error':worst['absolute_error'],'worst_absolute_pass':worst['pass'],'max_relative_error_excluding_nonzero_over_zero':relmax['relative_error'],'worst_relative_pass':relmax['pass'],'first_failure':next((v for v in vals if not v['within_frozen_criterion'] or not v['finite']),None),'cells':vals}
hc['exact_cells']=sum(c['exact_cells'] for c in hc['columns'].values()); hc['criterion_pass_cells']=sum(c['criterion_pass_cells'] for c in hc['columns'].values()); hc['status']='PASS' if hc['schema_exact'] and len(hist)==len(replay)==200 and hc['criterion_pass_cells']==3000 else 'HISTORICAL_MISMATCH_NO_TUNING'
save('HISTORICAL_COMPARISON.json',hc)
print(json.dumps({'fidelity':fidelity['status'],'first_error':fidelity['first_discrepancy'],'budget':budget,'historical':hc['status'],'historical_exact_cells':hc['exact_cells'],'historical_criterion_pass_cells':hc['criterion_pass_cells'],'reference_capture_csv_byte_identity':fidelity['reference_capture_csv_bytes_identical']},indent=2))
