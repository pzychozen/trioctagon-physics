"""Passive same-boundary membership, source-observer and stage-operand readback."""
from pathlib import Path
import csv, json
import numpy as np
from scipy.sparse.csgraph import connected_components
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'analysis'; B=ROOT/'runs/B_CAPTURE'
def load(p):
    with np.load(p,allow_pickle=False) as f: return {k:f[k] for k in f.files}
def save(n,x): (OUT/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csvout(n,r):
    with (OUT/n).open('w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=list(r[0])); w.writeheader(); w.writerows(r)
def canon(labels):
    a=np.empty(120,dtype=np.int64)
    for v in np.unique(labels): ids=np.flatnonzero(labels==v); a[ids]=ids[0]
    return a
members=[]; f=load(B/'boundaries/boundary_000.npz')['frequencies']; fv,fi=np.unique(f,return_inverse=True)
for b in [1,16,50,199]:
    graph=load(B/'stages'/f'pass_{b+1:03}.npz')['adjacency']
    weak=canon(connected_components(graph,directed=True,connection='weak')[1]); strong=canon(connected_components(graph,directed=True,connection='strong')[1]); observer=canon(load(B/'stages'/f'pass_{b:03}.npz')['observer_membership'])
    for i in range(120): members.append({'boundary':b,'graph_supplies_pass':b+1,'id':i,'population':i//20,'frequency_index':int(fi[i]),'weak_min_id':int(weak[i]),'strong_min_id':int(strong[i]),'observer_min_id':int(observer[i])})
csvout('same_boundary_memberships.csv',members)
stage=[]; checked=[]; cross=[]; exact=True; coupling_guard_failures=0
metrics=json.loads((B/'metrics.json').read_text())
for p in range(1,201):
    d=load(B/'stages'/f'pass_{p:03}.npz'); r=d['completed_R']; x=d['completed_X']; v=d['completed_V']; absr=np.abs(r)
    sortedr=np.sort(absr)[::-1]; nres=len(np.flatnonzero(np.abs(np.diff(sortedr))>.05*sortedr[0]))+1
    prob=absr/absr.sum()
    calc={'R_max':float(absr.max()),'R_min':float(absr.min()),'R_mean':float(absr.mean()),'R_std':float(r.std()),'n_resonance_clusters':nres,'entropy':float(-(prob*np.log(prob+1e-12)).sum()),'mean_grf':float((1/(1+np.linalg.norm(v,axis=1))).mean()),'top_seed_id':int(absr.argmax())}
    calc.update({f'band_{fval:.4f}':float(np.abs(r[f==fval]).mean()) for fval in fv})
    for k,value in calc.items():
        passed=(np.asarray(value).tobytes()==np.asarray(metrics[p-1][k]).tobytes()); exact&=passed
        checked.append({'pass':p,'column':k,'exact_binary_observer_readback':bool(passed)})
    coupling_guard_failures+=int((d['coupling_guard_visited'] & ~d['coupling_guard_passed']).sum())
    stage.append({'pass':p,'mean_local_length':float(np.linalg.norm(d['Y']-d['incoming_X'],axis=1).mean()),'mean_fusion_length':float(np.linalg.norm(d['Z']-d['Y'],axis=1).mean()),'mean_noise_length':float(np.linalg.norm(d['noise'],axis=1).mean()),'mean_net_length':float(np.linalg.norm(v,axis=1).mean()),'H':float(d['H']),'H_factor':float(d['H_factor']),'L':float(d['L']),'min_Q':float(d['Q'].min()),'max_Q':float(d['Q'].max()),'min_B':float(d['B'].min()),'max_B':float(d['B'].max()),'min_guard_sum':float(d['coupling_weight_sum'].min()),'min_abs_R':float(absr.min()),'min_log_margin_to_lower':float((d['compression_log_magnitude']+d['L']).min()),'min_log_margin_to_upper':float((d['L']-d['compression_log_magnitude']).min()),'noise_scale':float(d['noise_scale'])})
    for i,j in [(39,97),(97,34),(97,39)]: cross.append({'incoming_boundary':p-1,'pass_supplied':p,'selector_id':i,'selected_id':j,'incoming_distance':float(d['distances'][i,j]),'selected':int(d['adjacency'][i,j]>0)})
csvout('stage_movement.csv',stage); csvout('cross_population_distance_history.csv',cross); csvout('observer_readback.csv',checked)
tracks=[]
for b in range(201):
    d=load(B/'boundaries'/f'boundary_{b:03}.npz')
    for i in [34,39,97]: tracks.append({'boundary':b,'id':i,'population':i//20,'x':float(d['X'][i,0]),'y':float(d['X'][i,1]),'z':float(d['X'][i,2]),'R':float(d['R'][i]),'step':float(np.linalg.norm(d['V'][i]))})
csvout('cross_population_tracks.csv',tracks)
obs200=canon(load(B/'stages/pass_200.npz')['observer_membership']); obs_groups=[]
for gid in np.unique(obs200):
    ids=np.flatnonzero(obs200==gid); pops,counts=np.unique(ids//20,return_counts=True)
    obs_groups.append({'group_min_id':int(gid),'ids':ids.tolist(),'population_counts':{str(k):int(n) for k,n in zip(pops,counts)}})
replayX=load(B/'boundaries/boundary_200.npz')['X']; c=np.array([replayX[k*20:(k+1)*20].mean(axis=0) for k in range(6)])
inter=[float(np.linalg.norm(c[i]-c[j])) for i in range(6) for j in range(i+1,6)]
hc=json.loads((OUT/'HISTORICAL_COMPARISON.json').read_text()); hsummary={k:{kk:vv for kk,vv in v.items() if kk!='cells'} for k,v in hc['columns'].items()}; save('HISTORICAL_COLUMN_SUMMARY.json',hsummary)
save('SUPPLEMENTAL_READBACK.json',{'status':'PASS' if exact else 'OBSERVER_DISCREPANCY','observer_columns_checked':12,'observer_cells_checked':len(checked),'exact_observer_readback':bool(exact),'spatial_membership_source':'Actual original observer output, not rerun clustering','guard_failures':coupling_guard_failures,'stage_selected':[stage[p-1] for p in [1,16,50,200]],'endpoint_observer_groups':obs_groups,'cross_population_id97_first_last':[r for r in tracks if r['id']==97 and r['boundary'] in [0,8,16,30,200]],'population_center_distance_range_at_200':[min(inter),max(inter)],'all_Q_positive':all(s['min_Q']>0 for s in stage),'smallest_log_clipping_margin':min(min(s['min_log_margin_to_lower'],s['min_log_margin_to_upper']) for s in stage),'post_run_state_updates':0,'post_run_rng_calls':0})
print(json.dumps(json.loads((OUT/'SUPPLEMENTAL_READBACK.json').read_text()),indent=2))
