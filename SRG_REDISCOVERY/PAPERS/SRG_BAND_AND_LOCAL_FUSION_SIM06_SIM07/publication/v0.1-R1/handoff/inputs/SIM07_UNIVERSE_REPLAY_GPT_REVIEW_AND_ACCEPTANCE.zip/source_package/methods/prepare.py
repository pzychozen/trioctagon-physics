"""Prepare exact extraction and observational insertion; NEVER execute scientific code."""
from pathlib import Path
import ast, difflib, hashlib, json, platform, sys, zipfile, io, importlib.metadata

ROOT=Path(__file__).resolve().parents[1]
def sha(b): return hashlib.sha256(b).hexdigest()
def write(n,s):
    p=ROOT/n; p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists(): raise RuntimeError('No overwrite: '+str(p))
    p.write_text(s,encoding='utf-8',newline='\n')
def jwrite(n,x): write(n,json.dumps(x,indent=2)+'\n')

manifest=json.loads((ROOT/'handoff/HANDOFF_MANIFEST.json').read_text())
checks=[]
for e in manifest['files']:
    b=(ROOT/'handoff'/e['path']).read_bytes()
    assert len(b)==e['bytes'] and sha(b)==e['sha256'], e['path']
    checks.append(e['path'])
im=json.loads((ROOT/'handoff/INPUT_MANIFEST.json').read_text())
with zipfile.ZipFile(ROOT/'handoff'/im['primary_archive']['path']) as z:
    for e in im['convenience_copies']:
        assert z.read(e['source_member'])==(ROOT/'handoff'/e['path']).read_bytes()
    c=im['original_construction_archive_inside_primary']; b=z.read(c['member'])
    assert len(b)==c['bytes'] and sha(b)==c['sha256']
source=(ROOT/'handoff/originals/srg_condensate_breaking.py').read_text(encoding='utf-8')
lines=source.splitlines(keepends=True)
intervals=[(42,54),(60,266),(663,758)]
header='"""Declared exact source extraction; never run directly. OUTPUT_DIR supplied by runner."""\nimport numpy as np\nimport pandas as pd\nfrom scipy.spatial.distance import pdist, squareform\n\n'
pieces=[''.join(lines[a-1:b]) for a,b in intervals]
reference=header+'\n'.join(pieces)
assert len(lines)==778
tree=ast.parse(reference)
original=ast.parse(source)
for name in ['H','rpco','GlyphFieldUniverse','experiment_full_universe']:
    a=next(x for x in original.body if getattr(x,'name',None)==name)
    b=next(x for x in tree.body if getattr(x,'name',None)==name)
    assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)

# Hooks add only REC method calls at documented source-line boundaries. Removing
# every such expression restores reference text exactly, including statement order.
after={
 125: [],
 134: ['            REC.coupling_distance(i, nbrs, w)'],
 140: ['                REC.coupling_guard(i, freq_match, w, w_sum)'],
 142: ['                    REC.coupling_final(i, w)'],
 151: ['            REC.coupling_result(i, R_nbr, R_new[i])'],
 160: ['        REC.graph(adj, dists)'],
 168: ['        REC.local(lap, self.positions)'],
 171: ['        REC.post_coupling(self.resonance)'],
 176: ['        REC.post_H(h_t, mem, self.resonance)'],
 182: ['                REC.fusion_before(i, nbrs, self.positions, self.resonance)'],
 187: ['                    REC.fusion_center(i, local_center)'],
 188: ['                REC.fusion_after(i, self.positions[i])'],
 195: ['        REC.compression_before(self.positions, self.resonance, L)'],
 196: ['        REC.compression_after(self.resonance)'],
 199: ['        REC.noise_scale(noise_scale)'],
 220: ['            REC.observer_groups(spatial_clusters, Z)'],
}
capture=header
for k,(a,b) in enumerate(intervals):
    if k: capture+='\n'
    for number in range(a,b+1):
        capture+=lines[number-1]
        for hook in after.get(number,[]): capture+=hook+'\n'
stripped=''.join(line for line in capture.splitlines(keepends=True) if not line.lstrip().startswith('REC.'))
assert stripped==reference
class Strip(ast.NodeTransformer):
    def visit_Expr(self,node):
        if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='REC': return None
        return self.generic_visit(node)
assert ast.dump(Strip().visit(ast.parse(capture)),include_attributes=False)==ast.dump(tree,include_attributes=False)
compile(reference,'reference_core.py','exec'); compile(capture,'capture_core.py','exec')
write('methods/reference_core.py',reference)
write('methods/capture_core.py',capture)
write('methods/CAPTURE_HOOKS.diff',''.join(difflib.unified_diff(reference.splitlines(keepends=True),capture.splitlines(keepends=True),fromfile='reference_core.py',tofile='capture_core.py')))
jwrite('EXTRACTION_VERIFICATION.json',{'source_sha256':sha((ROOT/'handoff/originals/srg_condensate_breaking.py').read_bytes()),'intervals_inclusive':intervals,'exact_interval_text':True,'original_definition_AST_equal':True,'capture_hook_stripped_text_equal':True,'capture_hook_stripped_AST_equal':True,'reference_sha256':sha(reference.encode()),'capture_sha256':sha(capture.encode()),'hook_locations_after_original_line':after,'output_adaptation':'Runner supplies OUTPUT_DIR under runs/A_REFERENCE or runs/B_CAPTURE; no numerical original replaced','handoff_manifest_payloads_verified':checks,'nested_convenience_copies_verified':len(im['convenience_copies']),'prior_submission_hash_verified':True,'scientific_executions':0})

# Required dependencies imported BEFORE any scientific initialization. No install.
import numpy as np, pandas as pd, scipy
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.sparse.csgraph import connected_components
import matplotlib
env={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'byteorder':sys.byteorder,'versions':{n:importlib.metadata.version(n) for n in ['numpy','pandas','scipy','matplotlib']},'conda_environment':'torment','dependency_import_gate':'PASS; no initialization or random call','date_utc':'2026-10-25'}
buf=io.StringIO()
from contextlib import redirect_stdout
with redirect_stdout(buf): np.show_config()
env['numpy_build_configuration']=buf.getvalue()
jwrite('ENVIRONMENT.json',env)
print(json.dumps({'verified_payloads':len(checks),'extraction':'PASS','dependency_imports':'PASS','versions':env['versions'],'initializations':0,'updates':0},indent=2))
