"""Independent passive review of fixed SIM06 records.
No simulator imports, field construction, update execution, RNG calls, or spectral audit.
The only newly computed quantities describe delivered saved arrays and graph dependencies.
"""
from pathlib import Path
import ast, csv, hashlib, json, platform, re, zipfile
from urllib.parse import unquote
import numpy as np

BASE=Path(__file__).resolve().parent
ROOT=BASE/'source_package'
OUT=BASE/'independent'; OUT.mkdir(exist_ok=True)
RUN=ROOT/'records/R1_seed2038_eps1'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p): return json.loads(p.read_text(encoding='utf-8'))
def csvrows(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def writecsv(name,rows):
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader();w.writerows(rows)
def components(adj):
    """Independent undirected components; order by smallest ID."""
    A=adj|adj.T; unseen=set(range(len(A))); groups=[]
    while unseen:
        v=min(unseen); unseen.remove(v); stack=[v]; g=[]
        while stack:
            x=stack.pop(); g.append(x)
            nxt=unseen.intersection(np.flatnonzero(A[x]).tolist())
            unseen.difference_update(nxt);stack.extend(nxt)
        groups.append(sorted(g))
    return groups

def scc_count(adj):
    """Kosaraju SCC count; independent of submitted scipy graph implementation."""
    n=len(adj); nbr=[np.flatnonzero(row).tolist() for row in adj]
    rev=[np.flatnonzero(row).tolist() for row in adj.T]
    seen=set(); order=[]
    def visit(v):
        seen.add(v)
        for w in nbr[v]:
            if w not in seen:visit(w)
        order.append(v)
    for i in range(n):
        if i not in seen:visit(i)
    seen=set();count=0
    for v in reversed(order):
        if v in seen:continue
        count+=1;seen.add(v);stack=[v]
        while stack:
            x=stack.pop()
            for w in rev[x]:
                if w not in seen:seen.add(w);stack.append(w)
    return count

# Delivered identity and original-before/after snapshots, not a Windows filesystem audit.
initial={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*') if p.is_file()}
man=js(ROOT/'MANIFEST.json'); errors=[]
for e in man['files']:
    p=ROOT/e['path']
    if not p.exists() or p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']:errors.append(e['path'])
assert not errors,errors
assert set(initial)=={e['path'] for e in man['files']}|{'MANIFEST.json'}
bl=js(ROOT/'INPUT_BASELINE.json')
assert len(bl)==43 and len({e['copy'] for e in bl})==43
assert all((ROOT/e['copy']).stat().st_size==e['bytes'] and sha(ROOT/e['copy'])==e['sha256'] for e in bl)
r1_index={e['path']:e for e in js(ROOT/'context/R1/PAYLOAD_MANIFEST.json')['files']}
r1files=sorted(p for p in RUN.iterdir() if p.is_file())
for p in r1files:
    e=r1_index['RUN_01/seed2038_eps1/'+p.name]
    assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
source=ROOT/'original/srg_golden_tower_II.py'
assert source.stat().st_size==34980 and sha(source)=='147a32be3b6d6aad17ada6ab7be2fbc3994c3363f74d6a2b351fb8eecda80304'
sl=source.read_text().splitlines();ex=(ROOT/'context/R0/audited_golden_core.py').read_text().splitlines()
assert len(sl)==842 and ex[8:]==sl[30:254]
orig_ast=ast.parse(source.read_text()); ex_ast=ast.parse('\n'.join(ex))
orig_class=next(x for x in orig_ast.body if isinstance(x,ast.ClassDef) and x.name=='GoldenTowerFieldII')
ex_class=next(x for x in ex_ast.body if isinstance(x,ast.ClassDef) and x.name=='GoldenTowerFieldII')
assert ast.dump(orig_class)==ast.dump(ex_class)
external_order=Path('/mnt/data/SRG_SIM06_TOWER_II_CONSTRUCTION_HANDOFF_20261024/CODEX_SIM06_TOWER_II_CONSTRUCTION_WORK_ORDER.md')
assert external_order.read_bytes()==(ROOT/'WORK_ORDER.md').read_bytes()
assert Path('/mnt/data/START_HERE(10).md').read_bytes()==(ROOT/'START_HERE.md').read_bytes()
# Compare supplied context files to the previously supplied handoff when available.
handoff=Path('/mnt/data/SRG_SIM06_TOWER_II_CONSTRUCTION_HANDOFF_20261024.zip')
with zipfile.ZipFile(handoff) as z:
    prior_by_sha={hashlib.sha256(z.read(n)).hexdigest():n for n in z.namelist() if not n.endswith('/')}
prior_matches=[{'copy':e['copy'],'handoff_member':prior_by_sha[e['sha256']]} for e in bl if e['sha256'] in prior_by_sha]

# Numeric inputs never modified. Verify schema before computation.
arr={p.stem:np.load(p,allow_pickle=False,mmap_mode='r') for p in RUN.glob('*.npy')}
X,V,R=arr['X'],arr['V'],arr['R'];bands=arr['band_id'];freq=arr['natural_freq']
assert X.shape==V.shape==(601,80,3) and R.shape==(601,80)
assert all(np.isfinite(a).all() for a in arr.values())
assert np.array_equal(np.diff(X,axis=0),V[1:]) and np.all(V[0]==0)
assert np.array_equal(arr['actual_rpc_output'],R[1:])
assert np.array_equal(arr['positions_at_rpc']+arr['noise'],X[1:])
assert np.array_equal(np.bincount(bands),[20]*4)
group=[np.flatnonzero(bands==b) for b in range(4)]
assert group[0][:3].tolist()==[4,8,9]
assert all(np.unique(freq[g]).size==1 for g in group)
assert np.all(R>0)
geom=csvrows(ROOT/'derived/geometry.csv');bgeom=csvrows(ROOT/'derived/band_geometry.csv')
graph=csvrows(ROOT/'derived/graph_boundaries.csv');points=csvrows(ROOT/'derived/selected_points.csv')
nei=csvrows(ROOT/'derived/selected_point_neighbors.csv'); members=js(ROOT/'derived/graph_memberships.json')
diag=csvrows(RUN/'pass_diagnostics.csv')
assert len(geom)==601 and len(bgeom)==2404 and len(graph)==600 and len(points)==1803 and len(diag)==600
assert [int(d['pass']) for d in diag]==list(range(1,601))
assert [int(d['input_R_state']) for d in diag]==list(range(600))
assert [int(d['state']) for d in geom]==list(range(601))
assert all(int(d['state'])==s and int(d['band'])==b for (s,b),d in zip(((s,b) for s in range(601) for b in range(4)),bgeom))
mu=np.mean(X,axis=1);offset=X-mu[:,None,:]
rg2=np.mean(np.einsum('sij,sij->si',offset,offset),axis=1);rg=np.sqrt(rg2)
cent=np.stack([np.mean(X[:,g,:],axis=1) for g in group],axis=1)
within_b=np.stack([np.mean(np.einsum('sij,sij->si',X[:,g,:]-cent[:,b,None,:],X[:,g,:]-cent[:,b,None,:]),axis=1) for b,g in enumerate(group)],axis=1)
within=within_b.mean(axis=1);between=np.mean(np.sum((cent-mu[:,None,:])**2,axis=2),axis=1)
speed=np.linalg.norm(V,axis=2)
max_err={};checked={}
def test(label,a,b,atol=3e-12,rtol=3e-13):
    a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float)
    assert a.shape==b.shape,(label,a.shape,b.shape)
    err=float(np.max(np.abs(a-b))) if a.size else 0.0
    max_err[label]=max(max_err.get(label,0.0),err);checked[label]=checked.get(label,0)+int(a.size)
    if not np.allclose(a,b,atol=atol,rtol=rtol):raise AssertionError((label,err))
def col(rows,k):return [float(r[k]) for r in rows]
for k,a in [('Rg_reused_R1_R2',rg),('within_band_variance',within),('between_band_variance',between),('centroid_x',mu[:,0]),('centroid_y',mu[:,1]),('centroid_z',mu[:,2]),('centroid_displacement_from_0',np.linalg.norm(mu-mu[0],axis=1)),('mean_abs_R_reused_R1_R2',np.abs(R).mean(axis=1)),('mean_completed_step',speed.mean(axis=1)),('max_completed_step',speed.max(axis=1))]:test('geometry/'+k,a,col(geom,k))
test('geometry/L_used',arr['L_used'],col(geom[1:],'L_for_completed_pass'))
test('geometry/mean_GRF',np.mean(1/(1+speed[1:]),axis=1),col(geom[1:],'mean_grf_reused_R1'))
# Readout comparison only, not compressor evaluation or recurrence check.
test('L_affine_incoming_readout',9*(1+np.mean(np.abs(R[:-1]),axis=1)),arr['L_used'])
test('incoming_mean_abs_R',np.mean(np.abs(R[:-1]),axis=1),arr['incoming_mean_abs_R'])
for b,g in enumerate(group):
    rows=bgeom[b::4];off=X[:,g,:]-cent[:,b,None,:]
    for k,a in [('center_x',cent[:,b,0]),('center_y',cent[:,b,1]),('center_z',cent[:,b,2]),('Rg',np.sqrt(within_b[:,b])),('center_displacement_from_0',np.linalg.norm(cent[:,b]-cent[0,b],axis=1)),('center_step',np.r_[0,np.linalg.norm(np.diff(cent[:,b],axis=0),axis=1)]),('rms_offset_change_from_0',np.sqrt(np.mean(np.sum((off-off[0])**2,axis=2),axis=1)))]:test('band_geometry/'+k,a,col(rows,k))
    assert all(int(r['count'])==20 and float(r['frequency'])==float(freq[g[0]]) for r in rows)
for idx,i in enumerate([4,8,9]):
    rr=points[idx::3]; assert all(int(r['id'])==i and int(r['state'])==s and int(r['band'])==0 for s,r in enumerate(rr))
    for k,a in [('x',X[:,i,0]),('y',X[:,i,1]),('z',X[:,i,2]),('distance_from_band_center',np.linalg.norm(X[:,i]-cent[:,0],axis=1))]:test('selected_points/'+k,a,col(rr,k))
assert js(ROOT/'derived/band_membership.json')=={str(b):g.tolist() for b,g in enumerate(group)}
# Rebuild only instantaneous graphs on saved inputs, using a different distance expression.
min_cutoff_gap=float('inf');min_nonself=float('inf');self_edges=0;tie_rows=0
union_rows=[];snapshot_records={};neighbors_by_state={};changes=[];last_n=None
same_band=bands[:,None]==bands[None,:];np.fill_diagonal(same_band,False)
for s in range(600):
    dx=np.asarray(X[s])[:,None,:]-np.asarray(X[s])[None,:,:]
    dist=np.sqrt(np.einsum('ijk,ijk->ij',dx,dx));order=np.argsort(dist,axis=1)
    nbr=order[:,1:6]
    sd=np.take_along_axis(dist,order,axis=1)
    min_cutoff_gap=min(min_cutoff_gap,float((sd[:,6]-sd[:,5]).min()))
    min_nonself=min(min_nonself,float(sd[:,1].min()))
    tie_rows+=int(np.count_nonzero(sd[:,6]==sd[:,5]))
    self_edges+=int(np.count_nonzero(nbr==np.arange(80)[:,None]))
    A=np.zeros((80,80),dtype=bool);A[np.arange(80)[:,None],nbr]=True
    gs=components(A);nweak=len(gs);nstrong=scc_count(A);nsame=int(np.sum(A&same_band));row=graph[s]
    got={'incoming_state':s,'drives_saved_pass':s+1,'weak_components':nweak,'strong_components':nstrong,'same_band_edges':nsame,'cross_band_edges':400-nsame}
    for b,g in enumerate(group):got[f'band_{b}_induced_weak_components']=len(components(A[np.ix_(g,g)]))
    assert all(int(row[k])==v for k,v in got.items()),(s,got,row)
    if last_n is not None and last_n!=nweak:changes.append({'incoming_state':s,'from':last_n,'to':nweak})
    last_n=nweak
    if str(s) in members:
        data=[{'ids':ids,'band_counts':np.bincount(bands[ids],minlength=4).tolist()} for ids in gs]
        assert data==members[str(s)],s
        neighbors_by_state[s]=nbr
        snapshot_records[str(s)]=dict(got,components=data)
    # Additional structural analysis: local selection plus all same-band fusion dependencies.
    U=A|same_band
    union_rows.append({'incoming_state':s,'drives_saved_pass':s+1,'local_weak_components':nweak,'local_strong_components':nstrong,'with_band_fusion_weak_components':len(components(U)),'with_band_fusion_strong_components':scc_count(U),'local_edges':int(A.sum()),'additional_same_band_directed_pairs':int(np.sum(same_band&~A))})
for r in nei:
    s=int(r['incoming_state']);i=int(r['id']);nn=sorted(neighbors_by_state[s][i].tolist())
    assert r['neighbors_ascending_id']==' '.join(map(str,nn))
    assert r['neighbor_bands_same_order']==' '.join(str(int(bands[j])) for j in nn)
summary=js(ROOT/'derived/inspection_summary.json');assert summary['weak_component_count_changes']==changes
assert self_edges==0 and tie_rows==0
for e in summary['episode_descriptions']:
    a,b=e['start_state'],e['end_state']
    calc={'whole_center_displacement':float(np.linalg.norm(mu[b]-mu[a])),'Rg_start':rg[a],'Rg_end':rg[b],'band0_center_displacement':float(np.linalg.norm(cent[b,0]-cent[a,0])),'band0_Rg_start':np.sqrt(within_b[a,0]),'band0_Rg_end':np.sqrt(within_b[b,0]),'mean_completed_step_min':speed[a+1:b+1].mean(axis=1).min(),'mean_completed_step_max':speed[a+1:b+1].mean(axis=1).max()}
    for k,v in calc.items():test('episodes/'+k,[v],[e[k]])
# Source observer only: first-lock times from already stored amplitudes.
locks={}
for b,g in enumerate(group):
    vals=np.abs(R[1:,g]);mean=vals.mean(axis=1);coh=1-vals.std(axis=1)/(mean+1e-10)
    idx=np.flatnonzero((coh>.7)&(mean>.01))
    if idx.size:locks[str(b)]=int(idx[0]+1)
assert locks==js(RUN/'source_lock_times.json')
original=csvrows(ROOT/'original/self_coupled_breathing.csv')
eps1=next(r for r in original if float(r['epsilon'])==1)
original_comp={
    'R_mean':float(np.abs(R[200]).mean()),'L_mean':float(arr['L_used'][:200].mean()),
    'L_std':float(arr['L_used'][:200].std()),'L_range':float(np.ptp(arr['L_used'][:200])),
    'surviving_bands':int(sum(np.abs(R[200,g]).mean()>.01 for g in group))}
for k,v in original_comp.items():test('historical_aggregate/'+k,[v],[float(eps1[k])])
# No FFT, no estimate of periodicity, no extra execution of either control.
assert all(int(d['log_clip_count'])==0 for d in diag)
readout_fields={'historical_rows':len(original),'checked_epsilon':1,'checked_non_spectral_fields':original_comp,'source_recorded_dominant_frequency':float(eps1['L_dom_freq']),'spectral_recomputation':False,'retained_selected_diagnostic_clip_count_sum':sum(int(d['log_clip_count']) for d in diag)}
# Figures: limits and declared normalization from fixed records; no new rendering.
reg=js(ROOT/'FIGURE_REGISTER.json')
assert len(reg['F01']['states'])==6
assert np.max(np.abs(X[reg['F01']['states']]))<5.5
for spec in reg['F02']['panels']:
    s=spec['normalized_state'];g=group[0];z=(X[s,g]-cent[s,0])/np.sqrt(within_b[s,0])
    assert np.max(np.abs(z))<spec['normalized_halfspan']
    test('figure2/band_Rg',[np.sqrt(within_b[s,0])],[spec['actual_band_Rg']])
    a,b=spec['path_window'];pts=X[a:b+1,[4,8,9]]
    assert np.max(np.abs(pts-np.array(spec['path_world_center'])))<spec['path_axis_halfspan']
# Newly authored Markdown links (legacy context preserved separately).
links=[]
for name in ['START_HERE.md','CONSTRUCTION.md','ORIGINAL_EVIDENCE_AND_EXISTING_REPLAY.md','MOTION_AND_GEOMETRY.md','MODEL_RELATIONSHIPS.md','RECORD_SELECTION.md']:
    for target in re.findall(r'\]\(([^)]+)\)',(ROOT/name).read_text()):
        if '://' in target or target.startswith('#'):continue
        target=unquote(target.split('#')[0]); links.append({'document':name,'target':target,'exists_in_archive':(ROOT/target).exists()})
# Scope note: REVIEW_ZIP_IDENTITY.json is declared external to archive, so not a science blocker.
missing_links=[l for l in links if not l['exists_in_archive']]

def snap(s):
    return {'state':s,'Rg':float(rg[s]),'within_band_variance':float(within[s]),'between_band_variance':float(between[s]),'between_fraction':float(between[s]/rg2[s]),'band0_Rg':float(np.sqrt(within_b[s,0])),'band0_center_displacement_from_initial':float(np.linalg.norm(cent[s,0]-cent[0,0])),'mean_R':float(R[s].mean()),'mean_completed_displacement':float(speed[s].mean()),'maximum_completed_displacement':float(speed[s].max())}
findings={'scope':'New passive description of one preexisting R1 record; no update or RNG draw.',
    'snapshots':[snap(s) for s in [0,7,10,20,100,200,400,599,600]],
    'lock_times':locks,'first_local_weak_split_state':changes[0]['incoming_state'],
    'snapshot_graphs':snapshot_records,
    'augmented_dependency_graph':{'definition':'Union of directed local selections and all ordered distinct same-band pairs representing band-center dependencies; not a new force or executed update.',
        'boundaries':600,'weak_count_range':[min(x['with_band_fusion_weak_components'] for x in union_rows),max(x['with_band_fusion_weak_components'] for x in union_rows)],
        'strong_count_range':[min(x['with_band_fusion_strong_components'] for x in union_rows),max(x['with_band_fusion_strong_components'] for x in union_rows)],
        'qualified_interpretation':'Structural connectivity of dependencies does not establish synchronization, transmission speed, physical causality, or a nonzero instantaneous numerical sensitivity for every edge.'},
    'contraction':{'whole_Rg_reduction_percent_0_200':float(100*(1-rg[200]/rg[0])),'whole_Rg_reduction_percent_0_600':float(100*(1-rg[600]/rg[0])),'band0_Rg_ratio_200_to_600':float(np.sqrt(within_b[200,0]/within_b[600,0])),'between_fraction_0':float(between[0]/rg2[0]),'between_fraction_200':float(between[200]/rg2[200]),'between_fraction_600':float(between[600]/rg2[600])},
    'no_extrapolation':'600 is last saved boundary. All graph facts refer to inputs 0..599; no hypothetical 601st pass inspected.'}
final={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*') if p.is_file()}
assert initial==final
report={'date':'2026-10-24','execution':{'new_updates':0,'RNG_draws':0,'historical_module_imports':0,'submitted_checker_executions':0,'new_scientific_figures':0,'spectral_audits':0},
 'archive':{'bytes':Path('/mnt/data/SRG_SIMULATION_STUDY_06_TOWER_II_CONSTRUCTION_01_REVIEW.zip').stat().st_size,'sha256':sha(Path('/mnt/data/SRG_SIMULATION_STUDY_06_TOWER_II_CONSTRUCTION_01_REVIEW.zip')),'payloads':len(man['files']),'total_files':len(initial),'baseline_input_copies_verified':len(bl),'matching_R1_files':len(r1files),'earlier_handoff_matches':prior_matches,'manifest_errors':errors,'source_lines':len(sl),'source_class_AST_matches_excerpt':True,'supplied_work_order_matches_authority':True},
 'fixed_record_checks':{'finite_arrays':len(arr),'boundaries':601,'point_state_rows':601*80,'displacement_components_exact':int(V[1:].size),'R_equals_saved_RPC_output':True,'X_equals_saved_postfusion_plus_saved_noise':True,'band_counts':[len(g) for g in group],'all_saved_R_positive':True},
 'passive_numeric_checks':{'tested_scalar_count':sum(checked.values()),'counts':checked,'maximum_absolute_errors':max_err,'variance_identity_max_abs_error':float(np.max(np.abs(rg2-within-between)))},
 'graph_checks':{'boundaries':600,'directed_selections':600*80*5,'all_counts_and_7_membership_snapshots_match':True,'all_selected_neighbor_rows_match':True,'self_selections':self_edges,'cutoff_tied_rows':tie_rows,'minimum_5th_6th_distance_gap':min_cutoff_gap,'minimum_distinct_point_distance':min_nonself},
 'historical_comparison':readout_fields,'missing_direct_document_links':missing_links,'source_package_unchanged_after_review':initial==final,
 'provenance_limits':'Input files match retained manifests and available previous handoff copies. No fresh access to Windows or historical original run; hashes do not prove nonexecution.',
 'environment':{'python':platform.python_version(),'numpy':np.__version__}}
save('VERIFICATION.json',report);save('FINDINGS.json',findings);writecsv('combined_dependency_graph.csv',union_rows)
save('INPUT_IDENTITIES.json',initial)
print(json.dumps({'integrity':report['archive'],'fixed_record_checks':report['fixed_record_checks'],'graphs':report['graph_checks'],'hist':readout_fields,'numeric_max_error':max(max_err.values()),'union':findings['augmented_dependency_graph'],'contraction':findings['contraction'],'missing_links':missing_links},indent=2))
