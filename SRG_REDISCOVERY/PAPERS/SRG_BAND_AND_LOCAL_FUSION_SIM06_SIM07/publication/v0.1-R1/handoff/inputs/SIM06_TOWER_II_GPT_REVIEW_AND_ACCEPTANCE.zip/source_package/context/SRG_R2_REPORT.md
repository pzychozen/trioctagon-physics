# SRG-R2 — amplification, geometry, and mixing-off controls

10 October 2026. Completed independent mathematical audit and bounded execution.

Disabling only explicit additive mixing reduced the 600-pass net mean-resonance gain by **99.6553% for seed 2038** and **99.4654% for seed 42**. Mean resonance still rose about 4.6–5.0% from its initial value. Both controls compacted spatially, but their final radius of gyration squared was about 195 and 253 times the matched R1 baseline value. These are actual coupled control trajectories, not baseline budgets with a column subtracted.

GPT's stage decomposition, positive-cone argument, ordered gain budget, and conditional coordinatewise-box result are confirmed under their stated assumptions. No recurrence disagreement was found. The new evidence separates phi/sum/difference budgets, supplies counterexamples to stronger conservation/geometric claims, accounts for paired operator changes, and includes the two newly executed controls.

## Evidence and scope

The human request authorizes bounded R2 execution after successful preflight. The attached work order supplies its scope; the review's mathematical claims were independently checked against code. R1 remains accepted within its existing scope and is not revised.

| Evidence class | Files and role |
| --- | --- |
| Historical source | sources/srg_golden_tower_II.py, read only; audited_golden_core.py, exact accepted excerpt |
| Received reviewer evidence | received/SRG_R1_GPT_DECISION_20261010/, including review, checker, arithmetic and receipts |
| Independent stage evidence | stage_oracle.py, BASELINE_AUDIT_01/, CONTROL_AUDIT_01/ |
| Actual new source execution | PREFLIGHT_01/ and RUN_01/ |
| Paired diagnostics | COMPARISON_01/ and FINAL_CHECKS_02/ |

The core SHA-256 is 6b2f0a05df5871abe4fe97a9e56abd233ab55952028ae953a4b7a652fb24d5e8. After its eight-line R0 prefix, it matches historical source lines 31–254. Full source SHA-256 is 147a32be3b6d6aad17ada6ab7be2fbc3994c3363f74d6a2b351fb8eecda80304. The historical launcher was never imported.

The reused baselines are R1 seed2038_eps0 and seed42_eps0, from the accepted R1 ZIP with SHA-256 aa9a538979d773deb363e7a14398cc2f8b794840fdc9e40a9cf46586516e6f18. Full baseline raw arrays are referenced rather than duplicated in the R2 ZIP. Their newly reconstructed stages and budgets are included.

Source locators below refer to the full source: constants/H/RPCO 31–46; constructor/assignments 62–109; adjacency 111–127; pass ordering 129–215; diffusion 142–148; exchange/mixing 150–190; H 192–194; fusion 196–206; RPCO 208–209; noise/velocity 211–215. The corresponding audited-excerpt line is historical line minus 22.

## 1. Source-exact conditional resonance map

Let p>=1 be the source pass number and X,R the incoming state, row p−1. Frequencies are fixed labels \(\omega_i=.244\phi^n\), \(n\in\{-2,-1,0,1\}\), with \(\phi=(1+\sqrt5)/2\). Equal band assignments are shuffled once. Incoming geometry selects five directed neighbors. With no horizon, the source uses argsort(distance)[1:6], then binary adjacency and increasing neighbor-index iteration. It does not explicitly remove the self index in that branch; its tie behavior is preserved.

On active rows:

\[
w^*_{ij}=A_{ij}\frac{\exp[-2\log^2(\omega_j/\omega_i)]}{\|X_j-X_i\|+10^{-8}},
\quad W_{ij}=\frac{w^*_{ij}}{\sum_jw^*_{ij}},
\quad P_{ij}=.85\delta_{ij}+.15W_{ij}.
\]

Active means at least one neighbor and raw weight sum >=1e−10. Otherwise P's row is the identity row, \(d_i=1\), and every K row below is zero. That resonance row skips sine and mixing. Weight underflow does not skip spatial diffusion if neighbors exist; these are distinct branches.

On active rows \(d_i=1+.01\sin(2\pi\omega_i p)\), \(D=\mathrm{diag}(d_i)\). For selected neighbors with \(|\omega_i-\omega_j|>.01\):

\[
(K_\phi)_{ij}=\eta\sum_{q\in\{-2,-1,1,2\}}
\exp\{-5[\log(\omega_i/\omega_j)-\log(\phi^q)]^2\},
\]
\[
(K_\Sigma)_{ij}=\tfrac12\eta\sum_{f\in\mathcal T}
1_{|\omega_i+\omega_j-f|/f<.2},
\]
\[
(K_\Delta)_{ij}=\tfrac12\eta\,1_{|\omega_i-\omega_j|>.01}
\sum_{f\in\mathcal T}1_{||\omega_i-\omega_j|-f|/f<.2}.
\]

Other entries vanish. Every matching tower label adds a term; the code does not select only one match. Set \(K=K_\phi+K_\Sigma+K_\Delta\). Strength .001, multiplier .5, Gaussian width 5, powers, .01 cutoff and .2 tolerance are assigned source coefficients, not estimated couplings. There is no compensating outgoing subtraction. Sum/difference tests add amplitudes from existing neighbors; they do not generate new bands or frequency labels.

\[
H(t)=2e^{-.5t}\cos t+e^{-.3t}\sin t+1.5e^{-.7t}+e^{-.4t},
\quad m_p=1+.05H(p)/H_{MAX},
\]
\[
B=PR,\quad F=DB,\quad G_a=K_aR,\quad
S=F+G_\phi+G_\Sigma+G_\Delta,\quad
\boxed{Q=m_p(DP+K)R}.
\]

This is the exact real-arithmetic resonance expression before RPCO, conditional on geometry, labels and pass. P depends continuously on distances within a fixed selected graph. K's pair coefficients depend on labels/eta; geometry affects their incidence and guard activity. Despite the source's “nonlinear mixing” label, KR is linear in R at frozen geometry. Future geometry depends on Q, so the full coupled trajectory is not a fixed linear recurrence. Matrix regrouping is only an observer; source arithmetic order remains unchanged during execution.

The actual final resonance map is

\[
R_i^+=\operatorname{sgn}(Q_i)
\exp[\operatorname{clip}(\log(|Q_i|+10^{-9}),-L,L)],\qquad L=9.
\]

## 2. Positivity, row bounds, and their limits

Assume t>=0, finite positive frequencies, well-defined weights/branches, beta=.15, sine amplitude .01, lambda_H=.05, eta>=0, and finite real states. Then P>=0, P1=1, D has entries >=.99, and K>=0. The retained diagonal of P is at least .85 on active rows and one on skipped rows.

Since \(|H(t)|\le2+1+1.5+1=5.5\), and the source sampling of H_MAX includes t=0 where H(0)=4.5, H_MAX>=4.5. Hence

\[
m_p\ge1-.05(5.5/4.5)=169/180>0.
\]

Independent source-grid evaluation gives H_MAX=4.500000000001. Therefore R>=0 implies Q>=0 and RPCO returns R+>=0. Strictly positive R yields strictly positive Q through the retained diagonal and a positive finite RPCO result. If R=0, then Q=0 and sign(0)=0, so R+=0 despite the log guard; positions/noise can still evolve. This proves positive-cone invariance in the stated exact-arithmetic domain. It does not cover negative eta or guarantee against machine overflow.

For \(M=m_p(DP+K)\ge0\), \(s_i=\sum_jM_{ij}\), each row satisfies \(\min(R)s_i\le Q_i\le\max(R)s_i\). Consequently:

\[
\min(R)\min_i s_i\le\min_i Q_i\le\max_i Q_i\le\max(R)\max_i s_i.
\]

A uniform max-row-sum bound <=q<1 over all relevant states/passes gives pre-RPCO infinity-norm shrinkage. A uniform min-row-sum bound >=q>1 gives pre-RPCO minimum growth for strictly positive R. These premises must hold throughout the evolution. Positive unclipped RPCO gives \(R^+=MR+10^{-9}\mathbf1\) in real arithmetic, so even uniform q<1 supplies an additive-offset bound rather than decay to zero. Upper clipping defeats unrestricted expansion. A bound on one recorded path is not incremental contraction between paths whose M matrices differ. Frozen-matrix eigenvalues do not settle the time-dependent coupled system.

| Seed / condition | Min row sum | Max row sum | Passes all rows >1 | Passes all rows <1 |
| --- | ---: | ---: | ---: | ---: |
| 2038 baseline | .990000211049 | 1.051657777737 | 61 | 0 |
| 2038 mixing off | .990000010919 | 1.040225291111 | 38 | 36 |
| 42 baseline | .990000010919 | 1.052182778101 | 61 | 0 |
| 42 mixing off | .990000010919 | 1.040225291111 | 38 | 36 |

Neither every-pass uniform expansion nor contraction follows from these records. All actual R and Q stayed strictly positive. No empty-neighbor or weight-sum guard row occurred; separate finite algebraic fixtures exercise both branches without field calls.

P1=1 preserves constants; it does not imply arithmetic-mean conservation. That requires the column condition \(\mathbf1^TP=\mathbf1^T\). Specifically,

\[
\mu(PR)-\mu(R)=N^{-1}(\mathbf1^TP-\mathbf1^T)R.
\]

For W=[[0,1,0],[1,0,0],[1,0,0]], P=.85I+.15W and R=(1,2,3), row sums are one, column sums are (1.15,1,.85), and output mean is 1.9 rather than 2. Actual maximum column-sum defects are .288120/.343444 for baselines and .279944/.276120 for controls. The finite counterexample and every-pass column identity are retained.

## 3. Independent ordered gain accounting

The exact ordered identity is

\[
R^+-R=(B-R)+(F-B)+G_\phi+G_\Sigma+G_\Delta+(Q-S)+(R^+-Q).
\]

Machine evidence uses independently regrouped \(\widehat Q\) for the H term \(\widehat Q-S\), actual source RPCO offset \(R^+-Q_{\rm actual}\), and separate reconstruction residual \(Q_{\rm actual}-\widehat Q\). Their sum telescopes to actual \(R^+-R\). Neither log/exp rounding nor regrouping residual is discarded.

All 1,200 baseline incoming states were reconstructed independently. Maximum Q error was 2.220446049250313e−15; maximum fusion-position error 8.881784197001252e−16, against a declared 5e−13 absolute tolerance. Cumulative baseline budgets agree with GPT's table within about 2e−15, against a 1e−10 tolerance. Control maxima were 1.1102230246251565e−16 for Q and 4.440892098500626e−16 for fusion. Largest budget closure residual across all paths was below 3.65e−17. These are measured floating residuals, not interval enclosures.

| Contribution to mean R, summed over 600 passes | 2038 baseline | 2038 mixing off | 42 baseline | 42 mixing off |
| --- | ---: | ---: | ---: | ---: |
| Exchange | −.170423395583 | +.000775233891 | −.214466344585 | +.001228235121 |
| Imposed sine | −.015650720209 | −.000983548844 | −.010460044804 | −.000953661630 |
| Phi proximity | +1.467390429780 | 0 | +1.142927058251 | 0 |
| Sum match | +.286398385626 | 0 | +.248839099257 | 0 |
| Difference match | +.455535650226 | 0 | +.315506026595 | 0 |
| H modulation | +.007308561446 | +.007207093223 | +.007790479890 | +.007690500353 |
| Actual RPCO offset | +6.00000020972e−7 | +5.99999999810e−7 | +6.00000019326e−7 | +5.99999999739e−7 |
| Q reconstruction residual | +1.68477e−14 | +2.54284e−15 | +1.60938e−14 | +2.75465e−15 |
| **Net change** | **+2.030559511286** | **+.006999378271** | **+1.490136874606** | **+.007965673844** |

Explicit mixing is the dominant positive baseline contribution, with phi proximity the largest of its three channels. H follows the additions, so its scaling is assigned to H rather than redistributed across prior terms. In controls, H is comparable to the entire small net gain. Exchange becomes slightly positive; imposed sine remains cumulatively negative. Individual passes need not share those cumulative signs. This ordered path accounting is distinct from the actual long-horizon intervention.

## 4. Geometry guarantees and explicit counterexamples

With incoming adjacency, define \(\Delta_i=\mathrm{mean}_{j\in N_i}(X_j-X_i)\), zero on empty rows. Diffusion is \(Y=X+.05\Delta+.15\tanh\Delta\), coordinatewise. For nonempty rows:

\[
c_{ia}=.05+.15\frac{\tanh\Delta_{ia}}{\Delta_{ia}},\qquad
Y_{ia}=(1-c_{ia})X_{ia}+c_{ia}\overline X_{N_i,a}.
\]

At Delta=0 the continuous ratio is one, so c=.20 and that coordinate stays unchanged. For finite nonzero Delta, \(0<\tanh\Delta/\Delta<1\), hence \(.05<c\le.20\). Empty rows are exactly unchanged. Each scalar coordinate is a convex combination of values inside its incoming coordinate range, proving coordinatewise-box nonexpansion.

This does not prove full 3D convex-hull preservation. Take points (0,0,0) and (1,2,0). The first diffused point is (.05+.15 tanh(1), .10+.15 tanh(2), 0); its y coordinate is not twice its x coordinate. It leaves the line-segment hull while staying inside the box. The finite fixture records the nonzero cross product.

For bands with at least two members:

\[
c_b=\frac{\sum_{i\in b}(|Q_i|+10^{-8})Y_i}{\sum_{i\in b}(|Q_i|+10^{-8})},
\quad a_i=.02Q_i,\quad Z_i=(1-a_i)Y_i+a_i c_b.
\]

Center weights are positive even at Q=0. If \(0\le Q_i\le50\), then \(0\le a_i\le1\), so fusion stays inside that band's Y box and Y convex hull. Singleton/empty bands are skipped. This does not restore the original X convex hull after diffusion.

For Q>50 the guarantee ends: Y=(−1,+1) on a line and Q=150 gives a=3, center zero and Z=(+2,−2), outside the box. Fusion uses pre-RPCO Q; clipping later cannot retroactively prevent its overshoot. The fixture is recorded.

Finally \(X^+=Z+\xi_p\), with original Gaussian noise standard deviation .01/(1+.01p), and \(V^+=X^+-X\). The declining noise schedule is externally prescribed. These deterministic box results do not imply monotone radius of gyration, pairwise distances, a fixed centroid, a fixed global box after noise, or convergence. Directed diffusion and unequal fusion coefficients need not preserve arithmetic centroids.

Define \(Rg^2(X)=N^{-1}\sum_i\|X_i-\overline X\|^2\). Y is independently reconstructed; Z/noise are actual captures.

| Seed / condition | Initial Rg² | Final Rg² | Sum diffusion ΔRg² | Sum fusion ΔRg² | Sum noise ΔRg² |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2038 baseline | 27.68407762 | .003024498488 | −5.548017741 | −22.10703799 | −.025997396 |
| 2038 mixing off | 27.68407762 | .589336665810 | −5.409308044 | −21.65794562 | −.027487291 |
| 42 baseline | 25.34088964 | .002871479902 | −5.037674296 | −20.30859335 | +.008249485 |
| 42 mixing off | 25.34088964 | .726956917743 | −4.734020985 | −19.89035027 | +.010438535 |

| Seed / condition | Minimum .02Q | Maximum .02Q | Diffusion increases Rg² | Noise increases Rg² |
| --- | ---: | ---: | ---: | ---: |
| 2038 baseline | .000464306434 | .060480009869 | 194 | 336 |
| 2038 mixing off | .000454463315 | .005728351766 | 275 | 311 |
| 42 baseline | .000570592815 | .046967202776 | 254 | 322 |
| 42 mixing off | .000547377195 | .005839263326 | 347 | 302 |

Increase counts use ΔRg²>1e−14. The audit JSON key ending “above_1e14” has a missing minus sign in its label; the implemented threshold is 1e−14. Counts/data were not changed. No Q<0 or Q>50 crossing occurred. Global diffusion/fusion and same-band fusion box violations were zero (checks allow 5e−13 reconstruction tolerance). Fusion never increased Rg² by >1e−14 on these paths, which is an observation rather than a general theorem. Diffusion increased Rg² on many passes despite its box bound.

The full geometry tables retain x/y/z min/max/ranges at incoming, diffusion, fusion and noise stages for every pass. Band tables retain all four arithmetic centroids at each stage, their movements, weighted fusion centers and per-band raw R statistics. Stage sums are telescoping measurements along actual paths, not separate causal ablations.

## 5. Actual control and first-divergence evidence

The only model intervention from R1 epsilon=0 was the existing constructor option nonlinear_strength=0.0 instead of .001. Both runs retain seeds 2038/42, N=80, four bands, 600 passes, width=2, breathing=false, epsilon=0, k=5, alpha=.05, beta=.15, lambda_H=.05, L=9, horizon=None. Source initialization is uniform [−5,5]^3 for X and [0,.3] for R. Fixed labels, shuffle, H, sine, diffusion, fusion, signed RPCO and noise remain.

Preflight used two logged seed-2038 calls: uninstrumented and instrumented source passes from identical initialization. X/V/R and RNG agreed exactly. Independent eta=0 algebra passed; the matched baseline first pass came from saved R1. In common initial geometry:

\[
Q_b-Q_c=m_1K_bR_0.
\]

Its maximum preflight residual was 1.51e−16. Initial diffusion Y is shared, but Q changes both fusion coefficients and weighted centers:

\[
Z_{b,i}-Z_{c,i}=.02[Q_{b,i}(c_{b,\mathrm{band}(i)}-Y_i)
-Q_{c,i}(c_{c,\mathrm{band}(i)}-Y_i)].
\]

Fusion-difference residual was <=4.45e−16. Identical noise leaves this same-pass X difference in V as well. Saved completed controls independently verify the Q identity for both seeds. R1's bound-only intervention was inactive at RPCO; that earlier delay logic does not apply to mixing.

| Seed | First differing Q/R/X/V pass | Max \|ΔQ\| at pass 1 | Max \|ΔX\|=\|ΔV\| at pass 1 | First changed incoming graph |
| --- | --- | ---: | ---: | ---: |
| 2038 | 1 / 1 / 1 / 1 | .00208476304247 | .000206614592199 | 15 |
| 42 | 1 / 1 / 1 / 1 | .00249200438635 | .000251035324406 | 7 |

| Seed | Initial mean R | Baseline final mean R | Control final mean R | Control gain factor |
| --- | ---: | ---: | ---: | ---: |
| 2038 | .151692819189 | 2.182252330475 | .158692197459 | 1.046141790 |
| 42 | .160075758197 | 1.650212632803 | .168041432041 | 1.049761900 |

| Seed / condition | Final R minimum | Final R maximum | Final R standard deviation |
| --- | ---: | ---: | ---: |
| 2038 baseline | 1.628363474 | 2.667658892 | .271252439 |
| 2038 mixing off | .121479851 | .207937424 | .020762785 |
| 42 baseline | .706617446 | 2.128900286 | .466686782 |
| 42 mixing off | .070288728 | .237354412 | .040455441 |

Initial X/V/R, labels, full initial/final RNG checkpoints, every before/after-pass RNG fingerprint, and every actual noise array match the saved baseline exactly within each seed. This is a local same-runtime comparison, not a cross-platform bitwise claim. Every post-initial control R component was below its baseline counterpart (48,000 comparisons per seed); this is not a theorem about other seeds, longer times, or positions.

Both controls have zero lower/upper log crossings and zero effective-clipping entries. Minimum log margins are 5.215630 and 5.401651. The unclipped signed log/exp expression is bitwise equal to actual RPCO for all baseline and control values; four compressed all-zero difference arrays are retained. The 1e−9 offset and log/exp arithmetic remain, while bounds are inactive. No counterfactual output entered execution.

### Remaining budgets: changed R and changed geometry

Graphs differ on 580/586 passes; cumulative paired directed-edge symmetric differences are 172,610/159,916. P's continuous weights can change earlier than adjacency, beginning at pass 2. Full 4x4 receiving-band versus donor-band tables per pass retain selected/active edge counts, normalized W weight sums and all K channel coefficient sums. Every path has 400 selected/active edges per pass; no guard row occurred.

The additional saved-state identity

\[
\mu[(P_b-I)R_b-(P_c-I)R_c]
=\mu[(P_b-I)(R_b-R_c)]+\mu[(P_b-P_c)R_c]
\]

separates the R difference at baseline P from the changed geometry/graph operator on control R. Since labels and active-row status match, D is identical at matched passes. Sine-budget differences split analogously:

\[
\mu[(D-I)P_b(R_b-R_c)]+\mu[(D-I)(P_b-P_c)R_c].
\]

| Cumulative baseline-minus-control budget | Seed 2038 | Seed 42 |
| --- | ---: | ---: |
| Exchange total difference | −.171198629474 | −.215694579706 |
| Exchange R component at baseline P | −.180939579177 | −.231425175003 |
| Exchange changed-P component on control R | +.009740949703 | +.015730595297 |
| Sine total difference | −.014667171366 | −.009506383174 |
| Sine R component at baseline P | −.014629557319 | −.009468436271 |
| Sine changed-P component on control R | −.000037614047 | −.000037946902 |

Maximum single-pass residual is below 1.17e−16. Geometry/weights contribute measurably and partly offset the exchange difference in this ordering, but the R-difference term is larger. Geometry alone does not account for the remaining-budget differences. These exact decompositions are reference/order-dependent and redistribute interactions if the reference changes. They do not isolate a separate causal effect of geometry in future dynamics. The complete eta intervention is the causal control; no fake trajectory was generated by subtracting baseline K.

## 6. Spectral diagnostics in the three fixed windows

The copied R1 spectral routine is unchanged. Incoming mean absolute R equals mean R by positivity. Windows [50:200], [50:350], [50:600] contain 150/300/550 samples: incoming state rows 50..199/349/599, source passes 51..200/350/600. Mean subtraction and least-squares linear detrending are retained. All 24 records include raw windows, residuals, complex FFT and unnormalized powers. There are no extra windows or oscillator thresholds. L=9 is constant and supplies no independent oscillatory readout.

| Seed / condition | Samples | Mean-only peak cycles/pass | Detrended peak cycles/pass | Detrended standard deviation |
| --- | ---: | ---: | ---: | ---: |
| 2038 baseline | 150 | .006666667 | .006666667 | .009736254 |
| 2038 baseline | 300 | .003333333 | .003333333 | .061226448 |
| 2038 baseline | 550 | .001818182 | .003636364 | .069864547 |
| 2038 mixing off | 150 | .006666667 | .093333333 | .000648404 |
| 2038 mixing off | 300 | .003333333 | .093333333 | .000690399 |
| 2038 mixing off | 550 | .001818182 | .092727273 | .000693064 |
| 42 baseline | 150 | .006666667 | .006666667 | .008304439 |
| 42 baseline | 300 | .003333333 | .003333333 | .054803125 |
| 42 baseline | 550 | .001818182 | .001818182 | .101643410 |
| 42 mixing off | 150 | .093333333 | .093333333 | .000669656 |
| 42 mixing off | 300 | .093333333 | .093333333 | .000669537 |
| 42 mixing off | 550 | .092727273 | .092727273 | .000664641 |

Baseline mean-only peaks track 1/window length; detrending leaves slow curvature without a common fixed slow period. All six detrended control peaks are the nearest FFT bin to the assigned lowest label .244/phi²≈.093200. Visible smaller features lie near the other prescribed labels .150800, .244000 and .394800 and persist in baseline spectra beneath slow curvature. This is compatible with retained forcing; no sine-off comparison was executed, so it does not independently isolate that forcing's causal contribution or establish emergent frequencies.

Seed 2038's mean-only control peak remains window-length-dependent; seed 42's is near the imposed lowest frequency. Small drift and periodic forcing signatures coexist. The retained legacy 1% flag is not an oscillator criterion. The spectral figure divides nonzero power by its total only to compare shapes; all saved amplitudes and powers remain at source scale. No physical energy, probability, information-compression or sustained autonomous oscillation claim is made.

## 7. Execution and preservation

One 180-second worker supervisor completed both runs in 8.1212 seconds, with no retry or extension. Environment: Windows, Python 3.11.15, NumPy 2.4.4, SciPy 1.17.1, conda torment. Numerical thread variables were set to one for the worker only. Fixed arrays kept memory small; no OS-enforced memory cap is claimed.

Accounting: exactly two preflight calls under the separate <=8 allowance, then 1,200 control updates. Zero baseline rollout calls. Analysis performed 2,400 complete saved-input reconstructions and 2,400 further saved-input P constructions for paired identities, plus 24 spectra. These are not field updates.

The passive adapter calls original RPCO/normal once each, returns actual results unchanged, and copies evidence. All execution-bound hashes match preflight and final bytes. Independent algebra never writes to source state or RNG. HARNESS_AMENDMENTS.md and unified diffs describe the harness changes.

All new files are under R2. No original source, OLD_MATERIAL, R0, R1, UI, kernel, publication, installed environment or Git state was changed by this task; no Git commands or network were used. Initial discovery used PowerShell before the attached CMD-only requirement was read; all subsequent command execution and all Python/scientific work used CMD and torment. That initial deviation did not run field updates or write outside R2.

The final narrow rehash matches all 49 consumed original files. Earlier full OLD_MATERIAL/R0 checks are retained R1 preservation evidence, not a fresh R2 census.

The first final-check attempt stopped on a metadata KeyError: it expected “status” where the successful preflight receipt has “passed”. Partial clipping arrays and an explanation remain in FINAL_CHECKS_01. The corrected saved-data checker passed in fresh FINAL_CHECKS_02. No trajectory was retried, no tolerance changed and no bound code changed.

Three scientific figures under COMPARISON_01/figures/ were visually inspected: trajectories.png, gain_budgets.png and spectra.png. RAW_DATA_README.md maps all data and indices. PACKAGE_MANIFEST.json covers ZIP payloads; the external DELIVERY_RECEIPT.json records the ZIP hash and verification.

## One bounded next recommendation

After mathematical review, approve one **H-off comparison on the eta=0 configuration**: the same two seeds and 600 passes each, changing only the existing field parameter lam_H to 0 before the first pass. Keep the source module byte-identical and sine/fusion/noise unchanged, reuse the completed R2 controls as baselines, and retain the same preflight, 1,200-update, 180-second and no-retry limits. The question is whether the residual approximately 5% mean gain largely disappears without the prescribed transient H multiplier, as the current path budgets suggest. This is a future recommendation, not an executed extension or a subtraction estimate.
