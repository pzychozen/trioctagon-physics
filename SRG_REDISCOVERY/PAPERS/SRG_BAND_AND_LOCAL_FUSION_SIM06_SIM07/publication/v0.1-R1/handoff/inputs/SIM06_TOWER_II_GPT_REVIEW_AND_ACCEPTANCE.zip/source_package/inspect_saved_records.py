"""Passive SIM06 inspection: fixed saved boundaries only; never advance a state.

No field import, update, random draw, noise regeneration, recurrence transcription,
spectral recomputation or prior scientific checker execution is performed.
All new numerical outputs are DERIVED FROM R1 seed2038_eps1 saved records.
"""
from pathlib import Path
import csv,json,hashlib,platform
import numpy as np
import scipy
from scipy.spatial.distance import pdist,squareform
from scipy.sparse.csgraph import connected_components

ROOT=Path(__file__).resolve().parent
RUN=ROOT/'records/R1_seed2038_eps1'
OUT=ROOT/'derived'; OUT.mkdir(exist_ok=True)
def readcsv(p):
    with p.open(newline='',encoding='utf-8-sig') as f: return list(csv.DictReader(f))
def writecsv(name,rows):
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def writejson(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
manifest=json.loads((ROOT/'context/R1/PAYLOAD_MANIFEST.json').read_text())
lookup={r['path']:r for r in manifest['files']}
identities=[]
for p in sorted(RUN.iterdir()):
    expected=lookup['RUN_01/seed2038_eps1/'+p.name]
    raw=p.read_bytes(); actual=hashlib.sha256(raw).hexdigest()
    assert actual==expected['sha256'] and len(raw)==expected['bytes'],p
    identities.append({'file':p.name,'sha256':actual,'bytes':len(raw),'matches_R1_manifest':True})
src=(ROOT/'original/srg_golden_tower_II.py').read_text(encoding='utf-8').splitlines()
excerpt=(ROOT/'context/R0/audited_golden_core.py').read_text(encoding='utf-8').splitlines()
assert excerpt[8:]==src[30:254]
writejson('SOURCE_AND_RECORD_IDENTITY.json',{'selected_R1_files':identities,
    'excerpt_relation':'After eight prefix lines, excerpt line content equals full original lines 31–254; newline encoding differs.',
    'source_imported':False,'old_scientific_checkers_run':False})
X=np.load(RUN/'X.npy',mmap_mode='r',allow_pickle=False)
V=np.load(RUN/'V.npy',mmap_mode='r',allow_pickle=False)
bands=np.load(RUN/'band_id.npy',mmap_mode='r',allow_pickle=False)
freq=np.load(RUN/'natural_freq.npy',mmap_mode='r',allow_pickle=False)
diag=readcsv(RUN/'pass_diagnostics.csv')
r2=json.loads((ROOT/'context/R2_seed2038/summary.json').read_text())
assert X.shape==(601,80,3) and V.shape==X.shape and bands.shape==(80,)
groups=[np.flatnonzero(bands==b) for b in range(4)]
mu=X.mean(axis=1)
centers=np.stack([X[:,ids].mean(axis=1) for ids in groups],axis=1)
within=np.stack([np.mean(np.sum((X[:,ids]-centers[:,b,None,:])**2,axis=2),axis=1) for b,ids in enumerate(groups)],axis=1)
within_total=within.mean(axis=1) # four equal bands of 20
between=np.mean(np.sum((centers-mu[:,None,:])**2,axis=2),axis=1)
rg=np.array([np.sqrt(r2['Rg2_initial'])]+[float(d['radius_of_gyration_new_diagnostic']) for d in diag])
rmean=np.array([r2['R_initial_mean']]+[float(d['R_mean_abs']) for d in diag])
geometry=[]; band_rows=[]; graph_rows=[]; memberships={}; neighbor_rows=[]
snapshots=[0,20,50,100,200,400,599,600]
selected_ids=[int(i) for i in groups[0][:3]]
for s in range(601):
    velocity=np.linalg.norm(V[s],axis=1)
    geometry.append({'state':s,'evidence_window':'comparison_0_200' if s<=200 else 'R1_extension_201_600',
        'Rg_reused_R1_R2':rg[s],'within_band_variance':within_total[s],'between_band_variance':between[s],
        'centroid_x':mu[s,0],'centroid_y':mu[s,1],'centroid_z':mu[s,2],
        'centroid_displacement_from_0':float(np.linalg.norm(mu[s]-mu[0])),
        'mean_abs_R_reused_R1_R2':rmean[s],
        'mean_completed_step':float(velocity.mean()),'max_completed_step':float(velocity.max()),
        'L_for_completed_pass':float(diag[s-1]['L_used']) if s else '',
        'mean_grf_reused_R1':float(diag[s-1]['mean_grf']) if s else ''})
    for b,ids in enumerate(groups):
        offsets=X[s,ids]-centers[s,b]
        offset0=X[0,ids]-centers[0,b]
        band_rows.append({'state':s,'band':b,'count':len(ids),'frequency':float(freq[ids[0]]),
            'center_x':centers[s,b,0],'center_y':centers[s,b,1],'center_z':centers[s,b,2],
            'Rg':float(np.sqrt(within[s,b])),
            'center_displacement_from_0':float(np.linalg.norm(centers[s,b]-centers[0,b])),
            'center_step':float(np.linalg.norm(centers[s,b]-centers[s-1,b])) if s else 0.,
            'rms_offset_change_from_0':float(np.sqrt(np.mean(np.sum((offsets-offset0)**2,axis=1))))})
    if s==600: continue # terminal geometry only; never imply a 601st update was run
    d=squareform(pdist(X[s]))
    nbr=np.argsort(d,axis=1)[:,1:6]
    adj=np.zeros((80,80),dtype=bool);adj[np.arange(80)[:,None],nbr]=True
    nw,lab=connected_components(adj,directed=True,connection='weak')
    ns,_=connected_components(adj,directed=True,connection='strong')
    same=int(np.count_nonzero(bands[:,None]==bands[nbr]))
    row={'incoming_state':s,'drives_saved_pass':s+1,'weak_components':int(nw),'strong_components':int(ns),
        'same_band_edges':same,'cross_band_edges':400-same}
    for b,ids in enumerate(groups):
        count,_=connected_components(adj[np.ix_(ids,ids)],directed=True,connection='weak')
        row[f'band_{b}_induced_weak_components']=int(count)
    graph_rows.append(row)
    if s in snapshots:
        memberships[str(s)]=[{'ids':np.flatnonzero(lab==c).tolist(),
            'band_counts':np.bincount(bands[lab==c],minlength=4).tolist()} for c in range(nw)]
        for i in selected_ids:
            neighbor_rows.append({'incoming_state':s,'id':i,'band':int(bands[i]),
                'neighbors_ascending_id':' '.join(map(str,sorted(nbr[i].tolist()))),
                'neighbor_bands_same_order':' '.join(str(int(bands[j])) for j in sorted(nbr[i].tolist()))})
writecsv('geometry.csv',geometry);writecsv('band_geometry.csv',band_rows)
writecsv('graph_boundaries.csv',graph_rows);writecsv('selected_point_neighbors.csv',neighbor_rows)
point_rows=[]
for s in range(601):
    for i in selected_ids:
        point_rows.append({'state':s,'id':i,'band':int(bands[i]),'x':X[s,i,0],'y':X[s,i,1],'z':X[s,i,2],
            'distance_from_band_center':float(np.linalg.norm(X[s,i]-centers[s,int(bands[i])]))})
writecsv('selected_points.csv',point_rows)
writejson('graph_memberships.json',memberships)
writejson('band_membership.json',{str(b):ids.tolist() for b,ids in enumerate(groups)})
changes=[]
for i in range(1,len(graph_rows)):
    if graph_rows[i]['weak_components']!=graph_rows[i-1]['weak_components']:
        changes.append({'incoming_state':i,'from':graph_rows[i-1]['weak_components'],'to':graph_rows[i]['weak_components']})
episodes=[]
for a,z in [(0,20),(20,200),(200,600),(500,600)]:
    episodes.append({'start_state':a,'end_state':z,'whole_center_displacement':float(np.linalg.norm(mu[z]-mu[a])),
        'Rg_start':rg[a],'Rg_end':rg[z],
        'band0_center_displacement':float(np.linalg.norm(centers[z,0]-centers[a,0])),
        'band0_Rg_start':float(np.sqrt(within[a,0])),'band0_Rg_end':float(np.sqrt(within[z,0])),
        'mean_completed_step_min':min(g['mean_completed_step'] for g in geometry[a+1:z+1]),
        'mean_completed_step_max':max(g['mean_completed_step'] for g in geometry[a+1:z+1])})
summary={'evidence':'DERIVED FROM existing R1 seed2038_eps1; reused diagnostics explicitly named',
    'new_state_updates':0,'rng_draws':0,'selected_ids':selected_ids,
    'snapshot_geometry':[geometry[s] for s in snapshots],
    'snapshot_graphs':[graph_rows[s] for s in snapshots if s<600],
    'weak_component_count_changes':changes,'episode_descriptions':episodes,
    'variance_decomposition_max_abs_residual':float(np.max(np.abs(rg**2-within_total-between))),
    'graph_count_range':[min(r['weak_components'] for r in graph_rows),max(r['weak_components'] for r in graph_rows)],
    'runtime':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__}}
writejson('inspection_summary.json',summary)
print(json.dumps(summary,indent=2))
