# SRG-R3 — transient H control and R0–R3 mechanism synthesis

10 October 2026. Execution and independent mathematical check: Codex. Prior mathematical lead/reviewer: GPT, via the supplied R2 decision. This new R3 result is returned for GPT review; no R3 acceptance by GPT is claimed.

**Completed:** two new 600-pass eta=0, lambda_H=0 controls, after a successful two-call preflight. The accepted R2 eta=0, lambda_H=.05 controls were reused without rollout. Removing H largely removes their residual approximately 5% mean-resonance gain: the final changes from initialization are −0.19990% and +0.15538%, for seeds 2038 and 42. Geometry still compacts, with somewhat larger final spread than H-on. Passive division of baseline R by H's cumulative product approximates the amplitude scale but does not reproduce the H-off state.

GPT's H-product/integrating-factor derivation and source-specific centroid/within-band variance identities are independently confirmed under their stated assumptions. Complete proofs are in MATHEMATICAL_REVIEW.md; selected checks preceded execution. The new passive oracle explicitly takes the actual configured lambda_H and produces m=1 for H-off. The historical core is unchanged.

## 1. Source definitions, intervention and evidence roles

Only the existing attribute field.lam_H was set to 0 immediately after construction, before the first update. It is not a constructor keyword. H, H_MAX, the source constructor, loops and arithmetic were not edited, and H was not monkeypatched. Eta remains zero, as in the reused R2 controls.

| Setting | Both seeds, new R3 controls |
| --- | --- |
| Seeds / N / bands / passes | 2038 and 42 / 80 / 4 / 600 each |
| eta / lambda_H | 0 / 0; R2 baseline lambda_H=.05 |
| Breathing / epsilon / L | false / 0 / 9 |
| k / width / horizon | 5 / 2 / None |
| alpha / beta / imposed sine | .05 / .15 / original .01 amplitude |
| Initialization | Original uniform X in [−5,5]^3, R in [0,.3], shuffled fixed bands |
| Labels / fusion / RPCO / noise | Unchanged source assignments and arithmetic |

These constants are source choices, not measured physical couplings. Frequencies are fixed .244 phi^n with n=−2,−1,0,1; they do not evolve or become newly generated labels. Noise retains source standard deviation .01/(1+.01p). H-off is not forcing-off or an autonomous-system test.

Historical full-source locators in sources/srg_golden_tower_II.py: constants and H/RPCO 31–46; initialization and stored lam_H 62–109; adjacency 111–127; pass 129–215; diffusion 142–148; exchange/sine/mixing 150–190; H 192–194; band fusion 196–206; RPCO/noise/velocity 208–215. Its SHA-256 is 147a32be3b6d6aad17ada6ab7be2fbc3994c3363f74d6a2b351fb8eecda80304.

The copied audited core is byte-identical to accepted R2: SHA-256 6b2f0a05df5871abe4fe97a9e56abd233ab55952028ae953a4b7a652fb24d5e8. After its eight-line prefix, its 224 line contents match historical lines 31–254. The excerpt uses LF, while the full source uses CRLF; this is not raw interval byte equality. Both artifacts are retained unchanged.

The human request authorizes this bounded execution. The supplied work order specifies scope, while GPT's new deductions are claims independently checked against source. Distinct evidence classes are retained:

- Source definitions and assigned constants: unchanged excerpt/full source and configurations.
- Exact real-arithmetic proofs: MATHEMATICAL_REVIEW.md.
- Floating evidence: MATH_REVIEW_01 and ANALYSIS_01, with explicit residuals/tolerances.
- Actual paired interventions: complete RUN_01 arrays, source/RNG receipts and saved R2 baseline references.
- Historical interpretation and unresolved provenance: retained R0/R1/R2 reports, summarized at closeout without new invented rules.

The accepted baseline archive is R2 SRG_R2_GPT_REVIEW.zip, SHA-256 884ace29ccf74f76cde4a7e5983c1f8aecda17884478e945b5ab9e2ffc240971. Its full raw arrays and ZIP are referenced, not duplicated.

## 2. Independent H derivation and finite checks

At eta=0, frozen incoming geometry defines row-stochastic nonnegative P, and D has diagonal 1+.01 sin(2 pi omega_i p) on active rows. Empty/weight-underflow resonance rows have identity P, d_i=1 and no mixing. On a positive unclipped path:

\[
m_p=1+\lambda_HH(p)/H_{MAX},\quad A_0=1,\quad
A_p=\prod_{j=1}^p m_j,\quad
R_p=m_pD_pP(X_{p-1})R_{p-1}+\delta\mathbf1,\quad\delta=10^{-9}.
\]

For baseline lambda_H=.05, |H(t)|<=5.5 and H_MAX>=H(0)=4.5 imply m_p>=169/180>0. The exponentially summable envelope

\[
|m_p-1|\le u_p^*=\frac1{90}
(2e^{-p/2}+e^{-3p/10}+\tfrac32e^{-7p/10}+e^{-2p/5})
\]

and |log(1+x)|<=|x|/(1−|x|) give a convergent log product and a finite, strictly positive A_infinity. For a sufficiently late M:

\[
\left|\log\frac{A_\infty}{A_M}\right|
\le\frac{\sum_{p=M+1}^{\infty}u_p^*}{1-u_{M+1}^*}.
\]

Each sum is an explicit geometric tail. Taking exp(bound)−1 bounds relative product deviation. Independent 80-digit evaluation uses lambda_H=1/20 and the retained floating H_MAX=4.500000000001 as a fixed real parameter:

| p | A_p, high-precision evaluation |
| --- | --- |
| 1 | 1.02993327630541948059 |
| 10 | 1.04745121849395357865 |
| 20 | 1.04761452925611375426 |
| 50 | 1.04762634408385843711 |
| 600 | 1.04762634718064942207 |

The relative-product tail after 50 evaluates to approximately 9.762145e−9, and the absolute log-tail after 600 to 2.132347e−80. These decimals evaluate analytic bounds; they are not interval-certified decimal enclosures. Float64 A_600 differs from the stated high-precision product by about 1.55e−15. All machine passive readouts retain their actual float64 A values.

Defining u_p=R_p/A_p and dividing the recurrence proves

\[
u_p=D_pP(X_{p-1})u_{p-1}+\frac{\delta}{A_p}\mathbf1.
\]

The P here still uses H-on geometry. Actual H-off dynamics has a different subsequent geometry and unscaled delta, so passive u is not an H-off trajectory. H changes fusion strength and slightly changes its regularized center; the center cannot be assumed invariant under common Q scaling. The finite transient product is not sustained direct pumping, but early perturbations can persist after direct H becomes tiny.

Before execution, 12 selected R2 inputs at passes 1,10,50,51,200,600 were reconstructed, with 12 additional same-input lambda=0 evaluations. This checked m=.05-configured versus m=1, the integrating-factor identity and source Q/Z. Forty-eight selected band cases and four final R1/R2 geometry splits were checked, rather than rerunning all 2,400 prior input reconstructions. Maximum selected Q error was 1.11e−16, Z error 4.45e−16, centroid residual 3.21e−16 and variance residual 6.50e−15; the declared stage tolerance was 5e−13. No engine was imported by this mathematical review.

## 3. Source-specific fusion proof and domain

For one band after diffusion, q_i=Q_i>=0, rho=1e−8, kappa=.02, tau=kappa rho=2e−10:

\[
C=\frac{\sum_i(q_i+\rho)Y_i}{\sum_iq_i+n\rho},\quad
Z_i=Y_i+\kappa q_i(C-Y_i),\quad
\boxed{\mu^+-\mu=\tau(\mu-C)}.
\]

The identity follows by substituting sum(q_i Y_i)=(sum q_i+n rho)C−n rho mu into the summed update. Nonnegative q is sufficient for this centroid identity; the upper bound 50 is needed for the variance inequality, not for the centroid identity alone. The retained regularizer prevents exact centroid conservation in general.

Write y_i=Y_i−mu, c=C−mu, a_i=kappa q_i, A=sum a_i, S=sum a_i||y_i||², T=sum a_i(1−a_i)||y_i−c||². Then c=sum(a_i y_i)/(A+n tau). Expanding squared convex combinations and recentering on mu_plus proves

\[
\boxed{V(Z)-V(Y)=\frac{-S+A\|c\|^2-T}{n}-\tau^2\|c\|^2}.
\]

For 0<=Q<=50, 0<=a_i<=1 and T>=0. Weighted Cauchy–Schwarz implies A||c||²<=[A/(A+n tau)]² S<=S. Therefore

\[
V(Y)-V(Z)\ge
\frac{[1-(A/(A+n\tau))^2]S+T}{n}+\tau^2\|c\|^2\ge0.
\]

All-zero q gives C=mu and an unchanged stage. Singleton bands are source-skipped and have zero variance/shift; empty bands are skipped without evaluating means. Negative q or q>50 falls outside this variance guarantee. These conditions are recorded, not enforced by clamping source state.

For fixed bands, expanding around each arithmetic band center cancels the cross term and gives

\[
Rg^2(X)=\sum_b(n_b/N)V_b(X)+
\sum_b(n_b/N)\|\mu_b-\mu\|^2.
\]

The theorem is within-band and for one fusion stage. It is not a full-field monotonicity theorem, cross-trajectory contraction or convergence proof. Diffusion can alter band centers/spread, the regularized fusion centers shift slightly, and noise follows. The broader coordinatewise diffusion/fusion box result from R2 remains conditional and distinct.

## 4. Bounded execution and first differences

The successful preflight used two source calls: uninstrumented/instrumented H-off at seed 2038 with original noise. Actual initial X/V/R, labels and full RNG matched R2; output X/V/R and RNG matched exactly between instrumentation modes. Each pass called original RPCO and normal exactly once and returned their actual outputs unchanged.

On the common initial state:

\[
Q_{\rm on}-Q_{\rm off}=(m_1-1)D_1PR_0,
\]
\[
Z_{{\rm on},i}-Z_{{\rm off},i}
=.02[Q_{{\rm on},i}(C_{{\rm on},b}-Y_i)
-Q_{{\rm off},i}(C_{{\rm off},b}-Y_i)].
\]

Both regularized centers are retained in the saved fixture. They differ by up to 1.6740e−9 in the seed-2038 preflight. Q-difference residual was 2.52e−17 and Z-difference residual 8.26e−16, below 5e−13. Same-pass X and V differ by up to .000742373808135 with identical noise.

| Seed | First different Q/R/X/V | Diffusion Y | Continuous W/P | Selected graph | Passes with different graph |
| --- | --- | --- | --- | --- | --- |
| 2038 | 1 / 1 / 1 / 1 | 2 | 2 | 14 | 582 |
| 42 | 1 / 1 / 1 / 1 | 2 | 2 | 4 | 500 |

These are exact-inequality first differences, not thresholded events. Every-pass full-array maxima and graph differences are saved. Noise and all before/after RNG fingerprints match R2 exactly for both seeds, as do full initial/final checkpoints. Fields ran sequentially from source seed resets; they were not interleaved or repaired.

The single worker completed in 8.093124 seconds under its unchanged 180-second timeout. Exactly 1,200 new source updates and two separate preflight calls were used. There was no failed field preflight, timeout, source/random mismatch, trajectory retry or baseline rollout. Pure saved-data analysis took about 189.65 seconds separately; it made zero field calls and is not part of the source-worker timeout.

## 5. Actual resonance effects, passive scale comparison and budgets

| Seed | Initial mean | H-on final mean | H-off final mean | H-on gain factor | H-off gain factor |
| --- | --- | --- | --- | --- | --- |
| 2038 | 0.151692819189 | 0.158692197459 | 0.151389578319 | 1.04614179042 | 0.99800095435 |
| 42 | 0.160075758197 | 0.168041432041 | 0.160324481008 | 1.04976189983 | 1.00155378187 |

| Seed | H-on net gain | H-off net gain | Absolute gain difference on−off | Reduction relative to H-on net gain |
| --- | --- | --- | --- | --- |
| 2038 | +0.00699937827054 | -0.000303240870324 | +0.00730261914086 | 104.332397% |
| 42 | +0.00796567384415 | +0.000248722810973 | +0.00771695103318 | 96.877567% |

The denominator is mu_Hon(600)−mu_initial; it is not total final resonance. Seed 2038 exceeds 100% reduction because its H-off endpoint is slightly below initialization. The absolute effects are .007302619141 and .007716951033, not an exactly imposed 4.762635% endpoint change. The intervention establishes that H's prescribed transient accounts for most residual mean-gain scale in these two eta=0 runs; it does not prove H is the sole contributor or a universal comparison principle.

| Seed | Final passive mean R_on/A | Actual H-off mean | Passive-minus-off mean | Max component difference at 600 |
| --- | --- | --- | --- | --- |
| 2038 | 0.151477860295 | 0.151389578319 | +8.82819762734e-05 | 0.000968741331705 |
| 42 | 0.160402067487 | 0.160324481008 | +7.75864785575e-05 | 0.000340531497034 |

Thus passive normalization is close at the mean scale but measurably different in full resonance and geometry. The saved-state integrating-factor identity on the actual baseline has maximum residual 1.11e−16; this does not turn the normalized baseline into an H-off simulation.

The ordered identity is R+−R=(B−R)+(F−B)+G+(Q_hat−S)+(R+−Q_actual)+(Q_actual−Q_hat), where B=PR, F=DB, G=KR and S=F+G. Actual RPCO offsets and source/oracle regrouping residuals remain separate. R2 baseline budgets are reused; new control budgets use actual configured lambda_H=0 and have H exactly zero, not copied from a hardcoded .05 observer. Mixing is exactly zero in both.

| Seed / condition | Exchange | Sine | H | RPCO | Reconstruction | Net change |
| --- | --- | --- | --- | --- | --- | --- |
| 2038 / H_on | +0.000775233890914 | -0.00098354884353 | +0.00720709322315 | +5.9999999981e-07 | +2.54284440726e-15 | +0.00699937827054 |
| 2038 / H_off | +0.000586697766286 | -0.000890538636612 | +0 | +5.99999999754e-07 | +2.49331805202e-15 | -0.000303240870324 |
| 42 / H_on | +0.00122823512075 | -0.000953661629638 | +0.00769050035304 | +5.99999999739e-07 | +2.75465414368e-15 | +0.00796567384415 |
| 42 / H_off | +0.00109894881356 | -0.000850826002591 | +0 | +5.999999998e-07 | +2.68387742586e-15 | +0.000248722810973 |

The partition 1–50 / 51–600 was fixed in the work order using the H-tail derivation, not selected after these results:

| Seed / condition | Passes | Exchange | Sine | Direct H budget | Net mean change |
| --- | --- | --- | --- | --- | --- |
| 2038 / H_on | 1–50 | +0.001948097378 | +0.001416909549 | +0.007207092747 | +0.01057214967 |
| 2038 / H_on | 51–600 | -0.001172863488 | -0.002400458393 | +4.762054386e-10 | -0.003572771404 |
| 2038 / H_off | 1–50 | +0.001882816468 | +0.001406575356 | +0 | +0.003289441824 |
| 2038 / H_off | 51–600 | -0.001296118702 | -0.002297113993 | +0 | -0.003592682695 |
| 42 / H_on | 1–50 | +0.001612315125 | +0.001639401886 | +0.007690499851 | +0.01094226686 |
| 42 / H_on | 51–600 | -0.000384080004 | -0.002593063516 | +5.016973463e-10 | -0.002976593018 |
| 42 / H_off | 1–50 | +0.001451406873 | +0.001622756892 | +0 | +0.003074213764 |
| 42 / H_off | 51–600 | -0.0003524580591 | -0.002473582894 | +0 | -0.002825490953 |

Baseline direct H contributes only about 4.76e−10 / 5.02e−10 during passes 51–600, while late total mean changes remain negative and paired differences persist. In H-off, early exchange+sine still raise the mean and later changes partly reverse that increase. This separates H's direct late action from its lasting consequences. Stage budgets are path-dependent identities, not a way to manufacture a control by subtracting a column.

## 6. Geometry, within/between split and theorem evidence

| Seed / condition | Final within | Final between | Final Rg² | Final Rg | Within fraction |
| --- | --- | --- | --- | --- | --- |
| 2038 / R2 H-on | 0.544353742451 | 0.0449829233592 | 0.58933666581 | 0.767682659574 | 92.367194% |
| 2038 / R3 H-off | 0.642576593047 | 0.0514891762526 | 0.6940657693 | 0.833106097265 | 92.581513% |
| 42 / R2 H-on | 0.687991268843 | 0.0389656489 | 0.726956917743 | 0.852617685568 | 94.639896% |
| 42 / R3 H-off | 0.781224148076 | 0.0437207324431 | 0.824944880519 | 0.908264763447 | 94.700163% |

| Seed | Final Rg² ratio off/on | Final Rg ratio off/on |
| --- | --- | --- |
| 2038 | 1.17770674992 | 1.08522198186 |
| 42 | 1.13479198063 | 1.06526615483 |

Compaction remains large from initial Rg² 27.6840776223 / 25.3408896414, despite H removal. Final control spread is predominantly within the assigned bands. It is not just separation of four internally collapsed point bands. R3's final Rg is 8.52% / 6.53% greater than R2's, whereas Rg² is 17.77% / 13.48% greater; these are different ratios.

| Seed / condition | Passes | Diffusion ΔRg² | Fusion ΔRg² | Noise ΔRg² |
| --- | --- | --- | --- | --- |
| 2038 / H_on | 1–50 | -5.567661552 | -5.98400742 | -0.06890460575 |
| 2038 / H_on | 51–600 | +0.1583535084 | -15.6739382 | +0.04141731456 |
| 2038 / H_on | 1–600 | -5.409308044 | -21.65794562 | -0.02748729118 |
| 2038 / H_off | 1–50 | -5.542947026 | -5.761144853 | -0.06921437811 |
| 2038 / H_off | 51–600 | +0.1607001234 | -15.81878924 | +0.04138352582 |
| 2038 / H_off | 1–600 | -5.382246903 | -21.5799341 | -0.02783085229 |
| 42 / H_on | 1–50 | -4.980556274 | -5.605768058 | +0.01894430786 |
| 42 / H_on | 51–600 | +0.2465352881 | -14.28458221 | -0.008505773204 |
| 42 / H_on | 1–600 | -4.734020985 | -19.89035027 | +0.01043853466 |
| 42 / H_off | 1–50 | -4.969292102 | -5.393911992 | +0.01898058646 |
| 42 / H_off | 51–600 | +0.254741646 | -14.41790024 | -0.008562660028 |
| 42 / H_off | 1–600 | -4.714550456 | -19.81181223 | +0.01041792643 |

The full table also splits each geometry contribution into within and between parts. Every incoming/diffusion/fusion/noise snapshot has the exact sum-of-squares decomposition, retained with its floating closure error. Every band has per-stage arithmetic centers, movement norms, variances and R statistics.

All 9,600 baseline/control band-pass checks lie in 0<=Q<=50. Maximum centroid-identity residual is 6.38e−16, variance-identity residual 1.20e−14, and decrease-bound violation is zero. No within-band fusion variance increase >1e−14 occurred. These verify the conditional theorem numerically in the sampled domain; they do not prove convergence or isolate fusion from the geometry/noise system over time. The tiny between-band fusion budget reflects the source-specific near-centroid conservation; diffusion and noise account for much larger band-center changes.

All new Q/R values are positive. There are no lower/upper log crossings, zeros, effective-clipping differences or Q>50 entries. Actual RPCO is bitwise equal to the unclipped signed log/exp expression on every recorded baseline/control input. The positive 1e−9 offset remains active. H-off minimum log margins are 5.186136 / 5.372157; Q ranges are [.022062755210,.278093343413] and [.026573429935,.283477748529]. No theorem was extended across an unverified clipping or fusion-domain boundary.

New source-input reconstructions have maximum Q residual 1.11e−16 and fusion-position residual 4.45e−16. Largest new mean-budget closure residual is 5.75e−17. The stage tolerance remains 5e−13; segment sums have separately recorded floating aggregation closure, not interval guarantees.

## 7. Spectral comparison with existing R2 records

Only 12 new H-off spectra were calculated. The 12 corresponding R2 eta=0 spectra are reused byte-for-byte and their raw slices checked against the baseline. Windows remain incoming-mean-R[50:200], [50:350], [50:600], i.e. 150/300/550 samples, incoming state indices 50..199/349/599 and source passes 51..200/350/600. Mean removal and least-squares linear detrending retain all raw values, complex rFFT coefficients and powers. No extra spectral window, frequency fit, sine-off mutation or replacement oscillator threshold was introduced.

| Seed | Samples | H-on detrended peak | H-off detrended peak | H-off mean-only peak | H-on detrended std | H-off detrended std |
| --- | --- | --- | --- | --- | --- | --- |
| 2038 | 150 | 0.0933333333 | 0.0933333333 | 0.00666666667 | 0.000648404086 | 0.000614380109 |
| 2038 | 300 | 0.0933333333 | 0.0933333333 | 0.00333333333 | 0.00069039868 | 0.000650840058 |
| 2038 | 550 | 0.0927272727 | 0.0927272727 | 0.00181818182 | 0.000693063871 | 0.000656625783 |
| 42 | 150 | 0.0933333333 | 0.0933333333 | 0.0933333333 | 0.000669655637 | 0.000638863563 |
| 42 | 300 | 0.0933333333 | 0.0933333333 | 0.0933333333 | 0.000669536745 | 0.000638859729 |
| 42 | 550 | 0.0927272727 | 0.0927272727 | 0.0927272727 | 0.00066464098 | 0.000634318496 |

All six H-off detrended peaks remain at the closest bin to assigned .244/phi²≈.0931997067 cycles/pass, as in R2. Other assigned-frequency features remain visible. H-off changes amplitudes and geometry but does not remove these peaks. This is compatible with retained sine forcing; no direct causal sine test was performed and no physical coupling or new frequency label was inferred. Seed 2038's mean-only peaks still follow 1/window length; seed 42's are near the lowest assigned frequency. The legacy 1% flags remain descriptive artifacts, not oscillator criteria.

Three scientific figures were visually inspected: FIGURES/trajectories.png, passive_vs_intervention.png, spectra.png. The spectral figure uses absolute FFT power, not normalized display power.

## 8. Preservation, reproducibility and closeout

All new files, extracted decision copies, scripts, temp/cache paths, evidence and ZIP stay under R3_TRANSIENT_H_AND_SYNTHESIS. R3 did not exist when checked. Original OLD_MATERIAL and R0/R1/R2 work were untouched. Narrow before/after hashes cover 93 actually consumed files, including accepted archives and selected baseline arrays; earlier full historical checks remain prior evidence rather than a fresh census.

Windows CMD and conda torment were used from the beginning. No PowerShell, network, installations, persistent environment changes, Git commands, kernel/UI edits, publication or production integration occurred. Python 3.11.15, NumPy 2.4.4 and SciPy 1.17.1 executed the source worker. Single-thread numerical variables were child-local. A small-memory expectation was not an OS memory cap.

The exact principal execution command was:

~~~bat
C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R3_TRANSIENT_H_AND_SYNTHESIS\r3_cmd.cmd run_srg_r3.py --execute --output C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R3_TRANSIENT_H_AND_SYNTHESIS\RUN_01
~~~

COMMANDS_USED.md includes activation, setup and all task-script invocations. The execution receipt retains actual worker argv, timestamps, timeout, return code and nine bound file hashes. Preflight, execution and final bound bytes agree. The source-line ending qualification is preserved.

Final accounting: 2 preflight source calls, 1,200 new updates, zero accepted baseline rollout calls. Before execution: 12 selected full reconstructions plus 12 same-input lambda-zero oracle evaluations, 48 selected band checks, four finite fixtures, four earlier final-state splits. After execution: 1,200 new control reconstructions, 1,200 reused baseline stage sets, 1,200 baseline weight-matrix constructions, 9,600 band checks and 12 new spectra with 12 reused spectra. All analysis/plotting/packaging made zero field calls. These many correlated checks are not independent trials.

RAW_DATA_README.md maps complete arrays and indices. The review ZIP includes all new trajectories, source, tested harness, proofs, receipts, differences, tables, spectra and figures. Prior raw archives remain exact hash references. PACKAGE_MANIFEST.json excludes itself and the outer archive; DELIVERY_RECEIPT.json records the finished ZIP hash and independent payload/CRC verification.

## R0–R3 mechanism synthesis

**Recovered versions remain distinct.** R0 recovered several complete executable models, not one canonical SRG recurrence. The July position patch evolves only a real N×3 position array with static neighbors; older wrapped particle/tetrahedral models carry velocities and sometimes binary rules; March models add real resonance, with separate dark-field, horizon and band variants. The November fixed six-component complex-linear transfer and URF action/algorithm are different mathematical objects. Tower II results do not retroactively validate or replace these other versions.

**Tower II's source state and update are known.** It rebuilds incoming geometry, diffuses coordinates, exchanges resonance using frequency/distance weights, applies prescribed sine and explicit mixing, multiplies by scheduled H, fuses within fixed bands, applies signed RPCO, adds noise and records displacement velocities. Assigned frequencies and coefficient tests are source inputs; they do not constitute an independently measured coupling. R0's paper/code discrepancies remain: signed RPCO preserves sign rather than performing claimed negative-to-positive inversion; March glyph engines lack the claimed toroidal spatial bound; algebraic breathing is not an independent evolving field.

**R1 isolates inactive breathing bounds in the sampled domain.** Changing breathing epsilon changed L but no actual Q/R/X/V, clipping output or random input in the paired 600-pass runs. The historical slow FFT peak tracks window resolution; the legacy 1% test is non-discriminating for a 150-sample trace above its guard. L is an affine incoming-R readout, not independent corroboration of another oscillator.

**R2 isolates explicit additive mixing as the major tested growth mechanism.** Removing eta=.001 reduced net mean gain by 99.6553% / 99.4654%, while compaction persisted. Separate phi-proximity, sum-match and difference-match terms are unbalanced additions from existing neighbors. Path budgets explain their arithmetic role, while the actual intervention captures subsequent geometry and graph feedback. The result is limited to the stated two seeds, settings and horizon, not a universal monotonicity theorem.

**R3 isolates the prescribed transient H as the principal residual gain scale at eta=0.** H-off leaves a −.19990% / +.15538% endpoint change instead of +4.61418% / +4.97619%. The positive finite product explains the transient amplification scale, and direct H after pass 50 is negligible; early H still changes later states. Passive division is therefore informative but not interchangeable with actual H-off dynamics. Remaining exchange, sine, RPCO offset and geometry feedback produce a small seed-dependent net change rather than an exactly conserved resonance.

**Compaction has a source-specific conditional theorem and a coupled remainder.** Nonnegative preclip Q<=50 makes within-band fusion variance nonincreasing, with the exact regularizer-controlled arithmetic centroid identity. Coordinatewise diffusion has a separate box property. Neither establishes global monotonicity or asymptotic collapse once between-band geometry, directed neighborhoods and noise are included. R2/R3's remaining spread is predominantly within bands. The noise schedule is prescribed and declining; no diffusion-only or noise-free causal claim has been tested.

**Historical interpretations remain unresolved where source rules are missing.** The tower zeta relation is a post-run map of assigned frequencies, not a measured gamma estimator or an operative update coefficient. The dark-field literal .08699 has a different, active input role; unused gamma constants in other models are yet another role. URF's GammaEstimate, estimator objective and spectrum-to-scalar rule remain unspecified in the recovered chain. No source-grounded geometry-to-zeta normalization or coupling map was supplied by these controls. The .244 choice, odd-zeta family and other constants retain their recorded provenance; forcing-aligned spectral features do not independently supply those missing derivations. No physical energy/information, particle identity, autonomous-heartbeat or production-equivalence claim follows.

The authorized R3 task ends here. No further experiment was started.
