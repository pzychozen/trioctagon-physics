# SRG-R1 raw data and review guide

The four complete runs are under `RUN_01/seed2038_eps0`, `RUN_01/seed2038_eps1`, `RUN_01/seed42_eps0`, and `RUN_01/seed42_eps1`. Each contains 600 updates of 80 glyphs. All are included in `SRG_R1_GPT_REVIEW.zip`; no downsampling or state normalization was applied.

| File | Shape | Meaning |
|---|---|---|
| X.npy, V.npy | (601,80,3) | Initial state at row 0, then complete state after each update |
| R.npy | (601,80) | Initial and post-update real resonance |
| Q.npy | (600,80) | Actual input to signed RPCO, after memory modulation and before clipping |
| actual_rpc_output.npy | (600,80) | Actual returned source output; equals R[1:] exactly |
| counterfactual_fixed.npy | (600,80) | Preserved operator applied to same Q with L=9; observer only |
| counterfactual_breathing.npy | (600,80) | Same Q with L=9*(1+incoming mean abs R); observer only |
| positions_at_rpc.npy | (600,80,3) | Positions after fusion, before clipping and position noise |
| noise.npy | (600,80,3) | Actual original random-normal arrays, copied without extra draws |
| L_used.npy, incoming_mean_abs_R.npy | (600,) | Update index k uses pass k+1 and incoming R state k |
| natural_freq.npy, band_id.npy | (80,) | Fixed assigned frequency labels/bands |
| pass_diagnostics.csv | 600 rows | Log clipping/equality counts, effective comparisons, margins, RNG fingerprints and scalar observables |
| rng_initial.json, rng_final.json | Complete checkpoints | MT19937 algorithm, all 624 keys, position, Gaussian cache flag/value |
| configuration.json, run_summary.json | Metadata | Exact design, completion and clipping summaries |

NPY files are numeric, readable with `numpy.load(..., allow_pickle=False)`. For example, from the R1 folder:

```python
from pathlib import Path
import numpy as np
p = Path('RUN_01/seed2038_eps1')
R = np.load(p/'R.npy', mmap_mode='r', allow_pickle=False)
L = np.load(p/'L_used.npy', allow_pickle=False)
# L[50:200] uses update passes 51..200 and incoming R states 50..199.
assert np.array_equal(L, 9*(1+np.mean(np.abs(R[:-1]), axis=1)))
```

Each `ANALYSIS_01/spectra/*.npz` retains raw window values, local sample indices, residual, FFT frequencies, powers, and real/imaginary coefficients. Matching JSON retains slope/intercept, physical pass/state mapping, bin spacing, peak index/fraction and diagnostic flags. All frequencies are cycles/pass. All rFFT bins are included; no power interpolation or doubled one-sided normalization is applied. Mean-only flags reproduce the historical observer; residual-rule flags are separately labelled. Neither is an R1 scientific oscillator decision. Unthresholded peaks in zero/roundoff spectra are retained as arithmetic output, not frequency measurements.

Start review with `SRG_R1_REPORT.md`, then `ANALYSIS_01/pairing_and_first_divergence.json`, `RUN_01/*/pass_diagnostics.csv`, the raw arrays, `ANALYSIS_01/spectral_summary.json`, and `PREFLIGHT_01/preflight_receipt.json`. The source core is byte-identical to accepted R0; full historical source is included only for reading. Do not launch it.
