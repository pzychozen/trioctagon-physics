"""SRG-R0 AUDITED EXCERPT, not an original file.
Original: research_files/archive_members/Zenodo_research/19023429/simulations.zip/srg_golden_tower_II.py
Source lines 31-254 copied verbatim; only numpy/scipy-distance imports added.
Excluded launchers, paths, printing, CSV writes, warning suppression and experiments.
See audited_excerpt_manifest.json for hashes. Pure update plus in-memory diagnostics.
"""
import numpy as np
from scipy.spatial.distance import pdist, squareform
PHI = (1 + np.sqrt(5)) / 2
PI = np.pi
E = np.e
OMEGA_0 = 0.244  # vesica piscis base frequency
LOCK_PRODUCT = PI * E * PHI  # ≈ 13.818

def H(t):
    t = np.asarray(t, dtype=float)
    return (2.0*np.exp(-0.5*t)*np.cos(t) + 1.0*np.exp(-0.3*t)*np.sin(t)
            + 1.5*np.exp(-0.7*t) + 1.0*np.exp(-0.4*t))

def rpco(x, L=9.0, eps=1e-9):
    x = np.asarray(x, dtype=float)
    return np.sign(x) * np.exp(np.clip(np.log(np.abs(x)+eps), -L, L))

H_MAX = float(np.max(np.abs(H(np.linspace(0, 100, 50000))))) + 1e-12


# ============================================================================
# ENHANCED GOLDEN TOWER FIELD — with self-coupled breathing & stronger mixing
# ============================================================================

class GoldenTowerFieldII:
    """
    Extended tower field with:
    - Self-coupled breathing RPCO (L responds to mean field resonance)
    - Stronger nonlinear mode coupling
    - Lock-time measurement per band
    - Causal horizons (optional)
    """

    def __init__(self, N, n_bands, R_range=(0, 0.3), spatial_range=(-5, 5),
                 seed=None, coupling_width=3.0, breathing=False,
                 breathing_epsilon=0.5, horizon_radius=None,
                 nonlinear_strength=0.001):
        if seed is not None:
            np.random.seed(seed)
        self.N = N
        self.n_bands = n_bands
        self.positions = np.random.uniform(spatial_range[0], spatial_range[1], (N, 3))
        self.resonance = np.random.uniform(R_range[0], R_range[1], N)
        self.velocities = np.zeros((N, 3))
        self.pass_count = 0

        # Golden tower
        half = n_bands // 2
        self.tower_indices = list(range(-half, half + 1))[:n_bands]
        self.tower_freqs = np.array([OMEGA_0 * PHI**n for n in self.tower_indices])

        # Assign glyphs to bands (equal distribution)
        band_assignments = np.array([i % n_bands for i in range(N)])
        np.random.shuffle(band_assignments)
        self.natural_freq = self.tower_freqs[band_assignments]
        self.band_id = band_assignments

        # Coupling parameters
        self.coupling_width = coupling_width
        self.nonlinear_strength = nonlinear_strength

        # Self-coupled breathing
        self.breathing = breathing
        self.breathing_epsilon = breathing_epsilon
        self.rpco_L_base = 9.0

        # Causal horizon
        self.horizon_radius = horizon_radius

        # Standard params
        self.alpha = 0.05
        self.beta = 0.15
        self.lam_H = 0.05
        self.rpco_L = 9.0
        self.k_neighbors = 5

        # Tracking
        self.metrics_history = []
        self.band_history = []
        self.L_history = []
        self.lock_times = {}  # band_id -> first pass where band coherence > threshold

    def _adjacency(self):
        dists = squareform(pdist(self.positions))
        adj = np.zeros((self.N, self.N))
        for i in range(self.N):
            # Apply causal horizon
            if self.horizon_radius is not None:
                candidates = np.where(dists[i] < self.horizon_radius)[0]
                candidates = candidates[candidates != i]
                if len(candidates) == 0:
                    continue
                # Pick k nearest within horizon
                sorted_c = candidates[np.argsort(dists[i, candidates])]
                neighbors = sorted_c[:self.k_neighbors]
            else:
                neighbors = np.argsort(dists[i])[1:self.k_neighbors+1]
            adj[i, neighbors] = 1
        return adj, dists

    def evolve_pass(self):
        self.pass_count += 1
        t = float(self.pass_count)
        old_pos = self.positions.copy()

        # Self-coupled breathing: L responds to field resonance
        if self.breathing:
            mean_R = float(np.mean(np.abs(self.resonance)))
            self.rpco_L = self.rpco_L_base * (1.0 + self.breathing_epsilon * mean_R)
            self.L_history.append({'pass': int(t), 'L': self.rpco_L, 'mean_R': mean_R})

        adj, dists = self._adjacency()

        # 1. Spatial evolution
        lap = np.zeros_like(self.positions)
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) > 0:
                lap[i] = np.mean(self.positions[nbrs] - self.positions[i], axis=0)
        self.positions += self.alpha * lap + self.beta * np.tanh(lap)

        # 2. Frequency-dependent resonance coupling with ENHANCED nonlinear mixing
        R_new = self.resonance.copy()
        for i in range(self.N):
            nbrs = np.where(adj[i] > 0)[0]
            if len(nbrs) == 0:
                continue
            w = 1.0 / (dists[i, nbrs] + 1e-8)
            freq_match = np.exp(-self.coupling_width *
                               (np.log(self.natural_freq[nbrs]/self.natural_freq[i]))**2)
            w *= freq_match
            w_sum = w.sum()
            if w_sum < 1e-10:
                continue
            w /= w_sum

            R_nbr = np.sum(w * self.resonance[nbrs])
            R_new[i] += self.beta * (R_nbr - self.resonance[i])
            R_new[i] *= (1.0 + 0.01 * np.sin(self.natural_freq[i] * 2*PI * t))

            # ENHANCED nonlinear mixing
            for j in nbrs:
                if abs(self.natural_freq[i] - self.natural_freq[j]) > 0.01:
                    f_ratio = self.natural_freq[i] / self.natural_freq[j]
                    # Enhancement for φ-related ratios (φ, φ², 1/φ, etc.)
                    for power in [-2, -1, 1, 2]:
                        target = PHI**power
                        proximity = np.exp(-5 * (np.log(f_ratio) - np.log(target))**2)
                        R_new[i] += self.nonlinear_strength * proximity * self.resonance[j]

                    # Also: sum and difference frequency generation
                    # (like optical wave mixing)
                    f_sum = self.natural_freq[i] + self.natural_freq[j]
                    f_diff = abs(self.natural_freq[i] - self.natural_freq[j])
                    # Check if sum/diff matches any tower frequency
                    for tf in self.tower_freqs:
                        if abs(f_sum - tf) / tf < 0.2:
                            R_new[i] += 0.5 * self.nonlinear_strength * self.resonance[j]
                        if f_diff > 0.01 and abs(f_diff - tf) / tf < 0.2:
                            R_new[i] += 0.5 * self.nonlinear_strength * self.resonance[j]

        self.resonance = R_new

        # 3. Memory modulation
        h_t = H(t)
        self.resonance *= (1.0 + self.lam_H * h_t / H_MAX)

        # 4. Band-local fusion
        for band in range(self.n_bands):
            mask = self.band_id == band
            if np.sum(mask) < 2:
                continue
            band_pos = self.positions[mask]
            band_R = self.resonance[mask]
            band_center = np.average(band_pos, axis=0, weights=np.abs(band_R)+1e-8)
            idx = np.where(mask)[0]
            for ii in idx:
                self.positions[ii] += 0.02 * self.resonance[ii] * (band_center - self.positions[ii])

        # 5. RPCO (with possibly breathing L)
        self.resonance = rpco(self.resonance, L=self.rpco_L)

        # 6. Noise
        noise = 0.01 / (1 + 0.01*t)
        self.positions += np.random.normal(0, noise, self.positions.shape)

        self.velocities = self.positions - old_pos
        self._record()

    def _record(self):
        t = self.pass_count
        R = self.resonance

        band_stats = {}
        for b in range(self.n_bands):
            mask = self.band_id == b
            if np.sum(mask) == 0:
                continue
            R_b = np.abs(R[mask])
            mean_R = float(np.mean(R_b))
            band_stats[b] = {
                'freq': float(self.tower_freqs[b]),
                'tower_idx': self.tower_indices[b],
                'mean_R': mean_R,
                'max_R': float(np.max(R_b)),
                'std_R': float(np.std(R_b)),
                'count': int(np.sum(mask)),
                'coherence': float(1.0 - np.std(R_b)/(np.mean(R_b)+1e-10)),
                'mean_grf': float(np.mean(1.0/(1.0+np.linalg.norm(self.velocities[mask], axis=1))))
            }

            # Track lock time: first pass where band coherence > 0.7
            if b not in self.lock_times and band_stats[b]['coherence'] > 0.7 and mean_R > 0.01:
                self.lock_times[b] = t

        self.band_history.append({'pass': t, 'bands': band_stats})
        self.metrics_history.append({
            'pass': t,
            'R_max': float(np.max(np.abs(R))),
            'R_mean': float(np.mean(np.abs(R))),
            'n_surviving_bands': len([b for b in band_stats.values() if b['mean_R'] > 0.01]),
        })

    def evolve(self, n_passes):
        for _ in range(n_passes):
            self.evolve_pass()
