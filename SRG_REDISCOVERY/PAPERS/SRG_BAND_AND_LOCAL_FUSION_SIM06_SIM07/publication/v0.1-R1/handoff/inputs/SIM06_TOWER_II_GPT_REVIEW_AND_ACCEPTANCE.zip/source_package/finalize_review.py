"""SIM06 document, preservation and ZIP checks only. Standard library only.

Does not load numerical arrays, run scientific checks, import original code,
construct fields, sample RNG, execute Git or modify an input file.
"""
from pathlib import Path
import ast,hashlib,json,re,struct,zipfile
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
stamp=datetime.now(timezone.utc).isoformat()
ZIPNAME='SRG_SIMULATION_STUDY_06_TOWER_II_CONSTRUCTION_01_REVIEW.zip'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def identity(p):
    raw=p.read_bytes();return {'bytes':len(raw),'sha256':sha(raw)}
def write(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

baseline=json.loads((ROOT/'INPUT_BASELINE.json').read_text())
assert len(baseline)==43 and len({x['copy'] for x in baseline})==43
preserved=[]
for row in baseline:
    expected={k:row[k] for k in ['bytes','sha256']}
    original=identity(Path(row['original'])); copy=identity(ROOT/row['copy'])
    assert original==copy==expected,row['copy']
    preserved.append({**row,'original_unchanged':True,'copy_identical':True})
assert identity(ROOT/'original/srg_golden_tower_II.py')=={'bytes':34980,'sha256':'147a32be3b6d6aad17ada6ab7be2fbc3994c3363f74d6a2b351fb8eecda80304'}
assert identity(ROOT/'context/R0/audited_golden_core.py')['sha256']=='6b2f0a05df5871abe4fe97a9e56abd233ab55952028ae953a4b7a652fb24d5e8'
assert identity(ROOT/'original/self_coupled_breathing.csv')=={'bytes':765,'sha256':'67c4aab59b8dd4ac8f46387cf4800fe4408aa54f253afb8481a51c6dfb16a462'}
write('PRESERVATION_RECEIPT.json',{'recorded_utc':stamp,'scope':'43 used source/context/record inputs, not a repository-wide audit',
    'all_originals_unchanged':True,'all_copies_identical':True,'inputs':preserved,
    'work_boundary':{'new_state_updates':0,'rng_draws':0,'historical_imports':0,'old_scientific_checker_runs':0,'git_writes':0},
    'scope_limit':'Untouched unrelated work, kernels, canonical ledger and published editions were not rehashed. All explicit writes for this assignment were confined to this new workspace.'})

visual=[]
notes={
 'F01_fixed_world.png':'Inspected all six panels: readable labels/legend; same world limits and equal aspect; 200 versus extension labels; marker overlap explicitly qualified.',
 'F02_band_and_point_detail.png':'Inspected final normalized and world-coordinate panels: equal aspect, global normalized limit contains points, no crowded numeric point labels; stable marker legend, zoom spans and endpoint conventions disclosed.',
 'F03_geometry_and_diagnostics.png':'Inspected all six panels: axes and legends readable, two amplitude/readout axes labeled, boundary 200 shading clear, incoming-graph versus completed-displacement indexing disclosed.'}
for name,note in notes.items():
    p=ROOT/'figures'/name;raw=p.read_bytes();width,height=struct.unpack('>II',raw[16:24])
    visual.append({'file':'figures/'+name,**identity(p),'pixels':[width,height],
        'inspection_method':'Codex view_image with detail=original on final saved PNG; visual review, not automated scientific verification',
        'status':'inspected','notes':note})
write('VISUAL_INSPECTION.json',{'recorded_utc':stamp,'figures':visual})

docs=['START_HERE.md','CONSTRUCTION.md','ORIGINAL_EVIDENCE_AND_EXISTING_REPLAY.md','MOTION_AND_GEOMETRY.md','MODEL_RELATIONSHIPS.md','RECORD_SELECTION.md']
future={'MANIFEST.json','REVIEW_ZIP_IDENTITY.json','DOCUMENT_QA.json'}
links=[]
for name in docs:
    p=ROOT/name;assert p.is_file() and p.stat().st_size>1000
    source=p.read_text(encoding='utf-8')
    assert '\ufffd' not in source,name
    for target in re.findall(r'\]\(([^)]+)\)',source):
        if target.startswith(('https://','http://','#')):continue
        target=target.split('#')[0]
        ok=(ROOT/target).is_file() or target in future
        assert ok,(name,target)
        links.append({'document':name,'target':target,'exists_or_generated_here':ok})
audited=[]
for p in sorted(ROOT.glob('*.py')):
    tree=ast.parse(p.read_text(encoding='utf-8'),filename=p.name)
    prohibited=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call):
            n=node.func.attr if isinstance(node.func,ast.Attribute) else node.func.id if isinstance(node.func,ast.Name) else ''
            if n in {'evolve_pass','evolve','GoldenTowerFieldII','normal','uniform','shuffle','seed','eval','exec','run_module','run_path'}:prohibited.append(n)
        if isinstance(node,(ast.Import,ast.ImportFrom)):
            modules=[x.name for x in node.names] if isinstance(node,ast.Import) else [node.module or '']
            assert not any('golden_core' in m or 'tower_II' in m for m in modules),(p.name,modules)
    assert not prohibited,(p.name,prohibited)
    audited.append(p.name)
write('DOCUMENT_QA.json',{'recorded_utc':stamp,'required_five_deliverables_present':True,'new_documents_checked':docs,
    'new_document_links':links,'passive_scripts_parse':audited,
    'static_check_scope':'New top-level scripts parsed and checked for named update/RNG calls and historical imports. No earlier code was executed. This is a narrow source/document check, not a scientific rerun.',
    'source_read_coverage':'All 842 original lines read as text; focused line readback checked constructor, update, observers and selected driver.',
    'visuals_inspected':3,'input_preservation_passed':43,'new_state_updates':0,'rng_draws':0})

exclusions={ZIPNAME,'REVIEW_ZIP_IDENTITY.json','MANIFEST.json'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).as_posix() not in exclusions)
assert not any('__pycache__' in p.parts for p in files)
payload=[{'path':p.relative_to(ROOT).as_posix(),**identity(p)} for p in files]
write('MANIFEST.json',{'assignment':'SRG_SIMULATION_STUDY_06_TOWER_II_CONSTRUCTION_01','created_utc':stamp,
    'scope':'Complete review payload excluding manifest self, ZIP and outer ZIP identity receipt',
    'files':payload,'file_count':len(payload),'bytes_total':sum(r['bytes'] for r in payload)})
zipfiles=files+[ROOT/'MANIFEST.json']
with zipfile.ZipFile(ROOT/ZIPNAME,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(zipfiles):z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(ROOT/ZIPNAME) as z:
    assert z.testzip() is None
    expected={p.relative_to(ROOT).as_posix():identity(p) for p in zipfiles}
    assert set(z.namelist())==set(expected) and len(z.namelist())==len(expected)
    for name,ident in expected.items():
        raw=z.read(name);assert {'bytes':len(raw),'sha256':sha(raw)}==ident,name
write('REVIEW_ZIP_IDENTITY.json',{'file':ZIPNAME,**identity(ROOT/ZIPNAME),'entries':len(zipfiles),
    'created_utc':stamp,'every_entry_matches_current_file':True,'crc_check_passed':True,
    'manifest_identity':identity(ROOT/'MANIFEST.json'),'outer_receipt_not_inside_zip':True})
print(json.dumps({'preserved_inputs':len(preserved),'manifest_files':len(payload),'zip':ZIPNAME,
    'zip_identity':identity(ROOT/ZIPNAME),'zip_entries':len(zipfiles),'new_state_updates':0,'rng_draws':0},indent=2))
