"""SIM06 source/record intake and scoped preservation baseline. No historical imports."""
from pathlib import Path
import hashlib,json,sys,shutil
ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\TORMENT\TRIOCTAGON_new\trioctagon-physics')
R=REPO/'SRG_REDISCOVERY'
def ident(p):
    b=p.read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def recordcopy(src,dst,rows):
    src=Path(src);dst=ROOT/dst
    b=src.read_bytes();dst.parent.mkdir(parents=True,exist_ok=True)
    assert not dst.exists(),dst
    dst.write_bytes(b)
    rows.append({'original':str(src),'copy':dst.relative_to(ROOT).as_posix(),**ident(src)})
rows=[]
s=R/'R0_SOURCE_RECOVERY/selected_sources/MARCH_19023429/srg_golden_tower_II.py'
assert ident(s)=={'bytes':34980,'sha256':'147a32be3b6d6aad17ada6ab7be2fbc3994c3363f74d6a2b351fb8eecda80304'}
recordcopy(s,'original/srg_golden_tower_II.py',rows)
for folder,name in [('R0_SOURCE_RECOVERY','SRG_R0_REPORT.md'),('R1_CLIPPING_AND_SPECTRAL_AUDIT','SRG_R1_REPORT.md'),('R2_AMPLIFICATION_AND_GEOMETRY','SRG_R2_REPORT.md'),('R3_TRANSIENT_H_AND_SYNTHESIS','SRG_R3_REPORT.md')]:
    recordcopy(R/folder/name,'context/'+name,rows)
for name in ['source_manifest.json','external_and_selected_sources.json','data_inventory.json','audited_excerpt_manifest.json','audited_golden_core.py']:
    recordcopy(R/'R0_SOURCE_RECOVERY'/name,'context/R0/'+name,rows)
for name in ['SOURCE_PROVENANCE.json','RAW_DATA_README.md','PAYLOAD_MANIFEST.json']:
    recordcopy(R/'R1_CLIPPING_AND_SPECTRAL_AUDIT'/name,'context/R1/'+name,rows)
for name in ['MATHEMATICAL_REVIEW.md','GPT_REVIEW_BRIEF.md']:
    recordcopy(R/'R3_TRANSIENT_H_AND_SYNTHESIS'/name,'context/R3/'+name,rows)
recordcopy(Path(r'C:\Users\Notandi\Downloads\CODEX_SIM06_TOWER_II_CONSTRUCTION_WORK_ORDER.md'),'WORK_ORDER.md',rows)
run=R/'R1_CLIPPING_AND_SPECTRAL_AUDIT/RUN_01/seed2038_eps1'
names=['X.npy','V.npy','R.npy','Q.npy','actual_rpc_output.npy','positions_at_rpc.npy','noise.npy','L_used.npy',
       'incoming_mean_abs_R.npy','natural_freq.npy','band_id.npy','pass_diagnostics.csv','configuration.json',
       'run_summary.json','source_lock_times.json','rng_initial.json','rng_final.json']
for n in names:recordcopy(run/n,'records/R1_seed2038_eps1/'+n,rows)
(ROOT/'INPUT_BASELINE.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
(ROOT/'READ_ONLY_EXECUTION_BOUNDARY.json').write_text(json.dumps({'new_state_updates':0,'rng_draws':0,
    'historical_module_imports':0,'earlier_checkers_executed':0,
    'allowed':'Read source/records; derive descriptive geometry and figures without constructing or advancing state.',
    'missing_original_locator':str(REPO/'research_files/archive_members/Zenodo_research/19023429/simulations.zip/srg_golden_tower_II.py'),
    'verified_recovered_source':str(s)},indent=2)+'\n')
print(json.dumps({'source_identity':ident(s),'copied_inputs':len(rows),'selected_run':str(run)}))
for n in ['context/R0/data_inventory.json','context/R0/external_and_selected_sources.json']:
    obj=json.loads((ROOT/n).read_text(encoding='utf-8'))
    def walk(x):
        if isinstance(x,dict):
            if any(isinstance(v,str) and ('self_coupled_breathing' in v or 'tower_II' in v) for v in x.values()):print(json.dumps(x,ensure_ascii=False))
            else:
                for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    print('RELEVANT INVENTORY RECORDS',n);walk(obj)

