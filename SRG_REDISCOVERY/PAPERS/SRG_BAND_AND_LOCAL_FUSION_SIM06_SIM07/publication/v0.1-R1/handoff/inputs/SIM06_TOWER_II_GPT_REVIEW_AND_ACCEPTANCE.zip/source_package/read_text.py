"""Read source slices or metadata as text; never imports the historical program."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
name=sys.argv[1]
p=ROOT/name
if len(sys.argv)>2:
    lines=p.read_text(encoding='utf-8-sig').splitlines()
    a=int(sys.argv[2]);b=int(sys.argv[3])
    for i in range(a,min(b,len(lines))+1):print(f'{i:04}: {lines[i-1]}')
else:print(p.read_text(encoding='utf-8-sig'))

