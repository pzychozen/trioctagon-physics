# Independent mathematical review before R3 execution

Codex, 10 October 2026. GPT's supplied R2 review is the claim under examination, not authority over the source. The exact accepted source and R2 reports were read. The arguments below were derived independently; scalar and selected saved-state checks are in MATH_REVIEW_01. No reviewer source engine is imported and no trajectory is propagated.

## H product and integrating factor

The source schedule is H(p)=2 exp(−p/2) cos(p)+exp(−3p/10) sin(p)+(3/2) exp(−7p/10)+exp(−2p/5). The sampled normalization includes H(0)=4.5, with a positive 1e−12 guard. For lambda=.05, the envelope |H|<=5.5 implies m_p=1+.05 H(p)/H_MAX>=169/180>0. Thus every finite product A_p=product(m_j,j=1..p), A_0=1, is positive.

For p>=1, |m_p−1| is bounded by

\[
u_p^*=\frac1{90}(2e^{-p/2}+e^{-3p/10}+\tfrac32e^{-7p/10}+e^{-2p/5}).
\]

This decreasing positive envelope is summable. Its eventual value is below one. For x=m_p−1, |log(1+x)|<=|x|/(1−|x|); the tail of sum log(m_p) therefore converges absolutely. Adding finitely many finite early logs proves that A_infinity is finite and strictly positive, not merely nonnegative.

For sufficiently late M the log-tail is bounded by the sum of four explicit geometric tails divided by 1−u*_(M+1). A bound on the relative product error is exp(log-tail-bound)−1. These are analytic inequalities; the reported numerical evaluations, even at high precision, are not interval-certified decimal bounds.

On a positive, unclipped eta=0 path in exact real arithmetic, R_p=m_p D_p P(X_(p−1)) R_(p−1)+delta 1, delta=1e−9. Dividing by A_p=m_p A_(p−1) gives

\[
u_p=D_pP(X_{p-1})u_{p-1}+\frac{\delta}{A_p}\mathbf1,\qquad u_p=R_p/A_p.
\]

It uses the actual H-on geometry, not the geometry of an H-off field. The offset is also divided by A_p. Common amplitude scaling changes fusion strength; its center also changes slightly because of the fixed 1e−8 weight regularizer. Hence this passive transformation is not the proposed causal control. Under finite arithmetic, retain actual log/exp and matrix regrouping residuals. If clipping activates, apply this identity only to its verified unclipped domain. H's tiny direct late tail does not eliminate persistent effects of its earlier state perturbation.

## Source-specific fusion

Take one nonempty band after diffusion, with n points Y_i, arithmetic center mu, q_i=Q_i>=0, rho=1e−8, kappa=.02 and tau=kappa rho=2e−10. The source center is C=sum((q_i+rho)Y_i)/(sum q_i+n rho), and Z_i=Y_i+kappa q_i(C−Y_i). Because

\[
\sum q_iY_i=(\sum q_i+n\rho)C-n\rho\mu,
\]

summing the updates and dividing by n gives mu_plus−mu=kappa rho(mu−C). This centroid identity only needs nonnegative q (to replace |q| by q); its upper bound q<=50 is unnecessary for this identity alone. It is not exact centroid conservation with the retained regularizer.

Write y_i=Y_i−mu, c=C−mu, a_i=kappa q_i and A=sum a_i. Then c=sum(a_i y_i)/(A+n tau), and mu_plus−mu=−tau c. Set S=sum a_i||y_i||² and T=sum a_i(1−a_i)||y_i−c||². Expanding each squared convex combination and subtracting n||mu_plus−mu||² yields

\[
V(Z)-V(Y)=\frac{-S+A\|c\|^2-T}{n}-\tau^2\|c\|^2.
\]

If 0<=q_i<=50, then 0<=a_i<=1 and T>=0. Weighted Cauchy–Schwarz gives ||sum a_i y_i||²<=A S, so A||c||²<= [A/(A+n tau)]² S<=S. Therefore

\[
V(Y)-V(Z)\ge
\frac{[1-(A/(A+n\tau))^2]S+T}{n}+\tau^2\|c\|^2\ge0.
\]

All q=0 gives A=S=T=c=0, since C=mu, and the stage is unchanged. The positive regularizer makes the denominator valid in this case. Singleton bands are skipped by the source; their center equals their point and variance/shift are zero, consistently with the identities. Empty bands are skipped and no mean/variance formula is evaluated for n=0. Negative q breaks the replacement |q|=q; q>50 removes the sign guarantee on T. Neither case is silently clamped.

This theorem concerns one source-specific within-band fusion stage. It proves neither full-field variance monotonicity, cross-trajectory contraction, a uniform decay rate, nor asymptotic collapse. Diffusion and noise remain separate mechanisms.

## Total variance decomposition

For fixed bands, expand X_i−mu=(X_i−mu_b)+(mu_b−mu). The cross term sums to zero separately in every band. Thus

\[
Rg^2(X)=\sum_b\frac{n_b}{N}V_b(X)+
\sum_b\frac{n_b}{N}\|\mu_b-\mu\|^2.
\]

This exact identity separates within-band spread from band-center separation at each stage. Fusion's tiny band-center shifts can still change the between-band part; the within-band theorem cannot alone be promoted to a full-field theorem.

## Independent-check decision and source qualification

The three derivations are confirmed under their stated conditions. The narrower centroid domain qualification above strengthens precision without conflicting with GPT's claims. There is no scientific disagreement requiring escalation.

The R3 oracle requires an explicit lambda_H argument from actual configuration. It is tested on the same input with .05 and 0 before execution. No source function, constructor, schedule, normalization or field state is changed by this passive adaptation.

The accepted core is byte-identical to R2. Its 224 source-line contents match historical lines 31–254 after the eight-line prefix; the full script has CRLF and the excerpt LF. This is line-content equality, not raw extracted-interval byte identity. Both artifacts are preserved.
