"""Render saved coordinates and passive tables. No simulator, RNG or new updates."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)
X=np.load(ROOT/'records/R1_seed2038_eps1/X.npy',mmap_mode='r',allow_pickle=False)
b=np.load(ROOT/'records/R1_seed2038_eps1/band_id.npy',mmap_mode='r',allow_pickle=False)
def rows(name):
    with (ROOT/'derived'/name).open(newline='') as f:return list(csv.DictReader(f))
g=rows('geometry.csv');bg=rows('band_geometry.csv');gr=rows('graph_boundaries.csv')
def col(table,key):return np.array([float(r[key]) for r in table])
palette=['#1571ad','#d35a24','#26905a','#8555a6']
plt.rcParams.update({'font.size':11,'axes.titlesize':12,'figure.facecolor':'white','savefig.facecolor':'white'})
def spatial(ax,center,half,label=''):
    for axis,c in zip(['x','y','z'],center):
        getattr(ax,'set_'+axis+'lim')(c-half,c+half)
        getattr(ax,'set_'+axis+'label')(axis+label,labelpad=2)
    ax.set_box_aspect((1,1,1));ax.view_init(22,-55)
def save(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=120)
    plt.close(fig)

fig=plt.figure(figsize=(14,9))
states=[0,20,100,200,400,600]
for k,s in enumerate(states):
    ax=fig.add_subplot(2,3,k+1,projection='3d')
    for band in range(4):
        v=X[s,b==band]
        ax.scatter(*v.T,c=palette[band],s=20,alpha=.85,depthshade=False)
    spatial(ax,[0,0,0],5.5)
    tag='R1 extension' if s>200 else 'comparison window'
    ax.set_title(f'State {s} | {tag}\nRg = {float(g[s]["Rg_reused_R1_R2"]):.5g}')
fig.suptitle('Tower II: the same 80 saved points on one fixed world scale',fontsize=17,y=.99)
handles=[Line2D([0],[0],marker='o',color='none',markerfacecolor=palette[i],label=f'Assigned band {i} (20 IDs)') for i in range(4)]
fig.legend(handles=handles,loc='lower center',ncol=4,bbox_to_anchor=(.5,.025))
fig.text(.5,.005,'DERIVED FROM existing R1 seed2038_eps1. No new simulation. Fixed limits ±5.5; equal spatial aspect; marker overlap is not coincidence.',ha='center',fontsize=10)
fig.subplots_adjust(top=.90,bottom=.11,left=.015,right=.97,hspace=.24,wspace=.12)
save(fig,'F01_fixed_world')

ids=np.flatnonzero(b==0); selected=[4,8,9]
colors=['#222222','#d94141','#c28100'];markers=['o','^','s']
cent=X[:,ids].mean(axis=1)
normalized_halfspan=max(2.6,1.1*max(float(np.max(np.abs((X[s,ids]-cent[s])/float(next(r['Rg'] for r in bg if int(r['state'])==s and int(r['band'])==0))))) for s in [20,200,600]))
fig=plt.figure(figsize=(14,9))
metadata=[]
for k,s in enumerate([20,200,600]):
    rg=float(next(r['Rg'] for r in bg if int(r['state'])==s and int(r['band'])==0))
    z=(X[s,ids]-cent[s])/rg
    ax=fig.add_subplot(2,3,k+1,projection='3d')
    ax.scatter(*z.T,c='#9cbbd0',s=28,depthshade=False)
    for i,c,m in zip(selected,colors,markers):
        v=(X[s,i]-cent[s])/rg;ax.scatter(*v,c=c,marker=m,s=55,depthshade=False)
    spatial(ax,[0,0,0],normalized_halfspan,' / band Rg')
    ax.set_title(f'Band 0 at state {s}\nCentered / Rg; actual Rg = {rg:.5g}')
    a,zend=[(0,20),(20,200),(200,600)][k]
    ax=fig.add_subplot(2,3,k+4,projection='3d')
    points=X[a:zend+1,selected,:].reshape(-1,3)
    low=points.min(axis=0);high=points.max(axis=0);mid=(low+high)/2
    half=max(high-low)*.57
    for i,c,m in zip(selected,colors,markers):
        path=X[a:zend+1,i]
        ax.plot(*path.T,color=c,lw=1)
        ax.scatter(*path.T,color=c,s=3,depthshade=False)
        ax.scatter(*path[0],facecolors='white',edgecolors=c,marker=m,s=35,depthshade=False)
        ax.scatter(*path[-1],c=c,marker=m,s=45,depthshade=False)
    spatial(ax,mid,half)
    ax.set_title(f'IDs 4, 8, 9: states {a}–{zend}\nWorld coordinates; axis span {2*half:.3g}')
    metadata.append({'normalized_state':s,'band':0,'actual_band_Rg':rg,'normalized_halfspan':normalized_halfspan,
        'path_window':[a,zend],'path_world_center':mid.tolist(),'path_axis_halfspan':float(half)})
fig.suptitle('One assigned band: shape detail and three persistent point identities',fontsize=17,y=.99)
handles=[Line2D([0],[0],color=c,marker=m,label=f'Point ID {i}') for i,c,m in zip(selected,colors,markers)]
fig.legend(handles=handles,loc='lower center',ncol=3,bbox_to_anchor=(.5,.027))
fig.text(.5,.005,'Top: normalized display only, no rotation fit. Bottom: per-panel world zoom; dots are saved states, lines are reading guides; hollow start / filled end.',ha='center',fontsize=10)
fig.subplots_adjust(top=.9,bottom=.115,left=.015,right=.97,hspace=.30,wspace=.16)
save(fig,'F02_band_and_point_detail')

s=col(g,'state');q=col(gr,'incoming_state');b0=[r for r in bg if int(r['band'])==0]
fig,axes=plt.subplots(3,2,figsize=(14,11))
ax=axes[0,0]
ax.semilogy(s,col(g,'Rg_reused_R1_R2'),color='#222',label='Whole-field Rg (retained)')
ax.semilogy(s,np.sqrt(col(g,'within_band_variance')),color='#1571ad',label='RMS within-band radius')
ax.semilogy(s,np.sqrt(col(g,'between_band_variance')),color='#d35a24',label='RMS band-center separation')
ax.set_ylabel('Length (log scale)');ax.set_title('Size and where the spread resides');ax.legend(fontsize=9)
ax=axes[0,1];ax.plot(s,col(g,'mean_abs_R_reused_R1_R2'),color='#1571ad',label='Mean |R| at state s')
ax.set_ylabel('Mean |R|',color='#1571ad');ax.set_title('Retained R1 amplitude and clipping-limit readout')
ax2=ax.twinx();ax2.plot(s[1:],col(g[1:],'L_for_completed_pass'),color='#d35a24',ls='--',label='L used for pass s (reads state s−1)')
ax2.set_ylabel('L used',color='#d35a24');ax.legend(loc='upper left',fontsize=9);ax2.legend(loc='lower right',fontsize=9)
ax=axes[1,0];ax.step(q,col(gr,'weak_components'),where='post',label='Weak components',color='#1571ad')
ax.step(q,col(gr,'strong_components'),where='post',label='Strong components',color='#999')
ax.set_title('Local graph from incoming saved state s');ax.set_ylabel('Graph components');ax.legend(fontsize=9)
ax=axes[1,1];ax.plot(q,col(gr,'same_band_edges')/400,color='#26905a',label='Same-band neighbors')
ax.plot(q,col(gr,'cross_band_edges')/400,color='#8555a6',label='Other-band neighbors')
ax.set_ylim(0,1);ax.set_title('400 directed local neighbor selections per boundary');ax.set_ylabel('Fraction of selections');ax.legend(fontsize=9)
ax=axes[2,0];ax.plot(s,col(g,'centroid_displacement_from_0'),color='#222',label='Whole-field arithmetic center')
ax.plot(s,col(b0,'center_displacement_from_0'),color='#1571ad',label='Band-0 arithmetic center')
ax.set_title('Movement of centers, separate from spread');ax.set_ylabel('Distance from own state-0 center');ax.legend(fontsize=9)
ax=axes[2,1];ax.semilogy(s[1:],col(g[1:],'mean_completed_step'),color='#1571ad',label='Mean ||V||')
ax.semilogy(s[1:],col(g[1:],'max_completed_step'),color='#d35a24',alpha=.7,label='Maximum ||V||')
ax.set_title('Completed displacements; V is a diagnostic');ax.set_ylabel('Length per completed pass (log)');ax.legend(fontsize=9)
for ax in axes.flat:
    ax.axvline(200,color='#666',ls='--',lw=1)
    ax.axvspan(200,600,color='#b2b6c4',alpha=.10)
    ax.set_xlim(0,600);ax.set_xlabel('Saved state / pass label (see panel)');ax.grid(alpha=.17)
fig.suptitle('Saved movement and its changing local relationships',fontsize=18,y=.99)
fig.text(.5,.952,'Left of boundary 200: historical-configuration comparison window. Shaded right: later R1 extension.',ha='center',fontsize=11)
fig.text(.5,.008,'DERIVED FROM existing R1 seed2038_eps1; retained R1/R2 diagnostics reused where indicated. Graph at state s drives recorded pass s+1 (s≤599).',ha='center',fontsize=10)
fig.tight_layout(rect=[.015,.03,.985,.94],h_pad=2.0,w_pad=2.0)
save(fig,'F03_geometry_and_diagnostics')
(ROOT/'FIGURE_REGISTER.json').write_text(json.dumps({'evidence':'All three figures are new passive renderings of an existing reproduced trajectory, not historical images.',
    'F01':{'file':'figures/F01_fixed_world.png','input':'records/R1_seed2038_eps1/X.npy and band_id.npy; derived/geometry.csv','states':states,'limits':[-5.5,5.5],'equal_aspect':True,'pixels':[1680,1080]},
    'F02':{'file':'figures/F02_band_and_point_detail.png','input':'X.npy, band_id.npy; derived/band_geometry.csv, selected_points.csv','selected_ids':selected,'selection':'lowest three stable IDs in assigned band 0; not leaders or optimized cases','panels':metadata,'equal_aspect':True,'pixels':[1680,1080]},
    'F03':{'file':'figures/F03_geometry_and_diagnostics.png','input':'derived/geometry.csv, band_geometry.csv, graph_boundaries.csv','pixels':[1680,1320]},
    'matplotlib':matplotlib.__version__,'new_state_updates':0,'rng_draws':0},indent=2)+'\n')
print('Wrote three static PNG figures and FIGURE_REGISTER.json; no state updates or RNG draws.')
