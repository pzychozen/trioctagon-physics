# SRG-R1: clipping causality and spectral audit

10 October 2026. Executed by Codex under the owner's approval of GPT's R1 work order. R0 remains accepted within source-recovery scope, with the supplied GPT addendum retained unchanged.

**Completed: four trajectories, 600 passes each, 2,400 trajectory passes total.** The worker finished in **15.873 seconds**, within its unchanged 180-second supervisor limit. No timeout, nonfinite state, failed field preflight, retry, recurrence change or parameter expansion occurred. Five additional single-pass calls were used only for the separately logged preflight.

**Q1 — breathing causality:** for both seeds, disabling versus enabling breathing produced exactly equal X, V, R and preclip Q at every saved pass. Actual noise arrays, positions at the RPCO stage, pass-level RNG fingerprints and full initial/final RNG checkpoints also agree. Every maximum paired difference is **0.0**. No first divergence exists in these runs. There were no lower or upper log-bound crossings, and no fixed-versus-breathing counterfactual output differences on any saved Q. L varies in the enabled runs but is causally inactive along these sampled trajectories.

**Q2 — spectral interpretation:** the mean-only dominant peak tracks the window's first bin, **1/150, 1/300, 1/550 cycles/pass**, for both seeds. Linear detrending removes most variance but leaves slow curved variation; its dominant peak is still the first bin except seed 2038's 550-sample window, where it is the second. The raw traces show substantial growth with smaller variations, not a stable common slow period. These results do not establish an autonomous oscillator. They also do not prove that this model can never oscillate.

The historical 150-sample 1% flag accepts a linear trend and a single pulse, as GPT's addendum predicted. It is retained only as a defective legacy observer. No replacement threshold is used to declare a scientific oscillator.

## 1. Preserved source and executed design

The only field engine used is the unchanged R0 audited `GoldenTowerFieldII` excerpt. Its SHA-256 is:

```text
6b2f0a05df5871abe4fe97a9e56abd233ab55952028ae953a4b7a652fb24d5e8
```

After its existing eight-line R0 header/import prefix, its content matches historical source lines **31–254** exactly. The full historical source hash is `147a32be3b6d6aad17ada6ab7be2fbc3994c3363f74d6a2b351fb8eecda80304`. The full historical script was not imported or launched. See [SOURCE_PROVENANCE.json](SOURCE_PROVENANCE.json).

| Parameter | Executed value |
|---|---|
| Seeds | 2038, 42 |
| Controls | Breathing disabled, epsilon=0; enabled, epsilon=1 |
| Field size / assigned bands | 80 / 4 |
| Passes | 600 per trajectory, 2,400 total |
| Initial X / R | Source uniform [-5,5]^3 / [0,.3] |
| k, alpha, beta, lambda_H | 5, .05, .15, .05 |
| L base, coupling width, mixing strength | 9, 2, .001 |
| Horizon | None |
| RNG | Original NumPy global generator, source seed reset before each whole trajectory |

The four frequency labels remain `.244 * phi^n` for n=-2,-1,0,1, approximately .09319971, .15080029, .244 and .39480029 cycles/pass in the imposed sine modulation. They were neither measured from the trajectory nor changed by the run.

The source stage order remains: incoming-R breathing readout; graph/distance calculation; position diffusion; frequency-weighted resonance exchange and source-labelled mixing; H modulation; band-local fusion; signed RPCO; position noise; velocity/diagnostic recording. Fusion precedes clipping. The observer does not substitute a matrix update, remove forcing, change guards, normalize state, vectorize or reorder source loops.

[HARNESS_AMENDMENTS.md](HARNESS_AMENDMENTS.md) and [R0_TO_R1_RUNNER.diff](R0_TO_R1_RUNNER.diff) explain the changes from the preserved R0 proposed runner. Only execution controls, observations and output handling changed. The actual RPCO output and actual random-normal array are returned unchanged; counterfactual outputs never enter the dynamics. The preflight receipt binds the exact runner, observers, spectral module, fixture and core hashes used for execution.

Exact command executed in PowerShell after activating the requested environment:

```powershell
& 'C:\Users\Notandi\miniconda3\shell\condabin\conda-hook.ps1'
conda activate torment
# cwd: ...\SRG_REDISCOVERY\R1_CLIPPING_AND_SPECTRAL_AUDIT
python run_srg_r1.py --execute --output 'C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R1_CLIPPING_AND_SPECTRAL_AUDIT\RUN_01'
```

`PYTHONDONTWRITEBYTECODE=1`, local R1 temporary directories and UTF-8 output were set for the invocation. The supervisor set OMP/OpenBLAS/MKL/NumExpr thread counts to one for its child only. Python 3.11.15, NumPy 2.4.4 and SciPy 1.17.1 were used in `torment`; no dependencies or environments were modified. The 512 MB expectation was an estimate, not an enforced memory cap. [Execution record](RUN_01/execution_record.json) and [environment](RUN_01/environment.json) retain full details.

## 2. Bounded preflight and instrumentation fidelity

[PREFLIGHT_01/preflight_receipt.json](PREFLIGHT_01/preflight_receipt.json) records **7/7 scoped checks**, with **5 source field calls**, below the permitted maximum of 12. These are finite verification records, not seven independent mathematical theorems.

| Check | Result |
|---|---|
| Source bytes, source interval, syntax | All pass; exact source preserved |
| Independent six-point, three-band calculation | 24 nonzero cross-band mixing entries and three same-band fusion groups exercised; max Q/R error 1.67e-16, X error 1.11e-16, below the declared 5e-15 absolute tolerance |
| Uninstrumented versus instrumented update, real noise | X/V/R agree exactly; before/after RNG fingerprints match exactly; one original RPCO and one original normal call observed |
| Scalar operator controls | Zero, lower-active, upper-active, inactive and constructed log-bound equality values all behave as recorded |
| First-pass clip-divergence fixture | Q, same-pass X/V, fusion-stage positions and actual noise agree; R differs by 1.6660211094813443e-9 for L=9 versus 9.0000135 |
| Legacy spectral controls | Trend and pulse are flagged at 150 samples, an expected defect rather than a preflight failure |
| Detrending controls | Linear trend removed to floating roundoff; declared .08 cycles/pass sine retains its spectral peak at all three lengths |

The first independent field call used a declared zero-noise fixture. The two fidelity calls and two lower-clipping calls used original random draws. All calls are listed in [field_call_ledger.json](PREFLIGHT_01/field_call_ledger.json). No reviewer data census, R0 checker replay, Bridge, QSM, native or historical full suite was rerun.

At zero, `log(abs(0)+1e-9)` lies below -9, so the log crossing count is one, but both signed outputs remain zero. At ±1e-6 and ±1e7, changing L from 9 to 12 changes outputs. At inactive ±.2/.3 it does not. The constructed values `exp(-9)-1e-9` and `exp(9)-1e-9` evaluated to exact log-bound equality in this runtime; equality was logged separately and not counted as a strict crossing. These finite controls verify the reporting distinctions without modifying the engine.

## 3. Q1: effective clipping, equality and first divergence

For pass p, the observer saves Q before clipping, the actual output, L used, and the two passive values

\[
C_9(Q),\qquad C_{9(1+\mu_{p-1})}(Q),\qquad
\mu_{p-1}=\operatorname{mean}|R^{p-1}|,
\]

using the preserved source function

\[
C_L(x)=\operatorname{sgn}(x)\exp\bigl(\operatorname{clip}(\log(|x|+10^{-9}),-L,L)\bigr).
\]

Lower/upper crossings use strict floating comparisons with -L/+L; equality is counted separately. Effective coordinate differences use exact floating `!=`; trajectory agreement uses exact array equality and maximum absolute differences, with no hidden tolerance. The minimum margin is `min_i min(log(abs(Q_i)+delta)+L, L-log(abs(Q_i)+delta))`; it includes the finite logarithm at zeros, while a separate nonzero-only margin is also stored.

| Seed | Epsilon | Completed passes | Log crossings | Effective differing coordinates | Minimum log margin |
|---|---:|---:|---:|---:|---:|
| 2038 | 0 | 600 | 0 | 0 | 5.2370572423 |
| 2038 | 1 | 600 | 0 | 0 | 6.6022926150 |
| 42 | 0 | 600 | 0 | 0 | 5.4431883298 |
| 42 | 1 | 600 | 0 | 0 | 6.8838701536 |

All Q and R values were strictly positive. The saved Q range was [.02321532169, 3.02400049347] for seed 2038 and [.02852964077, 2.34836013881] for seed 42. No boundary equalities or zero inputs occurred in the four trajectories. Across their 192,000 scalar Q observations, both the actual log-crossing count and counterfactual effective-difference count were zero. These observations are correlated samples from four trajectories, not independent trials.

For each seed, paired initial X/V/R, natural frequencies, band labels and pass count agree. At every subsequent pass:

* X, V, R, Q, positions after fusion and actual noise arrays agree exactly; all maximum differences are 0.0.
* Initial/final full MT19937 checkpoints and every before/after pass fingerprint agree.
* Earliest differing X, V, R or Q pass is **null: no divergence observed through pass 600**. There is no actual-run clipping event at which to claim a delayed spatial response. The preflight fixture separately demonstrates correct first-pass stage logging when clipping is effective.

The two 601-row pair CSVs and [pairing_and_first_divergence.json](ANALYSIS_01/pairing_and_first_divergence.json) retain these comparisons. L-containing histories are deliberately not treated as dynamical carriers required to agree.

Read-only raw-data checks also establish exact identities: stored actual RPCO output equals R[1:], X[1:] equals saved fusion-stage positions plus saved noise, V[1:] equals successive X differences, and incoming means correspond to R states 0–599. No nonfinite values or normalized replacements were introduced. See [raw_validation.json](ANALYSIS_01/raw_validation.json).

The result verifies the empirical premise of GPT's conditional induction argument for these runs: changing L cannot change a common trajectory prefix if both bounds return the same RPCO outputs and the random draws agree. It does not establish inactivity for other states, parameters or horizons.

## 4. Q2: raw traces, windows and full spectra

### Raw behavior and sample mapping

| Seed | Initial mean R | Mean R at state 200 | Mean R at state 600 | Enabled L at pass 600 |
|---|---:|---:|---:|---:|
| 2038 | .151692819189 | .548983268650 | 2.182252330475 | 28.632813653512 |
| 42 | .160075758197 | .516269283933 | 1.650212632803 | 23.854283011747 |

Both epsilon settings share each seed's R values. The seed-2038 state-200 mean equals the historical value quoted in the accepted R0 report; this scalar agreement is not a claim of byte-for-byte reproduction of every historical output. L at pass 600 uses **R state 599**, not state 600. Spatial radius of gyration decreases from 5.26157 to .0549954 for seed 2038 and 5.03397 to .0535862 for seed 42, while mean resonance grows. Radius of gyration is a new diagnostic, not an information-compression measure or physical energy.

![Raw resonance and L](figures/trajectory_overview.png)

| Stored L slice | L update passes | Incoming-R state indices | Length / frequency spacing |
|---|---|---|---|
| [50:200] | 51–200 | 50–199 | 150 / 1/150 |
| [50:350] | 51–350 | 50–349 | 300 / 1/300 |
| [50:600] | 51–600 | 50–599 | 550 / 1/550 |

All frequencies are **cycles/pass**, without a Hz interpretation. For each window and both L/incoming-mean-R signals, both mean removal and linear detrending are stored. Linear fits use local sample indices 0,...,n-1, so the saved intercept belongs to that window's first sample. No taper, zero-padding, interpolation, changed integration cadence or spectral selection filter is applied. Every rFFT bin, including labelled DC and Nyquist, is retained with raw power and complex coefficients; the plots omit DC and normalize power only for display.

### Dominant enabled-L peaks

`Fraction` below means peak power divided by total nonzero-bin power. A high fraction of a curved trend does not by itself indicate sustained oscillation.

| Seed | Samples | Mean-only peak | Fraction | Linear-detrended peak | Fraction | Std before / after linear detrending |
|---|---:|---:|---:|---:|---:|---:|
| 2038 | 150 | .006666667 | .588718 | .006666667 | .879172 | .812791 / .087626 |
| 2038 | 300 | .003333333 | .599937 | .003333333 | .913885 | 2.674763 / .551038 |
| 2038 | 550 | .001818182 | .702573 | .003636364 | .451264 | 5.600343 / .628781 |
| 42 | 150 | .006666667 | .601206 | .006666667 | .891605 | .728307 / .074740 |
| 42 | 300 | .003333333 | .590279 | .003333333 | .898607 | 2.353095 / .493228 |
| 42 | 550 | .001818182 | .773570 | .001818182 | .424717 | 4.615858 / .914791 |

The raw mean-only feature follows frequency-bin spacing exactly. Linear detrending removes approximately 95.6–99.0% of variance across these windows, but cannot remove arbitrary nonlinear growth or a transition in slope. The remaining low-bin features vary with window/seed and do not select a stable common slow period. We do not infer that every residual feature is an artifact: smaller faster spectral features are visible, and the known assigned frequency forcing remains in the recurrence. Their causal origins have not been isolated by this experiment.

Disabled L is exactly constant at 9. Its historical variance guard is false and its source-reported frequency is zero. The analysis preserves unthresholded argmax indices even for zero or roundoff power; those indices are explicitly not physical frequency measurements. Constant/linear synthetic fits likewise leave tiny numerical residuals, which should not be interpreted through normalized peak fractions alone.

![Full nonzero spectra](figures/spectral_windows.png)

### Legacy flag and diagnostic controls

For 150 real mean-zero samples, there are 75 nonzero rFFT bins. If their total power is nonzero, the largest has at least 1/75 of that total, exceeding 1%. Thus the intended historical percentage test is necessarily true for every nonconstant trace reaching its `std > 1e-8` branch. The finite controls confirm this in the actual arithmetic:

| 150-sample control | Legacy flag | Mean-only peak fraction | Result of linear detrending |
|---|---|---:|---|
| Constant | false | 0 | Roundoff only |
| Linear trend | true | .6079619575 | Std 4.92e-15; trend removed |
| One isolated pulse | true | .0133333333 | Pulse remains, as expected |
| Sine at .08 cycles/pass | true | 1 | Same .08 peak retained; fraction .9959553 |

The same controls were examined at 300 and 550 samples. The trend's legacy flag remains true, while detrending reduces its residual std below 3.61e-14. The sine's peak remains .08 at all lengths. The pulse's legacy flag becomes false in the longer mean-only windows; linear detrending does not have to remove a pulse. This demonstrates observer behavior, not a new oscillator-classification rule. Source-style and parallel residual-rule flags are retained with different labels and neither is used to decide Q2 scientifically.

![Synthetic controls](figures/diagnostic_controls.png)

### L is an affine readout, not independent spectral corroboration

For correctly aligned samples, each run obeys

\[
L_p-\overline L=9\epsilon\left(\mu_{p-1}-\overline\mu\right).
\]

Across all windows, the maximum centered-array residual is **6.44e-15** and maximum nonzero complex-Fourier residual is **2.40e-13**. All declared floating-tolerance checks pass. These are roundoff-level checks of the known affine law, not exact bitwise spectral equality or independent evidence for a second oscillator. See [affine_readout_checks.json](ANALYSIS_01/affine_readout_checks.json). The full 48 field-signal/window/processing records are in [spectral_summary.json](ANALYSIS_01/spectral_summary.json) and the associated NPZ files; 24 synthetic-control records are retained separately.

## 5. Mathematical implication and limits

**The useful next analytical object is the coupled amplification of resonance and geometry in the inactive-clipping regime.** For frozen incoming geometry, frequencies and pass p, GPT's source decomposition gives

\[
Q=m_p(D_pP_p+K_p)R.
\]

Since the observed Q stays positive and inside both bounds, the real-arithmetic RPCO expression on these trajectories is `R_next = Q + 1e-9 * 1`, subject to the source's floating log/exp evaluation. L is then an algebraic readout without a causal effect on the sampled dynamics. This supports studying growth through that time- and geometry-dependent linear resonance substage, coupled to the unchanged nonlinear position update. It does not make the whole system linear or autonomous and does not authorize replacing the source with a matrix implementation.

Two seeds over 600 passes do not prove global inactivity, a limiting fixed point, universal instability, or absence of possible oscillations. The observed growing traces and window-dependent slow peaks do not establish a sustained intrinsic period. Prescribed frequency modulation and H remain. No independent gamma estimator exists in this engine; no zeta-coupling experiment was performed or claimed. No new feedback, phase, physical particle interpretation, centre force or integration is proposed here.

## 6. Payloads, preservation and review

All new work is under `C:\TORMENT\TRIOCTAGON_new\trioctagon-physics\SRG_REDISCOVERY\R1_CLIPPING_AND_SPECTRAL_AUDIT`. No earlier R1 directory existed at the start. The decision ZIP was copied and safely extracted below this directory, rather than writing a new sibling outside the authorized R1 destination. Its 16 manifested payloads were hash-verified.

The preservation baseline includes **97 OLD_MATERIAL files and all 240 R0 files**, including its delivered ZIP and receipts. Final verification is recorded in [PRESERVATION_FINAL.json](PRESERVATION_FINAL.json). No historical source, R0 payload, kernel, UI, published work, environment or Git metadata was edited. No Git commands, network operations, historical GUI launchers, installations or external publication were used.

* [RAW_DATA_README.md](RAW_DATA_README.md) documents all four raw trajectory directories and exact array shapes/index conventions.
* `RUN_01/seed*_eps*/` contains 601 full X/V/R states, 600 Q/actual/counterfactual/noise/fusion-stage/readout samples, per-pass clipping/RNG diagnostics, complete initial/final RNG states and configurations.
* `ANALYSIS_01/` contains both every-pass pair comparisons, first-divergence evidence, raw identities, full spectra, detrend coefficients and affine checks.
* `PREFLIGHT_01/` preserves the five-call ledger, fixtures, seven-check receipt and full synthetic controls. Its code hashes match the completed execution record.
* `sources/`, the copied core, provenance, passive modules and runner diff enable source and arithmetic review without importing a historical launcher.

`SRG_R1_GPT_REVIEW.zip` includes these raw and derived payloads, the report, figures, provenance and received GPT decision. Temporary/cache files are excluded. `PAYLOAD_MANIFEST.json` hashes every packaged payload except itself; the external `DELIVERY_RECEIPT.json` hashes and verifies the finished ZIP. The three scientific figures were visually inspected; no clipped labels or layout repairs were needed.

Execution accounting is final: **5 preflight field calls + 2,400 trajectory field calls; zero analysis/plot field calls**. The experiment is completed, not prepare-only. There are no unresolved harness failures requiring an owner decision.
