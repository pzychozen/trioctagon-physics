"""Bounded intake of additional cited evidence; no simulator import or execution."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
R=ROOT.parents[1]
baseline=json.loads((ROOT/'INPUT_BASELINE.json').read_text())
items=[]
old=R/'R0_SOURCE_RECOVERY/selected_sources/MARCH_19023429'
for name in ['self_coupled_breathing.csv','The_Golden_Tower_Part_II.md']:
    items.append((old/name,'original/'+name))
for name in ['summary.json','geometry_stages.csv','band_statistics_and_centroids.csv','directed_band_edges.csv','stage_budget.csv']:
    items.append((R/'R2_AMPLIFICATION_AND_GEOMETRY/BASELINE_AUDIT_01/seed2038'/name,'context/R2_seed2038/'+name))
pub=R/'PAPERS/SRG_LOCAL_GEOMETRY_AND_RESONANCE_SIM04_SIM05/publication/v0.1.1'
items.extend([(pub/'manuscript.tex','context/Volume_II_manuscript.tex'),(pub/'evidence/originals/SIM05/srg_infinity.py','context/srg_infinity.py')])
items.append((pub/'evidence/originals/SIM04/srg_seed_explorer.py','context/srg_seed_explorer.py'))
for src,rel in items:
    b=src.read_bytes(); dst=ROOT/rel
    if dst.exists():
        assert dst.read_bytes()==b,dst
        assert any(x['copy']==rel for x in baseline),rel
        continue
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
    baseline.append({'original':str(src),'copy':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(ROOT/'INPUT_BASELINE.json').write_text(json.dumps(baseline,indent=2)+'\n')
print('Copied',len(items),'additional inputs; baseline',len(baseline))
